package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;

public class LaneSegmentTest {

	private static final int MIN_DISTANCE_METERS = 1;
	private Vehicle v1;
	private Vehicle v2;
	private Vehicle v3;
	private Vehicle v4;
	private RoadSegment rs1;
	private RoadSegment rs2;
	private Vehicle v5;
	private Vehicle v6;
	private Vehicle v7;
	

	@Before
	public void setup() {

		RoadGeometry rm1 = new RoadGeometry();
		rm1.addPoint(10, 10);
		rm1.addPoint(15, 30);
		rm1.addPoint(30, 10);
		rm1.addPoint(100, 100);

		rs1 = new RoadSegment(rm1,2);

		RoadGeometry rm2 = new RoadGeometry();
		rm2.addPoint(100, 100);
		rm2.addPoint(150, 100);
		rm2.addPoint(150, 150);
		rm2.addPoint(100, 200);

		rs2 = new RoadSegment(rm2,2);
		v1 = new Vehicle(20);
		v2 = new Vehicle(50);
		v3 = new Vehicle(100);
		v4 = new Vehicle(150);

		
		v5 = new Vehicle(15);
		v6 = new Vehicle(30);
		v7 = new Vehicle(100);

		addVehicles(0);

		rs1.getLaneSegments().get(0).setSinkLaneSegment(rs2.getLaneSegments().get(0));
		rs2.getLaneSegments().get(0).setSourceLaneSegment(rs1.getLaneSegments().get(0));
		rs1.getLaneSegments().get(1).setSinkLaneSegment(rs2.getLaneSegments().get(1));
		rs2.getLaneSegments().get(1).setSourceLaneSegment(rs1.getLaneSegments().get(1));
		
//		v1 = new Vehicle(10);
//		v2 = new Vehicle(40);
//		v3 = new Vehicle(60);
//		v4 = new Vehicle(20);
//		v5 = new Vehicle(40);
//		
		
		RoadNetwork rn = new RoadNetwork();
		rn.addRoadSegment(rs1);
	}

	@Test
	public void testFrontVehicleLane0() {
		
		VehicleWithDistance front = rs1.getLaneSegments().get(0).frontVehicle(VehicleFactory.createObstacle(10));
		assertEquals(v1, front.getVehicle());
//		assertEquals(10, front.getDistance(), 0.0001);
		front = rs1.getLaneSegments().get(0).frontVehicle(VehicleFactory.createObstacle(30));
		assertEquals(v2, front.getVehicle());
		front = rs1.getLaneSegments().get(0).frontVehicle(VehicleFactory.createObstacle(50));
		assertEquals(v3, front.getVehicle());
		front = rs1.getLaneSegments().get(0).frontVehicle(VehicleFactory.createObstacle(110));
		assertEquals(v4, front.getVehicle());
		// segment overflow
		front = rs1.getLaneSegments().get(0).frontVehicle(VehicleFactory.createObstacle(155));
		assertEquals(v5, front.getVehicle());
//		assertEquals(rs1.getRoadLength() - 155 + v5.getRearPosition(), front.getDistance(), 0.00001);
		// second segment
		front = rs2.getLaneSegments().get(0).frontVehicle(VehicleFactory.createObstacle(20));
		assertEquals(v6, front.getVehicle());

		// without parameter
		Vehicle v = rs2.getLaneSegments().get(0).frontVehicle();
		assertEquals(v5, v);

		// with vehicle as parameter
		front = rs1.getLaneSegments().get(0).frontVehicle(v2);
		assertEquals(v3, front.getVehicle());

		front = rs1.getLaneSegments().get(0).frontVehicle(v4);
		assertEquals(v5, front.getVehicle());
	}
	
	@Test
	public void testFrontVehicleLane1() {
		v1 = new Vehicle(v1.getFrontPosition()-MIN_DISTANCE_METERS/2);
		v2 = new Vehicle(v2.getFrontPosition()-MIN_DISTANCE_METERS/2);
		v3 = new Vehicle(v3.getFrontPosition()-MIN_DISTANCE_METERS/2);
		v4 = new Vehicle(v4.getFrontPosition()-MIN_DISTANCE_METERS/2);
		v5 = new Vehicle(v5.getFrontPosition()-MIN_DISTANCE_METERS/2);
		v6 = new Vehicle(v6.getFrontPosition()-MIN_DISTANCE_METERS/2);
		v7 = new Vehicle(v7.getFrontPosition()-MIN_DISTANCE_METERS/2);

		addVehicles(1); //a second time to add them also to lane 2
		VehicleWithDistance front = rs1.getLaneSegments().get(1).frontVehicle(VehicleFactory.createObstacle(10));
		assertEquals(v1, front.getVehicle());
//		assertEquals(10, front.getDistance(), 0.0001);
		front = rs1.getLaneSegments().get(1).frontVehicle(VehicleFactory.createObstacle(30));
		assertEquals(v2, front.getVehicle());
		front = rs1.getLaneSegments().get(1).frontVehicle(VehicleFactory.createObstacle(50));
		assertEquals(v3, front.getVehicle());
		front = rs1.getLaneSegments().get(1).frontVehicle(VehicleFactory.createObstacle(110));
		assertEquals(v4, front.getVehicle());
		// segment overflow
		front = rs1.getLaneSegments().get(1).frontVehicle(VehicleFactory.createObstacle(155));
		assertEquals(v5, front.getVehicle());
		assertEquals(rs1.getRoadLength() - 155 + v5.getRearPosition(), front.getDistance(), 0.00001);
		// second segment
		front = rs2.getLaneSegments().get(1).frontVehicle(VehicleFactory.createObstacle(20));
		assertEquals(v6, front.getVehicle());

		// without parameter
		Vehicle v = rs2.getLaneSegments().get(1).frontVehicle();
		assertEquals(v5, v);

		// with vehicle as parameter
		front = rs1.getLaneSegments().get(1).frontVehicle(v2);
		assertEquals(v3, front.getVehicle());

		front = rs1.getLaneSegments().get(1).frontVehicle(v4);
		assertEquals(v5, front.getVehicle());
	}

//	@Test
//	public void testRearVehicleLane0() {
//		VehicleWithDistance rear = rs1.getLaneSegments().get(0).rearVehicle(300);
//		assertEquals(v4, rear.getVehicle());
//		rear = rs1.getLaneSegments().get(0).rearVehicle(new Vehicle(40));
//		assertEquals(v1, rear.getVehicle());
//		assertEquals(20, rear.getDistance(), 0.0001);
//		rear = rs1.getLaneSegments().get(0).rearVehicle(50);
//		assertEquals(v1, rear.getVehicle());
//		assertEquals(30, rear.getDistance(), 0.0001);
//		// segment overflow
//		rear = rs2.getLaneSegments().get(0).rearVehicle(5.2);
//		assertEquals(v4, rear.getVehicle());
//		assertEquals(rs1.getLaneSegments().get(0).getRoadLength() - v4.getFrontPosition() + 5.2, rear.getDistance(), 0.0001);
//
//		// without parameter
//		Vehicle v = rs2.getLaneSegments().get(0).rearVehicle();
//		assertEquals(v7, v);
//
//		// with vehicle as parameter
//		rear = rs1.getLaneSegments().get(0).rearVehicle(v2);
//		assertEquals(v1, rear.getVehicle());
//
//		rear = rs2.getLaneSegments().get(0).rearVehicle(v5);
//		assertEquals(v4, rear.getVehicle());
//	}
	
	private void addVehicles(int lane) {
		rs1.addVehicle(v1,lane);
		rs1.addVehicle(v2,lane);
		rs1.addVehicle(v3,lane);
		rs1.addVehicle(v4,lane);

		rs2.addVehicle(v5,lane);
		rs2.addVehicle(v6,lane);
		rs2.addVehicle(v7,lane);
	}
}

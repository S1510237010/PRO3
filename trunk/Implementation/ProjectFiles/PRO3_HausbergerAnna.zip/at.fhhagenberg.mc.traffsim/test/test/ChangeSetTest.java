package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import at.fhhagenberg.mc.traffsim.changes.ChangeSet;
import at.fhhagenberg.mc.traffsim.changes.ChangeSetDateConverter;
import at.fhhagenberg.mc.traffsim.changes.ChangeSetItem;
import at.fhhagenberg.mc.traffsim.changes.ChangeSetList;
import at.fhhagenberg.mc.traffsim.changes.Changelog;

public class ChangeSetTest {

	public static void main(String[] args) {

		XStream xstream = new XStream(new DomDriver("UTF-8"));
		xstream.ignoreUnknownElements();
		xstream.autodetectAnnotations(true);
		xstream.ignoreUnknownElements();
		xstream.processAnnotations(new Class[] { Changelog.class, ChangeSet.class, ChangeSetItem.class, ChangeSetList.class });
		xstream.registerConverter(new ChangeSetDateConverter());
		try {
			Object o = xstream.fromXML(new FileInputStream(
					new File("C:/Users/Christian/Documents/FuE/Dissertation/Java/workspace/at.fhhagenberg.mc.traffsim/changelog.xml")));
			System.out.println(o);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

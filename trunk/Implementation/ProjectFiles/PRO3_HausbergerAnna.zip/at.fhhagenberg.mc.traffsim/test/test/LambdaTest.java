package test;

import java.util.ArrayList;
import java.util.List;

public class LambdaTest {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();

		for (int i = 0; i < 1000; i++) {
			list.add(i);
		}

		System.out.println("Serial stream: ");
		long start = System.currentTimeMillis();
		list.stream().forEach(item -> System.out.println(item));
		System.out.println("Time: " + (System.currentTimeMillis() - start) + "\n");
		System.out.println("Parallel stream: ");
		start = System.currentTimeMillis();
		list.parallelStream().forEach(item -> System.out.println(item));
		System.out.println("Time: " + (System.currentTimeMillis() - start) + "\n");
	}

}

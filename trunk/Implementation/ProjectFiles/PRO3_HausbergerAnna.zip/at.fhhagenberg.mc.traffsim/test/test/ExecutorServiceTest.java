package test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import at.fhhagenberg.mc.traffsim.util.types.NamedThreadFactory;

public class ExecutorServiceTest {

	private static ExecutorService exec;

	private class MyCallable implements Callable<Object> {

		private int var;

		public MyCallable(int var) {
			this.var = var;
		}

		@Override
		public Object call() throws Exception {
			System.out.println(var);
			return null;
		}

	}

	public static void main(String[] args) {
		new ExecutorServiceTest().doIt();
	}

	public void doIt() {
		List<Callable<Object>> tasks = new ArrayList<>();
		exec = Executors.newFixedThreadPool(3, new NamedThreadFactory("name"));
		for (int i = 0; i < 10000; i++) {
			tasks.add(new MyCallable(i));
		}
		try {
			long start = System.currentTimeMillis();
			exec.invokeAll(tasks);
			System.out.println("time: " + (System.currentTimeMillis() - start));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

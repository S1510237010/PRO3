package test;

import java.util.Collections;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.DefaultJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.SpatialCache;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;

public class NetworkCreator {
	public static RoadNetwork createNetwork() {
		RoadNetwork n = new RoadNetwork();
		RoadGeometry rg1 = new RoadGeometry();
		rg1.addPoint(new Vector(-120, -10));
		rg1.addPoint(new Vector(-90, -5));
		rg1.addPoint(-50, -10);
		rg1.addPoint(0, 40);

		RoadGeometry rg2 = new RoadGeometry();
		rg2.addPoint(0, 40);
		rg2.addPoint(new Vector(110, 80));

		RoadGeometry rg3 = new RoadGeometry();
		rg3.addPoint(110, 80);
		rg3.addPoint(150, 100);
		rg3.addPoint(150, 150);
		rg3.addPoint(100, 200);

		RoadGeometry rg4 = new RoadGeometry();
		rg4.addPoint(100, 200);
		rg4.addPoint(50, 150);
		rg4.addPoint(20, 150);
		rg4.addPoint(-40, 250);
		rg4.addPoint(-80, 250);

		RoadGeometry rg51 = new RoadGeometry();
		rg51.addPoint(-86, 245);
		rg51.addPoint(-150, 150);
		rg51.addPoint(-200, 140);

		RoadGeometry rg52 = new RoadGeometry();
		rg52.addPoint(-84, 250);
		rg52.addPoint(-150, 280);
		rg52.addPoint(-350, 280);

		RoadSegment rs1 = new RoadSegment(rg1, 3, 1);
		RoadSegment rs2 = new RoadSegment(rg2, 3, 2);
		RoadSegment rs3 = new RoadSegment(rg3, 2, 3);
		RoadSegment rs4 = new RoadSegment(rg4, 3, 4);

		RoadSegment rs51 = new RoadSegment(rg51, 2, 51);
		RoadSegment rs52 = new RoadSegment(rg52, 2, 52);

		rs2.getLaneSegments().get(2).setLaneType(Lane.Type.ENTRANCE);

		Vehicle obstacle = VehicleFactory.createObstacle(rs2.getLaneSegments().get(2).getRoadLength());
		obstacle.setType(VehicleType.OBSTACLE);
		rs2.addVehicle(obstacle, 2);

		n.addRoadSegment(rs1);
		n.addRoadSegment(rs2);
		n.addRoadSegment(rs3);
		n.addRoadSegment(rs4);
		n.addRoadSegment(rs52);
		n.addRoadSegment(rs51);
		rs1.setSinkRoadSegment(rs2);
		rs2.setSinkRoadSegment(rs3);
		rs3.setSinkRoadSegment(rs4);

		AbstractJunction c = new DefaultJunction(0, new SpatialCache(60000));
		rs4.setJunction(c);
		c.addConnectionOut(rs51);
		c.addConnectionOut(rs52);
		n.addJunction(c);

		// ////////////
		RoadGeometry rg1_1 = new RoadGeometry(rg1);
		Collections.reverse(rg1_1.getPoints());
		RoadSegment rs1_1 = new RoadSegment(rg1_1, 2);
		n.addRoadSegment(rs1_1);

		RoadGeometry rg2_1 = new RoadGeometry(rg2);
		Collections.reverse(rg2_1.getPoints());
		RoadSegment rs2_1 = new RoadSegment(rg2_1, 2, 21);
		n.addRoadSegment(rs2_1);

		RoadGeometry rg3_1 = new RoadGeometry(rg3);
		Collections.reverse(rg3_1.getPoints());
		RoadSegment rs3_1 = new RoadSegment(rg3_1, 2, 31);

		RoadGeometry rg4_1 = new RoadGeometry(rg4);
		Collections.reverse(rg4_1.getPoints());
		RoadSegment rs4_1 = new RoadSegment(rg4_1, 2, 41);

		RoadGeometry rg52_1 = new RoadGeometry(rg52);
		Collections.reverse(rg52_1.getPoints());
		RoadSegment rs52_1 = new RoadSegment(rg52_1, 2, 521);

		n.addRoadSegment(rs3_1);
		n.addRoadSegment(rs4_1);
		n.addRoadSegment(rs52_1);

		rs4_1.setSinkRoadSegment(rs3_1);
		rs3_1.setSinkRoadSegment(rs2_1);
		rs2_1.setSinkRoadSegment(rs1_1);
		c.addConnectionOut(rs4_1);
		rs52_1.setJunction(c);

		return n;
	}

	public static RoadNetwork createStraight() {
		RoadNetwork n = new RoadNetwork();
		RoadGeometry rg1 = new RoadGeometry();
		rg1.addPoint(new Vector(10, 10));
		rg1.addPoint(700, 10);
		n.addRoadSegment(new RoadSegment(rg1, 2));
		return n;
	}
}

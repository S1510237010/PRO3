package test;

import static org.junit.Assert.assertArrayEquals;

import java.util.Date;

import org.junit.Test;

import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.statistics.LaneStatisticsData;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;

public class RoadStatisticsDataTest {
	@Test
	public void TestRoadStatisticsSort() {
		LaneStatisticsData data1 = new LaneStatisticsData();
		LaneStatisticsData data2 = new LaneStatisticsData();
		SimulationModel model = new SimulationModel("test");
		Vehicle v1 = VehicleFactory.createVehicle(model, 10, 7, null, 10, "", "", "", "", "");
		Vehicle v2 = VehicleFactory.createVehicle(model, 10, 7, null, 10, "", "", "", "", "");
		Vehicle v3 = VehicleFactory.createVehicle(model, 10, 7, null, 10, "", "", "", "", "");
		Vehicle v4 = VehicleFactory.createVehicle(model, 10, 7, null, 10, "", "", "", "", "");
		Date date = new Date();
		data1.vehiclePassed(date, v1);
		data1.vehiclePassed(new Date(date.getTime() + 2000), v2);
		data2.vehiclePassed(new Date(date.getTime() + 100), v3);
		data2.vehiclePassed(new Date(date.getTime() + 1900), v4);

		LaneStatisticsData merged = data1.merge(data2);
		assertArrayEquals(merged.getVehicleIds().toArray(new Long[] {}), new Long[] { 0l, 2l, 3l, 1l });
	}
}

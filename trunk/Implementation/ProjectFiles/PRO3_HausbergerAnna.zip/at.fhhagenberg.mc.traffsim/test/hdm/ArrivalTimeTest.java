package hdm;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Random;

import at.fhhagenberg.mc.traffsim.util.math.MathUtil;

public class ArrivalTimeTest {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		StringBuilder sb2 = new StringBuilder();
		String filePath = "C:\\Users\\Lokal\\Desktop\\sampleRand.txt";
		String filePath2 = "C:\\Users\\Lokal\\Desktop\\sampleUtil.txt";
		PrintWriter writer;

		Random r = new Random(1l);

		for (int i = 0; i < 10000; i++) {
			sb.append(String.valueOf(getExponential(r, 1 / (3600.0 / 70.0))) + "\n");
		}

		for (int i = 0; i < 10000; i++) {
			sb2.append(String.valueOf(MathUtil.distributeExponentially(3600.0 / 70.0)) + "\n");
		}

		try {
			writer = new PrintWriter(filePath, "UTF-8");
			writer.print(sb.toString());
			writer.close();

			writer = new PrintWriter(filePath2, "UTF-8");
			writer.print(sb2.toString());
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	public static double getExponential(Random r, double lambda) {
		return -Math.log(1 - r.nextDouble()) / lambda;
	}
}
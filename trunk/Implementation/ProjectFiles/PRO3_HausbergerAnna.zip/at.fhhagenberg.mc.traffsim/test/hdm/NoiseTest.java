package hdm;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.Noise;

public class NoiseTest {

	private static double dt = 0.05;

	public static void main(String[] args) {

		// Evaluate development of relative noise
		NoiseDataBean noiseBean = new NoiseDataBean();
		noiseBean.setFluctStrength(0.8);
		noiseBean.setTau(20);
		noiseBean.setAmplifier(0.05);

		Noise noise = new Noise(noiseBean);

		StringBuilder sb = new StringBuilder();
		String filePath = "C:\\Users\\Manuel\\Desktop\\relativeNoise.txt";
		PrintWriter writer;

		for (int i = 0; i < 1000; i++) {
			noise.update(dt);
			double error = noise.getError();
			double amplifier = noise.getAmplifier();
			double value = Math.exp(amplifier * error);
			sb.append(String.valueOf(value) + "\n");
		}

		try {
			writer = new PrintWriter(filePath, "UTF-8");
			writer.print(sb.toString());
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// Evaluate development of additive noise
		noiseBean = new NoiseDataBean();
		noiseBean.setFluctStrength(0.5);
		noiseBean.setTau(20);
		noiseBean.setAmplifier(0.01);

		noise = new Noise(noiseBean);

		sb = new StringBuilder();
		filePath = "C:\\Users\\Manuel\\Desktop\\additiveNoise.txt";

		for (int i = 0; i < 1000; i++) {
			noise.update(dt);
			double error = noise.getError();
			double amplifier = noise.getAmplifier();
			double value = amplifier * error;
			sb.append(String.valueOf(value) + "\n");
		}

		try {
			writer = new PrintWriter(filePath, "UTF-8");
			writer.print(sb.toString());
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}
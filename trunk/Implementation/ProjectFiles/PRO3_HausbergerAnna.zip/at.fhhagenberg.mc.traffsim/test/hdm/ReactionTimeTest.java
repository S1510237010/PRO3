package hdm;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import at.fhhagenberg.mc.traffsim.util.math.MathUtil;

public class ReactionTimeTest {

	static double std_log = 170.8468;
	static double mean_log = 196.6155;
	static double mean_norm = 900;
	static double std_norm = 50;
	static double mean_exp = 150;
	
	static String log_path = "C:\\Users\\Manuel\\Documents\\Work\\log.txt";
	static String ex_gauss_path = "C:\\Users\\Manuel\\Documents\\Work\\ex_gauss.txt";
	
	public static void main(String[] args) {

		StringBuilder sb = new StringBuilder();
		PrintWriter writer;
		
		for(int i = 0; i < 10000; i++){
			double result = MathUtil.distributeLogNormally(mean_log, std_log);
			sb.append(result + "\n");
		}
		
		try {
			writer = new PrintWriter(log_path, "UTF-8");
			writer.print(sb.toString());
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		sb = new StringBuilder();
		
		for(int i = 0; i < 10000; i++){
			double result = MathUtil.distributeExGaussian(mean_norm, std_norm, mean_exp);
			sb.append(result + "\n");
		}

		try {
			writer = new PrintWriter(ex_gauss_path, "UTF-8");
			writer.print(sb.toString());
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}

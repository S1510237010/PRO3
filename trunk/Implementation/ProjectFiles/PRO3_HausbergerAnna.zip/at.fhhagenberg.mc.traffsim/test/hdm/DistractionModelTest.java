package hdm;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionType;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.ExtendedHumanDriverControl;
import at.fhhagenberg.mc.util.CollectionUtil;

public class DistractionModelTest {
	public static int GROUND_TRUTH_VEHICLES = 70;
	public static int NUM_VEHICLES = 1000;
	public static int NUM_ITERATIONS = 100;
	public static long NUM_HOURS = 3;
	public static long SIMULATION_TIME_S = 3600 * NUM_HOURS;
	public static double UPDATE_INTERVAL_S = 0.1;

	public static boolean IS_STOCHASTIC = true;

	public static void main(String[] args) {
		DistractionModel model = new DistractionModel();
		model.setArrivalStochastic(IS_STOCHASTIC);
		model.setExposureStochastic(IS_STOCHASTIC);

		// Add distraction types
		List<DistractionType> distractionTypes = getDistractionTypes();

		for (DistractionType type : distractionTypes) {
			model.addDistractionType(type);
		}

		List<Vehicle> vehicles = new ArrayList<>();

		// Add vehicle conglomerate
		for (int i = 0; i < NUM_VEHICLES; i++) {
			Vehicle v = createVehicle();
			vehicles.add(v);
			model.vehicleGenerated(v);
		}

		Date date = new Date();
		long duration = (long) (SIMULATION_TIME_S / UPDATE_INTERVAL_S);
		Map<Long, Double> minDuration = new HashMap<>();
		Map<Long, Double> maxDuration = new HashMap<>();
		Map<Long, Double> totalDuration = new HashMap<>();
		Map<Long, Double> exposure = new HashMap<>();
		Map<Long, Long> occurrences = new HashMap<>();
		Map<Long, Double> meanDuration = new HashMap<>();
		Map<Long, Double> stdDuration = new HashMap<>();
		Map<Long, Double> percentileMin = new HashMap<>();
		Map<Long, Double> percentileMax = new HashMap<>();

		// Run simulation
		for (int j = 0; j < NUM_ITERATIONS; j++) {
			model.reset();
			model.initialize(vehicles);

			for (int i = 0; i < duration; i++) {
				model.timeStep(UPDATE_INTERVAL_S, date, 0d);
			}

			for (DistractionType type : model.getDistractionTypes()) {
				double[] durations = CollectionUtil.toPrimitiveDoubleArray(model.getDurationsPerType(type.getId()));
				DescriptiveStatistics stat = new DescriptiveStatistics(durations);
				Arrays.sort(durations);

				if (!minDuration.containsKey(type.getId())) {
					minDuration.put(type.getId(), stat.getMin());
					maxDuration.put(type.getId(), stat.getMax());
					totalDuration.put(type.getId(), stat.getSum());
					meanDuration.put(type.getId(), stat.getMean());
					stdDuration.put(type.getId(), stat.getStandardDeviation());
					exposure.put(type.getId(), model.getExposurePerType(type.getId()) / (double) NUM_VEHICLES);
					occurrences.put(type.getId(), stat.getN());
					percentileMin.put(type.getId(), getPercentile(durations, type.getMinDuration()));
					percentileMax.put(type.getId(), getPercentile(durations, type.getMaxDuration()));
				} else {
					minDuration.put(type.getId(), minDuration.get(type.getId()) + stat.getMin());
					maxDuration.put(type.getId(), maxDuration.get(type.getId()) + stat.getMax());
					totalDuration.put(type.getId(), totalDuration.get(type.getId()) + stat.getSum());
					meanDuration.put(type.getId(), meanDuration.get(type.getId()) + stat.getMean());
					stdDuration.put(type.getId(), stdDuration.get(type.getId()) + stat.getStandardDeviation());
					exposure.put(type.getId(), exposure.get(type.getId()) + model.getExposurePerType(type.getId()) / (double) NUM_VEHICLES);
					occurrences.put(type.getId(), occurrences.get(type.getId()) + stat.getN());
					percentileMin.put(type.getId(), percentileMin.get(type.getId()) + getPercentile(durations, type.getMinDuration()));
					percentileMax.put(type.getId(), percentileMax.get(type.getId()) + getPercentile(durations, type.getMaxDuration()));
				}
			}
		}

		StringBuilder sb = new StringBuilder();
		sb.append(
				"Distraction Type;Exposure [%];Occurrences;Total Duration [s];% of Simulation Time;Avg. Duration [s];Std. Duration [s];Min. Duration [s];Max. Duration [s]; Percentage below min.; Percentage above max.;Simulation Time (all vehicles) [s]; Num. Vehicles\n");

		for (DistractionType type : model.getDistractionTypes()) {
			double minDur = minDuration.get(type.getId()) / NUM_ITERATIONS;
			double maxDur = maxDuration.get(type.getId()) / NUM_ITERATIONS;
			double totalDur = totalDuration.get(type.getId()) / NUM_ITERATIONS;
			double exp = exposure.get(type.getId()) / NUM_ITERATIONS;
			double mean = meanDuration.get(type.getId()) / NUM_ITERATIONS;
			double std = stdDuration.get(type.getId()) / NUM_ITERATIONS;
			double occ = occurrences.get(type.getId()) / (double) NUM_ITERATIONS;
			double perc5 = percentileMin.get(type.getId()) / NUM_ITERATIONS;
			double perc95 = percentileMax.get(type.getId()) / NUM_ITERATIONS;
			sb.append(String.format("%s;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%d;%d\n", type.getDescription(), exp * 100.0, occ, totalDur,
					totalDur / (SIMULATION_TIME_S * NUM_VEHICLES) * 100, mean, std, minDur, maxDur, perc5, perc95, SIMULATION_TIME_S * NUM_VEHICLES,
					NUM_VEHICLES));
		}

		String filePath = "C:\\Users\\Lokal\\Desktop\\distraction_test.csv";
		PrintWriter writer;

		try {
			writer = new PrintWriter(filePath, "UTF-8");
			writer.print(sb.toString());
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		System.out.println("Finished");
	}

	/**
	 * https://de.mathworks.com/matlabcentral/answers/99683-how-do-i-calculate-the-percent-rank-of-each-value-in-an-array-using-matlab
	 */
	private static double getPercentile(double[] durations, double value) {

		int numSmallerValues = 0;

		for (int i = 0; i < durations.length; i++) {
			if (durations[i] > value) {
				break;
			}

			numSmallerValues++;
		}

		return (numSmallerValues + 0.5) / durations.length * 100;
	}

	private static List<DistractionType> getDistractionTypes() {
		List<DistractionType> types = new ArrayList<>();

		DistractionType type = new DistractionType(0, "Talking on cell phone", IS_STOCHASTIC);
		type.setExposure(0.329);
		type.setFrequency(100 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(1.2);
		type.setMaxDuration(1264.2);
		type.setMeanDuration(92.65);
		type.setStdDuration(176.29);
		types.add(type);

		type = new DistractionType(1, "Answering cell phone", IS_STOCHASTIC);
		type.setExposure(0.157);
		type.setFrequency(15 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(1.3);
		type.setMaxDuration(19.7);
		type.setMeanDuration(7.86);
		type.setStdDuration(4.24);
		types.add(type);

		type = new DistractionType(2, "Dialing cell phone", IS_STOCHASTIC);
		type.setExposure(0.357);
		type.setFrequency(122 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(1);
		type.setMaxDuration(65.7);
		type.setMeanDuration(12.85);
		type.setStdDuration(13.41);
		types.add(type);

		type = new DistractionType(3, "Drinking", IS_STOCHASTIC);
		type.setExposure(0.729);
		type.setFrequency(1028 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0.3);
		type.setMaxDuration(104.9);
		type.setMeanDuration(5.23);
		type.setStdDuration(7.4);
		types.add(type);

		type = new DistractionType(4, "Preparing to eat or to drink", IS_STOCHASTIC);
		type.setExposure(0.614);
		type.setFrequency(1503 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0);
		type.setMaxDuration(755.5);
		type.setMeanDuration(15.4);
		type.setStdDuration(34.7);
		types.add(type);

		type = new DistractionType(5, "Manipulating audio video", IS_STOCHASTIC);
		type.setExposure(0.943);
		type.setFrequency(1539 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0);
		type.setMaxDuration(80.3);
		type.setMeanDuration(5.46);
		type.setStdDuration(8.63);
		types.add(type);

		type = new DistractionType(6, "Smoking", IS_STOCHASTIC);
		type.setExposure(0.071);
		type.setFrequency(45 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(13.2);
		type.setMaxDuration(838.1);
		type.setMeanDuration(245.81);
		type.setStdDuration(162.95);
		types.add(type);

		type = new DistractionType(7, "Reading or writing", IS_STOCHASTIC);
		type.setExposure(0.643);
		type.setFrequency(303 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0);
		type.setMaxDuration(282.4);
		type.setMeanDuration(18.43);
		type.setStdDuration(29.7);
		types.add(type);

		type = new DistractionType(8, "Grooming", IS_STOCHASTIC);
		type.setExposure(0.571);
		type.setFrequency(229 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(1);
		type.setMaxDuration(340);
		type.setMeanDuration(11.82);
		type.setStdDuration(29.77);
		types.add(type);

		type = new DistractionType(9, "Baby distracting", IS_STOCHASTIC);
		type.setExposure(0.086);
		type.setFrequency(114 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0.8);
		type.setMaxDuration(192.6);
		type.setMeanDuration(23.49);
		type.setStdDuration(28.39);
		types.add(type);

		type = new DistractionType(10, "Child distracting", IS_STOCHASTIC);
		type.setExposure(0.143);
		type.setFrequency(81 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0.7);
		type.setMaxDuration(1124.2);
		type.setMeanDuration(25.76);
		type.setStdDuration(124.72);
		types.add(type);

		type = new DistractionType(11, "Adult distracting", IS_STOCHASTIC);
		type.setExposure(0.257);
		type.setFrequency(48 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(1.1);
		type.setMaxDuration(608.8);
		type.setMeanDuration(46.32);
		type.setStdDuration(108.49);
		types.add(type);

		type = new DistractionType(12, "Conversing", IS_STOCHASTIC);
		type.setExposure(0.80);
		type.setFrequency(1558 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0);
		type.setMaxDuration(4827);
		type.setMeanDuration(74.04);
		type.setStdDuration(234.5);
		types.add(type);

		type = new DistractionType(13, "Reaching", IS_STOCHASTIC);
		type.setExposure(1.0);
		type.setFrequency(2246 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0);
		type.setMaxDuration(1351);
		type.setMeanDuration(7.58);
		type.setStdDuration(36.7);
		types.add(type);

		type = new DistractionType(14, "Manipulating vehicle controls", IS_STOCHASTIC);
		type.setExposure(1.0);
		type.setFrequency(2095 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0);
		type.setMaxDuration(283.8);
		type.setMeanDuration(4.82);
		type.setStdDuration(11.53);
		types.add(type);

		type = new DistractionType(15, "All other internal distraction", IS_STOCHASTIC);
		type.setExposure(0.814);
		type.setFrequency(481 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0);
		type.setMaxDuration(496.3);
		type.setMeanDuration(21.55);
		type.setStdDuration(46.38);
		types.add(type);

		type = new DistractionType(16, "External distraction", IS_STOCHASTIC);
		type.setExposure(0.90);
		type.setFrequency(659 / (double) NUM_HOURS * NUM_VEHICLES / GROUND_TRUTH_VEHICLES);
		type.setMinDuration(0.4);
		type.setMaxDuration(770.5);
		type.setMeanDuration(26.55);
		type.setStdDuration(58.78);
		types.add(type);

		return types;
	}

	private static Vehicle createVehicle() {
		Vehicle v = new Vehicle(0);
		v.setLongitudinalControl(new ExtendedHumanDriverControl());
		return v;
	}
}

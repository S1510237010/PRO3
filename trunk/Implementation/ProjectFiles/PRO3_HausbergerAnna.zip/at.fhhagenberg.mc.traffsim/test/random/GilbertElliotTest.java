package random;

import org.apache.commons.math3.distribution.GeometricDistribution;

import at.fhhagenberg.mc.traffsim.communication.IChannelModel;
import at.fhhagenberg.mc.traffsim.communication.channelmodels.GilbertElliotChannelModel;

public class GilbertElliotTest {
	public static void main(String[] args) {
		IChannelModel model = new GilbertElliotChannelModel(0.7f, 0.8f, 10l, 0);
		for (int i = 0; i < 10000; i++) {
			System.out.print(model.getNextDelay() + ",");
		}
		GeometricDistribution dist = new GeometricDistribution(0.01);
		for (int i = 0; i < 10000; i++) {
			System.out.print(dist.sample() + ",");
		}

	}

	public static int getPoisson(double lambda) {
		double L = Math.exp(-lambda);
		double p = 1.0;
		int k = 0;

		do {
			k++;
			p *= Math.random();
		} while (p > L);

		return k - 1;
	}
}

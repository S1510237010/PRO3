package random;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Random;

import org.junit.Test;

public class RandomTest {

	@Test
	public void testReproducibleNumberGeneration() {
		Random random1 = new Random();
		Random random2 = new Random();

		for (int i = 0; i < 10; i++) {
			double d1 = random1.nextDouble();
			double d2 = random2.nextDouble();
			System.out.println(String.format("%f - %f", d1, d2));
			assertNotEquals(d1, d2);
		}
		
		Random random3 = new Random(0l);
		Random random4 = new Random(0l);
		
		for (int i = 0; i < 10; i++) {
			double d1 = random3.nextDouble();
			double d2 = random4.nextDouble();
			System.out.println(String.format("%f - %f", d1, d2));
			assertEquals(d1, d2, 0.00001);
		}
	}
}

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketTest {
	public static void main(String[] argv) {
		try {
			ServerSocket sock = new ServerSocket(1234);
			new Thread(new Runnable() {

				@Override
				public void run() {
					try {
						System.out.println("server accepting accept");
						Socket clientSocket = sock.accept();
						while (true) {
							clientSocket.getOutputStream().write(17);
							int i = clientSocket.getInputStream().read();
							System.out.println("server write 17, read " + i);
							Thread.sleep(100);
						}
					} catch (IOException | InterruptedException e) {
						e.printStackTrace();
					}
				}
			}).start();
			Socket client = new Socket("localhost", 1234);
			byte[] bytes = new byte[1000];
			for (int i = 0; i < 1000; i++) {
				bytes[i] = (byte) (i % 256);
			}
			int j = 0;
			while (true) {
				System.out.println("client write " + j);
				client.getOutputStream().write(bytes);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

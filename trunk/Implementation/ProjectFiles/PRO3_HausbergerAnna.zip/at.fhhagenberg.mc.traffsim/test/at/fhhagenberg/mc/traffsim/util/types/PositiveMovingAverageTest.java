package at.fhhagenberg.mc.traffsim.util.types;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PositiveMovingAverageTest {

	private static final int LENGTH = 10;
	PositiveMovingAverage average;

	@Before
	public void setUp() throws Exception {
		average = new PositiveMovingAverage(LENGTH);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddValue() {
		int sum = 0;
		for (int i = 0; i < LENGTH; i++) {
			average.addValue(i);
			sum += i;
		}
		assertEquals((double) sum / LENGTH, average.currentAverage(), 0.001);
	}

	@Test
	public void testPartFill() {
		int len = 5;
		int sum = 0;
		for (int i = 0; i < len; i++) {
			average.addValue(i);
			sum += i;
		}
		assertEquals((double) sum / len, average.currentAverage(), 0.001);
	}

	@Test
	public void testOverload() {
		int len = 15;
		for (int i = 0; i < len; i++) {
			average.addValue(i);
		}
		assertEquals(9.5, average.currentAverage(), 0.001);
	}

	@Test
	public void testMultithreadedAdd() throws InterruptedException {
		Thread a = new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 0; i < 5; i++) {
					average.addValue(i);
				}
			}
		});
		Thread b = new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 0; i < 5; i++) {
					average.addValue(i);
				}
			}
		});
		a.start();
		b.start();
		while (a.isAlive() && b.isAlive()) {
			Thread.sleep(20);
		}
		assertEquals(2, average.currentAverage(), 0.001);

		a = new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 10; i < 15; i++) {
					average.addValue(i);
				}
			}
		});
		b = new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 10; i < 15; i++) {
					average.addValue(i);
				}
			}
		});
		a.start();
		b.start();
		while (a.isAlive() && b.isAlive()) {
			Thread.sleep(20);
		}
		assertEquals(12, average.currentAverage(), 0.001);
	}

}

package at.fhhagenberg.mc.traffsim.util;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import at.fhhagenberg.mc.traffsim.model.geo.Line;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;

public class SpatialUtilTest {

	@Before
	public void init() {
	}

	@Test
	public void testRemovePointsFromLine() {
		Line l = new Line(new Vector(1, 0), new Vector(1, 4));
		ArrayList<Vector> toRemove = new ArrayList<>();
		toRemove.add(new Vector(1,0));
		toRemove.add(new Vector(1,2));
		Line newLine = SpatialUtil.removePoints(l, toRemove);
		System.out.println(newLine);
	}

}

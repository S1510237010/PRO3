package ksproute;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.eclipse.core.runtime.NullProgressMonitor;

import at.fhhagenberg.mc.traffsim.data.DataLoader;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.Node;
import at.fhhagenberg.mc.traffsim.routing.KSPRouteService;
import at.fhhagenberg.mc.traffsim.routing.routegenerator.RouteResult;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class DefaultRouteCreator {
	public List<RouteResult> getRoutes() {
		// ///////////////////////
		File graph = new File("../at.fhhagenberg.mc.traffsim.data/data/valentin/map.gph");
		DataLoader loader = new DataLoader();
		PreferenceUtil.setMockPrefStore(new MockPreferenceStore());
		SimulationModel model = new SimulationModel("1");
		loader.setDonotInitialize(true);
		Properties loadingOptions = new Properties();
		loadingOptions.put(PropertyKeys.RESET_GEOMETRY, true);
		try {
			loader.loadBeans(new File("../at.fhhagenberg.mc.traffsim.data/data/valentin/configuration.xml"), new NullProgressMonitor());
			loader.loadConfiguration(model, new NullProgressMonitor(), loadingOptions);
		} catch (LoadingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		KSPRouteService router = new KSPRouteService(graph, loader.getOldRoutingIds(), 10, loader.getRoadNetwork(), null);
		// RouteService router = new RouteService(new File("../at.fhhagenberg.mc.traffsim.data/data/reroute2/map.gph"), new
		// HashSet<Long>());
		List<RouteResult> result = new ArrayList<>();
		int kirchdorf = router.getId(48.169005, 14.529823); // kirchdorf
		int altenhofen = router.getId(48.181983, 14.547891); // altenhofen
		int amstetten = router.getId(48.087024, 14.802307);
		int amstetten2 = router.getId(48.115324, 14.887999);
		int asten = router.getId(48.227417, 14.399933);
		int gollensdrfStr = router.getId(48.17734, 14.510449);
		int kaplanStr = router.getId(48.157712, 14.51358);

		long start = System.currentTimeMillis();
		List<RouteResult> paths = router.findKsp(new Node(amstetten2), new Node(gollensdrfStr), 10);
		System.out.println("multi: " + (System.currentTimeMillis() - start));
		for (int i = 0; i < paths.size(); i++) {
			System.out.println("#" + i + ": " + paths.get(i).getTotalCost());
		}
		result.addAll(paths);
		start = System.currentTimeMillis();

		// RouteResult route1 = router.findRoute(new Node(gollensdrfStr), new Node(kaplanStr));
		// result.add(route1);
		//
		// RouteResult route2 = router.findRoute(new Node(amstetten), new Node(asten));
		// result.add(route2);
		// router.graph.hOverrider.overrideCost(JAM_ID, Float.MAX_VALUE, false);
		// router.graph.hOverrider.overrideCost(JAM_ID, Float.MAX_VALUE, true);
		// Vector<RoutingResultSegment> route3 = router.getRoute(amstetten, asten);
		// result.add(route3);
		return result;
	}
}

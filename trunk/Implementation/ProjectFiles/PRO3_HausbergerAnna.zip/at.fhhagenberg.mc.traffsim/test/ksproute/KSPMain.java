package ksproute;

public class KSPMain {
	public static void main(String[] argv) {
		try {
			System.out.println("enter key");
//			System.in.read();
		} catch (Exception e) {
			e.printStackTrace();
		}
		MapView view = new MapView(0);
		view.setRoutes(new DefaultRouteCreator().getRoutes());
	}
}

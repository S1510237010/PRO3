//package ksproute;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.apache.commons.lang3.ArrayUtils;
//
//import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
//import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
//import at.fhhagenberg.mc.traffsim.routing.osm2po.RoutingSegment;
//
//public class RouteResult implements Comparable<RouteResult> {
//	private List<RoadSegment> segments;
//	private List<Long> nodeIds;
//	private float[] cost;
//	private Map<Long, RoadSegment> startNodeMapping = new HashMap<>();
//	private double totalCost;
//	private RoadNetwork network;
//
//	public RouteResult(List<RoadSegment> segments, float[] cost) {
//		this.segments = segments;
//		this.cost = cost;
//		updateData();
//	}
//
//	public RouteResult(RouteResult route, RoadNetwork network) {
//		for (int i = 0; i < route.getRouteIds().length; i++) {
//			segments.add(network.getRoadSegmentByRoutingId(route.getRouteIds()[i], route.getIsReverse()[i]));
//		}
//		this.cost = route.cost;
//		updateData();
//	}
//
//	private void updateData() {
//		nodeIds = new ArrayList<>();
//		if (segments == null || segments.size() == 0) {
//			return;
//		}
//		nodeIds.add(segments.get(0).getStartNode().getId());
//		for (RoadSegment seg : segments) {
//			nodeIds.add(seg.getEndNode().getId());
//			startNodeMapping.put(seg.getStartNode().getId(), seg);
//		}
//		for (Float c : cost) {
//			totalCost += c;
//		}
//	}
//
//	public List<Long> getNodeIds() {
//		return nodeIds;
//	}
//
//	public List<RoadSegment> getSegments() {
//		return segments;
//	}
//
//	public RoadSegment getRoutingSegment(long startNode) {
//		return startNodeMapping.get(startNode);
//	}
//
//	public RouteResult subRoute(int startIndex, int endIndex) {
//		RouteResult newRoute = new RouteResult(new ArrayList<>(segments.subList(startIndex, endIndex)), Arrays.copyOfRange(cost, startIndex, endIndex));
//		newRoute.updateData();
//		return newRoute;
//	}
//
//	public RouteResult copyAndAppend(RouteResult toAppend) {
//		ArrayList<RoadSegment> newSegments = new ArrayList<>(segments);
//		if (toAppend != null) {
//			newSegments.addAll(toAppend.getSegments());
//		}
//		return new RouteResult(newSegments, ArrayUtils.addAll(cost, toAppend.cost));
//	}
//
//	public double getTotalCost() {
//		return totalCost;
//	}
//
//	@Override
//	public int compareTo(RouteResult o) {
//		return new Double(totalCost).compareTo(o.getTotalCost());
//	}
//
//	@Override
//	public String toString() {
//		return nodeIds.toString();
//	}
//}

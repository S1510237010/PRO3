package ksproute;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.event.MouseInputListener;

import org.jdesktop.swingx.JXMapViewer;
import org.jdesktop.swingx.OSMTileFactoryInfo;
import org.jdesktop.swingx.VirtualEarthTileFactoryInfo;
import org.jdesktop.swingx.input.CenterMapListener;
import org.jdesktop.swingx.input.PanKeyListener;
import org.jdesktop.swingx.input.PanMouseInputListener;
import org.jdesktop.swingx.input.ZoomMouseWheelListenerCenter;
import org.jdesktop.swingx.mapviewer.DefaultTileFactory;
import org.jdesktop.swingx.mapviewer.GeoPosition;
import org.jdesktop.swingx.mapviewer.LocalResponseCache;
import org.jdesktop.swingx.mapviewer.TileFactoryInfo;
import org.jdesktop.swingx.painter.Painter;

import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.routing.routegenerator.RouteResult;
import at.fhhagenberg.mc.traffsim.ui.osm.TileType;
import at.fhhagenberg.mc.traffsim.ui.osm.TraffSimTileFactoryProvider;
import at.fhhagenberg.mc.traffsim.util.CoordinateUtil;

public class MapView extends JFrame {
	private static final long serialVersionUID = -4534848224929042328L;
	private int JAM_ID;// = 288304;
	private JXMapViewer jxMap;
	private List<RouteResult> routeResults = new ArrayList<>();

	public MapView(int jamId) {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JAM_ID = jamId;
		createContents(this.getContentPane());
		this.setSize(700, 500);
		// Display the window.
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	private void createContents(Container parent) {
		jxMap = new JXMapViewer();
		TileFactoryInfo info = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.HYBRID);// new OSMTileFactoryInfo();
		info = new OSMTileFactoryInfo();

		DefaultTileFactory tileFactory = TraffSimTileFactoryProvider.getTileFactory(TileType.OSMDE);
		tileFactory.setThreadPoolSize(8);

		File cacheDir = new File(System.getProperty("user.home") + File.separator + ".jxmapviewer2");
		LocalResponseCache.installResponseCache(info.getBaseURL(), cacheDir, false);

		jxMap.setTileFactory(tileFactory);
		// Use 8 threads in parallel to load the tiles
		tileFactory.setThreadPoolSize(8);

		MouseInputListener mia = new PanMouseInputListener(jxMap);
		jxMap.addMouseListener(mia);
		jxMap.addMouseMotionListener(mia);
		jxMap.addMouseListener(new CenterMapListener(jxMap));
		jxMap.addMouseWheelListener(new ZoomMouseWheelListenerCenter(jxMap));
		jxMap.addKeyListener(new PanKeyListener(jxMap));
		// Set the focus
		GeoPosition pos = new GeoPosition(48.179005, 14.539823);

		jxMap.setAddressLocation(pos);
		jxMap.setZoom(5);
		initPainter();
		parent.add(jxMap);

	}

	public void setRoutes(List<RouteResult> routeResults) {
		this.routeResults = routeResults;
		repaint();
	}

	public void initPainter() {
		Painter<JXMapViewer> painter = new Painter<JXMapViewer>() {

			@Override
			public void paint(Graphics2D g, JXMapViewer arg1, int arg2, int arg3) {
				g = (Graphics2D) g.create();

				g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
				// convert from viewport to world bitmap
				Rectangle rect = jxMap.getViewportBounds();
				g.translate(-rect.x, -rect.y);
				g.setStroke(new BasicStroke(3.0f));

				g.setColor(Color.BLACK);
				// drawOCMRoute(g);

				List<Color> colors = new ArrayList<>();
				colors.add(new Color(0xBF1906));
				colors.add(Color.BLUE);
				colors.add(Color.CYAN);
				colors.add(Color.MAGENTA);
				colors.add(Color.YELLOW);
				colors.add(Color.DARK_GRAY);
				colors.add(Color.BLACK);
				for (RouteResult a : routeResults) {
					g.setColor(colors.get(routeResults.indexOf(a) % colors.size()));
					drawRoute(g, a);
				}

				// g.setColor(Color.MAGENTA);
				// drawRoute(g, routeResults.get(1));

				g.setColor(new Color(0xFFFFFF));
				// drawRouteSegments(g, mOCMIntersectCallRoute);

				g.dispose();
			}

			/**
			 * Draws a route
			 * 
			 * @param g
			 *            a graphics object
			 * @param _route
			 *            the route which shall be drawn
			 */
			private void drawRoute(Graphics2D g, RouteResult _route) {
				if (_route == null) {
					return;
				}
				Point2D origin = null;
				Point2D destination = null;
				for (RoadSegment r : _route.getSegments()) {

					List<Vector> ll = r.getRoadGeometry().getPoints();
					for (int i = 0; i < ll.size() - 1; i++) {
						Location cur = ll.get(i);
						Location next = ll.get(i + 1);
						origin = getPoint(cur.y, cur.x);
						destination = getPoint(next.y, next.x);
						Line2D line = new Line2D.Double(origin.getX(), origin.getY(), destination.getX(), destination.getY());
						g.draw(line);
						if (r.getId() == JAM_ID) {
							Color old = g.getColor();
							Stroke str = g.getStroke();
							g.setColor(Color.BLACK);
							g.setStroke(new BasicStroke(10));
							g.draw(new Line2D.Double(origin.getX(), origin.getY(), destination.getX(), destination.getY()));
							g.setColor(old);
							g.setStroke(str);
						}
					}
				}
			}
		};
		jxMap.setOverlayPainter(painter);
	}

	/**
	 * Gets the point in screen coordinates for a position
	 * 
	 * @param lat
	 *            latitude part
	 * @param lon
	 *            longitude part
	 * @return screen coordinates
	 */
	private Point2D getPoint(double lat, double lon) {
		Location wgs84 = CoordinateUtil.toWGS84Coordinate(new Location(lon, lat));
		return getPoint2D(wgs84.y, wgs84.x);

	}

	/**
	 * Gets the point in screen coordinates for a position
	 * 
	 * @param lat
	 *            latitude part
	 * @param lon
	 *            longitude part
	 * @return screen coordinates
	 */
	private Point2D getPoint2D(double lat, double lon) {
		GeoPosition gp = new GeoPosition(lat, lon);
		return jxMap.getTileFactory().geoToPixel(gp, jxMap.getZoom());

	}
}

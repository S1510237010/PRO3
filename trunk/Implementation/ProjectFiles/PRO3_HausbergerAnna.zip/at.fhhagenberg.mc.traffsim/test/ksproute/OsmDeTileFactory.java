package ksproute;


import org.jdesktop.swingx.mapviewer.DefaultTileFactory;
import org.jdesktop.swingx.mapviewer.TileFactoryInfo;

/**
 * This class makes it possible to display MapQuest-tiles in JXMapKit. Simply use jxMapKit.setTileFactory(new MapQuestTileFactory());
 *
 * Please visit http://developer.mapquest.com/web/products/open/map for more information about the license under which this tiles are released.
 * @author twalcari
 *
 */
public class OsmDeTileFactory extends DefaultTileFactory {

    private static final int MAX_ZOOM = 17;

    private static final TileFactoryInfo info = new TileFactoryInfo(1,
            MAX_ZOOM - 2, MAX_ZOOM, 256, true, true,
//            "http://oatile1.mqcdn.com/tiles/1.0.0/sat", //aerial tiles
            "http://tile.openstreetmap.de/tiles/osmde", //Mapquest OSM
            "x", "y", "z") {
        public String getTileUrl(int x, int y, int zoom) {
            zoom = MAX_ZOOM - zoom;
            String url = this.baseURL + "/" + zoom + "/" + x + "/" + y + ".png";
            return url;
        }
    };

    public OsmDeTileFactory() {
        super(info);
    }

}
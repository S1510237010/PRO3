package ksproute;
import org.eclipse.jface.preference.PreferenceStore;

import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;

public class MockPreferenceStore extends PreferenceStore {
	@Override
	public double getDouble(String name) {
		if (name.equals(IPreferenceConstants.NETWORK_SIMPLIFICATION_TOLERANCE)) {
			return 0.1;
		}
		if (name.equals(IPreferenceConstants.NETWORK_SMOOTHING)) {
			return 40;
		}
		return super.getDouble(name);
	}
}

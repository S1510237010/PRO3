package at.fhhagenberg.mc.traffsim.statistics.events;

public interface IEventLog {
	public void logEvent(Event event);

	public default void logEvent(EventType type, String message) {
		logEvent(type, "", message);
	}

	public void logEvent(EventType type, String typeInfo, String message);

	public void logCongestion(EventType type, String typeInfo, String message, long nodeId, long segId, double severity);
}

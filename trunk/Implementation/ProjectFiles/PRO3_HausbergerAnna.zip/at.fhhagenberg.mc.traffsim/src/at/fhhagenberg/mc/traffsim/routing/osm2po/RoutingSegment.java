package at.fhhagenberg.mc.traffsim.routing.osm2po;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Location;
import de.cm.osm2po.model.LatLon;
import de.cm.osm2po.routing.Graph;
import de.cm.osm2po.routing.RoutingResultSegment;

/**
 * This is a wrapper for the {@link RoutingResultSegment} class from osm2po library.
 * 
 * @author Christian Backfrieder
 * 
 */
public class RoutingSegment {

	private int edgeId;
	private int segmentId;
	private int sourceId;
	private int targetId;
	private float h;
	private float km;
	private byte noTurnBits;
	private List<Location> coords = new ArrayList<>();
	private String name;
	private boolean reverse;

	public RoutingSegment(RoutingResultSegment rrs) {
		this.sourceId = rrs.getSourceId();
		this.targetId = rrs.getTargetId();
		this.h = rrs.getH();
		this.km = rrs.getKm();
		this.name = rrs.getName().toString();

		for (long l : rrs.getCoords().getCoords()) {
			LatLon ll = new LatLon();
			ll.setCoord(l);
			coords.add(new Location(ll.getLon(), ll.getLat()));
		}
		this.segmentId = rrs.getId();
		this.edgeId = Graph.toEdgeId(rrs.getId(), rrs.isReverse());
		this.reverse = rrs.isReverse();
	}

	public int getEdgeId() {
		return edgeId;
	}

	public int getSegmentId() {
		return segmentId;
	}

	public int getSourceId() {
		return sourceId;
	}

	public int getTargetId() {
		return targetId;
	}

	public float getH() {
		return h;
	}

	public float getKm() {
		return km;
	}

	public byte getNoTurnBits() {
		return noTurnBits;
	}

	public List<Location> getCoords() {
		return coords;
	}

	public String getName() {
		return name;
	}

	public boolean isReverse() {
		return reverse;
	}
}

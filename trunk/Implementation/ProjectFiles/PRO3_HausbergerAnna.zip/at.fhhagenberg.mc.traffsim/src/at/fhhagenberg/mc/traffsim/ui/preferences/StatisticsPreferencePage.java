package at.fhhagenberg.mc.traffsim.ui.preferences;

import java.io.File;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class StatisticsPreferencePage extends PreferencePage implements IWorkbenchPreferencePage {

	private Spinner spinnerStatisticsCacheSize;
	private Group grpMatlab;
	private Label lblMatlabExecutablePath;
	private Text textExecutablePath;
	private Button btnBrowse;
	private Label lblMergeStatistics;
	private Button btnAfterEachSimulation;
	private Button btnAfterBatchFinish;
	private Button btnDoNotMerge;
	private Button btnDeleteMergedFiles;
	private Group grpOutput;
	private Button btnUseGlobalOutput;
	private Label lblOutputRootFolder;
	private Text textOutputRoot;
	private Button btnBrowse_1;
	private Button btnDeleteCanceledSimulation;
	private Group groupScreenCapture;
	private Button btnEnableCapture;
	private Spinner spinnerScreenCapture;
	private Label lblSpeedupFactor;
	private Button btnNumberParameterSet;
	private Label lblbatchmodeOnly;
	private Button btnCompressConfiguration;
	private Button btnClearOutputFolder;
	private Button btnCopyOriginalConfiguration;

	public StatisticsPreferencePage() {
		setTitle("Statistics Preferences");
		setDescription("Set up recording mode, import and export of statistic gathering");
	}

	@Override
	public void init(IWorkbench workbench) {
		setPreferenceStore(TraffSimCorePlugin.getDefault().getPreferenceStore());
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(2, false));
		btnDeleteCanceledSimulation = new Button(container, SWT.CHECK);
		btnDeleteCanceledSimulation.setToolTipText(
				"Delete all statistics and output cache files if simulation was not finished successfully (e.g. canceled by user, view closed)");
		btnDeleteCanceledSimulation.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnDeleteCanceledSimulation.setText("Delete canceled simulation results");

		String cacheSizeToolTip = "Number of statistics elements to keep in memory (e.g. eventlog entries, vehicle statistics timesteps)\nWarning: A very high number leads to high memory consumption!";
		Label lblEventlogCacheSize = new Label(container, SWT.NONE);
		lblEventlogCacheSize.setText("Statistics cache size");
		lblEventlogCacheSize.setToolTipText(cacheSizeToolTip);

		spinnerStatisticsCacheSize = new Spinner(container, SWT.BORDER);
		spinnerStatisticsCacheSize.setPageIncrement(1000);
		spinnerStatisticsCacheSize.setIncrement(100);
		spinnerStatisticsCacheSize.setMaximum(10000000);
		spinnerStatisticsCacheSize.setSelection(500);
		spinnerStatisticsCacheSize.setToolTipText(cacheSizeToolTip);

		grpOutput = new Group(container, SWT.NONE);
		grpOutput.setLayout(new GridLayout(3, false));
		grpOutput.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 2, 1));
		grpOutput.setText("Output");

		btnUseGlobalOutput = new Button(grpOutput, SWT.CHECK);
		btnUseGlobalOutput.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setGlobalOutputFolderEnabled(btnUseGlobalOutput.getSelection());
			}
		});
		btnUseGlobalOutput.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnUseGlobalOutput.setText("Use global output folder");

		lblOutputRootFolder = new Label(grpOutput, SWT.NONE);
		lblOutputRootFolder.setEnabled(false);
		lblOutputRootFolder.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblOutputRootFolder.setText("Output root folder");

		textOutputRoot = new Text(grpOutput, SWT.BORDER);
		textOutputRoot.setEnabled(false);
		textOutputRoot.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btnBrowse_1 = new Button(grpOutput, SWT.NONE);
		btnBrowse_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DirectoryDialog dialog = new DirectoryDialog(btnBrowse_1.getShell());
				dialog.setText("Global output root folder");
				String selected = dialog.open();
				textOutputRoot.setText(selected);
			}
		});
		btnBrowse_1.setEnabled(false);
		btnBrowse_1.setText("Browse");

		btnNumberParameterSet = new Button(grpOutput, SWT.CHECK);
		btnNumberParameterSet.setToolTipText(
				"Append a suffix with a continuous parameter set number (e.g. _no1) from the current configuration to the output folder");
		btnNumberParameterSet.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnNumberParameterSet.setText("Number parameter set outputs in batch mode");

		btnCopyOriginalConfiguration = new Button(grpOutput, SWT.CHECK);
		btnCopyOriginalConfiguration.setToolTipText("Copy the used simulation configuration in a config directory within the output folder");
		btnCopyOriginalConfiguration.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				btnCompressConfiguration.setEnabled(btnCopyOriginalConfiguration.getSelection());
			}
		});
		btnCopyOriginalConfiguration.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnCopyOriginalConfiguration.setText("Copy original configuration to output");

		btnCompressConfiguration = new Button(grpOutput, SWT.CHECK);
		btnCompressConfiguration.setToolTipText("Create ZIP of the used configuration in the output folder instead of a bare copy");
		btnCompressConfiguration.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnCompressConfiguration.setText("Compress original configuration in output");

		btnClearOutputFolder = new Button(grpOutput, SWT.CHECK);
		btnClearOutputFolder.setToolTipText(
				"Clear the complete simulation output of this simulation after the simulation has finished.\r\nATTENTION: This does not leave anything related to the executed simulation over on disk!");
		btnClearOutputFolder.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnClearOutputFolder.setText("Delete generated simulation output");

		groupScreenCapture = new Group(container, SWT.NONE);
		groupScreenCapture.setText("Screen Capture");
		groupScreenCapture.setLayout(new GridLayout(3, false));
		groupScreenCapture.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));

		btnEnableCapture = new Button(groupScreenCapture, SWT.CHECK);
		btnEnableCapture.setText("Enable capture");

		lblSpeedupFactor = new Label(groupScreenCapture, SWT.NONE);
		lblSpeedupFactor.setText("Speedup factor");

		spinnerScreenCapture = new Spinner(groupScreenCapture, SWT.BORDER);
		spinnerScreenCapture.setSelection(1);

		grpMatlab = new Group(container, SWT.NONE);
		grpMatlab.setLayout(new GridLayout(3, false));
		grpMatlab.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpMatlab.setText("Matlab");

		lblMergeStatistics = new Label(grpMatlab, SWT.NONE);
		lblMergeStatistics.setText("Merge statistics");

		btnAfterEachSimulation = new Button(grpMatlab, SWT.RADIO);
		btnAfterEachSimulation.setText("After each simulation");
		new Label(grpMatlab, SWT.NONE);

		lblbatchmodeOnly = new Label(grpMatlab, SWT.NONE);
		lblbatchmodeOnly.setText("(batch-mode only)");

		btnAfterBatchFinish = new Button(grpMatlab, SWT.RADIO);
		btnAfterBatchFinish.setSelection(true);
		btnAfterBatchFinish.setText("After batch finish");
		new Label(grpMatlab, SWT.NONE);
		new Label(grpMatlab, SWT.NONE);

		btnDoNotMerge = new Button(grpMatlab, SWT.RADIO);
		btnDoNotMerge.setText("Do not merge");
		new Label(grpMatlab, SWT.NONE);

		lblMatlabExecutablePath = new Label(grpMatlab, SWT.NONE);
		lblMatlabExecutablePath.setText("Matlab exe path");

		textExecutablePath = new Text(grpMatlab, SWT.BORDER);
		textExecutablePath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btnBrowse = new Button(grpMatlab, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(Display.getCurrent().getActiveShell());
				dialog.setText("Matlab Path");
				dialog.setFilterExtensions(new String[] { "matlab.exe" });
				dialog.setFilterNames(new String[] { "MATLAB Executable" });
				File filterPath = new File("C:\\Program Files\\MATLAB");
				if (!filterPath.exists()) {
					filterPath = new File("C:\\Program Files (x86)\\MATLAB");

				}
				if (filterPath.exists()) {
					dialog.setFilterPath(filterPath.getAbsolutePath());
				}
				String selected = dialog.open();
				textExecutablePath.setText(selected);
			}
		});
		btnBrowse.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnBrowse.setSize(50, 25);
		btnBrowse.setText("Browse");

		btnDeleteMergedFiles = new Button(grpMatlab, SWT.CHECK);
		btnDeleteMergedFiles.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnDeleteMergedFiles.setText("Delete merged files");
		new Label(grpMatlab, SWT.NONE);
		initializePreferences();
		return container;
	}

	protected void setGlobalOutputFolderEnabled(boolean enabled) {
		btnBrowse_1.setEnabled(enabled);
		textOutputRoot.setEnabled(enabled);
		lblOutputRootFolder.setEnabled(enabled);
	}

	private void initializePreferences() {
		spinnerStatisticsCacheSize.setSelection(PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_CACHE_SIZE));
		textExecutablePath.setText(PreferenceUtil.getString(IPreferenceConstants.MATLAB_PATH));
		btnAfterBatchFinish.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_BATCH));
		btnAfterEachSimulation.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_EACH_SIMULATION));
		btnDeleteMergedFiles.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.MATLAB_DELETE_FILES_AFTER_MERGE));
		String globaloutput = PreferenceUtil.getString(IPreferenceConstants.GLOBAL_OUTPUT_FOLDER);
		btnUseGlobalOutput.setSelection(StringUtil.isNotNullOrEmpty(globaloutput));
		setGlobalOutputFolderEnabled(StringUtil.isNotNullOrEmpty(globaloutput));
		textOutputRoot.setText(globaloutput);
		btnDeleteCanceledSimulation.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.DELETE_CANCELED_SIMULATION_RESULTS));
		btnEnableCapture.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.ENABLE_SCREEN_CAPTURE));
		spinnerScreenCapture.setSelection(PreferenceUtil.getInt(IPreferenceConstants.SCREEN_CAPTURE_SPEEDUP));
		btnNumberParameterSet.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.NUMBER_PARAMETER_SET_OUTPUTS));
		btnCompressConfiguration.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.COMPRESS_CONFIG_IN_OUTPUT));
		btnClearOutputFolder.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.CLEAR_OUTPUT_FOLDER_AFTER_SIMULATION_FINISH));
		btnCopyOriginalConfiguration.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.COPY_CONFIG_TO_OUTPUT));
		btnCompressConfiguration.setEnabled(btnCopyOriginalConfiguration.getSelection());
	}

	@Override
	protected void performApply() {
		PreferenceUtil.setInt(IPreferenceConstants.STATISTICS_CACHE_SIZE, spinnerStatisticsCacheSize.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_BATCH, btnAfterBatchFinish.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_EACH_SIMULATION, btnAfterEachSimulation.getSelection());
		PreferenceUtil.set(IPreferenceConstants.MATLAB_PATH, textExecutablePath.getText());
		PreferenceUtil.setBoolean(IPreferenceConstants.MATLAB_DELETE_FILES_AFTER_MERGE, btnDeleteMergedFiles.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.DELETE_CANCELED_SIMULATION_RESULTS, btnDeleteCanceledSimulation.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.ENABLE_SCREEN_CAPTURE, btnEnableCapture.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.SCREEN_CAPTURE_SPEEDUP, spinnerScreenCapture.getSelection());
		if (btnUseGlobalOutput.getSelection()) {
			PreferenceUtil.set(IPreferenceConstants.GLOBAL_OUTPUT_FOLDER, textOutputRoot.getText());
		} else {
			PreferenceUtil.set(IPreferenceConstants.GLOBAL_OUTPUT_FOLDER, "");
		}
		PreferenceUtil.setBoolean(IPreferenceConstants.NUMBER_PARAMETER_SET_OUTPUTS, btnNumberParameterSet.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.COMPRESS_CONFIG_IN_OUTPUT, btnCompressConfiguration.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.CLEAR_OUTPUT_FOLDER_AFTER_SIMULATION_FINISH, btnClearOutputFolder.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.COPY_CONFIG_TO_OUTPUT, btnCopyOriginalConfiguration.getSelection());
	}

	@Override
	public boolean performOk() {
		performApply();
		return super.performOk();
	}
}

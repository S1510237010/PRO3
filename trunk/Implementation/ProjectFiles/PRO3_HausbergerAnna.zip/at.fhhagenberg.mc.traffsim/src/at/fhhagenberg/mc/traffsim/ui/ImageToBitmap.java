package at.fhhagenberg.mc.traffsim.ui;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;

import at.fhhagenberg.mc.traffsim.log.Logger;

/**
 * Provides functionality to store images in the file system
 * 
 * @author mc07003
 * 
 */
public class ImageToBitmap {
	/**
	 * Liefert eine Image-Vorlage in einer definierten Groesse
	 * 
	 * @param _width
	 *            Die Breite des Bildes
	 * @param _height
	 *            Die Hoehe des Bildes
	 * @return Das Bild in Form eines BufferedImages
	 * @see java.awt.image.BufferedImage
	 */
	public static BufferedImage getImage(int _width, int _height) {
		return new BufferedImage(_width, _height, BufferedImage.TYPE_INT_ARGB);
	}

	/**
	 * Liefert die durch das System unterstuetzten Bitmap-Konverter
	 * 
	 * @return String-Array mit allen zur Verfuegung stehenden Bitmap-Konvertern
	 * @see java.lang.String
	 */
	public static String[] getImageTypes() {
		return new String[] { "JPG", "PNG", "GIF" };
	}

	/**
	 * Speichert das uebergebene Bild in Form des angegebenen Bitmap-Formats in einen Ausgabestrom
	 * 
	 * @param _image
	 *            Das zu speichernde Bild
	 * @param _out
	 *            Der Ausgabestrom, in den das Bild im entsprechenden Format abzuspeichern ist
	 * @param _type
	 *            Der Bitmap-Typ [JPEG|BMP|PNG]
	 * @see java.awt.image.BufferedImage
	 * @see java.io.OutputStream
	 */
	public static void storeImage(BufferedImage _image, OutputStream _out, String _type) {
		try {
			ImageIO.write(_image, _type, _out);
			_out.flush();
			_out.close();
			Logger.logInfo("Stored image successfully!");
		} catch (IOException _e) {
			Logger.logError("Error when trying to write image.", _e);
		}
	}

}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.IDMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;

/**
 * Longitudinal calculation of acceleration values, where each vehicle has its own model and european traffic rules (right before left).
 * This is an implementation of the IDM of Treiber/Kesting.
 *
 * @author Christian B.
 *
 */
public class IDM extends LongitudinalModel implements IComposableLongitudinalModel {

	private double tMin;
	private double sMin;
	private double vTarget;
	private double comfortableAcc;
	private double maxAcc;
	private double safeDec;
	private double maxDec;
	private double delta;
	private IDMData modelData;

	public IDM() {

	}

	public IDM(IDMData data) {
		super(data.getIdentifier());
		fullname = data.getFullname();
		tMin = data.gettMin();
		sMin = data.getsMin();
		vTarget = data.getvTarget();
		comfortableAcc = data.getComfortableAcc();
		maxAcc = data.getMaxAcc();
		safeDec = data.getSafeDec();
		maxDec = data.getMaxDec();
		delta = data.getDelta();
		modelData = data;
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA, double speedLimit) {
		double accSpeedLimit = Double.POSITIVE_INFINITY;

		final double localT = alphaT * tMin;
		final double localTargetSpeed = Math.min(alphaV0 * vTarget, speedLimit);
		final double localA = alphaA * comfortableAcc;

		/** continue calculation according to Treiber / Kesting */
		double sstar = sMin + v * localT + v * dv / (2 * Math.sqrt(localA * -safeDec));
		if (sstar < sMin) {
			sstar = sMin;
		}
		final double s_frac = Math.pow(sstar / Math.max(s, 0.01), 2);

		double fracCurrentTargetSpeed = v / localTargetSpeed;
		if (localTargetSpeed == 0) {
			if (v == 0) {
				fracCurrentTargetSpeed = 1;
			} else {
				fracCurrentTargetSpeed = v / 1E-5;
			}
		}

		final double acc = localA * (1 - Math.pow(fracCurrentTargetSpeed, delta) - s_frac);
		return Math.min(acc, accSpeedLimit);
	}

	@Override
	public LongitudinalModel createCopyFor(double targetSpeed) {
		IDMData copy = new Kryo().copy(new IDMData(vTarget, sMin, tMin, comfortableAcc, safeDec, maxAcc, maxDec, delta));
		copy.setvTarget(targetSpeed);
		return new IDM(copy);
	}

	@Override
	public LongitudinalModelData getModelData() {
		return modelData;
	}

	@Override
	public boolean isSafeAcceleration(double acceleration) {
		return acceleration < maxAcc && acceleration > maxDec;
	}

	@Override
	public double calcAccComponent(double v, double speedLimit, double alphaT, double alphaV0, double alphaA) {
		final double localTargetSpeed = Math.min(alphaV0 * vTarget, speedLimit);
		final double localA = alphaA * comfortableAcc;

		double fracCurrentTargetSpeed = v / localTargetSpeed;

		if (localTargetSpeed == 0) {
			if (v == 0) {
				fracCurrentTargetSpeed = 1;
			} else {
				fracCurrentTargetSpeed = v / 1E-5;
			}
		}

		return localA * (1 - Math.pow(fracCurrentTargetSpeed, delta));
	}

	@Override
	public double calcBrakeComponent(double v, double speedLimit, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA,
			double renormalizationFactor) {
		final double localT = alphaT * sMin;
		final double localA = alphaA * comfortableAcc;

		double sNormalized = sMin / renormalizationFactor;
		double tNormalized = localT / renormalizationFactor;
		double sstar = sNormalized + v * tNormalized + v * dv / (2 * Math.sqrt(localA * -safeDec));

		if (sstar < sNormalized) {
			sstar = sNormalized;
		}

		double s_frac = Math.pow(sstar / s, 2);
		return -localA * s_frac;
	}
}

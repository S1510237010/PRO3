package at.fhhagenberg.mc.traffsim.communication;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import at.fhhagenberg.mc.traffsim.communication.messaging.InitialPayload;
import at.fhhagenberg.mc.traffsim.communication.messaging.PositionPayload;
import at.fhhagenberg.mc.traffsim.communication.messaging.RoutePayload;
import at.fhhagenberg.mc.traffsim.communication.messaging.VehicleDataPayload;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.vehicle.CommVehicle;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.types.IDisposable;

public class ObservationCenter implements ICommunicationPartner, IVehicleListener, IDisposable {

	Map<Long, Location> vehiclePositions = new ConcurrentHashMap<>();
	Map<Long, Double> vehicleFrontPositions = new ConcurrentHashMap<>();
	Map<Long, IRoute> vehicleRoutes = new ConcurrentHashMap<>();
	Map<Long, VehiclesLane> vehicleLaneSegments = new ConcurrentHashMap<>();
	Map<Long, RoadSegment> vehicleSourceSegments = new ConcurrentHashMap<>();
	Map<Long, RoadSegment> vehicleDestinationSegments = new ConcurrentHashMap<>();
	private Set<IVehicleInformationReceiver> vehicleInfoReceivers = new HashSet<>();
	private SimulationModel model;
	private Map<Long, Double> vehicleSpeeds = new ConcurrentHashMap<>();
	private Map<Long, Set<Long>> roadSegmentVehicleMapping = new ConcurrentHashMap<>();

	public ObservationCenter(SimulationModel model) {
		this.model = model;
	}

	@Override
	public void messageReceived(MessageTransfer msg) {
		if (msg.getReceiver().equals(this)) {
			if (msg.getMessage().getPayload() instanceof InitialPayload && msg.getSender() instanceof CommVehicle) {
				// initial appearance
				InitialPayload payload = ((InitialPayload) msg.getMessage().getPayload());
				Long vehId = ((CommVehicle) msg.getSender()).getUniqueId();
				vehicleLaneSegments.put(vehId, payload.getSource().getRightMostLane());
				LaneSegment lane = payload.getSource().getRightMostLane();
				updateRoadMappings(vehId, lane, lane.getRoadSegment().getId(), -1);
				vehicleSourceSegments.put(vehId, payload.getSource());
				vehicleDestinationSegments.put(vehId, payload.getDestination());
			} else if (msg.getMessage().getPayload() instanceof PositionPayload && msg.getSender() instanceof CommVehicle) {
				long vehId = ((CommVehicle) msg.getSender()).getUniqueId();
				VehiclesLane curLane = ((PositionPayload) msg.getMessage().getPayload()).getLane();
				vehiclePositions.put(vehId, ((PositionPayload) msg.getMessage().getPayload()).getPosition());

				if (!vehiclePositions.containsKey(vehId)) {
					((CommVehicle) msg.getSender()).addVehicleListener(this);
					notifyVehicleUpdate((CommVehicle) msg.getSender(), null, null, true, false, null, null);
				}
				if (msg.getMessage().getPayload() instanceof VehicleDataPayload) {
					vehicleSpeeds.put(vehId, ((VehicleDataPayload) msg.getMessage().getPayload()).getSpeed());
					vehicleFrontPositions.put(vehId, ((VehicleDataPayload) msg.getMessage().getPayload()).getSpeed());
				}
				if (!vehicleLaneSegments.containsKey(vehId) || !vehicleLaneSegments.get(vehId).equals(curLane)) {
					VehiclesLane oldLane = vehicleLaneSegments.get(vehId);
					RoadSegment curSeg = curLane != null ? curLane.getRoadSegment() : null;
					if (curSeg != null) {
						updateRoadMappings(vehId, curLane, curLane.getRoadSegment().getId(), oldLane != null ? oldLane.getRoadSegment().getId() : -1);
						// check if route is up to date and remove wrong ids, in case there are some
						IRoute curRt = vehicleRoutes.get(vehId);
						if (curRt != null && curSeg.getRoutingId() != curRt.getNextRoutingId()) {
							vehicleRoutes.put(vehId, RoutingUtil.trimUntilId(curRt, curSeg.getRoutingId()));
						}
						notifyVehicleUpdate((CommVehicle) msg.getSender(), null, null, false, false, oldLane, curLane);
					}
				}
			}
			if (msg.getMessage().getPayload() instanceof RoutePayload && msg.getSender() instanceof CommVehicle) {
				Long vehId = ((CommVehicle) msg.getSender()).getUniqueId();
				IRoute newRoute = ((RoutePayload) msg.getMessage().getPayload()).getRoute();
				IRoute oldRoute = vehicleRoutes.get(vehId);
				vehicleRoutes.put(vehId, newRoute);
				notifyVehicleUpdate((CommVehicle) msg.getSender(), oldRoute, newRoute, false, false, null, null);
			}
		}
	}

	private void updateRoadMappings(long vehId, VehiclesLane lane, long newRoadSegmentId, long oldRoadSegmentId) {
		vehicleLaneSegments.put(vehId, lane);
		if (roadSegmentVehicleMapping.containsKey(oldRoadSegmentId)) {
			roadSegmentVehicleMapping.get(oldRoadSegmentId).remove(vehId);
		}
		if (!roadSegmentVehicleMapping.containsKey(newRoadSegmentId)) {
			roadSegmentVehicleMapping.put(newRoadSegmentId, CollectionUtil.createConcurrentHashSet(vehId));
		} else {
			roadSegmentVehicleMapping.get(newRoadSegmentId).add(vehId);
		}
	}

	private void notifyVehicleUpdate(Vehicle veh, IRoute oldRt, IRoute newRt, boolean created, boolean left, VehiclesLane oldLane,
			VehiclesLane newLane) {
		for (IVehicleInformationReceiver recv : vehicleInfoReceivers) {
			if (newRt != null) {
				recv.routeUpdated(veh,
						vehicleLaneSegments.containsKey(veh.getUniqueId()) ? vehicleLaneSegments.get(veh.getUniqueId()).getRoadSegment() : null,
						oldRt, newRt);
			}
			if (created) {
				recv.vehicleGenerated(veh.getUniqueId());
			}
			if (newLane != null) {
				recv.vehicleChangedLaneSegment(veh, oldLane, newLane);
			}
			if (left) {
				recv.vehicleLeftSimulation(veh);
			}
		}
	}

	public void registerInformationReceiver(IVehicleInformationReceiver recv) {
		if (recv != null) {
			this.vehicleInfoReceivers.add(recv);
		}
	}

	public void unregisterInformationReceiver(IVehicleInformationReceiver recv) {
		vehicleInfoReceivers.remove(recv);
	}

	public IRoute getRoute(long uniqueId) {
		return vehicleRoutes.get(uniqueId);
	}

	public double getVehicleFrontPos(long uniqueId) {
		return vehicleFrontPositions.containsKey(uniqueId) ? vehicleFrontPositions.get(uniqueId) : 0;
	}

	public Location getPosition(long uniqueId) {
		return vehiclePositions.get(uniqueId);
	}

	@Override
	public void vehicleLeftSimulation(Vehicle v) {
		v.removeVehicleListener(this);
		vehiclePositions.remove(v.getUniqueId());
		vehicleRoutes.remove(v.getUniqueId());
		notifyVehicleUpdate(v, null, null, false, true, null, null);
	}

	@Override
	public String getCommName() {
		return "Observation-Center";
	}

	/**
	 *
	 * @param uniqueId
	 * @return the reported vehicle speed, or -1 if no vehicle speed has been reported yet
	 */
	public double getVehicleSpeed(long uniqueId) {
		return vehicleSpeeds.containsKey(uniqueId) ? vehicleSpeeds.get(uniqueId) : -1;
	}

	public Set<Long> getVehicleIds(long roadSegmentId) {
		return CollectionUtil.ensureNotNull(roadSegmentVehicleMapping.get(roadSegmentId));
	}

	public long getNumVehicles(long roadSegmentId) {
		return roadSegmentVehicleMapping.containsKey(roadSegmentId) ? roadSegmentVehicleMapping.get(roadSegmentId).size() : 0;
	}

	@Override
	public void dispose() {
		vehicleInfoReceivers.clear();
	}

}

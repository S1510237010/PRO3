package at.fhhagenberg.mc.traffsim.ui.osm;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Point2D;

import org.jdesktop.swingx.mapviewer.GeoPosition;
import org.jdesktop.swingx.painter.AbstractPainter;

/**
 * This specific overlay painter extends the class AbstractPaint and allows us to draw overlays on a JXMapViewer object. In this particular
 * case the painter is used to visualize the currently draw bounding box on a map view.
 * 
 * @author Manuel Lindorfer, 2013
 * @param <JXMapViewer>
 * 
 */
public class SelectionRectanglePainter<JXMapViewer> extends AbstractPainter<org.jdesktop.swingx.JXMapViewer> {

	/**
	 * Minimum and maximum position of the bounding box (min. lat/lng, max. lat/lng)
	 **/
	private GeoPosition minPos = null;
	private GeoPosition maxPos = null;

	/**
	 * Set's the bounding rectangle to be displayed.
	 * 
	 * @param rect
	 *            the new bounding rectangle
	 * @param map
	 *            the map viewer to draw on
	 */
	public void setSelectionRectangle(Rectangle rect, org.jdesktop.swingx.JXMapViewer map) {
		if (rect != null) {
			minPos = map.convertPointToGeoPosition(new Point2D.Double(rect.x, rect.y));
			maxPos = map.convertPointToGeoPosition(new Point2D.Double(rect.x + rect.width, rect.y + rect.height));
		} else {
			minPos = null;
			maxPos = null;
		}
	}

	/**
	 * Set's the bounding coordinates for the painter.
	 * 
	 * @param bounds
	 *            minimum and maximum latitude and longitude of the bounding rectangle
	 */
	public void setBoundaries(double[] bounds) {
		minPos = new GeoPosition(bounds[2], bounds[1]);
		maxPos = new GeoPosition(bounds[0], bounds[3]);
	}

	@Override
	protected void doPaint(Graphics2D g, org.jdesktop.swingx.JXMapViewer map, int arg2, int arg3) {
		if (minPos != null) {
			g.setColor(Color.RED);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
			Point2D min = map.convertGeoPositionToPoint(minPos);
			Point2D max = map.convertGeoPositionToPoint(maxPos);
			g.fillRect((int) min.getX(), (int) min.getY(), Math.abs((int) (max.getX() - min.getX())),
					Math.abs((int) (max.getY() - min.getY())));
		}
	}
}

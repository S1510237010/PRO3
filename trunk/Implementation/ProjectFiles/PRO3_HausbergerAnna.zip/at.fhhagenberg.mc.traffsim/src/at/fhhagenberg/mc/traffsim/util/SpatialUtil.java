package at.fhhagenberg.mc.traffsim.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.geotools.geometry.jts.JTS;

import com.vividsolutions.jts.algorithm.ConvexHull;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.MultiLineString;
import com.vividsolutions.jts.geom.MultiPoint;
import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.geom.PrecisionModel;
import com.vividsolutions.jts.geom.TopologyException;
import com.vividsolutions.jts.geom.impl.CoordinateArraySequence;
import com.vividsolutions.jts.operation.buffer.BufferOp;
import com.vividsolutions.jts.operation.buffer.BufferParameters;
import com.vividsolutions.jts.operation.buffer.OffsetCurveBuilder;
import com.vividsolutions.jts.operation.distance.DistanceOp;
import com.vividsolutions.jts.operation.linemerge.LineMerger;
import com.vividsolutions.jts.simplify.DouglasPeuckerSimplifier;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.geo.Line;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.Node;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.exceptions.MergeException;
import at.fhhagenberg.mc.traffsim.util.exceptions.SpatialException;
import at.fhhagenberg.mc.traffsim.util.exceptions.SplitException;
import at.fhhagenberg.mc.traffsim.util.jts.JTSAdapter;
import at.fhhagenberg.mc.traffsim.util.types.MergeResult;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle.VehicleProperties;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Static class which provides spatial utility functions
 *
 * @author Christian B.
 *
 */
public class SpatialUtil {
	/**
	 * Creates an offset polygon from the polygon given by the points list.
	 * <p>
	 * A negative distance indicates offset to the right, a positive distance to the left
	 *
	 * @param points
	 *            forming the polygon
	 * @param distance
	 *            offset distance to current polygon. If distance is negative, the offset curve will be created on the LEFT of the current
	 *            curve, if positive, on the right.
	 * @param removeSelfIntersections
	 *            Fix self intersections which occur because of offsetting
	 * @return the offset curve if OK, or the original curve if distance == 0
	 * @throws SpatialException
	 */
	public static List<Vector> createOffsetCurve(List<Vector> points, double distance, boolean removeSelfIntersections) throws SpatialException {
		if (distance == 0.0) {
			return new ArrayList<>(points);
		}
		List<Coordinate> coords = new ArrayList<>();
		for (int i = 0; i < points.size(); i++) {
			coords.add(new Coordinate(points.get(i).x, points.get(i).y));
		}
		Coordinate[] coordinates = coords.toArray(new Coordinate[] {});

		PrecisionModel model = new PrecisionModel();
		BufferParameters params = new BufferParameters();
		params.setQuadrantSegments(10);
		params.setJoinStyle(BufferParameters.JOIN_ROUND);
		params.setEndCapStyle(BufferParameters.CAP_ROUND);
		params.setSingleSided(true);
		BufferOp.bufferOp(JTSAdapter.toLineString(coordinates), distance);
		OffsetCurveBuilder offset = new OffsetCurveBuilder(model, params);
		Coordinate[] curve = offset.getOffsetCurve(coordinates, distance);
		if (removeSelfIntersections) {
			curve = JTSAdapter.toCoordinates(removeSelfIntersections(JTSAdapter.toVectorList(curve), points, distance));
		}
		List<Vector> result = JTSAdapter.toVectorList(curve);
		/**
		 * check if points are straight, because possibly middle points are removed (since potentially unnecessary). This is not the case in
		 * this use case, because the first and last point may be removed afterwards, so that a line consists of only one point after all
		 * operations. Therefore, the middle points must be added again
		 */
		if (isStraight(points) && points.size() != result.size() && result.size() <= 3) {
			for (Vector origPt : points) {
				List<Vector> closestPts = closestPoints(origPt, result);
				for (Vector closestPt : closestPts) {
					if (!result.contains(closestPt)) {
						result.add(points.indexOf(origPt), closestPt);
					}
				}
			}
		}
		return result;
	}

	/**
	 * Simplifies a Geometry using the standard Douglas-Peucker algorithm. Ensures that any polygonal geometries returned are valid. Simple
	 * lines are not guaranteed to remain simple after simplification. All geometry types are handled. Empty and point geometries are
	 * returned unchanged.
	 *
	 * Note that in general D-P does not preserve topology - e.g. polygons can be split, collapse to lines or disappear holes can be created
	 * or disappear, and lines can cross. To simplify geometry while preserving topology use TopologyPreservingSimplifier. (However, using
	 * D-P is significantly faster).
	 *
	 * @param curve
	 *            to simplify
	 * @param distanceTolerance
	 *            in meters
	 * @return the simplified curve
	 * @throws SpatialException
	 *             if simplification fails
	 */
	public static List<Vector> simplifyCurve(List<Vector> curve, double distanceTolerance) throws SpatialException {
		try {
			return JTSAdapter.toVectorList(DouglasPeuckerSimplifier
					.simplify(new GeometryFactory().createLineString(JTSAdapter.toCoordinates(curve)), distanceTolerance).getCoordinates());
		} catch (IllegalArgumentException ex) {
			throw new SpatialException("Could not simplify curve starting with point: " + curve.get(0).toString());
		}
	}

	public static boolean isStraight(List<Vector> points) {
		double angle = Double.POSITIVE_INFINITY;
		Iterator<Vector> it = points.iterator();
		Vector v1 = it.next();
		while (it.hasNext()) {
			Vector v2 = it.next();
			if (angle == Double.POSITIVE_INFINITY || NumberUtil.doubleEquals(v2.minus(v1).getAngle(), angle, 0.000001)) {
				angle = v2.minus(v1).getAngle();
			} else {
				return false;
			}
		}
		return true;
	}

	/**
	 * Translates a position between lanes, since the positions do not match. The position is calculated starting at the beginnning of the
	 * road segment, including all turns. The outer segment obviously has a longer way at the turn than the inner, thus positions go their
	 * separate ways. This method translates the position between two lanes.
	 *
	 * @param currentLane
	 *            The lane where the position is known
	 * @param newLane
	 *            The target lane of which the position is desired
	 * @param positionOnCurrentLane
	 *            The position on <code>currentLane</code>
	 *
	 * @return position on <code>newLane</code>
	 */
	public static double translatePosition(VehiclesLane currentLane, VehiclesLane newLane, double positionOnCurrentLane) {
		RoadGeometry currentGeom = currentLane.getRoadGeometry();
		RoadGeometry newGeom = newLane.getRoadGeometry();
		Vector pos = currentGeom.mapPosition(positionOnCurrentLane);
		if (pos == null) {
			Logger.logError("Position mapping not found");
			return positionOnCurrentLane;
		}
		try {
			Coordinate[] points = DistanceOp.nearestPoints(JTSAdapter.toLineString(newGeom), JTSAdapter.toPoint(pos));
			return newGeom.mapPoint(JTSAdapter.toVector(points[0]));
		} catch (Exception e) {
			Logger.logError("Could not map position", e);
			return positionOnCurrentLane;
		}
	}

	public static double angleAtPosition(Vehicle vehicle, double position) {
		return angleAtPosition(vehicle, position, vehicle.getLaneSegment().getSourceLaneSegment());
	}

	public static double angleAtPosition(Vehicle vehicle, double position, VehiclesLane source) {
		RoadGeometry geom = vehicle.getLaneSegment().getRoadGeometry();
		if (position > 0 || source == null) {
			return geom.angleAt(position);
		} else {
			return source.getRoadGeometry().angleAt(position + source.getRoadGeometry().getRoadLength());
		}
	}

	/**
	 * Smoothes edges of the network, sharp edges are split to multiple edges with less sharp angles
	 *
	 * @param network
	 * @param factor
	 *            smoothing factor, which indicates similarity to original shape. 0 indicates smoothest network, 1 the best similarity to
	 *            original
	 * @return smoothed network, with updated lane segments and
	 */
	public static RoadNetwork smoothNetwork(RoadNetwork network, float factor) {
		List<RoadSegment> roadSegments = new ArrayList<>(network.getRoadSegments());
		RoadSegment processedInLastLoop = null;
		while (roadSegments.size() > 0) {
			RoadSegment roadSegment = roadSegments.get(0);
			if (roadSegment.equals(processedInLastLoop)) {
				/**
				 * special case: if the source and destination is not linked correctly (because of cut off on area edges), an endless loop
				 * may occur because of non-removal of the segment at index 0. This is worked against by checking double-processing of a
				 * single id here
				 */
				roadSegments.remove(roadSegment);
			} else {
				processedInLastLoop = roadSegment;
			}
			Set<Long> alreadyPassedIds = new HashSet<>();
			while (roadSegment.getSourceRoadSegment() != null && !alreadyPassedIds.contains(roadSegment.getId())) {
				alreadyPassedIds.add(roadSegment.getId());
				roadSegment = roadSegment.getSourceRoadSegment();
			}
			LineMerger merger = new LineMerger();
			List<RoadSegment> containingSegments = new ArrayList<>();
			alreadyPassedIds = new HashSet<>();
			while (roadSegment != null && !alreadyPassedIds.contains(roadSegment.getId())) {
				containingSegments.add(roadSegment);
				roadSegments.remove(roadSegment);
				try {
					LineString ls = JTSAdapter.toLineString(roadSegment.getRoadGeometry());
					merger.add(ls);
				} catch (IllegalArgumentException e) {
					Logger.logWarn("Could not merge road segment " + roadSegment.getId() + " (" + e.getMessage() + ")");
				}
				alreadyPassedIds.add(roadSegment.getId());
				roadSegment = roadSegment.getSinkRoadSegment();
			}
			Collection<?> mergedLine = merger.getMergedLineStrings();
			for (Object object : mergedLine) {
				if (object instanceof LineString) {
					LineString str = (LineString) object;
					Geometry smoothed = JTS.smooth(str, factor);
					List<Vector> smoothedPoints = JTSAdapter.toVectorList(smoothed.getCoordinates());
					for (RoadSegment rs : containingSegments) {
						List<Vector> roadPoints = rs.getRoadGeometry().getPoints();
						int first = smoothedPoints.indexOf(roadPoints.get(0));
						int last = smoothedPoints.lastIndexOf(roadPoints.get(roadPoints.size() - 1));
						if (first >= 0 && last >= 0 && first < last) {
							rs.getRoadGeometry().setPoints(smoothedPoints.subList(first, last + 1));
						}
					}
				}
			}
		}
		for (RoadSegment seg : network.getRoadSegments()) {
			seg.updateLaneGeometries();
		}
		return network;
	}

	public static List<Vector> smooth(List<Vector> points, float factor) {
		return JTSAdapter.toVectorList(JTS.smooth(JTSAdapter.toLineString(points), factor).getCoordinates());
	}

	public static List<Vector> removeSelfIntersections(List<Vector> offsetPoints, final List<Vector> originalCurve, final double distance)
			throws SpatialException {
		try {
			if (!SpatialUtil.isSimple(offsetPoints)) {
				/** remove potential null entries */
				offsetPoints.remove(null);
				LineString ls = JTSAdapter.toLineString(offsetPoints);
				List<Vector> resultCoords = new ArrayList<>();
				Geometry result = ls.union();
				if (result instanceof MultiLineString) {
					MultiLineString mls = (MultiLineString) result;
					if (mls.getNumGeometries() == 3) {
						/**
						 * simple case -> only one "crossing" point is found, but: It may be the case that the road is a ring road, and in
						 * fact not the middle ring has to be removed, but the first and the last part.<br>
						 * The decision which part has to be removed is made by calculating both results and doing a plausibility check,
						 * which compares the average distance from the original curve. The curve which average distance is closer to the
						 * desired distance is taken.
						 */
						for (int n = 0; n < mls.getNumGeometries(); n += 2) {
							resultCoords.addAll(JTSAdapter.toVectorList(mls.getGeometryN(n).getCoordinates()));
						}
						List<Vector> result1 = JTSAdapter.toVectorList(mls.getGeometryN(1).getCoordinates());
						double dist0 = NumberUtil.roundTo(SpatialUtil.averagePointDistance(resultCoords, originalCurve), 2);
						double dist1 = NumberUtil.roundTo(SpatialUtil.averagePointDistance(result1, originalCurve), 2);
						/** Compare if the alternative method creates a better result. If yes -> take it */
						if (Math.abs(dist0 - Math.abs(distance)) > Math.abs(dist1 - Math.abs(distance)) && Math.abs(
								SpatialUtil.getLength(result1) - SpatialUtil.getLength(originalCurve)) < SpatialUtil.getLength(originalCurve) / 3) {
							resultCoords = result1;
						}
					} else {
						/**
						 * More complicated curve: More self-intersections are detected. Remove all middle intersections to transform the
						 * curve into a form which contains only 1 intersection and treat it as "simple case" (see above)
						 */
						/** first polyline is added in every case */
						resultCoords.addAll(JTSAdapter.toVectorList(mls.getGeometryN(0).getCoordinates()));
						/** run through the rest of the split polylines and check if they are part of an intersection */
						for (int n = 1; n < mls.getNumGeometries() - 1; n++) {
							Coordinate[] coords = mls.getGeometryN(n).getCoordinates();
							/**
							 * find any next part which has our first point as last point. if found -> skip all parts inbetween because they
							 * form the superfluous self-intersection
							 */
							int skipUntil = -1;
							for (int nn = n; nn < mls.getNumGeometries() - 1; nn++) {
								Coordinate[] nnCoords = mls.getGeometryN(nn).getCoordinates();
								/**
								 * 2 cases:<br>
								 * - coords[0].equals(nnCoords[nnCoords.length - 1]: found a segment which ends at coords start point ->
								 * skip all segments from coords to this segment<br>
								 * - nn==numGeometries-2: see doc/Self-Intersection/3.fig for details. Intersectino point found, but
								 * segments inbetween must not be removed -> do not set skip point
								 */
								if (coords[0].equals(nnCoords[nnCoords.length - 1]) && nn != mls.getNumGeometries() - 2) {
									skipUntil = nn;
									break;
								}
							}
							if (skipUntil == -1 && n > 0) {
								/** no self-intersection found (skipUntil==-1), and we are over the first polyline (n>0) */
								resultCoords.addAll(JTSAdapter.toVectorList(coords));
							} else {
								/**
								 * skip all polylines which form the self-intersection and continue after them searching for new ones
								 */
								n = skipUntil;
							}
						}
						/** add the last polyline of the MultilineString */
						resultCoords.addAll(JTSAdapter.toVectorList(mls.getGeometryN(mls.getNumGeometries() - 1).getCoordinates()));

						/** Continue removing left self-intersections, but avoid endless loop if nothing is removed any more */
						if (resultCoords.size() != offsetPoints.size()) {
							resultCoords = removeSelfIntersections(resultCoords, originalCurve, distance);
						}
					}
				}
				return resultCoords;
			} else {
				/** no self-intersections found - return original line */
				return offsetPoints;
			}
		} catch (Exception ex) {
			throw new SpatialException("Could not remove self-intersections", ex, true);
		}
	}

	public static double getLength(List<Vector> polyline) {
		if (polyline.size() < 2) {
			return 0;
		}
		double length = 0;
		Vector point1 = polyline.get(0);
		for (int i = 1; i < polyline.size(); i++) {
			Vector point2 = polyline.get(i);
			length += point2.minus(point1).magnitude();
			point1 = point2;
		}
		return length;
	}

	/**
	 * Calculates the average distance of each point from the input vector measured to the nearest point from the original curve.
	 *
	 * @param vector
	 * @param originalCurve
	 * @return the average point distance from vector to originalcurve
	 */
	public static double averagePointDistance(List<Vector> vector, List<Vector> originalCurve) {
		double average = 0;
		for (int i = 0; i < vector.size(); i++) {
			average += closestPoints(vector.get(i), originalCurve).get(0).minus(vector.get(i)).magnitude();
		}
		return average / vector.size();
	}

	public static boolean isSimple(List<Vector> points) {
		LineString ls = JTSAdapter.toLineString(points);
		return ls.isSimple();
	}

	public static boolean isRing(List<Vector> line) {
		return JTSAdapter.toLineString(line).isRing();
	}

	public static List<Vector> intersect(List<Vector> list, List<Vector> list2) {
		LineString ls1;
		ls1 = JTSAdapter.toLineString(list);
		LineString ls2 = JTSAdapter.toLineString(list2);
		List<Vector> result = new ArrayList<>();
		Geometry inter = ls1.intersection(ls2);
		if (inter instanceof Point) {
			result.add(JTSAdapter.toVector((Point) inter));
			return result;
		} else if (inter instanceof MultiPoint) {
			result.addAll(JTSAdapter.toVectorList(((MultiPoint) inter).getCoordinates()));
			return result;
		}
		return null;
	}

	public static boolean intersectsArea(List<Vector> original, List<Vector> containing) {
		if (original == null || containing == null) {
			return false;
		}
		Polygon ls1 = JTSAdapter.toPolygon(original);
		Polygon ls2 = JTSAdapter.toPolygon(containing);
		Geometry inter;
		try {
			inter = ls1.intersection(ls2);
		} catch (TopologyException ex) {
			inter = new ConvexHull(ls1).getConvexHull().intersection(new ConvexHull(ls2).getConvexHull());
		}
		return !inter.isEmpty();
	}

	/**
	 * Creates a convex hull for the polygon given, and moves it outwards by the given parameter
	 *
	 * @param bounds
	 * @param buffer
	 *            amount of distance units to move outwards
	 * @return the convex hull
	 */
	public static List<Vector> convexHull(Set<Vector> bounds, double buffer) {
		ConvexHull hull = new ConvexHull(JTSAdapter.toCoordinates(new ArrayList<>(bounds)), new GeometryFactory());
		Coordinate[] coords = hull.getConvexHull().getCoordinates();
		if (buffer > 0 && coords.length > 2) {
			coords = hull.getConvexHull().buffer(buffer).getCoordinates();
		}
		return JTSAdapter.toVectorList(coords);
	}

	/**
	 * Splits the lineString at the point closest to c.
	 *
	 * @param toSplit
	 *            the vector to split
	 * @param splitter
	 *            the splitting vector
	 * @param ignoreNonFatalExceptions
	 *            ignore exception if possible, and return original curve toSplit
	 * @return the longest part of the split vector
	 * @throws SplitException
	 *
	 */
	public static List<Vector> split(List<Vector> toSplit, List<Vector> splitter, boolean ignoreNonFatalExceptions) throws SplitException {
		if (toSplit.isEmpty()) {
			throw new IllegalArgumentException("Empty geometry to split");
		}
		if (splitter.isEmpty()) {
			throw new IllegalArgumentException("Empty splitter");
		}
		LineString toSplitLS = JTSAdapter.toLineString(toSplit);
		Polygon splitterLS = JTSAdapter.toPolygon(splitter);

		Geometry diff = toSplitLS.difference(splitterLS);
		if (diff.isEmpty()) {
			if (!ignoreNonFatalExceptions) {
				if (splitterLS.contains(toSplitLS) || splitterLS.crosses(toSplitLS)) {
					throw new SplitException("Split not possible (splitter contains toSplit and does not intersect)", false);
				}
				throw new SplitException("Geometry to cut does not intersect with the splitter", true);
			} else {
				return toSplit;
			}
		}
		if (diff instanceof LineString) {
			return JTSAdapter.toVectorList(diff.getCoordinates());
		} else if (diff instanceof MultiLineString) {
			// take longest part if split line contains more than one segment
			MultiLineString mls = (MultiLineString) diff;
			double maxLen = 0;
			int ind = 0;
			for (int n = 0; n < mls.getNumGeometries(); n++) {
				if (mls.getGeometryN(n).getLength() > maxLen) {
					maxLen = mls.getGeometryN(n).getLength();
					ind = n;
				}
			}
			return JTSAdapter.toVectorList(mls.getGeometryN(ind).getCoordinates());
		}
		return null; // we should never reach this
	}

	public static List<Vector> extend(List<Vector> inputLine, int factor) {
		if (inputLine == null || inputLine.isEmpty()) {
			return inputLine;
		}
		List<Vector> currentList = new ArrayList<>(inputLine);
		for (int f = 1; f < factor; f++) {
			List<Vector> result = new ArrayList<>();
			result.add(inputLine.get(0));
			for (int v = 1; v < inputLine.size(); v++) {
				Vector pt1 = inputLine.get(v - 1);
				Vector pt2 = inputLine.get(v);
				Vector dir = pt2.minus(pt1);
				result.add(pt1.plus(dir.unify().multiplyBy(dir.magnitude() / 2)));
				result.add(pt2);
			}
			currentList = result;
		}
		return (currentList);
	}

	public static boolean intersects(List<Vector> geom1, List<Vector> geom2) {
		LineString ls1;
		ls1 = JTSAdapter.toLineString(geom1);
		LineString ls2 = JTSAdapter.toLineString(geom2);
		return ls1.intersects(ls2);

	}

	public static boolean intersects(VehiclesLane lane1, VehiclesLane lane2) {
		if (lane1.equals(lane2)) {
			return true;
		}
		List<List<Vector>> allpts1 = getAllPolyLines(lane1);
		List<List<Vector>> allpts2 = getAllPolyLines(lane2);
		for (List<Vector> poly1 : allpts1) {
			for (List<Vector> poly2 : allpts2) {
				if (intersects(poly1, poly2)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Returns a list of List<Vector> which contains left bounds, right bounds and center of a {@link VehiclesLane}. Can be used e.g. for
	 * intersection calculation
	 *
	 * @param lane
	 * @return (new) collection of vector lists containing the {@link VehiclesLane} geometries
	 */
	public static List<List<Vector>> getAllPolyLines(VehiclesLane lane) {
		List<List<Vector>> allPoints = new ArrayList<>();

		allPoints.add(lane.getRoadGeometry().getPoints());
		allPoints.add(lane.getLeftEdge());
		allPoints.add(lane.getRightEdge());
		return allPoints;
	}

	public static List<Vector> intersect(VehiclesLane lane1, VehiclesLane lane2) {
		List<List<Vector>> allPoints1 = getAllPolyLines(lane1);
		List<List<Vector>> allPoints2 = getAllPolyLines(lane2);
		Set<Vector> intersections = new HashSet<>();
		for (List<Vector> list1 : allPoints1) {
			for (List<Vector> list2 : allPoints2) {
				List<Vector> inter = intersect(list1, list2);
				if (inter != null) {
					intersections.addAll(inter);
				}
			}
		}
		return convexHull(intersections, 0);
	}

	/**
	 * Calculates the points of a curve which has a minimal distance to the origin. This point needs NOT to be contained in the polygon
	 * points!
	 *
	 * @param origin
	 * @param polygon
	 * @return the closest points of the polygon, which needs NOT to be contained in the polygon
	 */
	public static List<Vector> closestPoints(Vector origin, List<Vector> polygon) {
		GeometryFactory f = new GeometryFactory();
		Coordinate[] coords = new Coordinate[] { JTSAdapter.toCoordinate(origin) };
		Point p = new Point(new CoordinateArraySequence(coords), f);
		Coordinate[] pts = DistanceOp.nearestPoints(p, JTSAdapter.toLineString(polygon));
		List<Vector> closestPts = JTSAdapter.toVectorList(pts);
		closestPts.remove(origin);
		return closestPts;
	}

	/**
	 * Determines the closest point to the origin, out of the given list
	 *
	 * @param origin
	 *            the point to compare to
	 * @param polygon
	 *            the list of points to compare with
	 * @return the closest point, out of the sampling points of the provided curve
	 */
	public static Vector closestPointOutOfList(Vector origin, List<Vector> polygon) {
		double mindist = Double.MAX_VALUE;
		Vector nearest = null;
		for (Vector vector : polygon) {
			if (vector != null) {
				double curdist = vector.distanceTo(origin);
				if (curdist < mindist) {
					nearest = vector;
					mindist = curdist;
				}
			}
		}
		return nearest;
	}

	public static Vector firstIntersection(List<Vector> points1, List<Vector> points2) {
		List<Vector> inter = intersect(points1, points2);
		return (inter != null && inter.size() > 0) ? inter.get(0) : null;
	}

	/**
	 * Calcualtes the nearest intersection point to referencePoint between points1 and points2
	 *
	 * @param points1
	 *            first geometry
	 * @param points2
	 *            second geometry
	 * @param referencePoint
	 *            reference point to calculate the nearest intersection
	 * @return the nearest intersection of vectors to the reference point
	 */
	public static Vector nearestIntersection(List<Vector> points1, List<Vector> points2, Vector referencePoint) {
		List<Vector> inter = intersect(points1, points2);
		if (inter == null) {
			return null;
		}
		Vector closest = null;
		double minDistance = Double.MAX_VALUE;
		for (Vector vector : inter) {
			double curDist = getDistance(vector, referencePoint);
			if (curDist < minDistance) {
				minDistance = curDist;
				closest = vector;
			}
		}
		return closest;
	}

	public static double getDistance(Vector vec1, Vector vec2) {
		return vec1.minus(vec2).magnitude();
	}

	/**
	 * Finds the shortest distance between the two polygons
	 *
	 * @param polygon1
	 * @param polygon2
	 * @return the distance between the nearest two points of the geometries (0 if they intersect)
	 */
	public static double getShortestDistance(List<Vector> polygon1, List<Vector> polygon2) {
		return JTSAdapter.toPolygon(polygon1).distance(JTSAdapter.toPolygon(polygon2));
	}

	/**
	 * This estimation assumes the earth to be a sphere instead of its original ellipse-like geometry
	 *
	 * @param lat1
	 *            in decimal WGS84 coordinates
	 * @param lon1
	 *            in decimal WGS84 coordinates
	 * @param lat2
	 *            in decimal WGS84 coordinates
	 * @param lon2
	 *            in decimal WGS84 coordinates
	 * @return the estimated distance of the two points in meters
	 */
	public static double getDistance(double lat1, double lon1, double lat2, double lon2) {
		double d2r = Math.PI / 180;

		double dlong = (lon2 - lon1) * d2r;
		double dlat = (lat2 - lat1) * d2r;
		double a = Math.pow(Math.sin(dlat / 2.0), 2) + Math.cos(lat1 * d2r) * Math.cos(lat2 * d2r) * Math.pow(Math.sin(dlong / 2.0), 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		double d = 6367 * c;

		return d;

	}

	/**
	 * Merges the two road segment, which means that the geometry of the second parameter is appended to the base geometry. This method
	 * auto-detects the start and end points of the geometries, so that the end point of the base geometry equals the start point of the
	 * geometry to add.
	 *
	 * @param base
	 * @param toAdd
	 * @return a {@link RoadSegment} which is lengthened by the geometry of another segment, or <code>null</code> if the geometries do not
	 *         have any common dangling point
	 */
	public static RoadSegment mergeSegments(RoadSegment base, RoadSegment toAdd) {
		RoadGeometry geom1 = base.getRoadGeometry();
		RoadGeometry geom2 = toAdd.getRoadGeometry();
		LinkedHashSet<Vector> newPts = new LinkedHashSet<>();

		Node start;
		Node end;
		// goal: 1--->2--->
		// comment: current situation
		if (geom1.getLastPoint().equals(geom2.getFirstPoint())) {
			// 1---> 2--->
			newPts.addAll(geom1.getModifiablePoints());
			newPts.addAll(geom2.getModifiablePoints());
			start = base.getStartNode();
			end = toAdd.getEndNode();
		} else if (geom1.getFirstPoint().equals(geom2.getFirstPoint())) {
			// <---2 1--->
			//
			List<Vector> pts = geom2.getModifiablePoints();
			Collections.reverse(pts);
			newPts.addAll(pts);
			newPts.addAll(geom1.getModifiablePoints());
			start = toAdd.getStartNode();
			end = base.getStartNode();
		} else if (geom1.getLastPoint().equals(geom2.getLastPoint())) {
			// 1---> <---2
			List<Vector> pts = geom2.getModifiablePoints();
			Collections.reverse(pts);
			newPts.addAll(geom1.getModifiablePoints());
			newPts.addAll(pts);
			start = base.getStartNode();
			end = toAdd.getStartNode();
		} else if (geom1.getFirstPoint().equals(geom2.getLastPoint())) {
			// 2---> 1--->
			newPts.addAll(geom2.getPoints());
			newPts.addAll(geom1.getPoints());
			start = toAdd.getStartNode();
			end = base.getEndNode();
		} else {
			// segments do not have any common point!
			return null;
		}
		RoadGeometry geomNew = new RoadGeometry();
		geomNew.setPoints(new ArrayList<>(newPts));
		RoadSegment mergedSeg = new RoadSegment(geomNew, base.getLaneCount());
		mergedSeg.setStartNode(start);
		mergedSeg.setEndNode(end);
		mergedSeg.getRoadGeometry().setPoints(new ArrayList<>(newPts));
		mergedSeg.setId(base.getId());
		mergedSeg.setRoutingId(base.getRoutingId());
		mergedSeg.setSourceRoadSegment(base.getSourceRoadSegment());
		mergedSeg.setSinkRoadSegment(toAdd.getSinkRoadSegment());
		mergedSeg.setSpeedLimitKmh(toAdd.getSpeedLimitKmph());
		mergedSeg.setName(base.getName());
		mergedSeg.setOsmReverse(base.isOsmReverse());
		return mergedSeg;
	}

	/**
	 * Computes the centroid of this polygon.
	 *
	 * @param bounds
	 *            the polygon
	 * @return the vector of which to calculate the center
	 */
	public static Vector getCenter(List<Vector> bounds) {
		Point center = JTSAdapter.toLineString(bounds).getCentroid();
		return JTSAdapter.toVector(center);
	}

	public static double getStartAngle(List<Vector> geom) {
		if (geom.size() < 2) {
			throw new IllegalArgumentException("Geometry must have at least two points");
		}
		return geom.get(1).minus(geom.get(0)).getAngle();
	}

	/**
	 *
	 * @param geom
	 * @return the angle of the vector of the last two points in radians
	 */
	public static double getEndAngle(List<Vector> geom) {
		if (geom.size() < 2) {
			throw new IllegalArgumentException("Geometry must have at least two points");
		}
		return CollectionUtil.getSecondToLastObject(geom).minus(CollectionUtil.getLastObject(geom)).getAngle();
	}

	public static double getAngleDifference(RoadGeometry roadGeom, boolean makePositive) {
		List<Vector> geom = roadGeom.getPoints();
		double diff = getEndAngle(geom) - Math.PI / 2 - getStartAngle(geom) - Math.PI / 2;
		if (makePositive) {
			return (diff + 4 * Math.PI) % (2 * Math.PI);
		}
		return diff;
	}

	/**
	 * Returns the difference of the angle inwards and outwards in a junction
	 *
	 * @param segmentIn
	 * @param segmentOut
	 * @param makePositive
	 *            add 2*PI until angle is positive
	 * @return angle difference of geometries
	 */
	public static double getAngleDifference(RoadGeometry segmentIn, RoadGeometry segmentOut, boolean makePositive) {
		double diff = (2 * Math.PI) + getEndAngle(segmentIn.getPoints()) - getStartAngle(segmentOut.getPoints());
		if (makePositive) {
			return (diff + 4 * Math.PI) % (2 * Math.PI);
		}
		return diff;
	}

	public static double getRelativeAngle(RoadGeometry geom1, boolean useEnd1, RoadGeometry geom2, boolean useEnd2) {
		double angle1 = useEnd1 ? getEndAngle(geom1.getPoints()) : getStartAngle(geom1.getPoints());
		double angle2 = useEnd2 ? getEndAngle(geom2.getPoints()) : getStartAngle(geom2.getPoints());
		return angle2 - angle1;
	}

	public static boolean isRightAngle(RoadGeometry geom1, boolean useEnd1, RoadGeometry geom2, boolean useEnd2) {
		double angle = getRelativeAngle(geom1, useEnd1, geom2, useEnd2);
		angle = (2 * Math.PI + angle) % Math.PI;
		return angle < Math.PI * 3 / 4 && angle > Math.PI * 1 / 4;
	}

	/**
	 * Checks whether the given points is contained in the polygon
	 *
	 * @param polygon
	 * @param point
	 * @return <code>true</code> if the point is contained in polygon
	 */
	public static boolean contains(List<Vector> polygon, Vector point) {
		return JTSAdapter.toPolygon(polygon).contains(JTSAdapter.toPoint(point));
	}

	/**
	 * Create a square around the point, with a width of distance
	 *
	 * @param pt
	 * @param width
	 * @return the square arount point pt
	 */
	public static List<Vector> extendToSquare(Vector pt, double width) {
		double dist = width / 2;
		List<Vector> result = new ArrayList<>();
		result.add(new Vector(pt.x - dist, pt.y - dist));
		result.add(new Vector(pt.x - dist, pt.y + dist));
		result.add(new Vector(pt.x + dist, pt.y + dist));
		result.add(new Vector(pt.x + dist, pt.y - dist));
		return result;
	}

	public static Line removePoints(Line line, Vector... pointsToRemove) {
		return removePoints(line, Arrays.asList(pointsToRemove));
	}

	public static Line removePoints(Line line, List<Vector> pointsToRemove) {
		LineString lineStr = JTSAdapter.toLineString(line.getPoints());
		List<Vector> newLine = new ArrayList<>(line.getPoints());
		for (Vector v : pointsToRemove) {
			if (!DistanceOp.isWithinDistance(JTSAdapter.toPoint(v), lineStr, 10e-10)) {
				// abort, because not all points intersect (do not use intersect to leave double precision tolerance)
				return line;
			}
		}
		for (Vector v : pointsToRemove) {
			if (newLine.contains(v)) {
				newLine.remove(v);
			} else {
				newLine.add(v);
			}
		}
		return new Line(newLine);
	}

	/**
	 * Merge junctions into one single junction containing all necessary connectors
	 *
	 * @param base
	 *            the junction to merge to
	 * @param toMerge
	 *            the junction which has to be merged (does not exist any more after merging and has to be removed from {@link RoadNetwork}
	 *            !)
	 * @return the merged junction
	 * @throws MergeException
	 *             if anything goes wrong during merging (e.g. new junction cannot be initialized)
	 */
	public static MergeResult merge(AbstractJunction base, AbstractJunction toMerge) throws MergeException {
		Node mergedNode = base.getSegmentsOut().get(0).getStartNode();
		// 1. find segments to remove
		ArrayList<RoadSegment> toRemove = new ArrayList<>(toMerge.getSegmentsIn());
		toRemove.addAll(toMerge.getSegmentsOut());
		ArrayList<RoadSegment> allOtherTemp = new ArrayList<>(base.getSegmentsIn());
		allOtherTemp.addAll(base.getSegmentsOut());
		toRemove.retainAll(allOtherTemp);
		// 2. mark routing ids which are not available any more after merging
		List<Long> oldRoutingIds = new ArrayList<>();
		for (RoadSegment rs : toRemove) {
			oldRoutingIds.add(rs.getRoutingId());
		}
		// 3. set correct in and out segments for new junctions and remove deleted road segment
		base.getSegmentsIn().addAll(toMerge.getSegmentsIn());
		base.getSegmentsOut().addAll(toMerge.getSegmentsOut());
		base.getSegmentsIn().removeAll(toRemove);
		base.getSegmentsOut().removeAll(toRemove);
		// 4. assign new junction and nodes to road segments and initialize
		for (RoadSegment rs : base.getSegmentsIn()) {
			rs.setJunction(base);
			rs.setEndNode(mergedNode);
		}
		for (RoadSegment rs : base.getSegmentsOut()) {
			rs.setStartNode(mergedNode);
		}
		base.addSecondaryId(toMerge.getId());
		try {
			base.initializeInterior();
		} catch (Exception e) {
			throw new MergeException("Cannot merge junctions", e);
		}
		return new MergeResult(base, toRemove);
	}

	/**
	 *
	 * @param bounds
	 * @return the maximum distance between two points of the given list
	 */
	public static double getMaxExtent(List<? extends Location> bounds) {
		double max = Double.MIN_VALUE;
		for (Location l1 : bounds) {
			for (Location l2 : bounds) {
				double dist = l1.distanceTo(l2);
				max = Math.max(max, dist);
			}
		}
		return max;
	}

	/**
	 *
	 * @param lane1
	 * @param lane2
	 * @return <code>true</code> if lane1 is the source or sink of lane2
	 */
	public static boolean areBordering(VehiclesLane lane1, VehiclesLane lane2) {
		return lane1.getSourceLaneSegment() != null && lane1.getSourceLaneSegment().equals(lane2)
				|| lane1.getSinkLaneSegment() != null && lane1.getSinkLaneSegment().equals(lane2)
				|| lane2.getSourceLaneSegment() != null && lane2.getSourceLaneSegment().equals(lane1)
				|| lane2.getSinkLaneSegment() != null && lane2.getSinkLaneSegment().equals(lane1);

	}

	/**
	 * Checks if a given area is in sight, assuming a view direction and current location.
	 *
	 * @param position
	 *            the current point of view
	 * @param direction
	 *            the viewing direction as {@link Vector}
	 * @param area
	 *            the area that should be checked if seen
	 * @param viewDistance
	 *            the viewing distance (if area farer away than that distance, it is considered as NOT viewable)
	 * @return <code>true</code> if viewing angle crosses the area within the provided distance, <code>false</code> otherwise
	 */
	public static boolean areaInSight(Vector position, Vector direction, List<Vector> area, double viewDistance) {
		return intersects(area, CollectionUtil.createArrayList(position, position.plus(direction.unify().multiplyBy(viewDistance))));
	}

	/**
	 * Get distance from me front to other tail in direction traffic direction
	 *
	 * @param me
	 *            vehicle which is behind to vehicle
	 * @param other
	 *            vehicle to get distance to
	 * @return distance to other vehicle in traffic direction, null if vehicle not found
	 */
	public static VehicleWithDistance getDirectedDistanceBetween(Vehicle me, Vehicle other) {
		double distance = 0;
		VehiclesLane curLaneSeg = me.getLaneSegment();
		double pos = me.getFrontPosition();
		if (curLaneSeg.getRoadSegment() == other.getRoadSegment()) {
			distance = -me.getFrontPosition();
		} else {
			while (curLaneSeg.getRoadSegment() != other.getRoadSegment()) {
				distance += curLaneSeg.getRoadLength() - pos;
				pos = 0;
				curLaneSeg = curLaneSeg.getSinkLaneSegment();
				if (curLaneSeg == null) {
					return null;
				}
			}
		}
		return new VehicleWithDistance(other,
				distance + SpatialUtil.translatePosition(other.getLaneSegment(), curLaneSeg, other.getFrontPosition()) - other.getLength());
	}

	/**
	 * Get absolute distance without directional constraints
	 *
	 * @param me
	 *            current vehicle
	 * @param other
	 *            other vehicle to get distance to
	 * @return absolute distance to other vehicle in both direction, null if vehicles not found
	 */
	public static VehicleWithDistance getAbsoluteDistanceBetween(Vehicle me, Vehicle other) {
		VehicleWithDistance vd = getDirectedDistanceBetween(me, other);
		if (vd == null) {
			vd = getDirectedDistanceBetween(other, me);
		}
		return new VehicleWithDistance(other, Math.abs(vd.getDistance()));
	}

	/**
	 * Get distance from vehicle me front position to vehicle other back position in both directions if me is in front of other distance is
	 * negative.
	 *
	 * @param me
	 *            current vehicle
	 * @param other
	 *            other vehicle to get distance to
	 * @return vehicle with distance
	 */
	public static VehicleWithDistance getDistanceBetween(Vehicle me, Vehicle other) {
		VehicleWithDistance vd = getDirectedDistanceBetween(me, other);
		if (vd == null) {
			vd = getDirectedDistanceBetween(other, me);
			if (vd == null) {
				return null;
			}
			vd = new VehicleWithDistance(other, -(vd.getDistance() + me.getLength() + other.getLength()));
		}
		return vd;

	}

	public static VehicleWithDistance getNeighborVehicle(Vehicle me, int lookForward) {
		if (me.getLaneSegment() == null || me.getRoadSegment() == null || me.getRoadSegment().getLaneCount() <= 1) {
			return null;
		}
		LaneSegment laneLeft = me.getRoadSegment().laneSegment(me.getLaneIndex() + Lane.TO_LEFT);
		if (laneLeft != null) {
			VehicleWithDistance frontLeft = RoadUtil.isOtherVehicleBeforeJunction(me, laneLeft) ? laneLeft.frontVehicle(me, me.getFrontPosition())
					: null;
			if (frontLeft != null && !frontLeft.getVehicle().isObstacle()) {
				double distSum = frontLeft.getDistance();
				for (int i = 1; i < lookForward; i++) {
					distSum += frontLeft.getVehicle().getLength();
					frontLeft = laneLeft.frontVehicle(frontLeft.getVehicle());
					if (frontLeft == null) {
						return null;
					}
					distSum += frontLeft.getDistance();
				}
				frontLeft = new VehicleWithDistance(frontLeft.getVehicle(), distSum);
				if (frontLeft != null && PropertyUtil.getIntProperty(frontLeft.getVehicle().getVehicleProperties(),
						VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name(), Lane.NO_CHANGE) == Lane.TO_RIGHT) {
					return frontLeft;

				}
			}

		}
		LaneSegment laneRight = me.getRoadSegment().laneSegment(me.getLaneIndex() + Lane.TO_RIGHT);
		if (laneRight != null) {
			VehicleWithDistance frontRight = RoadUtil.isOtherVehicleBeforeJunction(me, laneRight) ? laneRight.frontVehicle(me, me.getFrontPosition())
					: null;
			if (frontRight != null && !frontRight.getVehicle().isObstacle()) {
				double distSum = frontRight.getDistance();
				for (int i = 1; i < lookForward; i++) {
					distSum += frontRight.getVehicle().getLength();
					frontRight = laneRight.frontVehicle(frontRight.getVehicle());
					if (frontRight == null) {
						return null;
					}
					distSum += frontRight.getDistance();
				}
				frontRight = new VehicleWithDistance(frontRight.getVehicle(), distSum);
				if (frontRight != null && PropertyUtil.getIntProperty(frontRight.getVehicle().getVehicleProperties(),
						VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name(), Lane.NO_CHANGE) == Lane.TO_LEFT) {
					// breaking is necessary
					return frontRight;
				}
			}
		}

		return null;
	}

}

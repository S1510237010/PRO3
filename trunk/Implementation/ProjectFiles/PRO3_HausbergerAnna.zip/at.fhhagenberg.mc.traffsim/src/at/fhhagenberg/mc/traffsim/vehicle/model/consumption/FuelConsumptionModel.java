package at.fhhagenberg.mc.traffsim.vehicle.model.consumption;

import at.fhhagenberg.mc.traffsim.vehicle.model.AbstractModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics.PhysicsConsumptionModel;

/**
 * Base class for fuel consumption models which provides basic functionalities. For a concrete implementation see
 * {@link PhysicsConsumptionModel}.
 *
 * @author Christian Backfrieder
 */
public abstract class FuelConsumptionModel extends AbstractModel {

	/**
	 * Creates a new {@link FuelConsumptionModel}.
	 */
	public FuelConsumptionModel() {
		super();
	}

	/**
	 * Gets the error associated with the incorrect determination of fuel flow.
	 *
	 * @return the fuel flow error
	 */
	public abstract double fuelflowError();

	/**
	 * Gets the fuel flow in m^3/s and the <code>FUEL_ERROR</code> if the operation point is not possible.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @param slope
	 *            the slope
	 * @param gearIndex
	 *            the gear index
	 * @param withJante
	 *            the with jante
	 * @return fuelFlow
	 */
	public abstract double getFuelFlow(double v, double acc, double slope, int gearIndex, boolean withJante);

	/**
	 * Gets the optimum fuel consumption flow in liter/s.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @param slope
	 *            the slope of the current road segment (positive value - upwards, negative value - downwards)
	 * @return the fuel flow in liter/s
	 */
	public double getFuelFlowInLiterPerS(double v, double acc, double slope) {
		return 1000 * getMinFuelFlow(v, acc, slope, true)[0];
	}

	public abstract double getCO2EmissionsInKgPerS(double fuelFlow);

	/**
	 * Gets the model's unique identifier.
	 *
	 * @return the unique identifier
	 */
	public abstract String getIdentifier();

	/**
	 * Gets the instantaneous fuel consumption in liters/100km with a cut-off for v=0, choose gear automatically.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @param slope
	 *            the slope of the current road segment (positive value - upwards, negative value - downwards)
	 * @param withJante
	 *            indicates whether or not to consider the engine's min. and max. frequency for fuel flow calculation
	 * @return the instantaneous consumption per 100km
	 */
	public double getInstConsumption100km(double v, double acc, double slope, boolean withJante) {
		return 1e8 * getMinFuelFlow(v, acc, slope, withJante)[0] / Math.max(v, 0.001);
	}

	/**
	 * Gets the instantaneous fuel consumption in liters/100km with a cut-off for zero velocity.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @param slope
	 *            the slope of the current road segment (positive value - upwards, negative value - downwards)
	 * @param gear
	 *            the currently selected gear
	 * @param withJante
	 *            indicates whether or not to consider the engine's min. and max. frequency for fuel flow calculation
	 * @return the instantaneous consumption per 100km
	 */
	public double getInstConsumption100km(double v, double acc, double slope, int gear, boolean withJante) {
		final int gearIndex = gear - 1;
		return 1e8 * getFuelFlow(v, acc, slope, gearIndex, withJante) / Math.max(v, 0.001);
	}

	/**
	 * Gets the optimal fuel flow in m^3/s and the used fuel-optimised gear.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @param slope
	 *            the slope of the current road segment (positive value - upwards, negative value - downwards)
	 * @param withJante
	 *            indicates whether or not to consider the engine's min. and max. frequency for fuel flow calculation
	 * @return double array containing the optimal fuel flow (index 0) and the (fuel-)optimised gear (index 1)
	 */
	public abstract double[] getMinFuelFlow(double v, double acc, double slope, boolean withJante);

	/**
	 * Gets the optimal fuel flow (choose gear with lowest flow automatically) in liter/s and liters/100km.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @param slope
	 *            the slope of the current road segment (positive value - upwards, negative value - downwards)
	 * @return double array containing the optimal fuel flow in liter/s (index 0) and liter/100km (index 1)
	 */
	public double[] getMultipleFuelFlow(double v, double acc, double slope) {
		double[] result = new double[2];
		result[0] = getFuelFlowInLiterPerS(v, acc, slope);
		result[1] = result[0] / 1000 * 1e8 / Math.max(v, 0.001);
		return result;
	}

	/**
	 * Gets the current CO2 consumption
	 * 
	 * @param v
	 *            the current speed in m/s
	 * @param fuelFlow
	 *            the current fuel flow in liters per second
	 * @return array with fuel flow in kg per second at index 0, in kg / 100 km at index 1
	 */
	public double[] getMultipleCo2Emissions(double v, double fuelFlow) {
		double[] result = new double[2];

		// CO2 in kg/s
		result[0] = getCO2EmissionsInKgPerS(fuelFlow);

		// CO2 in kg/100km
		result[1] = result[0] / 1000 * 1e8 / Math.max(v, 0.001);
		return result;
	}

	@Override
	public abstract String getName();
}
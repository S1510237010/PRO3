package at.fhhagenberg.mc.traffsim.vehicle;

import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;

public class VehicleInJunction implements Comparable<VehicleInJunction> {
	Vehicle vehicle;
	VehiclesLane sourceLane;
	VehiclesLane destinationLane;
	JunctionConnector junctionConnector;
	private double distanceToJunction;

	public VehicleInJunction(Vehicle vehicle, VehiclesLane sourceLane, VehiclesLane destinationLane, JunctionConnector junctionConnector,
			double distance) {
		super();
		this.vehicle = vehicle;
		this.sourceLane = sourceLane;
		this.destinationLane = destinationLane;
		this.junctionConnector = junctionConnector;
		this.distanceToJunction = distance;
	}

	/**
	 * @return the vehicle
	 */
	public Vehicle getVehicle() {
		return vehicle;
	}

	/**
	 * @param vehicle
	 *            the vehicle to set
	 */
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	/**
	 * @return the sourceLane
	 */
	public VehiclesLane getSourceLane() {
		return sourceLane;
	}

	/**
	 * @param sourceLane
	 *            the sourceLane to set
	 */
	public void setSourceLane(VehiclesLane sourceLane) {
		this.sourceLane = sourceLane;
	}

	/**
	 * @return the destinationLane
	 */
	public VehiclesLane getDestinationLane() {
		return destinationLane;
	}

	/**
	 * @param destinationLane
	 *            the destinationLane to set
	 */
	public void setDestinationLane(VehiclesLane destinationLane) {
		this.destinationLane = destinationLane;
	}

	/**
	 * @return the junctionConnector
	 */
	public JunctionConnector getJunctionConnector() {
		return junctionConnector;
	}

	/**
	 * @param junctionConnector
	 *            the junctionConnector to set
	 */
	public void setJunctionConnector(JunctionConnector junctionConnector) {
		this.junctionConnector = junctionConnector;
	}

	@Override
	public int compareTo(VehicleInJunction o) {
		return vehicle.compareTo(o.vehicle);
	}

	public double getDistanceToJunction() {
		return distanceToJunction;
	}

	public void setDistanceToJunction(double distanceToJunction) {
		this.distanceToJunction = distanceToJunction;
	}

	@Override
	public String toString() {
		return String.format("v#%d (%s) | %s -> %s | d: %.2f\n", vehicle.getUniqueId(), vehicle.getLabel(), sourceLane.toString(),
				destinationLane.toString(), distanceToJunction);
	}
}

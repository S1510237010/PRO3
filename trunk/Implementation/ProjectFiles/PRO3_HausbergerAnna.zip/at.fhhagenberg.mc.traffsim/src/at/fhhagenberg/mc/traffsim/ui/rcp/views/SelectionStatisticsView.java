package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider;
import org.csstudio.swt.xygraph.dataprovider.IDataProvider;
import org.csstudio.swt.xygraph.dataprovider.Sample;
import org.csstudio.swt.xygraph.figures.Axis;
import org.csstudio.swt.xygraph.figures.Trace;
import org.csstudio.swt.xygraph.figures.Trace.TraceType;
import org.csstudio.swt.xygraph.figures.XYGraph;
import org.csstudio.swt.xygraph.linearscale.AbstractScale.LabelSide;
import org.csstudio.swt.xygraph.util.XYGraphMediaFactory;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.communication.IChannelModel;
import at.fhhagenberg.mc.traffsim.model.IItemSelectionListener;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.ui.UiConstants;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.util.ChartUtil;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.vehicle.CommVehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.AbstractModel;

public class SelectionStatisticsView extends BaseTableViewerView implements IModelInputChangedListener, IItemSelectionListener {
	private static final String N_A_COMMUNICATION_DISABLED = "N/A (communication disabled)";
	private static final String RECORDING_DISABLED = "N/A (detailed recording disabled)";
	/** view id as defined in manifest */
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.statistics.selection";
	private SimulationModel currentModel;
	private XYGraph graph;
	private CircularBufferDataProvider fuelProvider;
	private CircularBufferDataProvider speedProvider;
	private Axis y2Axis;
	private CircularBufferDataProvider speedProviderOthers;
	private CircularBufferDataProvider fuelProviderOthers;
	private Composite vehiclesComposite;

	private class SelectionStatisticsComparator extends BaseViewerComparator {
		@Override
		public int compare(Viewer viewer, Object e1, Object e2) {
			if (!viewer.equals(SelectionStatisticsView.this.viewer)) {
				return 0;
			}

			int rc = 0;

			ILabelProvider labelProvider = (ILabelProvider) SelectionStatisticsView.this.viewer.getLabelProvider(propertyIndex);
			String t1 = labelProvider.getText(e1);
			String t2 = labelProvider.getText(e2);

			if (t1 == null) {
				t1 = "";
			}

			if (t2 == null) {
				t2 = "";
			}

			rc = t1.compareTo(t2);

			// If descending order, flip the direction
			if (direction == DESCENDING) {
				rc = -rc;
			}

			return rc;
		}
	}

	@Override
	public void createPartControl(Composite parent) {

		SashForm container = new SashForm(parent, SWT.SMOOTH);

		vehiclesComposite = new Composite(container, SWT.NONE);
		vehiclesComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		GridLayout gl_vehiclesComposite = new GridLayout(2, false);
		gl_vehiclesComposite.marginHeight = 0;
		gl_vehiclesComposite.verticalSpacing = 0;
		vehiclesComposite.setLayout(gl_vehiclesComposite);

		Label lblSelectedVehicles = new Label(vehiclesComposite, SWT.NONE);
		lblSelectedVehicles.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		lblSelectedVehicles.setText("Selected vehicles");

		comparator = new SelectionStatisticsComparator();
		viewer = createTableViewer(vehiclesComposite);
		viewer.setComparator(comparator);

		// Layout the viewer
		GridData gridData = new GridData();
		gridData.verticalAlignment = GridData.FILL;
		gridData.grabExcessHorizontalSpace = true;
		gridData.grabExcessVerticalSpace = true;
		gridData.horizontalAlignment = GridData.FILL;
		viewer.getControl().setLayoutData(gridData);

		Table table = viewer.getTable();
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		getViewSite().setSelectionProvider(viewer);
		new Label(vehiclesComposite, SWT.NONE);
		new Label(vehiclesComposite, SWT.NONE);

		Composite overallComposite = new Composite(container, SWT.NONE);
		overallComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		overallComposite.setLayout(new GridLayout(1, false));

		Canvas canvas = new Canvas(overallComposite, SWT.NONE);
		canvas.setLayout(new GridLayout(1, false));
		canvas.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		final LightweightSystem lws = new LightweightSystem(canvas);
		container.setWeights(new int[] { 5, 2 });
		graph = new XYGraph();
		graph.setTitle("");
		org.eclipse.swt.graphics.Color neutralColor = getViewSite().getShell().getDisplay().getSystemColor(SWT.COLOR_WIDGET_BACKGROUND);
		graph.primaryXAxis.getScaleTickLabels().setForegroundColor(neutralColor);
		graph.primaryXAxis.getScaleTickMarks().setForegroundColor(neutralColor);
		graph.primaryXAxis.setScaleLineVisible(false);
		graph.primaryYAxis.setTitle("speed [m/s]");
		graph.primaryYAxis.setShowMajorGrid(true);
		graph.primaryXAxis.setRange(0.5, 4.5);
		graph.primaryXAxis.setDateEnabled(false);
		graph.primaryYAxis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_BLUE));
		graph.primaryXAxis.setTitleFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.ITALIC));
		graph.primaryXAxis.setTitle("");
		lws.setContents(graph);
		speedProvider = ChartUtil.createDataProvider(4, IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL);
		speedProviderOthers = ChartUtil.createDataProvider(1, IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL);
		Trace spdTrace = createTrace("Speed (selected)", graph.primaryXAxis, graph.primaryYAxis, speedProvider,
				XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_BLUE));
		Trace spdTraceOthers = createTrace("Speed (others)", graph.primaryXAxis, graph.primaryYAxis, speedProviderOthers,
				XYGraphMediaFactory.getInstance().getColor(UiConstants.COLOR_LIGHT_BLUE));
		y2Axis = new Axis("fuel [l]", true);
		y2Axis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(UiConstants.COLOR_DARK_ORANGE));
		y2Axis.setTickLableSide(LabelSide.Secondary);
		graph.addAxis(y2Axis);

		fuelProvider = ChartUtil.createDataProvider(4, IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL);
		fuelProviderOthers = ChartUtil.createDataProvider(4, IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL);
		Trace fuelTrace = createTrace("Fuel (selected)", graph.primaryXAxis, y2Axis, fuelProvider,
				XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_ORANGE));
		Trace fuelTraceOthers = createTrace("Fuel (others)", graph.primaryXAxis, y2Axis, fuelProviderOthers,
				XYGraphMediaFactory.getInstance().getColor(UiConstants.COLOR_LIGHT_ORANGE));
		graph.addTrace(spdTrace);
		graph.addTrace(spdTraceOthers);
		graph.addTrace(fuelTrace);
		graph.addTrace(fuelTraceOthers);
	}

	private Trace createTrace(String title, Axis xAxis, Axis yAxis, IDataProvider provider, Color color) {
		Trace tr = new Trace(title, xAxis, yAxis, provider);
		tr.setTraceType(TraceType.BAR);
		tr.setLineWidth(30);
		tr.setTraceColor(color);
		tr.setAreaAlpha(100);
		tr.setPointSize(10);
		tr.setErrorBarEnabled(true);
		tr.setErrorBarCapWidth(7);
		return tr;
	}

	private TableViewer createTableViewer(Composite parent) {

		Composite selectionControls = new Composite(vehiclesComposite, SWT.NONE);
		selectionControls.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, true, false, 1, 1));
		GridLayout gl_selectionControls = new GridLayout(4, false);
		gl_selectionControls.verticalSpacing = 0;
		selectionControls.setLayout(gl_selectionControls);

		final Button btnShowSelection = new Button(selectionControls, SWT.CHECK);
		btnShowSelection.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (currentModel != null) {
					currentModel.getUiModel().showSelectedArea(btnShowSelection.getSelection());
				}
			}
		});
		btnShowSelection.setText("Show selection");

		Button btnSelectAll = new Button(selectionControls, SWT.NONE);
		btnSelectAll.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (currentModel != null) {
					currentModel.getUiModel().selectAll();
				}
			}
		});
		btnSelectAll.setText("Select all");

		Button btnClear = new Button(selectionControls, SWT.NONE);
		btnClear.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (currentModel != null) {
					currentModel.getUiModel().selectArea(new Rectangle());
				}
			}
		});
		btnClear.setText("Clear");

		Button btnRefresh = new Button(selectionControls, SWT.NONE);
		btnRefresh.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				currentModel.getUiModel().selectArea(null);
			}
		});
		btnRefresh.setText("Refresh");
		TableViewer tv = new TableViewer(parent, SWT.BORDER | SWT.FULL_SELECTION);
		tv.setContentProvider(new ArrayContentProvider());
		int colIndex = 0;

		TableViewerColumn colVehicleId = createTableViewerColumn(tv, "ID", 40, colIndex++);
		colVehicleId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return v.getLabel() + "";
			}
		});

		TableViewerColumn colSpeed = createTableViewerColumn(tv, "Speed [m/s]", 70, colIndex++);
		colSpeed.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return String.format("%.3f", v.getCurrentSpeed());
			}
		});

		TableViewerColumn colSpeedKmh = createTableViewerColumn(tv, "Speed [km/h]", 70, colIndex++);
		colSpeedKmh.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return String.format("%.3f", v.getCurrentSpeed() * 3.6);
			}
		});

		TableViewerColumn colAverageSpeed = createTableViewerColumn(tv, "� speed [km/h]", 70, colIndex++);
		colAverageSpeed.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (currentModel != null && currentModel.getStatistics() != null) {
					Vehicle v = (Vehicle) element;
					return currentModel.getStatistics().getVehicleStats().containsKey(v.getUniqueId())
							? String.format("%.3f", currentModel.getStatistics().getVehicleStats().get(v.getUniqueId()).getAvgSpeed() * 3.6)
							: RECORDING_DISABLED;
				}

				return "-";
			}
		});

		TableViewerColumn colTargetSpeed = createTableViewerColumn(tv, "Target speed [km/h]", 70, colIndex++);
		colTargetSpeed.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return String.format("%.3f", v.getTargetSpeed() * 3.6);
			}
		});

		TableViewerColumn colFuelConsumed = createTableViewerColumn(tv, "Fuel consumed [l]", 70, colIndex++);
		colFuelConsumed.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return String.format("%.3f", v.getFuelConsumed());
			}
		});

		TableViewerColumn colDistTravelled = createTableViewerColumn(tv, "Distance travelled [m]", 70, colIndex++);
		colDistTravelled.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return String.format("%.3f", v.getTravelDistance());
			}
		});

		TableViewerColumn colAverageFuelConsumed = createTableViewerColumn(tv, "� fuel [l/100km]", 70, colIndex++);
		colAverageFuelConsumed.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (currentModel != null && currentModel.getStatistics() != null) {
					Vehicle v = (Vehicle) element;
					return currentModel.getStatistics().getVehicleStats().containsKey(v.getUniqueId())
							? String.format("%.3f",
									currentModel.getStatistics().getVehicleStats().get(v.getUniqueId()).getAvgFuelConsumptionPer100km())
							: RECORDING_DISABLED;
				}

				return "-";
			}
		});

		TableViewerColumn colVType = createTableViewerColumn(tv, "Type", 50, colIndex++);
		colVType.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return v.getType().toString();
			}
		});

		TableViewerColumn colLaneChangeModel = createTableViewerColumn(tv, "Lane-Change Model", 80, colIndex++);
		colLaneChangeModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return createModelName(v.getLaneChangeModel());
			}
		});

		TableViewerColumn colLongChangeModel = createTableViewerColumn(tv, "Longitudinal Model", 80, colIndex++);
		colLongChangeModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return createModelName(v.getLongitudinalControl());
			}
		});

		TableViewerColumn colFuelModel = createTableViewerColumn(tv, "Fuel Consumption Model", 80, colIndex++);
		colFuelModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return createModelName(v.getConsumptionModel());
			}
		});

		TableViewerColumn colMemory = createTableViewerColumn(tv, "Memory", 45, colIndex++);
		colMemory.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return v.getMemory() == null ? "no" : "yes";
			}
		});

		TableViewerColumn colcolState = createTableViewerColumn(tv, "State", 45, colIndex++);
		colcolState.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Vehicle v = (Vehicle) element;
				return v.getState().name();
			}
		});

		TableViewerColumn colChannelModel = createTableViewerColumn(tv, "Demand CH Model", 80, colIndex++);
		colChannelModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (element instanceof CommVehicle) {
					String modelId = PropertyUtil.getStringProperty(currentModel.getSimulationParameters(),
							PropertyKeys.DEMAND_CHANNEL_MODEL_IDENTIFIER, "");
					return currentModel.getModelRegistry().getModel(modelId, IChannelModel.class).toString();
				}
				return N_A_COMMUNICATION_DISABLED;
			}
		});

		TableViewerColumn colContChannelModel = createTableViewerColumn(tv, "Continuous CH Model", 80, colIndex++);
		colContChannelModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (element instanceof CommVehicle) {
					String modelId = PropertyUtil.getStringProperty(currentModel.getSimulationParameters(),
							PropertyKeys.CONTINUOUS_CHANNEL_MODEL_IDENTIFIER, "");
					return currentModel.getModelRegistry().getModel(modelId, IChannelModel.class).toString();
				}
				return N_A_COMMUNICATION_DISABLED;
			}
		});

		comparator.setColumn(0);
		comparator.direction = SWT.DOWN;
		return tv;
	}

	private String createModelName(AbstractModel model) {
		return model == null ? "<none>" : model.getName();
	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
		}

		if (newModel != null) {
			newModel.addItemSelectionListener(this);
			updateView(newModel.getSelectedVehicles());
		}

		currentModel = newModel;
	}

	@Override
	public void dispose() {
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
			currentModel = null;
		}
		
		super.dispose();
	}

	private void updateView(List<Vehicle> items) {
		if (items == null) {
			return;
		}
		final Map<Long, Vehicle> vehicles = new HashMap<>();
		final List<Double> speeds = new ArrayList<>();
		final List<Double> fuels = new ArrayList<>();
		final List<Double> speedsOthers = new ArrayList<>();
		final List<Double> fuelsOthers = new ArrayList<>();

		for (Vehicle v : items) {
			vehicles.put(v.getUniqueId(), v);
			speeds.add(v.getCurrentSpeed());
			fuels.add(v.getFuelConsumed());
		}

		if (currentModel != null) {
			List<Long> otherVehicleIds = currentModel.getSimObserver().getVehiclesInSimulation().stream().map(Vehicle::getUniqueId)
					.collect(Collectors.toList());
			otherVehicleIds.removeAll(vehicles.keySet());
			for (Long id : otherVehicleIds) {
				Vehicle v = currentModel.getSimObserver().getVehicleById(id);
				speedsOthers.add(v.getCurrentSpeed());
				fuelsOthers.add(v.getFuelConsumed());
			}
		}

		final double[] avgStdSpeed = NumberUtil.average(speeds);
		final double[] avgStdFuel = NumberUtil.average(fuels);
		final double[] avgStdSpeedOthers = NumberUtil.average(speedsOthers);
		final double[] avgStdFuelOthers = NumberUtil.average(fuelsOthers);
		if (getViewSite() != null) {
			getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					viewer.setInput(vehicles.values());
					speedProvider.clearTrace();
					speedProvider.addSample(new Sample(1, avgStdSpeed[0], avgStdSpeed[1], avgStdSpeed[1], 0, 0));
					speedProviderOthers.clearTrace();
					speedProviderOthers.addSample(new Sample(2, avgStdSpeedOthers[0], avgStdSpeedOthers[1], avgStdSpeedOthers[1], 0, 0));

					graph.primaryYAxis.setRange(0,
							(int) (Math.ceil(
									Math.max(speedProvider.getYDataMinMax().getUpper(), speedProviderOthers.getYDataMinMax().getUpper()))
									* 1.05));
					fuelProvider.clearTrace();
					fuelProvider.addSample(new Sample(3, avgStdFuel[0], avgStdFuel[1], avgStdFuel[1], 0, 0));
					fuelProviderOthers.clearTrace();
					fuelProviderOthers.addSample(new Sample(4, avgStdFuelOthers[0], avgStdFuelOthers[1], avgStdFuelOthers[1], 0, 0));
					y2Axis.setRange(0,
							(Math.ceil(Math.max(fuelProvider.getYDataMinMax().getUpper(), fuelProviderOthers.getYDataMinMax().getUpper()))
									* 1.05));
					graph.primaryXAxis.setTitle(String.format("%.2f m/s        %.2f m/s       %.2f l         %.2f l   ", avgStdSpeed[0],
							avgStdSpeedOthers[0], avgStdFuel[0], avgStdFuelOthers[0]));
				}
			});
		}
	}

	@Override
	public void itemsSelected(List<AbstractJunction> junctions, List<JunctionConnector> connectors, List<RoadSegment> roadSegments,
			List<LaneSegment> laneSegments, List<Vehicle> vehicles) {
		if (!vehicles.isEmpty()) {
			updateView(vehicles);
		}
	}

	@Override
	protected BaseViewerComparator createComparator() {
		SelectionStatisticsComparator comparator = new SelectionStatisticsComparator();
		return comparator;
	}
}

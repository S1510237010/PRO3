package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.osm2po.libs.TraffSimLibsPlugin;
import at.fhhagenberg.mc.traffsim.data.RCPClassPathProvider;
import at.fhhagenberg.mc.traffsim.data.TraffSimDataPlugin;
import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.BaseRoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.osmimport.ImportWizard;
import at.fhhagenberg.mc.util.OsUtil;
import at.fhhagenberg.mc.util.StringUtil;
import at.fhhagenberg.mc.util.UtilPlugin;
import de.cm.osm2po.Main;

public class ImportOsmCommand implements IHandler {

	/** prefix after which the task name comes */
	private static final String OSM2PO_OUTPUT_TASK_KEYWORD = "Starting ";
	private static final int OSM2PO_PREFIX_LENGTH = 7;
	private static final String OSM2PO_GRAPH_FILE_NAME = "osm_2po.gph";

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		ImportWizard wizard = new ImportWizard();
		WizardDialog dialog = new WizardDialog(Display.getCurrent().getActiveShell(), wizard);
		int result = dialog.open();
		if (result == Dialog.CANCEL) {
			return null;
		}

		String separator = OsUtil.getClassPathSeparator();

		RCPClassPathProvider osmCpProv = new RCPClassPathProvider(TraffSimLibsPlugin.PLUGIN_ID, RCPClassPathProvider.LIB_FOLDER, "*.jar", true,
				separator);
		String osmClasspath = osmCpProv.getClassPath();
		osmClasspath += separator + new RCPClassPathProvider(TraffSimDataPlugin.PLUGIN_ID, "/", ".", false, separator).getClassPath();
		osmClasspath += separator + new RCPClassPathProvider(TraffSimDataPlugin.PLUGIN_ID, "/", "target/classes", false, separator).getClassPath();
		osmClasspath += separator + new RCPClassPathProvider(UtilPlugin.PLUGIN_ID, "/", ".", false, separator).getClassPath();

		final TraffSimConfiguration config = wizard.getTraffsimConfiguration();
		final File configFolder = config.getConfigurationFile().getParentFile();
		final File osm2poWorking = new File(configFolder, "osm2po_working");
		List<File> toDelete = new ArrayList<>();
		toDelete.add(new File(configFolder, StringUtil.ensureNotNull(config.getGraphFile())));
		toDelete.add(new File(configFolder, StringUtil.ensureNotNull(config.getFilenameFor(BaseRoadSegmentBean.class.getCanonicalName()))));
		toDelete.add(new File(configFolder, StringUtil.ensureNotNull(config.getFilenameFor(InfrastructureBean.class.getCanonicalName()))));
		toDelete.add(new File(configFolder, StringUtil.ensureNotNull(config.getFilenameFor(VehicleBean.class.getCanonicalName()))));
		toDelete.add(new File(configFolder, StringUtil.ensureNotNull(config.getFilenameFor(RouteBean.class.getCanonicalName()))));
		for (File f : toDelete) {
			if (f.exists() && f.isFile()) {
				f.delete();
			}
		}
		osm2poWorking.mkdirs();
		List<String> argList = new ArrayList<>();
		argList.add("java");
		argList.add("-cp");
		argList.add(osmClasspath);
		argList.add(Main.class.getName());
		argList.add("workDir=" + osm2poWorking.getAbsolutePath());
		argList.add(new File(configFolder, config.getOsmNetworkFile()).getAbsolutePath());
		argList.add("wayTagResolver.class=at.fhhagenberg.mc.osm2po.ext.LaneWayTagResolver");
		argList.add("cmd=tjsgp");
		argList.add("osm2poWaysFile=" + new File(osm2poWorking, "sw_all.2po").getAbsolutePath());
		argList.add("postp.0.class=at.fhhagenberg.mc.osm2po.ext.TraffSimGeometryWriter");
		argList.add("traffSimConfigFile=" + config.getConfigurationFile().getAbsolutePath());
		try {
			URL fileURL = Main.class.getProtectionDomain().getCodeSource().getLocation();
			File configFile = new File(new File(new URI(StringUtil.ensureURICompatible(fileURL.toString()))).getParent(), "osm2po.config");
			if (configFile.exists()) {
				argList.add("config=" + configFile.getAbsolutePath());
			}

		} catch (URISyntaxException e) {
			Logger.logWarn("OSm2po config file not found. Using default configuration.");
		}
		final String[] args = argList.toArray(new String[] {});
		Logger.logInfo(Arrays.toString(args));
		Job job = new Job("Importing OSM") {

			@Override
			protected IStatus run(IProgressMonitor monitor) {
				try {
					// delete old graph file beforehand
					File oldGraph = new File(configFolder, config.getGraphFile());
					if (oldGraph.exists()) {
						oldGraph.delete();
					}
					String[] oldData = new String[] { RouteBean.class.getCanonicalName(), VehicleBean.class.getCanonicalName(),
							InfrastructureBean.class.getCanonicalName() };
					for (String className : oldData) {
						if (config.getBeanConfigurationsMapping().containsKey(className)) {
							File oldFile = new File(configFolder, config.getBeanConfigurationsMapping().get(className).getFileName());
							if (oldFile.exists()) {
								oldFile.delete();
							}
						}
					}
					// create process
					Process proc = Runtime.getRuntime().exec(args, null, osm2poWorking);
					Logger.logInfo(
							String.format("Executing the following command:\n%s", Arrays.toString(args).replaceAll("\\[", "").replaceAll(",", "")));
					BufferedReader input = new BufferedReader(new InputStreamReader(proc.getInputStream()));
					String line;
					while ((line = input.readLine()) != null) {
						if (line.contains(OSM2PO_OUTPUT_TASK_KEYWORD)) {
							int taskStartIndex = line.indexOf(OSM2PO_OUTPUT_TASK_KEYWORD) + OSM2PO_OUTPUT_TASK_KEYWORD.length();
							int endIndex = line.indexOf(' ', taskStartIndex);
							monitor.beginTask(line.substring(taskStartIndex, endIndex), 100);
						}
						monitor.subTask(line.length() > OSM2PO_PREFIX_LENGTH ? line.substring(OSM2PO_PREFIX_LENGTH) : line);
						Logger.logInfo(line);
						monitor.worked(1);
					}
					input.close();
					// copy graph file
					File graph = new File(osm2poWorking, OSM2PO_GRAPH_FILE_NAME);
					if (graph.exists()) {
						String graphFileName = StringUtil.isNullOrEmpty(config.getGraphFile()) ? OSM2PO_GRAPH_FILE_NAME : config.getGraphFile();
						monitor.subTask("Rename graph file to " + graphFileName);
						File newFile = new File(configFolder, graphFileName);
						newFile.delete();
						graph.renameTo(newFile);
					} else {
						return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, "Error moving graph file to " + config.getGraphFile());
					}
				} catch (IOException e1) {
					return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, "Could not import from OSM. " + e1.getMessage());
				}
				return Status.OK_STATUS;
			}
		};
		job.setUser(true);
		job.schedule();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

}

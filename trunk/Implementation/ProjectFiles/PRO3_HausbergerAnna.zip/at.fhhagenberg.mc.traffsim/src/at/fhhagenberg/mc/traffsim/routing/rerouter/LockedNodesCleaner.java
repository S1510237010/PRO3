package at.fhhagenberg.mc.traffsim.routing.rerouter;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;

/**
 * Cleanup of locked nodes: Congested nodes are remembered in a {@link Map}. This thread cleans up the map as soon as the simulation time
 * propagates to a time after the predicted congestion
 * 
 * @author Christian Backfrieder
 *
 */
public class LockedNodesCleaner extends PauseableThread implements ISimulationStateListener {

	private Map<Long, Map<Date, AbstractJunction>> lockedNodes;
	private SimulationModel model;

	public LockedNodesCleaner(String name, long delayInMillis, Map<Long, Map<Date, AbstractJunction>> lockedNodes, SimulationModel model) {
		super(name, delayInMillis);
		this.lockedNodes = lockedNodes;
		this.model = model;
		model.addSimulationStateListener(this);
	}

	@Override
	public void doWork() {
		for (Iterator<Map<Date, AbstractJunction>> it1 = lockedNodes.values().iterator(); it1.hasNext();) {
			Map<Date, AbstractJunction> lockedNode = it1.next();
			for (Iterator<Date> it2 = lockedNode.keySet().iterator(); it2.hasNext();) {
				Date dt = it2.next();
				// check if congestion was predicted before the current simulation time. if yes - remove
				if (dt.before(model.getCurrentSimTime())) {
					it2.remove();
				}
			}
			//also removed empty mappings of date to junction
			if (lockedNode.isEmpty()) {
				it1.remove();
			}
		}
	}

	@Override
	public void simulationStateChanged(SimulationModel model, SimulationState oldState, SimulationState newState) {
		if (SimulationState.isSimulationRunningAfter(newState)) {
			proceed();
		} else {
			pause();
		}
	}

	@Override
	protected void preStop() {
		model.removeSimulationStateListener(this);
	}

}

package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.optim.InitialGuess;
import org.apache.commons.math3.optim.MaxEval;
import org.apache.commons.math3.optim.PointValuePair;
import org.apache.commons.math3.optim.SimpleValueChecker;
import org.apache.commons.math3.optim.linear.LinearConstraint;
import org.apache.commons.math3.optim.linear.LinearConstraintSet;
import org.apache.commons.math3.optim.linear.LinearObjectiveFunction;
import org.apache.commons.math3.optim.linear.Relationship;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction;
import org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex;
import org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer;
import org.apache.commons.math3.optim.univariate.BrentOptimizer;
import org.apache.commons.math3.optim.univariate.SearchInterval;
import org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction;
import org.apache.commons.math3.optim.univariate.UnivariatePointValuePair;

import com.google.common.collect.Iterables;
import com.google.common.primitives.Doubles;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.SelfOrganizingControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightControllerBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.SelfOrganizingControlLogic;
import at.fhhagenberg.mc.traffsim.statistics.IStatsConstants;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;

/**
 * Implementation of a traffic light controller realizing a self-organizing control scheme. Traffic lights at the intersection are operated
 * under consideration of queue lengths monitored in the individual approaches. A stabilization mechanism ensures that all approaches are
 * operated in a given maximum cycle length.
 *
 * @author Manuel Lindorfer / Hannes Markschl�ger
 *
 */
public class SelfOrganizingController extends TrafficLightController<SelfOrganizingControlLogic> {

	private static final long DEFAULT_UPDATE_INTERVAL = 5000;
	private static final long DEFAULT_TARGET_CYCLE_LENGTH = 120000;
	private static final long DEFAULT_MAX_CYCLE_LENGTH = 180000;

	public enum Mode {
		PI_ONLY(0, "PI non-stabilizing GTE"), PI_STABILIZER(1, "PI stabilizing GTE"), PI_ONLY_NO_EXT(2, "PI non-stabilizing"), PI_STABILIZER_NO_EXT(3,
				"PI stabilizing");

		private int id;
		private String description;

		private Mode(int id, String description) {
			this.id = id;
			this.description = description;
		}

		public int getId() {
			return id;
		}

		public String getDescription() {
			return description;
		}

		public static Mode getModeById(final int id) {
			for (Mode m : Mode.values()) {
				if (m.id == id) {
					return m;
				}
			}

			return null;
		}

		public static Mode getModeByLabel(final String label) {
			for (Mode m : Mode.values()) {
				if (m.description.compareTo(label) == 0) {
					return m;
				}
			}

			return null;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	private long updateInterval;
	private long maxCycleLength;
	private long targetCycleLength;
	private boolean useHeuristics = false;
	private boolean isStabilizing = false;

	private long lastUpdate;
	private Mode mode;
	private SelfOrganizingControlLogic servicedLane;
	private Queue<SelfOrganizingControlLogic> serviceQueue;

	public SelfOrganizingController(long id, AbstractJunction junction) {
		super(id, junction);
		this.mode = Mode.PI_STABILIZER;
		this.maxCycleLength = DEFAULT_MAX_CYCLE_LENGTH;
		this.targetCycleLength = DEFAULT_TARGET_CYCLE_LENGTH;
		this.updateInterval = DEFAULT_UPDATE_INTERVAL;
		this.serviceQueue = new ArrayDeque<>(junction.getApproaches().size());
	}

	public SelfOrganizingController(long id, AbstractJunction junction, Mode mode, long maxCycleLength, long targetCycleLength, long updateInterval) {
		super(id, junction);
		this.mode = mode;
		this.maxCycleLength = maxCycleLength;
		this.targetCycleLength = targetCycleLength;
		this.updateInterval = updateInterval;
		this.serviceQueue = new ArrayDeque<>(junction.getApproaches().size());
	}

	public Mode getMode() {
		return mode;
	}

	public void setMode(Mode mode) {
		this.mode = mode;
	}

	public long getMaxCycleLength() {
		return maxCycleLength;
	}

	public void setMaxCycleLength(long maxCycleLength) {
		this.maxCycleLength = maxCycleLength;
	}

	public long getTargetCycleLength() {
		return targetCycleLength;
	}

	public void setTargetCycleLength(long targetCycleLength) {
		this.targetCycleLength = targetCycleLength;
	}

	public boolean isStabilizing() {
		return isStabilizing;
	}

	public boolean getUseHeuristics() {
		return useHeuristics;
	}

	public void setUseHeuristics(boolean useHeuristics) {
		this.useHeuristics = useHeuristics;
	}

	public long getUpdateInterval() {
		return updateInterval;
	}

	public void setUpdateInterval(long updateInterval) {
		this.updateInterval = updateInterval;
	}

	@Override
	protected void update(long dt, long simulationRuntime) {
		if (simulationRuntime - lastUpdate >= updateInterval) {
			lastUpdate = simulationRuntime;
			internalUpdate();
		}
	}

	private void internalUpdate() {
		updateStates();

		switch (mode) {
		case PI_ONLY:
		case PI_ONLY_NO_EXT:
			validatePriorityIndex();
			break;
		case PI_STABILIZER:
		case PI_STABILIZER_NO_EXT:
			stabilizeLocally();
			break;
		default:
			break;
		}
	}

	private void stabilizeLocally() {
		for (ControlLogic logic : controlLogics) {
			SelfOrganizingControlLogic socl = (SelfOrganizingControlLogic) logic;

			if (!serviceQueue.contains(socl)) {
				double queueLength = socl.getQueueLengthExpected(socl.getSimualtionTimeInMilliseconds(), socl.getTau());
				double queueLengthCriticalTimeDependent = socl.getQueueLengthCriticalTimeDependent(targetCycleLength, maxCycleLength);

				if (queueLength >= queueLengthCriticalTimeDependent && socl.getQueueMonitor().areVehiclesQueued()) {
					serviceQueue.add(socl);
				}
			}
		}

		for (Iterator<SelfOrganizingControlLogic> iterator = serviceQueue.iterator(); iterator.hasNext();) {
			SelfOrganizingControlLogic socl = iterator.next();

			double queueLength = socl.getQueueLengthExpected(socl.getSimualtionTimeInMilliseconds(), socl.getTau());
			boolean expired = socl.getReleaseTime() >= socl.getReleasePeriod();

			if (NumberUtil.doubleEquals(queueLength, 0) || expired) {
				socl.requestChange(false);
				iterator.remove();
				continue;
			}
		}

		if (!serviceQueue.isEmpty()) {
			SelfOrganizingControlLogic peek = serviceQueue.peek();
			if (!peek.isServiced()) {
				performSwitch(peek);
				isStabilizing = true;
			}
		} else {
			validatePriorityIndex();
			isStabilizing = false;
		}
	}

	void updateMinReleaseHeuristic() {
		int order = junction.getApproaches().size();
		ArrayList<Double> targetCoeff = new ArrayList<>(order);
		ArrayList<Double> initialSolution = new ArrayList<>(order);
		ArrayList<LinearConstraint> constraints = new ArrayList<>(order + 1);
		LinearConstraint c;
		double sumTau0 = 0;
		double cycle_idle = getControlLogicsAsStream().mapToDouble(x -> x.getAverageLoad() * targetCycleLength + x.getTau0()).sum();
		cycle_idle = targetCycleLength - cycle_idle;

		for (ControlLogic strategy : controlLogics) {
			SelfOrganizingControlLogic sso = (SelfOrganizingControlLogic) strategy;
			// eq 5.16
			c = new LinearConstraint(new double[] { 1 }, Relationship.GEQ, sso.getAverageLoad() * targetCycleLength);
			constraints.add(c);
			// eq 5.17
			double upperBound = calcMinReleaseSimplified(sso, cycle_idle);
			c = new LinearConstraint(new double[] { 1 }, Relationship.LEQ, upperBound);
			constraints.add(c);
			sumTau0 += sso.getTau0();
			targetCoeff.add(sso.getQmax());
			initialSolution.add(upperBound);
		}
		double[] d = new double[order];
		Arrays.fill(d, 1);
		// eq 5.18
		c = new LinearConstraint(d, Relationship.LEQ, targetCycleLength - sumTau0);
		constraints.add(c);
		// eq 5.19
		ObjectiveFunction target = new ObjectiveFunction(new LinearObjectiveFunction(Doubles.toArray(targetCoeff), 0.0));
		SimplexOptimizer simplex = new SimplexOptimizer(new SimpleValueChecker(-1, 1));
		PointValuePair optimize = simplex.optimize(new MaxEval(50), //
				new InitialGuess(Doubles.toArray(initialSolution)), //
				target, //
				new LinearConstraintSet(constraints), //
				GoalType.MAXIMIZE, //
				new NelderMeadSimplex(order));
		double[] key = optimize.getKey();
		Iterator<? extends ControlLogic> iterator = controlLogics.iterator();
		for (double e : key) {
			SelfOrganizingControlLogic next = (SelfOrganizingControlLogic) iterator.next();
			next.setReleasePeriod(e);
		}
	}

	/**
	 * eq 5.20
	 */
	private void updateMinReleaseSimplified() {
		double cycleReal = targetCycleLength;
		double cycle_idle = getControlLogicsAsStream().mapToDouble(x -> x.getAverageLoad() * cycleReal + x.getTau0()).sum();
		cycle_idle = cycleReal - cycle_idle;
		for (ControlLogic logic : controlLogics) {
			SelfOrganizingControlLogic socl = (SelfOrganizingControlLogic) logic;
			double val = calcMinReleaseSimplified(socl, cycle_idle);
			socl.setReleasePeriod(val);
		}
	}

	private void updateStates() {
		if (useHeuristics) {
			updateMinReleaseHeuristic();
		} else {
			updateMinReleaseSimplified();
		}

		getControlLogicsAsStream().forEach(n -> {
			switch (mode) {
			case PI_STABILIZER_NO_EXT:
			case PI_ONLY_NO_EXT:
				updatePriorityIndexNoExtension(n);
				break;
			case PI_ONLY:
			case PI_STABILIZER:
				updatePriorityIndex(n);
				break;
			default:
				break;
			}
		});
	}

	/**
	 * eq 4.17
	 *
	 * @param n
	 */
	private void updatePriorityIndexNoExtension(SelfOrganizingControlLogic str) {
		double pi = 0;

		if (str.isServiced()) {
			double n = str.getQueueMonitor().getQueueLength();
			double g = n / str.getQmax();
			pi = n / (str.getTau() + g);
		} else {
			double n = str.getQueueMonitor().getQueueLength();
			double g = n / str.getQmax();
			double denom = servicedLane != null ? servicedLane.getTau0() - servicedLane.getTau() : 0;
			denom += str.getTau0() + g;
			pi = n / denom;
		}

		if (Double.isNaN(pi)) {
			pi = 0;
		}

		pi = MathUtil.clamp(pi, 0, str.getQmax());
		str.setPriorityIndex(pi);
	}

	/**
	 * eq 4.35
	 *
	 * @param socl
	 */
	private void updatePriorityIndex(SelfOrganizingControlLogic socl) {
		double pi = 0;
		UnivariateFunction f = null;
		UnivariatePointValuePair optimize = null;
		long time = socl.getSimualtionTimeInMilliseconds();

		if (socl.isServiced()) {
			f = x -> {
				double qMax = socl.getQmax();
				long tau = Math.round(x);
				long t = time;
				double calcClearingTime = socl.calcClearingTime(t, tau);
				double nom = calcClearingTime * qMax;
				double denom = calcClearingTime;
				denom += tau;

				if (denom == 0) {
					return 0;
				}

				return nom / denom;
			};

			BrentOptimizer optimizer = new BrentOptimizer(0.0001, 0.001);
			optimize = optimizer.optimize(new MaxEval((int) Math.round(socl.getTau0() / 50.0)), new UnivariateObjectiveFunction(f), GoalType.MAXIMIZE,
					new SearchInterval(socl.getTau(), socl.getTau0()));
			pi = optimize.getValue();
		} else {
			double clearingTime = socl.calcClearingTime(time, socl.getTau0());
			double num = clearingTime * socl.getQmax();
			double denom = servicedLane != null ? servicedLane.getTauSwitchingPenalty() : 0;
			denom += socl.getTau0();
			denom += clearingTime;
			pi = num / denom;

			if (Double.isNaN(pi)) {
				pi = 0;
			}
		}

		pi = MathUtil.clamp(pi, 0, socl.getQmax());
		socl.setPriorityIndex(pi);
	}

	private void validatePriorityIndex() {
		List<SelfOrganizingControlLogic> sorted = getControlLogicsAsStream()
				.sorted(Comparator.comparingDouble(SelfOrganizingControlLogic::getPriorityIndex).reversed()).collect(Collectors.toList());
		SelfOrganizingControlLogic socl = Iterables.getFirst(sorted, null);

		if (socl == null || (socl.equals(servicedLane) && servicedLane.isServiced())) {
			// still highest pi, keep serving
			return;
		}

		double pi_a = socl.getPriorityIndex();

		if (pi_a == 0) {
			return;
		}

		performSwitch(socl);
	}

	/**
	 * eq 5.12
	 *
	 * @return
	 */
	private double calcMinCycle() {
		double result = 0;
		double tau0Sum = 0, loadSum = 0;

		for (ControlLogic logic : controlLogics) {
			SelfOrganizingControlLogic socl = (SelfOrganizingControlLogic) logic;
			tau0Sum += socl.getTau0();
			loadSum += socl.getAverageLoad();
		}

		result = tau0Sum / (1 - loadSum);
		return result;
	}

	/**
	 * eq 5.20
	 *
	 * @param socls
	 * @param cycle_idle
	 * @return
	 */
	private double calcMinReleaseSimplified(SelfOrganizingControlLogic socl, double cycle_idle) {
		double result = socl.getAverageLoad() * targetCycleLength;
		result += cycle_idle * (socl.getQmax() / getControlLogicsAsStream().collect(Collectors.summingDouble(SelfOrganizingControlLogic::getQmax)));
		return result;
	}

	private boolean performSwitch(SelfOrganizingControlLogic lane) {
		if (servicedLane != null && lane.equals(servicedLane) && servicedLane.isServiced()) {
			return false;
		}

		for (ControlLogic logic : controlLogics) {
			SelfOrganizingControlLogic socl = (SelfOrganizingControlLogic) logic;
			boolean equals = socl.equals(lane);
			socl.requestChange(equals);
		}
		servicedLane = lane;
		return true;
	}

	private Stream<SelfOrganizingControlLogic> getControlLogicsAsStream() {
		return StreamSupport.stream(getControlLogics().spliterator(), false);
	}

	@Override
	public TrafficLightControllerBean toBean() {
		SelfOrganizingControllerBean bean = new SelfOrganizingControllerBean();
		bean.setId(id);
		bean.setJunctionId(junction.getId());
		bean.setMode(mode.getId());
		bean.setMaxCycleLength(maxCycleLength);
		bean.setTargetCycleLength(targetCycleLength);
		bean.setUseHeuristics(useHeuristics);
		bean.setUpdateInterval(updateInterval);
		bean.setAreLanesOperatedIndividually(areLanesOperatedIndividually);

		List<ControlLogicBean> controlBeans = new ArrayList<>();

		for (SelfOrganizingControlLogic logic : controlLogics) {
			controlBeans.add(logic.toBean());
		}

		bean.setControlLogic(controlBeans);

		return bean;
	}

	@Override
	public Map<String, Number> obtainStatistics() {
		Map<String, Number> statistics = super.obtainStatistics();

		double cycleLength = 0;

		for (SelfOrganizingControlLogic logic : controlLogics) {
			cycleLength += logic.getReleasePeriod() + logic.getTau0();
		}

		statistics.put(IStatsConstants.CONTROLLER_CYCLE_TIME, cycleLength);
		statistics.put(IStatsConstants.CONTROLLER_STABILIZER_STATE, isStabilizing ? 1d : 0d);
		return statistics;
	}

	@Override
	public TrafficLightControllers getControlMode() {
		return TrafficLightControllers.SELF_ORGANIZING;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers;

/**
 * Container class holding various parameters required for implementing a spatial anticipation mechanism which allows for the consideration
 * of multiple preceding vehicles while carrying out the driving task.
 *
 * @author Manuel Lindorfer
 */
public class SpatialAnticipation {

	/**
	 * Gets a normalization factor which is required for applying the HDM extension to the Intelligent Driver Model (@link IDM). This factor
	 * is based on the number of considered vehicles exclusively.
	 *
	 * @param numConsideredVehicles
	 *            the number of considered preceding vehicles
	 * @return the corresponding normalization factor
	 */
	public static double getNormalizationFactor(int numConsideredVehicles) {
		double normalizationFactor = 0;

		for (int i = 1; i <= numConsideredVehicles; i++) {
			normalizationFactor += 1.0 / Math.pow(i, 2);
		}

		return Math.sqrt(normalizationFactor);
	}

	/** The number of preceding vehicles to be considered */
	private int numConsideredVehicles;

	/** The max. distance to be perceived (looked ahead) by a driver [m] */
	private double sightDistance;

	public SpatialAnticipation() {
		this(0, 0);
	}

	/**
	 * Instantiates a new spatial anticipation parameter set with the given parameters.
	 *
	 * @param numConsideredVehicles
	 *            number of spatially considered vehicles
	 *
	 * @param sightDistance
	 *            the max. sight distance constrained by the limits of human vision
	 */
	public SpatialAnticipation(int numConsideredVehicles, double sightDistance) {
		this.numConsideredVehicles = numConsideredVehicles;
		this.sightDistance = sightDistance;
	}

	/**
	 * Gets the number of considered preceding vehicles.
	 *
	 * @return the number of vehicles
	 */
	public int getNumConsideredVehicles() {
		return numConsideredVehicles;
	}

	/**
	 * Gets the max. distance to be perceived (looked ahead) by the driver.
	 *
	 * @return the max. perception distance
	 */
	public double getSightDistance() {
		return sightDistance;
	}

	/**
	 * Sets the number of considered preceding vehicles.
	 *
	 * @param lookAhead
	 *            the number of vehicles
	 */
	public void setNumConsideredVehicles(int lookAhead) {
		this.numConsideredVehicles = lookAhead;
	}

	/**
	 * Sets the max. distance to be perceived (looked ahead) by the driver.
	 *
	 * @param sightDistance
	 *            the new sight distance
	 */
	public void setSightDistance(double sightDistance) {
		this.sightDistance = sightDistance;
	}
}

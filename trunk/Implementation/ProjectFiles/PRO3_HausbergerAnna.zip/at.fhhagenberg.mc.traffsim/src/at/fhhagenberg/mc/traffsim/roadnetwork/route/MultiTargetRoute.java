package at.fhhagenberg.mc.traffsim.roadnetwork.route;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;

public class MultiTargetRoute extends Route {
	private List<RoadSegment> targets = new ArrayList<>();

	public MultiTargetRoute() {
		super();
	}

	public List<RoadSegment> getTargets() {
		return targets;
	}

	public void setTargets(List<RoadSegment> targets) {
		this.targets = targets;
	}
}

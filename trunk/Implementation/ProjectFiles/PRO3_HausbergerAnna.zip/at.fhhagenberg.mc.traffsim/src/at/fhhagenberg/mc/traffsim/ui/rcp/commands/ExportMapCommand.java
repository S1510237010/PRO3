package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;

public class ExportMapCommand implements IHandler {
	private static final String PDF_SUFFIX = ".pdf";

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

	@Override
	public void dispose() {
		// unused
	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		if (SimulationKernel.getInstance().isModelActive()) {
			FileDialog dialog = new FileDialog(Display.getCurrent().getActiveShell());
			DateFormat f = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			dialog.setFileName(String.format("%s_Map.pdf", f.format(new Date())));
			dialog.setText("Choose export folder");
			dialog.setFilterExtensions(new String[] { "*.pdf" });
			String selected = dialog.open();
			if (!selected.endsWith(PDF_SUFFIX)) {
				selected += PDF_SUFFIX;
			}
			if (selected != null) {
				SimulationKernel.getInstance().getActiveModel().getUiModel().generatePdf(new File(selected));
				MessageDialog.openInformation(Display.getCurrent().getActiveShell(), "Export successful",
						"The current map was exported successfully to folder '" + selected + "'.");
			}
		}
		return null;
	}

	@Override
	public boolean isEnabled() {
		return SimulationKernel.getInstance().isModelActive();
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

}

package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLCell;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;
import com.jmatio.types.MLInt64;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionType;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Outline statistics collector used to obtain various figures, e.g. the number of occurrences, exposure, frequency, average duration, for
 * individual distraction types.
 *
 * @author Manuel Lindorfer
 *
 */
public class DistractionOutlineStatisticsCollector extends BaseStatisticsCollector implements IConvertableStatisticsCollector {

	private static final String DISTRACTIONS_STATISTICS_SUFFIX = ".mat";
	private static final String DISTRACTIONS_VAR_PREFIX = "distractions";

	public DistractionOutlineStatisticsCollector(String name, SimulationModel model, long recordIntervalMillis) {
		super(name, recordIntervalMillis, false);
		this.model = model;
		if (recordIntervalMillis <= 0) {
			stopAndDestroy();
		} else {
			startPaused();
		}
	}

	@Override
	public IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException {
		monitor.subTask("Writing distraction statistics");

		DistractionModel distractionModel = model.getDistractionModel();

		if (distractionModel == null || distractionModel.getDistractionTypes().isEmpty()) {
			return Status.OK_STATUS;
		}

		List<DistractionType> distractionTypes = distractionModel.getDistractionTypes();

		List<MLArray> matFileData = new ArrayList<>();

		String varname = DISTRACTIONS_VAR_PREFIX;
		MLCell jStats = new MLCell(varname, new int[] { distractionTypes.size() + 1, 8 });
		int index = 0;

		jStats.set(new MLChar("", "Distraction Type"), 0, index++);
		jStats.set(new MLChar("", "Exposure [%]"), 0, index++);
		jStats.set(new MLChar("", "Occurrences"), 0, index++);
		jStats.set(new MLChar("", "Mean Duration [s]"), 0, index++);
		jStats.set(new MLChar("", "Std. Duration [s]"), 0, index++);
		jStats.set(new MLChar("", "Min. Duration [s]"), 0, index++);
		jStats.set(new MLChar("", "Max. Duration [s]"), 0, index++);
		jStats.set(new MLChar("", "Simulation Time [s]"), 0, index++);

		int i = 1;
		double simulationTime = model.getSimRuntimeSeconds();
		long distractibleVehicles = distractionModel.getNumTargetVehicles();

		for (DistractionType type : distractionTypes) {
			if (monitor.isCanceled()) {
				return Status.CANCEL_STATUS;
			}

			long id = type.getId();
			List<Double> durations = distractionModel.getDurationsPerType(id);
			long exposure = distractionModel.getExposurePerType(id);

			DescriptiveStatistics stats = new DescriptiveStatistics(CollectionUtil.toPrimitiveDoubleArray(durations));
			double minDuration = stats.getMin();
			double maxDuration = stats.getMax();
			double meanDuration = stats.getMean();
			double stdDuration = stats.getStandardDeviation();
			long occurrences = stats.getN();

			index = 0;
			jStats.set(new MLInt64("", new long[] { id }, 1), i, index++);
			jStats.set(new MLDouble("", new double[] { exposure / (double) distractibleVehicles * 100.0 }, 1), i, index++);
			jStats.set(new MLInt64("", new long[] { occurrences }, 1), i, index++);
			jStats.set(new MLDouble("", new double[] { meanDuration }, 1), i, index++);
			jStats.set(new MLDouble("", new double[] { stdDuration }, 1), i, index++);
			jStats.set(new MLDouble("", new double[] { minDuration }, 1), i, index++);
			jStats.set(new MLDouble("", new double[] { maxDuration }, 1), i, index++);
			jStats.set(new MLDouble("", new double[] { simulationTime }, 1), i, index++);
			i++;
		}

		// Only add if data has been recorded actually
		if (i > 1) {
			matFileData.add(jStats);
		}

		File matFile = getStandardMatFile(outputFolder, date, crashDetected ? String.format("-%s%s", CRASH_TAG, DISTRACTIONS_STATISTICS_SUFFIX)
				: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, DISTRACTIONS_STATISTICS_SUFFIX) : DISTRACTIONS_STATISTICS_SUFFIX);

		try

		{
			monitor.subTask("Writing to Distraction Outline Statistics MAT file");
			new MatFileWriter(matFile, matFileData);
		} catch (

		IOException e)

		{
			String msg = "Cannot write to Distraction Outline Statistics MAT file '" + matFile.getName() + "'";
			Logger.logError(msg, e);
			return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, msg);
		}

		return Status.OK_STATUS;

	}

	@Override
	protected String getStatisticsFilePrefix() {
		return "distraction_outline_statistics_";
	}
}
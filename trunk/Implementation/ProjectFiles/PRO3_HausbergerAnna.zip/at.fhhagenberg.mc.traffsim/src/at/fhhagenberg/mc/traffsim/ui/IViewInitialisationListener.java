package at.fhhagenberg.mc.traffsim.ui;

import org.eclipse.ui.IWorkbenchPart;

public interface IViewInitialisationListener {

	void onViewInitialised(IWorkbenchPart view);
}

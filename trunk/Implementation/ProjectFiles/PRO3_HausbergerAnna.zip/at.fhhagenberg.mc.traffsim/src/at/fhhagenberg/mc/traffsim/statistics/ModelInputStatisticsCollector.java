package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

import com.esotericsoftware.kryo.io.Input;
import com.jmatio.io.MatFileReader;
import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.EnumUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Collects the input parameters passed to the longitudinal model for acceleration calculation for every vehicle in the simulation run.
 * Required for allowing to reproduce specific simulation scenarios by simply feeding the model with the respective input, e.g. in Matlab.
 *
 * @author Manuel Lindorfer
 *
 */
public class ModelInputStatisticsCollector extends CachingStatisticsCollector
		implements IVehicleGeneratorListener, IVehicleListener, IPropertyChangeListener {

	private static final String COLUMN_NAMES_MODEL_INPUT_VAR = "column_names_model_input";

	/**
	 * As soon as a vehicle leaves simulation, its data is cached and written to a file in the next write cycle
	 */
	private List<ModelInputStatisticsData> leftVehiclesCache = new CopyOnWriteArrayList<>();

	private enum ModelInputFieldId {
		TIME, SPEED, SPEED_DIFFERENCE, SPACING, ACC_LEADER, ALPHA_ACC, ALPHA_T, ALPHA_V0, APPLIED_ACC, DISTANCE_NOISE, SPEED_DIFFERENCE_NOISE, ACCELERATION_NOISE;

		public static int length() {
			return values().length;
		}
	}

	public ModelInputStatisticsCollector(String name, SimulationModel model, long delay, boolean clearPreviousCaches) {
		super(name, model, delay, false, clearPreviousCaches);
		PreferenceUtil.addPropertyChangeListener(this);
	}

	@Override
	public IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException {
		if (!cacheFolder.exists()) {
			Logger.logWarn("Expected cache folder " + cacheFolder.getName() + " does not exist");
			return Status.CANCEL_STATUS;
		}

		monitor.worked(1);

		File matFile = getStandardMatFile(outputFolder, date, crashDetected ? String.format("-%s%s", CRASH_TAG, SIMPLE_MAT_FILE_SUFFIX)
				: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, SIMPLE_MAT_FILE_SUFFIX) : SIMPLE_MAT_FILE_SUFFIX);

		Map<Long, List<Double[]>> modelInputData = new HashMap<>();
		File[] files = cacheFolder.listFiles();

		if (files != null) {
			monitor.beginTask("Converting " + files.length + " cached files", files.length + 2);

			long totalLength = 0;

			for (File f : files) {
				Input input = new Input(new FileInputStream(f));
				List<?> objs = kryo.readObject(input, ArrayList.class);
				input.close();

				for (Object obj : objs) {
					if (obj instanceof ModelInputStatisticsData) {
						ModelInputStatisticsData bvd = (ModelInputStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (vehicle " + bvd.getVehicleId() + ")");
						List<Double[]> dataToAdd;

						if (!modelInputData.containsKey(bvd.getVehicleId())) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = modelInputData.get(bvd.getVehicleId());
						}

						int arraySize = ModelInputFieldId.length();

						for (int i = 0; i < bvd.getTime().size(); i++) {
							Double[] row = new Double[arraySize];
							row[ModelInputFieldId.TIME.ordinal()] = bvd.getTime().get(i);
							row[ModelInputFieldId.SPEED.ordinal()] = bvd.getSpeed().get(i);
							row[ModelInputFieldId.SPEED_DIFFERENCE.ordinal()] = bvd.getSpeedDifference().get(i);
							row[ModelInputFieldId.SPACING.ordinal()] = bvd.getSpacing().get(i);
							row[ModelInputFieldId.ACC_LEADER.ordinal()] = bvd.getAccLeader().get(i);
							row[ModelInputFieldId.ALPHA_ACC.ordinal()] = bvd.getAlphaA().get(i);
							row[ModelInputFieldId.ALPHA_T.ordinal()] = bvd.getAlphaT().get(i);
							row[ModelInputFieldId.ALPHA_V0.ordinal()] = bvd.getAlphaV0().get(i);
							row[ModelInputFieldId.APPLIED_ACC.ordinal()] = bvd.getAppliedAcc().get(i);
							row[ModelInputFieldId.DISTANCE_NOISE.ordinal()] = bvd.getDistanceEstimationError().get(i);
							row[ModelInputFieldId.SPEED_DIFFERENCE_NOISE.ordinal()] = bvd.getSpeedDifferenceEstimationError().get(i);
							row[ModelInputFieldId.ACCELERATION_NOISE.ordinal()] = bvd.getDrivingError().get(i);

							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						modelInputData.put(bvd.getVehicleId(), dataToAdd);

					} else if (obj != null) {
						Logger.logWarn(
								"Found unexpected object type in cache: " + obj.getClass().getCanonicalName() + " | toString(): " + obj.toString());
					} else {
						Logger.logWarn("Found null object in cache");
					}
				}

				totalLength += f.length();
				long threshold = Runtime.getRuntime().freeMemory() / 2;

				if (totalLength > threshold) {
					appendData(matFile, modelInputData, monitor);
					modelInputData = new HashMap<>();
					totalLength = 0;
				}

				monitor.worked(1);

			}
		}

		// write and clear data
		appendData(matFile, modelInputData, monitor);

		monitor.worked(2);

		if (clearCache) {
			clearCache(cacheFolder);
		}

		return Status.OK_STATUS;
	}

	protected void appendData(File matFile, Map<Long, List<Double[]>> data, IProgressMonitor monitor) throws IOException {
		String baseMsg = String.format("Appending to MAT-file (current size: %.1f MB): ", ((double) matFile.length()) / 1024 / 1024);
		Map<String, MLArray> matFileData;
		matFile = findMatFile(matFile, false);

		if (matFile.exists() && matFile.length() < Math.pow(10, 9) / 2) {
			monitor.subTask(baseMsg + "Reading old file");
			matFileData = new MatFileReader(matFile).getContent();
		} else {
			matFile = findMatFile(matFile, true);
			matFileData = new HashMap<>();
		}

		Set<Long> keys = new HashSet<>(data.keySet());

		for (Long vid : keys) {
			monitor.subTask(baseMsg + "Appending vehicle " + vid);
			String varname = getVarName(vid, null);

			int arraySize = ModelInputFieldId.length();

			double[][] newarr = new double[data.get(vid).size()][arraySize];
			if (data.get(vid).size() == 0) {
				Logger.logWarn("Found no recorded data for vehicle #" + vid);
				continue;
			}

			int i = 0;

			for (Double[] row : data.remove(vid)) {
				newarr[i++] = CollectionUtil.toPrimitiveDoubleArray(row);
			}

			if (matFileData.containsKey(varname)) {
				double[][] oldarr = ((MLDouble) matFileData.get(varname)).getArray();
				int oldlen = oldarr.length;
				int newlen = newarr.length;
				double joined[][] = new double[oldlen + newlen][];
				System.arraycopy(oldarr, 0, joined, 0, oldlen);
				oldarr = null; // clean memory
				System.arraycopy(newarr, 0, joined, oldlen, newlen);
				matFileData.put(varname, new MLDouble(varname, joined));
			} else {
				matFileData.put(varname, new MLDouble(varname, newarr));
			}
		}

		Collection<MLArray> finalData = new ArrayList<>(matFileData.values());

		// column names for vehicles
		String[] colNames = EnumUtil.enumNameToStringArray(ModelInputFieldId.values());
		finalData.add(new MLChar(COLUMN_NAMES_MODEL_INPUT_VAR, colNames));

		monitor.subTask(baseMsg + "Writing new file");
		new MatFileWriter(matFile, finalData);
	}

	@Override
	public String getCacheFolderPrefix() {
		return ".stat-model-cache_";
	}

	@Override
	protected String getCacheFilePrefix() {
		return "traffsim_model_stats";
	}

	@Override
	protected String getVariablePrefix() {
		return "vehicle_input_";
	}

	@Override
	protected String getStatisticsFilePrefix() {
		return "model_input_statistics_";
	}

	@Override
	protected synchronized void collectStatistics(int itemsToKeep) {
		Map<Long, ModelInputStatisticsData> mStats = model.getStatistics().getModelInputStats();

		for (Vehicle v : model.getVehiclesInSimulation(false)) {
			ModelInputStatisticsData msd = mStats.get(v.getUniqueId());

			if (msd != null) {
				ModelInputStatisticsData data = msd.collectData(itemsToKeep);
				dataList.add(data);
				pause(2);
			}
		}

		if (!leftVehiclesCache.isEmpty()) {
			dataList.addAll(leftVehiclesCache);
		}

		leftVehiclesCache = new CopyOnWriteArrayList<>();
	}

	@Override
	public void vehicleGenerated(Vehicle vehicle) {
		vehicle.addVehicleListener(this);
	}

	@Override
	public synchronized void vehicleLeftSimulation(Vehicle v) {
		if (model != null && model.getStatistics() != null && model.getStatistics().getModelInputStats() != null && leftVehiclesCache != null) {
			leftVehiclesCache.add(model.getStatistics().getModelInputStats().get(v.getUniqueId()).collectData(0));
		}
	}

	@Override
	public void propertyChange(PropertyChangeEvent event) {
		if (event.getProperty().equals(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS) && !Boolean.valueOf(event.getNewValue().toString())) {
			model.removeSimulationTimeUpdatable(this);
			stopAndDestroy();
		}
	}

	@Override
	protected void preStop() {
		PreferenceUtil.removePropertyChangeListener(this);
	}
}

package at.fhhagenberg.mc.traffsim.roadnetwork.junction;

import java.util.Comparator;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;

/**
 * Comparator, which enables sorting of road connections of a junction clockwise, so that index of the connections represents the neighbors
 * (e.g. index 1 is left to index 2, while index 3 is right to index 2; index size()-1 is left of index 0)
 * 
 * @author Christian B.
 * 
 */
public class DirectionComparator implements Comparator<RoadSegment> {

	public static final int GEOMETRY_TAKE_FIRST = 1;
	public static final int GEOMETRY_TAKE_LAST = 2;

	private boolean takeFirst = false;
	private Vector center;

	/**
	 * Initialize the comparator with the reference point at the center of the junction, and an information which point of the
	 * roadgeometries should be taken for angle calculation
	 * 
	 * @param junctionCenter
	 *            Reference point for calculation of the angle
	 * @param geometryPointToTake
	 *            Point of {@link RoadGeometry} which is taken into consideration for angle calculation. This is usually the nearest point
	 *            to the junction, being the first of an outgoing direction and the last of an incoming geometry.
	 */
	public DirectionComparator(Vector junctionCenter, int geometryPointToTake) {
		this.center = junctionCenter;
		this.takeFirst = geometryPointToTake == GEOMETRY_TAKE_FIRST ? true : false;
	}

	@Override
	public int compare(RoadSegment o1, RoadSegment o2) {
		if (o1.getRoadGeometry().getPoints().size() == 0 || o2.getRoadGeometry().getPoints().size() == 0) {
			return 0;
		}
		if (takeFirst) {
			double angle1 = center.minus(o1.getRoadGeometry().getPoints().get(0)).getAngle();
			double angle2 = center.minus(o2.getRoadGeometry().getPoints().get(0)).getAngle();
			return Double.compare(angle1, angle2);
		} else {
			double angle1 = center.minus(o1.getRoadGeometry().getPoints().get(o1.getRoadGeometry().getPoints().size() - 1)).getAngle();
			double angle2 = center.minus(o2.getRoadGeometry().getPoints().get(o2.getRoadGeometry().getPoints().size() - 1)).getAngle();
			return Double.compare(angle1, angle2);
		}
	}
}

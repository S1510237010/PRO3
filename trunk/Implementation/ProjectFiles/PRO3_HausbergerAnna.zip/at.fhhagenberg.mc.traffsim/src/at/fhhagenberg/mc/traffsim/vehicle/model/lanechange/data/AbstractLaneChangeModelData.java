package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data;

import at.fhhagenberg.mc.traffsim.vehicle.model.VehicleModelInputData;

public abstract class AbstractLaneChangeModelData extends VehicleModelInputData {

}

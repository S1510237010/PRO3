package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.behaviors;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.BeanConfigurationContainer;
import at.fhhagenberg.mc.traffsim.data.beans.BehaviorBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.csv.CFDataParser;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.BehaviorType;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class BehaviorSpecificationPage extends WizardPage {

	// Configuration selection controls
	private Text textConfigPath;
	private Button btnBrowse;

	// Behavior specification page
	private Button btnAddBehavior;
	private Button btnRemoveBehavior;
	private Combo cmbVehicles;
	private Combo cmbBehaviorTypes;
	private Spinner spinnerIntensity;
	private Spinner spinnerDuration;
	private Spinner spinnerOffset;

	// Trace file
	private Text textTracePath;
	private Button btnBrowseTraceFile;

	// Table viewer
	private TableViewer viewer;
	private Table table;

	// List of loaded vehicle beans
	private List<VehicleBean> vehicles;

	// List of added behaviors
	private List<BehaviorBean> behaviors;
	private Spinner spinnerResponseTime;

	private boolean wasBehaviorRemoved;

	public BehaviorSpecificationPage(String pageName) {
		super(pageName);
		setTitle("Behavior specifiation");
		behaviors = new ArrayList<BehaviorBean>();
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new GridLayout(5, false));

		Label lblTraffsimConfiguration = new Label(container, SWT.NONE);
		lblTraffsimConfiguration.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTraffsimConfiguration.setText("TraffSim Configuration");

		textConfigPath = new Text(container, SWT.BORDER);
		GridData gd_textConfigPath = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_textConfigPath.widthHint = 400;
		textConfigPath.setLayoutData(gd_textConfigPath);
		textConfigPath.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});

		textConfigPath.setText(PreferenceUtil.getString(IPreferenceConstants.WIZARD_BEHAVIOR_CONFIG_PATH, ""));
		new Label(container, SWT.NONE);

		btnBrowse = new Button(container, SWT.NONE);
		btnBrowse.setText("Browse");
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(getWizard().getContainer().getShell());
				dialog.setText("Open configuration file");
				dialog.setFilterExtensions(new String[] { Constants.FILE_FILTER_TRAFFSIM_XML });
				dialog.setFilterNames(new String[] { Constants.FILTER_NAME_TRAFFSIM });
				String selected = dialog.open();

				if (StringUtil.isNotNullOrEmpty(selected)) {
					textConfigPath.setText(selected);
				}

				validatePage();

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});

		new Label(container, SWT.NONE);

		Group grpSetOverview = new Group(container, SWT.NONE);
		grpSetOverview.setLayout(new FillLayout(SWT.HORIZONTAL));
		GridData overviewData = new GridData(SWT.FILL, SWT.FILL, true, false, 5, 1);
		overviewData.heightHint = 150;
		grpSetOverview.setLayoutData(overviewData);
		grpSetOverview.setText("Overview");

		viewer = new TableViewer(grpSetOverview, SWT.BORDER | SWT.FULL_SELECTION);
		viewer.addSelectionChangedListener(new ISelectionChangedListener() {

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				if (((IStructuredSelection) viewer.getSelection()).getFirstElement() != null) {
					btnRemoveBehavior.setEnabled(true);
				} else {
					btnRemoveBehavior.setEnabled(false);
				}
			}
		});

		table = viewer.getTable();
		table.setHeaderVisible(true);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		Group grpBehaviorSpecifiation = new Group(container, SWT.NONE);
		grpBehaviorSpecifiation.setLayout(new GridLayout(5, false));
		grpBehaviorSpecifiation.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 2, 1));
		grpBehaviorSpecifiation.setText("Behavior Specifiation");

		Label lblNewLabel = new Label(grpBehaviorSpecifiation, SWT.NONE);
		lblNewLabel.setText("Select a vehicle");

		cmbVehicles = new Combo(grpBehaviorSpecifiation, SWT.READ_ONLY);
		GridData gd_cmbVehicles = new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1);
		gd_cmbVehicles.widthHint = 200;
		cmbVehicles.setLayoutData(gd_cmbVehicles);

		Label lblSelectABehavior = new Label(grpBehaviorSpecifiation, SWT.NONE);
		lblSelectABehavior.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblSelectABehavior.setText("Select a behavior");

		cmbBehaviorTypes = new Combo(grpBehaviorSpecifiation, SWT.READ_ONLY);
		cmbBehaviorTypes.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1));
		cmbBehaviorTypes.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (cmbBehaviorTypes.getText().compareTo(BehaviorType.CONTROL.toString()) == 0) {
					spinnerDuration.setEnabled(false);
					spinnerIntensity.setEnabled(false);
					spinnerOffset.setEnabled(false);
					spinnerResponseTime.setEnabled(false);
					btnBrowseTraceFile.setEnabled(false);
				} else {
					if (cmbBehaviorTypes.getText().compareTo(BehaviorType.TRACE.toString()) == 0) {
						spinnerDuration.setEnabled(false);
						spinnerIntensity.setEnabled(false);
						spinnerOffset.setEnabled(true);
						btnBrowseTraceFile.setEnabled(true);
						spinnerResponseTime.setEnabled(false);
					} else if (cmbBehaviorTypes.getText().compareTo(BehaviorType.DISTRACTION_EYES_OFF_ROAD.toString()) == 0) {
						spinnerDuration.setEnabled(true);
						spinnerIntensity.setEnabled(false);
						spinnerOffset.setEnabled(true);
						spinnerResponseTime.setEnabled(false);
						btnBrowseTraceFile.setEnabled(false);
					} else if (cmbBehaviorTypes.getText().compareTo(BehaviorType.DISTRACTION_MIND_OFF_ROAD.toString()) == 0) {
						spinnerDuration.setEnabled(true);
						spinnerIntensity.setEnabled(false);
						spinnerOffset.setEnabled(true);
						spinnerResponseTime.setEnabled(true);
						btnBrowseTraceFile.setEnabled(false);
					} else {
						spinnerDuration.setEnabled(true);
						spinnerIntensity.setEnabled(true);
						spinnerOffset.setEnabled(true);
						spinnerResponseTime.setEnabled(false);
						btnBrowseTraceFile.setEnabled(false);
					}
				}
			}
		});

		for (BehaviorType behaviorType : BehaviorType.values()) {
			cmbBehaviorTypes.add(behaviorType.toString());
		}

		cmbBehaviorTypes.select(0);

		Label lblTracePath = new Label(grpBehaviorSpecifiation, SWT.NONE);
		lblTracePath.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTracePath.setText("Select a speed/acceleration trace");

		textTracePath = new Text(grpBehaviorSpecifiation, SWT.BORDER);
		textTracePath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		textTracePath.setEnabled(false);
		lblTracePath
				.setToolTipText("Path to trace file containing a trajectory pair (leader, follower) incl. velocities, accelerations, ...");

		btnBrowseTraceFile = new Button(grpBehaviorSpecifiation, SWT.NONE);
		btnBrowseTraceFile.setText("Browse");
		btnBrowseTraceFile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(getWizard().getContainer().getShell());
				dialog.setText("Open NGSIM trace file");
				dialog.setFilterExtensions(new String[] { Constants.FILE_FILTER_CSV });
				dialog.setFilterNames(new String[] { Constants.FILTER_NAME_CSV });
				String selected = dialog.open();

				if (StringUtil.isNotNullOrEmpty(selected)) {
					if (CFDataParser.isValidNGSIMSet(selected) || CFDataParser.isValidOBDSet(selected)) {
						textTracePath.setText(selected);
					} else {
						textTracePath.setText("");

						Display.getDefault().asyncExec(new Runnable() {

							@Override
							public void run() {
								MessageDialog.openError(Display.getDefault().getActiveShell(), "Error",
										"The selected trace file is corrupt. Please ensure that the file yields the correct format and contains valid content only.");
							}
						});
					}
				}

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});

		new Label(grpBehaviorSpecifiation, SWT.NONE);
		new Label(grpBehaviorSpecifiation, SWT.NONE);
		new Label(grpBehaviorSpecifiation, SWT.NONE);
		new Label(grpBehaviorSpecifiation, SWT.NONE);

		textConfigPath.setText(PreferenceUtil.getString(IPreferenceConstants.WIZARD_BEHAVIOR_CONFIG_PATH, ""));

		new Label(grpBehaviorSpecifiation, SWT.NONE);

		Label lblIntensityms = new Label(grpBehaviorSpecifiation, SWT.NONE);
		lblIntensityms.setText("Intensity [m/s\u00B2]");

		spinnerIntensity = new Spinner(grpBehaviorSpecifiation, SWT.BORDER);
		spinnerIntensity.setMaximum(1000);
		spinnerIntensity.setDigits(2);
		lblIntensityms.setToolTipText("Specifies the intensity of the braking / acceleration maneuver.");
		new Label(grpBehaviorSpecifiation, SWT.NONE);

		Label lblDurations = new Label(grpBehaviorSpecifiation, SWT.NONE);
		lblDurations.setText("Duration [s]");

		spinnerDuration = new Spinner(grpBehaviorSpecifiation, SWT.BORDER);
		spinnerDuration.setMaximum(600);
		spinnerDuration.setDigits(1);
		lblDurations.setToolTipText("Specifies the behavior's duration.");

		Label lblOffests = new Label(grpBehaviorSpecifiation, SWT.NONE);
		lblOffests.setText("Offset [s]");
		spinnerOffset = new Spinner(grpBehaviorSpecifiation, SWT.BORDER);
		spinnerOffset.setMaximum(10000);
		spinnerOffset.setDigits(1);
		lblOffests.setToolTipText(
				"Specifies the behavior's offset from simulation start. Determines when the behavior's execution is triggered.");
		new Label(grpBehaviorSpecifiation, SWT.NONE);

		Label lblResponseTime = new Label(grpBehaviorSpecifiation, SWT.NONE);
		lblResponseTime.setText("Response time increase [%]");

		spinnerResponseTime = new Spinner(grpBehaviorSpecifiation, SWT.BORDER);
		spinnerResponseTime.setMaximum(100);
		spinnerResponseTime.setMinimum(1);
		lblResponseTime
				.setToolTipText("Specifies to what extent a vehicle's response time increased throughout a 'mind-off road' distraction.");
		new Label(container, SWT.NONE);

		Group grpHandling = new Group(container, SWT.NONE);
		grpHandling.setText("Handling");
		grpHandling.setLayout(new GridLayout(1, false));
		grpHandling.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));

		btnAddBehavior = new Button(grpHandling, SWT.NONE);
		GridData gd_btnAddBehavior = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnAddBehavior.widthHint = 150;
		btnAddBehavior.setLayoutData(gd_btnAddBehavior);
		btnAddBehavior.setText("Add Behavior");
		btnAddBehavior.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				boolean isValid = true;
				String errorMessage = "";

				BehaviorBean behavior = new BehaviorBean();
				behavior.setBehaviorType(cmbBehaviorTypes.getText());
				behavior.setVehicleLabel(cmbVehicles.getText());
				behavior.setIntensity((double) spinnerIntensity.getSelection() / Math.pow(10, spinnerIntensity.getDigits()));
				behavior.setDuration((double) spinnerDuration.getSelection() / Math.pow(10, spinnerDuration.getDigits()));
				behavior.setOffset((double) spinnerOffset.getSelection() / Math.pow(10, spinnerOffset.getDigits()));

				if ((cmbBehaviorTypes.getText().compareTo(BehaviorType.ACCELERATION.toString()) == 0
						|| cmbBehaviorTypes.getText().compareTo(BehaviorType.DECELERATION.toString()) == 0
						|| cmbBehaviorTypes.getText().compareTo(BehaviorType.DISTRACTION_EYES_OFF_ROAD.toString()) == 0
						|| cmbBehaviorTypes.getText().compareTo(BehaviorType.DISTRACTION_MIND_OFF_ROAD.toString()) == 0)
						&& spinnerDuration.getSelection() == 0) {
					isValid = false;
					errorMessage = "The selected behavior's duration cannot be zero.";
				}

				if (cmbBehaviorTypes.getText().compareTo(BehaviorType.DISTRACTION_MIND_OFF_ROAD.toString()) == 0) {
					behavior.setParam((double) spinnerResponseTime.getSelection() / Math.pow(10, spinnerResponseTime.getDigits()));
				}

				if (cmbBehaviorTypes.getText().compareTo(BehaviorType.TRACE.toString()) == 0) {
					// A trace file is required in this case
					if (StringUtil.isNotNullOrEmpty(textTracePath.getText())) {
						behavior.setControlTrace(CFDataParser.parse(textTracePath.getText()));
					} else {
						isValid = false;
						errorMessage = "A trace file is required for this kind of behavior.";
					}
				}

				if (isValid) {
					double startTime = behavior.getOffset();
					double endTime = behavior.getOffset() + behavior.getDuration();
					String vehicle = behavior.getVehicleLabel();

					for (BehaviorBean b : behaviors) {
						if (b.getVehicleLabel().compareTo(vehicle) != 0) {
							continue;
						}

						double bStart = b.getOffset();
						double bEnd = b.getOffset() + b.getDuration();

						// Only one control behavior per vehicle is allowed
						if (b.getBehaviorType().compareTo(behavior.getBehaviorType()) == 0
								&& (b.getBehaviorType().compareTo(BehaviorType.CONTROL.toString()) == 0
										|| b.getBehaviorType().compareTo(BehaviorType.TRACE.toString()) == 0)) {
							isValid = false;
							errorMessage = "Only one control / trace-imposed behavior is allowed per vehicle.";
							break;
						}

						if (behavior.getBehaviorType().compareTo(BehaviorType.CONTROL.toString()) == 0
								|| behavior.getBehaviorType().compareTo(BehaviorType.TRACE.toString()) == 0) {
							continue;
						}

						// Check if the behavior overlaps with existing ones, which
						// is not valid either
						if (b.getBehaviorType().compareTo(BehaviorType.CONTROL.toString()) != 0
								&& ((bStart <= startTime && startTime <= bEnd) || (bStart <= endTime && endTime <= bEnd))) {
							isValid = false;
							errorMessage = "The new behavior would overlap with other behaviors of the same vehicle. Please ensure that behaviors of a particular vehicle do not overlap.";
							break;
						}
					}
				}

				if (isValid) {
					behaviors.add(behavior);
					viewer.refresh();

					// Update the wizard buttons
					if (getWizard() != null && getWizard().getContainer() != null) {
						getWizard().getContainer().updateButtons();
					}
				} else {
					MessageDialog messageDialog = new MessageDialog(Display.getCurrent().getActiveShell(), "Behavior can not be added",
							null, errorMessage, MessageDialog.ERROR, new String[] { "Ok" }, 0);
					messageDialog.open();
				}
			}
		});

		btnRemoveBehavior = new Button(grpHandling, SWT.NONE);
		btnRemoveBehavior.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnRemoveBehavior.setText("Remove Behavior");
		btnRemoveBehavior.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (behaviors != null && !behaviors.isEmpty()) {
					behaviors.remove(((IStructuredSelection) viewer.getSelection()).getFirstElement());
					wasBehaviorRemoved = true;

					viewer.refresh();

					// Update the wizard buttons
					if (getWizard() != null && getWizard().getContainer() != null) {
						getWizard().getContainer().updateButtons();
					}
				}
			}
		});

		Label lblHint = new Label(container, SWT.NONE);
		lblHint.setText("Please note: An existing behavior specification will be overwritten when finishing this operation.");
		GridData gdhint = new GridData(SWT.LEFT, SWT.CENTER, false, false, 5, 1);
		lblHint.setLayoutData(gdhint);

		Label lblHint2 = new Label(container, SWT.NONE);
		lblHint2.setText(
				"Please note: Adding a control behavior to a vehicle will make this vehicle not change its acceleration unless imposed by a behavior.");
		gdhint = new GridData(SWT.LEFT, SWT.CENTER, false, false, 5, 1);
		gdhint.heightHint = 80;
		lblHint2.setLayoutData(gdhint);

		createColumns(viewer);

		viewer.setContentProvider(new ArrayContentProvider());
		viewer.setInput(behaviors);

		validatePage();
	}

	private void validatePage() {
		StringBuffer msg = new StringBuffer();

		if (vehicles == null) {
			vehicles = new ArrayList<VehicleBean>();
		} else {
			vehicles.clear();
		}

		if (behaviors == null) {
			behaviors = new ArrayList<BehaviorBean>();
		} else {
			behaviors.clear();
		}

		if (StringUtil.isNullOrEmpty(textConfigPath.getText())) {
			msg.append("Please specify a config file\n");
		} else {
			if (!new File(textConfigPath.getText()).exists()) {
				msg.append("The selected configuration file does not exist\n");
			} else {
				// Try to Load configuration and check if it contains vehicles
				try {
					DataSerializer serializer = new DataSerializer();
					serializer.readConfiguration(new File(textConfigPath.getText()));

					List<? extends AbstractBean> vehicleBeans = serializer.readData(VehicleBean.class);

					for (AbstractBean abstractBean : vehicleBeans) {
						if (abstractBean instanceof VehicleBean) {
							vehicles.add((VehicleBean) abstractBean);
						}
					}

					if (vehicles == null || vehicles.size() == 0) {
						msg.append("The selected configuration does not contain any vehicles.\n");
					} else {
						TraffSimConfiguration config = serializer.getConfiguration();
						Map<String, BeanConfigurationContainer> mapping = config.getBeanConfigurationsMapping();

						if (mapping.containsKey(BehaviorBean.class.getName())) {
							List<? extends AbstractBean> existingBehaviors = serializer.readData(BehaviorBean.class);

							if (existingBehaviors != null && existingBehaviors.size() > 0) {
								for (AbstractBean behavior : existingBehaviors) {
									if (behavior instanceof BehaviorBean) {
										behaviors.add((BehaviorBean) behavior);
									}
								}
							}
						}
					}

				} catch (Exception exc) {
					msg.append("The selected configuration could not be read. Ensure that the referenced files are not corrupt.\n");
					getWizard().getContainer().updateButtons();
					return;
				}

			}
		}

		setErrorMessage(msg.length() == 0 ? null : msg.toString());

		// Enable / disable UI controls
		if (msg.length() == 0) {

			cmbVehicles.removeAll();

			for (VehicleBean v : vehicles) {
				String label = v.getId() + (v.getLabel().isEmpty() ? "" : "_" + v.getLabel());
				cmbVehicles.add(label);
			}

			cmbVehicles.select(0);
			btnAddBehavior.setEnabled(true);
			cmbBehaviorTypes.setEnabled(true);
			cmbVehicles.setEnabled(true);

			if (cmbBehaviorTypes.getText().compareTo(BehaviorType.CONTROL.toString()) == 0) {
				spinnerDuration.setEnabled(false);
				spinnerIntensity.setEnabled(false);
				spinnerOffset.setEnabled(false);
				btnBrowseTraceFile.setEnabled(false);
				spinnerResponseTime.setEnabled(false);
			} else {
				if (cmbBehaviorTypes.getText().compareTo(BehaviorType.TRACE.toString()) == 0) {
					spinnerDuration.setEnabled(false);
					spinnerIntensity.setEnabled(false);
					spinnerOffset.setEnabled(true);
					btnBrowseTraceFile.setEnabled(true);
					spinnerResponseTime.setEnabled(false);
				} else if (cmbBehaviorTypes.getText().compareTo(BehaviorType.DISTRACTION_EYES_OFF_ROAD.toString()) == 0) {
					spinnerDuration.setEnabled(true);
					spinnerIntensity.setEnabled(false);
					spinnerOffset.setEnabled(true);
					spinnerResponseTime.setEnabled(false);
					btnBrowseTraceFile.setEnabled(false);
				} else if (cmbBehaviorTypes.getText().compareTo(BehaviorType.DISTRACTION_MIND_OFF_ROAD.toString()) == 0) {
					spinnerDuration.setEnabled(true);
					spinnerIntensity.setEnabled(false);
					spinnerOffset.setEnabled(true);
					spinnerResponseTime.setEnabled(true);
					btnBrowseTraceFile.setEnabled(false);
				} else {
					spinnerDuration.setEnabled(true);
					spinnerIntensity.setEnabled(true);
					spinnerOffset.setEnabled(true);
					spinnerResponseTime.setEnabled(false);
					btnBrowseTraceFile.setEnabled(false);
				}
			}

			table.setEnabled(true);
			viewer.refresh();

			if (((IStructuredSelection) viewer.getSelection()).getFirstElement() != null) {
				btnRemoveBehavior.setEnabled(true);
			} else {
				btnRemoveBehavior.setEnabled(false);
			}

			// Update the wizard buttons
			if (getWizard() != null && getWizard().getContainer() != null) {
				getWizard().getContainer().updateButtons();
			}
		} else {
			cmbVehicles.removeAll();
			btnAddBehavior.setEnabled(false);
			spinnerOffset.setEnabled(false);
			btnRemoveBehavior.setEnabled(false);
			cmbBehaviorTypes.setEnabled(false);
			cmbVehicles.setEnabled(false);
			spinnerDuration.setEnabled(false);
			spinnerIntensity.setEnabled(false);
			table.setEnabled(false);
			btnBrowseTraceFile.setEnabled(false);
		}
	}

	private void createColumns(TableViewer tv) {
		TableViewerColumn colBehaviorType = createTableViewerColumn("Behavior Type", 120);
		colBehaviorType.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((BehaviorBean) element).getBehaviorType() + "";
			}
		});

		TableViewerColumn colVehicle = createTableViewerColumn("Target Vehicle", 150);
		colVehicle.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((BehaviorBean) element).getVehicleLabel() + "";
			}
		});

		TableViewerColumn colIntensity = createTableViewerColumn("Intensity [m/s\u00B2]", 100);
		colIntensity.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.CONTROL.toString()) == 0
						|| ((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.TRACE.toString()) == 0
						|| ((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.DISTRACTION_EYES_OFF_ROAD.toString()) == 0
						|| ((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.DISTRACTION_MIND_OFF_ROAD.toString()) == 0) {
					return "-";
				}

				return ((BehaviorBean) element).getIntensity() + "";
			}
		});

		TableViewerColumn colDuration = createTableViewerColumn("Duration [s]", 100);
		colDuration.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.CONTROL.toString()) == 0
						|| ((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.TRACE.toString()) == 0) {
					return "-";
				}

				return ((BehaviorBean) element).getDuration() + "";
			}
		});

		TableViewerColumn colOffset = createTableViewerColumn("Offset [s]", 100);
		colOffset.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.CONTROL.toString()) == 0) {
					return "-";
				}

				return ((BehaviorBean) element).getOffset() + "";
			}
		});

		TableViewerColumn colPreset = createTableViewerColumn("Delay [s]", 100);
		colPreset.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.TRACE.toString()) == 0) {
					return ((BehaviorBean) element).getParam() + "";
				}

				return "-";
			}
		});

		TableViewerColumn colSpeedChange = createTableViewerColumn("Change in speed", 120);
		colSpeedChange.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				BehaviorBean behavior = (BehaviorBean) element;

				if (behavior.getBehaviorType().compareTo(BehaviorType.CONTROL.toString()) == 0
						|| ((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.TRACE.toString()) == 0
						|| behavior.getBehaviorType().compareTo(BehaviorType.DISTRACTION_EYES_OFF_ROAD.toString()) == 0
						|| behavior.getBehaviorType().compareTo(BehaviorType.DISTRACTION_MIND_OFF_ROAD.toString()) == 0) {
					return "-";
				}

				String prefix = behavior.getBehaviorType().compareTo(BehaviorType.DECELERATION.toString()) == 0 ? "- " : "";
				return prefix + behavior.getIntensity() * behavior.getDuration() + " m/s";
			}
		});

		TableViewerColumn colResponseTimeIncrease = createTableViewerColumn("Reponse time increase [%]", 150);
		colResponseTimeIncrease.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (((BehaviorBean) element).getBehaviorType().compareTo(BehaviorType.DISTRACTION_MIND_OFF_ROAD.toString()) == 0) {
					return ((BehaviorBean) element).getParam() + "";
				}

				return "-";
			}
		});
	}

	protected TableViewerColumn createTableViewerColumn(String title, int width) {
		final TableViewerColumn viewerColumn = new TableViewerColumn(viewer, SWT.NONE);
		final TableColumn column = viewerColumn.getColumn();
		column.setText(title);
		column.setWidth(width);
		column.setResizable(true);
		column.setMoveable(true);
		return viewerColumn;
	}

	@Override
	public IWizardPage getNextPage() {
		return getWizard().getPage(BehaviorGenerationWizard.PAGE_BEHAVIOR_SPECIFICATION);
	}

	@Override
	public boolean canFlipToNextPage() {
		return StringUtil.isNullOrEmpty(getErrorMessage());
	}

	@Override
	public boolean isPageComplete() {
		return getErrorMessage() == null && behaviors != null && (behaviors.size() > 0 || wasBehaviorRemoved);
	}

	public File getConfigFile() {
		if (textConfigPath == null) {
			return null;
		}

		return new File(textConfigPath.getText());
	}

	public List<BehaviorBean> getBehaviors() {
		return behaviors;
	}
}
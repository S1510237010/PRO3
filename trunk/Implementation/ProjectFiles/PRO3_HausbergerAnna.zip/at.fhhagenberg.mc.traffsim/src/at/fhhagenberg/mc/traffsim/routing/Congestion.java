package at.fhhagenberg.mc.traffsim.routing;

import java.util.Date;
import java.util.List;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class Congestion {
	/** the vehicle which is affected by the congestion */
	private List<Vehicle> vehicles;
	/** nodes which are affected by the congestion (may be empty if unknown) */
	private long congestedNode;
	/** number of vehicles which are allowed to pass the congested node */
	private long numAllowed;
	/** unique id of congestion */
	private long congestionId;
	/** the predicted date of the congestion, or <code>null</code> if not applicable */
	private Date predictedDate;

	private static long maxCongestionId = 0;

	public Congestion(long congestedNode, long numAllowedVehicles, List<Vehicle> vehicles, Date predictedDate) {
		this.vehicles = vehicles;
		this.congestedNode = congestedNode;
		this.numAllowed = numAllowedVehicles;
		this.predictedDate = predictedDate;
		congestionId = maxCongestionId++;
	}

	public Congestion(long congestedNode, long numAllowedVehicles, List<Vehicle> vehicles) {
		this(congestedNode, numAllowedVehicles, vehicles, null);
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public long getCongestedNode() {
		return congestedNode;
	}

	@Override
	public String toString() {
		return "Nodes: " + congestedNode + ", " + vehicles.size() + " vehicles";
	}

	public long getNumAllowed() {
		return numAllowed;
	}

	public long getCongestionId() {
		return congestionId;
	}

	public Date getPredictedDate() {
		return predictedDate;
	}

}

package at.fhhagenberg.mc.traffsim.ui.preferences;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.crashdetector.ActionOnCrash;
import at.fhhagenberg.mc.traffsim.deadlock.ActionOnDeadlock;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class SimulationPreferencePage extends PreferencePage implements IWorkbenchPreferencePage {
	private Combo comboCrash;
	private Group grpCrashHandling;
	private Group grpSimulationRun;
	private Label lblActionOnCrash;
	private Spinner spinnerDelay;
	private Spinner spinnerResolution;
	private Group grpDeadlockHandling;
	private Label lblActionOnDeadlock;
	private Combo comboDeadlock;
	private Button btnBoundSimulationRuntime;
	private Label lblMaxSimulationRuntime;
	private Spinner spinnerMaxSimulationRuntime;
	private Group grpThreading;
	private Button btnSinglethreaded;
	private Button btnMultithreaded;
	private Button btnEnableDistractions;

	/**
	 * @wbp.parser.constructor
	 */
	public SimulationPreferencePage() {
	}

	public SimulationPreferencePage(String title) {
		super(title);
	}

	public SimulationPreferencePage(String title, ImageDescriptor image) {
		super(title, image);
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(1, false));

		grpThreading = new Group(container, SWT.NONE);
		grpThreading.setLayout(new GridLayout(2, true));
		grpThreading.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpThreading.setText("Threading");

		btnSinglethreaded = new Button(grpThreading, SWT.RADIO);
		btnSinglethreaded.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnSinglethreaded.setText("Single-Threaded");

		btnMultithreaded = new Button(grpThreading, SWT.RADIO);
		btnMultithreaded.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnMultithreaded.setText("Multithreaded");

		grpSimulationRun = new Group(container, SWT.NONE);
		grpSimulationRun.setText("Simulation Run");
		grpSimulationRun.setLayout(new GridLayout(2, false));
		grpSimulationRun.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblSimulationDelayms = new Label(grpSimulationRun, SWT.NONE);
		lblSimulationDelayms.setText("Simulation delay [ms]");

		spinnerDelay = new Spinner(grpSimulationRun, SWT.BORDER);
		spinnerDelay.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerDelay.setMaximum(1000);
		spinnerDelay.setMinimum(0);

		Label lblSimulationResolutionms = new Label(grpSimulationRun, SWT.NONE);
		lblSimulationResolutionms.setText("Simulation resolution [ms]");

		spinnerResolution = new Spinner(grpSimulationRun, SWT.BORDER);
		spinnerResolution.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerResolution.setMaximum(1000);
		spinnerResolution.setMinimum(1);

		btnBoundSimulationRuntime = new Button(grpSimulationRun, SWT.CHECK);
		btnBoundSimulationRuntime.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				spinnerMaxSimulationRuntime.setEnabled(btnBoundSimulationRuntime.getSelection());
			}
		});

		btnBoundSimulationRuntime.setText("Bound simulation runtime");
		new Label(grpSimulationRun, SWT.NONE);

		lblMaxSimulationRuntime = new Label(grpSimulationRun, SWT.NONE);
		lblMaxSimulationRuntime.setText("Max. simulation runtime [s]");
		lblMaxSimulationRuntime.setToolTipText(
				"Bounds the simulation runtime to the selected number of seconds. The simulation run is stopped after the specified timespan has ellapsed.");

		spinnerMaxSimulationRuntime = new Spinner(grpSimulationRun, SWT.BORDER);
		spinnerMaxSimulationRuntime.setMaximum(86400);
		spinnerMaxSimulationRuntime.setMinimum(1);

		btnEnableDistractions = new Button(grpSimulationRun, SWT.CHECK);
		btnEnableDistractions.setText("Enable driver distractions");
		btnEnableDistractions.setToolTipText("Determines whether driver distractions are modeled throughout a simulation run or not");

		grpCrashHandling = new Group(container, SWT.NONE);
		grpCrashHandling.setText("Crash Handling");
		grpCrashHandling.setLayout(new GridLayout(2, false));
		grpCrashHandling.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		lblActionOnCrash = new Label(grpCrashHandling, SWT.NONE);
		lblActionOnCrash.setText("Action on Crash");

		comboCrash = new Combo(grpCrashHandling, SWT.READ_ONLY);
		comboCrash.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		for (ActionOnCrash act : ActionOnCrash.values()) {
			comboCrash.add(act.toString());
		}

		grpDeadlockHandling = new Group(container, SWT.NONE);
		grpDeadlockHandling.setLayout(new GridLayout(2, false));
		grpDeadlockHandling.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		grpDeadlockHandling.setText("Deadlock Handling");

		lblActionOnDeadlock = new Label(grpDeadlockHandling, SWT.NONE);
		lblActionOnDeadlock.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblActionOnDeadlock.setText("Action on Deadlock");

		comboDeadlock = new Combo(grpDeadlockHandling, SWT.READ_ONLY);
		comboDeadlock.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		for (ActionOnDeadlock act : ActionOnDeadlock.values()) {
			comboDeadlock.add(act.toString());
		}

		initializePreferences();
		return container;
	}

	@Override
	public void init(IWorkbench workbench) {

	}

	private void initializePreferences() {
		spinnerDelay.setSelection(PreferenceUtil.getInt(IPreferenceConstants.SIMULATION_DELAY_MS));
		spinnerResolution.setSelection(PreferenceUtil.getInt(IPreferenceConstants.SIMULATION_RESOLUTION_MS));
		spinnerMaxSimulationRuntime.setSelection(PreferenceUtil.getInt(IPreferenceConstants.MAX_SIMULATION_RUNTIME));
		btnBoundSimulationRuntime.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.BOUND_SIMULATION_RUNTIME));
		comboCrash.select(PreferenceUtil.getInt(IPreferenceConstants.ACTION_ON_CRASH));
		comboDeadlock.select(PreferenceUtil.getInt(IPreferenceConstants.ACTION_ON_DEADLOCK));
		spinnerMaxSimulationRuntime.setEnabled(btnBoundSimulationRuntime.getSelection());
		btnSinglethreaded.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.SINGLETHREADED_EXECUTION));
		btnMultithreaded.setSelection(!PreferenceUtil.getBoolean(IPreferenceConstants.SINGLETHREADED_EXECUTION));
		btnEnableDistractions.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.DISTRACTION_MODEL_ACTIVE));
	}

	@Override
	protected void performApply() {
		PreferenceUtil.setBoolean(IPreferenceConstants.BOUND_SIMULATION_RUNTIME, btnBoundSimulationRuntime.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.MAX_SIMULATION_RUNTIME, spinnerMaxSimulationRuntime.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.SIMULATION_DELAY_MS, spinnerDelay.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.SIMULATION_RESOLUTION_MS, spinnerResolution.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.ACTION_ON_CRASH, comboCrash.getSelectionIndex());
		PreferenceUtil.setInt(IPreferenceConstants.ACTION_ON_DEADLOCK, comboDeadlock.getSelectionIndex());
		PreferenceUtil.setBoolean(IPreferenceConstants.SINGLETHREADED_EXECUTION, btnSinglethreaded.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.DISTRACTION_MODEL_ACTIVE, btnEnableDistractions.getSelection());
	}

	@Override
	public boolean performOk() {
		performApply();
		return super.performOk();
	}
}
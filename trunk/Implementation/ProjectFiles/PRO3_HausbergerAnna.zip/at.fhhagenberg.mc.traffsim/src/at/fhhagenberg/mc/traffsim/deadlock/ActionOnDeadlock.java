package at.fhhagenberg.mc.traffsim.deadlock;

public enum ActionOnDeadlock {
	/**
	 * The simulation is paused and an info dialog is shown
	 */
	OPEN_POPUP("Pause and open info dialog"),

	/**
	 * The deadlock is ignored silently
	 */
	IGNORE("Ignore silently"),

	/**
	 * The simulation is restarted if it is executed in batch mode
	 */
	RESTART("Restart simulation (only in batch mode)"),

	/**
	 * The simulation is stopped and aborted
	 */
	STOP_SIMULATION("Stop and abort simulation"),

	/**
	 * The simulation's output is tagged as "deadlocked"; if the simulation is executed in batch mode, it continues as normal
	 */
	TAG_AND_CONTINUE("Tag simulation run and continue (if in batch mode)");

	String longtext;

	private ActionOnDeadlock(String desc) {
		this.longtext = desc;
	}

	@Override
	public String toString() {
		return longtext;
	}
}

package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.DateUtil;
import at.fhhagenberg.mc.util.StringUtil;

public abstract class CachingStatisticsCollector extends BaseStatisticsCollector implements IConvertableStatisticsCollector {

	protected static final String RUNNING_PREFIX = "~";

	/** Fast serialization **/
	protected Kryo kryo = new Kryo();

	/** Caching **/
	List<Object> dataList = new CopyOnWriteArrayList<>();
	protected Lock dataCollectionLock = new ReentrantLock();
	protected long continousFileCounter = 0;
	protected File cacheFolder;

	protected int statisticsFetchSize;
	protected int additionalDataFetchSize;

	public CachingStatisticsCollector(String name, SimulationModel model, long delayInMillis, boolean startThread, boolean clearPreviousCaches) {
		super(name, delayInMillis, startThread);

		this.model = model;
		this.statisticsFetchSize = PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_CACHE_SIZE);
		this.additionalDataFetchSize = PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_CACHE_SIZE);

		if (clearPreviousCaches) {
			clearPreviousCaches();
		}

		kryo.setClassLoader(TraffSimCorePlugin.class.getClassLoader());
		kryo.setAutoReset(true);
		startPaused();
	}

	public IStatus convertStatistics(File cacheFolder, Kryo kryo, File outputFolder, String startDate, boolean clearCache, IProgressMonitor monitor)
			throws IOException {
		this.cacheFolder = cacheFolder;
		this.kryo = kryo;
		return convertStatistics(outputFolder, startDate, clearCache, monitor, false, false);
	}

	protected void clearPreviousCaches() {
		Logger.logInfo("Deleting previous cache folders");

		if (model.getOutputFolder() != null && model.getOutputFolder().exists()) {

			File[] files = model.getOutputFolder().listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return name.startsWith(getCacheFolderPrefix());
				}
			});

			if (files != null) {
				for (File f : files) {
					if (f.isDirectory()) {
						clearCache(f);
					}
					f.delete();
				}
			}
		}
	}

	protected void clearCache(File parentFolder) {
		if (parentFolder == null) {
			return;
		}

		File[] files = parentFolder.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return name.startsWith(getCacheFilePrefix()) && name.endsWith(CACHE_FILE_SUFFIX);
			}
		});

		if (files != null) {
			for (File f2 : files) {
				if (f2.exists() && !f2.delete()) {
					Logger.logWarn("Could not delete '" + f2.getAbsolutePath() + "'");
				}
			}
		}
		if (parentFolder.list() != null && parentFolder.list().length == 0) {
			parentFolder.delete();
		}
	}

	protected void writeDataList(List<?> dataList) {

		if (dataList.isEmpty() || cacheFolder == null) {
			return;
		}

		try {
			File outFile = new File(cacheFolder, String.format("%s%06d%s", getCacheFilePrefix(), continousFileCounter++, CACHE_FILE_SUFFIX));
			Output output = new Output(new FileOutputStream(outFile));
			kryo.writeObject(output, dataList);
			double targetCacheBytes = PreferenceUtil.getInt(IPreferenceConstants.CACHE_FILE_SIZE_TARGET) * 1E6;
			long filesize = outFile.length();
			if (filesize < targetCacheBytes * 0.9) {
				updateIntervalMillis += Math.min(10000, targetCacheBytes / filesize * 3000);
			} else if (outFile.length() > targetCacheBytes * 1.1) {
				updateIntervalMillis -= Math.min(10000, filesize / targetCacheBytes * 3000);
			}
			output.close();
		} catch (IOException e) {
			Logger.logError("Could not write statistics data to cache file", e);
		}
	}

	protected File[] listCachedFiles() {
		if (cacheFolder == null) {
			return null;
		}
		return cacheFolder.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return name.startsWith(getCacheFilePrefix()) && dir.getAbsolutePath().contains(getCacheFolderPrefix());
			}
		});
	}

	/**
	 * Finds the next mat file.
	 *
	 * @param matFile
	 *            the original format of the filename with index 1
	 * @param createNew
	 *            if <code>true</code>, create a new file with next free index (file does not yet exist). if <code>false</code>, find file
	 *            with highest index matching pattern
	 * @return the file
	 */
	protected File findMatFile(File matFile, boolean createNew) {
		int i = 1;
		while (matFile.exists()) {
			matFile = getMatFileIndex(matFile, i++);
		}
		if (!createNew) {
			// one index back
			matFile = getMatFileIndex(matFile, Math.max(1, i - 2));
		}
		return matFile;
	}

	protected File getMatFileIndex(File originalFile, int index) {
		return new File(originalFile.getParentFile(), originalFile.getName().replaceAll("\\.\\d\\.mat", "." + index + ".mat"));
	}

	protected String getVarName(long objectId, String postFix) {
		return getVarName(objectId, postFix, getVariablePrefix());
	}

	protected String getVarName(long objectId, String postFix, String variablePrefix) {
		if (StringUtil.isNotNullOrEmpty(postFix)) {
			return String.format("%s%06d%s", variablePrefix, objectId, postFix);
		}

		return String.format("%s%06d", variablePrefix, objectId);
	}

	protected void collectRemainingData() {
		try {
			Logger.logInfo("Waiting for data caching to finish...");
			dataCollectionLock.lock();
			Logger.logInfo("Data caching finished. Writing remaining data");
			this.dataList = new CopyOnWriteArrayList<>();
			collectStatistics(0);
			collectAdditionalData(0);
			writeDataList(dataList);
			this.dataList = new CopyOnWriteArrayList<>();
			Logger.logInfo("Remaining data successfully written");
		} finally {
			dataCollectionLock.unlock();
		}
	}

	protected void cleanup() {
		// Perform cleanup actions in subclasses if required
	}

	protected void collectAdditionalData(int itemsToKeep) {
		// Collect additional data in subclasses if required
	}

	protected void createCacheFolder() {
		cacheFolder = new File(model.getOutputFolder(), RUNNING_PREFIX + getCacheFolderPrefix() + DateUtil.formatForFile(model.getStartDate()));
		if (!cacheFolder.mkdirs()) {
			Logger.logError("Could not create cache folder '" + cacheFolder.getAbsolutePath() + "'");
		}
	}

	@Override
	public void doWorkWaitForFinish() {
		if (cacheFolder == null || !cacheFolder.exists()) {
			createCacheFolder();
		}
		try {
			dataCollectionLock.lock();
			this.dataList = new CopyOnWriteArrayList<>();
			collectStatistics(statisticsFetchSize);
			collectAdditionalData(additionalDataFetchSize);

			if (!dataList.isEmpty()) {
				writeDataList(dataList);
				this.dataList = new CopyOnWriteArrayList<>();
			}
		} finally {
			dataCollectionLock.unlock();
		}
	}

	@Override
	public void performFinish() {
		collectRemainingData();
		cleanup();

		// Rename cache folder (remove ~)
		if (cacheFolder != null) {
			File renamedCache = new File(cacheFolder.getParentFile(), cacheFolder.getName().replace(RUNNING_PREFIX, ""));
			if (cacheFolder.renameTo(renamedCache)) {
				cacheFolder = renamedCache;
			} else {
				Logger.logError("Could not rename cache folder");
			}
		}

		kryo.reset();
		this.dataList = new CopyOnWriteArrayList<>();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see at.fhhagenberg.mc.traffsim.statistics.ICachingStatisticsCollector#convertStatistics(java.io.File, java.lang.String, boolean,
	 * org.eclipse.core.runtime.IProgressMonitor, boolean, boolean)
	 */
	@Override
	public abstract IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException;

	protected abstract void collectStatistics(int itemsToKeep);

	public abstract String getCacheFolderPrefix();

	protected abstract String getCacheFilePrefix();

	protected abstract String getVariablePrefix();
}

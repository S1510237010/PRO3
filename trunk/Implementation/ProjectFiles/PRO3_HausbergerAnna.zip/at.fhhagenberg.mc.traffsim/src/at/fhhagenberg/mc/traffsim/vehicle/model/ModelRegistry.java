package at.fhhagenberg.mc.traffsim.vehicle.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ModelRegistry {
	HashMap<String, Object> models = new HashMap<>();

	public void registerModel(String identifier, Object model) {
		models.put(identifier, model);
	}

	public <T> T getModel(String identifier, Class<T> clazz) {
		if(identifier == null || !models.containsKey(identifier)){
			return null;
		}
		
		try {
			return clazz.cast(models.get(identifier));
		} catch (ClassCastException ex) {
			return null;
		}
	}

	public <T> List<T> getModels(Class<T> clazz) {
		List<T> typeModels = new ArrayList<>();
		for (Object o : models.values()) {
			T casted;
			try {
				casted = clazz.cast(o);
			} catch (ClassCastException e) {
				continue;
			}
			typeModels.add(casted);
		}
		return typeModels;
	}

	public Object getModel(String identifier) {
		return models.get(identifier);
	}
}

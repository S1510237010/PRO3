package at.fhhagenberg.mc.traffsim.generator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Implementation of {@link AbstractVehicleGenerator} which adds (pre-defined) vehicles to a simulation. The vehicles to be added are
 * obtained from the configuration file <i>vehicles.xml</i>.
 *
 * @author Christian Backfrieder
 */
public class PredefinedVehicleGenerator extends AbstractVehicleGenerator {

	/** The initial list of vehicles as obtained from the configuration file */
	protected List<? extends Vehicle> initialVehicles = new ArrayList<>();

	/** The list of vehicles still to be generated */
	protected List<? extends Vehicle> vehicles = new ArrayList<>();

	/**
	 * Gets the list of {@link Vehicle}s which has been obtained from the configuration file.
	 *
	 * @return the original list of vehicles
	 */
	public List<? extends Vehicle> getInitialVehicles() {
		return initialVehicles;
	}

	@Override
	public boolean hasMoreVehicles() {
		return vehicles.size() > 0;
	}

	/**
	 * Sets the {@link Vehicle}s to be generated.
	 *
	 * @param vehicles
	 *            the list of vehicles to be be generated
	 */
	public void setVehicles(List<? extends Vehicle> vehicles) {
		Collections.sort(vehicles, new Comparator<Vehicle>() {

			@Override
			public int compare(Vehicle o1, Vehicle o2) {
				return o1.getStartTime().compareTo(o2.getStartTime());
			}
		});

		this.vehicles = vehicles;
		initialVehicles = new ArrayList<>(vehicles);

		for (Vehicle v : vehicles) {
			if (!v.isObstacle() && v.getRoute().getInitialSegment() == null) {
				Logger.logError("Unknown initial segment of vehicle #" + v.getUniqueId() + " (" + v.getLabel() + ")");
			}
		}
	}

	@Override
	public void timeStep(double dt, Date time, double runTime) {
		for (Iterator<? extends Vehicle> vIt = vehicles.iterator(); vIt.hasNext();) {
			Vehicle generated = vIt.next();
			if (generated != null) {
				if (time.after(generated.getStartTime())) {
					notifyVehicleGenerated(generated);
					model.getVehicleProcessor().scheduleVehicle(generated.getRoute().getInitialSegment(), generated);
					vIt.remove();
				}
			} else {
				Logger.logWarn("Read null vehicle");
				vIt.remove();
			}

		}
	}

	@Override
	public void dispose() {
		initialVehicles.clear();
	}
}
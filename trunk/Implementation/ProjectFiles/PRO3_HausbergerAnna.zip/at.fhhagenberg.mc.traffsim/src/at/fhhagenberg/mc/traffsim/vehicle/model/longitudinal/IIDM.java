package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.IIDMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;

public class IIDM extends LongitudinalModel {

	private IIDMData data;

	public IIDM(){
		
	}
	
	public IIDM(IIDMData data) {
		super(data.getIdentifier());
		fullname = data.getFullname();
		this.data = data;
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {

		final double localT = alphaT * data.gettMin();
		final double localTargetSpeed = Math.min(alphaV0 * data.getvTarget(), speedLimit);
		final double localA = alphaA * data.getComfortableAcc();

		final double sstar = data.getsMin() + Math.max(localT * v + 0.5 * v * dv / Math.sqrt(localA * -data.getSafeDec()), 0.);
		final double z = sstar / Math.max(s, 0.01);
		final double accEmpty = v <= localTargetSpeed ? localA * (1 - Math.pow(v / Math.max(localTargetSpeed, 1e-5), data.getDelta()))
				: data.getSafeDec() * (1 - Math.pow(localTargetSpeed / v, localA * data.getDelta() / -data.getSafeDec()));
		final double accPos = accEmpty * (1. - Math.pow(z, Math.min(2 * localA / accEmpty, 100.)));
		final double accInt = localA * (1 - z * z);

		double accIIDM = 0;

		if (v <= localTargetSpeed) {
			if (z < 1) {
				accIIDM = accPos;
			} else {
				accIIDM = accInt;
			}
		} else {
			if (z < 1) {
				accIIDM = accEmpty;
			} else {
				accIIDM = accInt + accEmpty;
			}
		}

		return accIIDM;
	}

	@Override
	public LongitudinalModel createCopyFor(double targetSpeed) {
		IIDMData copy = new Kryo().copy(data);
		copy.setvTarget(targetSpeed);
		return new IIDM(copy);
	}

	@Override
	public LongitudinalModelData getModelData() {
		return data;
	}

	@Override
	public boolean isSafeAcceleration(double acceleration) {
		return acceleration < data.getMaxAcc() && acceleration > data.getMaxDec();
	}
}
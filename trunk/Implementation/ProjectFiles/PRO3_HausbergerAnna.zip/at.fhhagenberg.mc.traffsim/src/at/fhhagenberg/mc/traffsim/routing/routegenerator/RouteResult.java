package at.fhhagenberg.mc.traffsim.routing.routegenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.routing.SimpleRouteResult;

public class RouteResult extends SimpleRouteResult
		implements Comparable<RouteResult> {
	private List<RoadSegment> segments;
	private List<Long> nodeIds;
	private List<Float> cost;
	private Map<Long, RoadSegment> startNodeMapping = new HashMap<>();
	private double totalCost;

	public RouteResult(List<RoadSegment> segments, List<Float> cost) {
		this.segments = segments;
		this.cost = cost;
		updateData();
	}

	public RouteResult(SimpleRouteResult route, RoadNetwork network) {
		super(route.getRoutingIds(), route.getReverse(), route.getCost());
		segments = new ArrayList<>();
		for (int i = 0; i < routingIds.size(); i++) {
			segments.add(network.getRoadSegmentByRoutingId(routingIds.get(i),
					reverse.get(i)));
		}
		cost = route.getCost();
		updateData();
	}

	private void updateData() {
		nodeIds = new ArrayList<>();
		routingIds = new ArrayList<>();
		reverse = new ArrayList<>();
		if (segments == null || segments.size() == 0) {
			return;
		}
		nodeIds.add(segments.get(0).getStartNode().getId());
		for (RoadSegment seg : segments) {
			nodeIds.add(seg.getEndNode().getId());
			startNodeMapping.put(seg.getStartNode().getId(), seg);
			routingIds.add(seg.getRoutingId());
			reverse.add(seg.isOsmReverse());
		}
		for (Float c : cost) {
			totalCost += c;
		}
	}

	public List<Long> getNodeIds() {
		return nodeIds;
	}

	public List<RoadSegment> getSegments() {
		return segments;
	}

	public RoadSegment getRoutingSegment(long startNode) {
		return startNodeMapping.get(startNode);
	}

	public RouteResult subRoute(int startIndex, int endIndex) {
		try {
			RouteResult newRoute = new RouteResult(
					new ArrayList<>(segments.subList(startIndex, endIndex)),
					new ArrayList<>(cost.subList(startIndex, endIndex)));
			newRoute.updateData();
			return newRoute;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public RouteResult copyAndAppend(RouteResult toAppend) {
		ArrayList<RoadSegment> newSegments = new ArrayList<>(segments);
		List<Float> newCost = new ArrayList<>(cost);
		if (toAppend != null) {
			newSegments.addAll(toAppend.getSegments());
			newCost.addAll(toAppend.cost);
		}

		return new RouteResult(newSegments, newCost);
	}

	public double getTotalCost() {
		return totalCost;
	}

	@Override
	public int compareTo(RouteResult o) {
		return new Double(totalCost).compareTo(o.getTotalCost());
	}

	@Override
	public String toString() {
		return super.toString() + " | Nd: " + nodeIds.toString();
	}
}

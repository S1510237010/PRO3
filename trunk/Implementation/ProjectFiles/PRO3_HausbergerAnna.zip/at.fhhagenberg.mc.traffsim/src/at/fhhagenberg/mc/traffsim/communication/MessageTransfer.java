package at.fhhagenberg.mc.traffsim.communication;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

import at.fhhagenberg.mc.traffsim.communication.messaging.Message;
import at.fhhagenberg.mc.traffsim.model.ISimulationTimeProvider;
import at.fhhagenberg.mc.util.StringUtil;

public class MessageTransfer implements Delayed {
	ICommunicationPartner sender, receiver;
	Message<?> message;
	private ISimulationTimeProvider timeProvider;
	private long endTime;
	private long startTime;

	public MessageTransfer(ICommunicationPartner sender, ICommunicationPartner receiver, Message<?> message) {
		super();
		this.sender = sender;
		this.receiver = receiver;
		this.message = message;
	}

	public ICommunicationPartner getSender() {
		return sender;
	}

	public void setSender(ICommunicationPartner sender) {
		this.sender = sender;
	}

	public ICommunicationPartner getReceiver() {
		return receiver;
	}

	public void setReceiver(ICommunicationPartner receiver) {
		this.receiver = receiver;
	}

	public Message<?> getMessage() {
		return message;
	}

	public void setMessage(Message<?> message) {
		this.message = message;
	}

	@Override
	public int compareTo(Delayed o) {
		return new Long(endTime).compareTo(((MessageTransfer) o).getEndTime());
	}

	@Override
	public long getDelay(TimeUnit unit) {
		long diff = endTime - timeProvider.getCurrentSimTime().getTime();
		return unit.convert(diff, TimeUnit.MILLISECONDS);
	}

	/**
	 * @param delay
	 *            in {@link TimeUnit#MILLISECONDS}
	 * @param timeProvider
	 *            the time provider for simulation time (for determination of the delay)
	 */
	public void setDelay(long delay, ISimulationTimeProvider timeProvider) {
		this.startTime = timeProvider.getCurrentSimTime().getTime();
		this.endTime = startTime + delay;
		this.timeProvider = timeProvider;
	}

	@Override
	public String toString() {
		return String.format("MSG #%d (%s): %s -> %s", message.getId(),
				StringUtil.humanReadableByteCount(message.getPayload().getSize(), false),
				sender != null ? sender.getCommName() : "<undefined>", receiver != null ? receiver.getCommName() : "<undefined>");
	}

	public long getStartTime() {
		return startTime;
	}

	public long getEndTime() {
		return endTime;
	}

}

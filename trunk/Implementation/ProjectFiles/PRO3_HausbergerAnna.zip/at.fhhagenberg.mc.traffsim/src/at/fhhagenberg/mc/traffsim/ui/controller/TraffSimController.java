package at.fhhagenberg.mc.traffsim.ui.controller;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.JSpinner;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;

import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.ui.IImageKeys;
import at.fhhagenberg.mc.traffsim.ui.IResizeListener;
import at.fhhagenberg.mc.traffsim.ui.UiConstants;
import at.fhhagenberg.mc.traffsim.ui.UiFlag;
import at.fhhagenberg.mc.traffsim.ui.UiModel;
import at.fhhagenberg.mc.traffsim.ui.osm.TileType;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.SimulationView;
import at.fhhagenberg.mc.traffsim.util.ImageUtil;

/**
 * Controller of MVC pattern. Receives events from SimulationView.
 *
 * @author Christian
 *
 */
public class TraffSimController extends SelectionAdapter implements MouseListener, MouseMotionListener, MouseWheelListener, IResizeListener,
		KeyListener, ChangeListener, ControlListener, IPropertyChangeListener, ISimulationStateListener {
	private UiModel uiModel = null;
	private int mouseOptionState = UiConstants.INITIAL_MOUSE_STATE;
	private Point lastPosition;
	private Rectangle zoomRectangle;
	private int oldMouseState;
	private SimulationView simView;
	private boolean simulationRunning;

	/**
	 * Constructor which receives the model to communicate with.
	 *
	 * @param uiModel
	 */
	public TraffSimController(UiModel uiModel) {
		this.uiModel = uiModel;
	}

	public void setRunning(boolean running, Button b) {
		simulationRunning = running;
		if (simulationRunning) {
			b.setImage(ImageUtil.getSWTImage(IImageKeys.PAUSE));
		} else {
			b.setImage(ImageUtil.getSWTImage(IImageKeys.PLAY));
		}
		uiModel.setSimulationRunning(running);
	}

	/**
	 * handles mouse clicks
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		int modifiers = e.getModifiers();

		if ((modifiers & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK) {
			if (mouseOptionState == UiConstants.MOUSE_STATE_SELECT || mouseOptionState == UiConstants.MOUSE_STATE_ADD_OBSTRUCTION) {
				uiModel.clickedOn(e.getPoint(), mouseOptionState);
			}
		}

		if (e.getButton() == 4) {
			uiModel.zoom(1.05);
		}
		if (e.getButton() == 5) {
			uiModel.zoom(0.95);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// not used
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// not used
	}

	@Override
	public void mousePressed(MouseEvent _e) {
		/** store position of last click for zooming and dragging */
		lastPosition = _e.getPoint();
		/** switch to drag mode for right mouse button */
		if (_e.getButton() == MouseEvent.BUTTON3) {
			oldMouseState = mouseOptionState;
			mouseOptionState = UiConstants.MOUSE_STATE_DRAG;
		}
	}

	@Override
	public void mouseReleased(MouseEvent _e) {
		if (_e.getButton() == MouseEvent.BUTTON3) {
			/** restore mouse state */
			mouseOptionState = oldMouseState;
			return;
		}
		if (mouseOptionState == UiConstants.MOUSE_STATE_DRAG) {
			/** store last position of mouse */
			lastPosition = _e.getPoint();
		} else if (mouseOptionState == UiConstants.MOUSE_STATE_ZOOM && uiModel != null) {
			/**
			 * zoom was finished -> remove zoom rectangle from view and zoom to it
			 */
			uiModel.setZoomRectangle(null);
			uiModel.zoomTo(zoomRectangle);
		} else if (mouseOptionState == UiConstants.MOUSE_STATE_SELECT && uiModel != null && zoomRectangle != null) {
			uiModel.setZoomRectangle(null);
			uiModel.selectArea(zoomRectangle);
		}
	}

	@Override
	public void mouseDragged(MouseEvent _e) {
		/** choose action depending on selected mouse option */
		switch (mouseOptionState) {
		case UiConstants.MOUSE_STATE_DRAG:
			/** if button1 or button3 was pressed, scroll to moved position */
			if (((_e.getModifiers() & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK)
					|| ((_e.getModifiers() & InputEvent.BUTTON3_MASK) == InputEvent.BUTTON3_MASK)) {
				simView.getDrawingPanel().setCursor(ImageUtil.getCursor(Cursor.MOVE_CURSOR));
				if (lastPosition != null) {
					uiModel.scrollDiagonal(_e.getX() - lastPosition.x, (_e.getY() - lastPosition.y));
				}
				lastPosition = _e.getPoint();
			}
			break;
		case UiConstants.MOUSE_STATE_SELECT:
		case UiConstants.MOUSE_STATE_ADD_OBSTRUCTION:
		case UiConstants.MOUSE_STATE_ZOOM:
			if ((_e.getModifiers() & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK && lastPosition != null) {
				/** set zoom rectangle to selected area to draw it */
				zoomRectangle = new Rectangle(lastPosition.x, lastPosition.y, Math.abs(_e.getPoint().x - lastPosition.x),
						Math.abs(_e.getPoint().y - lastPosition.y));
				/** correct origin of rectangle if draw direction is left */
				if (_e.getPoint().x < lastPosition.x) {
					zoomRectangle.x = _e.getPoint().x;
				}
				/** correct origin of rect if draw direction is up */
				if (_e.getPoint().y < lastPosition.y) {
					zoomRectangle.y = _e.getPoint().y;
				}
				uiModel.setZoomRectangle(zoomRectangle);
			}
			break;
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		switch (mouseOptionState) {
		case UiConstants.MOUSE_STATE_DRAG:
			simView.getDrawingPanel().setCursor(ImageUtil.getCursor(Cursor.MOVE_CURSOR));
			break;
		case UiConstants.MOUSE_STATE_SELECT:
			simView.getDrawingPanel().setCursor(ImageUtil.getCursor(Cursor.HAND_CURSOR));
			break;
		case UiConstants.MOUSE_STATE_ADD_OBSTRUCTION:
			simView.getDrawingPanel().setCursor(ImageUtil.getCursor(Cursor.HAND_CURSOR));
			break;
		case UiConstants.MOUSE_STATE_ZOOM:
			simView.getDrawingPanel().setCursor(ImageUtil.getCursor(Cursor.DEFAULT_CURSOR));
			break;

		default:
			break;
		}
	}

	/**
	 * handles mouse-wheel-events for zooming
	 */
	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		/** zoom in or out - depending on wheel rotation direction */
		if (e.getWheelRotation() <= 0) {
			uiModel.zoom(e.getPoint(), UiConstants.ZOOM_FACTOR * -e.getWheelRotation(), true);
		} else {
			uiModel.zoom(e.getPoint(), 1 / (UiConstants.ZOOM_FACTOR * e.getWheelRotation()), true);
		}

	}

	@Override
	public void windowSizeChanged() {
		uiModel.updateView(true);
	}

	@Override
	public void windowSizeInitialized() {
		uiModel.zoomToFit();
	}

	private int parseScale(String entered) {
		String text = entered.replaceAll(" ", "");
		if (text.indexOf(':') == -1) {
			return Integer.parseInt(text);
		}
		return Integer.parseInt(text.split(":")[1]);
	}

	public void setView(SimulationView _view) {
		simView = _view;
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		if (e.getSource() instanceof JSpinner) {
			JSpinner spinner = ((JSpinner) e.getSource());
			if (spinner.getName().equals(UiConstants.SPINNER_RESOLUTION)) {
				uiModel.setResolution((int) spinner.getValue());
			}

		}
	}

	@Override
	public void widgetSelected(SelectionEvent e) {
		Object actionData = ((Widget) e.getSource()).getData();
		if (actionData.equals(UiConstants.ACTION_SCROLL_UP)) {
			uiModel.scrollVertical(-UiConstants.SCROLL_DELTA);
		} else if (actionData.equals(UiConstants.ACTION_SCROLL_DOWN)) {
			uiModel.scrollVertical(UiConstants.SCROLL_DELTA);
		} else if (actionData.equals(UiConstants.ACTION_SCROLL_LEFT)) {
			uiModel.scrollHorizontal(UiConstants.SCROLL_DELTA);
		} else if (actionData.equals(UiConstants.ACTION_SCROLL_RIGHT)) {
			uiModel.scrollHorizontal(-UiConstants.SCROLL_DELTA);
		} else if (actionData.equals(UiConstants.ACTION_ZOOM_IN)) {
			uiModel.zoom(UiConstants.ZOOM_FACTOR, true);
		} else if (actionData.equals(UiConstants.ACTION_ZOOM_OUT)) {
			uiModel.zoom(1 / UiConstants.ZOOM_FACTOR, true);
		} else if (actionData.equals(UiConstants.ACTION_ZOOM_TO_FIT)) {
			uiModel.zoomToFit();
		} else if (actionData.equals(UiConstants.ACTION_STORE_IMAGE)) {
			// uiModel.storeImage(imageType);
		} else if (actionData.equals(UiConstants.ACTION_START_SIMULATION)) {
			if (e.getSource() instanceof Button) {
				setRunning(!simulationRunning, (Button) e.getSource());
			}
		} else if (actionData.equals(UiConstants.ACTION_MOUSE_DRAG)) {
			mouseOptionState = UiConstants.MOUSE_STATE_DRAG;
		} else if (actionData.equals(UiConstants.ACTION_MOUSE_SELECT)) {
			mouseOptionState = UiConstants.MOUSE_STATE_SELECT;
		} else if (actionData.equals(UiConstants.ACTION_MOUSE_ZOOM)) {
			mouseOptionState = UiConstants.MOUSE_STATE_ZOOM;
		} else if (actionData.equals(UiConstants.ACTION_MOUSE_ADD_OBSTRUCTION)) {
			mouseOptionState = UiConstants.MOUSE_STATE_ADD_OBSTRUCTION;
		} else if (actionData.equals(UiConstants.ACTION_DELAY)) {
			if (e.getSource() instanceof Spinner) {
				uiModel.setDelay(((Spinner) e.getSource()).getSelection());
			}
		} else if (actionData.equals(UiConstants.ACTION_RESOLUTION)) {
			if (e.getSource() instanceof Spinner) {
				uiModel.setResolution(((Spinner) e.getSource()).getSelection());
			}
		} else if (actionData.equals(UiConstants.ACTION_SHOW_OSM_MAP)) {
			Button showOsm = (Button) e.getSource();
			uiModel.setShowOsmMap(showOsm.getSelection());
		} else if (actionData.equals(UiConstants.ACTION_TILE_TYPE_CHANGE)) {
			Combo tiletype = (Combo) e.getSource();
			uiModel.setTileType(TileType.fromString(tiletype.getText()));
		}
	}

	@Override
	public void controlMoved(ControlEvent e) {
		// unused
	}

	@Override
	public void controlResized(ControlEvent e) {
		if (uiModel != null) {
			uiModel.updateView(true);
		}
	}

	@Override
	public void propertyChange(PropertyChangeEvent event) {
		if (event.getProperty().equals(IPreferenceConstants.VEHICLE_PRINT)) {
			if (event.getNewValue().equals(IPreferenceConstants.PRINT_DETAILS)) {
				uiModel.setUiFlag(UiFlag.VEHICLE_DETAILS, true);
				uiModel.setUiFlag(UiFlag.VEHICLE_IDS, false);
			} else if (event.getNewValue().equals(IPreferenceConstants.PRINT_IDS)) {
				uiModel.setUiFlag(UiFlag.VEHICLE_DETAILS, false);
				uiModel.setUiFlag(UiFlag.VEHICLE_IDS, true);
			} else {
				uiModel.setUiFlag(UiFlag.VEHICLE_DETAILS, false);
				uiModel.setUiFlag(UiFlag.VEHICLE_IDS, false);
			}
		} else if (event.getProperty().equals(IPreferenceConstants.PRINT_IDS)) {
			uiModel.setUiFlag(UiFlag.VEHICLE_IDS, (boolean) event.getNewValue());
		} else if (event.getProperty().equals(IPreferenceConstants.BACKGROUND_COLOR)) {
		} else if (event.getProperty().equals(IPreferenceConstants.DEBUG_LANE_INFO)) {
			uiModel.setUiFlag(UiFlag.LANE_DEBUG, (boolean) event.getNewValue());
		} else if (event.getProperty().equals(IPreferenceConstants.DEBUG_ROAD_INFO)) {
			uiModel.setUiFlag(UiFlag.ROADSEGMENT_DEBUG, (boolean) event.getNewValue());
		} else if (event.getProperty().equals(IPreferenceConstants.DEBUG_JUNCTION_INFO)) {
			uiModel.setUiFlag(UiFlag.JUNCTION_DEBUG, (boolean) event.getNewValue());
		} else if (event.getProperty().equals(IPreferenceConstants.TRANSPARENT_ROADS)) {
			uiModel.setUiFlag(UiFlag.TRANSPARENT_ROADS, (boolean) event.getNewValue());
		} else if (event.getProperty().equals(IPreferenceConstants.PRINT_SPEED_LIMITS)) {
			uiModel.setUiFlag(UiFlag.SPEED_LIMITS, (boolean) event.getNewValue());
		} else if (event.getProperty().equals(IPreferenceConstants.SHOW_LOOP_DETECTORS)) {
			uiModel.setUiFlag(UiFlag.SHOW_DETECTORS, (boolean) event.getNewValue());
		}

		uiModel.updateView(true);
	}

	@Override
	public void keyPressed(org.eclipse.swt.events.KeyEvent _e) {
		if (_e.character == '\r') {
			if (_e.getSource() instanceof Text && ((Text) _e.getSource()).getData().equals(UiConstants.FIELD_SCALE)) {
				Text field = (Text) _e.getSource();
				int factor = parseScale(field.getText());
				uiModel.zoomScale(factor);
			}
		}
	}

	@Override
	public void keyReleased(org.eclipse.swt.events.KeyEvent e) {
		// unused
	}

	@Override
	public void simulationStateChanged(SimulationModel model, SimulationState oldState, SimulationState newState) {
		switch (newState) {
		case STARTED:
		case CONTINUED:
			simulationRunning = true;
			break;
		case ENDED:
		case COMPLETED:
		case PAUSED:
		case INITIAL:
		case ABORTED:
		case LOADED:
		case LOADING:
			simulationRunning = false;
			break;
		default:
			assert false : "Missing case in switch!";
			break;
		}
	}
}

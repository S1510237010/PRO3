package at.fhhagenberg.mc.traffsim.util;

import java.awt.Color;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceStore;
import org.eclipse.jface.util.IPropertyChangeListener;

import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;

/**
 * Utility class encapsulating the access to the application's preference store. Used for maintaining user settings in the scope of the
 * application, even accross application starts.
 *
 * @author Christian Backfrieder
 */
public class PreferenceUtil {

	/** Instance of the preference store */
	private static IPreferenceStore PREF_STORE = TraffSimCorePlugin.getDefault() == null ? new PreferenceStore()
			: TraffSimCorePlugin.getDefault().getPreferenceStore();

	public static boolean containsKey(String key) {
		return PREF_STORE.contains(key);
	}

	/**
	 * Gets a boolean value in the preference store identified by the given key.
	 *
	 * @param key
	 *            the key of the requested preference setting
	 * @return the boolean value of the requested preference
	 */
	public static final boolean getBoolean(String key) {
		if (PREF_STORE.contains(key)) {
			return PREF_STORE.getBoolean(key);
		}

		return PREF_STORE.getDefaultBoolean(key);
	}

	/**
	 * Gets a color value in the preference store identified by the given key.
	 *
	 * @param key
	 *            the key of the requested preference setting
	 * @return the color value of the requested preference
	 */
	public static final Color getColor(String key) {
		try {
			String[] color = TraffSimCorePlugin.getDefault().getPreferenceStore().getString(key).split(",");
			final int[] ints = new int[color.length];

			for (int i = 0; i < color.length; i++) {
				ints[i] = Integer.parseInt(color[i]);
			}

			return new Color(ints[0], ints[1], ints[2]);
		} catch (Exception e) {
			return Color.BLACK;
		}
	}

	/**
	 * Gets a double value in the preference store identified by the given key.
	 *
	 * @param key
	 *            the key of the requested preference setting
	 * @return the double value of the requested preference
	 */
	public static final double getDouble(String key) {
		if (PREF_STORE.contains(key)) {
			return PREF_STORE.getDouble(key);
		}

		return PREF_STORE.getDefaultDouble(key);
	}

	/**
	 * Gets an integer value in the preference store identified by the given key.
	 *
	 * @param key
	 *            the key of the requested preference setting
	 * @return the integer value of the requested preference
	 */
	public static final int getInt(String key) {
		if (PREF_STORE.contains(key)) {
			return PREF_STORE.getInt(key);
		}

		return PREF_STORE.getDefaultInt(key);
	}

	/**
	 * Gets an integer value in the preference store identified by the given key.
	 *
	 * @param key
	 *            the key of the requested preference setting
	 * @param defaultValue
	 *            the default value to be used if a setting is not found using the provided key
	 * @return the integer value of the requested preference
	 */
	public static final int getInt(String key, int defaultValue) {
		if (PREF_STORE.contains(key)) {
			return PREF_STORE.getInt(key);
		}

		return defaultValue;
	}

	/**
	 * Gets a string value in the preference store identified by the given key.
	 *
	 * @param key
	 *            the key of the requested preference setting
	 * @return the string value of the requested preference
	 */
	public static final String getString(String key) {
		if (PREF_STORE.contains(key)) {
			return PREF_STORE.getString(key);
		}

		return PREF_STORE.getDefaultString(key);
	}

	/**
	 * Gets a string value in the preference store identified by the given key.
	 *
	 * @param key
	 *            the key of the requested preference setting
	 * @param defaultValue
	 *            the default value to be used if a setting is not found using the provided key
	 * @return the string value of the requested preference
	 */
	public static final String getString(String key, String defaultValue) {
		if (PREF_STORE.contains(key)) {
			return PREF_STORE.getString(key);
		}

		return defaultValue;
	}

	/**
	 * Initializes the preference store with default values.
	 */
	public static void initializeDefaultPreferences() {
		PREF_STORE.setDefault(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL, IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL);
		PREF_STORE.setDefault(IPreferenceConstants.BACKGROUND_ALPHA, IPreferenceConstants.DEFAULT_BACKGROUND_ALPHA);
		PREF_STORE.setDefault(IPreferenceConstants.BACKGROUND_COLOR, IPreferenceConstants.DEFAULT_BACKGROUND_COLOR);
		PREF_STORE.setDefault(IPreferenceConstants.AUTO_LOAD_ALTITUDES, IPreferenceConstants.DEFAULT_AUTO_LOAD_ALTITUDES);
		PREF_STORE.setDefault(IPreferenceConstants.JUNCTION_MERGE_LIMIT, IPreferenceConstants.DEFAULT_JUNCTION_MERGE_LIMIT);
		PREF_STORE.setDefault(IPreferenceConstants.SHOW_DETAIL_UPON_SELECTION, IPreferenceConstants.DEFAULT_SHOW_DETAILS_UPON_SELECTION);
		PREF_STORE.setDefault(IPreferenceConstants.CREATE_REVERSE_CONNECTOR, IPreferenceConstants.DEFAULT_CREATE_REVERSE_CONNECTOR);
		PREF_STORE.setDefault(IPreferenceConstants.RESET_GEOMETRY_ON_LOAD, IPreferenceConstants.DEFAULT_RESET_GEOMETRY_ON_LOAD);
		PREF_STORE.setDefault(IPreferenceConstants.SHOW_LOADING_OPTIONS_DIALOG, IPreferenceConstants.DEFAULT_SHOW_LOADING_OPTIONS_DIALOG);
		PREF_STORE.setDefault(IPreferenceConstants.SELECTION_COORD_LAT_MIN, IPreferenceConstants.DEFAULT_SELECTION_COORD_LAT_MIN);
		PREF_STORE.setDefault(IPreferenceConstants.SELECTION_COORD_LAT_MAX, IPreferenceConstants.DEFAULT_SELECTION_COORD_LAT_MAX);
		PREF_STORE.setDefault(IPreferenceConstants.SELECTION_COORD_LON_MIN, IPreferenceConstants.DEFAULT_SELECTION_COORD_LON_MIN);
		PREF_STORE.setDefault(IPreferenceConstants.SELECTION_COORD_LON_MAX, IPreferenceConstants.DEFAULT_SELECTION_COORD_LON_MAX);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);

		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_TIME, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_TIME);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_DISTANCE, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_DISTANCE);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_POSITION, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_POSITION);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_SPEED, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_SPEED);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_ACCELERATION, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_ACCELERATION);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_FUEL_CONSUMPTION, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_FUEL_CONSUMPTION);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_CARBON_EMISSIONS, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_CARBON_EMISSIONS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_ROAD_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_DETAILED_JUNCTION_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_DETECTOR_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_DETECTOR_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.STATISTICS_CACHE_SIZE, IPreferenceConstants.DEFAULT_EVENTLOG_CACHE_SIZE);
		PREF_STORE.setDefault(IPreferenceConstants.SIMULATION_DELAY_MS, IPreferenceConstants.DEFAULT_DELAY_MS);
		PREF_STORE.setDefault(IPreferenceConstants.SIMULATION_RESOLUTION_MS, IPreferenceConstants.DEFAULT_RESOLUTION_MS);
		PREF_STORE.setDefault(IPreferenceConstants.DELETE_CANCELED_SIMULATION_RESULTS,
				IPreferenceConstants.DEFAULT_DELETE_CANCELED_SIMULATION_RESULTS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_DEBUG_EVENTS, IPreferenceConstants.DEFAULT_RECORD_DEBUG_EVENTS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_CPU_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_CPU_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.ENABLE_SCREEN_CAPTURE, IPreferenceConstants.DEFAULT_ENABLE_SCREEN_CAPTURE);
		PREF_STORE.setDefault(IPreferenceConstants.SCREEN_CAPTURE_SPEEDUP, IPreferenceConstants.DEFAULT_SCREEN_CAPTURE_SPEEDUP);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_MODEL_INPUT_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.ACTION_ON_CRASH, 0);
		PREF_STORE.setDefault(IPreferenceConstants.NUM_SIMULTANEOUS_SIMULATIONS, IPreferenceConstants.DEFAULT_NUM_SIMULTANEOUS_SIMULATIONS);
		PREF_STORE.setDefault(IPreferenceConstants.CLEANUP_BATCH_TEMP, IPreferenceConstants.DEFAULT_CLEANUP_BATCH_TEMP);
		PREF_STORE.setDefault(IPreferenceConstants.START_SOCKET_ON_APPLICATION_START, IPreferenceConstants.DEFAULT_START_SOCKET_ON_APPLICATION_START);
		PREF_STORE.setDefault(IPreferenceConstants.SOCKET_PORT, IPreferenceConstants.DEFAULT_SOCKET_PORT);
		PREF_STORE.setDefault(IPreferenceConstants.UI_UPDATE_TIME, IPreferenceConstants.DEFAULT_UI_UPDATE_TIME);
		PREF_STORE.setDefault(IPreferenceConstants.NUMBER_PARAMETER_SET_OUTPUTS, IPreferenceConstants.DEFAULT_NUMBER_PARAMETER_SET_OUTPUTS);
		PREF_STORE.setDefault(IPreferenceConstants.CACHE_FILE_SIZE_TARGET, IPreferenceConstants.DEFAULT_CACHE_FILE_SIZE_TARGET);
		PREF_STORE.setDefault(IPreferenceConstants.JUNCTION_LOG_CACHE_SIZE, IPreferenceConstants.DEFAULT_JUNCTION_LOG_CACHE_SIZE);
		PREF_STORE.setDefault(IPreferenceConstants.COMPRESS_CONFIG_IN_OUTPUT, true);
		PREF_STORE.setDefault(IPreferenceConstants.BOUND_SIMULATION_RUNTIME, IPreferenceConstants.DEFAULT_BOUND_SIMULATION_RUNTIME);
		PREF_STORE.setDefault(IPreferenceConstants.MAX_SIMULATION_RUNTIME, IPreferenceConstants.DEFAULT_MAX_SIMULATION_RUNTIME);
		PREF_STORE.setDefault(IPreferenceConstants.TOOL_EXECUTION_INTERVAL, IPreferenceConstants.DEFAULT_TOOL_EXECUTION_INTERVAL);
		PREF_STORE.setDefault(IPreferenceConstants.USE_CACHE_FOR_LOADING, false);
		PREF_STORE.setDefault(IPreferenceConstants.CONFIGURATIONS_BEFORE_RESTART, IPreferenceConstants.DEFAULT_CONFIGURATIONS_BEFORE_RESTART);
		PREF_STORE.setDefault(IPreferenceConstants.RESTART_AFTER_N_CONFIGURATIONS, IPreferenceConstants.DEFAULT_RESTART_AFTER_N_CONFIGURATIONS);
		PREF_STORE.setDefault(IPreferenceConstants.SINGLETHREADED_EXECUTION, IPreferenceConstants.DEFAULT_SINGLETHREADED_EXECUTION);

		PREF_STORE.setDefault(IPreferenceConstants.ENABLE_LOOP_DETECTORS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.QUEUE_MONITORING_TIME_HORIZON_S, IPreferenceConstants.DEFAULT_QUEUE_MONITORING_TIME_HORIZON_S);
		PREF_STORE.setDefault(IPreferenceConstants.LOOP_DETECTOR_SAMPLE_INTERVAL, IPreferenceConstants.DEFAULT_LOOP_DETECTOR_SAMPLE_INTERVAL_S);
		PREF_STORE.setDefault(IPreferenceConstants.TRAFFIC_LIGHT_DELAY, IPreferenceConstants.DEFAULT_TRAFFIC_LIGHT_DELAY_MS);
		PREF_STORE.setDefault(IPreferenceConstants.TRAFFIC_LIGHT_INTERGREEN_TIME, IPreferenceConstants.DEFAULT_INTERGREEN_TIME_MS);
		PREF_STORE.setDefault(IPreferenceConstants.TRAFFIC_LIGHT_YELLOW_TIME, IPreferenceConstants.DEFAULT_YELLOW_TIME_MS);
		PREF_STORE.setDefault(IPreferenceConstants.TRAFFIC_LIGHT_RED_YELLOW_TIME, IPreferenceConstants.DEFAULT_RED_YELLOW_TIME_MS);
		PREF_STORE.setDefault(IPreferenceConstants.TRAFFIC_LIGHT_PHASE_LENGTH, IPreferenceConstants.DEFAULT_PHASE_LENGTH_MS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_QUEUE_MONITORING_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_TRAFFIC_CONTROLLER_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_TRAFFIC_LIGHT_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_INDIVIDUAL_WAITING_TIMES, IPreferenceConstants.DEFAULT_RECORD_STATISTICS);
		PREF_STORE.setDefault(IPreferenceConstants.TRAFFIC_LIGHT_GREEN_TIME, IPreferenceConstants.DEFAULT_PHASE_LENGTH_MS);
		PREF_STORE.setDefault(IPreferenceConstants.TRAFFIC_LIGHT_RED_TIME, IPreferenceConstants.DEFAULT_PHASE_LENGTH_MS);
		PREF_STORE.setDefault(IPreferenceConstants.RESTART_SOCKET_AFTER_SIMSTART, IPreferenceConstants.DEFAULT_RESTART_SOCKET_AFTER_SIMSTART);
		PREF_STORE.setDefault(IPreferenceConstants.COPY_CONFIG_TO_OUTPUT, IPreferenceConstants.DEFAULT_COPY_CONFIG_TO_OUTPUT);
		PREF_STORE.setDefault(IPreferenceConstants.UI_UPDATE_ENABLED, IPreferenceConstants.DEFAULT_UI_UPDATE_ENABLED);
		PREF_STORE.setDefault(IPreferenceConstants.DISTRACTION_MODEL_ACTIVE, IPreferenceConstants.DEFAULT_DISTRACTION_MODEL_ACTIVE);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_DIST_TO_FRONT, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_DIST_TO_FRONT);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_VEHICLE_DISTRACTION_STATE, IPreferenceConstants.DEFAULT_RECORD_VEHICLE_DISTRACTION_STATE);
		PREF_STORE.setDefault(IPreferenceConstants.RECORD_DISTRACTION_STATISTICS, IPreferenceConstants.DEFAULT_RECORD_DISTRACTION_STATISTICS);
	}

	/**
	 * Sets the preference setting identified by the given key to the provided string value.
	 *
	 * @param key
	 *            the key identifying the preference setting to be updated
	 * @param value
	 *            the new string value
	 */
	public static final void set(String key, String value) {
		PREF_STORE.setValue(key, value);
	}

	/**
	 * Sets the preference setting identified by the given key to the provided boolean value.
	 *
	 * @param key
	 *            the key identifying the preference setting to be updated
	 * @param value
	 *            the new boolean value
	 */
	public static final void setBoolean(String key, boolean value) {
		PREF_STORE.setValue(key, value);
	}

	/**
	 * Sets the preference setting identified by the given key to the provided double value.
	 *
	 * @param key
	 *            the key identifying the preference setting to be updated
	 * @param value
	 *            the new double value
	 */
	public static final void setDouble(String key, double value) {
		PREF_STORE.setValue(key, value);
	}

	/**
	 * Sets the preference setting identified by the given key to the provided integer value.
	 *
	 * @param key
	 *            the key identifying the preference setting to be updated
	 * @param value
	 *            the new integer value
	 */
	public static final void setInt(String key, int value) {
		PREF_STORE.setValue(key, value);
	}

	/**
	 * Updates the instance of the preference store to the provided one.
	 *
	 * @param mockStore
	 *            a new prefrence store instance
	 */
	public static final void setMockPrefStore(PreferenceStore mockStore) {
		PREF_STORE = mockStore;
	}

	public static final void addPropertyChangeListener(IPropertyChangeListener listener) {
		PREF_STORE.addPropertyChangeListener(listener);
	}

	public static void removePropertyChangeListener(IPropertyChangeListener propListener) {
		PREF_STORE.removePropertyChangeListener(propListener);
	}
}
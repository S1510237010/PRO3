package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public interface IReactiveLongitudinalControl {
	void updateHistory(Vehicle vehicle, AccUpdateData accData);
}

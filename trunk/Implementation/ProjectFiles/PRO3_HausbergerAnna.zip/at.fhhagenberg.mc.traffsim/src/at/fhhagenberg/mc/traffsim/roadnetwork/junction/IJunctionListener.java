package at.fhhagenberg.mc.traffsim.roadnetwork.junction;

public interface IJunctionListener {

	default void onVehicleEnteredJunction(long junctionId, long roadSegmentId, long vehicleId) {

	}

	default void onVehicleLeftJunction(long junctionId, long vehicleId) {

	}
}

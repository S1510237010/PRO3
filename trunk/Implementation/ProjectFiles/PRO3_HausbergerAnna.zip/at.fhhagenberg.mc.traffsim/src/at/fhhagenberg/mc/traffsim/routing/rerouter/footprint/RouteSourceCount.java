package at.fhhagenberg.mc.traffsim.routing.rerouter.footprint;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Mapping of route source ids (mostly road segment ids) to number of vehicles coming from this route, used by
 * {@link TimeDynamicFootprintGenerator}
 * 
 * @author Christian Backfrieder
 * 
 */
public class RouteSourceCount {
	private List<Long> sources = new CopyOnWriteArrayList<>();
	private List<Integer> count = new CopyOnWriteArrayList<>();

	public long sum() {
		long sum = 0;
		for (Integer cnt : count) {
			sum += cnt;
		}
		return sum;
	}

	public void updateItem(long segId, int summand) {
		if (sources.contains(segId)) {
			int index = sources.indexOf(segId);
			Integer cnt = count.get(index);
			cnt += summand;
			count.set(index, Math.max(0, cnt));
		} else {
			sources.add(segId);
			count.add(Math.max(0, summand));
		}
	}

	public int getNumberOfOccupiedSources() {
		int num = 0;
		for (int i = 0; i < sources.size() && i < count.size(); i++) {
			if (count.get(i) > 0) {
				num++;
			}
		}
		return num;
	}

	@Override
	public String toString() {
		StringBuffer str = new StringBuffer();
		str.append("Sum: ");
		str.append(sum());
		for (int i = 0; i < sources.size(); i++) {
			str.append(sources.get(i));
			str.append("-");
			str.append(count.get(i));
			str.append(", ");
		}
		str.setLength(str.length() - 2);
		return str.toString();
	}
}

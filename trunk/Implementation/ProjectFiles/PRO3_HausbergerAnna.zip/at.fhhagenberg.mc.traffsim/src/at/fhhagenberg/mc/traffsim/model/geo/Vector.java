package at.fhhagenberg.mc.traffsim.model.geo;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Simple vector class which provides basic vector operations in two dimensions.
 *
 * @author Christian Backfrieder
 */
@XStreamAlias("Vector")
public class Vector extends Location {

	/**
	 * Helping class mapping two double values or a {@link Vector} to integer
	 * values.
	 */
	public class Int {

		/** The x- and y-coordinate */
		int x, y;

		/**
		 * Maps the given double values onto two integer values
		 *
		 * @param x
		 *            the x-coordinate to be mapped
		 * @param y
		 *            the y-coordinate to be mapped
		 */
		public Int(double x, double y) {
			this.x = (int) x;
			this.y = (int) y;
		}

		/**
		 * Maps the given {@link Vector} onto two integer values
		 *
		 * @param v
		 *            the {@link Vector} to be mapped
		 */
		public Int(Vector v) {
			this(v.x, v.y);
		}
	}

	/** Unique identifier required for serialisation */
	private static final long serialVersionUID = 6426464711964255345L;

	/**
	 * Parameterless constructor required for serialisation
	 */
	public Vector() {
	}

	/**
	 * Creates a new {@link Vector}.
	 *
	 * @param x
	 *            the longitude, or x-coordinate
	 * @param y
	 *            the latitude, or y-coordinate
	 */
	public Vector(double x, double y) {
		super(x, y);
	}

	/**
	 * Creates a new {@link Vector} with coordinates obtained from the given
	 * {@link Location}.
	 *
	 * @param loc
	 *            the location providing the vector's x- and y-coordinate
	 */
	public Vector(Location loc) {
		this(loc.x, loc.y);
	}

	/**
	 * Creates a new {@link Vector} with coordinates obtained from the provided
	 * one.
	 *
	 * @param vector
	 *            the vector providing the x- and y-coordinate
	 */
	public Vector(Vector vector) {
		this.x = vector.x;
		this.y = vector.y;
	}

	/**
	 * Adds the given value to the vector's x-coordinate.
	 *
	 * @param toAdd
	 *            the value to add
	 * @return the incremented vector
	 */
	public Vector addX(double toAdd) {
		return new Vector(x + toAdd, y);
	}

	/**
	 * Adds the given value to the vector's y-coordinate.
	 *
	 * @param toAdd
	 *            the value to add
	 * @return the incremented vector
	 */
	public Vector addY(double toAdd) {
		return new Vector(x, y + toAdd);
	}

	/**
	 * Divide the vector be the given factor.
	 *
	 * @param divisor
	 *            the divisor
	 * @return the divided vector
	 */
	public Vector divideBy(double divisor) {
		return new Vector(x / divisor, y / divisor);
	}

	/**
	 * Gets the vector's angle in radians.
	 *
	 * @return the angle of this vector
	 */
	public double getAngle() {
		return Math.atan2(y, x) + Math.PI;
	}

	/**
	 * Gets the integer value of the vector's x-coordinate.
	 *
	 * @return the integer part of the vector's x-coordinate
	 */
	public int intX() {
		return (int) x;
	}

	/**
	 * Gets the integer value of the vector's y-coordinate.
	 *
	 * @return the integer part of the vector's y-coordinate
	 */
	public int intY() {
		return (int) y;
	}

	/**
	 * Inverses the vector.
	 *
	 * @return the inversed vector
	 */
	public Vector inverse() {
		return new Vector(-x, -y);
	}

	/**
	 * Gets the vector's magnitude.
	 *
	 * @return the vector's magnitude
	 */
	public double magnitude() {
		return Math.sqrt(x * x + y * y);
	}

	/**
	 * Subtracts the given {@link Vector} from the current one.
	 *
	 * @param toSubtract
	 *            the {@link Vector} to subtract
	 * @return the resulting vector
	 */
	public Vector minus(Vector toSubtract) {
		return new Vector(x - toSubtract.x, y - toSubtract.y);
	}

	/**
	 * Mirrors the vector in the x-axis.
	 *
	 * @return the mirrored vector
	 */
	public Vector mirrorX() {
		return new Vector(-x, y);
	}

	/**
	 * Mirrors the vector in the y-axis.
	 *
	 * @return the mirrored vector
	 */
	public Vector mirrorY() {
		return new Vector(x, -y);
	}

	/**
	 * Moves the vector towards the target {@link Vector} by the given distance.
	 *
	 * @param target
	 *            the target {@link Vector} to be moved towards
	 * @param distance
	 *            the movement distance
	 * @return the resulting vector
	 */
	public Vector moveTowards(Vector target, double distance) {
		return this.plus(target.minus(this).unify().multiplyBy(distance));
	}

	/**
	 * Multiplies the vector by the given factor.
	 *
	 * @param multiplicator
	 *            the multiplication factors
	 * @return the resulting vector
	 */
	public Vector multiplyBy(double multiplicator) {
		return new Vector(x * multiplicator, y * multiplicator);
	}

	/**
	 * Normalises the vector in either clockwise or counter-clockwise direction.
	 *
	 * @param clockwise
	 *            flag indicating whether the normalisation should be performed
	 *            in clockwise or counter-clockwise direction
	 * @return the normalised vector
	 */
	public Vector normal(boolean clockwise) {
		int sign = clockwise ? 1 : -1;
		return new Vector(sign * y, -sign * x);
	}

	/**
	 * Adds the given {@link Vector} to the current one.
	 *
	 * @param toAdd
	 *            the {@link Vector} to add
	 * @return the resulting vector
	 */
	public Vector plus(Vector toAdd) {
		return new Vector(toAdd.x + x, toAdd.y + y);
	}

	/**
	 * Unifies the vector by dividing it with it's magnitude value.
	 *
	 * @return the unified vector
	 */
	public Vector unify() {
		return this.divideBy(magnitude());
	}
}
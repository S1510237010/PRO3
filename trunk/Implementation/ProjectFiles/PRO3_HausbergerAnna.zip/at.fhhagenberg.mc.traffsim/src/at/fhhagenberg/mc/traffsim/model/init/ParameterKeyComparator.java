package at.fhhagenberg.mc.traffsim.model.init;

import java.util.Comparator;

public class ParameterKeyComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		String setIdentifierKey = o1;
		String setKey1 = setIdentifierKey;
		if (setIdentifierKey.contains(ParameterParser.PARAMETER_ID_SEPARATOR)) {
			String[] split = setIdentifierKey.split(ParameterParser.PARAMETER_ID_SEPARATOR);
			setKey1 = split[0];
			setIdentifierKey = split[1];
		}
		String setIdentifierOther = o2;
		String setKey2 = setIdentifierOther;
		if (setIdentifierOther.contains(ParameterParser.PARAMETER_ID_SEPARATOR)) {
			String[] split = setIdentifierOther.split(ParameterParser.PARAMETER_ID_SEPARATOR);
			setKey2 = split[0];
			setIdentifierOther = split[1];
		}
		if (!setKey1.equals(setKey2)) {
			return setKey1.compareTo(setKey2);
		}
		String[] setsKey = setIdentifierKey.split(ParameterParser.MULTIPARAMETERSET_SEPARATOR);
		String[] setsOther = setIdentifierOther.split(ParameterParser.MULTIPARAMETERSET_SEPARATOR);

		for (int i = 0; i < setsKey.length; i++) {
			int result = 0;
			try {
				String[] split1 = setsKey[i].split(ParameterParser.KEYVALUE_SEPARATOR);
				String[] split2 = setsOther[i].split(ParameterParser.KEYVALUE_SEPARATOR);
				if (split1[0].equals(split2[0])) {
					result = Double.compare(Double.parseDouble(split1[1].split(" ")[0]), Double.parseDouble(split2[1].split(" ")[0]));
				}
			} catch (IndexOutOfBoundsException | NumberFormatException e) {
				result = setsKey[i].compareTo(setsOther[i]);

			}
			if (result != 0) {
				return result;
			}
		}
		return 0;
	}

}

package at.fhhagenberg.mc.traffsim.crashdetector;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * The listener interface for receiving crash events. Classes implementing this
 * interface will be notified whenever a collision between two vehicles or a
 * vehicle and an obstacle occurs throughout a simulation run.
 *
 * @author Christian Backfrieder
 */
public interface ICrashListener {

	/**
	 * Method indicating that a crash involving the given vehicles has occurred.
	 *
	 * @param v1
	 *            the fist vehicle involved in the collision
	 * @param v2
	 *            the second vehicle involved in the collision
	 */
	public void crashDetected(Vehicle v1, Vehicle v2);
}
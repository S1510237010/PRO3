package at.fhhagenberg.mc.traffsim.routing.rerouter.footprint;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import at.fhhagenberg.mc.traffsim.communication.IVehicleInformationReceiver;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.routing.Congestion;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICongestionProvider;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICostProvider;
import at.fhhagenberg.mc.traffsim.routing.rerouter.IDynamicNodeWeightProvider;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Additional {@link ICostProvider} which calculates the footprint of a {@link RoadSegment} as weight of planned routes crossing this
 * segment. Therewith, a heuristic can be provided which foresees the future congestion for a road segment
 *
 * @author Christian Backfrieder
 *
 */
public class TimeDynamicFootprintGenerator implements ICostProvider, IDynamicNodeWeightProvider, ICongestionProvider, IVehicleInformationReceiver {
	/**
	 * map of time delay to node id to lists of vehicleIds which pass the segment
	 */
	private List<Map<Long, RouteSourceVehicleMapping>> delayNodeRouteList = new ArrayList<>();
	/**
	 * mapping from vehicle to any collection that contains this vehicles. used for performance reasons on removal
	 */
	private Map<Long, List<Set<Vehicle>>> reverseMapping = new HashMap<>();

	private Lock delayNodeRouteListLock = new ReentrantLock();
	private Lock reverseMappingLock = new ReentrantLock();

	private SimulationModel model;
	private double footprintSum;
	private int weight;
	/** time resolution of graphs in miliseconds */
	private int timeResolution;
	private int maxForecast;
	/** countdown to next update in miliseconds */

	private Queue<Congestion> congestionsQ = new ConcurrentLinkedQueue<>();
	private double thresholdVehiclesPerSecond;
	private int maxForecastSeconds;

	/**
	 *
	 * @param model
	 *            the model to use
	 * @param weight
	 *            weight of the cost provider
	 * @param timeResolution
	 *            time resolution of graphs in miliseconds
	 * @param maxForecast
	 *            maximum forecast in miliseconds
	 * @param thresholdVehiclesPerSecond
	 *            threshold of vehicles per second before situation is recognized as congestion
	 */
	public TimeDynamicFootprintGenerator(SimulationModel model, int weight, int timeResolution, int maxForecast, double thresholdVehiclesPerSecond) {
		model.getObservationCenter().registerInformationReceiver(this);
		this.model = model;
		if (weight < 1 || weight > 99) {
			throw new IllegalArgumentException("Weight must be between 1 and 99 (was " + weight + ")");
		}
		this.weight = weight;
		try {
			delayNodeRouteListLock.lock();
			// delayNodeVehicleListLock.lock();
			for (int i = 0; i <= maxForecast / timeResolution; i++) {
				// delayNodeVehicleList.add(new IdVehicleTimeMapping());
				delayNodeRouteList.add(new ConcurrentHashMap<Long, RouteSourceVehicleMapping>());
			}
		} finally {
			delayNodeRouteListLock.unlock();
			// delayNodeVehicleListLock.unlock();
		}
		this.timeResolution = timeResolution;
		if (maxForecast % timeResolution != 0) {
			int oldMaxForecast = maxForecast;
			maxForecast += timeResolution - (maxForecast % timeResolution);
			Logger.logInfo(String.format("Max. forecast time increased from %d to %d, since it did not fit to time resolution of %d", oldMaxForecast,
					maxForecast, timeResolution));
		}
		this.maxForecast = maxForecast;
		this.maxForecastSeconds = maxForecast / 1000;
		// parameter
		this.thresholdVehiclesPerSecond = thresholdVehiclesPerSecond;

	}

	public int getTimeResolution() {
		return timeResolution;
	}

	public int getMaxForecast() {
		return maxForecast;
	}

	@Override
	public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {
		if (newLane.getRoadSegment() != null) {
			IRoute rt = model.getObservationCenter().getRoute(vehicle.getUniqueId());
			updateFootprint(newLane.getRoadSegment(), vehicle, rt, rt);
		}
	}

	@Override
	public void vehicleLeftSimulation(Vehicle v) {
		try {
			delayNodeRouteListLock.lock();
			removeFromMapping(v);
		} finally {
			delayNodeRouteListLock.unlock();
		}

	}

	private RouteSourceVehicleMapping getRouteSourceVehicleMapping(int timeIndex, long nodeId) {
		try {
			delayNodeRouteListLock.lock();
			Map<Long, RouteSourceVehicleMapping> nodeRouteSourceMapping = delayNodeRouteList.get(timeIndex);

			if (!nodeRouteSourceMapping.containsKey(nodeId)) {
				nodeRouteSourceMapping.put(nodeId, new RouteSourceVehicleMapping());
			}
			return nodeRouteSourceMapping.get(nodeId);
		} finally {
			delayNodeRouteListLock.unlock();
		}
	}

	/**
	 * Remove all vehicles from all collections to which it was added <br>
	 * <b>Important:</b> only {@link Vehicle}s that were added to the reversemapping collection can be considered!
	 *
	 * @param veh
	 *            the vehicle to remove from all mappings
	 */
	private void removeFromMapping(Vehicle veh) {
		try {
			reverseMappingLock.lock();
			if (reverseMapping.containsKey(veh.getUniqueId())) {
				for (Iterator<Set<Vehicle>> it = reverseMapping.get(veh.getUniqueId()).iterator(); it.hasNext();) {
					Set<Vehicle> vSet = it.next();
					vSet.remove(veh);
					it.remove();
				}
			}
		} finally {
			reverseMappingLock.unlock();
		}
	}

	/**
	 * Add a single vehicle to the reverse mapping collection, which can be used to increase performance on removal of vehicles
	 *
	 * @param veh
	 *            the vehicle to consider
	 * @param coll
	 *            the collection to which the vehicle was added
	 */
	private void addToReverseMapping(Vehicle veh, Set<Vehicle> coll) {
		List<Set<Vehicle>> list;
		try {
			reverseMappingLock.lock();
			if (!reverseMapping.containsKey(veh.getUniqueId())) {
				list = new LinkedList<>();
				reverseMapping.put(veh.getUniqueId(), list);
			} else {
				list = reverseMapping.get(veh.getUniqueId());
			}
		} finally {
			reverseMappingLock.unlock();
		}
		list.add(coll);
		// check abnormal size, which must be a logical error
		if (list.size() > 200) {
			Logger.logWarn("Warning: Reverse mapping list of footprint grew to unusual size of " + list.size() + " when adding vehicle "
					+ veh.getUniqueId() + " (added array hash: " + coll.hashCode() + ")");
			model.setSimulationRunning(false, false);
		}
	}

	private void updateFootprint(RoadSegment curRS, Vehicle originatingVehicle, IRoute oldRoute, IRoute newRoute) {
		if (!originatingVehicle.isRoutable()) {
			return;
		}

		// remove old route
		if (oldRoute != null) {
			try {
				delayNodeRouteListLock.lock();
				removeFromMapping(originatingVehicle);

			} finally {
				delayNodeRouteListLock.unlock();
			}
		}

		// add new route
		if (newRoute != null && curRS != null) {
			double timeDelay = (curRS.getRoadLength() - model.getObservationCenter().getVehicleFrontPos(originatingVehicle.getUniqueId()))
					/ curRS.getRoadLength() * getTimeDelay(curRS);
			ArrayList<Long> routeIds = new ArrayList<>(newRoute.getRouteIds());
			// if (!routeIds.isEmpty() && routeIds.get(0) !=
			// curRS.getRoutingId()) {
			// routeIds.add(0, curRS.getRoutingId());
			// }
			for (int i = 0; i < routeIds.size(); i++) {
				Long routingId = routeIds.get(i);
				if (curRS.getRoutingId() == routingId) {
					// nothing
				} else if (curRS.getSinkRoadSegment() != null) {
					timeDelay += getTimeDelay(curRS);
					curRS = curRS.getSinkRoadSegment();
				} else if (curRS.getJunction() != null) {
					for (RoadSegment segTesting : curRS.getJunction().getSegmentsOut()) {
						if (segTesting.getRoutingId() == routingId) {
							timeDelay += getTimeDelay(curRS);
							curRS = segTesting;
							break;
						}
					}
				}
				if (curRS.getRoutingId() != routingId) {
					/**
					 * if routingId is not in sync with curRS -> this can happen due to delays resulting by communication component
					 */
					if (routeIds.contains(curRS.getRoutingId())) {
						int indexInRoute = routeIds.indexOf(curRS.getRoutingId());
						if (i < indexInRoute) {
							i = indexInRoute;
						}
						continue;
					} else {
						curRS = model.getNetwork().getRoadSegmentByRoutingId(routeIds.get(i), newRoute.getIsReverse().get(i));
						continue;
					}
				}
				long curEndNode = curRS.getEndNode().getId();
				if (timeDelay < maxForecastSeconds) {
					int curTimeIndex = getIndex(timeDelay);
					long curVehSum = 0;
					double[] occupation;
					AbstractJunction junc = model.getNetwork().getJunctionByKey(curEndNode);
					try {
						delayNodeRouteListLock.lock();
						RouteSourceVehicleMapping rsvm = getRouteSourceVehicleMapping(curTimeIndex, curEndNode);
						Set<Vehicle> coll = rsvm.addItem(curRS.getId(), originatingVehicle);
						addToReverseMapping(originatingVehicle, coll);
						curVehSum = rsvm.sum();
						occupation = rsvm.getNumberOfOccupiedSources();
					} finally {
						delayNodeRouteListLock.unlock();
					}

					double numOccupied = occupation[0];
					double minOccupied = occupation[1];
					/**
					 * 1. Ignore drivethrough junctions 2. occupiedSources > 1: vehicles must come from at least two different directions 3.
					 * threshold is weighted differently depending on the relation of lanes moving in/out of this jucntion
					 */
					if (junc != null && !junc.isSimpleThrough() && numOccupied > 1 && minOccupied > 1) {
						double numAllowed = timeResolution / 1000 * thresholdVehiclesPerSecond * Math.pow(1.5, junc.getDiffInOut());
						if (curVehSum > numAllowed) {
							congestionDetected(curEndNode, curTimeIndex, curVehSum / (timeResolution / 1000), curRS.getId(), curVehSum, numAllowed);
						}
					}
				} else {
					/*
					 * we are in front of max forecast - break updating (otherwise, everything gets assigned to last timestamp which causes
					 * jam
					 */
					break;
				}
			}
		}
	}

	private double getTimeDelay(RoadSegment cur) {
		return model.getRouteService().getSegmentUnfilteredHCost(cur.getRoutingId(), cur.isOsmReverse()) * 3600;// cur.getRoadLength();
	}

	@Override
	public double getCost(long segId) {
		return 0;
	}

	public double getJunctionCost(long nodeId, int forecastIndex) {
		Map<Long, RouteSourceVehicleMapping> nodeData = null;
		try {
			delayNodeRouteListLock.lock();
			if (forecastIndex < delayNodeRouteList.size()) {
				nodeData = delayNodeRouteList.get(forecastIndex);
			}
			return (nodeData != null && nodeData.containsKey(nodeId)) ? nodeData.get(nodeId).sum() : 0;
		} finally {
			delayNodeRouteListLock.unlock();
		}
	}

	private void congestionDetected(long nodeId, int timeIndex, double vehiclesPerSecond, long roadSegId, long vehSum, double numAllowed) {
		List<Vehicle> congestedVehicles = null;
		try {
			delayNodeRouteListLock.lock();
			Map<Long, RouteSourceVehicleMapping> nodeMapping = delayNodeRouteList.get(timeIndex);
			congestedVehicles = new ArrayList<>(nodeMapping.get(nodeId).getAffectedVehicles());
		} finally {
			delayNodeRouteListLock.unlock();
		}

		if (CollectionUtil.isNotNullOrEmpty(congestedVehicles)) {
			int futSeconds = timeIndex * timeResolution / 1000;
			Date futureDate = new Date(model.getCurrentSimTime().getTime() + timeIndex * timeResolution);
			model.logCongestion(EventType.CONGESTION_PREDICTED,
					"TimeDynamic", String.format("Node congestion warning: %d (RS %d) %d seconds (at %s), %d vehicles / %d seconds", nodeId,
							roadSegId, futSeconds, futureDate.toString(), vehSum, timeResolution / 1000),
					nodeId, roadSegId, vehSum / (timeResolution / 1000), futureDate);

			congestionsQ.offer(new Congestion(nodeId, (int) Math.floor(numAllowed), congestedVehicles, futureDate));
		}
	}

	/**
	 * Determines the forecast index from a delay in seconds
	 *
	 * @param delaySeconds
	 * @return index for usage of determination of forecast cost
	 */
	public int getIndex(double delaySeconds) {
		if (delaySeconds < 0) {
			return 0;
		}
		if (delaySeconds > maxForecastSeconds) {
			return Integer.MAX_VALUE;
		}

		int index = Math.floorDiv((int) (delaySeconds * 1000), timeResolution);
		return index;
	}

	@Override
	public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute) {
		updateFootprint(currentSegment, v, oldRoute, newRoute);
	}

	@Override
	public double getCurrentCostSum() {
		return footprintSum;
	}

	@Override
	public double getNormalizedCost(long segmentId) {
		return getCost(segmentId) / footprintSum;
	}

	@Override
	public int getWeight() {
		return weight;
	}

	@Override
	public double getNodeWeight(long nodeId, double delaySeconds) {
		int forecastIndex = getIndex(delaySeconds);
		try {
			Map<Long, RouteSourceVehicleMapping> nodeData = null;
			delayNodeRouteListLock.lock();
			if (forecastIndex < delayNodeRouteList.size()) {
				nodeData = delayNodeRouteList.get(forecastIndex);
			}
			return (nodeData != null && nodeData.containsKey(nodeId)) ? nodeData.get(nodeId).sum() : 0;
		} finally {
			delayNodeRouteListLock.unlock();
		}
	}

	public List<Vehicle> getVehiclesPassing(Long nodeId, double withinDelay) {
		List<Vehicle> vehicles = new ArrayList<>();
		for (int i = 0; i < getIndex(withinDelay); i++) {
			vehicles.addAll(getRouteSourceVehicleMapping(i, nodeId).getAffectedVehicles());
		}
		return vehicles;
	}

	@Override
	public Queue<Congestion> getCongestions() {
		return congestionsQ;
	}

	@Override
	public String getCommReceiverName() {
		return "TDyn Footprint";
	}

}
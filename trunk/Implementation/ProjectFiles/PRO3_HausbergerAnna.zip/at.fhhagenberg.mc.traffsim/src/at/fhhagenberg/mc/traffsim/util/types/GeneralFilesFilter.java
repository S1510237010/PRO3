package at.fhhagenberg.mc.traffsim.util.types;

import java.io.File;

import org.apache.commons.io.filefilter.IOFileFilter;

/**
 * Implementation of an IOFileFilter (@see IOFileFilter) bringing together the FileFilter and FilenameFilter interfaces. Files which do not
 * comply with a specific pattern are filtered.
 *
 * @author Christian Backfrieder
 */
public class GeneralFilesFilter implements IOFileFilter {

	/** The filter pattern */
	private String pattern;

	/**
	 * Creates a new instance of GeneralFilesFilter with the given filter pattern.
	 *
	 * @param patternToMatch
	 *            the filter pattern to be applied
	 */
	public GeneralFilesFilter(String patternToMatch) {
		this.pattern = patternToMatch;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.apache.commons.io.filefilter.IOFileFilter#accept(java.io.File)
	 */
	@Override
	public boolean accept(File file) {
		return file.getName().contains(pattern);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.apache.commons.io.filefilter.IOFileFilter#accept(java.io.File, java.lang.String)
	 */
	@Override
	public boolean accept(File dir, String name) {
		return name.contains(pattern);
	}
}
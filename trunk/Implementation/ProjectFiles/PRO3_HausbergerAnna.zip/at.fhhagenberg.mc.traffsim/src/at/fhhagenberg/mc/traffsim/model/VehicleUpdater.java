package at.fhhagenberg.mc.traffsim.model;

import java.util.Date;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.ThreadingUtil;

/**
 * Update task which starts new executor service to process all updates on vehicles
 *
 * @author Christian Backfrieder
 *
 */
public class VehicleUpdater implements ISimulationTimeUpdatable {
	private RoadNetwork network;
	private boolean isSingleThreaded = PreferenceUtil.getBoolean(IPreferenceConstants.SINGLETHREADED_EXECUTION);

	public VehicleUpdater(RoadNetwork network) {
		this.network = network;
	}

	@Override
	public void timeStep(final double dt, final Date time, double runTime) {
		/**
		 * Update road Segments: Accelerations, speed and outflow MUST be calculated separately in parallel, since the vehicles of
		 * subsequent roadsegments have direct influence to each other, which may lead to problems in parallel execution
		 */
		ThreadingUtil.executeAction(network.getLoopDetectors(), ld -> ld.update(dt, runTime), "updating loop detectors", isSingleThreaded);
		ThreadingUtil.executeAction(network.getRoadSegments(), rs -> rs.makeLaneChanges(dt, time), "updating lane changes", isSingleThreaded);
		ThreadingUtil.executeAction(network.getRoadSegments(), rs -> rs.updateAccelerations(dt, runTime), "updating accelerations", isSingleThreaded);
		ThreadingUtil.executeAction(network.getRoadSegments(), r -> r.updateSpeedsAndPositions(dt, time),
				"updating speed and position in road segments", isSingleThreaded);
		ThreadingUtil.executeAction(network.getLoopDetectors(), r -> r.updateSignalPoint(runTime), "updating signal points after inflow",
				isSingleThreaded);
		ThreadingUtil.executeAction(network.getRoadSegments(), rs -> rs.getLaneSegments().forEach(ls -> ls.outFlow(dt, time, runTime)),
				"updating lane segment outflow", true);

		/**
		 * update junctions: they can be updated independent from each other in parallel, since two junctions are not related to each other,
		 * in contrast to road segments
		 */
		ThreadingUtil.executeAction(network.getJunctions(), j -> {
			j.updateAccelerations(dt, runTime);
			j.updateSpeedsAndPositions(dt, time);
			j.updateWaitingTimes(dt);
			j.getConnectors().forEach(jc -> jc.outFlow(dt, time, runTime));
			j.updateEntryGrants(dt, time, runTime);
			j.getApproaches().forEach(app -> app.timeStep(dt, time, runTime));

			if (j.getTrafficLightController() != null) {
				j.getTrafficLightController().timeStep(dt, time, runTime);
			}
		}, "updating junctions", isSingleThreaded);
	}

}

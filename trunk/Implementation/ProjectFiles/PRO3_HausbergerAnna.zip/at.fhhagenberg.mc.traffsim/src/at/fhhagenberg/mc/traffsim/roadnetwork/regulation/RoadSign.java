package at.fhhagenberg.mc.traffsim.roadnetwork.regulation;

import at.fhhagenberg.mc.traffsim.roadnetwork.junction.PriorityState;
import at.fhhagenberg.mc.traffsim.ui.IImageKeys;

public class RoadSign {
	public enum Type {
		/** German: Vorrangschild */
		GIVE_WAY("GIVE_WAY"), STOP("STOP"), PRIORITY_ROAD("PRIORITY_ROAD"), NONE("NONE");

		private String name;

		private Type(String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return name;
		}
	}

	private static class TypeAssignment {
		public static String getImage(Type type) {
			switch (type) {
			case GIVE_WAY:
				return IImageKeys.ROAD_SIGN_GIVE_WAY;
			case NONE:
				return null;
			case PRIORITY_ROAD:
				return IImageKeys.ROAD_SIGN_PRIORITY_ROAD;
			case STOP:
				return IImageKeys.ROAD_SIGN_STOP;
			}
			return null;
		}

		public static int getPriority(Type type) {
			switch (type) {
			case GIVE_WAY:
				return PriorityState.GIVE_WAY_SIGN;
			case PRIORITY_ROAD:
				return PriorityState.PRIORITY_ROAD;
			case STOP:
				return PriorityState.STOP_SIGN;
			case NONE:
				return PriorityState.NONE;
			default:
				return PriorityState.NOT_AVAILABLE;
			}
		}
	}

	private Type type = Type.NONE;

	public RoadSign() {
	}

	public RoadSign(Type type) {
		this.type = type;
	}

	public RoadSign(String type) {
		this.type = Type.valueOf(type);
	}

	public String getImagePath() {
		return TypeAssignment.getImage(type);
	}

	public int getDefaultPriority() {
		return TypeAssignment.getPriority(type);
	}

	public boolean hasImage() {
		return getImagePath() != null;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type.toString();
	}

	public static int getPriority(Type type) {
		return TypeAssignment.getPriority(type);
	}
}

package at.fhhagenberg.mc.traffsim.statistics;

import java.util.Map;

/**
 * Helper interface to obtain statistics using key-value pairs.
 *
 * @author Manuel Lindorfer
 *
 */
public interface IStatisticsProvider {
	public Map<String, Number> obtainStatistics();
}

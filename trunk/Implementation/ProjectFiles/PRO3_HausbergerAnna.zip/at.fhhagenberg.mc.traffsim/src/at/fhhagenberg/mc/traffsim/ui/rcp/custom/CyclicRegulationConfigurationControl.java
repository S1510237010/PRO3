package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.CyclicController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.CyclicControlLogic;

public class CyclicRegulationConfigurationControl
		extends TrafficRegulationConfigurationControl<CyclicController, CyclicControlLogic, CyclicTrafficLightConfigurationParameters> {

	private Spinner spinnerDelay;
	private Spinner spinnerPhaseLength;
	private Button btnStartWithGreen;

	public CyclicRegulationConfigurationControl(Composite parent, int style) {
		super(parent, style);
	}

	@Override
	protected void intialize() {

		Label lblControllerHeader = new Label(container, SWT.CHECK);
		lblControllerHeader.setText("Controller Properties");
		lblControllerHeader.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		FontDescriptor boldDescriptor = FontDescriptor.createFrom(lblControllerHeader.getFont()).setStyle(SWT.BOLD);
		Font boldFont = boldDescriptor.createFont(lblControllerHeader.getDisplay());
		lblControllerHeader.setFont(boldFont);

		btnStartWithGreen = new Button(container, SWT.CHECK);
		btnStartWithGreen.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		btnStartWithGreen.setText("Start with green phase");
		btnStartWithGreen.setToolTipText("Determines if the cycle starts with a green phase or not");
		btnStartWithGreen.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label lblTrafficLightHeader = new Label(container, SWT.CHECK);
		lblTrafficLightHeader.setText("Traffic Light Properties");
		lblTrafficLightHeader.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		boldDescriptor = FontDescriptor.createFrom(lblTrafficLightHeader.getFont()).setStyle(SWT.BOLD);
		boldFont = boldDescriptor.createFont(lblTrafficLightHeader.getDisplay());
		lblTrafficLightHeader.setFont(boldFont);

		Label trafficLightDelayLabel = new Label(container, SWT.NONE);
		trafficLightDelayLabel.setText("Phase delay [s]");
		trafficLightDelayLabel.setToolTipText("Delay introduced before a traffic light changes its phase");
		spinnerDelay = new Spinner(container, SWT.BORDER);
		spinnerDelay.setDigits(3);
		spinnerDelay.setMaximum(120000);
		spinnerDelay.setMinimum(0);
		spinnerDelay.setPageIncrement(1000);
		spinnerDelay.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label trafficLightPhaseLengthLabel = new Label(container, SWT.NONE);
		trafficLightPhaseLengthLabel.setText("Phase length [s]");
		trafficLightPhaseLengthLabel.setToolTipText("Duration of the traffic light's green phase");
		spinnerPhaseLength = new Spinner(container, SWT.BORDER);
		spinnerPhaseLength.setDigits(3);
		spinnerPhaseLength.setMaximum(120000);
		spinnerPhaseLength.setMinimum(5000);
		spinnerPhaseLength.setPageIncrement(1000);
		spinnerPhaseLength.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

	}

	@Override
	protected void updateControls() {
		if (selectedControlLogic != null) {
			spinnerDelay.setSelection((int) selectedControlLogic.getDelay());
			spinnerPhaseLength.setSelection((int) selectedControlLogic.getPhaseLength());
			spinnerDelay.setEnabled(true);
			spinnerPhaseLength.setEnabled(true);
		} else {
			spinnerDelay.setSelection(0);
			spinnerPhaseLength.setSelection(0);
			spinnerDelay.setEnabled(false);
			spinnerPhaseLength.setEnabled(false);
		}

		if (selectedController != null) {
			btnStartWithGreen.setSelection(selectedController.getStartWithGreen());
			btnStartWithGreen.setEnabled(true);
		} else {
			btnStartWithGreen.setSelection(false);
			btnStartWithGreen.setEnabled(false);
		}
	}

	private void updateProperties() {
		if (selectedControlLogic != null) {
			selectedControlLogic.setDelay(spinnerDelay.getSelection());
			selectedControlLogic.setPhaseLength(spinnerPhaseLength.getSelection());
		}

		if (selectedController != null) {
			selectedController.setStartWithGreen(btnStartWithGreen.getSelection());
		}
	}

	@Override
	public void activate(boolean activate) {
		btnStartWithGreen.setEnabled(activate);
		spinnerDelay.setEnabled(activate);
		spinnerPhaseLength.setEnabled(activate);
	}

	@Override
	public CyclicTrafficLightConfigurationParameters getConfigurationParameters() {
		CyclicTrafficLightConfigurationParameters params = new CyclicTrafficLightConfigurationParameters();
		params.startWithGreenPhase = btnStartWithGreen.getSelection();
		params.phaseDelay = spinnerDelay.getSelection();
		params.phaseLength = spinnerPhaseLength.getSelection();
		return params;
	}
}

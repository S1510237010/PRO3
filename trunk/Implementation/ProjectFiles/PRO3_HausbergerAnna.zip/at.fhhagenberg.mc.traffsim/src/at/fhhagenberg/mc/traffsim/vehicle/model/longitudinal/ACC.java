package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.ACCData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;

/**
 * Adaptive cruise control model
 *
 * From Kesting et al. Enhanced intelligent driver model ...<br>
 * Compared with the IDM parameters, the ACC model contains only one additional model parameter c, which can be interpreted as a
 * data.getCoolness() factor. For c =0, the model reverts to the IDM, while for c =1 the sensitivity with respect to changes in the gap
 * vanishes in situations with small gaps and no velocity difference. This means that the behaviour would be too relaxed. In this paper, we
 * have assumed c =0.99 (see table 1)
 *
 * @author Christian Backfrieder
 *
 */
public class ACC extends LongitudinalModel {
	private ACCData data;

	public ACC() {

	}

	public ACC(ACCData data) {
		super(data.getIdentifier());
		fullname = data.getFullname();
		this.data = data;
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA, double speedLimit) {
		if (getModelData().getvTarget() == 0) {
			return 0;
		}

		double Tlocal = alphaT * data.gettMin();
		double v0Local = Math.min(alphaV0 * getModelData().getvTarget(), speedLimit);
		double aLocal = alphaA * data.getComfortableAcc();

		// ignored gap parameter s1 according to mail from martin treiber
		final double sstar = data.getsMin() + Math.max(Tlocal * v + 0.5 * v * dv / Math.sqrt(aLocal * -data.getSafeDec()), 0.);
		final double z = sstar / Math.max(s, 0.01);
		final double accEmpty = v <= v0Local ? aLocal * (1 - Math.pow(v / Math.max(v0Local, 1e-5), data.getDelta()))
				: data.getSafeDec() * (1 - Math.pow(v0Local / v, aLocal * data.getDelta() / -data.getSafeDec()));
		final double accPos = accEmpty * (1. - Math.pow(z, Math.min(2 * aLocal / accEmpty, 100.)));
		final double accInt = aLocal * (1 - z * z);

		double accIIDM = 0;

		if (v <= v0Local) {
			if (z < 1) {
				accIIDM = accPos;
			} else {
				accIIDM = accInt;
			}
		} else {
			if (z < 1) {
				accIIDM = accEmpty;
			} else {
				accIIDM = accInt + accEmpty;
			}
		}

		// constant-acceleration heuristic (CAH)

		final double aLeadRestricted = Math.min(aLead, aLocal);
		final double dvp = Math.max(dv, 0.0);
		final double vLead = v - dvp;
		final double denomCAH = vLead * vLead - 2 * s * aLeadRestricted;

		final double accCAH = vLead * dvp < -2 * s * aLeadRestricted && denomCAH != 0 ? v * v * aLeadRestricted / denomCAH
				: aLeadRestricted - 0.5 * dvp * dvp / Math.max(s, 0.0001);

		// ACC with IIDM

		final double accACC_IIDM = accIIDM > accCAH ? accIIDM
				: (1 - data.getCoolness()) * accIIDM
						+ data.getCoolness() * (accCAH + -data.getSafeDec() * Math.tanh((accIIDM - accCAH) / -data.getSafeDec()));

		return accACC_IIDM;
	}

	@Override
	public LongitudinalModel createCopyFor(double targetSpeed) {
		ACCData copy = new Kryo().copy(data);
		copy.setvTarget(targetSpeed);
		return new ACC(copy);
	}

	@Override
	public LongitudinalModelData getModelData() {
		return data;
	}

	@Override
	public boolean isSafeAcceleration(double acceleration) {
		return acceleration < data.getMaxAcc() && acceleration > data.getMaxDec();
	}
}

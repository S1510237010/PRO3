package at.fhhagenberg.mc.traffsim.routing;

import java.io.File;
import java.util.Set;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.Node;

public abstract class AbstractMultithreadedRouteService extends AbstractRouteService {
	private class InternalOverriderFactory implements PooledObjectFactory<TransientGraphCostsOverrider> {

		@Override
		public PooledObject<TransientGraphCostsOverrider> makeObject() throws Exception {
			OverrideableGraph newGraph = new OverrideableGraph(graphFile);
			TransientGraphCostsOverrider newOverrider = new TransientGraphCostsOverrider(newGraph, true, osm2poLog);
			newOverrider.resetToCosts(graph.getEdgeCostsH());
			newGraph.setHOverrider(newOverrider);
			return new DefaultPooledObject<TransientGraphCostsOverrider>(newOverrider);
		}

		@Override
		public void destroyObject(PooledObject<TransientGraphCostsOverrider> p) throws Exception {
			p.getObject().getGraph().close();
			p.getObject().close();
		}

		@Override
		public boolean validateObject(PooledObject<TransientGraphCostsOverrider> p) {
			return !p.getObject().getGraph().isInitializing();
		}

		@Override
		public void activateObject(PooledObject<TransientGraphCostsOverrider> p) throws Exception {
			p.getObject().resetToCosts(graph.getEdgeCostsH());
		}

		@Override
		public void passivateObject(PooledObject<TransientGraphCostsOverrider> p) throws Exception {
			// unused
		}

	}

	private GenericObjectPool<TransientGraphCostsOverrider> overriderPool;

	public AbstractMultithreadedRouteService(File graphFile, Set<Long> removedRoutingIds) {
		super(graphFile, removedRoutingIds);
	}

	public void setupDynamicGraphs(int number) {
		GenericObjectPoolConfig config = new GenericObjectPoolConfig();
		config.setMaxTotal(number);
		config.setMaxIdle(number);
		config.setBlockWhenExhausted(true);
		overriderPool = new GenericObjectPool<>(new InternalOverriderFactory());
	}

	public TransientGraphCostsOverrider startDynamicOverride() {
		TransientGraphCostsOverrider overrider;
		try {
			overrider = overriderPool.borrowObject();
			overrider.resetToCosts(graph.getEdgeCostsH());
			return overrider;
		} catch (Exception e) {
			Logger.logError("Could not borrow graph overrider from pool.");
			return null;
		}
	}

	public void finishDynamicOverrider(TransientGraphCostsOverrider overrider) {
		if (overrider != null) {
			overriderPool.returnObject(overrider);
		}
	}

	/**
	 * Find the route and use the dynamically overriden given graph
	 *
	 * @param s
	 * @param t
	 * @param overrider
	 * @return the found single route
	 */
	public SimpleRouteResult findRouteDynamic(Node s, Node t, TransientGraphCostsOverrider overrider) {
		return findSingleRoute(s, t, overrider.getGraph());
	}

	@Override
	public SimpleRouteResult findRoute(Node sourceNode, Node targetNode) {
		return findSingleRoute(sourceNode, targetNode);
	}

	@Override
	public void dispose() {
		if (overriderPool != null) {
			overriderPool.close();
			overriderPool.clear();
		}
		super.dispose();
	}

}

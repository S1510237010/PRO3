package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.ui.PlatformUI;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.util.ui.SWTUtil;

public class ShowViewCommand implements IHandler {
	private static final String VIEW_PARAMETER_ID = "at.fhooe.mc.traffsim.commands.showView.viewId";
	private static final String ISATTACHED_PARAMETER_ID = "at.fhooe.mc.traffsim.commands.showView.isAttached";

	private long secondaryIdMax = 0;

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

	@Override
	public void dispose() {
		// nothing
	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		String id;
		if ((id = event.getParameter(VIEW_PARAMETER_ID)) != null) {
			String secId = null;
			if (PlatformUI.getWorkbench().getViewRegistry().find(id).getAllowMultiple()) {
				secId = id + secondaryIdMax++;
			} else {
				secId = id;
			}
			SWTUtil.showView(id, secId, !Boolean.parseBoolean(event.getParameter(ISATTACHED_PARAMETER_ID)));
		}
		return null;

	}

	@Override
	public boolean isEnabled() {
		return SimulationKernel.getInstance().isModelActive();
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

}

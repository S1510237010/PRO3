package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.vehicle.DrivingRegime;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;
import at.fhhagenberg.mc.traffsim.vehicle.model.AutomationLevel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.Regime;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.SpeedRange;

public class VehicleAutomationControl extends ContainerControl {

	private enum State {
		AUTOMATED, NON_AUTOMATED
	}

	private State curState;
	private double transitionSecondsAutomated;
	private double transitionSecondsHuman;
	private double transitionTimeAutomatedHuman;
	private double transitionTimeHumanAutomated;
	private boolean isTransitioning;

	private boolean isSwitchForced;
	private double currentVehicleSpeed;
	private DrivingRegime currentDrivingRegime;

	private AutomationLevel automationLevel;
	private AccUpdateData currentAccData;

	private String modelIdentifier;
	private long vehicleIdentifier;
	private String vehicleLabel;

	/**
	 * Determines in which time interval the driving mode (human, automated) is evaluated using the specified probabilities and the current
	 * speed and / or driving regime
	 **/
	private double evaluationRate;
	private double timeUntilNextEvaluation;
	private Random random = new Random();

	private List<Regime> drivingRegimes = new ArrayList<>();
	private List<SpeedRange> speedRanges = new ArrayList<>();

	private double timeHeadway;
	private double spaceHeadway;

	public VehicleAutomationControl() {
		super();
	}

	public VehicleAutomationControl(String identifier, AutomationLevel automationLevel, double transitionSecondsAutomated,
			double transitionSecondsHuman, double evaluationRate, double timeHeadway, double spaceHeadway) {
		super(identifier);
		this.automationLevel = automationLevel;
		this.transitionSecondsAutomated = transitionSecondsAutomated;
		this.transitionSecondsHuman = transitionSecondsHuman;
		this.evaluationRate = evaluationRate;
		this.timeHeadway = timeHeadway;
		this.spaceHeadway = spaceHeadway;
		this.transitionTimeAutomatedHuman = Double.NEGATIVE_INFINITY;
		this.transitionTimeHumanAutomated = Double.NEGATIVE_INFINITY;
		this.timeUntilNextEvaluation = Double.NEGATIVE_INFINITY;
		this.vehicleIdentifier = -1;
		this.modelIdentifier = null;
		this.isSwitchForced = true;
	}

	public void initialize() {
		switch (automationLevel) {
		case NONE:
		case PARTIAL:
		case HIGH:
			activeControl = childControls.get(0);
			curState = State.NON_AUTOMATED;
			break;
		case FULL:
			activeControl = childControls.get(1);
			curState = State.AUTOMATED;
			break;
		}
	}

	public void setModelIdentifier(String modelIdentifier) {
		this.modelIdentifier = modelIdentifier;
	}

	public List<Regime> getDrivingRegimes() {
		return drivingRegimes;
	}

	public void setDrivingRegimes(List<Regime> drivingRegimes) {
		this.drivingRegimes = drivingRegimes;
	}

	public List<SpeedRange> getSpeedRanges() {
		return speedRanges;
	}

	public void setSpeedRanges(List<SpeedRange> speedRanges) {
		this.speedRanges = speedRanges;
	}

	public AutomationLevel getAutomationLevel() {
		return automationLevel;
	}

	@Override
	public void update(double dt, double simulationTime) {
		super.update(dt, simulationTime);

		if (automationLevel == AutomationLevel.NONE || automationLevel == AutomationLevel.FULL) {
			return;
		}

		/** Determine time when to switch to human or automated driving depending on the current speed **/
		boolean isInAutomatableRange = isInAutomatableRange(currentVehicleSpeed, currentDrivingRegime);

		if (isInAutomatableRange && curState == State.NON_AUTOMATED && isSwitchForced) {
			if (!isTransitioning) {
				transitionTimeHumanAutomated = transitionSecondsAutomated;
				isTransitioning = true;
			} else {
				if (transitionTimeHumanAutomated > 0) {
					transitionTimeHumanAutomated -= dt;
				} else if (transitionTimeHumanAutomated <= 0 && transitionTimeHumanAutomated != Double.NEGATIVE_INFINITY) {
					switchControl(false, true);
				}
			}
		} else if (!isInAutomatableRange && curState == State.AUTOMATED) {
			if (!isTransitioning) {
				transitionTimeAutomatedHuman = transitionSecondsHuman;
				isTransitioning = true;
			} else {
				if (transitionTimeAutomatedHuman > 0) {
					transitionTimeAutomatedHuman -= dt;
				} else if (transitionTimeAutomatedHuman <= 0 && transitionTimeAutomatedHuman != Double.NEGATIVE_INFINITY) {
					switchControl(true, true);
				}
			}
		} else {
			transitionTimeAutomatedHuman = Double.NEGATIVE_INFINITY;
			transitionTimeHumanAutomated = Double.NEGATIVE_INFINITY;
			isTransitioning = false;
		}

		/**
		 * Verify whether human or automated driving are currently active. Do not switch back to human driver randomly in case of high
		 * automation.
		 **/
		if (timeUntilNextEvaluation <= 0 && !isTransitioning && automationLevel != AutomationLevel.HIGH) {
			double fallbackProbability = getFallbackProbability(currentVehicleSpeed, currentDrivingRegime);

			if (fallbackProbability != Double.NEGATIVE_INFINITY) {
				double rand = random.nextDouble();

				/** Reverse probability for switching from human to automated driving **/
				if (curState == State.NON_AUTOMATED) {
					fallbackProbability = 1 - fallbackProbability;
				}

				if (rand < fallbackProbability) {
					switchControl(curState == State.AUTOMATED, false);
				}
			}

			timeUntilNextEvaluation = evaluationRate;
		} else {
			timeUntilNextEvaluation -= dt;
		}
	}

	@Override
	public double calcAccComprehensive(Vehicle me, double alphaT, double alphaV0, double alphaA) {
		updateVehicleProperties(me);
		return super.calcAccComprehensive(me, alphaT, alphaV0, alphaA);
	}

	private synchronized void switchControl(boolean toHuman, boolean isSwitchEnforced) {
		if (toHuman) {
			activeControl = childControls.get(0);
			curState = State.NON_AUTOMATED;
		} else {
			activeControl = childControls.get(1);
			curState = State.AUTOMATED;
		}

		isSwitchForced = isSwitchEnforced;

		// Log event
		SimulationModel model = SimulationKernel.getInstance().getSimulationModel(modelIdentifier);

		if (model != null) {
			String details = curState == State.AUTOMATED
					? isSwitchForced
							? String.format("#%05d (%s) %s", vehicleIdentifier, vehicleLabel,
									"Switched to automated mode [entered automatable range]")
							: String.format("#%05d (%s) %s", vehicleIdentifier, vehicleLabel, "Switched to automated mode [fallback]")
					: isSwitchForced
							? String.format("#%05d (%s) %s", vehicleIdentifier, vehicleLabel,
									"Human driver retained control [left automatable range]")
							: String.format("#%05d (%s) %s", vehicleIdentifier, vehicleLabel, "Human driver retained control [fallback]");
			model.logEvent(EventType.DRIVING_MODE_SWITCHED, details);
		}

		transitionTimeAutomatedHuman = Double.NEGATIVE_INFINITY;
		transitionTimeHumanAutomated = Double.NEGATIVE_INFINITY;
		isTransitioning = false;
	}

	@Override
	public void validate() {
		/**
		 * This control has to be composed of two child controls whereas the former is or extends the HumanDriverControl and the latter is
		 * any arbitrary non-human longitudinal control.
		 */
		assert childControls.size() == 2
				&& (childControls.get(0).getClass() == HumanDriverControl.class
						|| childControls.get(0).getClass() == ExtendedHumanDriverControl.class)
				&& childControls.get(1).getClass() != HumanDriverControl.class && childControls.get(1)
						.getClass() != ExtendedHumanDriverControl.class : "This control must be composed of two child controls, where the first one needs to be an instance of either HumanDriverControl or ExtendedHumanDriverControl and the second one must be any other control but these two.";
	}

	private boolean isInAutomatableRange(double speed, DrivingRegime drivingRegime) {

		/** Consider speed ranges **/
		for (SpeedRange speedRange : speedRanges) {
			if (speed >= speedRange.getFromSpeed() && speed <= speedRange.getToSpeed()) {
				return true;
			}
		}

		/** Consider driving regimes **/
		for (Regime regime : drivingRegimes) {
			if (drivingRegime == regime.getDrivingRegime()) {
				return true;
			}
		}

		return false;
	}

	private double getFallbackProbability(double speed, DrivingRegime drivingRegime) {

		for (SpeedRange speedRange : speedRanges) {
			if (speed >= speedRange.getFromSpeed() && speed <= speedRange.getToSpeed()) {
				return speedRange.getFallbackProbability();
			}
		}

		for (Regime regime : drivingRegimes) {
			if (drivingRegime == regime.getDrivingRegime()) {
				return regime.getFallbackProbability();
			}
		}

		return Double.NEGATIVE_INFINITY;
	}

	private void updateVehicleProperties(Vehicle vehicle) {
		if (vehicle != null) {
			currentAccData = getAccUpdateData(vehicle);
			currentVehicleSpeed = vehicle.getCurrentSpeed();

			/** Update human control (history) just in case the automated one is currently active **/
			if (curState == State.AUTOMATED) {
				IReactiveLongitudinalControl control = (IReactiveLongitudinalControl) childControls.get(0);
				control.updateHistory(vehicle, currentAccData);
			}

			double headway = 0;

			/** Update the current driving regime **/
			if (!NumberUtil.doubleEquals(currentAccData.distance, 0) && !NumberUtil.doubleEquals(currentVehicleSpeed, 0, 0.1)
					&& currentAccData.distance > spaceHeadway) {
				headway = currentAccData.distance / currentVehicleSpeed;
			}

			updateDrivingRegime(vehicle, currentAccData.frontVehicleType, headway);

			if (vehicleIdentifier < 0) {
				vehicleIdentifier = vehicle.getUniqueId();
				vehicleLabel = vehicle.getLabel();
			}
		}
	}

	private void updateDrivingRegime(Vehicle vehicle, VehicleType frontVehicleType, double headway) {
		if (headway <= timeHeadway) {
			if (frontVehicleType == VehicleType.CAR || frontVehicleType == VehicleType.TRUCK) {
				currentDrivingRegime = DrivingRegime.FOLLOWING;
			} else {
				currentDrivingRegime = DrivingRegime.FREE_DRIVING;
			}
		} else {
			currentDrivingRegime = DrivingRegime.FREE_DRIVING;
		}
	}
}

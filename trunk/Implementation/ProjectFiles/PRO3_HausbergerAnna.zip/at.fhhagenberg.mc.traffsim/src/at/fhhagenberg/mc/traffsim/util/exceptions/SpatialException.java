package at.fhhagenberg.mc.traffsim.util.exceptions;

/**
 * This exception type can be used to handle exceptions originating from spatial operations (e.g. simplyfing curves, remove
 * self-intersections of road segments etc.).
 *
 * @author Christian Backfrieder
 */
public class SpatialException extends Exception {

	/** Unique identifier for serialization */
	private static final long serialVersionUID = 762289715123036799L;

	/** Flag indidicating whether the exception is fatal */
	private boolean fatal = false;

	/**
	 * Creates a new SpatialException with the given message
	 *
	 * @param message
	 *            the exception message
	 */
	public SpatialException(String message) {
		super(message);
	}

	/**
	 * Creates a new SpatialException with the given message and exception.
	 *
	 * @param message
	 *            the exception message
	 * @param ex
	 *            the exception causing this SpatialException
	 */
	public SpatialException(String message, Exception ex) {
		super(message, ex);
	}

	/**
	 * Creates a new SpatialException with the given parameters.
	 *
	 * @param message
	 *            the exception message
	 * @param ex
	 *            the exception causing this SpatialException
	 * @param fatal
	 *            indicates whether the exception is fatal or not
	 */
	public SpatialException(String message, Exception ex, boolean fatal) {
		super(message, ex);
		this.fatal = fatal;
	}

	/**
	 * Gets whether the exception is fatal or not.
	 *
	 * @return true if fatal - false else
	 */
	public boolean isFatal() {
		return fatal;
	}
}

package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.google.common.collect.Iterators;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.CyclicControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightControllerBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.CyclicControlLogic;

/**
 * Implementation of a traffic light controller realizing a cyclic control scheme. Each traffic light at an intersection is served after
 * another under consideration of the individual traffic lights' phase lengths.
 *
 * @author Manuel Lindorfer
 *
 */
public class CyclicController extends TrafficLightController<CyclicControlLogic> {

	private long phaseLength;
	private boolean startWithGreen;
	private CyclicControlLogic servicedLane;
	private Iterator<CyclicControlLogic> cycle;

	/**
	 * Creates a new cyclic traffic light controller for the target junction.
	 *
	 * @param id
	 *            unique identifier
	 * @param junction
	 *            the target junction to be operated
	 * @param startWithGreen
	 *            flag indicating whether the cycle starts with a green phase or not
	 */
	public CyclicController(long id, AbstractJunction junction, boolean startWithGreen) {
		super(id, junction);
		this.startWithGreen = startWithGreen;
		this.cycle = Iterators.cycle(controlLogics);
		this.phaseLength = 0;
		this.servicedLane = cycle.next();

		if (startWithGreen) {
			servicedLane.requestChange(true);
		}
	}

	@Override
	protected void onControlLogicsChanged() {
		this.cycle = Iterators.cycle(controlLogics);

		if (cycle.hasNext()) {
			this.servicedLane = cycle.next();

			if (startWithGreen) {
				servicedLane.requestChange(true);
			}
		}
	}

	/**
	 * Determines whether the cycle starts with a green phase or not. If not, the first traffic light in the cycle is served at the start of
	 * the second cycle for the first time.
	 *
	 * @return true if the cycle starts with a green phase, false else
	 */
	public boolean getStartWithGreen() {
		return startWithGreen;
	}

	/**
	 * Specifies whether the cycle starts with a green phase or not. If not, the first traffic light in the cycle is served at the start of
	 * the second cycle for the first time.
	 *
	 * @param startWithGreen
	 *            true if the cycle starts with a green phase, false else
	 */
	public void setStartWithGreen(boolean startWithGreen) {
		this.startWithGreen = startWithGreen;
	}

	@Override
	protected void update(long dt, long simulationRuntime) {
		phaseLength += dt;

		if (phaseLength >= servicedLane.getPhaseLength()) {
			phaseLength = 0;
			servicedLane.requestChange(false, servicedLane.getDelay());
			servicedLane = cycle.next();
			servicedLane.requestChange(true, servicedLane.getDelay());
		}
	}

	@Override
	public TrafficLightControllerBean toBean() {
		CyclicControllerBean bean = new CyclicControllerBean();
		bean.setId(id);
		bean.setJunctionId(junction.getId());
		bean.setStartWithGreen(startWithGreen);
		bean.setAreLanesOperatedIndividually(areLanesOperatedIndividually);

		List<ControlLogicBean> controlBeans = new ArrayList<>();

		for (CyclicControlLogic logic : controlLogics) {
			controlBeans.add(logic.toBean());
		}

		bean.setControlLogic(controlBeans);

		return bean;
	}

	@Override
	public TrafficLightControllers getControlMode() {
		return TrafficLightControllers.CYCLIC;
	}
}

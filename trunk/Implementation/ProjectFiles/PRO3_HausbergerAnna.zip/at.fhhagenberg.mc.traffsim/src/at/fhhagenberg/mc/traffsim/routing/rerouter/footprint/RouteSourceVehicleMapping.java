package at.fhhagenberg.mc.traffsim.routing.rerouter.footprint;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Mapping of route source ids (mostly road segment ids) to List of vehicles coming from this route, used by
 * {@link TimeDynamicFootprintGenerator}
 *
 * @author Christian Backfrieder
 *
 */
public class RouteSourceVehicleMapping {
	private Map<Long, Set<Vehicle>> mapping = new ConcurrentHashMap<>();

	public long sum() {
		long sum = 0;
		for (Set<Vehicle> vIds : mapping.values()) {
			sum += vIds.size();
		}
		return sum;
	}

	/**
	 * Adds an item to the mapping
	 *
	 * @param segId
	 *            the originating segment id
	 * @param vehicle
	 *            the vehicle which passes the node from the given segment
	 * @return the collection to which the item was added
	 */
	public Set<Vehicle> addItem(long segId, Vehicle vehicle) {
		if (mapping.containsKey(segId)) {
			Set<Vehicle> vids = mapping.get(segId);
			vids.add(vehicle);
			return vids;
		} else {
			Set<Vehicle> newVids = new HashSet<>();
			newVids.add(vehicle);
			mapping.put(segId, newVids);
			return newVids;
		}
	}

	public void removeItem(Vehicle vehicle) {
		for (Set<Vehicle> vs : mapping.values()) {
			vs.remove(vehicle);
		}
	}

	public Set<Vehicle> getAffectedVehicles() {
		Set<Vehicle> veh = new HashSet<>();
		for (Set<Vehicle> vIds : mapping.values()) {
			veh.addAll(vIds);
		}
		return veh;
	}

	/**
	 * @return an array containing: <br>
	 *         <ul>
	 *         <li>0: number of sources</li>
	 *         <li>1 minimum vehicles</li>
	 *         <li>2: maximum vehicles</li>
	 *         </ul>
	 */
	public double[] getNumberOfOccupiedSources() {
		int num = 0;
		int min = Integer.MAX_VALUE;
		int max = 0;
		for (Set<Vehicle> vids : mapping.values()) {
			int curSize = vids.size();
			if (curSize > 0) {
				num++;
			}
			min = Math.min(curSize, min);
			max = Math.max(curSize, max);
		}

		return new double[] { num, min, max };
	}

	@Override
	public String toString() {
		StringBuffer str = new StringBuffer();
		str.append("Sum: ");
		str.append(sum());
		for (Long segId : mapping.keySet()) {
			str.append(segId);
			str.append("-");
			str.append(mapping.get(segId).toString());
			str.append(", ");
		}
		str.setLength(str.length() - 2);
		return str.toString();
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data;

import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalControlData;

public class HumanDriverControlData extends LongitudinalControlData {

	/** Unique model identifier */
	private static final String IDENTIFIER = "HDMx";

	// Noise models
	private String distanceNoiseIdentifier;
	private String velocityDifferenceNoiseIdentifier;

	// Spatial anticipation
	private int numConsideredVehicles;

	// Timely anticipation
	private boolean isAnticipative;

	// Finite reaction time
	private boolean isReactive;
	private double reactionTime;

	public HumanDriverControlData() {
		setIdentifier(IDENTIFIER);
	}

	public HumanDriverControlData(String distanceNoise, String velocityDifferenceNoise, double reactionTime, boolean isReactive,
			boolean isAnticipative, int numConsideredVehicles) {
		setIdentifier(IDENTIFIER);
		setDistanceNoiseIdentifier(distanceNoise);
		setVelocityDifferenceNoiseIdentifier(velocityDifferenceNoise);
		setReactionTime(reactionTime);
		setIsReactive(isReactive);
		setIsAnticipative(isAnticipative);
		setNumConsideredVehicles(numConsideredVehicles);
	}

	public String getDistanceNoiseIdentifier() {
		return distanceNoiseIdentifier;
	}

	public void setDistanceNoiseIdentifier(String distanceNoiseIdentifier) {
		this.distanceNoiseIdentifier = distanceNoiseIdentifier;
	}

	public String getVelocityDifferenceNoiseIdentifier() {
		return velocityDifferenceNoiseIdentifier;
	}

	public void setVelocityDifferenceNoiseIdentifier(String velocityDifferenceNoiseIdentifier) {
		this.velocityDifferenceNoiseIdentifier = velocityDifferenceNoiseIdentifier;
	}

	public int getNumConsideredVehicles() {
		return numConsideredVehicles;
	}

	public void setNumConsideredVehicles(int numConsideredVehicles) {
		this.numConsideredVehicles = numConsideredVehicles;
	}

	public boolean getIsAnticipative() {
		return isAnticipative;
	}

	public void setIsAnticipative(boolean isAnticipative) {
		this.isAnticipative = isAnticipative;
	}

	public boolean getIsReactive() {
		return isReactive;
	}

	public void setIsReactive(boolean isReactive) {
		this.isReactive = isReactive;
	}

	public double getReactionTime() {
		return reactionTime;
	}

	public void setReactionTime(double reactionTime) {
		this.reactionTime = reactionTime;
	}
}

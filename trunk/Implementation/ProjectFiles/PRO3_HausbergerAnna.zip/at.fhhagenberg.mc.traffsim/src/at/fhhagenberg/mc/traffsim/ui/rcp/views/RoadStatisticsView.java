package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;
import java.util.List;

import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider;
import org.csstudio.swt.xygraph.dataprovider.Sample;
import org.csstudio.swt.xygraph.figures.ToolbarArmedXYGraph;
import org.csstudio.swt.xygraph.figures.Trace;
import org.csstudio.swt.xygraph.figures.Trace.PointStyle;
import org.csstudio.swt.xygraph.figures.Trace.TraceType;
import org.csstudio.swt.xygraph.figures.XYGraph;
import org.csstudio.swt.xygraph.util.XYGraphMediaFactory;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.IRoadStatisticsChangedListener;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.statistics.LaneStatisticsData;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.ChartUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class RoadStatisticsView extends ViewPart implements IModelInputChangedListener, IRoadStatisticsChangedListener {

	public static String ID = "at.fhhagenberg.mc.traffsim.views.statistics.road";
	int oldComboSize = -1;

	private RoadSegment currentSegment;

	private Combo combo;
	private boolean autoUpdate = true;
	private CircularBufferDataProvider accumDataProvider;
	private XYGraph xyLineGraph;
	private List<CircularBufferDataProvider> additionalProviders = new ArrayList<>();
	private List<Trace> additionalTraces = new ArrayList<>();
	private boolean updateOnce;
	private long lastUpdate;
	private int lastSampleIndex;

	private int updateInterval = PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL);
	private SimulationModel currentModel;
	private Spinner spinnerSampleInterval;
	private XYGraph xyBarGraph;
	private CircularBufferDataProvider barDataProvider;
	private List<Trace> barTraces = new ArrayList<>();

	public RoadStatisticsView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(3, false));

		// Composite barComposite = createBarChart(container);
		// barComposite.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, true, 1, 1));

		Composite chartComposite = createLineChart(container);
		chartComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		Composite controls = new Composite(container, SWT.NONE);
		controls.setLayout(new GridLayout(2, false));

		Label lblVehicleId = new Label(controls, SWT.NONE);
		lblVehicleId.setText("Seg ID");

		combo = new Combo(controls, SWT.READ_ONLY);
		GridData gd_combo = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_combo.widthHint = 30;
		combo.setLayoutData(gd_combo);
		combo.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (currentSegment != null) {
					currentSegment.removeRoadDataChangedListener(RoadStatisticsView.this);
				}
				resetChartUi();
				currentSegment = currentModel.getNetwork().getRoadSegmentByKey(Long.valueOf(combo.getText()));
				currentSegment.addRoadDataChangedListener(RoadStatisticsView.this);
				for (LaneSegment ls : currentSegment.getLaneSegments()) {
					CircularBufferDataProvider prov = ChartUtil.createDataProvider(5000, updateInterval);
					Trace tr = createTrace("LS" + ls.getLaneIndex(), prov);
					xyLineGraph.addTrace(tr);
					additionalProviders.add(prov);
					additionalTraces.add(tr);
				}
				roadDataChanged(currentSegment.getId(), 0);
			}
		});

		final Button btnAutoUpdate = new Button(controls, SWT.CHECK);
		btnAutoUpdate.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnAutoUpdate.setSelection(true);
		btnAutoUpdate.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnAutoUpdate.getSelection()) {
					autoUpdate = true;
				} else {
					autoUpdate = false;
				}
			}
		});
		btnAutoUpdate.setText("Auto Update");

		TraffSimCorePlugin.getDefault().getPreferenceStore().addPropertyChangeListener(new IPropertyChangeListener() {

			@Override
			public void propertyChange(PropertyChangeEvent event) {
				if (event.getProperty().equals(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL)) {
					updateInterval = (int) event.getNewValue();
				}
			}
		});

		Label lblSampleInterval = new Label(controls, SWT.NONE);
		lblSampleInterval.setText("Sampe [ms]");

		spinnerSampleInterval = new Spinner(controls, SWT.BORDER);
		spinnerSampleInterval.setIncrement(1);
		spinnerSampleInterval.setPageIncrement(10);
		spinnerSampleInterval.setMaximum(120);
		spinnerSampleInterval.setMinimum(5);
		spinnerSampleInterval.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				resetChartUi();
				roadDataChanged(currentSegment.getId(), 0);
			}
		});
		new Label(container, SWT.NONE);
		SimulationKernel.getInstance().addInputChangedListener(this);
	}

	// private Composite createBarChart(Composite container) {
	// Canvas canvas = new Canvas(container, SWT.NONE);
	// final LightweightSystem lws = new LightweightSystem(canvas);
	// xyBarGraph = new XYGraph();
	// xyBarGraph.setTitle("");
	// xyBarGraph.primaryXAxis.setTitle("time [s]");
	// xyBarGraph.primaryYAxis.setTitle("flow [veh/s]");
	// xyBarGraph.primaryYAxis.setAutoScale(true);
	// xyBarGraph.primaryXAxis.setAutoScale(true);
	// xyBarGraph.primaryXAxis.setShowMajorGrid(true);
	// xyBarGraph.primaryYAxis.setShowMajorGrid(true);
	// xyBarGraph.primaryXAxis.setAutoScaleThreshold(0.5);
	// xyBarGraph.primaryYAxis.setAutoScaleThreshold(0.8);
	// xyBarGraph.primaryYAxis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_BLUE));
	// xyBarGraph.primaryXAxis.setDateEnabled(true);
	// barDataProvider = ChartUtil.createDataProvider(5000, IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL);
	// Trace barTrace = new Trace("Overview", xyBarGraph.primaryXAxis, xyBarGraph.primaryYAxis, barDataProvider);
	// // barTrace.setPointStyle(PointStyle.DIAMOND);
	// barTrace.setPointSize(10);
	// barTrace.setAreaAlpha(350);
	// barTrace.setTraceType(TraceType.BAR);
	// barTrace.setAntiAliasing(true);
	// xyBarGraph.addTrace(barTrace);
	// return canvas;
	// }

	private Composite createLineChart(Composite container) {
		Canvas canvas = new Canvas(container, SWT.NONE);
		final LightweightSystem lws = new LightweightSystem(canvas);
		xyLineGraph = new XYGraph();
		xyLineGraph.setTitle("");
		xyLineGraph.primaryXAxis.setTitle("time [s]");
		xyLineGraph.primaryYAxis.setTitle("flow [veh/min]");
		xyLineGraph.primaryYAxis.setAutoScale(true);
		xyLineGraph.primaryXAxis.setAutoScale(true);
		xyLineGraph.primaryXAxis.setShowMajorGrid(true);
		xyLineGraph.primaryYAxis.setShowMajorGrid(true);
		xyLineGraph.primaryXAxis.setAutoScaleThreshold(0.5);
		xyLineGraph.primaryYAxis.setAutoScaleThreshold(0.8);
		xyLineGraph.primaryYAxis.setRange(0, Double.MAX_VALUE);
		xyLineGraph.primaryYAxis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_BLUE));
		xyLineGraph.primaryXAxis.setDateEnabled(true);
		ToolbarArmedXYGraph toolbarArmedXYGraph = new ToolbarArmedXYGraph(xyLineGraph);
		lws.setContents(toolbarArmedXYGraph);
		accumDataProvider = ChartUtil.createDataProvider(5000, PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL));
		Trace accTrace = createTrace("Flow", accumDataProvider);
		xyLineGraph.addTrace(accTrace);
		return canvas;
	}

	private Trace createTrace(String name, CircularBufferDataProvider provider) {
		Trace trace = new Trace(name, xyLineGraph.primaryXAxis, xyLineGraph.primaryYAxis, provider);
		trace.setPointStyle(PointStyle.DIAMOND);
		trace.setPointSize(10);
		trace.setAreaAlpha(350);
		trace.setTraceType(TraceType.AREA);
		trace.setAntiAliasing(true);
		return trace;
	}

	@Override
	public void setFocus() {
		// unused

	}

	private void resetChartUi() {
		accumDataProvider.clearTrace();
		for (CircularBufferDataProvider prov : additionalProviders) {
			prov.clearTrace();
		}
		additionalProviders = new ArrayList<>();
		for (Trace tr : additionalTraces) {
			xyLineGraph.removeTrace(tr);
		}
		additionalTraces = new ArrayList<>();
		updateOnce = true;
		lastSampleIndex = 0;
		barTraces = new ArrayList<>();
	}

	@Override
	public void inputChanged(final SimulationModel newModel) {
		if (newModel != null && newModel.equals(currentModel)) {
			return;
		}
		currentModel = newModel;
		if (newModel == null) {
			return;
		}
		getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (!combo.isDisposed()) {
					combo.removeAll();
					for (Long id : newModel.getNetwork().getRoadSegmentKeys()) {
						combo.add(id + "");
					}
					resetChartUi();
				}
			}
		});
		currentSegment = null;
	}

	@Override
	public void roadDataChanged(long roadSegmentId, int laneIndex) {
		if (updateOnce || autoUpdate && currentSegment != null && roadSegmentId == currentSegment.getId()
				&& System.currentTimeMillis() - lastUpdate > updateInterval) {
			if (currentSegment == null) {
				return;
			}
			final LaneStatisticsData data = currentSegment.getCompleteRoadStatistics();
			lastUpdate = System.currentTimeMillis();
			// reconstruct data
			getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					// line chart
					final int sampleInterval = spinnerSampleInterval.getSelection() * 1000;
					for (int i = lastSampleIndex; i < data.getTime().size(); i++) {
						long nextStop = data.getTime().get(i++).getTime() + sampleInterval;
						int numVeh = 0;
						while (i < data.getTime().size() && data.getTime().get(i++).getTime() < nextStop) {
							numVeh++;
						}
						/** check if we have a whole sample */
						if (i < data.getTime().size()) {
							accumDataProvider.addSample(new Sample(data.getTime().get(i).getTime(), numVeh * 60000 / sampleInterval));
							lastSampleIndex = i;
						}
					}
				}
			});
			updateOnce = false;
		}
	}

	@Override
	public void dispose() {
		SimulationKernel.getInstance().removeInputChangedListener(this);
		super.dispose();
	}
}

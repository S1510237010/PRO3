package at.fhhagenberg.mc.traffsim.vehicle.model.platoon;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationObserver;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon.ManeuverResult;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonActionData;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonManagerData;

/**
 * Manager for platoons, handles platoon action and later on should detect possible platoons
 *
 * @author Sebastian Huber
 *
 */
public class PlatoonManager implements ISimulationTimeUpdatable {

	/**
	 * XML config data
	 */
	PlatoonManagerData data;

	/**
	 * All platoons which are managed by the manager
	 */
	private Map<Long, Platoon> platoons = new HashMap<>();

	/**
	 * List of platoon actions which are not triggered yet
	 */
	private List<PlatoonActionData> platoonActions = new ArrayList<>();

	/**
	 * Simualtion observer of the current simulation
	 */
	private SimulationObserver simObserver;

	/**
	 * CTor
	 *
	 * @param data
	 *            data entity which holds parameters from the configuration file
	 */
	public PlatoonManager(PlatoonManagerData data) {
		this.data = data;
		this.platoonActions = data.getPlatoonActions();
	}

	/**
	 * Simulation Observer of the current simulation
	 *
	 * @param simObserver
	 *            simulation observer
	 */
	public void setSimulationObserver(SimulationObserver simObserver) {
		this.simObserver = simObserver;
	}

	@Override
	public void timeStep(double dt, Date simulationTime, double simulationRunTime) {
		List<Long> platoonIdsMarkedForRemove = new ArrayList<>();
		for (Map.Entry<Long, Platoon> p : platoons.entrySet()) {
			// cleanup empty platoons
			if (p.getValue().getAllVehicles().isEmpty()) {
				platoonIdsMarkedForRemove.add(p.getKey());
			}
			// maneuver timeout
			p.getValue().checkTimeouts(simulationTime);
		}
		// cleanup
		for (Long id : platoonIdsMarkedForRemove) {
			platoons.remove(id);
		}
		// platoon actions
		if (platoonActions != null && platoonActions.size() > 0) {
			int i = 0;
			while (platoonActions.size() > i && simulationTime.after(platoonActions.get(i).getTime())) {
				PlatoonActionData action = platoonActions.get(i);
				ManeuverResult result = ManeuverResult.SUCCESS;
				if (action != null) {
					// remove actions where action timeout is reached
					if ((simulationTime.getTime() - action.getTime().getTime()) / 1000.0 > data.getActionTimeout()) {
						Logger.logWarn("PlatoonManager: Reached timeout for action " + action);
						platoonActions.remove(action);
						continue;
					}
					if (action.getVehicle() == null || simObserver.getVehicleById(action.getVehicle().getUniqueId()) != null) {
						Platoon p = platoons.get(action.getPlatoonId());
						switch (action.getAction()) {
						case JOIN:
							if (p == null) {
								p = new Platoon(action.getPlatoonId(), data.getPlatoonData());
								platoons.put(action.getPlatoonId(), p);
							}
							result = p.join(action.getVehicle(), action.getPosition(), simulationTime, action.isForce());
							break;
						case LEAVE:
							if (p == null) {
								Logger.logWarn("Platoon for leave action does not exist!");
								break;
							}
							result = p.leave(action.getVehicle(), action.isForce());
							break;
						case DISSOLVE:
							if (p == null) {
								Logger.logWarn("Platoon for leave action does not exist!");
								break;
							}
							result = p.dissolve(action.getVehicle(), action.isForce());
							break;
						case ABORT:
							if (p == null) {
								Logger.logWarn("Platoon for leave action does not exist!");
								break;
							}
							result = p.abort();
							break;
						}
					} else {
						Logger.logWarn("Veicle for platoon action is not in simulation!");
					}
				} else {
					Logger.logWarn("Read null platoon action!");
				}

				switch (result) {
				case ALREADY_JOINED:
				case FAILURE:
				case IN_OTHER_PLATOON:
				case NOT_ALLOWED:
				case NOT_CAPABLE_FOR_PLATOONS:
				case NOT_IN_PLATOON:
				case NO_LEADER_CAPABILITY:
				case NO_MANEUVER:
				case PLATOON_FULL:
				case TOO_SLOW_FOR_PLATOON:
					platoonActions.remove(i);
					Logger.logWarn("PlatoonManager: Action Result " + result + " for action " + action);
					break;
				case NOT_IN_RANGE:
				case PLATOON_BUSY:
				case ROAD_TOO_SMALL:
				case WRONG_LANE_TYPE:
					++i;
					break;
				case SUCCESS:
				case SUCCESS_WITH_POSITION_CHANGE:
					platoonActions.remove(i);
					break;
				default:
					++i;
					break;

				}
			}
		}
	}
}

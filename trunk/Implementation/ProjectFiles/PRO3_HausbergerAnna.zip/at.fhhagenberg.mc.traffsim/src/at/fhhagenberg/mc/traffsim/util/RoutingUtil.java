package at.fhhagenberg.mc.traffsim.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.routing.RoutingException;
import at.fhhagenberg.mc.traffsim.util.types.JunctionWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

public class RoutingUtil {
	public static final RouteBean toRouteBean(long id, long[] routingIds, RoadSegment initial) {
		RouteBean result = new RouteBean(id, routingIds);
		return result;
	}

	public static final IRoute updateInitialAndTargetRoadSegments(IRoute route, Map<Long, List<RoadSegment>> routingSegmentIdMapping)
			throws RoutingException {
		List<RoadSegment> segments = new ArrayList<>();
		traverseRoute(route, getInitialSegment(route, routingSegmentIdMapping), seg -> segments.add(seg));
		route.setInitialRoadSegment(CollectionUtil.getFirstObject(segments));
		route.setTargetSegment(CollectionUtil.getLastObject(segments));
		List<Boolean> segmentReverse = new ArrayList<>();
		for (RoadSegment rs : segments) {
			segmentReverse.add(rs.isOsmReverse());
		}
		route.setIsReverse(segmentReverse);
		return route;
	}

	public static final RoadSegment getInitialSegment(IRoute route, Map<Long, List<RoadSegment>> routingSegmentIdMapping) throws RoutingException {
		long firstRoutingId = route.getRouteIds().get(0);
		long secondRoutingId = route.getRouteIds().size() > 1 ? route.getRouteIds().get(1) : Long.MIN_VALUE;
		List<RoadSegment> segmentsWithFirstRoutingId = routingSegmentIdMapping.get(firstRoutingId);
		if (segmentsWithFirstRoutingId == null) {
			return null;
		}
		if (route.getRouteIds().size() == 1) {
			for (RoadSegment seg : segmentsWithFirstRoutingId) {
				if (seg.getSinkRoadSegment() == null && seg.getJunction() == null) {
					route.setInitialRoadSegment(seg);
					return seg;
				}
			}
		}
		for (RoadSegment segRoutingId : segmentsWithFirstRoutingId) {
			/** one of the segments having the initial routing id */
			if ((segRoutingId.getJunction() != null && segRoutingId.getJunction().getConnector(firstRoutingId, secondRoutingId) != null)
					|| (segRoutingId.getSinkRoadSegment() != null && segRoutingId.getSinkRoadSegment().getRoutingId() == secondRoutingId)) {
				return segRoutingId;
			}
		}
		return null;
	}

	/**
	 * Verifies whether a route is consistent, meaning that the
	 *
	 * @param route
	 *            the route to check
	 * @param fromSegment
	 *            the segment from where to start the check
	 * @return <code>true</code> if it is possible to drive along the route without any problems
	 */
	public static final boolean isRouteConsistent(IRoute route, RoadSegment fromSegment) {
		try {
			traverseRoute(trimUntilId(route, fromSegment.getRoutingId()), fromSegment, null);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Traverse the given route and performs the action on each road segment that is passed during this route.
	 *
	 * @param route
	 * @param initialSegment
	 * @param action
	 * @throws RoutingException
	 *             if the route is inconsistent and cannot be traversed. A missing routing id of the given initialSegment is tolerated, if
	 *             only this id is missing.
	 */
	public static final void traverseRoute(IRoute route, RoadSegment initialSegment, Consumer<RoadSegment> action) throws RoutingException {
		if (route.getRouteIds().isEmpty()) {
			return;
		}
		RoadSegment current = initialSegment;
		if (current == null) {
			throw new RoutingException(
					"Route " + route.getId() + " references non-existent start segment (routing id-1 " + route.getNextRoutingId() + ")");
		}
		List<Long> routeIds = new ArrayList<>(route.getRouteIds());
		if (CollectionUtil.getFirstObject(routeIds) != initialSegment.getRoutingId()) {
			routeIds.add(0, initialSegment.getRoutingId());
		}
		// traverse route
		for (int i = 0; i < routeIds.size(); i++) {
			if (action != null) {
				action.accept(current);
			}

			Long routingId = routeIds.get(i);
			/* also check if we are ahead of the first segment to tolerate the missing routing id of the initial segment */
			if (current.getRoutingId() != routingId) {
				throw new RoutingException(
						String.format("Error while traversing route #%d near road segment #%d (expected routing id %d, but was %d)", route.getId(),
								current.getId(), current.getRoutingId(), routingId));
			}
			if (current.getSinkRoadSegment() != null) {
				current = current.getSinkRoadSegment();
			} else if (current.getJunction() != null && i < routeIds.size() - 1) {
				current = current.getJunction().getConnector(routingId, routeIds.get(i + 1)).getSinkLaneSegment().getRoadSegment();
			} else if (i != routeIds.size() - 1) {
				throw new RoutingException("traversal unsuccessful!");
			}
		}
	}

	/**
	 * Find the next {@link LaneSegment} after the current lane which has the given routing id
	 *
	 * @param curLane
	 *            the current lane after which to find the matching one
	 * @param nextRoutingId
	 *            the routing id for the next {@link LaneSegment}
	 * @return the found {@link LaneSegment}, or <code>null</code> if nothing found
	 */
	public static LaneSegment getNextLaneSegment(VehiclesLane curLane, long nextRoutingId) {
		if (curLane instanceof JunctionConnector) {
			if (((JunctionConnector) curLane).getSinkLaneSegment().getRoadSegment().getRoutingId() == nextRoutingId) {
				return curLane.getSinkLaneSegment();
			}
		} else if (curLane instanceof LaneSegment) {
			LaneSegment curSink = curLane.getSinkLaneSegment();
			if (curSink != null) {
				if (curSink.getRoadSegment().getRoutingId() == nextRoutingId) {
					return curSink;
				}
			} else {
				AbstractJunction junc = curLane.getRoadSegment().getJunction();
				return junc.getConnector(curLane.getRoadSegment().getRoutingId(), nextRoutingId).getSinkLaneSegment();
			}
		}
		return null;
	}

	/**
	 * Find the {@link LaneSegment} which is passed next by the given vehicle
	 *
	 * @param v
	 *            the {@link Vehicle} to find out
	 * @return the next lane segment along the route, or <code>null</code> if not found
	 */
	public static LaneSegment getNextLaneSegment(Vehicle v) {
		return getNextLaneSegment(v.getLaneSegment(), v.getRoute().getNextRoutingId());
	}

	/**
	 * Check if the given route passes the junction within the given number of segments
	 *
	 * @param newRoute
	 * @param junc
	 * @param withinSegments
	 * @return <code>true</code> if the route passes the given junction, <code>false</code> otherwise
	 */
	public static boolean routePasses(IRoute newRoute, AbstractJunction junc, int withinSegments) {
		if (junc.getSegmentsOut().stream().anyMatch(rs -> rs.getRoutingId() == newRoute.getNextRoutingId())) {
			return true;
		}
		List<Long> rIds = newRoute.getRouteIds();
		for (int i = 0; i < rIds.size() - 1 && i < withinSegments; i += 1) {
			if (junc.getBorderingRoutingIds().contains(rIds.get(i)) && junc.getBorderingRoutingIds().contains(rIds.get(i + 1))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check if the provided routes pass the given junction, AND use the same connector (from in to out segment)
	 *
	 * @param route1
	 *            the first route to check
	 * @param route2
	 *            the second route to check
	 * @param junc
	 *            the junction which is checked whether both routes pass it
	 * @return <code>true</code> if both routes pass the junction using the same connector, <code>false</code> otherwise
	 */
	public static boolean routesPassSameConnector(IRoute route1, IRoute route2, AbstractJunction junc) {
		List<Long> rIds1 = route1.getRouteIds();
		List<Long> rIds2 = route2.getRouteIds();
		List<Long> segIdsIn = junc.getSegmentsIn().stream().map(RoadSegment::getRoutingId).collect(Collectors.toList());
		List<Long> segIdsOut = junc.getSegmentsOut().stream().map(RoadSegment::getRoutingId).collect(Collectors.toList());
		segIdsIn.retainAll(rIds1);
		segIdsOut.retainAll(rIds1);
		return rIds2.containsAll(segIdsIn) && rIds2.containsAll(segIdsOut);
	}

	/**
	 * Parses a route out of a {@link String}, which is terminated by [ and ]
	 *
	 * @param routeString
	 * @return the parsed routes of of the event description string, or empty list if nothing found
	 */
	public static List<IRoute> parseRoutesFromEvent(String routeString) {
		List<IRoute> routes = new ArrayList<>();
		Pattern pattern = Pattern.compile("\\[([^\\]]*)\\]");
		Matcher matcher = pattern.matcher(routeString);
		while (matcher.find()) {
			List<Long> route = CollectionUtil.toLongList(matcher.group(1), ",");
			routes.add(new Route(route));
		}
		return routes;
	}

	public static List<IRoute> getVehicleRoutes(Collection<Vehicle> vehicles) {
		List<IRoute> routes = new ArrayList<>();
		if (vehicles != null) {
			for (Vehicle v : vehicles) {
				routes.add(v.getRoute());
			}
		}
		return routes;
	}

	/**
	 * Check if the provided route assignment is ok and does not require a reverse 180 degree turn of the vehicle, requires potential
	 * impossible breaks before junctions etc.
	 *
	 * @param vehicle
	 *            the vehicle which may be assigned the route
	 * @param newRoute
	 *            the new route to test
	 * @return true if reverse turn is necessary, false otherwise
	 */
	public static boolean isRouteAssignmentOk(Vehicle vehicle, IRoute newRoute) {
		/** Check if route implies turnaround (next junction contains connector) */
		JunctionWithDistance juncWithDist = RoadUtil.getNextJunction(vehicle.getLaneSegment());
		// check if too close to junction for route change
		if (!routesPassSameConnector(vehicle.getRoute(), newRoute, juncWithDist.getJunction())
				&& !TrafficUtil.isSafeBreakPossible(vehicle, (juncWithDist.getDistance() - vehicle.getFrontPosition()))) {
			return false;
		}
		// check if route makes 180 degree turn
		if (routeMakesUturn(vehicle.getLaneSegment(), newRoute)) {
			return false;
		}
		// check if next junction contains the connector
		AbstractJunction nextJunc = juncWithDist.getJunction();
		List<Long> routeIdsInclCurrent = new ArrayList<>(newRoute.getRouteIds());
		if (vehicle.getRoadSegment() != null) {
			routeIdsInclCurrent.add(0, vehicle.getRoadSegment().getRoutingId());
		}
		RoadSegment currentRoadSeg = RoadUtil.getNextRoadSegment(vehicle.getLaneSegment());
		RoadSegment lastSegBeforeJunction = RoadUtil.getConnectingSegmentForward(currentRoadSeg, nextJunc);
		int indexOfLastSegBeforeJunction = routeIdsInclCurrent.indexOf(lastSegBeforeJunction.getRoutingId());
		boolean foundConnector = indexOfLastSegBeforeJunction >= 0 && routeIdsInclCurrent.size() > 1
				&& nextJunc.getConnector(routeIdsInclCurrent.get(indexOfLastSegBeforeJunction),
						routeIdsInclCurrent.get(indexOfLastSegBeforeJunction + 1)) != null;
		return foundConnector && isRouteConsistent(newRoute, currentRoadSeg);
	}

	public static boolean routeMakesUturn(VehiclesLane currentLane, IRoute route) {
		RoadSegment nextRoadSeg = RoadUtil.getNextRoadSegment(currentLane);
		if (nextRoadSeg != null) {
			if (nextRoadSeg.getRoutingId() == route.getNextRoutingId()
					|| nextRoadSeg.getSinkRoadSegment() != null && nextRoadSeg.getSinkRoadSegment().getRoutingId() == route.getNextRoutingId()) {
				return false;
			}
			if (nextRoadSeg.getJunction() != null
					&& nextRoadSeg.getJunction().getConnector(nextRoadSeg.getRoutingId(), route.getNextRoutingId()) != null) {
				// connector in next junction not found
				return false;
			}
		}
		return true;
	}

	/**
	 * trim the route and remove a number of segment references from beginning and end
	 *
	 * @param route
	 *            the route to trim (will not be modified!)
	 * @param beginning
	 *            the number of segments to remove from beginning
	 * @param end
	 *            the number of segments to remove from end
	 * @return new, trimmed {@link Route} object
	 */
	public static IRoute trimRoute(IRoute route, int beginning, int end) {
		List<Long> ids = CollectionUtil.trimCollection(route.getRouteIds(), beginning, 0);
		List<Boolean> isReverse = CollectionUtil.trimCollection(route.getIsReverse(), beginning, 0);
		Route result = new Route(route, ids, isReverse);
		return result;
	}

	/**
	 * Trims the beginning of the route until the given id is reached. The part of the route BEFORE the given id is removed.
	 *
	 * @param route
	 *            the route to trim
	 * @param id
	 *            the id to find
	 * @return a new, trimmed route, containing the given id and all route ids after it, or the original one if id not found.
	 */
	public static IRoute trimUntilId(IRoute route, long id) {
		int ind = route.getRouteIds().indexOf(id);
		if (ind > 0) {
			return trimRoute(route, ind, route.getRouteIds().size());
		} else {
			return route;
		}
	}

	public static boolean routeContains(IRoute route, IRoute newRoute) {
		return route.getRouteIds().containsAll(newRoute.getRouteIds()) || newRoute.getRouteIds().containsAll(route.getRouteIds());
	}

	public static IRoute subtractRoute(IRoute originalRoute, IRoute toSubtract) {
		List<Long> remainingIds = new ArrayList<Long>(originalRoute.getRouteIds());
		remainingIds.removeAll(toSubtract.getRouteIds());
		ArrayList<Boolean> reverse = new ArrayList<>();
		remainingIds.forEach(rid -> reverse.add(originalRoute.getIsReverse().get(originalRoute.getRouteIds().indexOf(rid))));
		Route newRt = new Route(remainingIds);
		newRt.setIsReverse(reverse);
		return newRt;
	}

}

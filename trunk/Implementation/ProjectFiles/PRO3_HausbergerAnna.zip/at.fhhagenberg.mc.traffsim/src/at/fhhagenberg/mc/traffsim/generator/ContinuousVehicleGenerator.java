package at.fhhagenberg.mc.traffsim.generator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.math3.distribution.NormalDistribution;

import at.fhhagenberg.mc.traffsim.data.beans.TrafficGeneratorBean;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;

/**
 * Implementation of {@link AbstractVehicleGenerator} which adds vehicles to a specific road segment periodically.
 *
 * @author Christian Backfrieder
 */
public class ContinuousVehicleGenerator extends AbstractVehicleGenerator {

	private RoadSegment initialRoadSegment;

	private double speedInitial;
	private double speedAverage;
	private double speedAverageStdDeviation;

	private double currentInFlow;
	private double inFlowRateMean = TrafficDefaults.DEFAULT_INFLOW;
	private double inFlowRateStdDeviation = TrafficDefaults.DEFAULT_INFLOW_STDDEV;

	private boolean isStochastic = false;
	private double sampleInterval = TrafficDefaults.DEFAULT_INFLOW_SAMPLE_INTERVAL;

	private double vehicleLengthStdDeviation = 0;

	private NormalDistribution normalDistribution;
	private List<IRoute> possibleRoutes = new ArrayList<>();

	private int totalNumVehicles;
	private int createdVehicles;

	/**
	 * Helping variable to determine the number of vehicles being generated within one simulation time step
	 */
	private double lastRest = 1;
	private double lastVariation;

	private String fuelModelIdentifier;
	private String laneChangeModelIdentifier;
	private String longitudinalControlIdentifier;
	private String memoryModelIdentifier;
	private String noiseModelIdentifier;

	public ContinuousVehicleGenerator(SimulationModel model, long id, double initialSpeed, double inFlowRatePerHour, double inflowStdDeviation,
			boolean isStochastic, double sampleInterval, RoadSegment initialRoadSegment, double averageSpeed, double speedStd, int numVehicles) {

		setId(id);
		this.inFlowRateStdDeviation = inflowStdDeviation;
		this.initialRoadSegment = initialRoadSegment;
		this.speedAverage = averageSpeed;
		this.speedAverageStdDeviation = speedStd;
		this.sampleInterval = sampleInterval;
		this.speedInitial = initialSpeed;
		this.model = model;
		this.totalNumVehicles = numVehicles == 0 ? Integer.MAX_VALUE : numVehicles;
		this.isStochastic = isStochastic;
		this.normalDistribution = new NormalDistribution(inFlowRatePerHour, inFlowRateStdDeviation);
		setInFlowRateMean(inFlowRatePerHour);
	}

	/**
	 * Adds the given {@link IRoute} to the list of possible routes.
	 *
	 * @param r
	 *            the {@link IRoute} to be added
	 */
	public void addPossibleRoute(IRoute r) {
		if (!possibleRoutes.contains(r)) {
			possibleRoutes.add(r);
		}
	}

	/**
	 * Returns a randomly selected {@link IRoute} obtained from the list of possible routes.
	 *
	 * @return a randomly selected route to be assigned to a generated vehicle
	 */
	private IRoute createRoute() {
		if (possibleRoutes != null && possibleRoutes.size() > 0) {
			return new Route(possibleRoutes.get((int) Math.floor(Math.random() * possibleRoutes.size())));
		}

		return null;
	}

	public void updatePossibleRoutes(List<Long> routeIds) {

		possibleRoutes.clear();

		for (Long routeId : routeIds) {
			if (model.getRouteRegistry().hasRoute(routeId)) {
				addPossibleRoute(model.getRouteRegistry().getRoute(routeId));
			}
		}
	}

	public RoadSegment getInitialRoadSegment() {
		return initialRoadSegment;
	}

	public double getSpeedInitial() {
		return speedInitial;
	}

	public double getSpeedAverage() {
		return speedAverage;
	}

	public double getSpeedAverageStdDeviation() {
		return speedAverageStdDeviation;
	}

	public double getInFlowRateMean() {
		return inFlowRateMean;
	}

	public double getInFlowRateStdDeviation() {
		return inFlowRateStdDeviation;
	}

	public double getSampleInterval() {
		return sampleInterval;
	}

	public int getMaxNumVehicles() {
		return totalNumVehicles;
	}

	public double getVehicleLengthStdDeviation() {
		return vehicleLengthStdDeviation;
	}

	public double getCurrentInFlow() {
		return currentInFlow;
	}

	public boolean isStochastic() {
		return isStochastic;
	}

	public String getLongitudinalControlIdentifier() {
		return longitudinalControlIdentifier;
	}

	public String getLaneChangeModelIdentifier() {
		return laneChangeModelIdentifier;
	}

	public String getFuelConsumptionModelIdentifier() {
		return fuelModelIdentifier;
	}

	public String getMemoryModelIdentifier() {
		return memoryModelIdentifier;
	}

	public List<IRoute> getPossibleRoutes() {
		return possibleRoutes;
	}

	public List<Long> getPossibleRouteIds() {
		List<Long> routeIds = new ArrayList<>();

		for (IRoute route : possibleRoutes) {
			routeIds.add(route.getId());
		}

		return routeIds;
	}

	/**
	 * Gets the number of vehicles being generated within the given simulation time step.
	 *
	 * @param dt
	 *            the simulation time step
	 * @return the number of vehicles generated within one simulation time step
	 */
	private int getNumberOfVehicles(double dt) {
		double vehFrac = currentInFlow * dt + lastRest;
		int numVehicles = (int) Math.floor(vehFrac);
		lastRest = vehFrac - numVehicles;
		return numVehicles;
	}

	@Override
	public boolean hasMoreVehicles() {
		return createdVehicles < totalNumVehicles;
	}

	public void setInitialRoadSegment(RoadSegment roadSegment) {
		this.initialRoadSegment = roadSegment;
	}

	public void setInitialSpeed(double initialSpeed) {
		this.speedInitial = initialSpeed;
	}

	public void setSpeedAverage(double averageSpeed) {
		this.speedAverage = averageSpeed;
	}

	public void setIsStochastic(boolean isStochastic) {
		this.isStochastic = isStochastic;
	}

	public void setSpeedAverageStdDeviation(double std) {
		this.speedAverageStdDeviation = std;
	}

	public void setInFlowRateMean(double inFlowMean) {
		this.inFlowRateMean = inFlowMean;
		this.currentInFlow = inFlowRateMean / 3600.0;
		setStochastic(isStochastic, getInFlowRateStdDeviation(), getSampleInterval());
	}

	public void setInFlowRateStdDeviation(double inFlowStdDeviation) {
		this.inFlowRateStdDeviation = inFlowStdDeviation;
	}

	public void setSampleInterval(double sampleInterval) {
		this.sampleInterval = sampleInterval;
	}

	public void setVehicleLengthStdDeviation(double std) {
		this.vehicleLengthStdDeviation = std;
	}

	public void setTotalNumVehicles(int totalNumVehicles) {
		this.totalNumVehicles = totalNumVehicles;
	}

	public void setStochastic(boolean isStochastic, double inFlowStdDeviation, double sampleInterval) {
		this.isStochastic = isStochastic;
		this.sampleInterval = sampleInterval;
		this.normalDistribution = new NormalDistribution(inFlowRateMean, inFlowStdDeviation);
		this.lastVariation = 0;
	}

	public void setFuelModelIdentifier(String fuelModelIdentifier) {
		this.fuelModelIdentifier = fuelModelIdentifier;
	}

	public void setLaneChangeModelIdentifier(String laneChangeModelIdentifier) {
		this.laneChangeModelIdentifier = laneChangeModelIdentifier;
	}

	public void setLongitudinalControlIdentifier(String longitudinalControlIdentifier) {
		this.longitudinalControlIdentifier = longitudinalControlIdentifier;
	}

	public void setMemoryModelIdentifier(String memoryModelIdentifier) {
		this.memoryModelIdentifier = memoryModelIdentifier;
	}

	public void setNoiseModelIdentifier(String noiseModelIdentifier) {
		this.noiseModelIdentifier = noiseModelIdentifier;
	}

	@Override
	public void timeStep(double dt, Date time, double runTime) {
		if (isStochastic && runTime - lastVariation > sampleInterval) {
			currentInFlow = normalDistribution.sample() / 3600.0;
			lastVariation = runTime;
		}

		int veh = getNumberOfVehicles(dt);

		if (veh + createdVehicles > totalNumVehicles) {
			veh = totalNumVehicles - createdVehicles;
		}

		if (veh <= 0) {
			return;
		} else {
			createdVehicles += veh;
		}

		for (int i = 0; i < veh; i++) {
			IRoute route = createRoute();

			if (route == null) {
				continue;
			}

			Vehicle newVeh = VehicleFactory.createVehicle(model, getSpeedAverage() + (Math.random() - 0.5) * getSpeedAverageStdDeviation(), 0, route,
					speedInitial, longitudinalControlIdentifier, laneChangeModelIdentifier, memoryModelIdentifier, noiseModelIdentifier,
					fuelModelIdentifier);

			notifyVehicleGenerated(newVeh);
			newVeh.setLength(newVeh.getLength() + (Math.random() - 0.5) * vehicleLengthStdDeviation);
			newVeh.setStartTime(model.getCurrentSimTime() != null ? model.getCurrentSimTime() : model.getStartDate());
			model.getVehicleProcessor().scheduleVehicle(initialRoadSegment, newVeh);
		}
	}

	public TrafficGeneratorBean toBean() {
		TrafficGeneratorBean bean = new TrafficGeneratorBean();
		bean.setId(getId());
		bean.setLongitudinalControlRef(getLongitudinalControlIdentifier());
		bean.setLaneChangeModelRef(getLaneChangeModelIdentifier());
		bean.setFuelConsumptionModelRef(getFuelConsumptionModelIdentifier());
		bean.setMemoryModelRef(getMemoryModelIdentifier());
		bean.setInitialRoadSegmentId(getInitialRoadSegment().getId());
		bean.setSpeedInitial(getSpeedInitial());
		bean.setSpeedAverage(getSpeedAverage());
		bean.setSpeedAverageStdDeviation(getSpeedAverageStdDeviation());
		bean.setInFlowRate(getInFlowRateMean());
		bean.setInFlowRateStdDeviation(getInFlowRateStdDeviation());
		bean.setIsStochastic(isStochastic());
		bean.setSampleInterval(getSampleInterval());
		bean.setVehicleLengthStdDeviation(getVehicleLengthStdDeviation());
		bean.setPossibleRouteIds(getPossibleRouteIds());
		bean.setMaxNumVehicles(getMaxNumVehicles());
		return bean;
	}

	@Override
	public void dispose() {

	}
}
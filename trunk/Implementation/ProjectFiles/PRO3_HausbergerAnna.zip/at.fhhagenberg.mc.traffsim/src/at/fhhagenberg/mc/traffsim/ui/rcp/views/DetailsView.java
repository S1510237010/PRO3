package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;

import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider;
import org.csstudio.swt.xygraph.dataprovider.Sample;
import org.csstudio.swt.xygraph.figures.Axis;
import org.csstudio.swt.xygraph.figures.ToolbarArmedXYGraph;
import org.csstudio.swt.xygraph.figures.Trace;
import org.csstudio.swt.xygraph.figures.Trace.PointStyle;
import org.csstudio.swt.xygraph.figures.XYGraph;
import org.csstudio.swt.xygraph.linearscale.AbstractScale.LabelSide;
import org.csstudio.swt.xygraph.util.XYGraphMediaFactory;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.LogMessage;
import at.fhhagenberg.mc.traffsim.model.IItemSelectionListener;
import at.fhhagenberg.mc.traffsim.model.ILogConsumer;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.routing.rerouter.footprint.TimeDynamicFootprintGenerator;
import at.fhhagenberg.mc.traffsim.ui.DrawingContext;
import at.fhhagenberg.mc.traffsim.ui.DrawingPanel;
import at.fhhagenberg.mc.traffsim.ui.Matrix;
import at.fhhagenberg.mc.traffsim.ui.UiFlag;
import at.fhhagenberg.mc.traffsim.ui.color.ColorSet;
import at.fhhagenberg.mc.traffsim.ui.color.DimensionLessColorSet;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.helper.NumberOnlyKeyAdapter;
import at.fhhagenberg.mc.traffsim.util.BitUtil;
import at.fhhagenberg.mc.traffsim.util.ChartUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleInJunction;
import at.fhhagenberg.mc.util.StringUtil;

public final class DetailsView extends ViewPart implements IItemSelectionListener, ILogConsumer, IModelInputChangedListener {
	/** Characters to look back when checking if a message is already contained in the last mesasges of the debug output */
	private static final int LOOKBACK_CHARACTERS_DEBUG_TEXT = 400;
	private static final int INITIAL_UPDATE_INTERVAL = 200;
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.details";
	private static final double INITIAL_JUNCTION_ZOOM_FACTOR = 0.3;
	protected static final double ZOOM_FACTOR_STEP = 1.2;

	private Label lblVehApproachingVal;
	private Label lblGrantsVal;
	private DrawingPanel drawingPanelJunction;
	private DrawingContext drawingContext = new DrawingContext();
	private Spinner spinnerInterval;
	private Label lblInterval;
	private BlockingQueue<String> debugMessages = new LinkedBlockingQueue<>();

	private static long maxViewId = 1;
	private static CopyOnWriteArrayList<DetailsView> openInstances = new CopyOnWriteArrayList<>();

	private class ModelDisposedException extends Exception {
		private static final long serialVersionUID = 8095179622235015752L;
	}

	private PauseableThread updateThread = new PauseableThread("Details update " + maxViewId++, 50) {

		@Override
		public void doWork() {
			updateJunction(false);
			updateRoadSegment(false);
		}
	};
	private AbstractJunction selectedJunction;
	private RoadSegment selectedRoadSegment;
	private double currentZoomFactor = INITIAL_JUNCTION_ZOOM_FACTOR;
	private Text textId;
	private Button btnCaptureSelections;
	private boolean captureSelection;
	private Text debugText;
	/** we cache this strnig to check if last messages contain duplicates */
	private String curDebugText = "";
	private Label lblVehInJunctionVal;
	protected ColorSet colorSet = new DimensionLessColorSet();

	private SimulationModel currentModel;
	private Text txtRsId;
	private Text txtVehicles;
	private Text txtLength;
	private Text txtKmcost;
	private Text txtCumCost;
	private DrawingPanel drawingPanelRoadSegment;
	private Text txtName;
	private XYGraph xyGraph;
	private CircularBufferDataProvider averageCostDataProvider;
	private CircularBufferDataProvider currentCostDataProvider;
	private Text txtFootprint;
	private Text txtHcostNorm;
	private Text txtAddCost;
	private Text txtHcostCur;
	private Text txtNumRoutesCrossing;
	private XYGraph xyGraph2;
	private CircularBufferDataProvider timeHistDataProvider;
	private XYGraph xyGraph3;
	private CircularBufferDataProvider junctionHistDataProvider;
	private Label lblDriveThroughNotPossible;

	public DetailsView() {
		inputChanged(SimulationKernel.getInstance().getActiveModel());
		SimulationKernel.getInstance().addInputChangedListener(this);
		updateThread.start();
		openInstances.add(this);
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		Composite compositeGlobalControls = new Composite(parent, SWT.NONE);
		compositeGlobalControls.setLayout(new GridLayout(4, false));
		compositeGlobalControls.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, true, false, 1, 1));

		Button btnAutoupdate = new Button(compositeGlobalControls, SWT.CHECK);
		btnAutoupdate.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				boolean autoupdate = ((Button) e.getSource()).getSelection();
				if (autoupdate) {
					updateThread.proceed();
				} else {
					updateThread.pause();
				}
				setIntervalControlsEnabled(autoupdate);
			}

		});
		btnAutoupdate.setSelection(true);
		btnAutoupdate.setText("Auto-Update");

		lblInterval = new Label(compositeGlobalControls, SWT.NONE);
		lblInterval.setText("Interval [ms]:");

		spinnerInterval = new Spinner(compositeGlobalControls, SWT.BORDER);
		spinnerInterval.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int selection = ((Spinner) e.getSource()).getSelection();
				updateThread.setDelayInMillis(selection);
			}
		});
		spinnerInterval.setPageIncrement(500);
		spinnerInterval.setIncrement(100);
		spinnerInterval.setMaximum(5000);
		spinnerInterval.setMinimum(50);
		spinnerInterval.setSelection(INITIAL_UPDATE_INTERVAL);

		btnCaptureSelections = new Button(compositeGlobalControls, SWT.CHECK);
		btnCaptureSelections.setToolTipText("Selections from the main map will be captured here to refresh current item");
		btnCaptureSelections.setText("Capture selections");
		for (DetailsView v : openInstances) {
			if (!this.equals(v)) {
				v.captureSelection = false;
				v.btnCaptureSelections.setSelection(false);
			}
		}
		btnCaptureSelections.setSelection(true);
		captureSelection = true;
		btnCaptureSelections.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				captureSelection = ((Button) e.getSource()).getSelection();
			}
		});

		TabFolder tabFolder = new TabFolder(parent, SWT.NONE);
		tabFolder.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		TabItem tbtmJunction = new TabItem(tabFolder, SWT.NONE);
		tbtmJunction.setText("Junction");

		Composite compositeJunction = new Composite(tabFolder, SWT.NONE);
		tbtmJunction.setControl(compositeJunction);
		compositeJunction.setLayout(new GridLayout(2, false));

		Composite compositeInfo = new Composite(compositeJunction, SWT.NONE);
		compositeInfo.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, true, 1, 1));
		compositeInfo.setLayout(new GridLayout(2, false));

		Label lblId = new Label(compositeInfo, SWT.NONE);
		lblId.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblId.setText("ID");

		textId = new Text(compositeInfo, SWT.BORDER);
		textId.addKeyListener(new NumberOnlyKeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.keyCode == SWT.CR || e.keyCode == SWT.KEYPAD_CR) {
					boolean found = false;
					for (AbstractJunction j : currentModel.getNetwork().getJunctions()) {
						if (new Long(textId.getText()).equals(j.getId())) {
							updateSelectedJunction(j);
							found = true;
						}
					}
					if (!found) {
						getDisplay().asyncExec(new Runnable() {
							@Override
							public void run() {
								textId.setText(selectedJunction == null ? "" : selectedJunction.getId() + "");
							}
						});
					}
				} else {
					super.keyReleased(e);
				}

			}

			@Override
			public Display getCurrentDisplay() {
				return getDisplay();
			}
		});
		textId.setToolTipText("Type ID and hit enter for refreshing");
		textId.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblNrVehiclesApproaching = new Label(compositeInfo, SWT.NONE);
		lblNrVehiclesApproaching.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblNrVehiclesApproaching.setText("Vehicles approaching:");

		lblVehApproachingVal = new Label(compositeInfo, SWT.NONE);
		lblVehApproachingVal.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		lblVehApproachingVal.setText(" ");

		Label lblGrants = new Label(compositeInfo, SWT.NONE);
		lblGrants.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblGrants.setText("Entry grants:");

		lblGrantsVal = new Label(compositeInfo, SWT.NONE);
		lblGrantsVal.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));

		Label vehInJunction = new Label(compositeInfo, SWT.NONE);
		vehInJunction.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		vehInJunction.setText("In junction:");

		lblVehInJunctionVal = new Label(compositeInfo, SWT.NONE);
		lblVehInJunctionVal.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));

		Label lblDriveThroughNot = new Label(compositeInfo, SWT.NONE);
		lblDriveThroughNot.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblDriveThroughNot.setText("Drive through not possible:");

		lblDriveThroughNotPossible = new Label(compositeInfo, SWT.NONE);
		lblDriveThroughNotPossible.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));

		SashForm sash = new SashForm(compositeJunction, SWT.NONE);

		sash.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));
		Composite drawingContainer = new Composite(sash, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		drawingContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));
		drawingContainer.setLayout(new FillLayout());
		Frame f = SWT_AWT.new_Frame(drawingContainer);

		drawingPanelJunction = new DrawingPanel();
		Panel rootPane = new Panel();
		rootPane.setLayout(new BorderLayout());
		rootPane.add(drawingPanelJunction);
		f.add(rootPane);

		Group consoleArea = new Group(sash, SWT.NONE);
		consoleArea.setText("Messages");
		consoleArea.setLayout(new GridLayout(1, false));

		debugText = new Text(consoleArea, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.MULTI);
		debugText.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		sash.setWeights(new int[] { 4, 3 });

		Group grpMap = new Group(compositeJunction, SWT.NONE);
		grpMap.setLayout(new FillLayout(SWT.HORIZONTAL));
		grpMap.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		grpMap.setText("Map");

		Button buttonZoomIn = new Button(grpMap, SWT.NONE);
		buttonZoomIn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				currentZoomFactor *= ZOOM_FACTOR_STEP;
				updateJunction(false);
			}
		});
		buttonZoomIn.setText("+");

		Button buttonZoomOut = new Button(grpMap, SWT.NONE);
		buttonZoomOut.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				currentZoomFactor /= ZOOM_FACTOR_STEP;
				updateJunction(false);
			}
		});
		buttonZoomOut.setText("-");

		createJunctionTimeHistChart(compositeJunction);
		// //////////////////////////////
		// ///// ROAD SEGMENT
		// //////////////////////////////
		TabItem tbtmRoadSegment = new TabItem(tabFolder, SWT.NONE);
		tbtmRoadSegment.setText("Road Segment");

		Composite compositeRoadSegment = new Composite(tabFolder, SWT.NONE);
		tbtmRoadSegment.setControl(compositeRoadSegment);
		compositeRoadSegment.setLayout(new GridLayout(1, false));
		SashForm sashRoadMain = new SashForm(compositeRoadSegment, SWT.VERTICAL);
		sashRoadMain.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		SashForm sashRoadSeg = new SashForm(sashRoadMain, SWT.NONE);
		sashRoadSeg.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		Composite drawingContainerRoadSeg = new Composite(sashRoadSeg, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		drawingContainerRoadSeg.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));
		drawingContainerRoadSeg.setLayout(new FillLayout());
		f = SWT_AWT.new_Frame(drawingContainerRoadSeg);

		drawingPanelRoadSegment = new DrawingPanel();
		rootPane = new Panel();
		rootPane.setLayout(new BorderLayout());
		rootPane.add(drawingPanelRoadSegment);
		f.add(rootPane);

		Composite rsDetails = new Composite(sashRoadSeg, SWT.NONE);
		rsDetails.setLayout(new GridLayout(2, false));

		Label lblId_1 = new Label(rsDetails, SWT.NONE);
		lblId_1.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblId_1.setText("ID");

		txtRsId = new Text(rsDetails, SWT.BORDER);
		txtRsId.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRsId.addKeyListener(new NumberOnlyKeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.keyCode == SWT.CR || e.keyCode == SWT.KEYPAD_CR) {
					boolean found = false;
					for (RoadSegment rs : currentModel.getNetwork().getRoadSegments()) {
						if (new Long(textId.getText()).equals(rs.getId())) {
							updateSelectedRoadSegment(rs);
							found = true;
						}
					}
					if (!found) {
						getDisplay().asyncExec(new Runnable() {
							@Override
							public void run() {
								textId.setText(selectedRoadSegment == null ? "" : selectedRoadSegment.getId() + "");
							}
						});
					}
				} else {
					super.keyReleased(e);
				}

			}

			@Override
			public Display getCurrentDisplay() {
				return getDisplay();
			}
		});

		Label lblName = new Label(rsDetails, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblName.setText("name");

		txtName = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblVehicles = new Label(rsDetails, SWT.NONE);
		lblVehicles.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblVehicles.setText("vehicles");

		txtVehicles = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtVehicles.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblGeometryLength = new Label(rsDetails, SWT.NONE);
		lblGeometryLength.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblGeometryLength.setText("geometry length");

		txtLength = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtLength.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblKmCost = new Label(rsDetails, SWT.NONE);
		lblKmCost.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblKmCost.setText("km cost");

		txtKmcost = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtKmcost.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblHCostCur = new Label(rsDetails, SWT.NONE);
		lblHCostCur.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblHCostCur.setText("h cost (cur.)");

		txtHcostCur = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtHcostCur.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblHCost = new Label(rsDetails, SWT.NONE);
		lblHCost.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblHCost.setText("h cost (norm.)");

		txtHcostNorm = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtHcostNorm.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblNumRoutesCrossing = new Label(rsDetails, SWT.NONE);
		lblNumRoutesCrossing.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblNumRoutesCrossing.setText("num routes crossing");

		txtNumRoutesCrossing = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtNumRoutesCrossing.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblFootprint = new Label(rsDetails, SWT.NONE);
		lblFootprint.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFootprint.setText("footprint");

		txtFootprint = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtFootprint.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblAdditionalCost = new Label(rsDetails, SWT.NONE);
		lblAdditionalCost.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblAdditionalCost.setText("additional cost");

		txtAddCost = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtAddCost.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 1, 1));

		Label lblCumCost = new Label(rsDetails, SWT.NONE);
		lblCumCost.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblCumCost.setText("cumulated cost");

		txtCumCost = new Text(rsDetails, SWT.BORDER | SWT.READ_ONLY);
		txtCumCost.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		createTimeHistChar(rsDetails);

		sashRoadSeg.setWeights(new int[] { 1, 1 });

		createCostChart(sashRoadMain);
		sashRoadMain.setWeights(new int[] { 294, 87 });

		TabItem tbtmVehicle = new TabItem(tabFolder, SWT.NONE);
		tbtmVehicle.setText("Vehicle");
	}

	private void createJunctionTimeHistChart(Composite compositeJunction) {
		Canvas junctionGraphCanvas = new Canvas(compositeJunction, SWT.NONE);
		GridData gd_junctionGraphCanvas = new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1);
		gd_junctionGraphCanvas.heightHint = 200;
		junctionGraphCanvas.setLayoutData(gd_junctionGraphCanvas);
		final LightweightSystem lws = new LightweightSystem(junctionGraphCanvas);
		xyGraph3 = new XYGraph();
		xyGraph3.setTitle("");
		xyGraph3.primaryXAxis.setTitle("time [s]");
		xyGraph3.primaryYAxis.setTitle("num vehicles");
		xyGraph3.primaryYAxis.setAutoScale(true);
		xyGraph3.primaryXAxis.setAutoScale(true);
		xyGraph3.primaryXAxis.setShowMajorGrid(true);
		xyGraph3.primaryYAxis.setShowMajorGrid(true);
		xyGraph3.primaryXAxis.setAutoScaleThreshold(0.2);
		xyGraph3.primaryYAxis.setAutoScaleThreshold(0.5);
		ToolbarArmedXYGraph toolbarArmedXYGraph = new ToolbarArmedXYGraph(xyGraph3);
		lws.setContents(toolbarArmedXYGraph);
		junctionHistDataProvider = ChartUtil.createDataProvider(500, (int) updateThread.getDelayInMillis());
		Trace junctionHistoryTrace = new Trace("time [s]", xyGraph3.primaryXAxis, xyGraph3.primaryYAxis, junctionHistDataProvider);
		junctionHistoryTrace.setPointStyle(PointStyle.NONE);
		junctionHistoryTrace.setAntiAliasing(true);

		xyGraph3.addTrace(junctionHistoryTrace);
	}

	private void createTimeHistChar(Composite rsDetails) {
		Canvas canvasTimeHist = new Canvas(rsDetails, SWT.NONE);
		canvasTimeHist.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		final LightweightSystem lws = new LightweightSystem(canvasTimeHist);
		xyGraph2 = new XYGraph();
		xyGraph2.setTitle("");
		xyGraph2.primaryXAxis.setTitle("time [s]");
		xyGraph2.primaryYAxis.setTitle("num vehicles");
		xyGraph2.primaryYAxis.setAutoScale(true);
		xyGraph2.primaryXAxis.setAutoScale(true);
		xyGraph2.primaryXAxis.setShowMajorGrid(true);
		xyGraph2.primaryYAxis.setShowMajorGrid(true);
		xyGraph2.primaryXAxis.setAutoScaleThreshold(0.2);
		xyGraph2.primaryYAxis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_BLUE));
		ToolbarArmedXYGraph toolbarArmedXYGraph = new ToolbarArmedXYGraph(xyGraph2);
		lws.setContents(toolbarArmedXYGraph);
		timeHistDataProvider = ChartUtil.createDataProvider(500, (int) updateThread.getDelayInMillis());
		Trace timeHistoryTrace = new Trace("time [s]", xyGraph2.primaryXAxis, xyGraph2.primaryYAxis, timeHistDataProvider);
		timeHistoryTrace.setPointStyle(PointStyle.NONE);
		timeHistoryTrace.setAntiAliasing(true);

		xyGraph2.addTrace(timeHistoryTrace);
	}

	private Composite createCostChart(Composite parent) {
		Canvas canvas = new Canvas(parent, SWT.NONE);
		final LightweightSystem lws = new LightweightSystem(canvas);
		xyGraph = new XYGraph();
		xyGraph.setTitle("");
		xyGraph.primaryXAxis.setTitle("time [s]");
		xyGraph.primaryYAxis.setTitle("cost [s]");
		xyGraph.primaryYAxis.setAutoScale(true);
		xyGraph.primaryXAxis.setAutoScale(true);
		xyGraph.primaryXAxis.setShowMajorGrid(true);
		xyGraph.primaryYAxis.setShowMajorGrid(true);
		xyGraph.primaryXAxis.setAutoScaleThreshold(0.2);
		xyGraph.primaryYAxis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_RED));

		Axis ax = new Axis("weight", true);
		ax.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_BLUE));
		ax.setTickLableSide(LabelSide.Primary);
		ax.setAutoScale(true);
		xyGraph.addAxis(ax);

		ToolbarArmedXYGraph toolbarArmedXYGraph = new ToolbarArmedXYGraph(xyGraph);
		lws.setContents(toolbarArmedXYGraph);
		averageCostDataProvider = ChartUtil.createDataProvider(1000, (int) updateThread.getDelayInMillis());
		currentCostDataProvider = ChartUtil.createDataProvider(1000, (int) updateThread.getDelayInMillis());

		Trace averageCostTrace = new Trace("average (low-pass filtered)", xyGraph.primaryXAxis, ax, averageCostDataProvider);
		averageCostTrace.setPointStyle(PointStyle.NONE);
		averageCostTrace.setAntiAliasing(true);

		Trace currentCostTrace = new Trace("current", xyGraph.primaryXAxis, xyGraph.primaryYAxis, currentCostDataProvider);
		currentCostTrace.setPointStyle(PointStyle.NONE);
		currentCostTrace.setAntiAliasing(true);

		xyGraph.addTrace(averageCostTrace);
		xyGraph.addTrace(currentCostTrace);
		return canvas;
	}

	protected String getViewId() {
		return ID;
	}

	@Override
	public void setFocus() {
		// unused
	}

	private void setIntervalControlsEnabled(boolean selection) {
		spinnerInterval.setEnabled(selection);
		lblInterval.setEnabled(selection);
	}

	private void updateSelectedJunction(AbstractJunction newSelection) {
		if (selectedJunction != null) {
			selectedJunction.removeLogProvider();
		}
		selectedJunction = newSelection;
		curDebugText = "";
		getDisplay().syncExec(new Runnable() {

			@Override
			public void run() {
				debugText.setText("");
			}
		});
		selectedJunction.setLogProvider(this);
		updateJunction(true);
	}

	protected void updateSelectedRoadSegment(RoadSegment newSelection) {
		selectedRoadSegment = newSelection;
		updateRoadSegment(true);
	}

	private void updateRoadSegment(final boolean idChanged) {
		if (selectedRoadSegment == null || currentModel == null) {
			return;
		}
		StringBuffer buf = new StringBuffer();
		List<Vehicle> vehInSegment = selectedRoadSegment.getAllVehicles();
		for (Vehicle v : vehInSegment) {
			buf.append(v.getLabel());
			buf.append(", ");
		}
		final String vsInRoadSegment = cutBy(buf, 2);

		final Rectangle bds = drawingPanelRoadSegment.getBounds();
		final Matrix m = Matrix.zoomPoint(Matrix.zoomToFit(selectedRoadSegment.getBoundsRectangle(), bds), new Point(bds.width / 2, bds.height / 2),
				0.95);

		getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (txtVehicles.isDisposed()) {
					return;
				}
				txtVehicles.setText(vsInRoadSegment);
				if (idChanged) {
					final String idStr = selectedRoadSegment.getId() + "";
					if (!txtRsId.getText().equals(idStr)) {
						txtRsId.setText(idStr);
					}
					averageCostDataProvider.clearTrace();
					currentCostDataProvider.clearTrace();

				}
				try {
					if (getCurrentModel().getRouteService() != null) {
						float averageCumCost = getCurrentModel().getRouteService().getHCosts(selectedRoadSegment.getRoutingId(),
								selectedRoadSegment.isOsmReverse()) * 3600;
						double currentHCost = getCurrentModel().getRouteService().getSegmentUnfilteredHCost(selectedRoadSegment.getRoutingId(),
								selectedRoadSegment.isOsmReverse()) * 3600;
						txtCumCost.setText(String.format("%.2f s", averageCumCost));
						txtAddCost.setText(String.format("%.2f", getCurrentModel().getRouteService()
								.getSegmentAdditionalNormalizedCost(selectedRoadSegment.getRoutingId(), selectedRoadSegment.isOsmReverse())));
						txtHcostCur.setText(String.format("%.2f s", currentHCost));
						txtHcostNorm.setText(String.format("%.4f", getCurrentModel().getRouteService()
								.getSegmentFilteredNormalizedCost(selectedRoadSegment.getRoutingId(), selectedRoadSegment.isOsmReverse())));
						txtKmcost.setText(String.format("%.3f m",
								getCurrentModel().getRouteService().getKmCosts(selectedRoadSegment.getRoutingId(), selectedRoadSegment.isOsmReverse())
										* 1000));
						txtFootprint.setText(String.format("%.3f", getCurrentModel().getFootprint(selectedRoadSegment.getId())));
						txtNumRoutesCrossing.setText(String.format("%d", getCurrentModel().getNumRoutesPassingSeg(selectedRoadSegment.getId())));
						if (getCurrentModel().isSimulationRunning()) {
							averageCostDataProvider.addSample(new Sample(getCurrentModel().getSimRuntimeSeconds(), averageCumCost));
							currentCostDataProvider.addSample(new Sample(getCurrentModel().getSimRuntimeSeconds(), currentHCost));
						}
					}
					txtLength.setText(String.format("%.3f m", selectedRoadSegment.getRoadLength()));
					txtName.setText(StringUtil.ensureNotNull(selectedRoadSegment.getName()));
					Image img = createAWTImage(drawingPanelRoadSegment);
					if (img == null) {
						// view not yet open
						return;
					}
					for (RoadSegment rs : getCurrentModel().getNetwork().getRoadSegmentsByRoutingId(selectedRoadSegment.getRoutingId())) {
						drawingContext.drawRoadSegment(rs, img.getGraphics(), m, colorSet, BitUtil.set(0, UiFlag.ROADSEGMENT_DEBUG));
					}
					timeHistDataProvider.clearTrace();
					if (getCurrentModel().getDynamicFootprintGenerator() != null) {

						for (int i = 0; i < getCurrentModel().getDynamicFootprintGenerator().getMaxForecast()
								/ getCurrentModel().getDynamicFootprintGenerator().getTimeResolution(); i++) {
							timeHistDataProvider.addSample(new Sample(i, getCurrentModel().getDynamicFootprintGenerator()
									.getJunctionCost(currentModel.getNetwork().getJunctionBySinkRoadSegment(selectedRoadSegment, true).getId(), i)));
						}
					}

					List<Vehicle> vs = new ArrayList<>(selectedRoadSegment.getAllVehicles());
					for (Vehicle v : vs) {
						drawingContext.drawVehicle(v, img.getGraphics(), m, colorSet, BitUtil.set(0, UiFlag.VEHICLE_IDS));
					}

					drawingPanelRoadSegment.setImage(img);
				} catch (ModelDisposedException e) {
					// model was disposed while execution of this thread, simply return
					return;
				}
			}
		});
	}

	private SimulationModel getCurrentModel() throws ModelDisposedException {
		if (currentModel == null) {
			throw new ModelDisposedException();
		}
		return currentModel;
	}

	private void updateJunction(final boolean idChanged) {
		if (selectedJunction == null) {
			return;
		}
		StringBuffer buf = new StringBuffer();
		Map<Long, VehicleInJunction> vijs = selectedJunction.getVehiclesApproaching();
		List<VehicleInJunction> vs = new ArrayList<>(vijs.values());
		Collections.sort(vs);
		for (VehicleInJunction v : vs) {
			buf.append(v.getVehicle().getLabel());
			buf.append(", ");
		}
		final String approaching = cutBy(buf, 2);

		buf = new StringBuffer();
		List<Long> entryGrants = new ArrayList<>(selectedJunction.getEntryGrants());
		Collections.sort(entryGrants);
		for (Long vid : entryGrants) {
			VehicleInJunction vij = vijs.get(vid);
			if (vij != null) {
				buf.append(vijs.get(vid).getVehicle().getLabel());
				buf.append(", ");
			}
		}
		final String grants = cutBy(buf, 2);

		buf = new StringBuffer();
		List<Vehicle> vehInJunction = selectedJunction.getVehicles();
		Collections.sort(vs);
		for (Vehicle v : vehInJunction) {
			buf.append(v.getLabel());
			buf.append(", ");
		}
		final String inJunction = cutBy(buf, 2);

		buf = new StringBuffer();
		Map<Vehicle, VehiclesLane> driveThrough = selectedJunction.getDriveThroughNotPossible();
		List<Vehicle> vehicles = new ArrayList<>(driveThrough.keySet());
		Collections.sort(vs);
		for (Vehicle v : vehicles) {
			buf.append(v.getLabel());
			buf.append(", ");
		}
		final String driveThroughImpossible = cutBy(buf, 2);

		Rectangle bds = drawingPanelJunction.getBounds();
		final Matrix m = Matrix.zoomPoint(Matrix.zoomToFit(selectedJunction.getBoundsRectangle(), drawingPanelJunction.getBounds()),
				new Point(bds.width / 2, bds.height / 2), currentZoomFactor);

		final StringBuffer dbgToAppend = new StringBuffer();
		while (!debugMessages.isEmpty()) {
			final String curMsg = debugMessages.poll();
			if (curMsg != null) {
				dbgToAppend.insert(0, curMsg + "\n");
			}
		}
		getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (lblVehApproachingVal.isDisposed()) {
					return;
				}
				if (dbgToAppend.length() > 0) {
					final String newText = dbgToAppend.toString() + debugText.getText();
					dbgToAppend.setLength(0);
					debugText.setText(newText);
					curDebugText = newText;
				}
				if (!lblVehApproachingVal.getText().equals(approaching)) {
					lblVehApproachingVal.setText(approaching);
				}
				if (!lblGrantsVal.getText().equals(grants)) {
					lblGrantsVal.setText(grants);
				}
				if (!lblVehInJunctionVal.getText().equals(inJunction)) {
					lblVehInJunctionVal.setText(inJunction);
				}
				if (!lblDriveThroughNotPossible.getText().equals(driveThroughImpossible)) {
					lblDriveThroughNotPossible.setText(driveThroughImpossible);
				}
				if (idChanged) {
					final String idStr = selectedJunction.getId() + "";
					if (!textId.getText().equals(idStr)) {
						textId.setText(idStr);
					}
				}

				Image img = createAWTImage(drawingPanelJunction);
				drawingContext.drawJunction(selectedJunction, img.getGraphics(), m, colorSet, BitUtil.set(0, UiFlag.JUNCTION_DEBUG));
				List<RoadSegment> rss = new ArrayList<>();
				rss.addAll(selectedJunction.getSegmentsIn());
				rss.addAll(selectedJunction.getSegmentsOut());
				List<Vehicle> vs = new ArrayList<>();
				for (RoadSegment rs : rss) {
					drawingContext.drawRoadSegment(rs, img.getGraphics(), m, colorSet, BitUtil.set(0, UiFlag.LANE_DEBUG));
					vs.addAll(rs.getAllVehicles());
				}
				vs.addAll(selectedJunction.getVehicles());
				for (Vehicle v : vs) {
					drawingContext.drawVehicle(v, img.getGraphics(), m, colorSet, BitUtil.set(0, UiFlag.VEHICLE_IDS));
				}

				drawingPanelJunction.setImage(img);
				junctionHistDataProvider.clearTrace();
				TimeDynamicFootprintGenerator dynFPGen;
				try {
					dynFPGen = getCurrentModel().getDynamicFootprintGenerator();
					if (dynFPGen != null) {
						for (int i = 0; i < dynFPGen.getMaxForecast() / getCurrentModel().getDynamicFootprintGenerator().getTimeResolution(); i++) {
							junctionHistDataProvider.addSample(
									new Sample(i * dynFPGen.getTimeResolution() / 1000, dynFPGen.getJunctionCost(selectedJunction.getId(), i)));
						}
					}
				} catch (ModelDisposedException e) {
					e.printStackTrace();
				}

			}
		});
	}

	private String cutBy(StringBuffer buf, int cut) {
		return buf != null && buf.length() > 0 ? buf.substring(0, buf.length() - cut) : "<none>";
	}

	@Override
	public void dispose() {
		openInstances.remove(this);
		updateThread.stopAndDestroy();
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
		}
		SimulationKernel.getInstance().removeInputChangedListener(this);
		super.dispose();
	}

	private Image createAWTImage(DrawingPanel panel) {
		if (panel.getWidth() > 0) {
			return new BufferedImage(Math.max(panel.getWidth() - 2, 1), Math.max(panel.getHeight() - 2, 1), BufferedImage.TYPE_INT_ARGB);
		}
		return null;
	}

	@Override
	public void addLogLine(final LogMessage message) {
		if (message != null) {
			debugMessages.add(message.getFullMessage());
		}
	}

	private Display getDisplay() {
		return getViewSite().getShell().getDisplay();
	}

	@Override
	public void itemsSelected(List<AbstractJunction> junctions, List<JunctionConnector> connectors, List<RoadSegment> roadSegments,
			List<LaneSegment> laneSegments, List<Vehicle> vehicles) {
		if (captureSelection) {
			if (!junctions.isEmpty()) {
				updateSelectedJunction(junctions.get(0));
			}
			if (!roadSegments.isEmpty()) {
				this.selectedRoadSegment = roadSegments.get(0);
				updateRoadSegment(true);
			}
		}
	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
		}
		currentModel = newModel;
		if (newModel == null) {
			updateThread.pause();
		} else {
			currentModel.addItemSelectionListener(this);
			updateThread.proceed();
		}
	}
}

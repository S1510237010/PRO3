package at.fhhagenberg.mc.traffsim.routing.rerouter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import at.fhhagenberg.mc.traffsim.communication.ObservationCenter;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.IntervalUpdateThread;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.routing.AbstractRouteService;
import at.fhhagenberg.mc.traffsim.util.types.PositiveMovingAverage;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public abstract class AbstractCostEvaluator extends IntervalUpdateThread {
	protected static final int MAXIMUM_TIME_PER_ROADSEGMENT_MULTIPLICATOR = 50;

	protected Map<Long, Double> speedCurrentMap = new ConcurrentHashMap<>();
	protected Map<Long, PositiveMovingAverage> speedAverageMap = new ConcurrentHashMap<>();
	protected Map<Long, Double> speedMaxMap = new ConcurrentHashMap<>();
	protected final RoadNetwork network;
	private AbstractRouteService router;

	protected ObservationCenter observationCenter;

	private List<ICostProvider> costProviders = new ArrayList<>();

	private double currentCostSum;

	public AbstractCostEvaluator(String name, long updateIntervalMillis, RoadNetwork network, AbstractRouteService router) {
		super(name, updateIntervalMillis);
		this.network = network;
		this.router = router;
		initCostSum();
	}

	public void setObservationCenter(ObservationCenter observationCenter) {
		this.observationCenter = observationCenter;
	}

	private void initCostSum() {
		for (RoadSegment seg : network.getRoadSegments()) {
			currentCostSum += router.getHCosts(seg.getRoutingId(), seg.isOsmReverse());
		}
	}

	@Override
	public final void doWorkWaitForFinish() {
		updateSpeedMapsAndCongestion();
	}

	/**
	 * In the given interval, the internal speed maps and congested road segments / vehicle must be updated
	 */
	protected abstract void updateSpeedMapsAndCongestion();

	protected void overrideSegmentCost() {
		for (Iterator<Long> segIt = speedAverageMap.keySet().iterator(); segIt.hasNext();) {
			Long segId = segIt.next();
			double speed = speedAverageMap.get(segId).currentAverage();
			RoadSegment seg = network.getRoadSegmentByKey(segId);
			if (seg == null) {
				// seg can be null if segment has been removed by infrastructure editor
				segIt.remove();
				continue;
			}
			int routingId = (int) seg.getRoutingId();
			double averageTime = Math.min((router.getKmCosts(routingId, seg.isOsmReverse()) * 1000) / speed,
					speedMaxMap.get(segId) * MAXIMUM_TIME_PER_ROADSEGMENT_MULTIPLICATOR);
			double currentTime = Math.min((router.getKmCosts(routingId, seg.isOsmReverse()) * 1000) / speedCurrentMap.get(segId),
					speedMaxMap.get(segId) * MAXIMUM_TIME_PER_ROADSEGMENT_MULTIPLICATOR);
			float filteredTimeCost = (float) (averageTime / 3600);

			// subtract old value, if exists
			currentCostSum += currentTime / 3600 - router.getSegmentUnfilteredHCost(seg.getRoutingId(), seg.isOsmReverse());

			// add new value
			double normalizedAdditionalCost = 0;
			int timeWeight = 100;
			for (ICostProvider prov : costProviders) {
				timeWeight -= prov.getWeight();
				normalizedAdditionalCost += (prov.getNormalizedCost(seg.getId()) * prov.getWeight());
			}
			double normalizedFilteredTimeCost = filteredTimeCost / currentCostSum * timeWeight;

			boolean reverse = seg.isOsmReverse();
			router.overrideSegmentHCost(routingId, (float) (normalizedAdditionalCost + normalizedFilteredTimeCost), reverse);
			router.setSegmentNormalizedAdditionalCost(routingId, normalizedAdditionalCost, reverse);
			router.setSegmentNormalizedFilteredHCost(routingId, normalizedFilteredTimeCost, reverse);
			router.setSegmentUnfilteredHCost(routingId, currentTime / 3600, reverse);
		}
	}

	public void addCostProvider(ICostProvider provider) {
		this.costProviders.add(provider);
	}

	/**
	 * Filter vehicles which pass the given road segment (have it in their route)
	 *
	 * @param allVehicles
	 * @param toPass
	 * @param onlyRoutable
	 * @return list of vehicles which pass the given road segment
	 */
	protected List<Vehicle> filterVehiclesPassing(List<Vehicle> allVehicles, RoadSegment toPass, boolean onlyRoutable) {
		List<Vehicle> result = new ArrayList<>();
		allVehicles.stream().filter(v -> onlyRoutable ? v.isRoutable() : true).forEach(v -> {
			try {
				if (!v.isObstacle() && v.getRoute().getRouteIds().contains(toPass.getRoutingId())) {
					result.add(v);
				}
			} catch (Exception ex) {
				Logger.logError("Problem in rerouter: " + ex.getMessage(), ex);
			}
		});
		return result;
	}
}

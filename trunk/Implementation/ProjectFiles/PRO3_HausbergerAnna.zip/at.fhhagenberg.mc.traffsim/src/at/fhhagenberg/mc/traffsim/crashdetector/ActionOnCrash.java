package at.fhhagenberg.mc.traffsim.crashdetector;

/**
 * Enumeration specifying various actions to be triggered upon a crash occurring in a simulation run.
 *
 * @author Christian Backfrieder
 */
public enum ActionOnCrash {

	/**
	 * The simulation is paused and an info dialog is shown
	 */
	OPEN_POPUP("Pause and open info dialog"),

	/**
	 * Removes involved vehicles from simulation
	 */
	REMOVE_PARTICIPANTS("Remove vehicles involved in the collision"),

	/**
	 * The crash is ignored silently
	 */
	IGNORE("Ignore silently"),

	/**
	 * The simulation is restarted if it is executed in batch mode
	 */
	RESTART("Restart simulation (only in batch mode)"),

	/**
	 * The simulation is stopped and aborted
	 */
	STOP_SIMULATION("Stop and abort simulation"),

	/**
	 * The simulation's output is tagged as "crashed"; if the simulation is executed in batch mode, it continues as normal
	 */
	TAG_AND_CONTINUE("Tag simulation run and continue (if in batch mode)");

	/**
	 * Descriptive text for the particular enumeration values
	 */
	String longtext;

	/**
	 * Private constructor required for initializing new crash handling states
	 *
	 * @param desc
	 *            a descriptive text for the crash handling state
	 */
	private ActionOnCrash(String desc) {
		this.longtext = desc;
	}

	@Override
	public String toString() {
		return longtext;
	}
}
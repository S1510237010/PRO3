package at.fhhagenberg.mc.traffsim.ui.rcp.views.performancemonitor;

import java.lang.management.ThreadInfo;

public class DetailThreadInfo {
	private ThreadInfo info;
	private double cputime;
	public ThreadInfo getInfo() {
		return info;
	}
	public void setInfo(ThreadInfo info) {
		this.info = info;
	}
	public double getCputime() {
		return cputime;
	}
	public void setCputime(double cputime) {
		this.cputime = cputime;
	}
	
	
	
}

package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.helper.NumberOnlyKeyAdapter;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class RouteParameterPage extends WizardPage {
	private static final String DELIMITER = ",";

	public class RouteParameters {
		public File configFile;
		public boolean useExistingRoutes;
		public List<Long> startIds, endIds;
		public int nrRoutes, startInterval;
		public Date startDate;
		public List<RouteBean> existingRoutes;
		public long maxRouteIndex;
	}

	private Text textConfigPath;
	private Text textStartIds;
	private Text textEndIds;
	private long maxRouteId;

	protected RouteParameterPage(String pageName) {
		super(pageName);
		setTitle("Route parameters");
		setDescription("Set up route details");
	}

	NumberOnlyKeyAdapter internalKeyAdapter = new NumberOnlyKeyAdapter(DELIMITER) {

		@Override
		public Display getCurrentDisplay() {
			return getWizard().getContainer().getShell().getDisplay();
		}
	};

	private Button btnUseExistingRoutes;
	private Label lblNumberOfRoutes;
	private Spinner spinnerNumberRoutes;
	private Spinner spinnerStartInterval;
	private DateTime date;
	private DateTime time;
	private RouteParameters result;

	private List<RouteBean> routes;

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new GridLayout(4, false));

		Label lblTraffsimConfiguration = new Label(container, SWT.NONE);
		lblTraffsimConfiguration.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTraffsimConfiguration.setText("TraffSim Configuration");

		textConfigPath = new Text(container, SWT.BORDER);
		textConfigPath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		textConfigPath.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});
		textConfigPath.setText(PreferenceUtil.getString(IPreferenceConstants.WIZARD_ROUTE_CONFIG_PATH, ""));

		Button btnBrowse = new Button(container, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(getWizard().getContainer().getShell());
				dialog.setText("Open configuration file");
				dialog.setFilterExtensions(new String[] { Constants.FILE_FILTER_TRAFFSIM_XML });
				dialog.setFilterNames(new String[] { Constants.FILTER_NAME_TRAFFSIM });
				String selected = dialog.open();

				if (selected != null) {
					textConfigPath.setText(selected);
				}

				validatePage();

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});
		btnBrowse.setText("Browse");

		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		btnUseExistingRoutes = new Button(container, SWT.CHECK);
		btnUseExistingRoutes.setText("Use existing routes");
		btnUseExistingRoutes.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnUseExistingRoutes.getSelection()) {
					lblNumberOfRoutes.setText("Number of vehicles");
					textEndIds.setEnabled(false);
					textStartIds.setEnabled(false);
				} else {
					lblNumberOfRoutes.setText("Number of routes   ");
					textEndIds.setEnabled(true);
					textStartIds.setEnabled(true);
				}

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});

		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		lblNumberOfRoutes = new Label(container, SWT.NONE);
		lblNumberOfRoutes.setText("Number of routes   ");

		spinnerNumberRoutes = new Spinner(container, SWT.BORDER);
		spinnerNumberRoutes.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerNumberRoutes.setIncrement(100);
		spinnerNumberRoutes.setPageIncrement(1000);
		spinnerNumberRoutes.setMaximum(50000);
		spinnerNumberRoutes.setMinimum(1);
		spinnerNumberRoutes.setSelection(PreferenceUtil.getInt(IPreferenceConstants.WIZARD_ROUTE_NUMBER_ROUTES, 1000));
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		Label lblStartIntervalms = new Label(container, SWT.NONE);
		lblStartIntervalms.setText("Start interval [ms]");

		spinnerStartInterval = new Spinner(container, SWT.BORDER);
		spinnerStartInterval.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerStartInterval.setIncrement(100);
		spinnerStartInterval.setPageIncrement(500);
		spinnerStartInterval.setMaximum(50000);
		spinnerStartInterval.setMinimum(1);
		spinnerStartInterval.setSelection(PreferenceUtil.getInt(IPreferenceConstants.WIZARD_ROUTE_START_INTERVAL, 500));
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		Label lblStartDate = new Label(container, SWT.NONE);
		lblStartDate.setText("Start date");

		date = new DateTime(container, SWT.BORDER | SWT.DROP_DOWN);

		time = new DateTime(container, SWT.BORDER | SWT.TIME);
		new Label(container, SWT.NONE);

		Label lblDefinedStartRoad = new Label(container, SWT.NONE);
		lblDefinedStartRoad.setText("Start road segment IDs");

		textStartIds = new Text(container, SWT.BORDER);
		textStartIds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		textStartIds.addKeyListener(internalKeyAdapter);
		textStartIds.setText(PreferenceUtil.getString(IPreferenceConstants.WIZARD_ROUTE_START_IDS, ""));

		Label lblEndRoadSegment = new Label(container, SWT.NONE);
		lblEndRoadSegment.setText("End road segment IDs");

		textEndIds = new Text(container, SWT.BORDER);
		textEndIds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		textEndIds.addKeyListener(internalKeyAdapter);
		textEndIds.setText(PreferenceUtil.getString(IPreferenceConstants.WIZARD_ROUTE_END_IDS, ""));

		validatePage();

		// Only enable in case routes are actually available in the current configuration
		if (btnUseExistingRoutes.isEnabled()) {
			btnUseExistingRoutes.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.WIZARD_ROUTE_USE_EXISTING_ROUTES));

			if (btnUseExistingRoutes.getSelection()) {
				lblNumberOfRoutes.setText("Number of vehicles");
				textEndIds.setEnabled(false);
				textStartIds.setEnabled(false);
			} else {
				lblNumberOfRoutes.setText("Number of routes   ");
				textEndIds.setEnabled(true);
				textStartIds.setEnabled(true);
			}
		}
	}

	@Override
	public boolean canFlipToNextPage() {
		return StringUtil.isNullOrEmpty(getErrorMessage());
	}

	@SuppressWarnings("unchecked")
	private void validatePage() {
		StringBuffer msg = new StringBuffer();

		if (StringUtil.isNullOrEmpty(textConfigPath.getText())) {
			msg.append("Please specify a config file\n");
		} else {
			if (!new File(textConfigPath.getText()).exists()) {
				msg.append("Selected config file does not exist\n");
			} else {
				try {
					DataSerializer ser = new DataSerializer();
					ser.readConfiguration(new File(textConfigPath.getText()));

					if (ser.containsData(RouteBean.class)) {
						routes = (List<RouteBean>) ser.readData(RouteBean.class);
						btnUseExistingRoutes.setEnabled(true);
						
						if(routes != null){
							for(RouteBean route : routes){
								if(route.getId() > maxRouteId){
									maxRouteId = route.getId();
								}
							}
						}
					} else {
						routes = null;
						btnUseExistingRoutes.setEnabled(false);
					}
				} catch (Exception exc) {
					msg.append("Routes cannot be loaded. Ensure that the configuration file is not corrupt.");
					getWizard().getContainer().updateButtons();
				}
			}
		}

		setErrorMessage(msg.length() == 0 ? null : msg.toString());
		setPreferences();
	}

	private void setPreferences() {
		PreferenceUtil.set(IPreferenceConstants.WIZARD_ROUTE_CONFIG_PATH, textConfigPath.getText());
		PreferenceUtil.set(IPreferenceConstants.WIZARD_ROUTE_END_IDS, textEndIds.getText());
		PreferenceUtil.setInt(IPreferenceConstants.WIZARD_ROUTE_NUMBER_ROUTES, spinnerNumberRoutes.getSelection());
		PreferenceUtil.set(IPreferenceConstants.WIZARD_ROUTE_START_IDS, textStartIds.getText());
		PreferenceUtil.setInt(IPreferenceConstants.WIZARD_ROUTE_START_INTERVAL, spinnerStartInterval.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.WIZARD_ROUTE_USE_EXISTING_ROUTES, btnUseExistingRoutes.getSelection());
	}

	@Override
	public boolean isPageComplete() {
		return getErrorMessage() == null;
	}

	public RouteParameters getResult() {
		validatePage();
		result = new RouteParameters();
		result.configFile = new File(textConfigPath.getText());
		result.startIds = CollectionUtil.toLongList(textStartIds.getText(), DELIMITER);
		result.endIds = CollectionUtil.toLongList(textEndIds.getText(), DELIMITER);
		result.nrRoutes = spinnerNumberRoutes.getSelection();
		result.startInterval = spinnerStartInterval.getSelection();
		result.useExistingRoutes = btnUseExistingRoutes.getSelection();

		if (result.useExistingRoutes) {
			result.existingRoutes = routes;
			result.maxRouteIndex = maxRouteId;
		}

		Calendar cal = Calendar.getInstance();
		cal.set(date.getYear(), date.getMonth(), date.getDay(), time.getHours(), time.getMinutes(), time.getSeconds());
		result.startDate = cal.getTime();
		return result;
	}
}

package at.fhhagenberg.mc.traffsim.communication;

public interface ICommunicationPartner {
	public void messageReceived(MessageTransfer msg);

	public String getCommName();
}

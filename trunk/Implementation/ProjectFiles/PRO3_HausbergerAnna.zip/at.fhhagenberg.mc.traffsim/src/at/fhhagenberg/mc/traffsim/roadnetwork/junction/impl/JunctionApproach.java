package at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.QueueMonitor;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.SelfOrganizingControlLogic;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

/**
 * Logical entity encapsulating all junction connectors and the associated traffic lights and their respective control logic for a single
 * approach to an intersection, i.e. a single road segment. Responsible for performing queue monitoring tasks and updating traffic lights
 * and their control logic in every simulation update time step.
 *
 * @author Manuel Lindorfer
 *
 */
public class JunctionApproach implements ISimulationTimeUpdatable {

	private long id;
	private AbstractJunction junction;
	private List<JunctionConnector> connectors;
	private List<TrafficLight> trafficLights;
	private QueueMonitor queueMonitor;
	private RoadSegment roadSegment;
	private Map<TrafficLight, ControlLogic> controlLogicMapping;
	private boolean loopDetectorsEnabled = PreferenceUtil.getBoolean(IPreferenceConstants.ENABLE_LOOP_DETECTORS);

	/**
	 * Creates a new approach referencing the provided junction, the inflowing segment and the list of junction connectors.
	 *
	 * @param junction
	 *            the junction to approach is associated to
	 * @param segment
	 *            the segment represented by the approach
	 * @param connectors
	 *            all connectors leaving from the approach into the intersection
	 */
	public JunctionApproach(AbstractJunction junction, RoadSegment segment, List<JunctionConnector> connectors) {
		this(junction, segment, connectors, new ArrayList<>());
	}

	/**
	 * Creates a new approach referencing the provided junction, the inflowing segment and list of junction connectors as well as the given
	 * set of traffic lights.
	 *
	 * @param junction
	 *            the junction to approach is associated to
	 * @param segment
	 *            the segment represented by the approach
	 * @param connectors
	 *            all connectors leaving from the approach into the intersection
	 * @param trafficLights
	 *            all traffic lights associated to connectors of the approach
	 */
	public JunctionApproach(AbstractJunction junction, RoadSegment segment, List<JunctionConnector> connectors, List<TrafficLight> trafficLights) {
		this.id = segment.getId();
		this.junction = junction;
		this.roadSegment = segment;
		this.connectors = connectors;
		this.trafficLights = trafficLights;
		this.queueMonitor = new QueueMonitor(this.junction, roadSegment);
		this.controlLogicMapping = new HashMap<>();
	}

	/**
	 * Get's the approach's unique identifier.
	 *
	 * @return unique identifier
	 */
	public long getId() {
		return id;
	}

	/**
	 * Get's the junction the approach is associated to.
	 *
	 * @return the referenced junction
	 */
	public AbstractJunction getJunction() {
		return junction;
	}

	/**
	 * Get's the list of junction connectors leaving into the referenced junction.
	 *
	 * @return a list of junction connectors
	 */
	public List<JunctionConnector> getConnectors() {
		return connectors;
	}

	/**
	 * Get's all traffic lights associated to junction connectors of the approach.
	 *
	 * @return a list of traffic lights
	 */
	public List<TrafficLight> getTrafficLights() {
		return trafficLights;
	}

	/**
	 * Get's the road segment represented by the approach.
	 *
	 * @return the referenced road segment
	 */
	public RoadSegment getRoadSegment() {
		return roadSegment;
	}

	/**
	 * Get's whether the approach is a single-lane approach or not
	 *
	 * @return true if single-lane, false else
	 */
	public boolean IsSingleLane() {
		return roadSegment.getLaneCount() == 1;
	}

	/**
	 * Get's the queue monitor used for monitoring waiting times and queue lenghts in the approach.
	 *
	 * @return the approach's queue monitor
	 */
	public QueueMonitor getQueueMonitor() {
		return queueMonitor;
	}

	/**
	 * Get's the control logics of each individual traffic light mounted in the approach.
	 *
	 * @return a list of traffic light control logics
	 */
	public List<ControlLogic> getControlLogics() {
		List<ControlLogic> controlLogics = new ArrayList<ControlLogic>(controlLogicMapping.values());
		Collections.sort(controlLogics, (c1, c2) -> new Long(c1.getTrafficLight().getId()).compareTo(new Long(c2.getTrafficLight().getId())));
		return controlLogics;
	}

	/**
	 * Get's the control logic for the specified traffic light.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 * @return the traffic light's control logic, or null if the target traffic light does not belong to the approach
	 */
	public ControlLogic getControlLogicForTrafficLight(TrafficLight trafficLight) {
		if (controlLogicMapping.containsKey(trafficLight)) {
			return controlLogicMapping.get(trafficLight);
		}

		return null;
	}

	/**
	 * Get's the total waiting of all vehicles queued in the approach measured by the queue monitor.
	 *
	 * @return the total waiting time in seconds
	 */
	public double getTotalWaitingTime() {
		return queueMonitor.getTotalWaitingTime();
	}

	/**
	 * Adds a new traffic light to the approach.
	 *
	 * @param trafficLight
	 *            the traffic light to be added
	 */
	public void addTrafficLight(TrafficLight trafficLight) {
		if (!trafficLights.contains(trafficLight)) {
			trafficLights.add(trafficLight);
		}
	}

	/**
	 * Adds a new control logic for the given traffic light.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 * @param controlLogic
	 *            the control logic used for operating the provided traffic light
	 */
	public void addControlLogicFor(TrafficLight trafficLight, ControlLogic controlLogic) {
		if (trafficLights.contains(trafficLight) && !controlLogicMapping.containsKey(trafficLight)) {
			controlLogicMapping.put(trafficLight, controlLogic);
		}
	}

	/**
	 * Removes the given traffic light and the associated control logic from the approach.
	 *
	 * @param trafficLight
	 *            the traffic light to be removed
	 */
	public void removeTrafficLight(TrafficLight trafficLight) {
		if (trafficLights.contains(trafficLight)) {
			trafficLights.remove(trafficLight);
			controlLogicMapping.remove(trafficLight);

			for (JunctionConnector connector : connectors) {
				if (connector.getTrafficLight() != null && connector.getTrafficLight().getId() == trafficLight.getId()) {
					connector.setTrafficLight(null);
				}
			}
		}
	}

	/**
	 * Removeds all traffic lights and associated control logics from the approach.
	 */
	public void removeAllTrafficLights() {
		trafficLights.clear();
		controlLogicMapping.clear();

		for (JunctionConnector connector : connectors) {
			connector.setTrafficLight(null);
		}
	}

	@Override
	public void timeStep(double dt, Date simulationTime, double simulationRunTime) {
		if (loopDetectorsEnabled || isQueueMonitoringRequired()) {
			queueMonitor.update(dt, simulationRunTime);
		}

		trafficLights.forEach(tl -> tl.update(dt, simulationTime, simulationRunTime));
		controlLogicMapping.values().forEach(cl -> cl.update(dt, simulationRunTime));
	}

	private boolean isQueueMonitoringRequired() {
		for (ControlLogic logic : controlLogicMapping.values()) {
			if (logic instanceof SelfOrganizingControlLogic) {
				return true;
			}
		}

		return false;
	}
}

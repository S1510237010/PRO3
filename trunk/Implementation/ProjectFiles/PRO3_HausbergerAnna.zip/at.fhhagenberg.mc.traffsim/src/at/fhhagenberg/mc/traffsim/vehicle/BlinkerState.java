package at.fhhagenberg.mc.traffsim.vehicle;

public enum BlinkerState {
	RIGHT, LEFT, RIGHT_OFF, LEFT_OFF, OFF, WARN, WARN_OFF
}

package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.esotericsoftware.kryo.io.Input;
import com.jmatio.io.MatFileReader;
import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLCell;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;
import com.jmatio.types.MLInt64;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.EnumUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleRouteListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

public class DetailedStatisticsCollector extends CachingStatisticsCollector implements IVehicleGeneratorListener, IVehicleRouteListener {
	private static final String SIMPLE_STATISTICS_VAR = "simple_statistics";
	static final String VEHICLE_STATISTICS_SUFFIX = ".1.mat";
	private static final String VEHICLE_STATISTICS_SUFFIX_SIMPLE = ".mat";
	private static final String VEHICLE_STATISTICS_INFIX_SIMPLE = "simple_";
	private static final String COLUMN_NAMES_VEHICLE_VAR = "column_names_vehicles";

	/**
	 * As soon as a vehicle leaves simulation, its data is cached and written to a file in the next write cycle
	 */
	private List<VehicleStatisticsData> leftVehiclesCache = new CopyOnWriteArrayList<>();

	public enum VehicleFieldId {
		TIME("Time"), X_POS("X-Position"), Y_POS("Y-Position"), SPEED("Speed"), ACC("Acceleration"), FUEL_KM("Fuel per km"), FUEL_HOUR(
				"Fuel per hour"), FUEL_TOTAL("Fuel total"), CO2_KM("CO2 per km"), CO2_HOUR("CO2 per hour"), CO2_TOTAL("CO2 total"), TRAVEL_DIST(
						"Distance"), DIST_TO_FRONT("Distance to front"), DISTRACTION("Distraction state");

		public static int length() {
			return values().length;
		}

		private String description;

		private VehicleFieldId(final String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	public DetailedStatisticsCollector(String name, SimulationModel model, long delay, boolean clearPreviousCaches) {
		super(name, model, delay, false, clearPreviousCaches);
	}

	/**
	 * Writes the rest of the data in cache to files to perform finish and free memory
	 */

	@Override
	public void vehicleGenerated(Vehicle vehicle) {
		vehicle.addVehicleListener(this);
	}

	@Override
	public synchronized void vehicleLeftSimulation(Vehicle v) {
		leftVehiclesCache.add(model.getStatistics().getVehicleStats().get(v.getUniqueId()).collectData(0));
	}

	@Override
	public IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException {
		if (!cacheFolder.exists()) {
			Logger.logWarn("Expected cache folder " + cacheFolder.getName() + " does not exist");
			return Status.CANCEL_STATUS;
		}

		monitor.worked(1);

		File matFile = getStandardMatFile(outputFolder, date, crashDetected ? String.format("-%s%s", CRASH_TAG, VEHICLE_STATISTICS_SUFFIX)
				: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, VEHICLE_STATISTICS_SUFFIX) : VEHICLE_STATISTICS_SUFFIX);

		SimpleStatisticsLine simpleStatLine = new SimpleStatisticsLine();
		List<Event> events = new ArrayList<>();
		Map<Long, List<Double[]>> vehicleMatData = new HashMap<>();

		boolean recordTime = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_TIME);
		boolean recordDistance = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_DISTANCE);
		boolean recordPosition = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_POSITION);
		boolean recordSpeed = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_SPEED);
		boolean recordAcceleration = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_ACCELERATION);
		boolean recordFuelConsumption = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_FUEL_CONSUMPTION);
		boolean recordCarbonEmissions = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_CARBON_EMISSIONS);
		boolean recordDistToFront = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_DIST_TO_FRONT);
		boolean recordDistractionState = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_DISTRACTION_STATE);

		File[] files = cacheFolder.listFiles();

		if (files != null) {
			monitor.beginTask("Converting " + files.length + " cached files", files.length + 2);
			long totalLength = 0;

			for (File f : files) {
				Input input = new Input(new FileInputStream(f));
				List<?> objs = kryo.readObject(input, ArrayList.class);
				input.close();

				for (Object obj : objs) {
					if (obj instanceof VehicleStatisticsData) {
						VehicleStatisticsData bvd = (VehicleStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (vehicle " + bvd.getVehicleId() + ")");
						List<Double[]> dataToAdd;
						if (!vehicleMatData.containsKey(bvd.getVehicleId())) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = vehicleMatData.get(bvd.getVehicleId());
						}

						int arraySize = VehicleFieldId.length();

						// Write statistics to array
						for (int i = 0; i < bvd.getTime().size(); i++) {
							Double[] row = new Double[arraySize];

							if (recordTime) {
								row[VehicleFieldId.TIME.ordinal()] = bvd.getTime().get(i);
							}

							if (recordPosition) {
								row[VehicleFieldId.X_POS.ordinal()] = bvd.getPosition().get(i).x;
								row[VehicleFieldId.Y_POS.ordinal()] = bvd.getPosition().get(i).y;
							}

							if (recordSpeed) {
								row[VehicleFieldId.SPEED.ordinal()] = bvd.getSpeed().get(i);
							}

							if (recordAcceleration) {
								row[VehicleFieldId.ACC.ordinal()] = bvd.getAcc().get(i);
							}

							if (recordFuelConsumption) {
								row[VehicleFieldId.FUEL_KM.ordinal()] = bvd.getFuelConsumptionPer100km().get(i);
								row[VehicleFieldId.FUEL_HOUR.ordinal()] = bvd.getFuelConsumptionPerHour().get(i);
								row[VehicleFieldId.FUEL_TOTAL.ordinal()] = bvd.getTotalFuelConsumed();
							}

							if (recordCarbonEmissions) {
								row[VehicleFieldId.CO2_KM.ordinal()] = bvd.getCarbonEmissionsPer100km().get(i);
								row[VehicleFieldId.CO2_HOUR.ordinal()] = bvd.getCarbonEmissionsPerHour().get(i);
								row[VehicleFieldId.CO2_TOTAL.ordinal()] = bvd.getTotalCarbonEmissions();
							}

							if (recordDistance) {
								row[VehicleFieldId.TRAVEL_DIST.ordinal()] = bvd.getTravelDistance().get(i);
							}

							if (recordDistToFront) {
								row[VehicleFieldId.DIST_TO_FRONT.ordinal()] = bvd.getDistanceToFront().get(i);
							}

							if (recordDistractionState) {
								row[VehicleFieldId.DISTRACTION.ordinal()] = bvd.getDistractionState().get(i);
							}

							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						vehicleMatData.put(bvd.getVehicleId(), dataToAdd);
					} else if (obj instanceof Event) {
						// write event
						events.add((Event) obj);
					} else if (obj != null) {
						Logger.logWarn(
								"Found unexpected object type in cache: " + obj.getClass().getCanonicalName() + " | toString(): " + obj.toString());
					} else {
						Logger.logWarn("Found null object in cache");
					}
				}

				totalLength += f.length();
				long threshold = Runtime.getRuntime().freeMemory() / 2;
				if (totalLength > threshold) {
					appendData(matFile, vehicleMatData, monitor);
					vehicleMatData = new HashMap<>();
					totalLength = 0;
				}
				monitor.worked(1);

			}
		}

		// simple statistics
		simpleStatLine.file = matFile.getAbsolutePath();
		simpleStatLine.numVehicles = vehicleMatData.size();
		int index = 0;
		for (List<Double[]> rows : vehicleMatData.values()) {
			if (rows.isEmpty()) {
				continue;
			}
			Double[] lastRow = CollectionUtil.getLastObject(rows);
			Double[] firstRow = CollectionUtil.getFirstObject(rows);
			if (recordDistance) {
				simpleStatLine.distAvg = (simpleStatLine.distAvg * index + lastRow[VehicleFieldId.TRAVEL_DIST.ordinal()]) / (index + 1);
				simpleStatLine.distSum += lastRow[VehicleFieldId.TRAVEL_DIST.ordinal()];
			}

			if (recordFuelConsumption) {
				simpleStatLine.fuelAvg = (simpleStatLine.fuelAvg * index + lastRow[VehicleFieldId.FUEL_TOTAL.ordinal()]) / (index + 1);
				simpleStatLine.fuelSum += lastRow[VehicleFieldId.FUEL_TOTAL.ordinal()];
			}

			if (recordCarbonEmissions) {
				simpleStatLine.carbonEmissionsAvg = (simpleStatLine.carbonEmissionsAvg * index + lastRow[VehicleFieldId.CO2_TOTAL.ordinal()])
						/ (index + 1);
				simpleStatLine.carbonEmissionsSum += lastRow[VehicleFieldId.CO2_TOTAL.ordinal()];
			}

			if (recordSpeed) {
				simpleStatLine.speedAvg = (simpleStatLine.speedAvg * index + lastRow[VehicleFieldId.SPEED.ordinal()]) / (index + 1);
			}

			if (recordTime) {
				simpleStatLine.timeAvg = (simpleStatLine.timeAvg * index + lastRow[VehicleFieldId.TIME.ordinal()]) / (index + 1);
				simpleStatLine.timeSum += lastRow[VehicleFieldId.TIME.ordinal()] - firstRow[VehicleFieldId.TIME.ordinal()];
			}

			index++;
		}
		// write and clear data
		appendData(matFile, vehicleMatData, monitor);

		// matfile output arrays
		List<MLArray> mlArrays = new ArrayList<>();

		MLCell simpleStat = new MLCell(SIMPLE_STATISTICS_VAR, new int[] { 2, SimpleStatisticsLine.class.getDeclaredFields().length });
		index = 0;
		simpleStat.set(new MLChar("", "File"), 0, index++);
		simpleStat.set(new MLChar("", "Num Vehicles"), 0, index++);
		simpleStat.set(new MLChar("", "Time Sum"), 0, index++);
		simpleStat.set(new MLChar("", "Time Avg"), 0, index++);
		simpleStat.set(new MLChar("", "Fuel Sum"), 0, index++);
		simpleStat.set(new MLChar("", "Fuel Avg"), 0, index++);
		simpleStat.set(new MLChar("", "CO2 Sum"), 0, index++);
		simpleStat.set(new MLChar("", "CO2 Avg"), 0, index++);
		simpleStat.set(new MLChar("", "Dist Sum"), 0, index++);
		simpleStat.set(new MLChar("", "Dist Avg"), 0, index++);
		simpleStat.set(new MLChar("", "Speed Avg"), 0, index++);
		index = 0;
		simpleStat.set(new MLChar("", simpleStatLine.file), 1, index++);
		simpleStat.set(new MLInt64("", new long[] { simpleStatLine.numVehicles }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.timeSum }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.timeAvg }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.fuelSum }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.fuelAvg }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.carbonEmissionsSum }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.carbonEmissionsAvg }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.distSum }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.distAvg }, 1), 1, index++);
		simpleStat.set(new MLDouble("", new double[] { simpleStatLine.speedAvg }, 1), 1, index++);
		mlArrays.add(simpleStat);

		// write simple statistics to separate mat file
		String simpleMatFilename = String.format("%s%s%s%s", VEHICLE_STATISTICS_PREFIX, VEHICLE_STATISTICS_INFIX_SIMPLE, date,
				crashDetected ? String.format("-%s%s", CRASH_TAG,
						VEHICLE_STATISTICS_SUFFIX_SIMPLE)
						: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, VEHICLE_STATISTICS_SUFFIX_SIMPLE)
								: VEHICLE_STATISTICS_SUFFIX_SIMPLE);
		File simpleMatFile = new File(outputFolder, simpleMatFilename);

		try {
			monitor.subTask("Writing to Simple MAT file");
			new MatFileWriter(simpleMatFile, CollectionUtil.createArrayList(simpleStat, MLArray.class));
		} catch (IOException e) {
			String msg = "Cannot write to simple MAT file '" + simpleMatFile.getName() + "'";
			Logger.logError(msg, e);
			return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, msg);
		}

		// event data
		MLCell eventData = getEventData(events);
		mlArrays.add(eventData);

		String[] colNames = EnumUtil.enumNameToStringArray(VehicleFieldId.values());
		mlArrays.add(new MLChar(COLUMN_NAMES_VEHICLE_VAR, colNames));

		// column names for events
		mlArrays.add(getEventColumnNames());

		// write everything to mat file
		try {
			monitor.subTask("Writing to MAT file");
			new MatFileWriter(findMatFile(matFile, true), mlArrays);
		} catch (IOException e) {
			String msg = "Cannot write to MAT file '" + matFile.getName() + "'";
			Logger.logError(msg, e);
			return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, msg);
		}
		monitor.worked(2);
		if (clearCache) {
			clearCache(cacheFolder);
		}
		return Status.OK_STATUS;
	}

	protected void appendData(File matFile, Map<Long, List<Double[]>> data, IProgressMonitor monitor) throws IOException {
		String baseMsg = String.format("Appending to MAT-file (current size: %.1f MB): ", ((double) matFile.length()) / 1024 / 1024);
		Map<String, MLArray> matFileData;
		matFile = findMatFile(matFile, false);
		if (matFile.exists() && matFile.length() < Math.pow(10, 9) / 2) {
			monitor.subTask(baseMsg + "Reading old file");
			// find last file
			matFileData = new MatFileReader(matFile).getContent();
		} else {
			matFile = findMatFile(matFile, true);
			matFileData = new HashMap<>();
		}
		Set<Long> keys = new HashSet<>(data.keySet());
		for (Long vid : keys) {
			monitor.subTask(baseMsg + "Appending vehicle " + vid);
			String varname = getVarName(vid, null);

			int arraySize = VehicleFieldId.length();

			double[][] newarr = new double[data.get(vid).size()][arraySize];
			if (data.get(vid).size() == 0) {
				Logger.logWarn("Found no recorded data for vehicle #" + vid);
				continue;
			}
			int i = 0;
			for (Double[] row : data.remove(vid)) {
				newarr[i++] = CollectionUtil.toPrimitiveDoubleArray(row);
			}
			if (matFileData.containsKey(varname)) {
				double[][] oldarr = ((MLDouble) matFileData.get(varname)).getArray();
				// join arrays
				int oldlen = oldarr.length;
				int newlen = newarr.length;
				double joined[][] = new double[oldlen + newlen][];
				System.arraycopy(oldarr, 0, joined, 0, oldlen);
				oldarr = null; // clean memory
				System.arraycopy(newarr, 0, joined, oldlen, newlen);
				matFileData.put(varname, new MLDouble(varname, joined));
			} else {
				matFileData.put(varname, new MLDouble(varname, newarr));
			}
		}

		Collection<MLArray> finalData = addStandardStatistics(new ArrayList<>(matFileData.values()));

		monitor.subTask(baseMsg + "Writing new file");
		new MatFileWriter(matFile, finalData);
	}

	@Override
	public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute) {
		model.getStatistics().getVehicleStats().get(v.getUniqueId()).increaseRouteUpdates();
	}

	@Override
	public String getCacheFolderPrefix() {
		return ".stat-cache_";
	}

	@Override
	protected String getCacheFilePrefix() {
		return "traffsim_stats";
	}

	@Override
	protected String getVariablePrefix() {
		return "vehicle_";
	}

	@Override
	protected String getStatisticsFilePrefix() {
		return "vehicle_statistics_";
	}

	@Override
	protected synchronized void collectStatistics(int itemsToKeep) {
		Map<Long, VehicleStatisticsData> vStats = model.getStatistics().getVehicleStats();

		for (Vehicle v : model.getVehiclesInSimulation(false)) {
			VehicleStatisticsData vsd = vStats.get(v.getUniqueId());
			if (vsd != null) {
				VehicleStatisticsData data = vsd.collectData(itemsToKeep);
				dataList.add(data);
				pause(2);
			}
		}

		if (!leftVehiclesCache.isEmpty()) {
			dataList.addAll(leftVehiclesCache);
		}

		leftVehiclesCache = new CopyOnWriteArrayList<>();
	}

	@Override
	protected void collectAdditionalData(int itemsToKeep) {
		List<Event> events = model.getEventLog().collectEvents(itemsToKeep);
		dataList.addAll(events);
	}
}

package at.fhhagenberg.mc.traffsim.routing.rerouter.congestion;

import java.util.ArrayList;
import java.util.Queue;

import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.routing.Congestion;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICongestionProvider;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Congestion provider which always returns all vehicles to be congested
 * 
 * @author Christian Backfrieder
 * 
 */
public class GlobalCongestionProvider implements ICongestionProvider {
	private SimulationModel model;

	public GlobalCongestionProvider(SimulationModel model) {
		this.model = model;
	}

	@Override
	public Queue<Congestion> getCongestions() {
		return CollectionUtil.createQueue(new Congestion(Long.MIN_VALUE, 0, new ArrayList<>(model.getVehiclesInSimulation(true))));
	}

}

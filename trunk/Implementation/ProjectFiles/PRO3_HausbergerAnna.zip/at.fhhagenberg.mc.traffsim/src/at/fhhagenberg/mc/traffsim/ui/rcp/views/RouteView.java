package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.IItemSelectionListener;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.ui.IImageKeys;
import at.fhhagenberg.mc.traffsim.ui.IRouteProvider;
import at.fhhagenberg.mc.traffsim.ui.IRouteTraversalListener;
import at.fhhagenberg.mc.traffsim.ui.IRouteUpdateListener;
import at.fhhagenberg.mc.traffsim.ui.IViewInitialisationListener;
import at.fhhagenberg.mc.traffsim.ui.UiModel;
import at.fhhagenberg.mc.traffsim.util.ImageUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * View which shows controls used to visualize a route on the map
 *
 * @author Christian Backfrieder
 *
 */
public class RouteView extends ViewPart
		implements IPartListener, IItemSelectionListener, IRouteUpdateListener, IViewInitialisationListener, IRouteTraversalListener {

	private static class ViewerLabelProvider extends LabelProvider {
		@Override
		public Image getImage(Object element) {
			if (element instanceof Route) {
				return ImageUtil.getSWTImage(IImageKeys.ROUTE);
			}

			return super.getImage(element);
		}

		@Override
		public String getText(Object element) {
			if (element instanceof Route) {
				return ((Route) element).toString();
			} else if (element instanceof IRouteProvider) {
				return ((IRouteProvider) element).getName();
			}

			return super.getText(element);
		}
	}

	public static final String ID = "at.fhhagenberg.mc.traffsim.views.route";
	private Button btnGrabSelectionFrom;
	private Button btnShowRoute;
	private Button btnShowRoutes;
	private Label lblAllRoutes;

	private List listAllRoutes;

	private List listProviders;
	private List listRoutes;
	private ListViewer listViewerAllRoutes;
	private ListViewer listViewerProviders;
	private ListViewer listViewerRoutes;
	private java.util.List<IRouteProvider> routeProviders = new ArrayList<>();
	protected UiModel selectedModel;
	protected IRouteProvider selectedRouteProvider;
	private Text textRouteString;
	private String manualRoute;

	public RouteView() {
		PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().addPartListener(this);
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout(SWT.VERTICAL));

		SashForm sashForm = new SashForm(parent, SWT.VERTICAL);

		Group grpAutomatic = new Group(sashForm, SWT.NONE);
		grpAutomatic.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpAutomatic.setText("Automatic (active simulation)");
		grpAutomatic.setLayout(new GridLayout(3, false));

		// Show routes
		btnShowRoutes = new Button(grpAutomatic, SWT.CHECK);
		btnShowRoutes.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnShowRoutes.getSelection()) {
					refreshRoutesToDraw();
				} else {
					if (selectedModel != null) {
						selectedModel.setRoutesToDraw(new ArrayList<>(), new ArrayList<>());
					}
				}
			}
		});

		btnShowRoutes.setSelection(true);
		btnShowRoutes.setText("Show Routes");

		// Grab selection
		btnGrabSelectionFrom = new Button(grpAutomatic, SWT.CHECK);
		btnGrabSelectionFrom.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnGrabSelectionFrom.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateGrabSelection();
			}
		});

		btnGrabSelectionFrom.setSelection(true);
		btnGrabSelectionFrom.setText("Grab selection from active view");

		Label lblRouteProviders = new Label(grpAutomatic, SWT.NONE);
		lblRouteProviders.setText("Route Providers       ");

		Label lblRoutes = new Label(grpAutomatic, SWT.NONE);
		lblRoutes.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		lblRoutes.setText("Active routes (dynamic)");

		lblAllRoutes = new Label(grpAutomatic, SWT.NONE);
		lblAllRoutes.setText("All routes (static)");

		// Route providers (active simulation)
		listViewerProviders = new ListViewer(grpAutomatic, SWT.BORDER | SWT.V_SCROLL);
		listViewerProviders.setLabelProvider(new ViewerLabelProvider());
		listViewerProviders.setContentProvider(new ArrayContentProvider());

		listProviders = listViewerProviders.getList();
		listProviders.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		listProviders.setToolTipText("Currently available route providers");
		listProviders.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				onProviderSelected();
			}
		});

		// Routes (active simulation)
		listViewerRoutes = new ListViewer(grpAutomatic, SWT.BORDER | SWT.V_SCROLL | SWT.MULTI);
		listViewerRoutes.setLabelProvider(new ViewerLabelProvider());
		listViewerRoutes.setContentProvider(new ArrayContentProvider());

		listRoutes = listViewerRoutes.getList();
		listRoutes.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		listRoutes.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				refreshRoutesToDraw();
			}
		});

		// Routes (all)
		listViewerAllRoutes = new ListViewer(grpAutomatic, SWT.BORDER | SWT.V_SCROLL | SWT.MULTI);
		listViewerAllRoutes.setLabelProvider(new ViewerLabelProvider());
		listViewerAllRoutes.setContentProvider(new ArrayContentProvider());

		listAllRoutes = listViewerAllRoutes.getList();
		listAllRoutes.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		listAllRoutes.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				refreshRoutesToDraw();
			}
		});

		Group grpManual = new Group(sashForm, SWT.NONE);
		grpManual.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpManual.setText("Manual (active simulation)");
		grpManual.setLayout(new GridLayout(2, false));

		// Show route (manually)
		btnShowRoute = new Button(grpManual, SWT.CHECK);
		btnShowRoute.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnShowRoute.getSelection()) {
					manualRoute = textRouteString.getText();
				} else {
					manualRoute = null;
				}
				refreshRoutesToDraw();
			}
		});
		btnShowRoute.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnShowRoute.setText("Show Route");

		Label lblRouteString = new Label(grpManual, SWT.NONE);
		lblRouteString.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRouteString.setText("Route String");

		// Route string (manually)
		textRouteString = new Text(grpManual, SWT.BORDER);
		textRouteString.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		sashForm.setWeights(new int[] { 5, 3 });

		if (SimulationKernel.getInstance().getActiveModel() != null) {
			if (SimulationKernel.getInstance().getActiveModel().getView().isInitialized()) {
				selectedModel = SimulationKernel.getInstance().getActiveModel().getUiModel();
				refreshRouteProviders(SimulationKernel.getInstance().getActiveModel().getView());
			} else {
				refreshRouteProviders(null);
			}
		} else {
			refreshRouteProviders(null);
		}

		updateGrabSelection();
	}

	@Override
	public void dispose() {
		PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().removePartListener(this);

		if (SimulationKernel.getInstance().getActiveModel() != null) {
			SimulationKernel.getInstance().getActiveModel().removeItemSelectionListener(this);
		}

		if (selectedModel != null) {
			selectedModel.setRoutesToDraw(new ArrayList<>(), new ArrayList<>());
		}
	}

	private void enableSimulationRelatedControls(boolean enable) {
		btnGrabSelectionFrom.setEnabled(enable);
		btnShowRoute.setEnabled(enable);
		btnShowRoutes.setEnabled(enable);
		textRouteString.setEnabled(enable);
		listProviders.setEnabled(enable);
		listRoutes.setEnabled(enable);
	}

	@Override
	public void itemsSelected(java.util.List<AbstractJunction> junctions, java.util.List<JunctionConnector> connectors,
			java.util.List<RoadSegment> roadSegments, java.util.List<LaneSegment> laneSegments, java.util.List<Vehicle> vehicles) {

		StructuredSelection sel = new StructuredSelection(RoutingUtil.getVehicleRoutes(vehicles));

		if (SimulationKernel.getInstance().getActiveModel() != null) {
			selectedModel = SimulationKernel.getInstance().getActiveModel().getUiModel();
		} else {
			selectedModel = null;
		}

		getSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (listViewerProviders.getSelection().isEmpty()) {
					listViewerProviders.setSelection(new StructuredSelection(SimulationKernel.getInstance().getActiveModel().getView()), true);
				}

				Object firstElem = listViewerProviders.getStructuredSelection().getFirstElement();

				if (firstElem != null && firstElem instanceof IRouteProvider) {
					ArrayList<IRoute> availableRoutes = (ArrayList<IRoute>) ((IRouteProvider) firstElem).getAvailableRoutes();

					for (IRoute route : availableRoutes) {
						route.addRouteTraversalListener(RouteView.this);
					}

					listViewerRoutes.setInput(availableRoutes);
					listViewerRoutes.setSelection(sel);
				}

				refreshRoutesToDraw();
			}
		});

	}

	private void onProviderSelected() {
		if (listViewerProviders.getStructuredSelection().getFirstElement() instanceof SimulationView) {
			selectedModel = ((SimulationView) listViewerProviders.getStructuredSelection().getFirstElement()).getModel();
		}

		if (listViewerProviders.getStructuredSelection().getFirstElement() instanceof IRouteProvider) {
			if (selectedRouteProvider != null) {
				selectedRouteProvider.setUpdateListener(null);
			}

			selectedRouteProvider = (IRouteProvider) listViewerProviders.getStructuredSelection().getFirstElement();
			selectedRouteProvider.setUpdateListener(RouteView.this);
			listViewerRoutes.setInput(selectedRouteProvider.getAvailableRoutes());
			listViewerAllRoutes.setInput(selectedRouteProvider.getAllRoutes());
		}
	}

	@Override
	public void onViewInitialised(IWorkbenchPart view) {
		updateGrabSelection();

		if (view instanceof SimulationView) {
			SimulationView simView = (SimulationView) view;
			simView.removeViewInitialisationListener(this);
			selectedModel = simView.getModel();
			refreshRouteProviders(simView);
		} else {
			refreshRouteProviders(null);
		}
	}

	@Override
	public void partActivated(IWorkbenchPart part) {

		updateGrabSelection();

		if (part instanceof SimulationView) {
			SimulationView simView = (SimulationView) part;

			if (simView.isInitialized()) {
				selectedModel = simView.getModel();
				refreshRouteProviders(simView);
			} else {
				refreshRouteProviders(null);
			}
		} else {
			refreshRouteProviders(null);
		}
	}

	@Override
	public void partBroughtToTop(IWorkbenchPart part) {
		// unused interface method
	}

	@Override
	public void partClosed(IWorkbenchPart part) {
		if (part instanceof SimulationView) {
			SimulationView simView = (SimulationView) part;
			simView.removeViewInitialisationListener(this);
		}

		if (SimulationKernel.getInstance().getActiveModel() != null) {
			selectedModel = SimulationKernel.getInstance().getActiveModel().getUiModel();

			if (SimulationKernel.getInstance().getActiveModel().getView().isInitialized()) {
				refreshRouteProviders(SimulationKernel.getInstance().getActiveModel().getView());
			}
		} else {
			selectedModel = null;
			updateGrabSelection();
			refreshRouteProviders(null);
		}
	}

	@Override
	public void partDeactivated(IWorkbenchPart part) {
		// unused interface method
	}

	@Override
	public void partOpened(IWorkbenchPart part) {
		if (part instanceof SimulationView) {
			SimulationView simView = (SimulationView) part;
			simView.addViewInitialisationListner(this);
		}
	}

	private void refreshRouteProviders(IRouteProvider activeProvider) {

		if (selectedModel != null) {
			enableSimulationRelatedControls(true);
		} else {
			enableSimulationRelatedControls(false);
		}

		routeProviders = new ArrayList<>();

		for (IViewReference viewRef : PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getViewReferences()) {
			IViewPart view = viewRef.getView(false);
			if (view instanceof IRouteProvider) {
				if (((IRouteProvider) view).isInitialized()) {
					routeProviders.add((IRouteProvider) view);
				}
			}
		}

		getSite().getShell().getDisplay().syncExec(new Runnable() {
			@Override
			public void run() {
				IStructuredSelection selection = listViewerProviders.getStructuredSelection();
				listViewerProviders.setInput(routeProviders);

				if (activeProvider != null) {
					listViewerProviders.setSelection(new StructuredSelection(activeProvider), true);
				} else {
					listViewerProviders.setSelection(selection);
				}

				onProviderSelected();

				if (routeProviders.size() == 0) {
					selection = listViewerRoutes.getStructuredSelection();
					listViewerRoutes.setInput(new ArrayList<>());
					listViewerRoutes.setSelection(selection);

					selection = listViewerAllRoutes.getStructuredSelection();
					listViewerAllRoutes.setInput(new ArrayList<>());
					listViewerAllRoutes.setSelection(selection);
				}
			}
		});
	}

	protected void refreshRoutesToDraw() {
		java.util.List<Route> routes = new ArrayList<>();
		java.util.List<Route> staticRoutes = new ArrayList<>();

		java.util.Iterator<?> it = listViewerRoutes.getStructuredSelection().iterator();

		while (it.hasNext()) {
			Object next = it.next();

			if (next instanceof Route) {
				routes.add((Route) next);
			}
		}

		java.util.Iterator<?> itStatic = listViewerAllRoutes.getStructuredSelection().iterator();

		while (itStatic.hasNext()) {
			Object next = itStatic.next();

			if (next instanceof Route) {
				staticRoutes.add((Route) next);
			}
		}

		if (StringUtil.isNotNullOrEmpty(manualRoute)) {
			routes.add(new Route(CollectionUtil.toLongList(manualRoute, ",", "[", "]")));
		}
		if (selectedModel != null) {
			selectedModel.setRoutesToDraw(routes, staticRoutes);
		}

	}

	@Override
	public void routesUpdated(java.util.List<IRoute> routes) {
		if (btnGrabSelectionFrom.getSelection()) {
			getSite().getShell().getDisplay().asyncExec(new Runnable() {
				@Override
				public void run() {
					listViewerRoutes.setInput(selectedRouteProvider.getAvailableRoutes());
					listViewerRoutes.setSelection(new StructuredSelection(routes));
				}
			});

			refreshRoutesToDraw();
		}
	}

	@Override
	public void setFocus() {
		// unused interface method
	}

	protected void updateGrabSelection() {
		if (SimulationKernel.getInstance().getActiveModel() != null) {
			getSite().getShell().getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {

					if (SimulationKernel.getInstance().getActiveModel() != null && !btnGrabSelectionFrom.isDisposed()) {
						if (btnGrabSelectionFrom.getSelection()) {
							SimulationKernel.getInstance().getActiveModel().addItemSelectionListener(RouteView.this);
						} else {
							SimulationKernel.getInstance().getActiveModel().removeItemSelectionListener(RouteView.this);
						}
					}
				}
			});
		}
	}

	@Override
	public void onRoutingIdTraversed() {
		getSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				IStructuredSelection sel = listViewerRoutes.getStructuredSelection();

				if (listViewerProviders.getSelection().isEmpty()) {
					listViewerProviders.setSelection(new StructuredSelection(SimulationKernel.getInstance().getActiveModel().getView()), true);
				}

				Object firstElem = listViewerProviders.getStructuredSelection().getFirstElement();

				if (firstElem != null && firstElem instanceof IRouteProvider) {
					listViewerRoutes.setInput(((IRouteProvider) firstElem).getAvailableRoutes());
					listViewerRoutes.setSelection(sel);
				}

				refreshRoutesToDraw();
			}
		});
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.behaviors;

import java.io.File;
import java.util.List;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;

import at.fhhagenberg.mc.traffsim.data.beans.BehaviorBean;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class BehaviorGenerationWizard extends Wizard {

	public static final String PAGE_BEHAVIOR_SPECIFICATION = "behavior_specification";

	private BehaviorSpecificationPage behaviorSpecificationPage;

	private File configFile;

	private List<BehaviorBean> behaviors;

	public BehaviorGenerationWizard() {
		setWindowTitle("Behavior Generation");
		behaviorSpecificationPage = new BehaviorSpecificationPage(PAGE_BEHAVIOR_SPECIFICATION);
	}

	@Override
	public void addPages() {
		addPage(behaviorSpecificationPage);
	}

	@Override
	public boolean canFinish() {

		IWizardPage currentPage = getContainer().getCurrentPage();

		if (currentPage == null) {
			return false;
		}

		return (currentPage.equals(behaviorSpecificationPage) && behaviorSpecificationPage.isPageComplete());
	}

	@Override
	public boolean performFinish() {
		configFile = ((BehaviorSpecificationPage) getPage(PAGE_BEHAVIOR_SPECIFICATION)).getConfigFile();
		behaviors = ((BehaviorSpecificationPage) getPage(PAGE_BEHAVIOR_SPECIFICATION)).getBehaviors();

		if (configFile == null) {
			return false;
		}

		PreferenceUtil.set(IPreferenceConstants.WIZARD_BEHAVIOR_CONFIG_PATH, configFile.getPath());

		if (behaviors != null && behaviors.size() > 0) {
			long id = 0;

			for (BehaviorBean bean : behaviors) {
				bean.setId(id);
				id++;
			}
		}

		return true;
	}

	public File getConfigFile() {
		return configFile;
	}

	public List<BehaviorBean> getBehaviors() {
		return behaviors;
	}
}

package at.fhhagenberg.mc.traffsim.routing;

import de.cm.osm2po.logging.Log;
import de.cm.osm2po.routing.GraphCostsOverrider;

/**
 * Overrider, which is able to reset its cost to a given base at once, not only edge by edge.
 * 
 * @author Christian Backfrieder
 * 
 */
public class TransientGraphCostsOverrider extends GraphCostsOverrider {

	private float[] currentCosts;
	private final int[] edgeIdxs;
	private final OverrideableGraph graph;
	private final int continuousIndex;
	private static int maxNumber;

	public TransientGraphCostsOverrider(OverrideableGraph graph, boolean hOrKm, Log log) {
		super(graph, hOrKm, log);
		this.graph = graph;
		this.currentCosts = (hOrKm ? graph.getEdgeCostsH() : graph.getEdgeCostsKm());
		this.edgeIdxs = graph.createTransformedEdgeIndex();
		continuousIndex = maxNumber++;
	}

	public OverrideableGraph getGraph() {
		return graph;
	}

	@Override
	public float[] getCurrentCosts() {
		return currentCosts;
	}

	public void resetToCosts(float[] costs) {
		System.arraycopy(costs, 0, this.currentCosts, 0, costs.length);
	}

	/**
	 * Temporarily override cost in the dynamic transient graph, which is not used for normal route calculations, but only for a short
	 * period of time. The override is valid until the next call of {@link AbstractRouteService#resetDynamicGraph()} is caled.
	 * 
	 * @param segmentId
	 * @param cost
	 *            in hours
	 * @param reverse
	 */
	@Override
	public void overrideCost(int segmentId, float cost, boolean reverse) {
		int edgeId = segmentId - 1 << 1;
		if (reverse)
			edgeId++;
		int edgeIdx = this.edgeIdxs[edgeId];
		this.currentCosts[edgeIdx] = cost;
	}

	public final int getContinuousIndex() {
		return continuousIndex;
	}
}

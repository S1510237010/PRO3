package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import java.util.Properties;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.data.csv.CFDataSet;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Behavior;
import at.fhhagenberg.mc.traffsim.vehicle.BehaviorType;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle.VehicleProperties;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.AbstractModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.LongitudinalModelInputParameterSet;

public class LongitudinalControl<T extends ILongitudinalModel> extends AbstractModel {
	public static final int FREE_FLOW_DISTANCE = 10000;

	protected T longitudinalModel;
	/**
	 * CLLxT = cooperative longitudinal and lane-change extension -
	 * <a href="https://link.springer.com/chapter/10.1007/978-3-319-39595-1_6">CLLxT Publication - Springer Link</a>
	 */
	private boolean cllxtEnabled;
	protected String identifier;
	protected double simulationTime;

	protected LongitudinalModelInputParameterSet modelInput;

	private boolean recordModelInputStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS);

	private double lastDistToFront;

	public LongitudinalControl() {

	}

	public LongitudinalControl(String identifier) {
		this.identifier = identifier;
	}

	/**
	 * Update function, which can be overridden by subclasses and called on each simulation time step. Perform time-dependent longitudinal
	 * update tasks therein.
	 *
	 * @param dt
	 *            the simulation time step (time duration in seconds since last update)
	 * @param simulationTime
	 *            the current simulation time in seconds
	 */
	public void update(double dt, double simulationTime) {
		this.simulationTime = simulationTime;
	}

	public LongitudinalControl<T> copy(double vTarget) {
		LongitudinalControl<T> copy = new Kryo().copy(this);
		copy.getLongitudinalModel().getModelData().setvTarget(vTarget);
		return copy;
	}

	public double getTargetSpeed() {
		return getLongitudinalModel().getModelData().getvTarget();
	}

	protected AccUpdateData getAccUpdateData(Vehicle me) {
		return getAccUpdateData(me, me.getLaneSegment(), null, 0, 1);
	}

	protected AccUpdateData getAccUpdateData(Vehicle me, VehiclesLane seg, Vehicle virtualFront, double virtualFrontDistance, int lookForward) {
		VehicleWithDistance vd = null;

		if (virtualFront == null) {
			vd = seg.frontVehicle(me);
		} else {
			vd = new VehicleWithDistance(virtualFront, virtualFrontDistance);
		}

		double s = 0;
		double dv = 0;
		double aLead = 0;
		VehicleType frontVehicleType = VehicleType.NONE;
		Vehicle vehicle = null;

		if (vd != null) {
			s = vd.getDistance();
			VehicleWithDistance vd_forward = vd;

			for (int i = 1; i < lookForward; i++) {
				vd_forward = seg.frontVehicle(vd_forward.getVehicle());
				if (vd_forward != null) {
					s += vd_forward.getDistance();
				} else {
					s = Double.POSITIVE_INFINITY;
				}
			}

			if (vd_forward != null) {
				dv = me.getCurrentSpeed() - vd_forward.getVehicle().getCurrentSpeed();
				aLead = vd_forward.getVehicle().getCurrentAcc();
				frontVehicleType = vd_forward.getVehicle().getType();
				vehicle = vd.getVehicle();
			}
		} else {
			s = FREE_FLOW_DISTANCE;
		}
		return new AccUpdateData(s, dv, aLead, frontVehicleType, vehicle, seg);
	}

	/**
	 * Convenience method for {@link #calcAccSolitary(Vehicle, VehiclesLane, int, Vehicle, double)}, which uses no virtual, but the real
	 * front vehicle
	 *
	 * @param me
	 *            the vehicle for which to calculate the acceleration
	 * @param lane
	 *            the lane of the vehicle
	 * @return current acceleration value in m/s^2
	 * @see #calcAccSolitary(Vehicle, VehiclesLane, int, Vehicle, double)
	 */
	public double calcAccSolitary(Vehicle me, VehiclesLane lane) {
		return calcAccSolitary(me, lane, 1, null, 0);
	}

	/**
	 * Calculate the current acceleration without considering any external effects, but only the vehicle, the provided front vehicle and the
	 * given lane.
	 *
	 * @param me
	 *            the vehicle to calc acc for
	 * @param seg
	 *            the {@link VehiclesLane} to use
	 * @param lookForward
	 *            the distance to look forward: if no virtual front is set, the front vehicle is determined by
	 *            {@link VehiclesLane#frontVehicle()}. In this case, one can specify if the first, second, ... nth front vehicle should be
	 *            used for acc calculation. Use <code>null</code> for virtualFront in order to consider this parameter!
	 * @param virtualFront
	 *            a virtual front vehicle to use (do not use the real front vehicle) - needs also virtualFrontDistance parameter
	 * @param virtualFrontDistance
	 *            the distance of me to the virtual front vehicle (only relevant in combination with virtualFront parameter)
	 * @return acceleration without any external effects
	 */
	public double calcAccSolitary(Vehicle me, VehiclesLane seg, int lookForward, Vehicle virtualFront, double virtualFrontDistance) {
		AccUpdateData accData = getAccUpdateData(me, seg, virtualFront, virtualFrontDistance, lookForward);
		return getLongitudinalModel().calcAcc(me, me.getCurrentSpeed(), accData.distance, accData.speedDiff, accData.accLead, 1, 1, 1,
				seg.getSpeedLimitMps());
	}

	/**
	 * Calculates the vehicles acceleration under consideration ALL modifications which are implemented by custom longitudinal controls
	 * (e.g. considering human factors, special cases for lane changes etc.). This is the acceleration which is used to actually update the
	 * vehicle's acceleration.
	 *
	 * @param me
	 *            the vehicle of interest
	 * @param alphaT
	 *            model parameter
	 * @param alphaV0
	 *            model parameter
	 * @param alphaA
	 *            model parameter
	 * @return the vehicle's current acceleration considering human limitations
	 */
	public double calcAccComprehensive(Vehicle me, double alphaT, double alphaV0, double alphaA) {
		AccUpdateData accData = getAccUpdateData(me, me.getLaneSegment(), null, 0, 1);
		double acc = calcAccCustom(me, accData, alphaT, alphaV0, alphaA);

		acc = adaptAccBehavioral(me, acc);

		acc = updateAccForOwnLaneChange(me, acc);

		acc = updateAccForCooperativeLaneChange(me, acc);

		// limit acc to allowed range
		acc = NumberUtil.limit(acc, getLongitudinalModel().getModelData().getMaxDec(), getLongitudinalModel().getModelData().getMaxAcc());

		if (recordModelInputStatistics) {
			updateModelInput(me, acc, accData.speedDiff, accData.distance, accData.accLead, alphaT, alphaV0, alphaA);
		}
		lastDistToFront = accData.distance;
		return acc;
	}

	public double getLastDistToFront() {
		return lastDistToFront;
	}

	/**
	 * Update the acceleration so that it takes the adaption of the current acceleration due to own lane change demands into account
	 *
	 * @param v
	 *            the affected vehicle
	 * @param currentAcc
	 *            current acceleration
	 * @return adapted acceleration, if own lane change is necessary, or the unmodified currentacc if no adaption is required
	 */
	private double updateAccForOwnLaneChange(Vehicle v, double currentAcc) {
		double updatedAcc = currentAcc;

		Properties vehicleProperties = v.getVehicleProperties();
		int dir;
		// check if breaking acc is necessary for own lane change
		double urgency = PropertyUtil.getDoubleProperty(vehicleProperties, VehicleProperties.LANE_CHANGE_URGENCY.name(), 0.0);
		if ((dir = PropertyUtil.getIntProperty(vehicleProperties, VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name(),
				Lane.NO_CHANGE)) != Lane.NO_CHANGE && urgency > 0) {
			LaneSegment newLane = v.getRoadSegment().laneSegment(v.getLaneSegment().getLaneIndex() + dir);
			VehicleWithDistance newFront = newLane == null ? null : newLane.frontVehicle(v);
			if (newFront != null && newFront.getVehicle() != null) {
				updatedAcc -= Math.abs(updatedAcc) * urgency;
			}

		}
		return updatedAcc;
	}

	private double updateAccForCooperativeLaneChange(Vehicle v, double originalAcc) {
		if (!isCllxtEnabled()) {
			return originalAcc;
		}
		RoadSegment curRoadSeg = v.getRoadSegment();
		VehiclesLane curLaneSeg = v.getLaneSegment();
		double waitAcc = Double.POSITIVE_INFINITY;
		boolean waitAccAvailable = false;
		// check if vehicle wants to change lane - if yes, break to let it pass
		if (curRoadSeg != null && curRoadSeg.getLaneCount() > 1) {
			LaneSegment leftLane = curRoadSeg.laneSegment(curLaneSeg.getLaneIndex() + Lane.TO_LEFT);

			if (leftLane != null) {
				VehicleWithDistance leftFront = leftLane.frontVehicle(v.getFrontPosition());

				if (leftFront != null && !leftFront.getVehicle().isObstacle()
						&& leftFront.getDistance() > getLongitudinalModel().getModelData().getsMin()) {
					int dir = PropertyUtil.getIntProperty(leftFront.getVehicle().getVehicleProperties(),
							VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name(), 0);

					if (dir == Lane.TO_RIGHT) {
						waitAcc = Math.max(getLongitudinalModel().getModelData().getMaxDec(),
								calcAccSolitary(v, curLaneSeg, 1, leftFront.getVehicle(), leftFront.getDistance()));
						waitAccAvailable = true;
					}
				}
			}

			LaneSegment rightLane = curRoadSeg.laneSegment(curLaneSeg.getLaneIndex() + Lane.TO_RIGHT);

			if (rightLane != null) {
				VehicleWithDistance rightFront = rightLane.frontVehicle(v.getFrontPosition());

				if (rightFront != null && !rightFront.getVehicle().isObstacle()
						&& rightFront.getDistance() > getLongitudinalModel().getModelData().getsMin()) {
					int dir = PropertyUtil.getIntProperty(rightFront.getVehicle().getVehicleProperties(),
							VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name(), 0);

					if (dir == Lane.TO_LEFT) {
						waitAcc = Math.min(waitAcc, Math.max(getLongitudinalModel().getModelData().getMaxDec(),
								calcAccSolitary(v, curLaneSeg, 1, rightFront.getVehicle(), rightFront.getDistance())));
						waitAccAvailable = true;
					}
				}
			}
			if (waitAccAvailable) {
				return Math.min(waitAcc, originalAcc);
			}
		}
		// additional return statement for performance reasons (avoid minimum calculation), because this will be the standard case
		return originalAcc;
	}

	/**
	 * Custom acceleration calculation, which is intended to be overridden by subclasses and called by
	 * {@link #calcAccComprehensive(Vehicle, double, double, double)}. This default implementation simply calls the underlying longitudinal
	 * model.
	 *
	 * @param me
	 *            The vehicle to calc acceleration for
	 * @param accData
	 *            the acc data which should be used for acc calculation
	 * @param alphaT
	 *            alpha for time of memory model
	 * @param alphaV0
	 *            alpha for speed of memory model
	 * @param alphaA
	 *            alpha for acceleration for memory model
	 * @return the custom acceleration value, depending on the logic in the longitudinal control
	 */
	protected double calcAccCustom(Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA) {
		return getLongitudinalModel().calcAcc(me, me.getCurrentSpeed(), accData.distance, accData.speedDiff, accData.accLead, alphaT, alphaV0, alphaA,
				getSpeedLimitMps(me));
	}

	/**
	 * Calculates the acceleration for the given vehicle based on behaviors assigned to the target vehicle. If no behaviors are assigned or
	 * none of them is executed
	 *
	 * @param me
	 *            the target vehicle
	 * @return the acceleration as imposed by a behavior, or the original acceleration if behaviours have (currently) no influence
	 */
	private double adaptAccBehavioral(Vehicle me, double originalAcc) {
		Behavior behavior = me.getNextBehavior();

		// In case a behavior is currently active, the current acceleration is imposed by it
		if (behavior != null) {

			LongitudinalControl<?> longitudinalControl = me.getLongitudinalControl();
			IDistractibleLongitudinalControl distractibleControl = (longitudinalControl instanceof IDistractibleLongitudinalControl)
					? ((IDistractibleLongitudinalControl) longitudinalControl) : null;

			if (behavior.readyForExecution(simulationTime)) {

				// Behavior execution finished
				if (behavior.finishedExecution(simulationTime)) {
					if (behavior.getBehaviorType() == BehaviorType.DISTRACTION_MIND_OFF_ROAD) {
						if (distractibleControl != null) {
							distractibleControl.distract(1 / distractibleControl.getDelayFactor());
							distractibleControl.setDistracted(false);
							Logger.logDebug("Vehicle '" + me.getLabel() + "' now pays attention again.");
						}
					} else if (behavior.getBehaviorType() == BehaviorType.DISTRACTION_EYES_OFF_ROAD) {
						if (distractibleControl != null) {
							distractibleControl.setDistracted(false);
							distractibleControl.setSeverelyDistracted(false);
							Logger.logDebug("Vehicle '" + me.getLabel() + "' is monitoring the road again.");
						}
					} else if (behavior.getBehaviorType() == BehaviorType.TRACE) {
						me.setIsVehicleBehaviorControlled(false);
						me.setRequiredTargetSpeed(0);
						Logger.logDebug("Finished trace behavior execution for vehicle '" + me.getLabel() + "'");
					} else {
						Logger.logDebug("Finished behavior execution for vehicle '" + me.getLabel() + "'");
					}

					me.switchToNextBehavior();
				}

				// Behavior is executing
				if (behavior.isExecuting(simulationTime)) {
					if (behavior.getBehaviorType() == BehaviorType.ACCELERATION) {
						Logger.logDebug("Executing behavior '" + behavior.toString() + "' for vehicle '" + me.getLabel() + "'");
						return behavior.getIntensity();
					} else if (behavior.getBehaviorType() == BehaviorType.DECELERATION) {
						Logger.logDebug("Executing behavior '" + behavior.toString() + "' for vehicle '" + me.getLabel() + "'");
						return -behavior.getIntensity();
					} else if (behavior.getBehaviorType() == BehaviorType.DISTRACTION_MIND_OFF_ROAD) {
						if (distractibleControl != null && !distractibleControl.isDistracted()) {
							distractibleControl.distract(1 + behavior.getParam() / 100.0);
							distractibleControl.setDistracted(true);
							me.onVehicleDistracted(behavior.getDuration(), false);
							Logger.logDebug("Vehicle '" + me.getLabel() + "' is distracted (mind-off-road)");
						}
					} else if (behavior.getBehaviorType() == BehaviorType.DISTRACTION_EYES_OFF_ROAD) {
						if (distractibleControl != null && !distractibleControl.isDistracted()) {
							distractibleControl.setDistracted(true);
							distractibleControl.setSeverelyDistracted(true);
							me.onVehicleDistracted(behavior.getDuration(), true);
							Logger.logDebug("Vehicle '" + me.getLabel() + "' is distracted (eyes-off-road)");
						}
					} else if (behavior.getBehaviorType() == BehaviorType.TRACE) {
						Logger.logDebug("Executing trace behavior for vehicle '" + me.getLabel() + "'");

						if (!behavior.getControlTrace().isEmpty()) {
							me.setIsVehicleBehaviorControlled(true);
							CFDataSet curSet = behavior.getControlTrace().remove(0);
							return curSet.getAccLeadVehicle();
						} else {
							me.setIsVehicleBehaviorControlled(false);
							me.setRequiredTargetSpeed(0);
						}
					}
				}
			}
		}

		// The vehicle is steered by a control behavior, but no behaviour is applicable. Continue with zero acc
		if (me.isVehicleBehaviorControlled()) {
			return 0;
		}

		return originalAcc;
	}

	protected double getSpeedLimitMps(Vehicle me) {
		double roadSpeedLimit = Double.POSITIVE_INFINITY;

		if (me.getRoadSegment() != null) {
			double correction = PropertyUtil.getDoubleProperty(me.getVehicleProperties(),
					VehicleProperties.SLOW_DOWN_PERCENTAGE_DUE_TO_LANE_CHANGE.name(), 0.0);

			if (correction < 0) {
				correction = 1;
			} else {
				correction = 1 - correction;
			}

			roadSpeedLimit = me.getRoadSegment().getSpeedLimitMps() * correction;
		} else if (me.getJunction() != null) {
			roadSpeedLimit = me.getLaneSegment().getSinkLaneSegment().getRoadSegment().getSpeedLimitMps();// me.getJunction().getSpeedLimitMps();
		}

		// set speed limit down to reach desired speed when limit zone starts
		double speedLimit = Double.POSITIVE_INFINITY;
		if (me.getRoadSegment() != null && (me.getRoadSegment().getSinkRoadSegment() != null || me.getRoadSegment().getJunction() != null)) {
			double speedLimitSink;

			if (me.getRoadSegment().getJunction() != null) {
				speedLimitSink = me.getRoadSegment().getJunction().getSpeedLimitMps();
			} else {
				speedLimitSink = me.getRoadSegment().getSinkRoadSegment().getSpeedLimitMps();
			}
			if (speedLimitSink < roadSpeedLimit) {

				Vehicle dummy = VehicleFactory.createDummy(speedLimitSink, me.getLaneSegment().getRoadLength() - me.getFrontPosition(),
						speedLimitSink);
				Vehicle meCopy = VehicleFactory.createDummy(me.getCurrentSpeed(), me.getFrontPosition(), me.getCurrentSpeed());
				meCopy.setLaneSegment(me.getLaneSegment());
				double accSpeedLimit = calcAccSolitary(meCopy, me.getLaneSegment(), 1, dummy,
						me.getLaneSegment().getRoadLength() - me.getFrontPosition());

				if (accSpeedLimit < getLongitudinalModel().getModelData().getSafeDec()) {
					speedLimit = speedLimitSink;
				}
			}

		}

		return Math.min(speedLimit, roadSpeedLimit);
	}

	public boolean isCllxtEnabled() {
		return cllxtEnabled;
	}

	public void setCllxtEnabled(boolean cllxtEnabled) {
		this.cllxtEnabled = cllxtEnabled;
	}

	private void updateModelInput(Vehicle vehicle, double appliedAcc, double dv, double s, double aLead, double alphaTLocal, double alphaV0Local,
			double alphaALocal) {
		if (modelInput == null) {
			modelInput = new LongitudinalModelInputParameterSet(vehicle.getUniqueId(), appliedAcc, vehicle.getCurrentSpeed(), dv, s, aLead,
					alphaALocal, alphaTLocal, alphaV0Local);
		} else {
			modelInput.setV(vehicle.getCurrentSpeed());
			modelInput.setAppliedAcc(appliedAcc);
			modelInput.setDv(dv);
			modelInput.setS(s);
			modelInput.setALead(aLead);
			modelInput.setAlphaA(alphaALocal);
			modelInput.setAlphaT(alphaTLocal);
			modelInput.setAlphaV0(alphaV0Local);
		}
	}

	public LongitudinalModelInputParameterSet getModelInputParameterSet() {
		return modelInput;
	}

	public String getIdentifier() {
		return identifier;
	}

	@Override
	public String getName() {
		return identifier;
	}

	public void setLongitudinalModel(T longitudinalModel) {
		this.longitudinalModel = longitudinalModel;
	}

	public T getLongitudinalModel() {
		return longitudinalModel;
	}

	public double getMinGap() {
		return getLongitudinalModel().getModelData().getsMin();
	}

	public double getTimeGap() {
		return getLongitudinalModel().getModelData().gettMin();
	}

	public double getComfortableAcc() {
		return getLongitudinalModel().getModelData().getComfortableAcc();
	}

	public double getSafeDec() {
		return getLongitudinalModel().getModelData().getSafeDec();
	}
}
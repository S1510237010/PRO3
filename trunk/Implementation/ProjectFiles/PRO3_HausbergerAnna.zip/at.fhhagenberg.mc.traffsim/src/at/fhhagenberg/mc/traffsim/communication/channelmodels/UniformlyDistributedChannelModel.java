package at.fhhagenberg.mc.traffsim.communication.channelmodels;

import java.util.Random;

import at.fhhagenberg.mc.traffsim.communication.IChannelModel;

public class UniformlyDistributedChannelModel implements IChannelModel {

	double pSuccess = 0;
	Random random = new Random();
	private String name;

	public UniformlyDistributedChannelModel() {
	}

	public UniformlyDistributedChannelModel(double successProbability) {
		this.pSuccess = successProbability;
	}

	@Override
	public long getNextDelay() {
		return 0;
	}

	@Override
	public boolean isSuccessful() {
		return random.nextDouble() < pSuccess;
	}

	@Override
	public IChannelModel clone() throws CloneNotSupportedException {
		// clone not necessary because model is stateless and same instance can be used
		return this;
	}

	public void setRandomSeed(long seed) {
		this.random = new Random(seed);
	}

	public void setSuccessProbability(double successProbability) {
		this.pSuccess = successProbability;
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return name + " (pSuccess " + pSuccess + ")";
	}
}

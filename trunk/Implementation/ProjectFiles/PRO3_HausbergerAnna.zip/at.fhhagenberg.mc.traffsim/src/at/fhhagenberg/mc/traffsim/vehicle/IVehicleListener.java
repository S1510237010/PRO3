package at.fhhagenberg.mc.traffsim.vehicle;

import at.fhhagenberg.mc.traffsim.model.ISimulationFinishedListener;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;

/**
 * Listener interface which is notified if the state of the vehicle as a whole changes (e.g. changed active {@link RoadSegment})
 * 
 * @author Christian Backfrieder
 * 
 */
public interface IVehicleListener {
	/**
	 * Vehicle left the simulation through a dangling road or lane segment. It is ensured that this notification is thrown before
	 * {@link ISimulationFinishedListener#simulationFinished()} notification.
	 * 
	 * @param v
	 *            the {@link Vehicle}
	 */
	default public void vehicleLeftSimulation(Vehicle v) {
	};

	/**
	 * Vehicle already left the simulation, and all listeners have already been notified with {@link #vehicleLeftSimulation(Vehicle)} before
	 * this method is called for the very first time! <br>
	 * <br>
	 * This functionality is used to detect finishing, in order not to notify about a finished simulation before the last call of
	 * {@link #vehicleLeftSimulation(Vehicle)}. <br>
	 * <br>
	 * <b>Warning: </b>If multiple subclasses of this interface have an implementation of this method, the last
	 * {@link #postLeftSimulation(Vehicle)} notification may occur after {@link ISimulationFinishedListener#simulationFinished()}
	 * notification!
	 * 
	 * @param v
	 *            the vehicle which left the simulation
	 */
	default public void postLeftSimulation(Vehicle v) {
	}

	/**
	 * Vehicle changed the lane segment (either due to lane change, or due to change of the current {@link RoadSegment}
	 * 
	 * @param vehicle
	 * @param oldLane
	 * @param newLane
	 */
	default public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {
	};

	/**
	 * The vehicle changed its distraction state
	 * 
	 * @param vehicleId
	 * @param isDistractionSevere
	 * @param duration
	 */
	default public void onDriverDistracted(long vehicleId, boolean isDistractionSevere, double duration) {
	}

	/**
	 * Notification that an already created vehicle entered a concrete road
	 * 
	 * @param vehicle
	 *            the vehicle that entered
	 */
	default void vehicleEntered(Vehicle vehicle) {
	}
}

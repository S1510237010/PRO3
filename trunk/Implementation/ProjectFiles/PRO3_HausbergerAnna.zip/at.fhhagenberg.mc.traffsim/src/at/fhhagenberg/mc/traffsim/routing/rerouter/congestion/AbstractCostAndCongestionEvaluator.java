package at.fhhagenberg.mc.traffsim.routing.rerouter.congestion;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.routing.AbstractRouteService;
import at.fhhagenberg.mc.traffsim.routing.Congestion;
import at.fhhagenberg.mc.traffsim.routing.rerouter.AbstractCostEvaluator;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICongestionProvider;
import at.fhhagenberg.mc.traffsim.statistics.events.IEventLog;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public abstract class AbstractCostAndCongestionEvaluator extends AbstractCostEvaluator implements ICongestionProvider {
	protected float congestionThreshold;
	protected int congestionLevel;
	protected IEventLog eventLog;

	private long nextCongestionUpdate = 0;
	private long congestionDetectionUpdateMillis;
	protected int numVehiclesForCongestion;

	protected Queue<RoadSegment> congestedSegments = new ConcurrentLinkedQueue<>();

	/** mapping from segment id to last notification timestamp (in order to avoid multiple notifications of the same segment) */
	protected Map<Long, Long> lastCongestedNotifications = new ConcurrentHashMap<>();
	protected long notificationThreshold = 10000;

	public AbstractCostAndCongestionEvaluator(String name, long updateIntervalMillis, long congestionDetectionUpdateMillis, RoadNetwork network,
			AbstractRouteService router, float congestionThreshold, int congestionLevel, int numVehiclesForCongestion, IEventLog log) {
		super(name, updateIntervalMillis, network, router);
		this.congestionDetectionUpdateMillis = congestionDetectionUpdateMillis;
		this.congestionThreshold = congestionThreshold;
		this.congestionLevel = congestionLevel;
		this.numVehiclesForCongestion = numVehiclesForCongestion;
		this.eventLog = log;
	}

	@Override
	public Queue<Congestion> getCongestions() {
		if (nextCongestionUpdate - getCurrentSimTime().getTime() <= 0) {
			Queue<Congestion> congestions = new LinkedBlockingQueue<>();
			Queue<RoadSegment> congSegCopy = congestedSegments;
			congestedSegments = new ConcurrentLinkedQueue<>();
			for (RoadSegment seg : congSegCopy) {
				List<Vehicle> sourceVehicles = getAllSourceVehicles(seg, new ArrayList<Vehicle>(), congestionLevel);
				List<Vehicle> vehicles = filterVehiclesPassing(sourceVehicles, seg, true);
				AbstractJunction nextJunc = RoadUtil.getNextJunctionOnly(seg);
				if (nextJunc != null) {
					// next junc may be null, in case of a dangling road segment
					congestions.add(new Congestion(nextJunc.getId(), 0, vehicles));
				}
			}
			nextCongestionUpdate = getCurrentSimTime().getTime() + congestionDetectionUpdateMillis;
			return congestions;

		}
		return new LinkedBlockingQueue<>();
	}

	/**
	 * Determine all vehicles which pass the given road segment and look back the given depth (recursive method)
	 *
	 * @param seg
	 *            the segment which is the origin of the lookup
	 * @param currentList
	 *            the current list of vehicles (usually is empty on initial call, used for recursion)
	 * @param remainingDepth
	 *            the depth how many {@link RoadSegment}s to look back in the road graph
	 * 
	 * @return the list of all {@link Vehicle}s which pass the given {@link RoadSegment} and are within the lookup depth of the
	 *         {@link RoadNetwork}
	 */
	private List<Vehicle> getAllSourceVehicles(RoadSegment seg, List<Vehicle> currentList, int remainingDepth) {
		if (remainingDepth-- > 0) {
			// System.out.println("seg: " + seg.getId() + " (" + seg.getName() + ") depth " + remainingDepth + " | add "
			// + seg.getAllVehicles().size());
			currentList.addAll(seg.getAllVehicles());
			if (seg.getSourceRoadSegment() != null) {
				return getAllSourceVehicles(seg.getSourceRoadSegment(), currentList, remainingDepth);
			} else if (network.getJunctionBySinkRoadSegment(seg) != null) {
				AbstractJunction junc = network.getJunctionBySinkRoadSegment(seg);
				currentList.addAll(junc.getVehicles());
				for (RoadSegment rsIn : junc.getSegmentsIn()) {
					if (rsIn.getRoutingId() != seg.getRoutingId()) {
						currentList = getAllSourceVehicles(rsIn, currentList, remainingDepth);
					}
				}
			}
		}
		return currentList;
	}

	protected boolean isMultiNotification(long segmentId) {
		return lastCongestedNotifications.containsKey(segmentId)
				&& getCurrentSimTime().getTime() - lastCongestedNotifications.get(segmentId) < notificationThreshold;
	}
}

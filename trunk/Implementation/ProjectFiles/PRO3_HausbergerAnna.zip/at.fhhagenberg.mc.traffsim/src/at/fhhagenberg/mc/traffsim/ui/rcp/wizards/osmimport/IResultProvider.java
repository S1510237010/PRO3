package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.osmimport;

import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;

public interface IResultProvider {
	public TraffSimConfiguration getResult();
}

package at.fhhagenberg.mc.traffsim.util;

/**
 * Utility class providing enum-related functionality.
 *
 * @author Christian Backfrieder
 */
public class EnumUtil {

	/**
	 * Converts the given array of enum-values of type T into a corresponding string array.
	 *
	 * @param <T>
	 *            the generic type
	 * @param values
	 *            the array of enum values
	 * @return the converted string array
	 */
	public static <T extends Enum<T>> String[] enumNameToStringArray(T[] values) {
		int i = 0;
		String[] result = new String[values.length];
		for (T value : values) {
			result[i++] = value.name();
		}
		return result;
	}
}
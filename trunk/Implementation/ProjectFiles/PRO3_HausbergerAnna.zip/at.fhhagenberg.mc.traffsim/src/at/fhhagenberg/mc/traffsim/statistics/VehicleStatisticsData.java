package at.fhhagenberg.mc.traffsim.statistics;

import java.util.ArrayList;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.IDistractibleLongitudinalControl;

/**
 * Statistics data for a single vehicle. Contains properties for each time step which is recorded! Number of timesteps must therefore be
 * equal to the number of data which is recorded.
 *
 * @author Christian Backfrieder
 *
 */
public class VehicleStatisticsData extends BaseVehicleStatisticsData {
	private static final long serialVersionUID = -4386668188143211798L;
	private double avgFuelConsumptionPer100km = 0;
	private double avgSpeed = 0;

	private long recordedItemsInMotion = 0;

	private long removedItems = 0;
	private long routeUpdates = 0;
	final Vehicle vehicle;

	public VehicleStatisticsData() {
		super(-1l);
		this.vehicle = null;
	}

	public VehicleStatisticsData(long id) {
		super(id);
		this.vehicle = null;
	}

	public VehicleStatisticsData(Vehicle v) {
		super(v.getUniqueId());
		this.vehicle = v;
	}

	/**
	 * Add a dataset to the vehicle statistics
	 *
	 * @param time
	 *            the time where the data was measured
	 * @param vehicle
	 *            the vehicle from which to extract the data
	 */
	public synchronized void addData(double time, Vehicle vehicle) {
		if (vehicle.getCurrentSpeed() > 0) {
			recordedItemsInMotion++;
			avgSpeed = (avgSpeed * (recordedItemsInMotion - 1) + vehicle.getCurrentSpeed()) / recordedItemsInMotion;
			avgFuelConsumptionPer100km = (avgFuelConsumptionPer100km * (recordedItemsInMotion - 1) + vehicle.getCurrentFuelConsumption()[1])
					/ recordedItemsInMotion;
		}

		this.time.add(time);
		speed.add(vehicle.getCurrentSpeed());
		acc.add(vehicle.getCurrentAcc());
		travelDistance.add(vehicle.getTravelDistance());
		fuelConsumptionPerHour.add(vehicle.getCurrentFuelConsumption()[0]);
		fuelConsumptionPer100km.add(vehicle.getCurrentFuelConsumption()[1]);
		carbonEmissionsPerHour.add(vehicle.getCurrentCarbonFootprint()[0]);
		carbonEmissionsPer100km.add(vehicle.getCurrentCarbonFootprint()[1]);
		distanceToFront.add(vehicle.getLongitudinalControl().getLastDistToFront());
		position.add(vehicle.getAbsolutePosition());
		totalFuelConsumed = vehicle.getFuelConsumed();
		totalCarbonEmissions = vehicle.getCarbonFootprint();

		boolean isDistracted = false;
		if (vehicle.getLongitudinalControl() instanceof IDistractibleLongitudinalControl) {
			IDistractibleLongitudinalControl l = (IDistractibleLongitudinalControl) vehicle.getLongitudinalControl();
			isDistracted = l.isDistracted();
		}
		distractionState.add(isDistracted ? 1d : 0d);

		recordedItems++;
	}

	public VehicleStatisticsData collectData(int numItemsToKeep) {
		VehicleStatisticsData data = new VehicleStatisticsData(vehicle.getUniqueId());
		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.acc.addAll(acc.subList(0, numItems));
				data.travelDistance.addAll(travelDistance.subList(0, numItems));
				data.fuelConsumptionPer100km.addAll(fuelConsumptionPer100km.subList(0, numItems));
				data.fuelConsumptionPerHour.addAll(fuelConsumptionPerHour.subList(0, numItems));
				data.carbonEmissionsPer100km.addAll(carbonEmissionsPer100km.subList(0, numItems));
				data.carbonEmissionsPerHour.addAll(carbonEmissionsPerHour.subList(0, numItems));
				data.position.addAll(position.subList(0, numItems));
				data.speed.addAll(speed.subList(0, numItems));
				data.time.addAll(time.subList(0, numItems));
				data.distanceToFront.addAll(distanceToFront.subList(0, numItems));
				data.distractionState.addAll(distractionState.subList(0, numItems));
				data.totalFuelConsumed = totalFuelConsumed;
				data.totalCarbonEmissions = totalCarbonEmissions;

				// remove the collected sublist from statistics data
				acc = new ArrayList<>(acc.subList(numItems, lastIndex));
				travelDistance = new ArrayList<>(travelDistance.subList(numItems, lastIndex));
				fuelConsumptionPer100km = new ArrayList<>(fuelConsumptionPer100km.subList(numItems, lastIndex));
				fuelConsumptionPerHour = new ArrayList<>(fuelConsumptionPerHour.subList(numItems, lastIndex));
				carbonEmissionsPer100km = new ArrayList<>(carbonEmissionsPer100km.subList(numItems, lastIndex));
				carbonEmissionsPerHour = new ArrayList<>(carbonEmissionsPerHour.subList(numItems, lastIndex));
				distanceToFront = new ArrayList<>(distanceToFront.subList(numItems, lastIndex));
				distractionState = new ArrayList<>(distractionState.subList(numItems, lastIndex));

				position = new ArrayList<>(position.subList(numItems, lastIndex));
				speed = new ArrayList<>(speed.subList(numItems, lastIndex));
				time = new ArrayList<>(time.subList(numItems, lastIndex));

				removedItems += numItems;
				data.recordedItems = recordedItems;
			}
		}

		return data;
	}

	public double getAvgFuelConsumptionPer100km() {
		return avgFuelConsumptionPer100km;
	}

	public double getAvgSpeed() {
		return avgSpeed;
	}

	/**
	 *
	 * @return the amount of items which already has been removed.
	 */
	public long getRemovedItems() {
		return removedItems;
	}

	public long getRouteUpdates() {
		return routeUpdates;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void increaseRouteUpdates() {
		routeUpdates++;
	}

	/**
	 * Transforms the given index (which is relative to the total items ever added to this statistics) to an index which is decreased by the
	 * elements which potentially have been removed
	 *
	 * @param totalIndex
	 * @return transformed index, which can be applied to the recorded arrays
	 */
	public int transformIndex(long totalIndex) {
		return (int) (totalIndex - removedItems);
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import at.fhhagenberg.mc.traffsim.changes.ChangeAuthor;
import at.fhhagenberg.mc.traffsim.changes.ChangeSet;
import at.fhhagenberg.mc.traffsim.changes.ChangeSetDateConverter;
import at.fhhagenberg.mc.traffsim.changes.ChangeSetItem;
import at.fhhagenberg.mc.traffsim.changes.ChangeSetList;
import at.fhhagenberg.mc.traffsim.changes.Changelog;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;

public class ChangelogView extends ViewPart {
	private static final String BUILD_ID_STR = "Build ID: ";

	private Changelog changelog;
	private StyledText styledText;
	private String verticalLine;

	public ChangelogView() {
		StringBuffer vertLine = new StringBuffer();
		for (int i = 1; i < 100; i++) {
			vertLine.append("\u2015");
		}
		verticalLine = vertLine.toString();
	}

	private void readChangelog() {
		XStream xstream = new XStream(new DomDriver("UTF-8"));
		xstream.setClassLoader(this.getClass().getClassLoader());
		xstream.ignoreUnknownElements();
		xstream.autodetectAnnotations(true);
		xstream.registerConverter(new ChangeSetDateConverter());
		xstream.ignoreUnknownElements();
		xstream.processAnnotations(
				new Class[] { Changelog.class, ChangeSet.class, ChangeSetItem.class, ChangeSetList.class, ChangeAuthor.class });
		// xstream.registerConverter(new ChangeSetDateConverter());
		URL changelogUrl = Platform.getBundle(TraffSimCorePlugin.PLUGIN_ID).getEntry("changelog.xml");
		if (changelogUrl == null) {
			Logger.logWarn("Could not find changelog at awaited location in plugin " + TraffSimCorePlugin.PLUGIN_ID);
			return;
		}
		try {
			InputStream inputStream = changelogUrl.openConnection().getInputStream();
			xstream.setClassLoader(this.getClass().getClassLoader());
			changelog = (Changelog) xstream.fromXML(inputStream);
			changelog.getChangeSetLists().stream().filter(csl -> csl != null && csl.getBuildId() != null).forEach(csl -> {
				String buildDate = csl.getBuildId().equals(csl.getBuildNumber())?"":" from " + csl.getBuildId();
				String buildInfo = BUILD_ID_STR + csl.getBuildNumber() + buildDate + "\n";
				styledText.append(buildInfo);
				if (csl.getChangeSetList() != null) {
					csl.getChangeSetList().stream().filter(li -> li != null && li.getItems() != null).forEach(li -> styledText
							.append("\n\t" + li.getItems().stream().map(ChangeSetItem::toString).collect(Collectors.joining("\n\t"))));
					styledText.append("\n" + verticalLine + "\n");
				}
			});
		} catch (IOException e) {
			Logger.logWarn("Could not read changelog!");
			return;
		}
		String text = styledText.getText();
		int fromIndex = 0;
		int index = -1;
		List<StyleRange> styleRanges = new ArrayList<>();
		while ((index = text.indexOf(BUILD_ID_STR, fromIndex)) >= 0) {
			StyleRange style1 = new StyleRange();
			style1.start = index;
			int endIndex = text.indexOf('\n', index);
			style1.length = endIndex - index;
			style1.foreground = getSite().getShell().getDisplay().getSystemColor(SWT.COLOR_BLUE);
			FontData[] fd = styledText.getFont().getFontData();
			fd[0].setStyle(SWT.BOLD);
			fd[0].setHeight(14);
			style1.font = new Font(getSite().getShell().getDisplay(), fd[0]);
			styleRanges.add(style1);
			fromIndex = endIndex;
			styledText.setStyleRange(style1);
		}
		fromIndex = 0;
		index = -1;
		while ((index = text.indexOf(ChangeSetItem.AFFECTED_PATH_BULLET, fromIndex)) >= 0) {
			StyleRange style1 = new StyleRange();
			style1.start = index;
			int endIndex = text.indexOf('\n', index);
			style1.length = endIndex - index;
			style1.foreground = getSite().getShell().getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY);
			FontData[] fd = styledText.getFont().getFontData();
			fd[0].setHeight(8);
			style1.font = new Font(getSite().getShell().getDisplay(), fd[0]);
			styleRanges.add(style1);
			fromIndex = endIndex;
			styledText.setStyleRange(style1);
		}
	}

	@Override
	public void dispose() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout(SWT.HORIZONTAL));

		Composite composite_1 = new Composite(parent, SWT.NONE);
		composite_1.setLayout(new GridLayout(1, false));

		Composite composite = new Composite(composite_1, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		composite.setLayout(new FillLayout());

		styledText = new StyledText(composite, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		styledText.setAlwaysShowScrollBars(false);
		styledText.setDoubleClickEnabled(false);
		styledText.setEditable(false);
		readChangelog();

	}

	@Override
	public void setFocus() {

	}

}

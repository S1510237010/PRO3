package at.fhhagenberg.mc.traffsim.log;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import at.fhhagenberg.mc.traffsim.ui.UiConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.util.DateUtil;

/**
 * Utility class allowing to log messages to either the console or an instance of {@link ILog}.
 *
 * @author Christian Backfrieder
 *
 */
public class Logger {

	/**
	 * Creates a log message with the given level and text and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param level
	 *            the level of log as {@link String}, this added as prefix to the message (see {@link UiConstants#LOG_INFO} etc.)
	 * @param msg
	 *            the actual log message
	 */
	private static void createMessage(String level, String msg) {
		createMessage(level, msg, IStatus.OK);
	}

	/**
	 * Creates a log message with the given level, text and severity and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param level
	 *            the level of log as {@link String}, this added as prefix to the message (see {@link UiConstants#LOG_INFO} etc.)
	 * @param msg
	 *            the actual log message
	 * @param severity
	 *            the severity as numeric value, as provided by {@link IStatus}
	 */
	private static void createMessage(String level, String msg, int severity) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		int i = 0;

		while (stackTraceElements[i].getClassName().contains(Logger.class.getName())
				|| stackTraceElements[i].getClassName().contains(Thread.class.getName())) {
			i++;
		}

		String stacktrace = stackTraceElements[i].getClassName().substring(stackTraceElements[i].getClassName().lastIndexOf('.') + 1) + "."
				+ stackTraceElements[i].getMethodName() + "():" + stackTraceElements[i].getLineNumber();
		print(getDate() + level + "[" + stacktrace + "]>>  " + msg, severity);
	}

	/**
	 * Gets the current date in the format <i>yyyy-MM-dd HH:mm:ss</i>.
	 *
	 * @return the formatted date string (TraffSim default format)
	 */
	public static String getDate() {
		return DateUtil.format(new Date()) + " ";
	}

	/**
	 * Gets a stringified representation of the given {@link Exception} being composed of it's stack trace and exception message.
	 *
	 * @param e
	 *            the exception to be stringified
	 * @return a stringified representation of the provided exception
	 */
	private static String getExceptionText(Exception e) {
		if (e != null) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			return e.getMessage() + "\n" + sw.toString();
		}

		return "";
	}

	/**
	 * Creates a log message tagged as debug message and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param msg
	 *            the actual log message
	 */
	public static void logDebug(String msg) {
		createMessage(UiConstants.LOG_DEBUG, msg);
	}

	public static void logException(Exception e) {
		createMessage(UiConstants.LOG_ERROR, getExceptionText(e));
	}

	/**
	 * Creates a log message tagged as error message and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param msg
	 *            the actual log message
	 */
	public static void logError(String msg) {
		logError(msg, null);
	}

	/**
	 * Creates a log message tagged as error message and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param msg
	 *            the actual log message
	 * @param e
	 *            the exception which caused the errr
	 */
	public static void logError(String msg, Exception e) {
		if (msg == null) {
			msg = "";
		}

		createMessage(UiConstants.LOG_ERROR, msg);

		if (e != null) {
			createMessage(UiConstants.LOG_ERROR, getExceptionText(e));
		}
	}

	/**
	 * Creates a log message tagged as info message and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param msg
	 *            the actual log message
	 */
	public static void logInfo(String msg) {
		createMessage(UiConstants.LOG_INFO, msg);
	}

	/**
	 * Creates a log message tagged as info message and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param msg
	 *            the actual log message
	 * @param e
	 *            an exception which is logged for informative reasons
	 */
	public static void logInfo(String msg, Exception e) {
		createMessage(UiConstants.LOG_INFO, msg + " (" + e.getMessage() + ")");
	}

	/**
	 * Creates a log message tagged as warning message and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param msg
	 *            the actual log message
	 */
	public static void logWarn(String msg) {
		logWarn(msg, null);
	}

	/**
	 * Creates a log message tagged as warning message and writes it to either the console or an instance of {@link ILog}.
	 *
	 * @param msg
	 *            the actual log message
	 * @param e
	 *            an exception which is the reason for the warning message to be logged
	 */
	public static void logWarn(String msg, Exception e) {
		if (e != null) {
			msg += "\n" + e.getMessage();
			msg += getExceptionText(e);
		}

		createMessage(UiConstants.LOG_WARNING, msg);
	}

	/**
	 * Writes the given message to either the console or an instance of {@link ILog}.
	 *
	 * @param message
	 *            the message to be logged
	 * @param severity
	 *            the severity required when logging to an instance of {@link ILog}
	 */
	private static void print(String message, int severity) {
		if (TraffSimCorePlugin.getDefault() == null) {
			System.out.println(message);
		} else {
			TraffSimCorePlugin.getDefault().getLog().log(new Status(severity, TraffSimCorePlugin.PLUGIN_ID, message));
		}
	}
}
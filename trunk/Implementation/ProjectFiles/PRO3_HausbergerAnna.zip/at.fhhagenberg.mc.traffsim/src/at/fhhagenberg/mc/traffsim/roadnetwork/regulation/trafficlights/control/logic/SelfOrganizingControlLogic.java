package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.integration.RombergIntegrator;
import org.apache.commons.math3.analysis.integration.UnivariateIntegrator;
import org.apache.commons.math3.analysis.solvers.BrentSolver;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.math.DoubleMath;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.SelfOrganizingControlLogicBean;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.QueueMonitor;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.DelayedTask;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.statistics.IStatsConstants;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;

/**
 * Implementation of control logic providing all parameters required to realize a self-organizing control logic according to L�mmer et al.
 * This comprises parameters obtained from queue monitoring such as waiting times and queue lengths.
 *
 * @author Manuel Lindorfer / Hannes Markschl�ger
 *
 */
public class SelfOrganizingControlLogic extends ControlLogic {

	public static final String CLEARING_TIME = "CLR_TIME";
	public static final String SWITCHING_PENALTY = "SWT_PENALTY";
	public static final String TAU_SWITCHING_PENALTY = "TAU_SWT_PENALTY";
	public static final String WAITING_TIME_EXP = "WAITING_TIME_EXP";

	private static final long DEFAULT_PASSOVER_TIME = 2000;
	private static final long DEFAULT_STARTUP_LOSS_TIME = 2000;
	private static final Pair<Long, Double> EMPTY_PAIR = Pair.of(0l, 0d);

	private DescriptiveStatistics efficiencyAvg;
	private UnivariateIntegrator integrator;
	private BrentSolver solver;

	private Map<String, Pair<Long, Double>> cache;
	private QueueMonitor queueMonitor;
	private double adaptivity;
	private double priorityIndex;

	private long releaseTime;
	private double releasePeriod;
	private long timeHorizon;
	private long tau;
	private long tau0;
	private long passOverTime;
	private long startUpLossTime;

	private double queueLengthTimeDependent;
	private boolean isServiced;
	private boolean isReleased;

	private LoadingCache<long[], Double> clearingTimeCache = CacheBuilder.newBuilder().maximumSize(1000).expireAfterWrite(1, TimeUnit.MINUTES)
			.build(new CacheLoader<long[], Double>() {

				@Override
				public Double load(long[] key) throws Exception {
					double result = 0;
					long time = key[0];
					long tau_ = key[1];

					// vehiclesOut(t) + greenTime*maxFlow = vehiclesExpected(t + tau + greenTime)
					UnivariateFunction f = reqGreen -> {
						// Traffic engineering, 20.2.6: 1900pcu/h
						long x = Math.round(reqGreen);
						long t = time;
						double a = queueMonitor.getCountOutflow(t) + x * getQmax();
						double b = queueMonitor.getCountExpected(time + tau_ + x);
						double d = b - a;
						return d;
					};
					try {
						result = solver.solve(100, f, -2000, 300000);

						// validation. f(result) = 0+-10ms
						if (!DoubleMath.fuzzyEquals(f.value(result), 0, 10)) {

							Logger.logWarn("validation of result failed!");
						}
					} catch (Exception e) {
						Logger.logException(e);
						// TODO adjust solver limits
						if (getQueueMonitor().getQueueLength() > 0) {
							return getQueueMonitor().getQueueLength() / getQmax();
						}
					}
					return result < 0 ? 0 : result;
				}
			});

	public SelfOrganizingControlLogic(TrafficLight trafficLight, QueueMonitor queueMonitor, long timeHorizon) {
		this(trafficLight, queueMonitor, timeHorizon, DEFAULT_PASSOVER_TIME, DEFAULT_STARTUP_LOSS_TIME);
	}

	public SelfOrganizingControlLogic(TrafficLight trafficLight, QueueMonitor queueMonitor, long timeHorizon, long passOverTime,
			long startUpLossTime) {
		super(trafficLight);
		this.cache = new HashMap<>();
		this.queueMonitor = queueMonitor;
		this.efficiencyAvg = new DescriptiveStatistics(10);
		this.integrator = new RombergIntegrator(1.0, 10, 1, RombergIntegrator.ROMBERG_MAX_ITERATIONS_COUNT);
		this.solver = new BrentSolver(0.01, 10);
		this.passOverTime = passOverTime;
		this.startUpLossTime = startUpLossTime;
		this.timeHorizon = timeHorizon;
		initialize();
	}

	public double getAdaptivity() {
		return adaptivity;
	}

	public void setAdaptivity(double adaptivity) {
		this.adaptivity = adaptivity;
	}

	public long getTimeHorizon() {
		return timeHorizon;
	}

	public void setTimeHorizon(long timeHorizon) {
		this.timeHorizon = timeHorizon;

		// Convesion from ms to s
		queueMonitor.setTimeHorizon(timeHorizon / 1000.0);
	}

	public double getPriorityIndex() {
		return priorityIndex;
	}

	public void setPriorityIndex(double priorityIndex) {
		this.priorityIndex = priorityIndex;
	}

	public QueueMonitor getQueueMonitor() {
		return queueMonitor;
	}

	public void setQueueMonitor(QueueMonitor queueMonitor) {
		this.queueMonitor = queueMonitor;
	}

	public double getReleasePeriod() {
		return releasePeriod;
	}

	public void setReleasePeriod(double releasePeriod) {
		this.releasePeriod = releasePeriod;
	}

	public long getReleaseTime() {
		return releaseTime;
	}

	public void setReleaseTime(long releaseTime) {
		this.releaseTime = releaseTime;
	}

	public long getPassOverTime() {
		return passOverTime;
	}

	public void setPassOverTime(long passOverTime) {
		this.passOverTime = passOverTime;
	}

	public long getStartUpLossTime() {
		return startUpLossTime;
	}

	public void setStartUpLossTime(long startUpLossTime) {
		this.startUpLossTime = startUpLossTime;
	}

	public long getTau() {
		return tau;
	}

	public void setTau(long tau) {
		this.tau = tau;
	}

	public long getTau0() {
		return tau0;
	}

	public void setTau0(long tau0) {
		this.tau0 = tau0;
	}

	public boolean isReleased() {
		return isReleased;
	}

	public void setReleased(boolean isReleased) {
		this.isReleased = isReleased;
	}

	public boolean isServiced() {
		return isServiced;
	}

	public void setServiced(boolean isServiced) {
		this.isServiced = isServiced;
	}

	private void initialize() {
		trafficLight.setTimeYellow(Math.max(passOverTime, trafficLight.getTimeYellow()));
		tau0 = trafficLight.getTimeYellow() + trafficLight.getTimeIntergreen() + trafficLight.getTimeRedYellow() + startUpLossTime;
		setTimeHorizon(timeHorizon);
	}

	@Override
	public void requestChange(boolean toGreen) {
		if (isServiced != toGreen) {
			if (toGreen) {
				isServiced = true;

				scheduledTasks.add(new DelayedTask(trafficLight.getTimeYellow(), TimeUnit.MILLISECONDS) {

					@Override
					public void run() {
						SelfOrganizingControlLogic.super.requestChange(true);
					}
				});

				scheduledTasks.add(new DelayedTask(tau0, TimeUnit.MILLISECONDS) {
					@Override
					public void run() {
						releaseTime = 0;
						isReleased = true;
					}
				});
			} else {
				tau = tau0;
				isServiced = false;
				super.requestChange(false);
				scheduledTasks.clear();

				// Release state includes passover time
				scheduledTasks.add(new DelayedTask(passOverTime, TimeUnit.MILLISECONDS) {
					@Override
					public void run() {
						endReleasePeriod();
					}
				});
			}
		}
	}

	@Override
	protected void onStrategyUpdate(long dt) {
		tau0 = trafficLight.getTimeYellow() + trafficLight.getTimeIntergreen() + trafficLight.getTimeRedYellow() + startUpLossTime;

		if (isServiced()) {
			tau = Math.max(0l, tau - dt);
			assert tau <= tau0 : "highest value tau should ever have is tau0.";
		}

		if (isReleased) {
			releaseTime += dt;
		}

		double queueLength = queueMonitor.getQueueLength();

		if (!queueMonitor.areVehiclesQueued() && queueLength == 0) {
			adaptivity = tau0;
		} else {
			adaptivity += dt;
		}
	}

	/**
	 * Time required to clear whole queue built up until given time eq 3.20
	 *
	 * @param time
	 * @param tau
	 * @return the clearingTime
	 */
	public double calcClearingTime(long time, long tau) {
		try {
			return clearingTimeCache.get(new long[] { time, tau });
		} catch (ExecutionException e) {
			Logger.logException(e);
		}
		return 0;
	}

	/**
	 * eq 3.37
	 *
	 * @param time
	 * @return
	 */
	private double calcWaitingTimeExp() {
		double y = 0;
		// A -> waitingtime
		double a = queueMonitor.getWaitingTimeSincQueueEmptied();
		long time = getSimualtionTimeInMilliseconds();
		// B -> waiting time clearing eq 3.36
		// double b = queueLog.getIntegral(tLong, tLong + tau);
		double countOut = queueMonitor.getCountOutflow(time);
		double b = 0;
		if (tau > 0) {
			b = integrator.integrate(100, x -> {
				double val = queueMonitor.getCountExpected(Math.round(x)) - countOut;
				return val;
			} , time, time + tau);
		}
		// C -> waiting time while serving eq 3.37
		long c_t0 = time + tau;
		double clTime = calcClearingTime(time, tau);
		long c_t1 = c_t0 + Math.round(clTime);
		double c = 0;
		if (c_t1 > c_t0) {
			c = integrator.integrate(100, x -> {
				long xLong = Math.round(x);
				double val = queueMonitor.getCountExpected(xLong);
				double val2 = queueMonitor.getCountOutflow(time) + (xLong - time - tau) * getQmax();
				return val - val2;
			} , c_t0, c_t1);
		}
		y = a + b + c;
		return Math.max(0, y);
	}

	public double getQueueLengthExpected(long t, long tau_) {
		return calcClearingTime(t, tau_) * getQmax();
	}

	protected void endReleasePeriod() {
		if (!isReleased) {
			releaseTime = 0;
			return;
		}

		// eq 5.2
		long simtime = getSimualtionTimeInMilliseconds();
		double vehiclesPassed = queueMonitor.getCountOutflow(simtime) - queueMonitor.getCountOutflow(simtime - releaseTime);
		double efficency = vehiclesPassed / getQmax();
		efficency = efficency / (tau0 + releaseTime);

		if (efficency > 1) {
			Logger.logWarn("Efficiency > 1 is quite unusual.");
		}

		efficiencyAvg.addValue(efficency);
		isReleased = false;
		releaseTime = 0;
	}

	public double getAverageLoad() {
		return queueMonitor.getAverageLoad();
	}

	public double getClearingTime() {
		long simTime = getSimualtionTimeInMilliseconds();
		Pair<Long, Double> p = cache.getOrDefault(CLEARING_TIME, EMPTY_PAIR);

		if (p.getLeft().equals(simTime)) {
			return p.getRight();
		}

		Pair<Long, Double> newVal = Pair.of(simTime, calcClearingTime(simTime, tau));
		cache.put(CLEARING_TIME, newVal);
		return newVal.getRight();
	}

	/**
	 * eq 5.2
	 */
	public double getEfficiencyAvg() {
		double[] values = efficiencyAvg.getValues();
		double result = 0;
		double n = 0;
		for (double d : values) {
			if (d != 0) {
				result += 1 / d;
				n++;
			}
		}

		result = n / result;
		return Double.isFinite(result) ? result : 0;
	}

	public double getEfficiencyExpected() {
		double y = 0;
		double a = getClearingTime();
		y = a / (a + tau0);
		return y;
	}

	public double getEfficiencyLastService() {
		if (efficiencyAvg.getN() > 0) {
			return efficiencyAvg.getElement((int) (efficiencyAvg.getN() - 1));
		}
		return 0;
	}

	public double getAverageFlow() {
		return queueMonitor.getTrafficFlowTenMinuteAverage();
	}

	public double getQmax() {
		return queueMonitor.getMaxTrafficFlow();
	}

	/**
	 * eq 5.9
	 */
	public double getQueueLengthCritical() {
		return releasePeriod * getAverageFlow();
	}

	/**
	 * eq 5.30
	 *
	 * @param cycleTimeActual
	 * @param cycleTimeMax
	 */
	public double getQueueLengthCriticalTimeDependent(double cycleTimeActual, double cycleTimeMax) {
		double qExpAvg = getAverageFlow();
		double y = qExpAvg * cycleTimeActual;
		double a = adaptivity;
		y = y * (cycleTimeMax - a / (1 - qExpAvg / getQmax()));
		y = y / (cycleTimeMax - cycleTimeActual);
		y = MathUtil.clamp(y, 0, Double.MAX_VALUE);
		return y;
	}

	/**
	 * eq 5.27
	 */
	public double getQueueLengthVirtual() {
		if (queueMonitor.areVehiclesQueued()) {
			return 0;
		}

		double qExpAvg = getAverageFlow();
		double y = getQmax() * qExpAvg;
		y /= getQmax() - qExpAvg;
		y *= tau0;
		return y;
	}

	/**
	 * eq 3.53
	 *
	 */
	public double getSwitchingPenalty() {
		long simTime = getSimualtionTimeInMilliseconds();
		Pair<Long, Double> p = cache.getOrDefault(SWITCHING_PENALTY, EMPTY_PAIR);

		if (p.getLeft().equals(simTime)) {
			return p.getRight();
		}

		long time = simTime;
		double pen = 0;

		/**
		 * eq 3.53
		 */
		if (tau != tau0) {
			UnivariateFunction f = t_ -> {
				return calcClearingTime(time, Math.round(t_)) * getQmax();
			};
			pen = integrator.integrate(100, f, tau, tau0);
			if (pen < 0) {
				pen = 0;
			}
		}

		Pair<Long, Double> newVal = Pair.of(time, pen);
		cache.put(SWITCHING_PENALTY, newVal);
		return pen;
	}

	/**
	 * eq 4.27
	 */
	public double getTauSwitchingPenalty() {
		Pair<Long, Double> p = cache.getOrDefault(TAU_SWITCHING_PENALTY, EMPTY_PAIR);
		if (p.getLeft().equals(getSimualtionTimeInMilliseconds())) {
			return p.getRight();
		}

		long time = getSimualtionTimeInMilliseconds();
		double tauPen = 0;

		if (tau != tau0) {
			double denom = getQueueLengthExpected(time, tau0);
			if (denom != 0) {
				tauPen = getSwitchingPenalty();
				tauPen /= denom;
			}
		}

		tauPen = MathUtil.clamp(tauPen, 0, tau0);
		Pair<Long, Double> newVal = Pair.of(time, tauPen);
		cache.put(TAU_SWITCHING_PENALTY, newVal);
		return tauPen;
	}

	public double getWaitingTimeExp() {
		Pair<Long, Double> p = cache.getOrDefault(WAITING_TIME_EXP, EMPTY_PAIR);

		if (p.getLeft().equals(getSimualtionTimeInMilliseconds())) {
			return p.getRight();
		}

		Pair<Long, Double> newVal = Pair.of(getSimualtionTimeInMilliseconds(), calcWaitingTimeExp());
		cache.put(WAITING_TIME_EXP, newVal);
		return newVal.getRight();
	}

	@Override
	public ControlLogicBean toBean() {
		SelfOrganizingControlLogicBean bean = new SelfOrganizingControlLogicBean();
		bean.setTrafficLightId(trafficLight.getId());
		bean.setTimeHorizon(timeHorizon);
		bean.setPassOverTime(passOverTime);
		bean.setStartUpLossTime(startUpLossTime);
		return bean;
	}

	@Override
	public Map<String, Number> obtainStatistics() {
		Map<String, Number> statistics = super.obtainStatistics();
		statistics.put(IStatsConstants.CONTROL_LOGIC_PRIORITY_INDEX, getPriorityIndex());
		statistics.put(IStatsConstants.CONTROL_LOGIC_CLEARING_TIME, getClearingTime());
		statistics.put(IStatsConstants.CONTROL_LOGIC_TAU_SWITCHING_PENALTY, getTauSwitchingPenalty());
		statistics.put(IStatsConstants.CONTROL_LOGIC_SWITCHING_PENALTY, getSwitchingPenalty());
		statistics.put(IStatsConstants.CONTROL_LOGIC_RELEASE_PERIOD, getReleasePeriod());
		statistics.put(IStatsConstants.CONTROL_LOGIC_WAITING_TIME_EXP, getWaitingTimeExp());
		statistics.put(IStatsConstants.CONTROL_LOGIC_TAU, (double) getTau());
		statistics.put(IStatsConstants.CONTROL_LOGIC_QUEUE_LENGTH_CRITICAL, getQueueLengthCritical());
		statistics.put(IStatsConstants.CONTROL_LOGIC_QUEUE_LENGTH_CRITICAL_TIME_DEPENDENT, queueLengthTimeDependent);
		statistics.put(IStatsConstants.CONTROL_LOGIC_QUEUE_LENGTH_EXP, getQueueLengthExpected(getSimualtionTimeInMilliseconds(), tau));
		statistics.put(IStatsConstants.CONTROL_LOGIC_EFFICIENCY, getEfficiencyAvg());
		statistics.put(IStatsConstants.CONTROL_LOGIC_EFFICIENCY_EXP, getEfficiencyExpected());
		statistics.put(IStatsConstants.CONTROL_LOGIC_EFFICIENCY_LAST_SERVICE, getEfficiencyLastService());
		statistics.put(IStatsConstants.CONTROL_LOGIC_ADAPTIVITY, adaptivity);
		statistics.put(IStatsConstants.CONTROL_LOGIC_RELEASE_STATE, isReleased ? 1d : 0d);
		return statistics;
	}
}

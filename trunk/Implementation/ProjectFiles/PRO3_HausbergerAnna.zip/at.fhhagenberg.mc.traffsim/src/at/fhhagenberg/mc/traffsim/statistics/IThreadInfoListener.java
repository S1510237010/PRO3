package at.fhhagenberg.mc.traffsim.statistics;

public interface IThreadInfoListener {
	public String getPattern();

	public void setCpuTime(double newTime);

	public void resetTime();

	double getCpuTime();
}

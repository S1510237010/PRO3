package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.FixedTimeControlLogicBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

/**
 * Implementation of control logic providing all parameters required to realize a fixed time control scheme (e.g. green and red phase
 * length, phase switching delay, phase offset, current state).
 *
 * @author Manuel Lindorfer
 *
 */
public class FixedTimeControlLogic extends ControlLogic {

	private long delay;
	private long timeGreen;
	private long timeRed;
	private boolean isGreenInitially;
	private boolean isGreen;
	private long offset;
	private long timeEllapsed;

	/**
	 * Creates a new instance of fixed time control logic for the target traffic light using default phase lengths, phase switching delay
	 * and no offset.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 */
	public FixedTimeControlLogic(TrafficLight trafficLight) {
		this(trafficLight, false, PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_DELAY),
				PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_GREEN_TIME),
				PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_RED_TIME));
	}

	/**
	 * Creates a new instance of fixed time control logic for the target traffic light using the given phase lengths, phase switching delay
	 * and no offset.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 * @param isGreenInitially
	 *            flag determining whether the the traffic light starts with a green phase
	 * @param delay
	 *            phase switching delay in milliseconds
	 * @param timeGreen
	 *            duration of green phase in milliseconds
	 * @param timeRed
	 *            duration of red phase in milliseconds
	 */
	public FixedTimeControlLogic(TrafficLight trafficLight, boolean isGreenInitially, long delay, long timeGreen, long timeRed) {
		super(trafficLight);
		this.isGreenInitially = isGreenInitially;
		this.isGreen = isGreenInitially;
		this.delay = delay;
		this.timeGreen = timeGreen;
		this.timeRed = timeRed;
		this.timeEllapsed = 0;
		this.offset = 0;
	}

	/**
	 * Creates a new instance of fixed time control logic for the target traffic light using the given phase lengths, phase switching delay
	 * and offset.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 * @param isGreenInitially
	 *            flag determining whether the the traffic light starts with a green phase
	 * @param delay
	 *            phase switching delay in milliseconds
	 * @param timeGreen
	 *            duration of green phase in milliseconds
	 * @param timeRed
	 *            duration of red phase in milliseconds
	 * @param offset
	 *            the phase offset
	 */
	public FixedTimeControlLogic(TrafficLight trafficLight, boolean isGreenInitially, long delay, long timeGreen, long timeRed, long offset) {
		super(trafficLight);
		this.isGreenInitially = isGreenInitially;
		this.isGreen = isGreenInitially;
		this.delay = delay;
		this.timeGreen = timeGreen;
		this.timeRed = timeRed;
		this.timeEllapsed = 0;
		this.offset = offset;
	}

	/**
	 * Get's the control logic's phase switching delay.
	 *
	 * @return delay in milliseconds
	 */
	public long getDelay() {
		return delay;
	}

	/**
	 * Set's the control logic's phase switching delay.
	 *
	 * @param delay
	 *            delay in milliseconds
	 */
	public void setDelay(long delay) {
		this.delay = delay;
	}

	/**
	 * Get's the control logic's green phase length.
	 *
	 * @return duration in milliseconds
	 */
	public long getTimeGreen() {
		return timeGreen;
	}

	/**
	 * Set's the control logic's green phase length.
	 *
	 * @param timeGreen
	 *            duration in milliseconds
	 */
	public void setTimeGreen(long timeGreen) {
		this.timeGreen = timeGreen;
	}

	/**
	 * Get's the control logic's red phase length.
	 *
	 * @return duration in milliseconds
	 */
	public long getTimeRed() {
		return timeRed;
	}

	/**
	 * Set's the control logic's red phase length.
	 *
	 * @param timeRed
	 *            duration in milliseconds
	 */
	public void setTimeRed(long timeRed) {
		this.timeRed = timeRed;
	}

	/**
	 * Determines whether the traffic light starts with a green phase or not.
	 *
	 * @return true if the traffic light starts with a green phase, false else
	 */
	public boolean isGreenInitially() {
		return isGreenInitially;
	}

	/**
	 * Specifies whether the traffic light starts with a green phase or not.
	 *
	 * @param isGreenInitially
	 *            true if the traffic light should start with a green phase, false else
	 */
	public void setGreenInitially(boolean isGreenInitially) {
		this.isGreenInitially = isGreenInitially;
		this.isGreen = isGreenInitially;
	}

	/**
	 * Determines whether the traffic light is currently in the green phase or not.
	 *
	 * @return true if green, false else
	 */
	public boolean isGreen() {
		return isGreen;
	}

	/**
	 * Specifies whether the traffic light is currently in the green phase or not.
	 *
	 * @param isGreen
	 *            true if green, false else
	 */
	public void setGreen(boolean isGreen) {
		this.isGreen = isGreen;
	}

	/**
	 * Get's the time spent in the current traffic light phase.
	 *
	 * @return duration in milliseconds
	 */
	public long getTimeEllapsed() {
		return timeEllapsed;
	}

	/**
	 * Set's the time spent in the current traffic light phase.
	 *
	 * @param timeEllapsed
	 *            duration in milliseconds
	 */
	public void setTimeEllapsed(long timeEllapsed) {
		this.timeEllapsed = timeEllapsed;
	}

	/**
	 * Get's the phase offset used for scheduling the phase switching.
	 *
	 * @return duration in milliseconds
	 */
	public long getOffset() {
		return offset;
	}

	/**
	 * Set's the phase offset used for scheduling the phase switching.
	 *
	 * @param offset
	 *            duration in milliseconds
	 */
	public void setOffset(long offset) {
		this.offset = offset;
	}

	@Override
	protected void onStrategyUpdate(long dt) {
		timeEllapsed += dt;
	}

	@Override
	public ControlLogicBean toBean() {
		FixedTimeControlLogicBean bean = new FixedTimeControlLogicBean();
		bean.setTrafficLightId(trafficLight.getId());
		bean.setTimeGreen(timeGreen);
		bean.setTimeRed(timeRed);
		bean.setOffset(offset);
		bean.setIsGreenInitially(isGreenInitially);
		bean.setDelay(delay);
		return bean;
	}
}

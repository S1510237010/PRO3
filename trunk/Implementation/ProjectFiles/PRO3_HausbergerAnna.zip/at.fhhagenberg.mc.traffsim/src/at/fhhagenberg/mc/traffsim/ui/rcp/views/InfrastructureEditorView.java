package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.IItemSelectionListener;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector.DetectionMode;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.QueueMonitor;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSign;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSign.Type;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.CyclicController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.FixedTimeController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightControllers;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.CyclicControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.FixedTimeControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.SelfOrganizingControlLogic;
import at.fhhagenberg.mc.traffsim.ui.DrawingPanel;
import at.fhhagenberg.mc.traffsim.ui.IResizeListener;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.CyclicRegulationConfigurationControl;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.FixedTimeRegulationConfigurationControl;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.SelfOrganizingRegulationConfigurationControl;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.TrafficRegulationConfigurationControl;
import at.fhhagenberg.mc.traffsim.ui.rcp.helper.NumberOnlyKeyAdapter;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.exceptions.MergeException;
import at.fhhagenberg.mc.traffsim.util.exceptions.SpatialException;
import at.fhhagenberg.mc.traffsim.util.types.MergeResult;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.StringUtil;

@SuppressWarnings("unchecked")
public class InfrastructureEditorView extends ViewPart implements IResizeListener, IItemSelectionListener, IModelInputChangedListener {

	public static final String ID = "at.fhhagenberg.mc.traffsim.views.infrastructureEditor";
	public static final int TAB_ROAD_SIGNS = 0;
	public static final int TAB_GEOMETRY = 1;
	public static final int TAB_DETECTORS = 2;
	protected static final double ZOOM_FACTOR_STEP = 1.2;
	protected static final String MODE_JUNCTION = "junction";
	protected static final String MODE_ROADSEGMENT = "road_segment";

	// Main controls
	private SashForm sashForm;
	private StackLayout parentStackLayout;
	private Composite tabComposite;
	private Composite tabFolderMain;
	private Combo comboId;
	private DrawingPanel drawingPanel;
	private Button btnJunction;
	private Button btnRoadSegment;
	private Button btnResetZoom;
	private Button btnZoomOut;
	private Button btnZoomIn;

	// Junction controls
	private TabFolder stackJunctionControls;
	protected int selectedJunctionTab = TAB_ROAD_SIGNS;

	// Junction regulation
	private Button btnSelectAllConnectors;
	private Combo comboConnector;
	private Combo comboSignType;
	private Spinner spinnerPriority;
	private Button btnSetRoadSign;
	private Button btnClearAllRoadSigns;
	private Button btClearConnectorRoadSign;

	// Junction traffic lights
	private Button btnIsJunctionSignalControlled;
	private Button btnMergeTrafficLightsPerApproach;
	private Combo comboController;
	private Combo comboTrafficLight;
	private Button btnDeleteTrafficLight;
	private Spinner spinnerYellowTime;
	private Spinner spinnerRedYellowTime;
	private Spinner spinnerIntergreenTime;
	private TrafficLightControllers prevControlMode;
	private TrafficLightControllers currentControlMode;
	private TrafficRegulationConfigurationControl currentConfigurationControl;

	// Junction appearance
	private Combo comboConnFrom;
	private Combo comboConnTo;
	private Spinner spinnerWidthFactor;
	private Spinner spinnerSmoothingDistance;
	private Text textMasterId;
	private Text textSlaveId;
	private Button btnAddConnector;
	private Button btnRemoveConnector;
	private Button btnClearMergeIds;
	private Button btnMergeJunction;
	private Spinner spinnerExtension;
	private Button btnResize;

	// Road segment controls
	private TabFolder stackRoadSegmentControls;
	protected int selectedRoadSegmentTab = TAB_GEOMETRY;

	// Detectors
	private Combo comboDetectors;
	private Spinner spinnerDetectorSampleRate;
	private Spinner spinnerDetectorPosition;
	private Button btnAddDetector;
	private Button btnRemoveDetector;
	private Button btnRemoveAllDetectors;

	// Common
	private SimulationModel currentModel;
	private RoadNetwork currentNetwork;
	private InfrastructureUiModel uiModel = new InfrastructureUiModel(this);
	protected String activeMode = MODE_JUNCTION;

	// Junctions / Connectors
	private Set<JunctionConnector> activeConnectors = new HashSet<>();
	private Map<String, JunctionConnector> connectorMapping = new HashMap<>();
	private Map<String, TrafficLight> trafficLightMapping = new HashMap<>();
	private Map<AbstractJunction, List<Long>> junctionIdMapping = new HashMap<>();
	private Map<TrafficLightControllers, TrafficRegulationConfigurationControl> configurationControlMapping = new HashMap<>();
	private TrafficLight selectedTrafficLight;
	private JunctionConnector selectedConnector;
	private JunctionConnector connToCreate;
	private double widthShrinkFactor;
	protected int smoothingDistance;
	private AbstractJunction selectedJunction;
	private LaneSegment selectedFrom, selectedTo;

	// Road segments
	private RoadSegment selectedRoadSegment;

	// Detectors
	private LoopDetector selectedDetector;
	private Map<String, LoopDetector> roadSegmentDetectorMapping = new HashMap<>();
	private Group grpConfiguration;
	private Composite compositeRegulation;
	private Group grpTrafficLights;
	private GridData configurationGridData;

	public InfrastructureEditorView() {
		SimulationKernel.getInstance().addInputChangedListener(this);
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout(SWT.VERTICAL));
		createMainControls(parent);
		createJunctionControls();
		createRoadSegmentControls();

		initializeItems();
		selectAndSwitch();
	}

	protected void enableJunctionControls(boolean enable) {
		btnSelectAllConnectors.setEnabled(enable);
		btnClearAllRoadSigns.setEnabled(enable);
		btnRemoveConnector.setEnabled(enable);
		btClearConnectorRoadSign.setEnabled(enable);
		btnSetRoadSign.setEnabled(enable);
		btnAddConnector.setEnabled(enable);
		btnClearMergeIds.setEnabled(enable);
		btnMergeJunction.setEnabled(enable);
		btnResize.setEnabled(enable);
		spinnerExtension.setEnabled(enable);
		textMasterId.setEnabled(enable);
		textSlaveId.setEnabled(enable);
		spinnerWidthFactor.setEnabled(enable);
		spinnerSmoothingDistance.setEnabled(enable);
		comboConnFrom.setEnabled(enable);
		comboConnTo.setEnabled(enable);

		comboConnector.setEnabled(enable);
		comboSignType.setEnabled(enable);
		spinnerPriority.setEnabled(enable);

		if (!enable) {
			btnIsJunctionSignalControlled.setEnabled(enable);
			btnMergeTrafficLightsPerApproach.setEnabled(enable);
			btnDeleteTrafficLight.setEnabled(enable);
			comboController.setEnabled(enable);
			comboTrafficLight.setEnabled(enable);
		} else {
			updateTrafficLightProperties();
			updateTrafficLightControlState(false);
		}
	}

	protected void enableRoadSegmentControls(boolean enable) {
		btnAddDetector.setEnabled(enable);
		enableDetectorControls(enable);
	}

	protected void enableDetectorControls(boolean enable) {
		comboDetectors.setEnabled(enable);
		spinnerDetectorSampleRate.setEnabled(enable);
		spinnerDetectorPosition.setEnabled(enable);
	}

	private void createMainControls(Composite parent) {
		tabFolderMain = new Composite(parent, SWT.NONE);
		tabFolderMain.setLayout(new GridLayout(1, false));

		sashForm = new SashForm(tabFolderMain, SWT.NONE);
		sashForm.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		Composite compositeGraphArea = new Composite(sashForm, SWT.BORDER);
		GridLayout gl_compositeGraphArea = new GridLayout(1, false);
		compositeGraphArea.setLayout(gl_compositeGraphArea);

		Composite compositeInfo = new Composite(compositeGraphArea, SWT.NONE);
		compositeInfo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		GridLayout gl_compositeInfo = new GridLayout(3, false);
		gl_compositeInfo.marginHeight = 0;
		compositeInfo.setLayout(gl_compositeInfo);

		Composite compositeTypeSelection = new Composite(compositeInfo, SWT.NONE);
		GridLayout gl_compositeTypeSelection = new GridLayout(2, false);
		gl_compositeTypeSelection.marginWidth = 0;
		gl_compositeTypeSelection.marginHeight = 0;
		compositeTypeSelection.setLayout(gl_compositeTypeSelection);
		compositeTypeSelection.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 3, 1));

		btnJunction = new Button(compositeTypeSelection, SWT.RADIO);
		btnJunction.setSelection(true);
		btnJunction.setBounds(0, 0, 90, 16);
		btnJunction.setText("Junction");
		btnJunction.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnJunction.getSelection()) {
					parentStackLayout.topControl = stackJunctionControls;
					stackJunctionControls.getParent().layout();
					activeMode = MODE_JUNCTION;
					selectedRoadSegment = null;
					selectedJunction = null;
					selectedDetector = null;
					initializeItems();
					selectAndSwitch();
					uiModel.updateView();
				}
			}
		});

		btnRoadSegment = new Button(compositeTypeSelection, SWT.RADIO);
		btnRoadSegment.setBounds(0, 0, 90, 16);
		btnRoadSegment.setText("Road Segment");
		btnRoadSegment.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnRoadSegment.getSelection()) {
					parentStackLayout.topControl = stackRoadSegmentControls;
					stackRoadSegmentControls.getParent().layout();
					activeMode = MODE_ROADSEGMENT;
					selectedRoadSegment = null;
					selectedJunction = null;
					selectedDetector = null;
					initializeItems();
					selectAndSwitch();
					uiModel.updateView();
				}
			}
		});

		Label lblId = new Label(compositeInfo, SWT.NONE);
		lblId.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblId.setText("ID");

		comboId = new Combo(compositeInfo, SWT.READ_ONLY);
		comboId.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectAndSwitch();
				uiModel.updateView();
			}
		});

		comboId.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Composite drawingContainer = new Composite(compositeGraphArea, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		drawingContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));

		drawingPanel = new DrawingPanel();
		drawingPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				uiModel.clickedOn(new Point(e.getX(), e.getY()), 0);
			}
		});

		drawingPanel.addResizeListener(this);

		drawingContainer.setLayout(new FillLayout());
		Frame f = SWT_AWT.new_Frame(drawingContainer);
		Panel rootPane = new Panel();
		rootPane.setLayout(new BorderLayout());
		rootPane.add(drawingPanel);
		f.add(rootPane);

		Composite grpMap = new Composite(compositeGraphArea, SWT.NONE);
		grpMap.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		GridLayout gl_grpMap = new GridLayout(4, true);
		gl_grpMap.horizontalSpacing = 0;
		gl_grpMap.verticalSpacing = 0;
		gl_grpMap.marginWidth = 0;
		gl_grpMap.marginHeight = 0;
		grpMap.setLayout(gl_grpMap);
		grpMap.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, true, false, 1, 1));

		Label lblZoom = new Label(grpMap, SWT.NONE);
		lblZoom.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		lblZoom.setText("Zoom");

		btnZoomIn = new Button(grpMap, SWT.NONE);
		btnZoomIn.setText("+");
		btnZoomIn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnZoomIn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				uiModel.zoom(ZOOM_FACTOR_STEP);
			}
		});

		btnZoomOut = new Button(grpMap, SWT.NONE);
		btnZoomOut.setText("-");
		btnZoomOut.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnZoomOut.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				uiModel.zoom(1 / ZOOM_FACTOR_STEP);
			}
		});

		btnResetZoom = new Button(grpMap, SWT.NONE);
		btnResetZoom.setText("Reset");
		btnResetZoom.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (activeMode == MODE_JUNCTION) {
					uiModel.updateActiveJunction(selectedJunction);
				} else {
					uiModel.updateActiveRoadSegment(selectedRoadSegment);
				}
			}
		});

		GridData gd_btnReset = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_btnReset.horizontalIndent = 10;
		btnResetZoom.setLayoutData(gd_btnReset);

		tabComposite = new Composite(sashForm, SWT.NONE);
		parentStackLayout = new StackLayout();
		tabComposite.setLayout(parentStackLayout);
		sashForm.setWeights(new int[] { 1, 1 });
	}

	private void createJunctionControls() {
		stackJunctionControls = new TabFolder(tabComposite, SWT.NONE);
		stackJunctionControls.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				activeConnectors.clear();
				selectedJunctionTab = stackJunctionControls.getSelectionIndex();

				if (selectedJunctionTab == TAB_GEOMETRY) {
					btnSelectAllConnectors.setSelection(false);
				} else if (selectedJunctionTab == TAB_ROAD_SIGNS) {
					if (connectorMapping != null && comboConnector != null && !StringUtil.isNullOrEmpty(comboConnector.getText())) {
						refreshSignCombo(connectorMapping.get(comboConnector.getText()));
					}
				}

				uiModel.updateView(true);
			}
		});

		stackJunctionControls.setLayout(new GridLayout(1, false));
		parentStackLayout.topControl = stackJunctionControls;

		createJunctionRegulationControls();
		createJunctionAppearanceControls();
	}

	private void createJunctionRegulationControls() {
		TabItem tbtmRoadSigns = new TabItem(stackJunctionControls, SWT.NONE);
		tbtmRoadSigns.setText("Regulation");

		compositeRegulation = new Composite(stackJunctionControls, SWT.NONE);
		tbtmRoadSigns.setControl(compositeRegulation);
		compositeRegulation.setLayout(new GridLayout(1, false));
		new Label(compositeRegulation, SWT.NONE);

		Group grpRoadSigns = new Group(compositeRegulation, SWT.NONE);
		grpRoadSigns.setLayout(new GridLayout(3, false));
		grpRoadSigns.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpRoadSigns.setText("Road Signs");

		btnSelectAllConnectors = new Button(grpRoadSigns, SWT.CHECK);
		btnSelectAllConnectors.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 3, 1));
		btnSelectAllConnectors.setText("Select all connectors of entry");
		btnSelectAllConnectors.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (connectorMapping != null && comboConnector != null && !StringUtil.isNullOrEmpty(comboConnector.getText())) {
					refreshSignCombo(connectorMapping.get(comboConnector.getText()));
				}
			}
		});

		Label lblConnector = new Label(grpRoadSigns, SWT.NONE);
		lblConnector.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblConnector.setText("Connector");

		comboConnector = new Combo(grpRoadSigns, SWT.READ_ONLY);
		comboConnector.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				refreshSignCombo(connectorMapping.get(comboConnector.getText()));
			}
		});

		comboConnector.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		Label lblSign = new Label(grpRoadSigns, SWT.NONE);
		lblSign.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblSign.setText("Sign");

		comboSignType = new Combo(grpRoadSigns, SWT.READ_ONLY);
		comboSignType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				spinnerPriority.setSelection(RoadSign.getPriority(Type.valueOf(comboSignType.getText())));
			}

		});

		comboSignType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		Label lblPriority = new Label(grpRoadSigns, SWT.NONE);
		lblPriority.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblPriority.setText("Priority");

		spinnerPriority = new Spinner(grpRoadSigns, SWT.BORDER);
		spinnerPriority.setToolTipText("Choose from -100 to 100");
		spinnerPriority.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		spinnerPriority.setMinimum(-100);

		Composite compositeSignAddRemove = new Composite(grpRoadSigns, SWT.NONE);
		compositeSignAddRemove.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, true, false, 3, 1));
		compositeSignAddRemove.setLayout(new GridLayout(3, true));

		btnClearAllRoadSigns = new Button(compositeSignAddRemove, SWT.NONE);
		btnClearAllRoadSigns.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				for (JunctionConnector conn : selectedJunction.getConnectors()) {
					conn.resetPriority();
				}

				uiModel.updateView(false);
			}
		});

		btnClearAllRoadSigns.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnClearAllRoadSigns.setText("Clear All Signs");

		btClearConnectorRoadSign = new Button(compositeSignAddRemove, SWT.NONE);
		btClearConnectorRoadSign.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				for (JunctionConnector conn : activeConnectors) {
					conn.resetPriority();
				}

				uiModel.updateView(false);
			}
		});

		btClearConnectorRoadSign.setText("Remove Conn. Signs");

		btnSetRoadSign = new Button(compositeSignAddRemove, SWT.NONE);
		btnSetRoadSign.setToolTipText("Apply current selection");
		btnSetRoadSign.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (!activeConnectors.isEmpty()) {
					Type toAdd = (comboSignType.getText().isEmpty() ? Type.NONE : RoadSign.Type.valueOf(comboSignType.getText()));
					addRoadSign(toAdd);
					connectorMapping.get(comboConnector.getText()).setPriority(spinnerPriority.getSelection());
				}
			}
		});

		btnSetRoadSign.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnSetRoadSign.setText("Set Road Sign");

		grpTrafficLights = new Group(compositeRegulation, SWT.NONE);
		grpTrafficLights.setLayout(new GridLayout(3, false));
		grpTrafficLights.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpTrafficLights.setText("Traffic Lights");

		btnIsJunctionSignalControlled = new Button(grpTrafficLights, SWT.CHECK);
		btnIsJunctionSignalControlled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 3, 1));
		btnIsJunctionSignalControlled.setText("Junction is signal-controlled");
		btnIsJunctionSignalControlled.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateJunctionSignalControls();
				updateTrafficLightProperties();
				updateTrafficLightControlState(false);
			}
		});

		btnMergeTrafficLightsPerApproach = new Button(grpTrafficLights, SWT.CHECK);
		btnMergeTrafficLightsPerApproach.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 3, 1));
		btnMergeTrafficLightsPerApproach.setText("Merge traffic lights per approach");
		btnMergeTrafficLightsPerApproach.setToolTipText("Traffic lights in the same approach are operated simultaneoulsy");
		btnMergeTrafficLightsPerApproach.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateJunctionSignalControls();
				updateTrafficLightProperties();
				updateTrafficLightControlState(false);
			}
		});

		Label lblController = new Label(grpTrafficLights, SWT.NONE);
		lblController.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblController.setText("Control Strategy");

		comboController = new Combo(grpTrafficLights, SWT.READ_ONLY);
		comboController.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				prevControlMode = currentControlMode;

				if (comboController.getText().compareTo(TrafficLightControllers.CYCLIC.toString()) == 0) {
					currentControlMode = TrafficLightControllers.CYCLIC;
				} else if (comboController.getText().compareTo(TrafficLightControllers.FIXED_TIMED.toString()) == 0) {
					currentControlMode = TrafficLightControllers.FIXED_TIMED;
				} else {
					currentControlMode = TrafficLightControllers.SELF_ORGANIZING;
				}

				updateJunctionSignalControls();
				updateTrafficLightProperties();
				updateTrafficLightControlState(true);
			}
		});

		comboController.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		Label lblTrafficLight = new Label(grpTrafficLights, SWT.NONE);
		lblTrafficLight.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblTrafficLight.setText("Traffic Light");

		comboTrafficLight = new Combo(grpTrafficLights, SWT.READ_ONLY);
		comboTrafficLight.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateTrafficLightProperties();

				if (currentConfigurationControl != null) {
					if (selectedJunction != null) {
						currentConfigurationControl.update(selectedJunction.getControlLogicForTrafficLight(selectedTrafficLight),
								selectedJunction.getTrafficLightController());
					} else {
						currentConfigurationControl.update(null, null);
					}
				}
			}
		});

		comboTrafficLight.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btnDeleteTrafficLight = new Button(grpTrafficLights, SWT.NONE);
		btnDeleteTrafficLight.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		btnDeleteTrafficLight.setText("Delete");
		btnDeleteTrafficLight.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (selectedTrafficLight != null && selectedJunction != null) {
					selectedJunction.removeTrafficLight(selectedTrafficLight);
					currentNetwork.removeTrafficLight(selectedTrafficLight);
					trafficLightMapping.remove(comboTrafficLight.getText());
					comboTrafficLight.remove(comboTrafficLight.getSelectionIndex());

					if (comboTrafficLight.getItemCount() > 0) {
						comboTrafficLight.select(0);
					}

					// All traffic lights have been removed
					if (selectedJunction.getTrafficLightController() == null) {
						btnIsJunctionSignalControlled.setSelection(false);
					}

					updateTrafficLightProperties();
					updateTrafficLightControlState(false);

					uiModel.updateView();
				}
			}
		});

		new Label(grpTrafficLights, SWT.NONE);
		Label trafficLightIntegreenLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightIntegreenLabel.setText("Intergreen time [s]");
		trafficLightIntegreenLabel.setToolTipText("Delay when traffic light switches from the red to red-yellow phase");
		spinnerIntergreenTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerIntergreenTime.setDigits(3);
		spinnerIntergreenTime.setMaximum(10000);
		spinnerIntergreenTime.setMinimum(1000);
		spinnerIntergreenTime.setPageIncrement(1000);
		spinnerIntergreenTime.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateTrafficLight();
			}
		});

		new Label(grpTrafficLights, SWT.NONE);
		Label trafficLightYellowLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightYellowLabel.setText("Yellow time [s]");
		trafficLightYellowLabel.setToolTipText("Duration of the traffic light's yellow phase");
		spinnerYellowTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerYellowTime.setDigits(3);
		spinnerYellowTime.setMaximum(10000);
		spinnerYellowTime.setMinimum(1000);
		spinnerYellowTime.setPageIncrement(1000);
		spinnerYellowTime.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateTrafficLight();
			}
		});

		new Label(grpTrafficLights, SWT.NONE);
		Label trafficLightRedYellowLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightRedYellowLabel.setText("Red-yellow time [s]");
		trafficLightRedYellowLabel.setToolTipText("Duration of the traffic light's red-yellow phase");
		spinnerRedYellowTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerRedYellowTime.setDigits(3);
		spinnerRedYellowTime.setMaximum(10000);
		spinnerRedYellowTime.setMinimum(1000);
		spinnerRedYellowTime.setPageIncrement(1000);
		spinnerRedYellowTime.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateTrafficLight();
			}
		});

		grpConfiguration = new Group(grpTrafficLights, SWT.NONE);
		grpConfiguration.setLayout(new GridLayout(2, false));
		configurationGridData = new GridData(SWT.FILL, SWT.FILL, true, false, 3, 1);
		grpConfiguration.setLayoutData(configurationGridData);
		grpConfiguration.setText("Configuration");

		// Initialize dynamic configuration controls
		CyclicRegulationConfigurationControl cyclicConfigurationControl = new CyclicRegulationConfigurationControl(grpConfiguration, SWT.NONE);
		cyclicConfigurationControl.setVisible(false);
		cyclicConfigurationControl.hide();

		FixedTimeRegulationConfigurationControl fixedTimeConfigurationControl = new FixedTimeRegulationConfigurationControl(grpConfiguration,
				SWT.NONE);
		fixedTimeConfigurationControl.setVisible(false);
		fixedTimeConfigurationControl.hide();

		SelfOrganizingRegulationConfigurationControl selfOrganizingConfigurationControl = new SelfOrganizingRegulationConfigurationControl(
				grpConfiguration, SWT.NONE);
		selfOrganizingConfigurationControl.setVisible(false);
		selfOrganizingConfigurationControl.hide();

		configurationControlMapping.put(TrafficLightControllers.CYCLIC, cyclicConfigurationControl);
		configurationControlMapping.put(TrafficLightControllers.FIXED_TIMED, fixedTimeConfigurationControl);
		configurationControlMapping.put(TrafficLightControllers.SELF_ORGANIZING, selfOrganizingConfigurationControl);
	}

	private void updateTrafficLight() {
		if (selectedTrafficLight != null) {
			selectedTrafficLight.setTimeIntergreen(spinnerIntergreenTime.getSelection());
			selectedTrafficLight.setTimeYellow(spinnerYellowTime.getSelection());
			selectedTrafficLight.setTimeRedYellow(spinnerRedYellowTime.getSelection());
		}
	}

	private void updateJunctionSignalControls() {
		if (selectedJunction == null) {
			return;
		}

		if (btnIsJunctionSignalControlled.getSelection()) {
			// Add signal control
			selectedJunction.setType(NodeType.TRAFFIC_LIGHT);
			currentNetwork.removeTrafficLightsForJunction(selectedJunction);
			selectedJunction.removeTrafficLightController();

			comboTrafficLight.removeAll();
			trafficLightMapping.clear();

			// Add traffic lights and control logics to all approaches per default
			if (btnMergeTrafficLightsPerApproach.getSelection()) {
				addTrafficLightsPerApproach(currentControlMode);
			} else {
				addTrafficLightsIndividually(currentControlMode);
			}

			if (comboTrafficLight.getItemCount() > 0) {
				comboTrafficLight.select(0);
			}

			TrafficLightController<?> controller;

			// Create traffic controller
			if (currentControlMode == TrafficLightControllers.CYCLIC) {
				controller = new CyclicController(TrafficLightController.NEXT_ID, selectedJunction, false);
			} else if (currentControlMode == TrafficLightControllers.FIXED_TIMED) {
				controller = new FixedTimeController(TrafficLightController.NEXT_ID, selectedJunction);
			} else {
				controller = new SelfOrganizingController(TrafficLightController.NEXT_ID, selectedJunction);

				for (JunctionApproach approach : selectedJunction.getApproaches()) {
					QueueMonitor queueMonitor = approach.getQueueMonitor();
					currentNetwork.addDetector(queueMonitor.getStopLineDetector());
					currentNetwork.addDetector(queueMonitor.getUpstreamDetector());
				}
			}

			controller.setAreLanesOperatedIndividually(!btnMergeTrafficLightsPerApproach.getSelection());
			selectedJunction.setTrafficLightController(controller);
		} else {
			// Remove all signalling controls
			selectedJunction.setType(NodeType.SIMPLE);
			currentNetwork.removeTrafficLightsForJunction(selectedJunction);
			selectedJunction.removeTrafficLightController();
		}

		uiModel.updateView();
	}

	private void addTrafficLightToConnectors(JunctionApproach approach, List<JunctionConnector> connectors, TrafficLightControllers controlMode,
			long id) {
		TrafficLight tl = new TrafficLight(id, connectors.stream().map(c -> c.getId()).collect(Collectors.toList()));

		for (JunctionConnector c : connectors) {
			c.setTrafficLight(tl);
		}

		approach.addTrafficLight(tl);

		ControlLogic controlLogic;

		// Add corresponding control logic
		if (controlMode == TrafficLightControllers.CYCLIC) {
			controlLogic = new CyclicControlLogic(tl);
		} else if (controlMode == TrafficLightControllers.FIXED_TIMED) {
			controlLogic = new FixedTimeControlLogic(tl);
		} else {
			controlLogic = new SelfOrganizingControlLogic(tl, approach.getQueueMonitor(),
					PreferenceUtil.getInt(IPreferenceConstants.QUEUE_MONITORING_TIME_HORIZON_S) * 1000);
		}

		approach.addControlLogicFor(tl, controlLogic);
		comboTrafficLight.add(String.valueOf(tl.getId()));
		trafficLightMapping.put(String.valueOf(tl.getId()), tl);
		addJunctionIdMapping(selectedJunction, tl.getId());
		currentNetwork.addTrafficLight(tl);
	}

	private void addTrafficLightsPerApproach(TrafficLightControllers controlMode) {

		int idx = 0;

		for (JunctionApproach approach : selectedJunction.getApproaches()) {
			List<JunctionConnector> approachConnectors = approach.getConnectors();

			long id = 0;

			if (junctionIdMapping.containsKey(selectedJunction) && junctionIdMapping.get(selectedJunction).size() - 1 >= idx) {
				id = junctionIdMapping.get(selectedJunction).get(idx);
			} else {
				id = TrafficLight.NEXT_ID++;
			}

			addTrafficLightToConnectors(approach, approachConnectors, controlMode, id);
			idx++;
		}
	}

	private void addTrafficLightsIndividually(TrafficLightControllers controlMode) {

		int idx = 0;

		for (JunctionApproach approach : selectedJunction.getApproaches()) {
			Map<Integer, List<JunctionConnector>> approachConnectors = approach.getConnectors().stream()
					.collect(Collectors.groupingBy(JunctionConnector::getLane));

			List<Integer> keys = new ArrayList<>();
			keys.addAll(approachConnectors.keySet());
			Collections.sort(keys);

			for (int lane : keys) {
				List<JunctionConnector> con = approachConnectors.get(lane);

				long id = 0;

				if (junctionIdMapping.containsKey(selectedJunction) && junctionIdMapping.get(selectedJunction).size() - 1 >= idx) {
					id = junctionIdMapping.get(selectedJunction).get(idx);
				} else {
					id = TrafficLight.NEXT_ID++;
				}

				addTrafficLightToConnectors(approach, con, controlMode, id);
				idx++;
			}
		}
	}

	private void updateTrafficLightProperties() {
		if (comboTrafficLight.getItemCount() > 0 && trafficLightMapping.containsKey(comboTrafficLight.getText())) {
			selectedTrafficLight = trafficLightMapping.get(comboTrafficLight.getText());
		} else {
			selectedTrafficLight = null;
		}

		if (selectedTrafficLight != null) {
			spinnerIntergreenTime.setSelection((int) selectedTrafficLight.getTimeIntergreen());
			spinnerYellowTime.setSelection((int) selectedTrafficLight.getTimeYellow());
			spinnerRedYellowTime.setSelection((int) selectedTrafficLight.getTimeRedYellow());
		} else {
			spinnerIntergreenTime.setSelection(0);
			spinnerYellowTime.setSelection(0);
			spinnerRedYellowTime.setSelection(0);
		}

		uiModel.updateView();
	}

	private void updateTrafficLightControlState(boolean relayout) {
		boolean isJunctionSignalControlled = btnIsJunctionSignalControlled.getSelection();
		comboTrafficLight.setEnabled(isJunctionSignalControlled);
		comboController.setEnabled(isJunctionSignalControlled);

		if (!isJunctionSignalControlled) {
			btnMergeTrafficLightsPerApproach.setSelection(false);
		}

		if (selectedTrafficLight != null) {
			spinnerIntergreenTime.setEnabled(isJunctionSignalControlled);
			spinnerYellowTime.setEnabled(isJunctionSignalControlled);
			spinnerRedYellowTime.setEnabled(isJunctionSignalControlled);
		} else {
			spinnerIntergreenTime.setEnabled(false);
			spinnerYellowTime.setEnabled(false);
			spinnerRedYellowTime.setEnabled(false);
		}

		if (!spinnerIntergreenTime.isEnabled()) {
			spinnerIntergreenTime.setSelection(0);
			spinnerYellowTime.setSelection(0);
			spinnerRedYellowTime.setSelection(0);
		}

		btnMergeTrafficLightsPerApproach.setEnabled(isJunctionSignalControlled);
		btnDeleteTrafficLight
				.setEnabled(isJunctionSignalControlled && selectedTrafficLight != null && btnMergeTrafficLightsPerApproach.getSelection());

		// Update the currently displayed configuration control
		if (prevControlMode != currentControlMode) {
			if (currentConfigurationControl != null) {
				currentConfigurationControl.hide();
				currentConfigurationControl.setVisible(false);
			}

			currentConfigurationControl = configurationControlMapping.get(currentControlMode);
			currentConfigurationControl.show();
			currentConfigurationControl.setVisible(true);

			if (currentConfigurationControl != null) {
				if (selectedJunction != null) {
					currentConfigurationControl.update(selectedJunction.getControlLogicForTrafficLight(selectedTrafficLight),
							selectedJunction.getTrafficLightController());
				} else {
					currentConfigurationControl.update(null, null);
				}
			}

			prevControlMode = currentControlMode;
			relayout = true;
		}

		if (currentConfigurationControl != null) {
			if (selectedJunction != null) {
				currentConfigurationControl.update(selectedJunction.getControlLogicForTrafficLight(selectedTrafficLight),
						selectedJunction.getTrafficLightController());
			} else {
				currentConfigurationControl.update(null, null);
			}
		}

		// Show / hide configuration controls
		if (isJunctionSignalControlled != grpConfiguration.isVisible() || relayout) {
			grpConfiguration.setVisible(isJunctionSignalControlled);
			configurationGridData.exclude = !isJunctionSignalControlled;
			grpTrafficLights.pack();
		}
	}

	private void createJunctionAppearanceControls() {
		TabItem tbtmJunctionAppearance = new TabItem(stackJunctionControls, SWT.NONE);
		tbtmJunctionAppearance.setText("Appearance");

		Composite compositeGeometry = new Composite(stackJunctionControls, SWT.NONE);
		tbtmJunctionAppearance.setControl(compositeGeometry);
		compositeGeometry.setLayout(new GridLayout(1, false));

		Group grpConnector = new Group(compositeGeometry, SWT.NONE);
		grpConnector.setLayout(new GridLayout(3, false));
		grpConnector.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpConnector.setText("Connector");

		Label lblFrom = new Label(grpConnector, SWT.NONE);
		lblFrom.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFrom.setText("from");

		comboConnFrom = new Combo(grpConnector, SWT.READ_ONLY);
		comboConnFrom.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		Label lblTo = new Label(grpConnector, SWT.NONE);
		lblTo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTo.setText("to");

		comboConnTo = new Combo(grpConnector, SWT.READ_ONLY);
		comboConnTo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		Label lblWidth = new Label(grpConnector, SWT.NONE);
		lblWidth.setText("Width");

		spinnerWidthFactor = new Spinner(grpConnector, SWT.BORDER);
		spinnerWidthFactor.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerWidthFactor.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				widthShrinkFactor = ((double) spinnerWidthFactor.getSelection()) / 100;
				updateConnToCreate();
			}
		});
		spinnerWidthFactor.setMaximum(150);
		spinnerWidthFactor.setMinimum(70);
		spinnerWidthFactor.setSelection(97);
		spinnerWidthFactor.setDigits(2);

		Label lblwidthFactor = new Label(grpConnector, SWT.NONE);
		lblwidthFactor.setText("(width factor in relation to lane width)");

		Label lblSmoothing = new Label(grpConnector, SWT.NONE);
		lblSmoothing.setText("Smoothing");

		spinnerSmoothingDistance = new Spinner(grpConnector, SWT.BORDER);
		spinnerSmoothingDistance.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				smoothingDistance = spinnerSmoothingDistance.getSelection();
				updateConnToCreate();
			}
		});
		spinnerSmoothingDistance.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerSmoothingDistance.setMaximum(5000);
		spinnerSmoothingDistance.setMinimum(1);
		spinnerSmoothingDistance.setSelection(200);

		Label lbldistanceForPoint = new Label(grpConnector, SWT.NONE);
		lbldistanceForPoint.setText("(lower values lead to sharper start/end of connector)");

		Composite compositeConnectorControls = new Composite(grpConnector, SWT.NONE);
		compositeConnectorControls.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 3, 1));
		GridLayout gl_compositeConnectorControls = new GridLayout(2, true);
		gl_compositeConnectorControls.marginWidth = 0;
		compositeConnectorControls.setLayout(gl_compositeConnectorControls);

		btnAddConnector = new Button(compositeConnectorControls, SWT.NONE);
		btnAddConnector.setText("Add");
		btnAddConnector.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (selectedJunction.getConnector(selectedFrom, selectedTo) != null) {
					MessageDialog.openWarning(getDisplay().getActiveShell(), "Duplicate connector", "Connector already exists in this junction!");
				} else {
					selectedJunction.addConnector(connToCreate);
					uiModel.updateView();
				}
			}
		});

		GridData gd_btnAdd = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_btnAdd.widthHint = 100;
		btnAddConnector.setLayoutData(gd_btnAdd);
		btnAddConnector.setBounds(0, 0, 75, 25);

		btnRemoveConnector = new Button(compositeConnectorControls, SWT.NONE);
		btnRemoveConnector.setText("Remove");
		btnRemoveConnector.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnRemoveConnector.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				JunctionConnector foundConn = selectedJunction.getConnector(selectedFrom, selectedTo);
				if (foundConn != null) {
					selectedJunction.removeConnector(foundConn);
					activeConnectors.clear();
					uiModel.updateView();
				} else {
					MessageDialog.openWarning(getDisplay().getActiveShell(), "Not found", "Connector does not exist in this junction!");
				}
			}
		});

		Group grpMerge = new Group(compositeGeometry, SWT.NONE);
		grpMerge.setLayout(new GridLayout(3, false));
		grpMerge.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpMerge.setText("Junction Merge");

		Label lblMaster = new Label(grpMerge, SWT.NONE);
		lblMaster.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMaster.setText("Master");

		textMasterId = new Text(grpMerge, SWT.BORDER);
		textMasterId.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		textMasterId.addKeyListener(new NumberOnlyKeyAdapter() {
			@Override
			public Display getCurrentDisplay() {
				return getDisplay();
			}
		});

		Label lblSlave = new Label(grpMerge, SWT.NONE);
		lblSlave.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblSlave.setText("Slave");

		textSlaveId = new Text(grpMerge, SWT.BORDER);
		textSlaveId.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		textSlaveId.addKeyListener(new NumberOnlyKeyAdapter() {
			@Override
			public Display getCurrentDisplay() {
				return getDisplay();
			}
		});

		Composite composite_2 = new Composite(grpMerge, SWT.NONE);
		composite_2.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 3, 1));
		GridLayout gl_composite_2 = new GridLayout(2, true);
		gl_composite_2.marginWidth = 0;
		gl_composite_2.verticalSpacing = 0;
		gl_composite_2.marginHeight = 0;
		composite_2.setLayout(gl_composite_2);

		btnClearMergeIds = new Button(composite_2, SWT.NONE);
		btnClearMergeIds.setText("Clear IDs");
		btnClearMergeIds.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				getDisplay().asyncExec(new Runnable() {
					@Override
					public void run() {
						textMasterId.setText("");
						textSlaveId.setText("");

					}
				});
			}
		});
		GridData gd_btnClearIds = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_btnClearIds.widthHint = 100;
		btnClearMergeIds.setLayoutData(gd_btnClearIds);

		btnMergeJunction = new Button(composite_2, SWT.NONE);
		btnMergeJunction.setText("Merge");
		btnMergeJunction.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnMergeJunction.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				RoadNetwork network = SimulationKernel.getInstance().getActiveModel().getNetwork();
				AbstractJunction junc1 = network.getJunctionByKey(Long.parseLong(textMasterId.getText()));
				AbstractJunction junc2 = network.getJunctionByKey(Long.parseLong(textSlaveId.getText()));
				try {
					MergeResult result = SpatialUtil.merge(junc1, junc2);
					network.removeJunction(junc2);
					for (RoadSegment rs : result.getRemovedRoadSegments()) {
						network.removeRoadSegment(rs);
						SimulationKernel.getInstance().getActiveModel().addRemovedRoutingId(rs.getRoutingId());
						getDrawingPanel().updateUI();
						SimulationKernel.getInstance().getActiveModel().getUiModel().clearDrawingCaches();
						SimulationKernel.getInstance().getActiveModel().getUiModel().updateView(true);
						setSelectedJunction(junc1);
					}
				} catch (MergeException e1) {
					e1.printStackTrace();
				}
			}
		});

		Group grpResize = new Group(compositeGeometry, SWT.NONE);
		grpResize.setLayout(new GridLayout(4, false));
		grpResize.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		grpResize.setText("Resize");

		Label lblDifferenceInMeters = new Label(grpResize, SWT.NONE);
		lblDifferenceInMeters.setText("Extension");

		spinnerExtension = new Spinner(grpResize, SWT.BORDER);
		spinnerExtension.setDigits(1);
		GridData gd_spinnerDifference = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_spinnerDifference.widthHint = 50;
		spinnerExtension.setLayoutData(gd_spinnerDifference);

		Label lblM = new Label(grpResize, SWT.NONE);
		lblM.setText("m     ");

		btnResize = new Button(grpResize, SWT.NONE);
		btnResize.setText("Resize");
		btnResize.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// reset road segments
				for (RoadSegment rs : selectedJunction.getAllSegments()) {
					rs.getRoadGeometry().resetToOriginalPoints();
					rs.updateLaneGeometries();
				}
				try {
					selectedJunction.initializeInterior(null, ((double) spinnerExtension.getSelection()) / 10);
				} catch (Exception e1) {
					MessageDialog.openError(Display.getDefault().getActiveShell(), "Initialization failure",
							"Cannot initialize junction " + selectedJunction.getId() + "\n\n" + e1.getMessage());

				}
				uiModel.updateView();
			}
		});

		GridData gd_btnResize = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnResize.widthHint = 100;
		btnResize.setLayoutData(gd_btnResize);
	}

	private void createRoadSegmentControls() {
		stackRoadSegmentControls = new TabFolder(tabComposite, SWT.NONE);
		stackRoadSegmentControls.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectedRoadSegmentTab = stackRoadSegmentControls.getSelectionIndex();
				uiModel.updateView(true);
			}
		});

		createDetectorControls();
	}

	private void createDetectorControls() {
		TabItem tbRoadSegmentDetectors = new TabItem(stackRoadSegmentControls, SWT.NONE);
		tbRoadSegmentDetectors.setText("Detectors");

		Composite rsDetectorsComposite = new Composite(stackRoadSegmentControls, SWT.NONE);
		tbRoadSegmentDetectors.setControl(rsDetectorsComposite);
		GridLayout layoutComposite = new GridLayout(1, false);
		layoutComposite.marginWidth = 0;
		layoutComposite.marginHeight = 0;
		rsDetectorsComposite.setLayout(layoutComposite);
		Group grpRoadSegmentDetectors = new Group(rsDetectorsComposite, SWT.NONE);
		grpRoadSegmentDetectors.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpRoadSegmentDetectors.setText("Detectors");
		grpRoadSegmentDetectors.setLayout(new GridLayout(2, false));

		Label lblRoadSegmentDetectors = new Label(grpRoadSegmentDetectors, SWT.NONE);
		lblRoadSegmentDetectors.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRoadSegmentDetectors.setText("Detectors");

		comboDetectors = new Combo(grpRoadSegmentDetectors, SWT.READ_ONLY);
		comboDetectors.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		comboDetectors.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setSelectedDetector(roadSegmentDetectorMapping.get(comboDetectors.getText()));
			}
		});

		Composite compositeControls = new Composite(grpRoadSegmentDetectors, SWT.NONE);
		compositeControls.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, true, false, 2, 1));
		compositeControls.setLayout(new GridLayout(3, true));

		btnAddDetector = new Button(compositeControls, SWT.NONE);
		btnAddDetector.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnAddDetector.setText("+");
		btnAddDetector.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (selectedRoadSegment != null) {
					LoopDetector newDetector = new LoopDetector(LoopDetector.NEXT_DETECTOR_ID++, selectedRoadSegment, 0d,
							PreferenceUtil.getInt(IPreferenceConstants.LOOP_DETECTOR_SAMPLE_INTERVAL), DetectionMode.DUAL);

					List<Vector> absoluteDetectorPositions = new ArrayList<>();

					for (LaneSegment lane : selectedRoadSegment.getLaneSegments()) {
						absoluteDetectorPositions.add(lane.getRoadGeometry().mapPosition(0));
					}

					newDetector.setAbsolutePositions(absoluteDetectorPositions);
					comboDetectors.add(String.valueOf(newDetector.getIdentifier()));
					roadSegmentDetectorMapping.put(String.valueOf(newDetector.getIdentifier()), newDetector);
					setSelectedDetector(newDetector);
					comboDetectors.setText(String.valueOf(newDetector.getIdentifier()));
					currentNetwork.addDetector(newDetector);
					spinnerDetectorPosition
							.setMaximum((int) (selectedRoadSegment.getMinLaneLength() * Math.pow(10, spinnerDetectorPosition.getDigits())));
					enableDetectorControls(true);
				}
			}
		});

		btnRemoveDetector = new Button(compositeControls, SWT.NONE);
		btnRemoveDetector.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnRemoveDetector.setText("-");
		btnRemoveDetector.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (selectedDetector != null) {
					long detectorId = selectedDetector.getIdentifier();
					int selectionIndex = comboDetectors.getSelectionIndex();
					comboDetectors.remove(String.valueOf(detectorId));
					roadSegmentDetectorMapping.remove(String.valueOf(detectorId));

					if (comboDetectors.getItemCount() > 0) {
						if (selectionIndex == 0) {
							comboDetectors.select(0);
						} else {
							comboDetectors.select(selectionIndex - 1);
						}

						setSelectedDetector(roadSegmentDetectorMapping.get(comboDetectors.getText()));
					} else {
						setSelectedDetector(null);
						enableDetectorControls(false);
					}

					currentNetwork.removeDetector(detectorId);
				}
			}
		});

		btnRemoveAllDetectors = new Button(compositeControls, SWT.NONE);
		btnRemoveAllDetectors.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnRemoveAllDetectors.setText("Clear");
		btnRemoveAllDetectors.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (selectedRoadSegment != null) {
					comboDetectors.removeAll();
					roadSegmentDetectorMapping.clear();
					setSelectedDetector(null);
					enableDetectorControls(false);
					currentNetwork.removeAllDetectorsForRoadSegment(selectedRoadSegment.getId());
				}
			}
		});

		new Label(grpRoadSegmentDetectors, SWT.NONE);
		new Label(grpRoadSegmentDetectors, SWT.NONE);

		Label lblSampleRate = new Label(grpRoadSegmentDetectors, SWT.NONE);
		lblSampleRate.setText("Sampling rate [s]");

		spinnerDetectorSampleRate = new Spinner(grpRoadSegmentDetectors, SWT.BORDER);
		spinnerDetectorSampleRate.setToolTipText("Configure the detector's sampling rate");
		spinnerDetectorSampleRate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerDetectorSampleRate.setMaximum(3600);
		spinnerDetectorSampleRate.setMinimum(1);

		spinnerDetectorSampleRate.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (selectedDetector != null) {
					selectedDetector.setSampleInterval(spinnerDetectorSampleRate.getSelection());
					currentNetwork.findDetectorById(selectedDetector.getIdentifier()).setSampleInterval(spinnerDetectorSampleRate.getSelection());
				}
			}
		});

		Label lblPosition = new Label(grpRoadSegmentDetectors, SWT.NONE);
		lblPosition.setText("Position [m]");
		spinnerDetectorPosition = new Spinner(grpRoadSegmentDetectors, SWT.BORDER);
		spinnerDetectorPosition.setToolTipText("Configure the detector's position on the road segment");
		spinnerDetectorPosition.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerDetectorPosition.setMinimum(0);
		spinnerDetectorPosition.setDigits(1);
		spinnerDetectorPosition.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (selectedDetector != null) {
					selectedDetector.updatePosition(spinnerDetectorPosition.getSelection() / Math.pow(10, spinnerDetectorPosition.getDigits()));
					currentNetwork.findDetectorById(selectedDetector.getIdentifier())
							.updatePosition(spinnerDetectorPosition.getSelection() / Math.pow(10, spinnerDetectorPosition.getDigits()));
					List<Vector> absoluteDetectorPositions = new ArrayList<>();

					for (LaneSegment lane : selectedRoadSegment.getLaneSegments()) {
						absoluteDetectorPositions.add(lane.getRoadGeometry().mapPosition(selectedDetector.getPosition()));
					}

					selectedDetector.setAbsolutePositions(absoluteDetectorPositions);
					currentNetwork.findDetectorById(selectedDetector.getIdentifier()).setAbsolutePositions(absoluteDetectorPositions);
					uiModel.updateView(true);
				}
			}
		});
	}

	public AbstractJunction getSelectedJunction() {
		return selectedJunction;
	}

	public DrawingPanel getDrawingPanel() {
		return drawingPanel;
	}

	private void refreshDetectorProperties() {
		if (selectedDetector != null) {
			btnRemoveDetector.setEnabled(true);
			btnRemoveAllDetectors.setEnabled(true);
			spinnerDetectorSampleRate.setSelection(selectedDetector.getSampleInterval());
			spinnerDetectorPosition.setSelection((int) (selectedDetector.getPosition() * Math.pow(10, spinnerDetectorPosition.getDigits())));
		} else {
			btnRemoveDetector.setEnabled(false);
			btnRemoveAllDetectors.setEnabled(false);
			spinnerDetectorSampleRate.setSelection(0);
			spinnerDetectorPosition.setSelection(0);
		}
	}

	/**
	 * update combo which shows sign depending on which {@link JunctionConnector} is selected
	 */
	private void refreshSignCombo(JunctionConnector selectedConn) {
		activeConnectors = new HashSet<>();
		// add selected as first connector
		activeConnectors.add(selectedConn);
		if (btnSelectAllConnectors.getSelection()) {
			for (JunctionConnector c : selectedJunction.getConnectors()) {
				if (c.getSourceLaneSegment().equals(selectedConn.getSourceLaneSegment())) {
					activeConnectors.add(c);
				}
			}
		}

		boolean connectorSelected = selectedConn != null && comboId.getItemCount() > 0;
		comboSignType.setEnabled(connectorSelected);
		if (selectedConn != null) {
			if (selectedConn.getRoadSign() != null) {
				comboSignType.setText(selectedConn.getRoadSign().getType().toString());
			} else {
				comboSignType.setText(RoadSign.Type.NONE.toString());
			}
			spinnerPriority.setSelection(selectedConn.getPriority());
		}
		uiModel.updateView(false);
	}

	public Set<JunctionConnector> getActiveConnectors() {
		return activeConnectors;
	}

	private void addRoadSign(Type type) {
		for (JunctionConnector c : activeConnectors) {
			c.setRoadSign(new RoadSign(type));
			c.setPriority(RoadSign.getPriority(type));
		}

		for (JunctionConnector c : selectedJunction.getConnectors()) {
			if (c.getRoadSign() == null) {
				c.setRoadSign(new RoadSign(Type.NONE));
				c.setPriority(RoadSign.getPriority(Type.NONE));
			}
		}

		uiModel.updateView(false);
	}

	private void initializeItems() {

		if (comboId == null) {
			return;
		}

		SimulationModel currentModel = SimulationKernel.getInstance().getActiveModel();

		comboId.removeAll();

		if (currentModel == null) {
			return;
		}

		if (activeMode == MODE_JUNCTION) {
			for (AbstractJunction junction : currentModel.getNetwork().getJunctions()) {
				comboId.add(String.valueOf(junction.getId()));
			}
		} else if (activeMode == MODE_ROADSEGMENT) {
			for (RoadSegment roadSegment : currentModel.getNetwork().getRoadSegments()) {
				comboId.add(String.valueOf(roadSegment.getId()));
			}
		}

		if (comboId.getItemCount() > 0) {
			comboId.setEnabled(true);
			comboId.select(0);
		} else {
			comboId.setEnabled(false);
		}

		if (activeMode == MODE_JUNCTION) {
			enableJunctionControls(comboId.isEnabled());
		} else {
			enableRoadSegmentControls(comboId.isEnabled());
		}
	}

	private void selectAndSwitch() {

		SimulationModel currentModel = SimulationKernel.getInstance().getActiveModel();

		if (currentModel == null) {
			return;
		}

		if (activeMode == MODE_JUNCTION) {
			if (StringUtil.isNotNullOrEmpty(comboId.getText())) {
				setSelectedRoadSegment(null);
				setSelectedJunction(currentModel.getNetwork().getJunctionByKey(Long.parseLong(comboId.getText())));
			}
		} else if (activeMode == MODE_ROADSEGMENT) {
			if (StringUtil.isNotNullOrEmpty(comboId.getText())) {
				setSelectedJunction(null);
				setSelectedRoadSegment(currentModel.getNetwork().getRoadSegmentByKey(Long.parseLong(comboId.getText())));
			}
		}
	}

	protected String getViewId() {
		return ID;
	}

	@Override
	public void setFocus() {
		// update listener in case simulation model changed
		SimulationModel activeModel = SimulationKernel.getInstance().getActiveModel();

		if (activeModel != null) {
			activeModel.addItemSelectionListener(this);
		}
	}

	@Override
	public void dispose() {
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
			currentModel.getUiModel().updateView(true); // draw possible new
														// signs
		}

		if (drawingPanel != null) {
			drawingPanel.removeResizeListener(this);
		}

		SimulationKernel.getInstance().removeInputChangedListener(this);
		super.dispose();
	}

	public Image createAWTImage() {
		if (drawingPanel.getWidth() > 0) {
			return new BufferedImage(Math.max(drawingPanel.getWidth() - 2, 1), Math.max(drawingPanel.getHeight() - 2, 1),
					BufferedImage.TYPE_INT_ARGB);
		}
		return null;
	}

	public Display getDisplay() {
		return getViewSite().getShell().getDisplay();
	}

	public void setSelectedDetector(final LoopDetector detector) {
		selectedDetector = detector;
		refreshDetectorProperties();
		uiModel.updateView(false);
	}

	public void setSelectedConnector(final JunctionConnector currentlySelected) {
		selectedConnector = currentlySelected;

		getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				comboConnector.setText(currentlySelected.toString());
				refreshSignCombo(currentlySelected);
			}
		});
	}

	public void setSelectedJunction(AbstractJunction newSelection) {
		selectedJunction = newSelection;

		if (selectedJunction == null) {
			return;
		}

		getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (selectedJunction == null || currentNetwork == null) {
					return;
				}

				if (StringUtil.isNullOrEmpty(comboId.getText()) || !comboId.getText().equals(String.valueOf(selectedJunction.getId()))) {
					comboId.setText(String.valueOf(selectedJunction.getId()));
				}

				if (textMasterId.getText().isEmpty()) {
					textMasterId.setText(selectedJunction.getId() + "");
				} else {
					textSlaveId.setText(selectedJunction.getId() + "");
				}

				// TAB ROAD SIGN
				comboConnector.removeAll();
				connectorMapping.clear();

				for (JunctionConnector jc : selectedJunction.getConnectors()) {
					comboConnector.add(jc.toString());
					connectorMapping.put(jc.toString(), jc);
				}

				if (comboConnector.getItemCount() > 0) {
					comboConnector.setEnabled(true);
					comboConnector.select(0);
					setSelectedConnector(connectorMapping.get(comboConnector.getText()));
				} else {
					comboConnector.setEnabled(false);
				}

				comboSignType.removeAll();

				for (RoadSign.Type t : RoadSign.Type.values()) {
					comboSignType.add(t.toString());
				}

				comboController.removeAll();

				for (TrafficLightControllers t : TrafficLightControllers.values()) {
					comboController.add(t.toString());
				}

				if (comboController.getItemCount() > 0) {
					if (selectedJunction.getTrafficLightController() != null) {
						comboController.setText(selectedJunction.getTrafficLightController().getControlMode().toString());
						currentControlMode = selectedJunction.getTrafficLightController().getControlMode();
					} else {
						comboController.select(0);
						currentControlMode = TrafficLightControllers.values()[0];
					}
				}

				comboTrafficLight.removeAll();
				trafficLightMapping.clear();

				List<TrafficLight> trafficLights = selectedJunction.getTrafficLights();
				TrafficLightController<?> trafficLightController = selectedJunction.getTrafficLightController();

				for (TrafficLight tl : trafficLights) {
					comboTrafficLight.add(String.valueOf(tl.getId()));
					trafficLightMapping.put(String.valueOf(tl.getId()), tl);
					addJunctionIdMapping(selectedJunction, tl.getId());
				}

				if (comboTrafficLight.getItemCount() > 0) {
					comboTrafficLight.select(0);
				}

				btnIsJunctionSignalControlled.setSelection(trafficLightController != null);

				if (trafficLightController != null) {
					btnMergeTrafficLightsPerApproach.setSelection(!trafficLightController.getAreLanesOperatedIndividually());
				} else {
					btnMergeTrafficLightsPerApproach.setSelection(false);
				}

				updateTrafficLightProperties();
				updateTrafficLightControlState(false);

				// TAB GEOMETRY
				comboConnFrom.removeAll();
				comboConnTo.removeAll();

				for (RoadSegment rs : selectedJunction.getSegmentsIn()) {
					for (LaneSegment ls : rs.getLaneSegments()) {
						comboConnFrom.add(ls.toString());
					}
				}

				for (RoadSegment rs : selectedJunction.getSegmentsOut()) {
					for (LaneSegment ls : rs.getLaneSegments()) {
						comboConnTo.add(ls.toString());
					}
				}

				if (comboConnFrom.getItemCount() > 0) {
					comboConnFrom.setEnabled(true);
					comboConnFrom.select(0);
				} else {
					comboConnFrom.setEnabled(false);
				}

				if (comboConnTo.getItemCount() > 0) {
					comboConnTo.setEnabled(true);
					comboConnTo.select(0);
				} else {
					comboConnTo.setEnabled(false);
				}
			}
		});

		uiModel.updateActiveJunction(newSelection);
	}

	public void setSelectedRoadSegment(RoadSegment seg) {
		selectedRoadSegment = seg;

		if (selectedRoadSegment == null) {
			return;
		}

		getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (selectedRoadSegment == null || currentNetwork == null) {
					return;
				}

				if (StringUtil.isNullOrEmpty(comboId.getText()) || !comboId.getText().equals(String.valueOf(selectedRoadSegment.getId()))) {
					comboId.setText(String.valueOf(selectedRoadSegment.getId()));
				}

				// Tab detectors
				comboDetectors.removeAll();
				roadSegmentDetectorMapping.clear();

				List<LoopDetector> detectors = currentNetwork.getDetectorsForRoadSegment(selectedRoadSegment.getId(), false);
				for (LoopDetector dt : detectors) {
					comboDetectors.add(String.valueOf(dt.getIdentifier()));
					roadSegmentDetectorMapping.put(String.valueOf(dt.getIdentifier()), dt.copy());
				}

				if (comboDetectors.getItemCount() > 0) {
					spinnerDetectorPosition
							.setMaximum((int) (selectedRoadSegment.getMinLaneLength() * Math.pow(10, spinnerDetectorPosition.getDigits())));
					comboDetectors.select(0);
					setSelectedDetector(roadSegmentDetectorMapping.get(comboDetectors.getText()));
					enableDetectorControls(true);
				} else {
					setSelectedDetector(null);
					enableDetectorControls(false);
				}

			}
		});

		uiModel.updateActiveRoadSegment(seg);
	}

	/**
	 * This method is called from both UIs, the main ui and the infrastructure editor view
	 */
	@Override
	public void itemsSelected(List<AbstractJunction> junctions, final List<JunctionConnector> connectors, List<RoadSegment> roadSegments,
			List<LaneSegment> laneSegments, List<Vehicle> vehicles) {
		if (activeMode == MODE_JUNCTION) {
			if (junctions != null && !junctions.isEmpty()) {
				setSelectedJunction(junctions.get(0));
			}

			switch (selectedJunctionTab) {
			case TAB_ROAD_SIGNS:
				break;
			case TAB_GEOMETRY:
				if (!laneSegments.isEmpty()) {
					LaneSegment selectedLane = laneSegments.get(0);
					if (selectedJunction.getSegmentsIn().contains(selectedLane.getRoadSegment())) {
						selectedFrom = selectedLane;
					} else if (selectedJunction.getSegmentsOut().contains(selectedLane.getRoadSegment())) {
						selectedTo = selectedLane;
						updateConnToCreate();
					}
					updateLaneSegmentConnector();
				} else if (connectors != null & !connectors.isEmpty()) {
					JunctionConnector conn = connectors.get(0);
					selectedFrom = conn.getSourceLaneSegment();
					selectedTo = conn.getSinkLaneSegment();
					widthShrinkFactor = conn.getLaneWidth() / conn.getSourceLaneSegment().getLaneWidth();
					updateConnToCreate();
				}

				break;
			}
		} else if (activeMode == MODE_ROADSEGMENT) {
			if (roadSegments != null && !roadSegments.isEmpty()) {
				setSelectedRoadSegment(roadSegments.get(0));
			}
		}
	}

	private void updateConnToCreate() {
		getDisplay().asyncExec(new Runnable() {
			@Override
			public void run() {
				comboConnFrom.setText(selectedFrom.toString());
				comboConnTo.setText(selectedTo.toString());
				spinnerWidthFactor.setSelection((int) (widthShrinkFactor * 100));
			}
		});

		connToCreate = selectedJunction.generateConnector(-1, selectedFrom, selectedTo, widthShrinkFactor, smoothingDistance);

		try {
			selectedJunction.updateConnectorEdges(connToCreate);
		} catch (SpatialException e) {
			MessageDialog.openError(getDisplay().getActiveShell(), "Connector update failed", "Cannot create connector edges: " + e.getMessage());
		}

		activeConnectors.clear();
		activeConnectors.add(connToCreate);
		uiModel.updateView(true);
	}

	private void updateLaneSegmentConnector() {
		getDisplay().asyncExec(new Runnable() {
			@Override
			public void run() {
				comboConnFrom.setText(StringUtil.toString(selectedFrom));
				comboConnTo.setText(StringUtil.toString(selectedTo));

			}
		});
	}

	public RoadSegment getSelectedRoadSegment() {
		return selectedRoadSegment;
	}

	public Map<String, LoopDetector> getDetectors() {
		return roadSegmentDetectorMapping;
	}

	public TrafficLight getSelectedTrafficLight() {
		return selectedTrafficLight;
	}

	public LoopDetector getSelectedDetector() {
		return selectedDetector;
	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
		}

		currentModel = newModel;

		if (currentModel != null) {
			currentModel.addItemSelectionListener(this);
			currentNetwork = currentModel.getNetwork();
		} else {
			currentNetwork = null;
		}
	}

	@Override
	public void windowSizeChanged() {
		uiModel.updateView();
	}

	@Override
	public void windowSizeInitialized() {
		if (activeMode == MODE_JUNCTION) {
			if (selectedJunction != null) {
				uiModel.updateActiveJunction(selectedJunction);
			}
		} else {
			if (selectedRoadSegment != null) {
				uiModel.updateActiveRoadSegment(selectedRoadSegment);
			}
		}
	}

	private void addJunctionIdMapping(AbstractJunction junction, long id) {
		if (junctionIdMapping.containsKey(junction) && !junctionIdMapping.get(junction).contains(id)) {
			junctionIdMapping.get(junction).add(id);
		} else if (!junctionIdMapping.containsKey(junction)) {
			List<Long> list = new ArrayList<>();
			list.add(id);
			junctionIdMapping.put(junction, list);
		}
	}
}

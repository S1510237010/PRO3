package at.fhhagenberg.mc.traffsim.routing.rerouter;

import java.util.Queue;

import at.fhhagenberg.mc.traffsim.routing.Congestion;

public interface ICongestionProvider {
	public Queue<Congestion> getCongestions();
}

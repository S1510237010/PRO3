package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.batch;

import java.io.File;
import java.util.List;

import org.eclipse.jface.wizard.Wizard;

public class BatchExecutionWizard extends Wizard {

	BatchFileSelectionPage batchSelectionPage = new BatchFileSelectionPage();

	@Override
	public boolean performFinish() {
		return true;
	}

	@Override
	public void addPages() {
		addPage(batchSelectionPage);
	}

	public List<File> getResult() {
		return batchSelectionPage.getSelectedFiles();
	}

	@Override
	public boolean canFinish() {
		return batchSelectionPage.isPageComplete();
	}

}

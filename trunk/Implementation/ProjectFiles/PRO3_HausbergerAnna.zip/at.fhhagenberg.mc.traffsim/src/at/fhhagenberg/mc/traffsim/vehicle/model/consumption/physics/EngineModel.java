package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.EngineDataBean;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConstants;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Container class providing a number of engine-related parameters and certain interfaces to access them in an abstracted manner.
 *
 * @author Christian Backfrieder
 */
public class EngineModel {

	/**
	 * Gets the engine's power loss for a specific operation frequency.
	 *
	 * @param frequency
	 *            the engine's current operation frequency
	 * @return the engine's power loss based the current frequency and the loss moment
	 */
	public static double getLossPower(double frequency) {
		return getPower(getModelLossMoment(frequency), frequency);
	}

	/**
	 * Gets the engine's power loss moment for a specific operation frequency.
	 *
	 * @param frequency
	 *            the engine's current operation frequency
	 * @return the engine's power loss moment
	 */
	public static double getModelLossMoment(double frequency) {
		final double a = 0.003;
		final double b = 0.03;
		final double c = 12;
		return a * frequency * frequency + b * frequency + c;
	}

	/**
	 * Gets the engine's mechanical moment based on the current operation frequency and the utilised power (mechanical and electrical).
	 *
	 * @param power
	 *            the engine's current power consumption (mechanical and electrical)
	 * @param frequency
	 *            the engine's current operation frequency
	 * @return the engine's mechanical moment
	 */
	public static double getMoment(double power, double frequency) {
		return power / (2 * Math.PI * frequency);
	}

	/**
	 * Gets the engine's power demand based on a given mechanical moment and the operation frequency.
	 *
	 * @param moment
	 *            the engine's mechanical moment
	 * @param frequency
	 *            the engine's operation frequency
	 * @return the engine's power demand
	 */
	public static double getPower(double moment, double frequency) {
		return 2 * Math.PI * frequency * moment;
	}

	/** Model containing various car-related parameters */
	private final CarModel carModel;

	/** The engine's specific consumption */
	private double cSpec0Idle;

	/** The engine's effective cylinder volume */
	private double cylinderVolume;

	/** A list of gear transmission ratios */
	private double[] gears;

	/** The engine's idling consumption rate (l/s) */
	private double idleConsumptionRate;

	/** The engine's idling moment */
	private double idleMoment;

	/** The engine's maximal effective pressure (Pa) */
	private double maxEffPressure;

	/** The engine's maximal operation frequency (revolutions, 1/s) */
	private double maxFrequency;

	/** The engine's maximal moment */
	private double maxMoment;

	/** The engine's maximal effective mechanical power (W) */
	private double maxPower;

	private FuelType fuelType;

	/**
	 * The engine's minimum effective pressure (Pa, part of Pe lost due to gear and engine friction)
	 */
	private double minEffPressure;

	/** The engine's minimum operation frequency (revolutions, 1/s) */
	private double minFrequency;

	/** The engine's minimum specific consumption (kg/Ws) */
	private double minSpecificConsumption;

	private int maxGearIndex;

	/**
	 * Creates a new {@link EngineModel} using the given {@link EngineDataBean} and {@link CarModel}.
	 *
	 * @param engineInput
	 *            a data entity containing all engine-related parameters obtained from a configuration file
	 * @param carModel
	 *            a data entity containing all car-related parameters
	 */
	public EngineModel(EngineDataBean engineInput, CarModel carModel) {
		this.carModel = carModel;
		initialize(engineInput);
	}

	/**
	 * Gets the engine's consumption rate in m�/s based on the current operation frequency and the mechanical output power.
	 *
	 * @param frequency
	 *            the engine's current operation frequency
	 * @param mechPower
	 *            the engine's mechanical output power
	 * @return the consumption rate in m�/s
	 */
	private double consRateAnalyticModel(double frequency, double mechPower) {
		final double indMoment = getMoment(mechPower, frequency) + getModelLossMoment(frequency);
		final double totalPower = mechPower + getLossPower(frequency);
		final double dotCInLiterPerSecond = 1. / FuelConstants.RHO_FUEL_PER_LITER * totalPower
				* cSpecific0(frequency, indMoment, minSpecificConsumption);
		return Math.max(0, dotCInLiterPerSecond / 1000.);
	}

	/**
	 * Gets the engine's specific consumption in l/s based on the current operation frequency, the engine's moment and the min. specific
	 * consumption.
	 *
	 * @param frequency
	 *            the engine's current operation frequency
	 * @param indMoment
	 *            the engine's moment
	 * @param minCSpec0
	 *            the engine's min. specific consumption
	 * @return the specific consumption in l/s
	 */
	private double cSpecific0(double frequency, double indMoment, double minCSpec0) {
		return minCSpec0 + (cSpec0Idle - minCSpec0) * (Math.exp(1 - indMoment / idleMoment)
				+ Math.exp(1 - (maxMoment + getModelLossMoment(frequency) - indMoment) / idleMoment));
	}

	/**
	 * Gets the engine's specific consumption in l/s based on the current operation frequency and the engine's mechanical moment.
	 *
	 * @param frequency
	 *            the engine's current operation frequency
	 * @param mechMoment
	 *            the engine's mechanical moment
	 * @return the specific consumption in l/s
	 */
	public double cSpecific0ForMechMoment(double frequency, double mechMoment) {
		final double indMoment = mechMoment + getModelLossMoment(frequency);
		return mechMoment <= 0 || mechMoment > maxMoment ? 0
				: cSpecific0(frequency, indMoment, minSpecificConsumption) * (indMoment / mechMoment);
	}

	/**
	 * Gets the engine's operation frequency based on the given velocity and the selected gear.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param gearIndex
	 *            the index of the currently selected gear
	 * @return the engine's operation frequency
	 */
	public double getEngineFrequency(double v, int gearIndex) {
		assert gearIndex >= 0 && gearIndex <= maxGearIndex : "gear out of range! g=" + gearIndex;

		final double freq = getGearRatio(gearIndex) * v / carModel.getDynamicWheelCircumfence();
		return Math.max(minFrequency, Math.min(freq, maxFrequency));
	}

	/**
	 * Gets the engine's fuel flow in m�/s based on the current operation frequency and the output power.
	 *
	 * @param frequency
	 *            the engine's current operation frequency
	 * @param power
	 *            the engine's output power
	 * @return the current fuel flow in m�/s
	 */
	public double getFuelFlow(double frequency, double power) {
		return consRateAnalyticModel(frequency, power);
	}

	/**
	 * Gets the gear transmission ratio for the given gear index.
	 *
	 * @param gearIndex
	 *            the gear's index
	 * @return the associated gear transmission ratio
	 */
	private double getGearRatio(int gearIndex) {
		return gears[gearIndex];
	}

	/**
	 * Gets the engine's idle consumption rate.
	 *
	 * @return the idle consumption rate
	 */
	public double getIdleConsumptionRate() {
		return idleConsumptionRate;
	}

	/**
	 * Gets the engine's idle operation frequency.
	 *
	 * @return the idle operation frequency
	 */
	private double getIdleFrequency() {
		return minFrequency;
	}

	/**
	 * Gets the engine's max. operation frequency.
	 *
	 * @return the max. operation frequency
	 */
	public double getMaxFrequency() {
		return maxFrequency;
	}

	/**
	 * Gets the engine's max. feasible gear index.
	 *
	 * @return the max. feasible gear index
	 */
	public int getMaxGearIndex() {
		return maxGearIndex;
	}

	/**
	 * Gets the engine's max. feasible moment.
	 *
	 * @return the max. feasible moment
	 */
	public final double getMaxMoment() {
		return cylinderVolume * maxEffPressure / (4 * Math.PI);
	}

	/**
	 * Gets the engine's max. output power.
	 *
	 * @return the max. output power
	 */
	public double getMaxPower() {
		return maxPower;
	}

	public FuelType getFuelType() {
		return fuelType;
	}

	/**
	 * Gets the engine's minimum operation frequency.
	 *
	 * @return the minimum operation frequency
	 */
	public double getMinFrequency() {
		return minFrequency;
	}

	/**
	 * Gets the engine's number of gears.
	 *
	 * @return the number of gears
	 */
	public int getNumberOfGears() {
		return gears.length;
	}

	/**
	 * Initialises the model using the given {@link EngineDataBean}
	 *
	 * @param engineInput
	 *            a data entity containing all engine-related parameters obtained from a configuration file
	 */
	private void initialize(EngineDataBean engineInput) {
		maxPower = engineInput.getMaxPower() * 1000;

		fuelType = FuelType.valueOfLabel(engineInput.getFuelType());

		idleConsumptionRate = engineInput.getIdleConsumptionRateLiterPerSecond() / 3600;
		minSpecificConsumption = engineInput.getMinSpecificConsumption() / 3.6e9;

		cylinderVolume = engineInput.getCylinderVolume() * 0.001;

		minEffPressure = engineInput.getEffectivePressureMinimum() * FuelConstants.CONVERSION_BAR_TO_PASCAL;
		maxEffPressure = engineInput.getEffectivePressureMaximum() * FuelConstants.CONVERSION_BAR_TO_PASCAL;

		minFrequency = engineInput.getIdleRotationRate() / 60;
		maxFrequency = engineInput.getMaxRotationRate() / 60;

		gears = CollectionUtil.toPrimitiveDoubleArray(engineInput.getGearRatios());
		maxGearIndex = gears.length - 1;
		maxMoment = getMaxMoment();
		idleMoment = getModelLossMoment(getIdleFrequency());

		final double powerIdle = getLossPower(getIdleFrequency());
		cSpec0Idle = idleConsumptionRate * FuelConstants.RHO_FUEL_PER_LITER / powerIdle;
	}

	/**
	 * Determines whether the engine can be operated with a feasible frequency based on the given velocity and the selected gear.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param gearIndex
	 *            the index of the currently selected gear
	 * @return true, if the resulting frequency does not exceed the min. respective the max. feasible operation frequency - false else
	 */
	public boolean isFrequencyPossible(double v, int gearIndex) {
		assert gearIndex >= 0 && gearIndex <= maxGearIndex : "gear out of range !  g=" + gearIndex;

		final double frequencyTest = getGearRatio(gearIndex) * v / carModel.getDynamicWheelCircumfence();

		if (frequencyTest > maxFrequency || frequencyTest < minFrequency) {
			return false;
		}

		return true;
	}
}
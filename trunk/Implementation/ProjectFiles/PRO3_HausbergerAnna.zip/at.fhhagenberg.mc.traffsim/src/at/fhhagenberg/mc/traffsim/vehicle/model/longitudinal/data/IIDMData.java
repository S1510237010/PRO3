package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

public class IIDMData extends IDMData {
	private static final String IDENTIFIER = "IIDM";

	public IIDMData() {
		setIdentifier(IDENTIFIER);
	}

	public IIDMData(double vTarget, double sMin, double tMin, double comfortableAcc, double safeDec, double maxAcc, double maxDec,
			double delta) {
		super(vTarget, sMin, tMin, comfortableAcc, safeDec, maxAcc, maxDec, delta);
		setIdentifier(IDENTIFIER);
	}
}

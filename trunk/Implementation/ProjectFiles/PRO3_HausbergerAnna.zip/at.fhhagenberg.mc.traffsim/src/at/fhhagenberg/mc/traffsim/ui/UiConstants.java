package at.fhhagenberg.mc.traffsim.ui;

import java.awt.Dimension;

import org.eclipse.swt.graphics.RGB;

public abstract class UiConstants {

	public static int MIN_ZOOMRECT_SIZE = 10;
	public static int MATRIX_SIZE = 3;

	// /////////////////////////////////
	/** general constants for the GisClient application */
	public static final int SCROLL_DELTA = 20;
	public static final double ZOOM_FACTOR = 1.2;
	public static final double ZOOM_FACTOR_OSM = 2;

	public static final int DEFAULT_ZOOM_LEVEL = 5;

	/** constants for identifying the gui components for listener notifications */
	public static final double STATUS_UPDATE_INTERVAL_SECONDS = 0.2;
	public static final double FPS_UPDATE_INTERVAL_SECONDS = 1;
	public static final String ACTION_PRINT_IDS = "ACTION_PRINT_IDS";
	public static final String ACTION_START_SIMULATION = "ACTION_START_SIMULATION";
	public static final String ACTION_LOAD_DATA = "ACTION_LOAD_DATA";
	public static final String ACTION_SCROLL_UP = "ACTION_SCROLL_UP";
	public static final String ACTION_SCROLL_DOWN = "ACTION_SCROLL_DOWN";
	public static final String ACTION_SCROLL_LEFT = "ACTION_SCROLL_LEFT";
	public static final String ACTION_SCROLL_RIGHT = "ACTION_SCROLL_RIGHT";
	public static final String ACTION_ZOOM_IN = "ACTION_ZOOM_IN";
	public static final String ACTION_ZOOM_OUT = "ACTION_ZOOM_OUT";
	public static final String ACTION_ZOOM_TO_FIT = "ACTION_ZOOM_TO_FIT";
	public static final String ACTION_MOUSE_SELECT = "BUTTON_NAME_SELECT";
	public static final String ACTION_MOUSE_DRAG = "BUTTON_NAME_DRAG";
	public static final String ACTION_MOUSE_ZOOM = "BUTTON_NAME_ZOOM";
	public static final String ACTION_MOUSE_ADD_OBSTRUCTION = "BUTTON_NAME_ADD_OBSTRUCTION";
	public static final String FIELD_SCALE = "FIELD_SCALE";
	public static final String ACTION_SHOW_SDE_POIS = "ACTION_SHOW_SDE_POIS";
	public static final String ACTION_SHOW_POIS = "ACTION_SHOW_POIS";
	public static final String ACTION_STORE_IMAGE = "ACTION_STORE_IMAGE";
	public static final String ACTION_IMAGE_TYPE = "ACTION_IMAGE_TYPE";
	public static final String ACTION_SHOW_OSM_MAP = "ACTION_SHOW_OSM_MAP";
	public static final String ACTION_TILE_TYPE_CHANGE = "ACTION_TILE_TYPE_CHANGE";

	public static final String ACTION_DELAY = "ACTION_SCALE";
	public static final String ACTION_RESOLUTION = "ACTION_RESOLUTION";

	public static final String SPINNER_AVG_SPEED = "SPINNER_AVG_SPEED";
	public static final String SLIDER_INFLOW = "SLIDER_INFLOW";
	public static final String CHECKBOX_PRINT_DETAILS = "CHECKBOX_PRINT_DETAILS";
	public static final String ACTION_GENERATOR_ID = "ACTION_GENERATOR_ID";
	public static final String SPINNER_RESOLUTION = "SPINNER_RESOLUTION";
	public static final String SPINNER_SIGMA = "SPINNER_SIGMA";

	public static final String DROPDOWN_MOUSE = "DROPDOWN_MOUSE";

	/** constants for mouse state */
	public static final int MOUSE_STATE_SELECT = 0;
	public static final int MOUSE_STATE_DRAG = 1;
	public static final int MOUSE_STATE_ZOOM = 2;
	public static final int MOUSE_STATE_ADD_OBSTRUCTION = 3;
	public static final int INITIAL_MOUSE_STATE = MOUSE_STATE_SELECT;

	public static final String SCALE_PREFIX = "1 : ";
	public static final String SCALE_UNKNOWN = SCALE_PREFIX + "unknown";
	public static final char ENTER_KEY = '\n';
	public static final int POI_TYPE = 99999;

	/** log messages */
	public static final String LOG_ERROR = "ERR  ";
	public static final String LOG_WARNING = "WARN ";
	public static final String LOG_INFO = "INF  ";
	public static final String LOG_DEBUG = "DBG  ";

	public static final String TRAFFIC_GENERATOR_PREFIX = "Traffic-Generator ";

	/** file structure */
	public static final Dimension INITIAL_SIZE = new Dimension(1280, 900);

	/** RCP */
	public static final String ID_CONSOLE_VIEW = "Message Console";

	/** Colors */
	public static final RGB COLOR_DARK_ORANGE = new RGB(240, 115, 0);
	public static final RGB COLOR_LIGHT_ORANGE = new RGB(213, 151, 89);
	public static final RGB COLOR_LIGHT_BLUE = new RGB(0, 128, 255);

}

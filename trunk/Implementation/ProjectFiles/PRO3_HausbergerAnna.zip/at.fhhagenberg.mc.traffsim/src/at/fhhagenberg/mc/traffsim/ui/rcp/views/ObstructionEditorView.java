package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.vehicle.Obstruction;

public class ObstructionEditorView extends AbstractControlView {

	public static final String ID = "at.fhhagenberg.mc.traffsim.views.control.obstructions";

	private Obstruction activeObstruction;
	private List<Obstruction> obstructions;
	private Combo comboObstructions;
	private Combo comboType;
	private Label lblObstruction;
	private Label lblRoadSegment;
	private Label lblPosition;
	private Label lblLane;
	private Label lblType;
	private Label lblOffset;
	private Label lblDuration;
	private Spinner spinnerOffset;
	private Spinner spinnerDuration;
	private Text txtRoadSegment;
	private Text txtPosition;
	private Text txtLane;

	public ObstructionEditorView() {
		this.obstructions = SimulationKernel.getInstance().getActiveModel().getNetwork().getObstructions();
	}

	@Override
	protected void applyChanges() {
		if (activeObstruction != null) {
			if (activeObstruction.isPermanent()) {
				activeObstruction.setDuration(0);
			} else {
				activeObstruction.setDuration(spinnerDuration.getSelection() / Math.pow(10, spinnerDuration.getDigits()));
			}

			activeObstruction.setOffset(spinnerOffset.getSelection() / Math.pow(10, spinnerOffset.getDigits()));
		}
	}

	@Override
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(2, false));

		lblObstruction = new Label(parent, SWT.NONE);
		lblObstruction.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblObstruction.setText("Obstruction");

		comboObstructions = new Combo(parent, SWT.READ_ONLY);
		comboObstructions.setEnabled(true);
		comboObstructions.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		if (obstructions != null) {
			for (Obstruction obstruction : obstructions) {
				comboObstructions.add(getLabel(obstruction));
			}
		}

		comboObstructions.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				activeObstruction = getObstruction(((Combo) e.getSource()).getText());
				updateData(parent);
			}
		});

		lblType = new Label(parent, SWT.NONE);
		lblType.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblType.setText("Type");

		comboType = new Combo(parent, SWT.READ_ONLY);
		comboType.setEnabled(true);
		comboType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		comboType.add("Permanent");
		comboType.add("Temporary");

		comboType.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				activeObstruction.setPermanent(comboType.getSelectionIndex() == 0);
				updateData(parent);
			}
		});

		lblOffset = new Label(parent, SWT.NONE);
		lblOffset.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblOffset.setText("Offset [s]");
		lblOffset.setToolTipText("Offset from simulation start");

		spinnerOffset = new Spinner(parent, SWT.BORDER);
		spinnerOffset.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerOffset.setPageIncrement(10);
		spinnerOffset.setMaximum(Integer.MAX_VALUE);
		spinnerOffset.setMinimum(0);
		spinnerOffset.setSelection(0);
		spinnerOffset.setIncrement(1);
		spinnerOffset.setDigits(1);

		lblDuration = new Label(parent, SWT.NONE);
		lblDuration.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblDuration.setText("Duration [s]");

		spinnerDuration = new Spinner(parent, SWT.BORDER);
		spinnerDuration.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerDuration.setPageIncrement(10);
		spinnerDuration.setMaximum(Integer.MAX_VALUE);
		spinnerDuration.setMinimum(0);
		spinnerDuration.setSelection(0);
		spinnerDuration.setIncrement(1);
		spinnerDuration.setDigits(1);

		lblRoadSegment = new Label(parent, SWT.NONE);
		lblRoadSegment.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRoadSegment.setText("Road segment");

		txtRoadSegment = new Text(parent, SWT.BORDER);
		txtRoadSegment.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRoadSegment.setEnabled(false);

		lblLane = new Label(parent, SWT.NONE);
		lblLane.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblLane.setText("Lane");

		txtLane = new Text(parent, SWT.BORDER);
		txtLane.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtLane.setEnabled(false);

		lblPosition = new Label(parent, SWT.NONE);
		lblPosition.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblPosition.setText("Position");

		txtPosition = new Text(parent, SWT.BORDER);
		txtPosition.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtPosition.setEnabled(false);

		new Label(parent, SWT.NONE);
		new Label(parent, SWT.NONE);

		createButtonComposite(parent);

		comboObstructions.select(0);
		comboType.select(0);

		activeObstruction = obstructions != null && !obstructions.isEmpty() ? obstructions.get(0) : null;
		updateData(parent);
	}

	private Obstruction getObstruction(String label) {
		String[] split = label.split(" ");
		try {
			long id = Long.parseLong(split[1]);
			for (Obstruction obs : obstructions) {
				if (obs.getUniqueId() == id) {
					return obs;
				}
			}
		} catch (Exception ex) {
			Logger.logWarn("Could not find obstruction " + label);
		}
		return null;
	}

	private String getLabel(Obstruction obs) {
		StringBuilder label = new StringBuilder();
		label.append("Obstruction ");
		label.append(obs.getUniqueId());
		return label.toString();
	}

	@Override
	protected String getViewId() {
		return ID;
	}

	private void setEnabled(Composite parent, boolean enabled) {
		for (Control c : parent.getChildren()) {
			if (c != comboObstructions && c != lblObstruction && !(c instanceof Text) && c != spinnerDuration) {
				c.setEnabled(enabled);
			}
		}
	}

	@Override
	public void setFocus() {
		// unused

	}

	protected void updateData(Composite parent) {
		if (activeObstruction != null) {
			spinnerOffset.setSelection((int) (activeObstruction.getOffset() * Math.pow(10, spinnerOffset.getDigits())));
			spinnerDuration.setSelection((int) (activeObstruction.getDuration() * Math.pow(10, spinnerDuration.getDigits())));
			txtPosition.setText(String.valueOf(activeObstruction.getFrontPosition()));
			txtRoadSegment.setText(String.valueOf(activeObstruction.getRoadSegment().getId()));
			txtLane.setText(String.valueOf(activeObstruction.getLaneId()));

			if (activeObstruction.isPermanent()) {
				comboType.select(0);
			} else {
				comboType.select(1);
			}

			if (comboType.getText().compareTo("Permanent") == 0) {
				spinnerDuration.setEnabled(false);
			} else {
				spinnerDuration.setEnabled(true);
			}

			setEnabled(parent, true);
		} else {
			spinnerOffset.setSelection(0);
			spinnerDuration.setSelection(0);
			txtPosition.setText("-");
			txtRoadSegment.setText("-");
			txtLane.setText("-");
			setEnabled(parent, false);
			comboObstructions.setEnabled(false);
			spinnerDuration.setEnabled(false);
		}

		if (obstructions.size() == 0) {
			enableButtons(false);
		} else {
			enableButtons(true);
		}
	}
}

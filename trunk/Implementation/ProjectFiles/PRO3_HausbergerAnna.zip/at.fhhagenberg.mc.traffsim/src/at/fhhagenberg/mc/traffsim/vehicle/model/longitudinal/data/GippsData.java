package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

import at.fhhagenberg.mc.traffsim.ui.Constants;

public class GippsData extends LongitudinalModelData {
	private static final String IDENTIFIER = "Gipps";

	public GippsData() {
		setIdentifier(IDENTIFIER);
	}

	public GippsData(double vTarget, double sMin, double comfortableAcc, double safeDec) {
		super(vTarget, sMin, Constants.DESIRED_TIME_HEADWAY, comfortableAcc, safeDec, Constants.MAX_ACCELERATION,
				Constants.MAX_DECELERATION);
		setIdentifier(IDENTIFIER);
	}
}
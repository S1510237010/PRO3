package at.fhhagenberg.mc.traffsim.routing.rerouter.footprint;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

public class IdVehicleTimeMapping {
	// map of segment/node id to list of vehicle ids that pass the segment
	private Map<Long, Set<Vehicle>> nodeVehicleIdsMapping = new ConcurrentHashMap<>();

	/**
	 * Add a vehicle to the list of passing vehicles for a specific node
	 * 
	 * @param id
	 *            the node id where to assign the vehicle
	 * @param v
	 *            the vehicle to add
	 */
	public void addVehicle(long id, Vehicle v) {
		if (!nodeVehicleIdsMapping.containsKey(id)) {
			nodeVehicleIdsMapping.put(id, new ConcurrentSkipListSet<Vehicle>());
		}
		nodeVehicleIdsMapping.get(id).add(v);
	}

	/**
	 * Remove a vehicle marked for passing a specific node
	 * 
	 * @param id
	 *            the node where to remove the vehicle
	 * @param vehicleId
	 *            the vehicle to remove
	 */
	public void removeVehicle(long id, long vehicleId) {
		if (nodeVehicleIdsMapping.containsKey(id)) {
			nodeVehicleIdsMapping.get(id).remove(vehicleId);
		}
	}

	/**
	 * Determine the vehicles which pass a specific node
	 * 
	 * @param id
	 *            the node id to get passing vehicles for
	 * @return list of vehicles passing the node id (the ones which were added by {@link #addVehicle(long, Vehicle)} before)
	 */
	public Set<Vehicle> getAffectedVehicles(long id) {
		return CollectionUtil.ensureNotNull(nodeVehicleIdsMapping.get(id));
	}
}

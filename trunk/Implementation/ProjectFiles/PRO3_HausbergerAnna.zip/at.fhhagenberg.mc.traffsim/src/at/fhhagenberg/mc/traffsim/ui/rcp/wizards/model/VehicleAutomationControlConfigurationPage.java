package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.io.File;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ContainerControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.VehicleAutomationControlBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControls;
import at.fhhagenberg.mc.util.CollectionUtil;

public class VehicleAutomationControlConfigurationPage extends ContainerControlConfigurationPage {

	protected VehicleAutomationControlConfigurationPage(String pageName) {
		super(pageName);
	}
	
	@Override
	protected void addModelToList() {
		VehicleAutomationControlBean control = new VehicleAutomationControlBean();
		control.setIdentifier(txtIdentifier.getText());
		modelSet.add(control);
	}

	@Override
	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((VehicleAutomationControlBean) element).getIdentifier() + "";
			}
		});

		TableViewerColumn colLongitudinalModel = createTableViewerColumn("Child controls", 310);
		colLongitudinalModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return CollectionUtil.toString(((VehicleAutomationControlBean) element).getControlIdentifiers(), ", ") + "";
			}
		});
	}
	
	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			
			onTableViewerSelectionChanged();
			initializeModels();
			currentControl = LongitudinalControls.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' control parameters", currentControl.toString()));
		}
	}
	
	private void initializeModels() {
		try {
			comboControls.removeAll();

			DataSerializer ser = new DataSerializer();
			File configFile = ((ModelSelectionPage) ((ModelGeneratorWizard) getWizard()).getPage(ModelGeneratorWizard.PAGE_MODEL_SELECTION))
					.getConfigFile();
			ser.readConfiguration(configFile);

			List<? extends AbstractBean> beans = ser.readData(LongitudinalControlBean.class);

			for (AbstractBean abstractBean : beans) {
				if (abstractBean instanceof LongitudinalControlBean && !(abstractBean instanceof ContainerControlBean)) {
					comboControls.add(((LongitudinalControlBean) abstractBean).getIdentifier());
				}
			}

			if (comboControls.getItemCount() > 0) {
				comboControls.setEnabled(true);
				comboControls.select(0);
				lblControlWarning.setVisible(false);
			} else {
				comboControls.setEnabled(false);
				lblControlWarning.setVisible(true);
			}

			validatePage();
		} catch (Exception exc) {
			setErrorMessage("Controls couldn't be loaded. Ensure that the configuration file is not corrupt.");
			comboControls.setEnabled(false);
			return;
		}
	}
}

package at.fhhagenberg.mc.traffsim.ui.preferences;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class ImportPreferencePage extends PreferencePage implements IWorkbenchPreferencePage, IPreferenceConstants {
	private static final String ALTITUDES_TOOLTIP = "Automatically load altitudes from web service (only applicable if configuration contains real coordinates)";
	private static final String SMOOTHING_TOOLTIP = "indicates similarity of smoothed to original shape. \n100% indicates smoothest network (least similarity to original), \n0% de facto no smoothing";
	private static final String SIMPLIFICATION_TOOLTIP = "tolerance for divergence from original to simplified shape (0 m means no simplification)";
	private static final String JUNCTION_TOOLTIP = "Junctions with a distance between their bounds lower than this limit will be merged to one single junction";

	private Text textConfigFile;
	private Button btnLoadConfigurationOn;
	private Label lblConfigurationFile;
	private Button btnBrowse;
	private Scale scaleSmoothing;
	private Spinner scaleSimplification;
	private Button btnAutoloadAltitudes;
	private Label lblSimplificationVal;
	private Label lblSmoothVal;
	private Group grpJunctions;
	private Spinner spinnerMinimalJuncDist;
	private Label lblSettingsForInfrastructure;
	private Button btnCreateReverseConnector;
	private Button btnResetGeometriesWhen;
	private Button btnShowLoadingOptions;
	private Button btnUseCacheFor;

	public ImportPreferencePage() {
		setTitle("General Preferences");
	}

	@Override
	public void init(IWorkbench workbench) {
		setPreferenceStore(TraffSimCorePlugin.getDefault().getPreferenceStore());
		setDescription("General preferences for the Traffic Simulator");
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(3, false));

		btnShowLoadingOptions = new Button(container, SWT.CHECK);
		btnShowLoadingOptions.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnShowLoadingOptions.setText("Show loading options dialog");

		btnUseCacheFor = new Button(container, SWT.CHECK);
		btnUseCacheFor.setToolTipText(
				"The loaded data beans will be cached in a java serialized object stream,\nwhich will increase loading performance for large configurations");
		btnUseCacheFor.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnUseCacheFor.setText("Use cache for data loading");
		new Label(container, SWT.NONE);

		btnLoadConfigurationOn = new Button(container, SWT.CHECK);
		btnLoadConfigurationOn.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnLoadConfigurationOn.setText("Load configuration on startup");

		lblConfigurationFile = new Label(container, SWT.NONE);
		lblConfigurationFile.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblConfigurationFile.setText("Configuration file");

		textConfigFile = new Text(container, SWT.BORDER);
		GridData gd_textConfigFile = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_textConfigFile.widthHint = 250;
		textConfigFile.setLayoutData(gd_textConfigFile);

		btnBrowse = new Button(container, SWT.NONE);
		btnBrowse.setText("Browse ...");
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog fd = new FileDialog(btnBrowse.getShell(), SWT.OPEN);
				fd.setText("Select configuration");
				fd.setFilterExtensions(new String[] { Constants.FILE_FILTER_TRAFFSIM_XML });
				fd.setFilterNames(new String[] { Constants.FILTER_NAME_TRAFFSIM });
				String txt = fd.open();
				textConfigFile.setText(txt);
			}
		});

		btnLoadConfigurationOn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setBrowseEnabled(btnLoadConfigurationOn.getSelection());
			}

		});

		lblSettingsForInfrastructure = new Label(container, SWT.NONE);
		lblSettingsForInfrastructure.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblSettingsForInfrastructure.setText("Settings for infrastructure generation");
		new Label(container, SWT.NONE);

		Group grpNetwork = new Group(container, SWT.NONE);
		grpNetwork.setLayout(new GridLayout(3, false));
		grpNetwork.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 3, 1));
		grpNetwork.setText("Network");

		btnResetGeometriesWhen = new Button(grpNetwork, SWT.CHECK);
		btnResetGeometriesWhen.setToolTipText(
				"The geometry of the road segments is reset to its initial value, road signs and regulations are preserved");
		btnResetGeometriesWhen.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnResetGeometriesWhen.setText("Reset geometries when loading configuration");

		final Label lblSimplification = new Label(grpNetwork, SWT.NONE);
		lblSimplification.setText("Simplification tolerance");
		lblSimplification.setToolTipText(SIMPLIFICATION_TOOLTIP);

		scaleSimplification = new Spinner(grpNetwork, SWT.BORDER);
		scaleSimplification.setDigits(1);
		scaleSimplification.setMaximum(500);
		scaleSimplification.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		scaleSimplification.setToolTipText(SIMPLIFICATION_TOOLTIP);

		lblSimplificationVal = new Label(grpNetwork, SWT.NONE);
		GridData gd_lblSimplificationVal = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_lblSimplificationVal.widthHint = 50;
		lblSimplificationVal.setLayoutData(gd_lblSimplificationVal);
		lblSimplificationVal.setToolTipText(SIMPLIFICATION_TOOLTIP);
		scaleSimplification.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lblSimplificationVal.setText(getMeterString(scaleSimplification.getSelection()));
			}
		});
		final Label lblSmoothing = new Label(grpNetwork, SWT.NONE);
		lblSmoothing.setText("Smoothing");
		lblSmoothing.setToolTipText(SMOOTHING_TOOLTIP);

		scaleSmoothing = new Scale(grpNetwork, SWT.NONE);
		scaleSmoothing.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		scaleSmoothing.setToolTipText(SMOOTHING_TOOLTIP);

		lblSmoothVal = new Label(grpNetwork, SWT.NONE);
		lblSmoothVal.setToolTipText(SMOOTHING_TOOLTIP);
		GridData gd_lblSmoothVal = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_lblSmoothVal.widthHint = 50;
		lblSmoothVal.setLayoutData(gd_lblSmoothVal);
		scaleSmoothing.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lblSmoothVal.setText(getPercentString(scaleSmoothing.getSelection()));
				super.widgetSelected(e);
			}
		});

		btnAutoloadAltitudes = new Button(grpNetwork, SWT.CHECK);
		btnAutoloadAltitudes.setToolTipText(ALTITUDES_TOOLTIP);
		btnAutoloadAltitudes.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnAutoloadAltitudes.setText("Auto-import altitudes");

		grpJunctions = new Group(container, SWT.NONE);
		grpJunctions.setLayout(new GridLayout(3, false));
		grpJunctions.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 3, 1));
		grpJunctions.setText("Junctions");

		Label lblMinimalDistance = new Label(grpJunctions, SWT.NONE);
		lblMinimalDistance.setText("Minimal distance");
		lblMinimalDistance.setToolTipText(JUNCTION_TOOLTIP);

		spinnerMinimalJuncDist = new Spinner(grpJunctions, SWT.BORDER);
		spinnerMinimalJuncDist.setMaximum(200);
		spinnerMinimalJuncDist.setSelection(30);
		spinnerMinimalJuncDist.setDigits(1);
		spinnerMinimalJuncDist.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerMinimalJuncDist.setToolTipText(JUNCTION_TOOLTIP);

		Label lblM = new Label(grpJunctions, SWT.NONE);
		lblM.setText("m");
		lblM.setToolTipText(JUNCTION_TOOLTIP);

		btnCreateReverseConnector = new Button(grpJunctions, SWT.CHECK);
		btnCreateReverseConnector.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnCreateReverseConnector.setText("Create reverse junction connector");
		new Label(grpJunctions, SWT.NONE);
		initializePreferences();
		return container;
	}

	private String getPercentString(int val) {
		return String.format("%d %%", val);
	}

	private String getMeterString(int val) {
		return String.format("%.1f m", (double) val / 10);
	}

	private void initializePreferences() {
		btnLoadConfigurationOn.setSelection(PreferenceUtil.getBoolean(LOAD_FILE_ON_STARTUP));
		textConfigFile.setText(PreferenceUtil.getString(FILE_TO_LOAD_ON_STARTUP));
		scaleSimplification.setSelection(PreferenceUtil.getInt(NETWORK_SIMPLIFICATION_TOLERANCE));
		lblSimplificationVal.setText(getMeterString(PreferenceUtil.getInt(NETWORK_SIMPLIFICATION_TOLERANCE)));
		scaleSmoothing.setSelection(PreferenceUtil.getInt(NETWORK_SMOOTHING));
		lblSmoothVal.setText(getPercentString(PreferenceUtil.getInt(NETWORK_SMOOTHING)));
		btnAutoloadAltitudes.setSelection(PreferenceUtil.getBoolean(AUTO_LOAD_ALTITUDES));
		spinnerMinimalJuncDist.setSelection(PreferenceUtil.getInt(JUNCTION_MERGE_LIMIT));
		btnCreateReverseConnector.setSelection(PreferenceUtil.getBoolean(CREATE_REVERSE_CONNECTOR));
		btnShowLoadingOptions.setSelection(PreferenceUtil.getBoolean(SHOW_LOADING_OPTIONS_DIALOG));
		btnResetGeometriesWhen.setSelection(PreferenceUtil.getBoolean(RESET_GEOMETRY_ON_LOAD));
		btnUseCacheFor.setSelection(PreferenceUtil.getBoolean(USE_CACHE_FOR_LOADING));
		setBrowseEnabled(btnLoadConfigurationOn.getSelection());
	}

	private void setBrowseEnabled(boolean selection) {
		lblConfigurationFile.setEnabled(btnLoadConfigurationOn.getSelection());
		textConfigFile.setEnabled(btnLoadConfigurationOn.getSelection());
		btnBrowse.setEnabled(btnLoadConfigurationOn.getSelection());
	}

	@Override
	protected void performApply() {
		PreferenceUtil.setBoolean(LOAD_FILE_ON_STARTUP, btnLoadConfigurationOn.getSelection());
		PreferenceUtil.set(FILE_TO_LOAD_ON_STARTUP, textConfigFile.getText());
		PreferenceUtil.setInt(NETWORK_SIMPLIFICATION_TOLERANCE, scaleSimplification.getSelection());
		PreferenceUtil.setInt(NETWORK_SMOOTHING, scaleSmoothing.getSelection());
		PreferenceUtil.setBoolean(AUTO_LOAD_ALTITUDES, btnAutoloadAltitudes.getSelection());
		PreferenceUtil.setInt(JUNCTION_MERGE_LIMIT, spinnerMinimalJuncDist.getSelection());
		PreferenceUtil.setBoolean(CREATE_REVERSE_CONNECTOR, btnCreateReverseConnector.getSelection());
		PreferenceUtil.setBoolean(SHOW_LOADING_OPTIONS_DIALOG, btnShowLoadingOptions.getSelection());
		PreferenceUtil.setBoolean(RESET_GEOMETRY_ON_LOAD, btnResetGeometriesWhen.getSelection());
		PreferenceUtil.setBoolean(USE_CACHE_FOR_LOADING, btnUseCacheFor.getSelection());
	}

	@Override
	public boolean performOk() {
		performApply();
		return true;
	}

	// @Override
	// public Point computeSize() {
	// return new Point(0,0);
	// }

}

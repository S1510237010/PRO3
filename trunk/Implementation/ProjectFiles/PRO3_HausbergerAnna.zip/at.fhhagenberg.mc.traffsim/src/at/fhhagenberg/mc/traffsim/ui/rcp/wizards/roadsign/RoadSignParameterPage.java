package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.roadsign;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.util.StringUtil;

public class RoadSignParameterPage extends WizardPage {

	public class GenerationParameters {
		/** difference of speed limits to create a stop sign instead of give way sign, -1 if disabled */
		public double stopSignFactor;
		public boolean roundaboutOnly;
		public double givewayThresholdFactor;
		public boolean tJunctions;
		public double spdRangeMin;
		public double spdRangeMax;
	}

	protected RoadSignParameterPage(String pageName) {
		super("Road Sign Generation Parameters");
		setTitle("Road Sign Generation Parameters");
		setDescription("Set up details for automated road sign generation");
	}

	private GenerationParameters result = new GenerationParameters();
	private Label lblThresholdFactor;
	private Spinner spinnerThresholdFactor;
	private Button btnGenerateStopSigns;
	private Button btnRoundaboutsOnly;
	private Label lblGivewayThresholdFactor;
	private Spinner spinnerThresholdGiveway;
	private Button btnIncludeTjunctionsWith;
	private Label lblMinimumSegmentSpeed;
	private Label lblMaximumSegmentSpeed;
	private Spinner spinnerMinSegSpeed;
	private Spinner spinnerMaxSegSpeed;
	private Label lblKmh;
	private Label label;

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);
		validatePage();
		getWizard().getContainer().updateButtons();
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new GridLayout(3, false));

		btnIncludeTjunctionsWith = new Button(container, SWT.CHECK);
		btnIncludeTjunctionsWith.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnIncludeTjunctionsWith.setText("Include T-junctions with same speed limit");

		lblGivewayThresholdFactor = new Label(container, SWT.NONE);
		lblGivewayThresholdFactor.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 2, 1));
		lblGivewayThresholdFactor.setText("Giveway threshold factor:");

		spinnerThresholdGiveway = new Spinner(container, SWT.BORDER);
		spinnerThresholdGiveway.setMaximum(1000);
		spinnerThresholdGiveway.setMinimum(100);
		spinnerThresholdGiveway.setSelection(120);
		spinnerThresholdGiveway.setDigits(2);

		btnGenerateStopSigns = new Button(container, SWT.CHECK);
		btnGenerateStopSigns.setSelection(true);
		btnGenerateStopSigns.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				boolean enabled = btnGenerateStopSigns.getSelection();
				lblThresholdFactor.setEnabled(enabled);
				spinnerThresholdFactor.setEnabled(enabled);
				validatePage();
			}
		});

		btnGenerateStopSigns.setText("Generate STOP signs");

		lblThresholdFactor = new Label(container, SWT.NONE);
		lblThresholdFactor.setText("Threshold factor:");

		spinnerThresholdFactor = new Spinner(container, SWT.BORDER);
		spinnerThresholdFactor.setMaximum(1000);
		spinnerThresholdFactor.setMinimum(100);
		spinnerThresholdFactor.setSelection(190);
		spinnerThresholdFactor.setDigits(2);

		btnRoundaboutsOnly = new Button(container, SWT.CHECK);
		btnRoundaboutsOnly.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				validatePage();
			}
		});

		btnRoundaboutsOnly.setText("Roundabouts");

		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);


		lblMinimumSegmentSpeed = new Label(container, SWT.NONE);
		lblMinimumSegmentSpeed.setToolTipText("Only junctions with segments that have a minimum speed limit of this value are considered");
		lblMinimumSegmentSpeed.setText("Minimum segment speed");

		spinnerMinSegSpeed = new Spinner(container, SWT.BORDER);
		spinnerMinSegSpeed.setToolTipText("Only junctions with segments that have a minimum speed limit of this value are considered");
		spinnerMinSegSpeed.setMaximum(250);
		spinnerMinSegSpeed.setMinimum(-1);
		spinnerMinSegSpeed.setSelection(-1);
		spinnerMinSegSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		lblKmh = new Label(container, SWT.NONE);
		lblKmh.setText("km/h");

		lblMaximumSegmentSpeed = new Label(container, SWT.NONE);
		lblMaximumSegmentSpeed.setToolTipText("Only junctions with segments that have a maximum speed limit of this value are considered");
		lblMaximumSegmentSpeed.setText("Maximum segment speed");

		spinnerMaxSegSpeed = new Spinner(container, SWT.BORDER);
		spinnerMaxSegSpeed.setToolTipText("Only junctions with segments that have a maximum speed limit of this value are considered");
		spinnerMaxSegSpeed.setMaximum(250);
		spinnerMaxSegSpeed.setMinimum(-1);
		spinnerMaxSegSpeed.setSelection(-1);
		spinnerMaxSegSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		label = new Label(container, SWT.NONE);
		label.setText("km/h");
		SelectionAdapter sel = new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				validatePage();
			}
		};
		spinnerThresholdFactor.addSelectionListener(sel);
		spinnerMaxSegSpeed.addSelectionListener(sel);
		spinnerMinSegSpeed.addSelectionListener(sel);
		spinnerThresholdGiveway.addSelectionListener(sel);
		btnRoundaboutsOnly.addSelectionListener(sel);
		btnIncludeTjunctionsWith.addSelectionListener(sel);
		btnGenerateStopSigns.addSelectionListener(sel);

		validatePage();
		getWizard().getContainer().updateButtons();
	}

	@Override
	public boolean canFlipToNextPage() {
		return StringUtil.isNullOrEmpty(getErrorMessage());
	}

	private void validatePage() {
		result.stopSignFactor = ((double) spinnerThresholdFactor.getSelection()) / 100f;

		if (!btnGenerateStopSigns.getSelection()) {
			result.stopSignFactor = 50;
		}

		result.roundaboutOnly = btnRoundaboutsOnly.getSelection();

		if (SimulationKernel.getInstance().getActiveModel() == null) {
			setErrorMessage("No simulation model selected");
		} else {
			setErrorMessage(null);
		}
		result.givewayThresholdFactor = ((double) spinnerThresholdGiveway.getSelection()) / 100f;
		result.tJunctions = btnIncludeTjunctionsWith.getSelection();
		result.spdRangeMin = spinnerMinSegSpeed.getSelection() >= 0 ? spinnerMinSegSpeed.getSelection() : Double.MIN_VALUE;
		result.spdRangeMax = spinnerMaxSegSpeed.getSelection() >= 0 ? spinnerMaxSegSpeed.getSelection() : Double.MAX_VALUE;
	}

	@Override
	public boolean isPageComplete() {
		validatePage();
		return getErrorMessage() == null;
	}

	public GenerationParameters getResult() {
		return result;
	}
}

package at.fhhagenberg.mc.traffsim.statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Location;

public class BaseVehicleStatisticsData implements Serializable {

	private static final long serialVersionUID = 7660408927145231445L;
	protected final long vehicleId;
	protected List<Double> time = new ArrayList<>();
	protected List<Double> speed = new ArrayList<>();
	protected List<Double> acc = new ArrayList<>();
	protected List<Double> fuelConsumptionPer100km = new ArrayList<>();
	protected List<Double> fuelConsumptionPerHour = new ArrayList<>();
	protected List<Double> carbonEmissionsPer100km = new ArrayList<>();
	protected List<Double> carbonEmissionsPerHour = new ArrayList<>();
	protected List<Double> travelDistance = new ArrayList<>();
	protected List<Double> distanceToFront = new ArrayList<>();
	protected List<Double> distractionState = new ArrayList<>();
	protected List<Location> position = new ArrayList<>();
	protected long recordedItems;
	protected double totalFuelConsumed;
	protected double totalCarbonEmissions;

	public BaseVehicleStatisticsData() {
		vehicleId = -1;
	}

	public BaseVehicleStatisticsData(long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public long getVehicleId() {
		return vehicleId;
	}

	public List<Double> getTime() {
		return time;
	}

	public List<Double> getSpeed() {
		return speed;
	}

	public List<Double> getAcc() {
		return acc;
	}

	public List<Double> getTravelDistance() {
		return travelDistance;
	}

	public List<Double> getDistanceToFront() {
		return distanceToFront;
	}

	public List<Double> getDistractionState() {
		return distractionState;
	}

	public List<Double> getFuelConsumptionPer100km() {
		return fuelConsumptionPer100km;
	}

	public List<Double> getFuelConsumptionPerHour() {
		return fuelConsumptionPerHour;
	}

	public List<Double> getCarbonEmissionsPer100km() {
		return carbonEmissionsPer100km;
	}

	public List<Double> getCarbonEmissionsPerHour() {
		return carbonEmissionsPerHour;
	}

	/**
	 *
	 * @return the total amount of recorded items. This does not correspond with the array sizes, since items have potentially been already
	 *         removed
	 */
	public long getRecordedItems() {
		return recordedItems;
	}

	public List<Location> getPosition() {
		return position;
	}

	public double getTotalFuelConsumed() {
		return totalFuelConsumed;
	}

	public double getTotalCarbonEmissions() {
		return totalCarbonEmissions;
	}
}
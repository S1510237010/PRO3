package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.data.DataExporter;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;

public class ExportInfrastructureCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

	@Override
	public void dispose() {
		// unused

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		if (SimulationKernel.getInstance().isModelActive()) {
			Job job = new Job("Exporting network") {

				@Override
				protected IStatus run(IProgressMonitor monitor) {
					DataExporter.exportNetwork(monitor);

					Display.getDefault().asyncExec(new Runnable() {
						@Override
						public void run() {
							MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Export finished",
									"The road network has been exported successfully.");
						}
					});

					return Status.OK_STATUS;
				}
			};

			job.setUser(true);
			job.schedule();
		}
		return null;
	}

	@Override
	public boolean isEnabled() {
		return SimulationKernel.getInstance().isModelActive();
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

}

package at.fhhagenberg.mc.traffsim.data.osm;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.osm.OSMNode;
import at.fhhagenberg.mc.traffsim.model.osm.OSMWay;

/**
 * This class provides functionalities to load OSM data from the web (via the overpass API <url>http://www.overpass-api.de/api/</url>) or
 * from an OSM-XML file.
 *
 * @author Manuel Lindorfer
 *
 */
public class OSMLoader {

	/**
	 * Boundary coordinates of the loaded network (min. latitude/longitude, max. latitude/longitude)
	 **/
	private double[] boundaries = new double[4];

	/** Loaded OSM nodes and ways */
	private ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();

	/** URL of the overpass API to be requested */
	private final String OVERPASS_API = "http://overpass.osm.rambler.ru/cgi/xapi_meta?*";

	/** List of loaded ways */
	private ArrayList<OSMWay> ways = new ArrayList<OSMWay>();

	/**
	 * Get's the bounding coordinates of the processed OSM-XML file.
	 *
	 * @return an array containing the bounding coordinates (min. latitude/longitude, max. latitude/longitude)
	 */
	public double[] getBoundaries() {
		return boundaries;
	}

	/**
	 * Get's a list of all extracted {@link OSMNode}s.
	 *
	 * @return a list of all OSM nodes
	 */
	public ArrayList<OSMNode> getNodes() {
		return nodes;
	}

	/**
	 * Get's an {@link OSMNode} identified by the given identifier.
	 *
	 * @param id
	 *            the identifier of the requested node
	 *
	 * @return an OSM node associated with the given identifier, or null
	 */
	private OSMNode getOSMNodeById(long id) {
		for (OSMNode n : nodes) {
			if (n.getId() == id) {
				return n;
			}
		}

		return null;
	}

	/**
	 * Get's a list of all extracted {@link OSMWay}s.
	 *
	 * @return a list of all OSM ways
	 */
	public ArrayList<OSMWay> getWays() {
		return ways;
	}

	/**
	 * Get's an XML document from a given file location.
	 *
	 * @param location
	 *            the path to the XML file
	 * @param monitor
	 *            an {@link IProgressMonitor} for progress monitoring
	 * @return the loaded XML document
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public Document getXMLFile(String location, IProgressMonitor monitor) throws ParserConfigurationException, SAXException, IOException {

		monitor.subTask("Loading file...");

		try {
			DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
			return docBuilder.parse(location);
		} catch (FileNotFoundException f) {
			return null;
		}
	}

	/**
	 * Get's an XML document by requesting it from the overpass API using the provided boundary coordinates.
	 *
	 * @param minlat
	 *            minimum latitude of the bounding rectangle
	 * @param minlon
	 *            minimum longitude of the bounding rectangle
	 * @param maxlat
	 *            maximum latitude of the bounding rectangle
	 * @param maxlon
	 *            maximum longitude of the bounding rectangle
	 * @param monitor
	 *            an {@link IProgressMonitor} for progress monitoring
	 * @return the downloaded XML document
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	public Document getXMLOverpass(double minlat, double minlon, double maxlat, double maxlon, IProgressMonitor monitor)
			throws IOException, ParserConfigurationException, SAXException {

		monitor.subTask("Downloading OSM data...");

		DecimalFormat format = new DecimalFormat("##0.0000000", DecimalFormatSymbols.getInstance(Locale.ENGLISH)); //$NON-NLS-1$
		String left = format.format(minlon);
		String bottom = format.format(minlat);
		String right = format.format(maxlon);
		String top = format.format(maxlat);

		String string = OVERPASS_API + "[bbox=" + left + "," + bottom + "," + right + "," + top + "]";
		URL osm = new URL(string);
		Logger.logDebug("Loading from '" + string + "'...");
		HttpURLConnection connection = (HttpURLConnection) osm.openConnection();

		DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
		return docBuilder.parse(new InputSource(new InputStreamReader(connection.getInputStream(), "UTF-8")));
	}

	/**
	 * Processes the given XML document and extracts all {@link OSMNode}s and {@link OSMWay}s from it.
	 *
	 * @param xmlDocument
	 *            the XML document to be processed
	 * @param monitor
	 *            an {@link IProgressMonitor} for progress monitoring
	 */
	public void processOSM(Document xmlDocument, IProgressMonitor monitor) {
		nodes.clear();
		ways.clear();

		if (xmlDocument != null) {

			Node osmRoot = xmlDocument.getFirstChild();
			NodeList osmXMLNodes = osmRoot.getChildNodes();

			for (int i = 1; i < osmXMLNodes.getLength(); i++) {
				Node item = osmXMLNodes.item(i);

				monitor.subTask("Processing OSM document... (" + i + "/" + osmXMLNodes.getLength() + ")");

				if (item.getNodeName().compareTo("bounds") == 0) {
					NamedNodeMap attributes = item.getAttributes();

					Node itemMinLat = attributes.getNamedItem("minlat");
					Node itemMinLon = attributes.getNamedItem("minlon");
					Node itemMaxLat = attributes.getNamedItem("maxlat");
					Node itemMaxLon = attributes.getNamedItem("maxlon");

					double minLatitude = Double.parseDouble(itemMinLat.getNodeValue());
					double minLongitude = Double.parseDouble(itemMinLon.getNodeValue());
					double maxLatitude = Double.parseDouble(itemMaxLat.getNodeValue());
					double maxLongitude = Double.parseDouble(itemMaxLon.getNodeValue());

					boundaries[0] = minLongitude;
					boundaries[1] = minLatitude;
					boundaries[2] = maxLongitude;
					boundaries[3] = maxLatitude;
				} else if (item.getNodeName().compareTo("node") == 0) {
					NamedNodeMap attributes = item.getAttributes();
					NodeList tagXMLNodes = item.getChildNodes();
					Map<String, String> tags = new HashMap<String, String>();

					for (int j = 1; j < tagXMLNodes.getLength(); j++) {
						Node tagItem = tagXMLNodes.item(j);
						NamedNodeMap tagAttributes = tagItem.getAttributes();
						if (tagAttributes != null) {
							tags.put(tagAttributes.getNamedItem("k").getNodeValue(), tagAttributes.getNamedItem("v").getNodeValue());
						}
					}

					Node namedItemID = attributes.getNamedItem("id");
					Node namedItemLat = attributes.getNamedItem("lat");
					Node namedItemLon = attributes.getNamedItem("lon");
					Node namedItemVersion = attributes.getNamedItem("version");

					long id = Long.parseLong(namedItemID.getNodeValue());
					double latitude = Double.parseDouble(namedItemLat.getNodeValue());
					double longitude = Double.parseDouble(namedItemLon.getNodeValue());
					String version = "0";

					if (namedItemVersion != null) {
						version = namedItemVersion.getNodeValue();
					}

					OSMNode node = new OSMNode(latitude, longitude, id);
					node.setVersion(version);
					nodes.add(node);
				} else if (item.getNodeName().compareTo("way") == 0) {
					NamedNodeMap attributes = item.getAttributes();

					Node namedItemID = attributes.getNamedItem("id");
					long id = Long.parseLong(namedItemID.getNodeValue());
					OSMWay way = new OSMWay(id);

					NodeList tagXMLNodes = item.getChildNodes();
					Map<String, String> tags = new HashMap<String, String>();

					for (int j = 1; j < tagXMLNodes.getLength(); j++) {
						Node tagItem = tagXMLNodes.item(j);
						NamedNodeMap tagAttributes = tagItem.getAttributes();

						if (tagItem.getNodeName().compareTo("nd") == 0) {
							if (tagAttributes != null) {
								long nodeId = Long.parseLong(tagAttributes.getNamedItem("ref").getNodeValue());

								OSMNode node = getOSMNodeById(nodeId);

								if (node != null) {
									way.addNode(node);
								}
							}
						} else {
							if (tagAttributes != null) {
								tags.put(tagAttributes.getNamedItem("k").getNodeValue(), tagAttributes.getNamedItem("v").getNodeValue());
							}
						}
					}

					Node namedItemVersion = attributes.getNamedItem("version");
					String version = "0";

					if (namedItemVersion != null) {
						version = namedItemVersion.getNodeValue();
					}

					way.setVersion(version);
					way.setTags(tags);
					ways.add(way);
				}
			}
		}
	}
}
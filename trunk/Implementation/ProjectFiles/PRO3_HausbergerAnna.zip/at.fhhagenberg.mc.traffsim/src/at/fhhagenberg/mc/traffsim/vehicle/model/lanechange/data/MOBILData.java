package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data;

public class MOBILData extends AbstractLaneChangeModelData {

	public MOBILData() {
	}

	public MOBILData(double biasRight, double sMin, double threshold, double politeness, double safeDec, double maxDec) {
		super();
		this.biasRight = biasRight;
		this.sMin = sMin;
		this.threshold = threshold;
		this.politeness = politeness;
		this.safeDec = safeDec;
		this.maxDec = maxDec;
	}

	private double biasRight;
	private double sMin;
	private double threshold;
	private double politeness;
	private double safeDec;
	private double maxDec;

	public double getBiasRight() {
		return biasRight;
	}

	public void setBiasRight(double biasRight) {
		this.biasRight = biasRight;
	}

	public double getsMin() {
		return sMin;
	}

	public void setsMin(double sMin) {
		this.sMin = sMin;
	}

	public double getThreshold() {
		return threshold;
	}

	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}

	public double getPoliteness() {
		return politeness;
	}

	public void setPoliteness(double politeness) {
		this.politeness = politeness;
	}

	public double getSafeDec() {
		return safeDec;
	}

	public void setSafeDec(double safeDec) {
		this.safeDec = safeDec;
	}

	public double getMaxDec() {
		return maxDec;
	}

	public void setMaxDec(double maxDec) {
		this.maxDec = maxDec;
	}
}

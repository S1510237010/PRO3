package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange;

import java.util.List;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.CheckUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.TrafficUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle.VehicleProperties;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleListenerAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data.CACCLaneChangeData;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon.ManeuverType;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon.State;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * Lane change model for platooning. Only allowed to use within a platoon in combination with CACC longitudinal model
 *
 * @author Sebastian Huber
 *
 */
public class CACCLaneChange extends LaneChangeModel {

	/**
	 * parameters from config file
	 */
	private CACCLaneChangeData data;

	/**
	 * human lane change model (used for non platoon and maneuvers on JOIN_REQ)
	 */
	private LaneChangeModel humanModel;

	/**
	 * leader lane change model
	 */
	private LaneChangeModel leaderModel;

	/**
	 * platoon of the vehicle
	 */
	private Platoon platoon;

	/**
	 * CTor
	 *
	 * @param data
	 *            data entity with parameters from xml
	 */
	public CACCLaneChange(CACCLaneChangeData data) {
		super(data.getIdentifier());
		this.data = data;
		this.fullname = data.getFullname();
		this.humanModel = data.getHumanModel().copyForVehicle(null);
		this.leaderModel = data.getLeaderModel().copyForVehicle(null);
	}

	/**
	 * Empty CTor for Kryo
	 */
	public CACCLaneChange() {

	}

	/**
	 * Getter for platoon of vehicle
	 *
	 * @return platoon
	 */
	public Platoon getPlatoon() {
		return platoon;
	}

	/**
	 * Setter for platoon
	 *
	 * @param platoon
	 *            platoon of vehicle
	 */
	public void setPlatoon(Platoon platoon) {
		this.platoon = platoon;
	}

	@Override
	public void setVehicle(Vehicle me) {
		super.setVehicle(me);
		humanModel.setVehicle(me);
		leaderModel.setVehicle(me);
	}

	@Override
	public LaneChangeModel copyForVehicle(Vehicle v) {
		CACCLaneChange copy = new Kryo().copy(this);
		copy.setVehicle(v);
		return copy;
	}

	@Override
	public LaneChangeDecision makeDecision() {

		// Not in platoon -> return human model
		if (platoon == null) {
			return humanModel.makeDecision();
		}

		if (me == null || getVehicle().getRoadSegment() == null || me.getRoadSegment().getLaneCount() == 1) {
			return LaneChangeFactory.decisionStayInLane();
		}

		Vehicle leader = platoon.getLeader();
		State state = platoon.getVehicleState(me);

		switch (state) {
		case IDLE:
			return processIdle(me, leader);
		case LANE_CHANGE:
			return processLaneChange(me, leader);
		case JOIN_REQUEST:
			return processJoinRequest(me, leader);
		case JOIN:
			return processJoin(me, leader);
		case LEAVE:
		case DISSOLVE:
			return processLeave(me, leader);
		}
		return LaneChangeFactory.decisionStayInLane();
	}

	// ##########################
	// # STATE MACHINE #
	// ##########################

	/**
	 * Helper for Idle state
	 *
	 * @param me
	 *            Vehicle to process
	 * @param leader
	 *            Leader of platoon
	 * @return lane change decision
	 */
	private LaneChangeDecision processIdle(Vehicle me, Vehicle leader) {
		if (me.equals(leader)) {
			if (data.isPlatoonLaneChangeEnabled()) {
				LaneChangeDecision decision = checkForLeaderLaneChange();
				if (decision.getDirection() == Lane.NO_CHANGE) {
					return LaneChangeFactory.decisionStayInLane();
				}
				if (platoon.onReadyForLaneChange(decision)) {
					return decision;
				}
				return LaneChangeFactory.decisionStayInLane();
			} else {
				return LaneChangeFactory.decisionStayInLane();
			}
		} else {
			if (me.getLaneIndex() != leader.getLaneIndex()) {
				int laneDistance = getLaneDistance(me, leader);
				return createLaneChangeDecisionForPlatoonLaneChange(me, laneDistance);
			}
			return LaneChangeFactory.decisionStayInLane();
		}
	}

	/**
	 * Helper for Lane Change state
	 *
	 * @param me
	 *            Vehicle to process
	 * @param leader
	 *            Leader of platoon
	 * @return lane change decision
	 */
	private LaneChangeDecision processLaneChange(Vehicle me, Vehicle leader) {
		LaneChangeDecision platoonDecision = platoon.getLaneChangeDecision();
		if (leader.getLaneIndex() != me.getLaneIndex()) {
			LaneChangeDecision finalDecision = createLaneChangeDecisionForPlatoonLaneChange(me, platoonDecision.getDirection());
			// TODO error states if final decision is not platoon decision
			return finalDecision;
		}
		platoon.onVehicleStateReadyLat(me);
		return LaneChangeFactory.decisionStayInLane();

	}

	/**
	 * Helper for JoinRequest state
	 *
	 * @param me
	 *            Vehicle to process
	 * @param leader
	 *            Leader of platoon
	 * @return lane change decision
	 */
	private LaneChangeDecision processJoinRequest(Vehicle me, Vehicle leader) {
		// first/last vehicle in platoon
		if (leader == null) {
			platoon.onVehicleStateReadyLat(me);
			return LaneChangeFactory.decisionStayInLane();
		}

		int laneDistance = getLaneDistance(me, leader);
		ManeuverType maneuverType = platoon.getManeuverType();

		switch (maneuverType) {
		// FRONT and TAIL behave the same
		case FRONT:
			VehicleWithDistance distanceToLeader = SpatialUtil.getDistanceBetween(leader, me);
			// if behind platoon apply human model until in front of platoon
			if (distanceToLeader.getDistance() < 0) {
				return humanModel.makeDecision();
			} else if (laneDistance == 0 && !me.isInProcessOfLaneChange()) {
				platoon.onVehicleStateReadyLat(me);
				return LaneChangeFactory.decisionStayInLane();
			}
			return createLaneChangeDecisionForPlatoonLaneChange(me, laneDistance);
		case TAIL:
			if (laneDistance == 0 && !me.isInProcessOfLaneChange()) {
				platoon.onVehicleStateReadyLat(me);
				return LaneChangeFactory.decisionStayInLane();
			}
			return createLaneChangeDecisionForPlatoonLaneChange(me, laneDistance);
		case SIDE:
			VehicleWithDistance distanceToTail = SpatialUtil.getDistanceBetween(me, platoon.getTail());
			double humanGap = TrafficUtil.getMinimumSafetyDistance(me.getCurrentSpeed(), me.getLongitudinalControl().getTimeGap(),
					me.getLongitudinalControl().getMinGap());
			if (distanceToTail.getDistance() > humanGap) {
				return humanModel.makeDecision();
			} else if (Math.abs(laneDistance) == 1 && !me.isInProcessOfLaneChange()) {
				platoon.onVehicleStateReadyLat(me);
				return LaneChangeFactory.decisionStayInLane();
			}
			// if vehicle make side join but is already in lane of platoon -> change to left lane
			if (laneDistance == 0) {
				laneDistance = (me.getLaneIndex() == Lane.MOST_LEFT_LANE) ? Lane.TO_RIGHT : Lane.TO_LEFT;
			}
			return createLaneChangeDecisionForPlatoonLaneChange(me, laneDistance);
		}
		// Default case will never be applied
		return LaneChangeFactory.decisionStayInLane();
	}

	/**
	 * Helper for Join state
	 *
	 * @param me
	 *            Vehicle to process
	 * @param leader
	 *            Leader of platoon
	 * @return lane change decision
	 */
	private LaneChangeDecision processJoin(Vehicle me, Vehicle leader) {
		// first/last vehicle in platoon
		if (leader == null) {
			platoon.onVehicleStateReadyLat(me);
			return LaneChangeFactory.decisionStayInLane();
		}
		ManeuverType maneuverType = platoon.getManeuverType();
		switch (maneuverType) {
		case FRONT:
		case TAIL:
			platoon.onVehicleStateReadyLat(me);
			return LaneChangeFactory.decisionStayInLane();
		case SIDE:
			int laneDistance = getLaneDistance(me, leader);
			if (laneDistance == 0 && !me.isInProcessOfLaneChange()) {
				platoon.onVehicleStateReadyLat(me);
				return LaneChangeFactory.decisionStayInLane();
			}
			return createLaneChangeDecisionForPlatoonLaneChange(me, laneDistance);
		}
		// Default case will never be applied
		return LaneChangeFactory.decisionStayInLane();
	}

	/**
	 * Helper for Leave state
	 *
	 * @param me
	 *            Vehicle to process
	 * @param leader
	 *            Leader of platoon
	 * @return lane change decision
	 */
	private LaneChangeDecision processLeave(Vehicle me, Vehicle leader) {
		// first/last vehicle in platoon
		if (leader == null) {
			platoon.onVehicleStateReadyLat(me);
			return LaneChangeFactory.decisionStayInLane();
		}
		ManeuverType maneuverType = platoon.getManeuverType();
		switch (maneuverType) {
		case FRONT:
		case TAIL:
			platoon.onVehicleStateReadyLat(me);
			return LaneChangeFactory.decisionStayInLane();
		case SIDE:
			if (me.getLaneIndex() == leader.getLaneIndex() && !me.isInProcessOfLaneChange()) {

				VehicleWithDistance preceding = SpatialUtil.getDistanceBetween(me, platoon.getPreceding(me));
				VehicleWithDistance following = SpatialUtil.getDistanceBetween(platoon.getFollowing(me), me);

				double gapThreshold = platoon.getDesiredGap(me) - platoon.getManeuverPlatoonDistanceThresholdOffset();

				// only change lane if maneuver gap has opened
				if (preceding.getDistance() > gapThreshold && following.getDistance() > gapThreshold) {
					int direction = (me.getLaneIndex() == Lane.MOST_LEFT_LANE) ? Lane.TO_RIGHT : Lane.TO_LEFT;
					return createLaneChangeDecisionForPlatoonLaneChange(me, direction);
				}
			}
			// ready if other lane then leader and no lane change is in process
			if (me.getLaneIndex() != leader.getLaneIndex() && !me.isInProcessOfLaneChange()) {
				platoon.onVehicleStateReadyLat(me);
				return LaneChangeFactory.decisionStayInLane();
			}
		}
		// Default case will never be applied
		return LaneChangeFactory.decisionStayInLane();
	}

	// ##########################
	// # LANE HELPERS #
	// ##########################

	/**
	 * Helper to create lane change decision for platoon leader base on leader model
	 *
	 * @return restricted lane change decision for leader
	 */
	private LaneChangeDecision checkForLeaderLaneChange() {

		LaneChangeDecision leaderDecision = leaderModel.makeDecision();

		LaneSegment potentialLeftLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + Lane.TO_LEFT);
		boolean addListener = false;
		if (potentialLeftLane != null
				&& !StringUtil.ensureNotNull(me.getProperty(VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name())).equals(Boolean.TRUE.toString())
				&& TrafficUtil.isLaneExitOrEntrance(potentialLeftLane)) {
			me.setProperty(VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name(), Boolean.TRUE.toString());
			addListener = true;
		}
		LaneSegment potentialRightLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + Lane.TO_RIGHT);
		if (potentialRightLane != null
				&& !StringUtil.ensureNotNull(me.getProperty(VehicleProperties.NO_RIGHT_LANE_CHANGE.name())).equals(Boolean.TRUE.toString())
				&& (potentialRightLane.getLaneType() == Lane.Type.ENTRANCE
						|| (me.getRoadSegment().isRightMostLane(me.getLaneIndex()) && TrafficUtil.isLaneExitOrEntrance(potentialRightLane)))) {
			me.setProperty(VehicleProperties.NO_RIGHT_LANE_CHANGE.name(), Boolean.TRUE.toString());
			addListener = true;
		}
		if (addListener) {
			me.addVehicleListener(new VehicleListenerAdapter() {
				@Override
				public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {
					me.getVehicleProperties().remove(VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name());
					me.getVehicleProperties().remove(VehicleProperties.NO_RIGHT_LANE_CHANGE.name());
					me.removeVehicleListener(this);

				}
			});
		}
		if (leaderDecision.getDirection() == Lane.TO_LEFT
				&& PropertyUtil.getBooleanProperty(me.getVehicleProperties(), VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name(), false)) {
			me.clearProperty(VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name());
			me.clearProperty(VehicleProperties.LANE_CHANGE_URGENCY.name());
			return LaneChangeFactory.decisionStayInLane();
		}
		if (leaderDecision.getDirection() == Lane.TO_RIGHT
				&& PropertyUtil.getBooleanProperty(me.getVehicleProperties(), VehicleProperties.NO_RIGHT_LANE_CHANGE.name(), false)) {
			me.clearProperty(VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name());
			me.clearProperty(VehicleProperties.LANE_CHANGE_URGENCY.name());
			return LaneChangeFactory.decisionStayInLane();
		}

		LaneSegment potentialNewLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + leaderDecision.getDirection());
		if (leaderDecision.getDirection() == Lane.NO_CHANGE || !isSafeLaneChangeForWholePlatoon(potentialNewLane) || me.isInProcessOfLaneChange()) {
			return LaneChangeFactory.decisionStayInLane();
		}
		return leaderDecision;
	}

	/**
	 * Helper to create lane change decision for a platoon vehicle
	 *
	 * @param me
	 *            vehicle for lane change
	 * @param distance
	 *            distance to desired lane
	 * @return lane change decision
	 */
	private LaneChangeDecision createLaneChangeDecisionForPlatoonLaneChange(Vehicle me, int distance) {
		int direction = getDirection(distance);
		LaneSegment newLaneSegment = TrafficUtil.getNewLaneSegmentForVehicle(me, direction);

		if (!me.isInProcessOfLaneChange() && newLaneSegment != null
				&& isSafeLaneChangeForPlatoonVehicle(newLaneSegment, platoon.getPreceding(me), platoon.getFollowing(me))) {
			return new LaneChangeDecision(direction, true);
		}
		return LaneChangeFactory.decisionStayInLane();
	}

	/**
	 * Method to check if a platoon lane change is safe for vehicle to a new lane segment
	 *
	 * @param newLaneSegment
	 *            new lane segment
	 * @return true if lane change is possible, else false
	 */
	private boolean isSafeLaneChangeForPlatoonVehicle(LaneSegment newLaneSegment, Vehicle preceding, Vehicle follower) {
		VehicleWithDistance vd_frontVeh = newLaneSegment.frontVehicle(getVehicle());
		VehicleWithDistance vd_backVeh = newLaneSegment.rearVehicle(getVehicle());

		// check distance to front vehicle
		if (vd_frontVeh != null && !vd_frontVeh.getVehicle().isObstacle()) {
			final double gapFront = vd_frontVeh.getDistance();
			// preceding vehicle exist -> check platoon distance
			if (preceding != null && gapFront < platoon.getDesiredGap(me) - platoon.getManeuverPlatoonDistanceThresholdOffset()) {
				return false;
			}
			// preceding vehicle not in platoon or preceding not back vehicle -> check human distance
			if ((preceding == null || !preceding.equals(vd_frontVeh.getVehicle())) && gapFront < data.getsMin()) {
				return false;
			}
		}

		// check distance to vehicle at behind
		if (vd_backVeh != null) {
			final double gapBack = vd_backVeh.getDistance();
			// follower not null check platoon gap
			if (follower != null && gapBack < platoon.getDesiredGap(me) - platoon.getManeuverPlatoonDistanceThresholdOffset()) {
				return false;
			}
			// follower null or follower not back vehicle check human gap
			if ((follower == null || !follower.equals(vd_backVeh.getVehicle())) && gapBack < data.getsMin()) {
				return false;
			}
			// check acceleration of back vehicle
			Vehicle back = vd_backVeh.getVehicle();
			final double backNewAcc = vd_backVeh.getVehicle().getLongitudinalControl().calcAccSolitary(back, back.getLaneSegment(), 1, getVehicle(),
					vd_backVeh.getDistance());
			if (!CheckUtil.isTolerableAcceleration(backNewAcc)) {
				return false;
			}

		}

		// check acceleration of vehicle ahead
		final double meNewAcc = Math.max(data.getMaxDec(), getVehicle().getLongitudinalControl().calcAccSolitary(me, newLaneSegment, 1, null, 0));
		if (meNewAcc >= data.getSafeDec() || meNewAcc > me.getCurrentAcc()) {
			return true;
		}
		return false;
	}

	/**
	 * Helper to check if lane change for whole platoon is safe
	 *
	 * @param newLaneSegment
	 *            lane segment to change to
	 * @return true if lane change is safe, false othewise
	 */
	private boolean isSafeLaneChangeForWholePlatoon(LaneSegment newLaneSegment) {
		List<Vehicle> vehicles = platoon.getAllVehicles();
		for (Vehicle v : vehicles) {
			int direction = newLaneSegment.getLaneIndex() - v.getLaneIndex();
			if (Math.abs(direction) > 1) {
				return false;
			}
			if (!isSafeLaneChangeForPlatoonVehicle(TrafficUtil.getNewLaneSegmentForVehicle(v, direction), platoon.getPreceding(v),
					platoon.getFollowing(v))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Helper to get direction for lane change
	 *
	 * @param me
	 *            current vehicle
	 * @param other
	 *            vehicle to change lane to
	 * @return direction, which contains number of lanes to change
	 */
	private int getLaneDistance(Vehicle me, Vehicle other) {
		return other.getLaneIndex() - me.getLaneIndex();
	}

	/**
	 * Helper to convert a lane distance to a direction
	 *
	 * @param distance
	 *            distance to convert
	 * @return direction based on given distance
	 */
	private int getDirection(int distance) {
		int direction = Lane.NO_CHANGE;
		if (distance < 0) {
			direction = Lane.TO_LEFT;
		} else if (distance > 0) {
			direction = Lane.TO_RIGHT;
		}
		return direction;
	}

}

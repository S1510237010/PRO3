package at.fhhagenberg.mc.traffsim.roadnetwork.lane;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.osm2po.ext.OsmUtil.LaneDirection;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;

/**
 * LaneSegments are part of a road segment and represent a single lane in a single direction. It holds all the vehicles driving currently in
 * this lane.The implementation of {@link Iterable} allows iterating over the vehicles.
 * 
 * 
 * @author Christian B.
 * 
 */
@XStreamAlias("LaneSegment")
public class LaneSegment extends VehiclesLane {
	private RoadSegment roadSegment;
	private LaneDirection restriction;

	/**
	 * Default constructor. Use only if segment is initialized immediately after creation!
	 */
	public LaneSegment() {
	}

	public LaneSegment(RoadSegment roadSegment, int laneIndex, Lane.Type type) {
		this(roadSegment, laneIndex, type, null);
	}

	public LaneSegment(RoadSegment roadSegment, int laneIndex, Lane.Type type, RoadGeometry geom) {
		this.roadSegment = roadSegment;
		this.laneIndex = laneIndex;
		this.setLaneType(type);
		this.roadGeometry = geom;
	}

	public void addVehicle(Vehicle vehicle) {
		this.vehicles.add(0, vehicle);
		vehicle.setLaneSegment(this);
		ensureVehiclesSorted();
	}

	@Override
	public RoadSegment getRoadSegment() {
		return roadSegment;
	}

	public void setRoadSegment(RoadSegment roadSegment) {
		this.roadSegment = roadSegment;
		speedLimit = roadSegment.getSpeedLimitMps();
	}

	public VehicleWithDistance frontVehicle(Vehicle v, double vehiclePosition) {
		return frontVehicle(v, vehiclePosition, 0);
	}

	public VehicleWithDistance frontVehicle(Vehicle v) {
		double translatedPosition = v.getFrontPosition();
		if (!v.isObstacle() && (v.getRoadSegment() == null || v.getRoadSegment().getId() == getRoadSegment().getId())
				&& v.getLaneSegment() != null && v.getLaneSegment() != this) {
			translatedPosition = SpatialUtil.translatePosition(v.getLaneSegment(), this, v.getFrontPosition());
		}
		return frontVehicle(v, translatedPosition);
	}

	/**
	 * @param position
	 * @return the front vehicle of the given position, considering only this lanesegment (no following ones)
	 */
	public VehicleWithDistance frontVehicle(double position) {
		int index = positionBinarySearch(position);
		final int insertionPoint = -index - 1;
		Vehicle result = null;
		if (index >= 0) {
			// exact match found
			if (index + 1 < vehicles.size()) {
				result = vehicles.get(index + 1);
			}
			if (index == 0) {
				/*
				 * added 2013-10-10 special case: one vehicle in lane, which is not v (the vehicle from the parameter from which to find
				 * front). This can be the case if we want to find the first vehicle in a lane
				 */
				result = vehicles.get(0);
			}
		} else if (insertionPoint >= 0 && insertionPoint < vehicles.size()) {
			result = vehicles.get(insertionPoint);
		}
		if (result != null) {
			return new VehicleWithDistance(result, result.getRearPosition() - position);
		}
		return null;
	}

	@Override
	public String toString() {
		StringBuffer vids = new StringBuffer();
		for (Vehicle v : vehicles) {
			vids.append(" - " + v.getUniqueId() + " (" + v.getLabel() + ")");
		}
		return getLaneIndex() + " (RS " + getRoadSegment().getId() + ") - " + vehicles.size() + " vehicles" + vids;
	}

	public LaneDirection getRestriction() {
		return restriction;
	}

	public void setRestriction(LaneDirection restriction) {
		this.restriction = restriction;
	}

}

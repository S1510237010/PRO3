package at.fhhagenberg.mc.traffsim.model.osm;

import java.util.Hashtable;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.model.geo.Location;

/**
 * Implementation of an {@link OSMNode}. A node consists of an unique
 * identifier, a specific location and may contain a certain number of
 * additional parameter tags.
 *
 * @author Manuel Lindorfer
 *
 */
public class OSMNode {

	/** The node's unique identifier */
	private long id;

	/** The node's location */
	private Location location;

	/** The tags for this node as key-value-pairs */
	private Map<String, String> tags = new Hashtable<String, String>();

	/** The node's (OSM) version */
	private String version;

	/**
	 * Creates a new {@link OSMNode} with the given x- and y-coordinate.
	 *
	 * @param x
	 *            the x-coordinate of the node's location
	 * @param y
	 *            the y-coordinate of the node's location
	 */
	public OSMNode(double x, double y) {
		location = new Location(x, y);
	}

	/**
	 * Creates a new {@link OSMNode} with the given latitude, longitude and
	 * unique identifier.
	 *
	 * @param lat
	 *            the latitude of the node's location
	 * @param lon
	 *            the longitude of the node's location
	 * @param id
	 *            the unique node identifier
	 */
	public OSMNode(double lat, double lon, long id) {
		location = new Location(lat, lon);
		this.id = id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		OSMNode other = (OSMNode) obj;

		if (id != other.id) {
			return false;
		}

		return true;
	}

	/**
	 * Get's the node's unique identifier.
	 *
	 * @return the node's unique identifier
	 */
	public long getId() {
		return id;
	}

	/**
	 * Get's the node's latitude.
	 *
	 * @return the node's latitude
	 */
	public double getLatitude() {
		return location.x;
	}

	/**
	 * Get's the node's longitude.
	 *
	 * @return the node's longitude
	 */
	public double getLongitude() {
		return location.y;
	}

	/**
	 * Get's the set of additional tags of this node.
	 *
	 * @return the set of tags associated with the node
	 */
	public Map<String, String> getTags() {
		return tags;
	}

	/**
	 * Get's the node's (OSM) version.
	 *
	 * @return the node's (OSM) version
	 */
	public String getVersion() {
		return version;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ id >>> 32);
		return result;
	}

	/**
	 * Updates the node tag identified by the given key with the given value.
	 *
	 * @param key
	 *            the key identifying the tag to be updated
	 * @param value
	 *            the new tag value
	 */
	public void putTag(String key, String value) {
		tags.put(key, value);
	}

	/**
	 * Set's the set of additional tags of this node.
	 *
	 * @param _tags
	 *            the new tags for this node
	 */
	public void setTags(Map<String, String> _tags) {
		tags = _tags;
	}

	/**
	 * Set's the node's (OSM) version.
	 *
	 * @param _version
	 *            the new (OSM) version
	 */
	public void setVersion(String _version) {
		version = _version;
	}

	@Override
	public String toString() {
		return "[Node " + id + " lat:" + location.x + " lon:" + location.y + "]";
	}
}
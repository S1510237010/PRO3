package at.fhhagenberg.mc.traffsim.communication;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

import at.fhhagenberg.mc.traffsim.communication.messaging.Message;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.IntervalUpdateThread;
import at.fhhagenberg.mc.traffsim.model.PropertyValues;
import at.fhhagenberg.mc.traffsim.model.ThreadConstants;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.types.NamedThreadFactory;
import at.fhhagenberg.mc.traffsim.vehicle.CommVehicle;
import at.fhhagenberg.mc.util.StringUtil;
import at.fhhagenberg.mc.util.types.IDisposable;

public class Communicator extends IntervalUpdateThread implements IDisposable {

	private String modelId;

	private Queue<MessageTransfer> messageQueue = new DelayQueue<>();
	private List<ICommunicationPartner> receivers = new CopyOnWriteArrayList<>();

	private Map<Long, ICommunicationPartner> vehicleReceivers = new ConcurrentHashMap<>();
	private AtomicLong totalBytes = new AtomicLong(0);
	private AtomicLong totalSubmittedMsg = new AtomicLong(0);
	private AtomicLong totalTransmittedMsg = new AtomicLong(0);

	private ExecutorService exec;

	private boolean delayEnabled = PropertyValues.DEFAULT_COMM_DELAY_ENABLED;

	public Communicator(String modelname, String name, long updateIntervalMillis) {
		super(name, updateIntervalMillis, false);
		this.modelId = modelname;
		exec = Executors.newFixedThreadPool(PreferenceUtil.getBoolean(IPreferenceConstants.SINGLETHREADED_EXECUTION) ? 1 : 2,
				new NamedThreadFactory(StringUtil.createThreadName(modelId, ThreadConstants.COMMUNICATOR_NAME)));
	}

	/**
	 * Enable or disable asynchronous communication with delay (greater or equal to zero)
	 *
	 * @param enabled
	 */
	public void setDelayEnabled(boolean enabled) {
		this.delayEnabled = enabled;
	}

	public boolean sendMessage(ICommunicationPartner sender, ICommunicationPartner receiver, Message<?> msg, IChannelModel model) {
		totalBytes.addAndGet(msg.getPayload().getSize());
		totalSubmittedMsg.incrementAndGet();
		MessageTransfer msgTr = new MessageTransfer(sender, receiver, msg);
		if (delayEnabled) {
			if (model == null || model.isSuccessful()) {
				long delay = model != null ? model.getNextDelay() : 0;
				msgTr.setDelay(delay, this);
				return messageQueue.add(msgTr);
			}
			return false;
		} else {
			receiver.messageReceived(msgTr);
			totalTransmittedMsg.incrementAndGet();
			return true;
		}
	}

	public boolean sendMessage(ICommunicationPartner sender, Long receiverVehicleId, Message<?> msg, IChannelModel model) {
		return sendMessage(sender, vehicleReceivers.get(receiverVehicleId), msg, model);
	}

	public void registerCommunicationReceiver(ICommunicationPartner receiver) {
		if (receiver != null) {
			this.receivers.add(receiver);
			if (receiver instanceof CommVehicle) {
				vehicleReceivers.put(((CommVehicle) receiver).getUniqueId(), receiver);
			}
		} else {
			Logger.logError("Cannot register unknown communication receiver!");
		}
	}

	@Override
	public void doWorkWaitForFinish() {
		List<Callable<Object>> executables = new ArrayList<>();
		MessageTransfer msg;
		while ((msg = messageQueue.poll()) != null) {
			final MessageTransfer finalMsg = msg;
			executables.add(new Callable<Object>() {
				@Override
				public Object call() throws Exception {
					if (receivers.contains(finalMsg.getReceiver())) {
						finalMsg.getReceiver().messageReceived(finalMsg);
						totalTransmittedMsg.incrementAndGet();
					} else {
						// no receiver registered - do something?
						Logger.logError("Could not find registration for intended receiver " + finalMsg.getReceiver().getCommName());
					}
					return null;
				}
			});
		}
		executeTasks(exec, executables);
	}

	public int getMessageQueueSize() {
		return messageQueue.size();
	}

	public long getTotalBytes() {
		return totalBytes.get();
	}

	public long getTotalSubmittedMsg() {
		return totalSubmittedMsg.get();
	}

	public long getTotalTransmittedMsg() {
		return totalTransmittedMsg.get();
	}

	public Queue<MessageTransfer> getMessageQueue() {
		return messageQueue;
	}

	@Override
	public void dispose() {
		receivers.clear();
		exec.shutdown();
	}

}

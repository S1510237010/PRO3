package at.fhhagenberg.mc.traffsim.model.batch;

import java.io.File;
import java.util.Collection;
import java.util.List;

/**
 * Dummy class which does nothing
 * 
 * @author Christian Backfrieder
 *
 */
public class DummyBatchListener implements IBatchListener {

	@Override
	public void batchStarted(List<File> originalConfigurations, List<ScheduledSimulation> currentScheduledSimulations,
			BatchExecutor executor) {

	}

	@Override
	public void currentConfigurationsChanged(List<File> newConfigurations, File active) {

	}

	@Override
	public void batchFinished() {

	}

	@Override
	public void logLine(String line) {

	}

	@Override
	public void currentSimulationsChanged(List<ScheduledSimulation> newScheduledSimulations, Collection<ScheduledSimulation> active,
			boolean clearOld) {

	}

}

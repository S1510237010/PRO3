package at.fhhagenberg.mc.traffsim.roadnetwork.detector;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterators;

import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector.DetectionMode;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class SignalPoint {

	private double position;
	private Predicate<Vehicle> passingPredicate;
	private Predicate<Vehicle> presencePredicate;
	private double simulationTime;

	private Set<Vehicle> vehiclesPassed = new LinkedHashSet<>();
	private Set<Vehicle> vehiclesPresent = new LinkedHashSet<>();

	public SignalPoint() {
		position = 0;
		passingPredicate = new VehiclePassedPosition(0, DetectionMode.DUAL);
		presencePredicate = new VehiclePresenceDetection(0);
	}

	public SignalPoint(double position, DetectionMode detectionMode) {
		this.position = position;
		passingPredicate = new VehiclePassedPosition(position, detectionMode);
		presencePredicate = new VehiclePresenceDetection(position);
	}

	public void registerVehicles(double simulationTime, Collection<Vehicle> vehicles) {
		this.simulationTime = simulationTime;
		Iterators.addAll(vehiclesPassed, Iterators.filter(vehicles.iterator(), passingPredicate));
		Iterators.addAll(vehiclesPresent, Iterators.filter(vehicles.iterator(), presencePredicate));
	}

	public double getPosition() {
		return position;
	}

	public Collection<Vehicle> getPassedVehicles() {
		return vehiclesPassed;
	}

	public Collection<Vehicle> getPresentVehicles() {
		return vehiclesPresent;
	}

	public double getSimulationTimeAtRegistration() {
		return simulationTime;
	}

	public void clear() {
		vehiclesPassed.clear();
		vehiclesPresent.clear();
	}
}

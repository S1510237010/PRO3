package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.BatteryDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ElectricEngineDataBean;

/**
 * This class manages the energy consumption of an electric motor.
 *
 * @author Anna
 *
 */
public class ElectricEngineModel {

	/**
	 * Battery of the electric vehicle.
	 */
	private Batterie mBat;
	/**
	 * Gear efficiency of electric vehicle.
	 */
	private final double mGEAREFF;
	/**
	 * radius of vehicle wheels.
	 */
	private final double mRADIUS;
	/**
	 * copper losses constant
	 */
	private final double mKC;
	/**
	 * iron losses constant
	 */
	private final double mKI;
	/**
	 * windage losses constant.
	 */
	private final double mKW;
	/**
	 * constant losses.
	 */
	private final double mCONSTLOSS;
	/**
	 * Accessery voltage.
	 */
	private final double mACCESSERY = 12;
	/**
	 * time since last calculation.
	 */
	private double mTime;

	public ElectricEngineModel(ElectricEngineDataBean _bean, BatteryDataBean _batbean) {
		mGEAREFF = _bean.getGearEff();
		mRADIUS = _bean.getRadius();
		mKC = _bean.getKC();
		mKI = _bean.getKI();
		mKW = _bean.getKW();
		mCONSTLOSS = _bean.getConstLoss();
		mTime = System.currentTimeMillis();
		mBat = new Batterie(_batbean);
	}

	/**
	 * This method calculates the angular speed of the vehicle.
	 *
	 * @param _v
	 *            current velocity of vehicle.
	 * @return angular speed of vehicle.
	 */
	private double getAngularSpeed(double _v) {
		return _v / mRADIUS;
	}

	/**
	 * This method calculates the torque of the vehicle.
	 *
	 * @param _power
	 *            current power on the vehicle.
	 * @param _angular
	 *            angular speed of vehicle.
	 * @return torque of vehicle.
	 */
	private double getTorque(double _power, double _angular) {
		return _power / _angular;
	}

	/**
	 * This method calculates the motor efficiency of the vehicle.
	 *
	 * @param _torque
	 *            Torque of vehicle
	 * @param _angular
	 *            angular speed of vehicle
	 * @return motor efficiency of vehicle.
	 */
	private double getMotorEff(double _torque, double _angular) {
		double motoreff = _torque * _angular;

		double loss = motoreff + mKC * Math.pow(_torque, 2) + mKI * _angular + mKW * Math.pow(_angular, 3) + mCONSTLOSS;

		return motoreff / loss;
	}

	/**
	 * @param _power
	 *            power needed by electric motor.
	 * @return motorout power when vehicle doesnt break.
	 */
	private double getMotorOut(double _power) {
		return _power / mGEAREFF;
	}

	/**
	 * @param _power
	 *            power needed by electric motor.
	 * @param _v
	 *            current velocity.
	 * @return motorin power when vehicle doesnt break.
	 */
	private double getMotorIn(double _power, double _v) {

		double motorOut = getMotorOut(_power);
		double angular = getAngularSpeed(_v);
		double torque = getTorque(_power, angular);
		double motoreff = getMotorEff(torque, angular);

		return motorOut / motoreff;
	}

	/**
	 * @param _power
	 *            power needed by electric motor.
	 * @param _v
	 *            current velocity.
	 * @return motorin power when vehicle breaks.
	 */
	private double getMotorInBreak(double _power, double _v) {

		double motorOut = getMotorOutBreak(_power);
		double angular = getAngularSpeed(_v);
		double torque = getTorque(_power, angular);
		double motoreff = getMotorEff(torque, angular);

		return motorOut * motoreff;
	}

	/**
	 *
	 * @param _power
	 *            power needed by electric motor.
	 * @return motorout when vehicle breaks.
	 */
	private double getMotorOutBreak(double _power) {
		return _power * mGEAREFF;
	}

	/**
	 * calculates the total required power from the motor.
	 *
	 * @param _power
	 *            power needed to overcome.
	 * @param _v
	 *            current velocity.
	 * @param _break
	 *            if vehicle breaks.
	 * @return total required power.
	 */
	private double getRequPower(double _power, double _v, boolean _break) {
		if (_break) {
			return mACCESSERY + getMotorInBreak(_power, _v);
		} else {
			return mACCESSERY + getMotorIn(_power, _v);
		}
	}

	/**
	 *
	 * This method can be called by the other classes and it calculates the total consumption of vehicle at a certain speed.
	 *
	 * @param _power
	 *            power needed to overcome.
	 * @param _v
	 *            current velocity.
	 * @param _break
	 *            if vehicle breaks or not.
	 * @return consumed Ampere by battery.
	 */
	public double getConsumption(double _power, double _v, boolean _break) {

		double seconds = System.currentTimeMillis() - mTime;

		double Pbat = getRequPower(_power, _v, _break);
		double I = mBat.getCurrentI(Pbat);
		double control = mBat.changeCharge(I, seconds / 1000);

		mTime = System.currentTimeMillis();

		return control;
	}

}

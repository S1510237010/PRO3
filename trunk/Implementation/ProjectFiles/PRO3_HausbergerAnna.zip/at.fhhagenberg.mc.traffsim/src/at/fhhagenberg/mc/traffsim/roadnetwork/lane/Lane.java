package at.fhhagenberg.mc.traffsim.roadnetwork.lane;

/**
 * <p>
 * Lane value constants.
 * </p>
 * <p>
 * Lanes are numbered from the inside lane to the outside lane. So, for example, on a three lane road LANE1 is the inside lane, LANE2 is the
 * middle lane and LANE3 is the outside lane.
 * </p>
 * Lane numbering is independent of whether traffic drives on the right or the left, indeed references to "right lanes" and "left lanes" is
 * conscientiously eschewed.
 * <p>
 * </p>
 */
public class Lane {
	public static final int NONE = -2;

	public final static int TO_LEFT = -1;
	public final static int TO_RIGHT = 1;
	public final static int NO_CHANGE = 0;
	/** index of left lane */
	public final static int MOST_LEFT_LANE = 0;

	/**
	 * Lane type.
	 */
	public static enum Type {
		/**
		 * Lane for normal traffic.
		 */
		TRAFFIC,
		/**
		 * Entrance (acceleration) lane.
		 */
		ENTRANCE,
		/**
		 * Exit (deceleration) lane.
		 */
		EXIT,
		/**
		 * Restricted lane, eg bus or multiple-occupancy vehicle lane.
		 */
		RESTRICTED,
		/**
		 * Bicycle lane.
		 */
		BICYCLE,

		/** restricted turns to left */
		TO_LEFT,

		/** restricted turns to right */
		TO_RIGHT;

	}

}

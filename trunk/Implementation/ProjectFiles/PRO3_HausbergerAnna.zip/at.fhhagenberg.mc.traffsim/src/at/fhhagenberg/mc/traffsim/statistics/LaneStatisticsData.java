package at.fhhagenberg.mc.traffsim.statistics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;

public class LaneStatisticsData {
	List<Date> time = new ArrayList<>();
	List<Long> vehicleIds = new ArrayList<>();
	List<VehicleType> type = new ArrayList<>();
	List<Double> speed = new ArrayList<>();

	public Date getStartTime() {
		return time.isEmpty() ? null : time.get(0);
	}

	public List<Date> getTime() {
		return time;
	}

	public List<Long> getVehicleIds() {
		return vehicleIds;
	}

	public List<VehicleType> getType() {
		return type;
	}

	public void vehiclePassed(Date date, Vehicle vehicle) {
		time.add(date);
		vehicleIds.add(vehicle.getUniqueId());
		type.add(vehicle.getType());
		speed.add(vehicle.getCurrentSpeed());
	}

	/**
	 * Merge two statistics data, sort all lists correctly after date and creates new {@link LaneStatisticsData} object containing both
	 * 
	 * @param other
	 * @return merged data, sorted after date
	 */
	public LaneStatisticsData merge(LaneStatisticsData other) {
		final LaneStatisticsData merged = new LaneStatisticsData();
		merged.time.addAll(time);
		merged.time.addAll(other.getTime());
		merged.type.addAll(type);
		merged.type.addAll(other.getType());
		merged.vehicleIds.addAll(vehicleIds);
		merged.vehicleIds.addAll(other.vehicleIds);
		merged.speed.addAll(speed);
		merged.speed.addAll(other.speed);

		Collections.sort(merged.type, new Comparator<VehicleType>() {
			@Override
			public int compare(VehicleType o1, VehicleType o2) {
				return LaneStatisticsData.this.compare(o1, o2, merged.type, merged.time);
			}
		});

		Collections.sort(merged.vehicleIds, new Comparator<Long>() {

			@Override
			public int compare(Long o1, Long o2) {
				return LaneStatisticsData.this.compare(o1, o2, merged.vehicleIds, merged.time);
			}
		});
		Collections.sort(merged.speed, new Comparator<Double>() {

			@Override
			public int compare(Double o1, Double o2) {
				return LaneStatisticsData.this.compare(o1, o2, merged.speed, merged.time);
			}
		});
		Collections.sort(merged.time);

		return merged;
	}

	private int compare(Object o1, Object o2, List<?> coll, List<Date> time) {
		return time.get(coll.indexOf(o1)).compareTo(time.get(coll.indexOf(o2)));
	}

}

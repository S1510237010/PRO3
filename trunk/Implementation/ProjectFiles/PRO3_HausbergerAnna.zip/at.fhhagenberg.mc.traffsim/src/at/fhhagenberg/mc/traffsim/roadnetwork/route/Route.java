package at.fhhagenberg.mc.traffsim.roadnetwork.route;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.ui.IRouteTraversalListener;
import at.fhhagenberg.mc.util.CollectionUtil;

public class Route implements IRoute {
	private List<Long> routingIds = new ArrayList<>();
	private List<Boolean> isReverse = new ArrayList<>();
	private long id;
	private RoadSegment initialSegment;
	private RoadSegment targetSegment;

	private static long nextId = 0;

	private Set<IRouteTraversalListener> routeTraversalListeners;

	/**
	 * Copy Constructor
	 * 
	 * @param route
	 *            a <code>IRoute</code> object
	 */
	public Route(IRoute route) {
		this(route, new ArrayList<Long>(route.getRouteIds()), new ArrayList<Boolean>(route.getIsReverse()));
	}

	/**
	 * Copy constructor, overriding route Ids
	 * 
	 * @param route
	 * @param routeIds
	 * @param isReverse
	 */
	public Route(IRoute route, List<Long> routeIds, List<Boolean> isReverse) {
		this();
		if (route != null) {
			this.routingIds = routeIds;
			this.initialSegment = route.getInitialSegment();
			this.isReverse = isReverse;
			this.targetSegment = route.getTargetSegment();
		}
	}

	public Route() {
		id = nextId++;
		routeTraversalListeners = new HashSet<>();
	}

	public Route(List<Long> routingIds, long id) {
		setId(id);
		routeTraversalListeners = new HashSet<>();
		this.routingIds = routingIds;
	}

	public Route(List<Long> routingIds) {
		this();
		this.routingIds = routingIds;
	}

	public void setRoutingIds(List<Long> roadSegmentIds) {
		this.routingIds = roadSegmentIds;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute#getNextRoutingId()
	 */
	@Override
	public long getNextRoutingId() {
		if (routingIds.size() > 0) {
			return routingIds.get(0);
		}
		return -1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute# removeNextSegmentIdIfMatches(int)
	 */
	@Override
	public long removeNextSegmentIdIfMatches(long id) {
		if (routingIds.size() > 0 && routingIds.get(0) == id) {
			if (isReverse.size() > 0) {
				isReverse.remove(0);
			}

			notifyRouteTraversalListeners();
			return routingIds.remove(0);
		}
		return -1;
	}

	private void notifyRouteTraversalListeners() {
		for (IRouteTraversalListener listener : routeTraversalListeners) {
			listener.onRoutingIdTraversed();
		}
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
		Route.nextId = id + 1;
	}

	@Override
	public List<Long> getRouteIds() {
		return routingIds;
	}

	@Override
	public long getRoutingIdAfter(long id) {
		int index = routingIds.indexOf(id);
		if (index < routingIds.size() - 1 && index >= 0) {
			return routingIds.get(index + 1);
		}
		return getNextRoutingId();
	}

	@Override
	public RoadSegment getInitialSegment() {
		return initialSegment;
	}

	public void setInitialRoadSegment(RoadSegment seg) {
		initialSegment = seg;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((routingIds == null) ? 0 : routingIds.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Route other = (Route) obj;
		if (routingIds == null) {
			if (other.routingIds != null)
				return false;
		} else if (!routingIds.equals(other.routingIds))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return Arrays.toString(CollectionUtil.toPrimitiveLongArray(routingIds));
	}

	@Override
	public RoadSegment getTargetSegment() {
		return targetSegment;
	}

	public void setTargetSegment(RoadSegment targetSegment) {
		this.targetSegment = targetSegment;
	}

	public List<Boolean> getIsReverse() {
		return isReverse;
	}

	public void setIsReverse(List<Boolean> isReverse) {
		this.isReverse = isReverse;
	}

	@Override
	public void addRouteTraversalListener(IRouteTraversalListener listener) {
		if (listener != null && !routeTraversalListeners.contains(listener)) {
			routeTraversalListeners.add(listener);
		}
	}

	@Override
	public void removeRouteTraversalListener(IRouteTraversalListener listener) {
		if (listener != null && routeTraversalListeners.contains(listener)) {
			routeTraversalListeners.add(listener);
		}
	}

}

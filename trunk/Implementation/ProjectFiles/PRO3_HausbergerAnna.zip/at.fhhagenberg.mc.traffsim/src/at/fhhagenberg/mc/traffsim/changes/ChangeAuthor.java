package at.fhhagenberg.mc.traffsim.changes;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("author")
public class ChangeAuthor {
	private String fullName;
	private String absoluteUrl;
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getAbsoluteUrl() {
		return absoluteUrl;
	}
	public void setAbsoluteUrl(String absoluteUrl) {
		this.absoluteUrl = absoluteUrl;
	}
}

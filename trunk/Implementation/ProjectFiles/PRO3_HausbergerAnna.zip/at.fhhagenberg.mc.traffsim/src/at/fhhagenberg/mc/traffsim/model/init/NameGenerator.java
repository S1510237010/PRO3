package at.fhhagenberg.mc.traffsim.model.init;

import java.util.Properties;

import at.fhhagenberg.mc.traffsim.data.beans.ParameterBean;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.PropertyValues;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * Generates a simulation name and simulation set subfolder out of the parameters
 *
 * @author Christian Backfrieder
 *
 */
public class NameGenerator {
	public enum NameFormat {
		FILENAME, LABEL;
	}

	private static final String UNDEFINED = PropertyValues.UNDEFINED;
	private static final String SEPARATOR = "_";
	private static final String SPACE = " ";

	public static String getFormattedIdentifier(String propId, Properties properties, NameFormat format) {
		StringBuilder b = new StringBuilder();
		String rrMode = PropertyUtil.getStringProperty(properties, PropertyKeys.REROUTING_MODE, UNDEFINED);
		b.append("TS-");
		b.append(propId);
		b.append("_");
		b.append(rrMode);
		if (!rrMode.equals(PropertyValues.DISABLED)) {
			// cost evaluation
			b.append("_CostE-");
			String costEval = PropertyUtil.getStringProperty(properties, PropertyKeys.ROUTING_COST_EVALUATION, UNDEFINED);
			b.append(shorten(costEval, format));
			// congestion evaluation
			b.append("_CongE-");
			String congEval = PropertyUtil.getStringProperty(properties, PropertyKeys.CONGESTION_EVALUATION, UNDEFINED);
			b.append(shorten(congEval, format));
			if (!congEval.equals(PropertyValues.GLOBAL)) {
				b.append("_CongThres-");
				if (congEval.equals(PropertyValues.GREENSHIELD)) {
					b.append(PropertyUtil.getDoubleProperty(properties, PropertyKeys.GREENSHIELD_CONGESTION_THRESHOLD_DELTA, -1.0));
				} else if (congEval.equals(PropertyValues.SPEED_AVERAGE)) {
					b.append(PropertyUtil.getDoubleProperty(properties, PropertyKeys.SPEED_AVERAGE_CONGESTION_THRESHOLD, -1.0));
				} else {
					b.append(UNDEFINED);
				}
			}
			b.append("_HEUR-");
			String heur = PropertyUtil.getStringProperty(properties, PropertyKeys.REROUTING_FOOTPRINT_HEURISTICS, UNDEFINED);
			b.append(shorten(heur, format));
			if (heur.equals(PropertyValues.REROUTING_HEURISTICS_FOOTPRINT_PREDICTION)) {
				b.append("_THVPS-");
				b.append(PropertyUtil.getDoubleProperty(properties, PropertyKeys.CONGESTION_THRESHOLD_VEHICLES_PER_SECOND, -1.0));
				b.append("_FPres-");
				b.append(PropertyUtil.getIntProperty(properties, PropertyKeys.REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_TIME_RESOLUTION, 0));
			}
			b.append("_RR-interval_");
			b.append(PropertyUtil.getIntProperty(properties, PropertyKeys.REROUTING_UPDATE_TIME, 0));
		}
		if (format == NameFormat.LABEL) {
			return b.toString().replaceAll("_", " ");
		}
		return b.toString();
	}

	private static String shorten(String fullString, NameFormat format) {
		if (format == NameFormat.LABEL) {
			return fullString;
		}
		if (fullString.equals(PropertyValues.GREENSHIELD)) {
			return "gs";
		} else if (fullString.equals(PropertyValues.GLOBAL)) {
			return "gl";
		} else if (fullString.equals(PropertyValues.SPEED_AVERAGE)) {
			return "sa";
		} else if (fullString.equals(PropertyValues.REROUTING_HEURISTICS_FOOTPRINT_PREDICTION)) {
			return "fpred";
		} else if (fullString.equals(PropertyValues.REROUTING_HEURISTICS_ROUTE_FOOTPRINT)) {
			return "rfp";
		} else {
			return fullString;
		}
	}

	/**
	 * Get identifier for parameter set, using name and label of the {@link ParameterBean}
	 *
	 * @param propId
	 *            the property id
	 * @param bean
	 *            the bean to read name and albel from
	 * @param format
	 *            {@link NameFormat#FILENAME} without spaces or {@link NameFormat#LABEL}
	 * @return formatted string
	 */
	public static String getIdentifier(String propId, ParameterBean bean, NameFormat format) {
		StringBuilder b = new StringBuilder();
		b.append("TS-");
		b.append(propId);
		b.append(SPACE);
		String name = format == NameFormat.FILENAME ? StringUtil.ensureNotEmpty(bean.getName(), "UNNAMED").replace(' ', '-')
				: StringUtil.ensureNotEmpty(bean.getName(), "<unnamed>");
		b.append(name);
		if (StringUtil.isNotNullOrEmpty(bean.getLabel())) {
			b.append(SEPARATOR);
			String lbl = format == NameFormat.FILENAME ? bean.getLabel().replace(' ', '-') : bean.getLabel();
			b.append(lbl);
		}
		if (format == NameFormat.FILENAME) {
			return b.toString().replaceAll(SPACE, SEPARATOR);
		}
		return b.toString();
	}
}

package at.fhhagenberg.mc.traffsim.statistics.events;

import java.util.Date;

public class CongestionEvent extends Event {

	private static final long serialVersionUID = -2639929963461136590L;

	private long segmentId;
	private long nodeId;
	private double severity;
	private Date prediction;

	/**
	 * No-arg constructor. for serialization ONLY!!
	 */
	public CongestionEvent() {
	}

	public CongestionEvent(String modelId, Date currentSimTime, EventType type, String typeInfo, String message, long nodeId, long segId,
			double severity, Date prediction) {
		super(modelId, currentSimTime, type, typeInfo, message, true);
		this.nodeId = nodeId;
		this.segmentId = segId;
		this.severity = severity;
		this.prediction = prediction;
	}

	public long getSegmentId() {
		return segmentId;
	}

	public long getNodeId() {
		return nodeId;
	}

	public double getSeverity() {
		return severity;
	}

	public Date getPrediction() {
		return prediction;
	}

}

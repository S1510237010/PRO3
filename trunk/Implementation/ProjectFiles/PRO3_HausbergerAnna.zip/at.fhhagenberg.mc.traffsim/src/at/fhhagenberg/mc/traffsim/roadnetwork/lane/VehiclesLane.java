package at.fhhagenberg.mc.traffsim.roadnetwork.lane;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import at.fhhagenberg.mc.traffsim.model.IRoadStatisticsChangedListener;
import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.statistics.LaneStatisticsData;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.util.CollectionUtil;

public abstract class VehiclesLane implements Iterable<Vehicle> {
	public static long NEXT_ID = 0;

	protected List<Vehicle> vehicles = new CopyOnWriteArrayList<>();
	protected LaneSegment sourceLaneSegment;
	protected LaneSegment sinkLaneSegment;
	protected RoadGeometry roadGeometry;
	private Lane.Type laneType;
	protected int laneIndex;
	private List<Vector> leftEdge;
	private List<Vector> rightEdge;
	private double laneWidth = TrafficDefaults.DEFAULT_LANE_WIDTH;
	private LaneStatisticsData statisticsData = new LaneStatisticsData();
	private IRoadStatisticsChangedListener listener;
	private long id = NEXT_ID++;

	/** cache for the speed limit */
	protected double speedLimit = 0;

	public VehicleWithDistance frontVehicle(Vehicle v, double position, double distance) {
		int index = positionBinarySearch(position);
		final int insertionPoint = -index - 1;
		Vehicle result = null;
		if (index >= 0) {
			// exact match found
			if (index + 1 < vehicles.size()) {
				result = vehicles.get(index + 1);
			}
			if (index == 0 && !v.equals(vehicles.get(0))) {
				/*
				 * added 2013-10-10 special case: one vehicle in lane, which is not v (the vehicle from the parameter from which to find
				 * front). This can be the case if we want to find the first vehicle in a lane
				 */
				result = vehicles.get(0);
			}
		} else if (insertionPoint >= 0 && insertionPoint < vehicles.size()) {
			result = vehicles.get(insertionPoint);
		}
		if (result != null && true) {
			return new VehicleWithDistance(result, distance + result.getRearPosition() - position);
		}
		// TODO: intelligently detect ring, or at least compare distance with constant
		if (sinkLaneSegment != null && distance < 1000) {
			distance = distance + roadGeometry.getRoadLength() - position;
			return sinkLaneSegment.frontVehicle(v, 0, distance);
		} else if (distance >= 1000) {
			return null;
		}
		RoadSegment roadSeg = getRoadSegment();
		if (roadSeg != null) {
			AbstractJunction junc = roadSeg.getJunction();
			if (junc != null) {
				if (v.getLaneSegment() != null && v.getRoute() != null) {
					// Check for vehicles in junction, but the rear end is still in road segment
					double minRearPos = Double.MAX_VALUE;
					Vehicle rearVehicle = null;
					for (JunctionConnector connFromThisLane : junc.getConnectors(this)) {
						Vehicle curVehicle = connFromThisLane.frontVehicle();
						if (curVehicle != null) {
							double curRearPos = curVehicle.getRearPosition();
							if (curRearPos < minRearPos) {
								minRearPos = curRearPos;
								rearVehicle = curVehicle;
							}
						}
					}
					JunctionConnector conn = junc.getConnector(roadSeg.getRoutingId(), v.getRoute().getRoutingIdAfter(roadSeg.getRoutingId()),
							getLaneIndex());
					distance = distance + roadGeometry.getRoadLength() - position;
					if (minRearPos < 0) {
						if (conn != null) {
							// also perform canEnter check in order to register vehicle for entry check
							conn.getJunction().canEnter(v, conn.getSourceLaneSegment(), conn.getSinkLaneSegment(), distance);
						}
						return new VehicleWithDistance(rearVehicle, v.hasBoundsPolygon()
								? SpatialUtil.getShortestDistance(v.getBoundsPolygon(), rearVehicle.getBoundsPolygon()) : distance);
					}
					// check for junction entry
					if (conn != null) {
						if (!conn.getJunction().canEnter(v, conn.getSourceLaneSegment(), conn.getSinkLaneSegment(), distance)) {
							Vehicle junctionFront = conn.frontVehicle(); /* ask for front vehicle in connector */
							if (junctionFront != null && junctionFront.getRearPosition() < 0) {
								// vehicle in junction has bounds out of junction area, we have to stop before
								return conn.frontVehicle(v, 0, distance);
							} else {
								/* no vehicle in currenct junction connector, or vehicle's bounds fully inside */
								return new VehicleWithDistance(VehicleFactory.createObstacle(0), distance
										+ v.getLongitudinalControl().getMinGap() * 0.6 /* shorten gap between vehicle and junction */);
							}
						} else {
							/* junction allows entry */
							if (!junc.getVehicles().isEmpty()) {
								if (junc.getVehicles().stream().allMatch(juncVeh -> juncVeh.getLaneSegment().equals(conn))) {
									return new VehicleWithDistance(conn.rearVehicle(), distance + conn.rearVehicle().getRearPosition());
								}
								for (Vehicle vInJunc : junc.getVehicles()) {
									if (!vInJunc.getLaneSegment().equals(conn)
											&& SpatialUtil.intersects(vInJunc.getBoundsPolygon(), conn.getBounds())) {
										/* a vehicle which is currently inside the junction intersects with the vehicle asking for grant */
										return new VehicleWithDistance(vInJunc, distance + vInJunc.getRearPosition());
									}
								}
							}
							for (RoadSegment rs : junc.getSegmentsOut()) {
								for (LaneSegment ls : rs.getLaneSegments()) {
									// get last vehicle from ls out
									Vehicle vInLsOut = ls.frontVehicle();
									if (vInLsOut != null && !Vehicle.isObstacle(vInLsOut.getType())
											&& vInLsOut.getFrontPosition() < vInLsOut.getLength() * 2
											&& SpatialUtil.intersects(vInLsOut.getBoundsPolygon(), conn.getBounds())) {
										/*
										 * a vehicle which is already outside the junction, but its bounds intersect with the used junction
										 * connector
										 */
										JunctionConnector intersectingConn = junc.getConnector(
												conn.getSourceLaneSegment().getRoadSegment().getRoutingId(), ls.getRoadSegment().getRoutingId());
										if (intersectingConn != null) {

											return new VehicleWithDistance(vInLsOut,
													distance + intersectingConn.getRoadLength() + vInLsOut.getRearPosition());
										} else {
											// intersecting connector can be null if the intersecting vehicle is located in a lane
											// segment
											// to which no
											// connector leads -> if yes, simply calculate distance between two vehicles
											return new VehicleWithDistance(vInLsOut,
													SpatialUtil.getShortestDistance(vInLsOut.getBoundsPolygon(), v.getBoundsPolygon()));
										}
									}
								}
							}
						}
						return /* junction front */conn.frontVehicle(v, 0, distance);
					} else {
						return new VehicleWithDistance(VehicleFactory.createObstacle(0),
								distance + v.getLongitudinalControl().getMinGap() * 0.6 /* shorten gap between vehicle and junction */);
					}

				}

			}
		}
		return null;
	}

	protected VehicleWithDistance rearVehicle(double position, double distance, double vehicleLength) {
		final int index = positionBinarySearch(position);
		final int insertionPoint = -index - 2;
		Vehicle result = null;
		if (index > 0) {
			// exact match found
			result = vehicles.get(index - 1);
		} else if (insertionPoint >= 0 && insertionPoint < vehicles.size()) {
			result = vehicles.get(insertionPoint);
		}
		if (result != null) {
			return new VehicleWithDistance(result, distance + position - vehicleLength - result.getFrontPosition());
		}
		// TODO: intelligently detect ring, or at least compare distance with constant
		if (sourceLaneSegment != null && distance < 1000) {
			return sourceLaneSegment.rearVehicle(sourceLaneSegment.getRoadLength(), distance + position, vehicleLength);
		}
		// sourcelane == null
		AbstractJunction sourceJunc = getRoadSegment().getSourceJunction();
		if (sourceJunc != null && distance < 50) {
			VehicleWithDistance shortest = null;
			for (JunctionConnector c : sourceJunc.getConnectorsTo(this)) {
				VehicleWithDistance vd = c.rearVehicle(c.getRoadLength(), distance + position, vehicleLength);
				if (shortest == null || (vd != null && shortest.getDistance() > vd.getDistance())) {
					shortest = vd;
				}
			}
			return shortest;
		}
		return null;
	}

	protected int positionBinarySearch(double vehiclePos) {
		int low = 0;
		int high = vehicles.size() - 1;

		while (low <= high) {
			final int mid = (low + high) >> 1;
			final double rearPos = vehicles.get(mid).getFrontPosition();
			// note vehicles are sorted in order of position
			final int compare = Double.compare(vehiclePos, rearPos);
			if (compare > 0) {
				low = mid + 1;
			} else if (compare < 0) {
				high = mid - 1;
			} else {
				return mid; // key found
			}
		}
		return -(low + 1); // key not found
	}

	public LaneSegment getSourceLaneSegment() {
		return sourceLaneSegment;
	}

	public void setSourceLaneSegment(LaneSegment sourceLaneSegment) {
		this.sourceLaneSegment = sourceLaneSegment;
	}

	public LaneSegment getSinkLaneSegment() {
		return sinkLaneSegment;
	}

	public void setSinkLaneSegment(LaneSegment sinkLaneSegment) {
		this.sinkLaneSegment = sinkLaneSegment;
	}

	/**
	 * The current list of vehicles contained by this {@link LaneSegment}. <br>
	 * <b>Important:</b> Consider that modifications may lead to exceptions due to concurrency reasons!
	 *
	 * @return List of vehicles
	 */
	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	/**
	 * @return a copy of the vehicles to avoid {@link ConcurrentModificationException}s
	 */
	public List<Vehicle> getVehiclesCopy() {
		return new ArrayList<Vehicle>(vehicles);
	}

	public double getRoadLength() {
		return roadGeometry.getRoadLength();
	}

	@Override
	public Iterator<Vehicle> iterator() {
		return vehicles.iterator();
	}

	/**
	 * Returns the first vehicle on this lane, NOT considering lanes from the sink lane segment.
	 *
	 * @return First vehicle on lane, or null if no vehicles are in lane
	 */
	public Vehicle frontVehicle() {
		if (vehicles.size() > 0)
			try {
				return vehicles.get(0);
			} catch (IndexOutOfBoundsException e) {
				// catch exception instead of checking size to be thread-safe
				return null;
			}
		return null;
	}

	/**
	 * @return the last vehicle on this lane, NOT considering lanes from the front segment
	 */
	public Vehicle rearVehicle() {
		final int count = vehicles.size();
		if (count > 0) {
			return vehicles.get(count - 1);
		}
		return null;
	}

	public VehicleWithDistance rearVehicle(Vehicle v) {
		double translatedPosition = v.getFrontPosition();
		if (v.getLaneSegment() != this) {
			translatedPosition = SpatialUtil.translatePosition(v.getLaneSegment(), this, v.getFrontPosition());
		}
		return rearVehicle(translatedPosition, 0, v.getLength());
	}

	public RoadGeometry getRoadGeometry() {
		return roadGeometry;
	}

	public void setRoadGeometry(RoadGeometry roadGeometry) {
		this.roadGeometry = roadGeometry;
	}

	public Lane.Type getLaneType() {
		return laneType;
	}

	public void setLaneType(Lane.Type laneType) {
		this.laneType = laneType;
	}

	public int getLaneIndex() {
		return laneIndex;
	}

	public void setLaneIndex(int laneIndex) {
		this.laneIndex = laneIndex;
	}

	public void outFlow(double dt, Date time, double runTime) {
		if (vehicles.size() > 0) {
			List<Vehicle> toRemove = new ArrayList<>(1);
			for (int i = vehicles.size() - 1; i >= 0; i--) {// Iterator<Vehicle> vehIterator = vehicles.iterator(); vehIterator.hasNext();)
															// {
				Vehicle v = vehicles.get(i);
				if (!v.isObstacle() && v.getFrontPosition() > getRoadLength()) {
					if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_ROAD_STATISTICS)) {
						statisticsData.vehiclePassed(time, v);
					}

					if (listener != null) {
						listener.roadDataChanged(-1, laneIndex);
					}

					boolean performRemove = false;

					if (sinkLaneSegment != null) {
						v.setFrontPosition(v.getFrontPosition() - getRoadLength());
						sinkLaneSegment.addVehicle(v);
						v.setRoadSegment(sinkLaneSegment.getRoadSegment());
						v.setJunction(null); // just in case
						if (v.hasRoute()) {
							v.getRoute().removeNextSegmentIdIfMatches(v.getRoadSegment().getRoutingId());
						}

						performRemove = true;
					} else {
						if (getRoadSegment() != null && getRoadSegment().getJunction() != null) {
							JunctionConnector con = getRoadSegment().getJunction().getNextConnector(v);

							// Only assign vehicle to junction if it is also allowed to enter
							if (con != null && getRoadSegment().getJunction().canEnter(v, con.getSourceLaneSegment(), con.getSinkLaneSegment(), 0)) {
								v.setFrontPosition(v.getFrontPosition() - getRoadLength());
								getRoadSegment().getJunction().addVehicle(v, this);
								performRemove = true;
							}
						} else {
							v.notifyListenersVehicleLeft();
							performRemove = true;
						}
					}
					v.updateGeometry();

					if (performRemove) {
						toRemove.add(v);
					}
				} else {
					// abort here since vehicles are sorted and if first vehicle does not exceed road length, also second does not
					break;
				}
			}
			vehicles.removeAll(toRemove);
		}
	}

	public LaneStatisticsData getLaneStatistics() {
		return statisticsData;
	}

	protected void ensureVehiclesSorted() {
		ArrayList<Vehicle> temp = new ArrayList<Vehicle>(vehicles);
		Collections.sort(temp, new Comparator<Vehicle>() {

			@Override
			public int compare(Vehicle arg0, Vehicle arg1) {
				return new Double(arg0.getFrontPosition()).compareTo(arg1.getFrontPosition());
			}
		});
		vehicles = new CopyOnWriteArrayList<>(temp);
	}

	public RoadSegment getRoadSegment() {
		return null;
	}

	public List<Vector> getLeftEdge() {
		return leftEdge;
	}

	public void setLeftEdge(List<Vector> leftEdge) {
		this.leftEdge = leftEdge;
	}

	public List<Vector> getRightEdge() {
		return rightEdge;
	}

	public void setRightEdge(List<Vector> rightEdge) {
		this.rightEdge = rightEdge;
	}

	public abstract void addVehicle(Vehicle v);

	public abstract VehicleWithDistance frontVehicle(Vehicle me);

	public double getLaneWidth() {
		return laneWidth;
	}

	public void setLaneWidth(double laneWidth) {
		this.laneWidth = laneWidth;
	}

	public void setListener(IRoadStatisticsChangedListener listener) {
		this.listener = listener;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public List<Vector> getBounds() {
		List<Vector> bounds = new ArrayList<>(leftEdge);
		Collections.reverse(bounds);
		bounds.addAll(rightEdge);
		bounds.add(CollectionUtil.getLastObject(leftEdge));
		return bounds;
	}

	public double getSpeedLimitMps() {
		return speedLimit;
	}

}

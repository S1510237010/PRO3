package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.osmimport;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;

import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;

public class ImportWizard extends Wizard {
	private SourceSelectionPage sourceSelectionPage;
	private ConfigurationSelectionPage configurationSelectionPage;

	private IResultProvider currentPage;
	private TraffSimConfiguration result;

	public ImportWizard() {
		setWindowTitle("OSM Import");
		currentPage = sourceSelectionPage = new SourceSelectionPage();
		configurationSelectionPage = new ConfigurationSelectionPage();
	}

	@Override
	public void addPages() {
		this.addPage(sourceSelectionPage);
		this.addPage(configurationSelectionPage);
	}

	@Override
	public boolean performFinish() {
		result = currentPage.getResult();
		return true;
	}

	@Override
	public boolean canFinish() {
		return ((IWizardPage) currentPage).isPageComplete();
	}

	@Override
	public IWizardPage getNextPage(IWizardPage page) {
		if (page.equals(sourceSelectionPage)) {
			currentPage = configurationSelectionPage;
			return configurationSelectionPage;
		} else {
			return null;
		}
	}

	public TraffSimConfiguration getTraffsimConfiguration() {
		return result;
	}

}

package at.fhhagenberg.mc.traffsim.roadnetwork.junction;

import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class JunctionLogCacheCleaner extends PauseableThread implements IPropertyChangeListener {

	private RoadNetwork network;
	private int logCacheSize = PreferenceUtil.getInt(IPreferenceConstants.JUNCTION_LOG_CACHE_SIZE);

	public JunctionLogCacheCleaner(String name, long delayInMillis, RoadNetwork network) {
		super(name, delayInMillis);
		this.network = network;
		PreferenceUtil.addPropertyChangeListener(this);
	}

	@Override
	public void doWork() {
		for (AbstractJunction junc : network.getJunctions()) {
			junc.cleanInternalLogCache(logCacheSize);
		}
	}

	@Override
	public void propertyChange(PropertyChangeEvent event) {
		if (event.getProperty().equals(IPreferenceConstants.JUNCTION_LOG_CACHE_SIZE)) {
			logCacheSize = (int) event.getNewValue();
		}
	}

	@Override
	protected void preStop() {
		PreferenceUtil.removePropertyChangeListener(this);
	}

}

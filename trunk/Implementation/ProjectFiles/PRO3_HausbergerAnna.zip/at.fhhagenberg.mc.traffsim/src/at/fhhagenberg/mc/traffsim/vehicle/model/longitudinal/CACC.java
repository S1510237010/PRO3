package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.CACCData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon;

/**
 * Longitudinal model for platooning. Only use if vehicle is in a platoon and in combination with platooning lane change model.
 *
 * @author Sebastian Huber
 *
 */
public class CACC extends LongitudinalModel implements IPlatoonLongitudinalModel {

	/**
	 * Data entity for model including config parameters
	 */
	private CACCData data;

	/**
	 * Platoon of vehicle
	 */
	private Platoon platoon;

	/**
	 * Empty CTor for Kryo
	 */
	public CACC() {

	}

	/**
	 * Ctor
	 *
	 * @param data
	 *            Data entity including configuration parameters
	 */
	public CACC(CACCData data) {
		super(data.getIdentifier());
		fullname = data.getFullname();
		this.data = data;
	}

	/**
	 * Platoon of vehicle
	 *
	 * @return platoon
	 */
	@Override
	public Platoon getPlatoon() {
		return platoon;
	}

	/**
	 * Platoon of vehicle
	 *
	 * @param platoon
	 *            Platoon
	 */
	@Override
	public void setPlatoon(Platoon platoon) {
		this.platoon = platoon;
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA, double speedLimit) {
		return calcAcc(me, v, s, dv, aLead, platoon.getLeader().getCurrentSpeed(), alphaT, alphaV0, alphaA, speedLimit);
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double vPlatoonLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		double a1 = data.getAlpha1();
		double a2 = data.getAlpha2();
		double a3 = data.getAlpha3();
		double a4 = data.getAlpha4();
		double a5 = data.getAlpha5();

		double gap = platoon.getDesiredGap(me);

		// use distance and acceleration diff from LongitudinalModel
		double distErr = -s + gap;
		double speedDiff = dv;

		double meAcc = me.getCurrentAcc();
		double meSpeed = me.getCurrentSpeed();

		double preAcc = aLead;
		// double preSpeed = preceding.getCurrentSpeed();

		// double leaAcc = leader.getCurrentAcc();
		double leaSpeed = vPlatoonLead;

		double accDes = 0;

		double accDesPlatoon = a1 * preAcc + a2 * meAcc + a3 * speedDiff + a4 * (meSpeed - leaSpeed) + a5 * distErr;
		double accDesCC = -1 * (meSpeed - speedLimit);

		// cap the speed of following model to target speed of vehicle
		if (accDesPlatoon > 0 && speedLimit <= meSpeed) {
			accDes = accDesCC;
		} else {
			accDes = accDesPlatoon;
		}

		// Cap positive acc to comfortable acc due to no risk for crashes at acceleration
		if (accDes > data.getComfortableAcc()) {
			accDes = data.getComfortableAcc();
		}

		if (accDes < data.getMaxDec()) {
			accDes = data.getMaxDec();
		}

		return accDes;
	}

	@Override
	public LongitudinalModel createCopyFor(double speed) {
		CACC copy = new CACC(new CACCData(speed, data.getsMin(), data.gettMin(), data.getComfortableAcc(), data.getSafeDec(), data.getMaxAcc(),
				data.getMaxDec(), data.getC1(), data.getDamping(), data.getBandwidth()));
		return copy;
	}

	@Override
	public LongitudinalModelData getModelData() {
		return data;
	}

	@Override
	public boolean isSafeAcceleration(double acceleration) {
		return acceleration < data.getMaxAcc() && acceleration > data.getMaxDec();
	}
}

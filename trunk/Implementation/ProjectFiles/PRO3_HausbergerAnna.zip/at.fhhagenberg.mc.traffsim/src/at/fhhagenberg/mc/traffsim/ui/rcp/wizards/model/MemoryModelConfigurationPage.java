package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.MemoryDataBean;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.MemoryModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class MemoryModelConfigurationPage extends ModelConfigurationPage {

	private Spinner spinnerMemoryTau;
	private Spinner spinnerMemoryResignationAlphaT;
	private Spinner spinnerMemoryResignationAlphaV0;
	private Spinner spinnerMemoryResignationAlphaA;

	private MemoryModels currentModel;

	protected MemoryModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		Label lblTau = new Label(grpModelParameters, SWT.NONE);
		lblTau.setText("Relaxation time [tau]");

		spinnerMemoryTau = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMemoryTau.setPageIncrement(50);
		spinnerMemoryTau.setIncrement(1);
		spinnerMemoryTau.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMemoryTau.setMaximum(10000);
		spinnerMemoryTau.setMinimum(0);
		spinnerMemoryTau.setSelection(6000);
		spinnerMemoryTau.setDigits(1);

		Label lblResignationMaxAlphaT = new Label(grpModelParameters, SWT.NONE);
		lblResignationMaxAlphaT.setText("Resignation max. alpha T");

		spinnerMemoryResignationAlphaT = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMemoryResignationAlphaT.setPageIncrement(50);
		spinnerMemoryResignationAlphaT.setIncrement(1);
		spinnerMemoryResignationAlphaT.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMemoryResignationAlphaT.setMaximum(1000);
		spinnerMemoryResignationAlphaT.setMinimum(0);
		spinnerMemoryResignationAlphaT.setSelection(170);
		spinnerMemoryResignationAlphaT.setDigits(2);

		Label lblResignationMinAlphaV0 = new Label(grpModelParameters, SWT.NONE);
		lblResignationMinAlphaV0.setText("Resignation min. alpha V0");

		spinnerMemoryResignationAlphaV0 = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMemoryResignationAlphaV0.setPageIncrement(50);
		spinnerMemoryResignationAlphaV0.setIncrement(1);
		spinnerMemoryResignationAlphaV0.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMemoryResignationAlphaV0.setMaximum(1000);
		spinnerMemoryResignationAlphaV0.setMinimum(0);
		spinnerMemoryResignationAlphaV0.setSelection(100);
		spinnerMemoryResignationAlphaV0.setDigits(2);

		Label lblResignationMinAlphaA = new Label(grpModelParameters, SWT.NONE);
		lblResignationMinAlphaA.setText("Resignation min. alpha A");

		spinnerMemoryResignationAlphaA = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMemoryResignationAlphaA.setPageIncrement(50);
		spinnerMemoryResignationAlphaA.setIncrement(1);
		spinnerMemoryResignationAlphaA.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMemoryResignationAlphaA.setMaximum(1000);
		spinnerMemoryResignationAlphaA.setMinimum(0);
		spinnerMemoryResignationAlphaA.setSelection(100);
		spinnerMemoryResignationAlphaA.setDigits(2);

		// Model property initialization
		ModelProperty relaxTime = new ModelProperty("Relaxation time [tau]", "setTau", Double.TYPE, 0, 1000);
		ModelProperty resigAlphaT = new ModelProperty("Resignation max. alpha T", "setResignationMaxAlphaT",
				Double.TYPE, 0, 10);
		ModelProperty resigAlphaV0 = new ModelProperty("Resignation min. alpha V0", "setResignationMinAlphaV0",
				Double.TYPE, 0, 10);
		ModelProperty resigAlphaA = new ModelProperty("Resignation min. alpha A", "setResignationMinAlphaA",
				Double.TYPE, 0, 10);

		modelProperties.add(relaxTime);
		modelProperties.add(resigAlphaT);
		modelProperties.add(resigAlphaV0);
		modelProperties.add(resigAlphaA);

		controlMapping.put(relaxTime, spinnerMemoryTau);
		controlMapping.put(resigAlphaT, spinnerMemoryResignationAlphaT);
		controlMapping.put(resigAlphaV0, spinnerMemoryResignationAlphaV0);
		controlMapping.put(resigAlphaA, spinnerMemoryResignationAlphaA);
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			currentModel = MemoryModels.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' model parameters", currentModel.toString()));
		}
	}

	protected void addModelToList() {
		MemoryDataBean memoryModel = new MemoryDataBean();
		memoryModel.setModelIdentifier(txtIdentifier.getText());
		memoryModel.setFullName(txtFullName.getText());
		memoryModel.setTau(spinnerMemoryTau.getSelection() / Math.pow(10, spinnerMemoryTau.getDigits()));
		memoryModel.setResignationMaxAlphaT(spinnerMemoryResignationAlphaT.getSelection()
				/ Math.pow(10, spinnerMemoryResignationAlphaT.getDigits()));
		memoryModel.setResignationMinAlphaA(spinnerMemoryResignationAlphaA.getSelection()
				/ Math.pow(10, spinnerMemoryResignationAlphaA.getDigits()));
		memoryModel.setResignationMinAlphaV0(spinnerMemoryResignationAlphaV0.getSelection()
				/ Math.pow(10, spinnerMemoryResignationAlphaV0.getDigits()));

		modelSet.add(memoryModel);
	}

	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MemoryDataBean) element).getModelIdentifier() + "";
			}
		});

		TableViewerColumn colTau = createTableViewerColumn("Relaxation time [tau]", 160);
		colTau.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MemoryDataBean) element).getTau() + "";
			}
		});

		TableViewerColumn colResigAlphaT = createTableViewerColumn("Resignation max. alpha T", 160);
		colResigAlphaT.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MemoryDataBean) element).getResignationMaxAlphaT() + "";
			}
		});

		TableViewerColumn colResigAlphaV0 = createTableViewerColumn("Resignation min. alpha V0", 160);
		colResigAlphaV0.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MemoryDataBean) element).getResignationMinAlphaV0() + "";
			}
		});

		TableViewerColumn colResigAlphaA = createTableViewerColumn("Resignation min. alpha A", 160);
		colResigAlphaA.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MemoryDataBean) element).getResignationMinAlphaA() + "";
			}
		});
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {

		try {
			Class<?> cls = MemoryDataBean.class;
			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();
				cls.getMethod("setModelIdentifier", String.class).invoke(obj,
						currentModel.getShortName() + "_gen_" + generationTime + "-" + (i + 1));
				cls.getMethod("setFullName", String.class).invoke(obj, "Auto. generated memory model");

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Method setter = cls.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);
						
						if (property.getType() == Integer.TYPE) {
							setter.invoke(obj, (int) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(obj, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(obj, (int) (spinner.getSelection()
										/ Math.pow(10, spinner.getDigits())  * property.getConversionFactor()));
							} else {
								setter.invoke(obj, (spinner.getSelection()
										/ Math.pow(10, spinner.getDigits()) * property.getConversionFactor()));
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(obj, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(obj, text.getText());
						}
					}
				}

				modelSet.add((MemoryDataBean) obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}

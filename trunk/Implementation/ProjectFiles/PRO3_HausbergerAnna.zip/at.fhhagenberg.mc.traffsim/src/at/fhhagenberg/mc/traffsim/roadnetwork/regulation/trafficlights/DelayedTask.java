package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * Helper class used to schedule tasks (e.g. phase switching of traffic lights) using specified delays.
 *
 * @author Manuel Lindorfer
 *
 */
public abstract class DelayedTask implements Delayed, Runnable {

	long creationTime = System.nanoTime();
	long delay;

	/**
	 * Creates a new instance of DelayedTask using the specified delay and the given time unit.
	 *
	 * @param delay
	 *            the delay considering the given time unit
	 * @param unit
	 *            the time unit used for converting the delay to milliseconds
	 */
	public DelayedTask(long delay, TimeUnit unit) {
		this.delay = TimeUnit.MILLISECONDS.convert(delay, unit);
	}

	@Override
	public int compareTo(Delayed o) {
		int compare = Long.compare(delay, o.getDelay(TimeUnit.MILLISECONDS));
		if (compare == 0) {
			DelayedTask t = (DelayedTask) o;
			return Long.compare(creationTime, t.creationTime);
		}
		return compare;
	}

	@Override
	public long getDelay(TimeUnit unit) {
		return unit.convert(delay, TimeUnit.MILLISECONDS);
	}

	/**
	 * Decreases the tasks remaining delay by the provided value.
	 *
	 * @param dt
	 *            decrement in milliseconds
	 */
	public void updateDelay(long dt) {
		delay -= dt;
	}
}

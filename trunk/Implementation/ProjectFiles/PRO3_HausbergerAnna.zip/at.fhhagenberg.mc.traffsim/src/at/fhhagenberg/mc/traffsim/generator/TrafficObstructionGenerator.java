package at.fhhagenberg.mc.traffsim.generator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.vehicle.IObstructionListener;
import at.fhhagenberg.mc.traffsim.vehicle.Obstruction;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Extension of {@link PredefinedVehicleGenerator} which adds (pre-defined) obstructions to a simulation. The obstructions to be added are
 * obtained from the configuration file <i>obstructions.xml</i>.
 *
 * @author Manuel Lindorfer
 */
public class TrafficObstructionGenerator extends PredefinedVehicleGenerator {

	/** A list of currently active obstructions */
	private ArrayList<Obstruction> activeObstructions = new ArrayList<>();

	/**
	 * The set of listeners to be notified when an obstruction is generated or decomposed respectively
	 */
	private Set<IObstructionListener> obstructionListeners = new HashSet<>();

	/**
	 * Adds the given {@link Obstruction} to the list of active obstructions.
	 *
	 * @param obstruction
	 *            the {@link Obstruction} to become active
	 * @param offset
	 *            the offset from simulation start when the obstruction becomes active
	 */
	public void addActiveObstruction(Obstruction obstruction, double offset) {
		if (obstruction != null && !activeObstructions.contains(obstruction)) {
			LaneSegment laneSeg = obstruction.getRoadSegment().laneSegment(obstruction.getLaneId());
			obstruction.setOffset(offset);
			obstruction.setLaneSegment(laneSeg);
			laneSeg.getVehicles().add(obstruction);
			activeObstructions.add(obstruction);
			notifyObstructionGenerated(obstruction);
		}
	}

	public void removeActiveObstruction(Obstruction obstruction) {
		if (obstruction != null && activeObstructions.contains(obstruction)) {
			obstruction.getLaneSegment().getVehicles().remove(obstruction);
			notifyObstructionDecomposed(obstruction);
			activeObstructions.remove(obstruction);
		}
	}

	/**
	 * Registers the given {@link IObstructionListener} to be notified when an {@link Obstruction} becomes active or is decomposed.
	 *
	 * @param listener
	 *            the listener to be registered
	 */
	public void addObstructionObserver(IObstructionListener listener) {
		obstructionListeners.add(listener);
	}

	/**
	 * Gets the set of currently registered {@link IObstructionListener}s.
	 *
	 * @return the currently registered listeners
	 */
	public Set<IObstructionListener> getObstructionObservers() {
		return obstructionListeners;
	}

	/**
	 * Notifies all registered {@link IObstructionListener}s that the given {@link Obstruction} has been decomposed and removed from the
	 * simulation.
	 *
	 * @param obstruction
	 *            the obstruction which was decomposed
	 */
	private void notifyObstructionDecomposed(Obstruction obstruction) {
		for (IObstructionListener ol : obstructionListeners) {
			ol.obstructionDecomposed(obstruction);
		}
	}

	/**
	 * Notifies all registered {@link IObstructionListener}s that the given {@link Obstruction} has become active.
	 *
	 * @param obstruction
	 *            the obstruction which has become active
	 */
	private void notifyObstructionGenerated(Obstruction obstruction) {
		for (IObstructionListener ol : obstructionListeners) {
			ol.obstructionGenerated(obstruction);
		}
	}

	/**
	 * Unregisters the given {@link IObstructionListener} from being notified when an {@link Obstruction} becomes active or is decomposed.
	 *
	 * @param listener
	 *            the listener to be unregistered
	 */
	public void removeObstructionObserver(IObstructionListener listener) {
		obstructionListeners.remove(listener);
	}

	/**
	 * NOTE: This generator can only accept a list of the {@link Vehicle} -derivated {@link Obstruction}!
	 *
	 * @param vehicles
	 *            the new obstructions to be generated
	 */
	@Override
	public void setVehicles(List<? extends Vehicle> vehicles) {
		// check if everything is an obstruction
		for (Vehicle vehicle : vehicles) {
			if (!(vehicle instanceof Obstruction)) {
				throw new IllegalArgumentException("This generator can only accept obstructions!");
			}
		}

		Collections.sort(vehicles, new Comparator<Vehicle>() {

			@Override
			public int compare(Vehicle o1, Vehicle o2) {
				if (((Obstruction) o1).getOffset() < ((Obstruction) o2).getOffset()) {
					return -1;
				} else if (((Obstruction) o1).getOffset() < ((Obstruction) o2).getOffset()) {
					return 1;
				} else {
					return 0;
				}
			}
		});

		this.vehicles = vehicles;
		initialVehicles = new ArrayList<>(vehicles);

		for (Vehicle v : vehicles) {
			if (!v.isObstacle() && v.getRoute().getInitialSegment() == null) {
				Logger.logError("Unknown initial segment of vehicle #" + v.getUniqueId() + " (" + v.getLabel() + ")");
			}
		}
	}

	@Override
	public void timeStep(double dt, Date time, double runTime) {
		if (vehicles.size() > 0) {
			Obstruction o = (Obstruction) vehicles.get(0);

			if (runTime > o.getOffset()) {
				Obstruction obs = (Obstruction) vehicles.remove(0);

				if (obs != null) {
					LaneSegment laneSeg = obs.getRoadSegment().laneSegment(obs.getLaneId());
					obs.setLaneSegment(laneSeg);
					laneSeg.getVehicles().add(obs);
					activeObstructions.add(obs);
					notifyObstructionGenerated(obs);
				} else {
					Logger.logWarn("Read null obstruction");
				}
			}
		}

		if (activeObstructions.size() > 0) {
			for (Iterator<Obstruction> it = activeObstructions.iterator(); it.hasNext();) {
				Obstruction obs = it.next();

				if (!NumberUtil.doubleEquals(obs.getDuration(), 0) && runTime > obs.getOffset() + obs.getDuration()) {
					obs.getLaneSegment().getVehicles().remove(obs);
					notifyObstructionDecomposed(obs);
					it.remove();
				}
			}
		}
	}
}
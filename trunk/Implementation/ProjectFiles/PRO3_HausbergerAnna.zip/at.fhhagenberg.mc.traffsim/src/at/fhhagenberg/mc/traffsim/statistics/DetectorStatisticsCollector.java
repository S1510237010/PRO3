package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.esotericsoftware.kryo.io.Input;
import com.jmatio.io.MatFileReader;
import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.DetectorDataSample;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.IDetectorDataListener;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.util.EnumUtil;
import at.fhhagenberg.mc.util.CollectionUtil;

public class DetectorStatisticsCollector extends CachingStatisticsCollector implements IDetectorDataListener {

	private static final String COLUMN_NAMES_DETECTORS_VAR = "column_names_detectors";
	private Map<Long, DetectorStatisticsData> detectorStats = new ConcurrentHashMap<>();

	public enum DetectorFieldId {
		LANE_INDEX("Lane Index"), TIME("Simulation Time [s]"), MEAN_SPEED("Mean Speed [km/h]"), FLOW("Traffic Flow [veh/h]"), DENSITY(
				"Traffic Density [veh/km]"), OCCUPANCY("Occupancy Rate [% of sampling interval]");

		public static int length() {
			return values().length;
		}

		private String description;

		private DetectorFieldId(final String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	public DetectorStatisticsCollector(String name, SimulationModel model, long delay, boolean clearPreviousCashes) {
		super(name, model, delay, false, clearPreviousCashes);
	}

	@Override
	public IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException {
		if (!cacheFolder.exists()) {
			Logger.logWarn("Expected cache folder " + cacheFolder.getName() + " does not exist");
			return Status.CANCEL_STATUS;
		}

		monitor.worked(1);

		File matFile = getStandardMatFile(outputFolder, date, crashDetected ? String.format("-%s%s", CRASH_TAG, SIMPLE_MAT_FILE_SUFFIX)
				: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, SIMPLE_MAT_FILE_SUFFIX) : SIMPLE_MAT_FILE_SUFFIX);

		Map<Long, List<Double[]>> detectorMatData = new HashMap<>();

		File[] files = cacheFolder.listFiles();

		if (files != null) {
			monitor.beginTask("Converting " + files.length + " cached files", files.length + 2);
			long totalLength = 0;

			for (File f : files) {
				Input input = new Input(new FileInputStream(f));
				List<?> objs = kryo.readObject(input, ArrayList.class);
				input.close();

				for (Object obj : objs) {
					if (obj instanceof DetectorStatisticsData) {
						DetectorStatisticsData detData = (DetectorStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (detector " + detData.getDetectorId() + ")");
						List<Double[]> dataToAdd;

						if (!detectorMatData.containsKey(detData.getDetectorId())) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = detectorMatData.get(detData.getDetectorId());
						}

						int arraySize = DetectorFieldId.length();

						// Write statistics to array
						for (int i = 0; i < detData.getTime().size(); i++) {
							Double[] row = new Double[arraySize];
							row[DetectorFieldId.LANE_INDEX.ordinal()] = (double) detData.getLaneIndices().get(i);
							row[DetectorFieldId.TIME.ordinal()] = detData.getTime().get(i);
							row[DetectorFieldId.MEAN_SPEED.ordinal()] = detData.getMeanSpeed().get(i);
							row[DetectorFieldId.FLOW.ordinal()] = detData.getTrafficFlow().get(i);
							row[DetectorFieldId.DENSITY.ordinal()] = detData.getTrafficDensity().get(i);
							row[DetectorFieldId.OCCUPANCY.ordinal()] = detData.getOccupancyRate().get(i);

							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						detectorMatData.put(detData.getDetectorId(), dataToAdd);

					} else if (obj != null) {
						Logger.logWarn(
								"Found unexpected object type in cache: " + obj.getClass().getCanonicalName() + " | toString(): " + obj.toString());
					} else {
						Logger.logWarn("Found null object in cache");
					}
				}

				totalLength += f.length();
				long threshold = Runtime.getRuntime().freeMemory() / 2;
				if (totalLength > threshold) {
					appendData(matFile, detectorMatData, monitor);
					detectorMatData = new HashMap<>();
					totalLength = 0;
				}

				monitor.worked(1);

			}
		}

		// write and clear data
		appendData(matFile, detectorMatData, monitor);

		monitor.worked(2);

		if (clearCache) {
			clearCache(cacheFolder);
		}

		return Status.OK_STATUS;
	}

	protected void appendData(File matFile, Map<Long, List<Double[]>> data, IProgressMonitor monitor) throws IOException {
		String baseMsg = String.format("Appending to MAT-file (current size: %.1f MB): ", ((double) matFile.length()) / 1024 / 1024);
		Map<String, MLArray> matFileData;
		matFile = findMatFile(matFile, false);

		if (matFile.exists() && matFile.length() < Math.pow(10, 9) / 2) {
			monitor.subTask(baseMsg + "Reading old file");
			matFileData = new MatFileReader(matFile).getContent();
		} else {
			matFile = findMatFile(matFile, true);
			matFileData = new HashMap<>();
		}

		Set<Long> keys = new HashSet<>(data.keySet());

		for (Long detectorId : keys) {
			monitor.subTask(baseMsg + "Appending detector " + detectorId);
			String varname = getVarName(detectorId, null);

			int arraySize = DetectorFieldId.length();

			double[][] newarr = new double[data.get(detectorId).size()][arraySize];

			if (data.get(detectorId).size() == 0) {
				Logger.logWarn("Found no recorded data for detector #" + detectorId);
				continue;
			}

			int i = 0;

			for (Double[] row : data.remove(detectorId)) {
				newarr[i++] = CollectionUtil.toPrimitiveDoubleArray(row);
			}

			if (matFileData.containsKey(varname)) {
				double[][] oldarr = ((MLDouble) matFileData.get(varname)).getArray();
				// join arrays
				int oldlen = oldarr.length;
				int newlen = newarr.length;
				double joined[][] = new double[oldlen + newlen][];
				System.arraycopy(oldarr, 0, joined, 0, oldlen);
				oldarr = null; // clean memory
				System.arraycopy(newarr, 0, joined, oldlen, newlen);
				matFileData.put(varname, new MLDouble(varname, joined));
			} else {
				matFileData.put(varname, new MLDouble(varname, newarr));
			}
		}

		Collection<MLArray> finalData = new ArrayList<>(matFileData.values());

		// column names for vehicles
		String[] colNames = EnumUtil.enumNameToStringArray(DetectorFieldId.values());
		finalData.add(new MLChar(COLUMN_NAMES_DETECTORS_VAR, colNames));

		monitor.subTask(baseMsg + "Writing new file");
		new MatFileWriter(matFile, finalData);
	}

	@Override
	protected void cleanup() {
		if (model != null && model.getNetwork() != null) {
			List<LoopDetector> detectors = model.getNetwork().getLoopDetectors();

			if (detectors != null && !detectors.isEmpty()) {
				for (LoopDetector detector : detectors) {
					detector.removeDataListener(this);
				}
			}
		}
	}

	@Override
	public void onDetectorDataSampled(long detectorId, long roadSegmentId, List<DetectorDataSample> dataSamplesPerLane) {

		DetectorStatisticsData data;

		if (detectorStats.containsKey(detectorId)) {
			data = detectorStats.get(detectorId);
		} else {
			data = new DetectorStatisticsData(detectorId, roadSegmentId);
		}

		for (DetectorDataSample sample : dataSamplesPerLane) {
			data.addData(sample);
		}

		detectorStats.put(detectorId, data);
	}

	@Override
	public String getCacheFolderPrefix() {
		return ".stat-detector-cache_";
	}

	@Override
	protected String getCacheFilePrefix() {
		return "traffsim_detector_stats";
	}

	@Override
	protected String getVariablePrefix() {
		return "detector_";
	}

	@Override
	protected String getStatisticsFilePrefix() {
		return "detector_statistics_";
	}

	@Override
	protected synchronized void collectStatistics(int itemsToKeep) {
		for (LoopDetector det : model.getNetwork().getLoopDetectors()) {

			if (detectorStats != null && detectorStats.containsKey(det.getIdentifier())) {
				DetectorStatisticsData detectorData = detectorStats.get(det.getIdentifier());

				if (detectorData != null) {
					DetectorStatisticsData data = detectorData.collectData(itemsToKeep);
					dataList.add(data);
					pause(2);
				}
			}
		}
	}
}

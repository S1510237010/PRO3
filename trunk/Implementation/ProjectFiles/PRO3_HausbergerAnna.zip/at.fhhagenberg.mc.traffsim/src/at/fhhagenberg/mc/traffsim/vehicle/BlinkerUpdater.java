package at.fhhagenberg.mc.traffsim.vehicle;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.util.types.JunctionWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle.VehicleProperties;

public class BlinkerUpdater extends PauseableThread implements IVehicleGeneratorListener, IVehicleListener {
	private Queue<Vehicle> openVehiclesQueue = new LinkedBlockingQueue<>();

	public BlinkerUpdater(String name, long delayInMillis) {
		super(name, delayInMillis);
	}

	@Override
	public void doWork() {
		List<Vehicle> outOfRange = new ArrayList<>();
		while (!openVehiclesQueue.isEmpty() && !isStopped()) {
			Vehicle v = openVehiclesQueue.poll();
			if (v == null) {
				continue;
			}
			RoadSegment rs = v.getRoadSegment();
			if (rs != null) {
				JunctionWithDistance nextJunc = RoadUtil.getNextJunction(rs, v.getFrontPosition());
				if (nextJunc.getJunction() != null && nextJunc.getDistance() < AbstractJunction.DIRECTION_INDICATOR_DISTANCE) {
					JunctionConnector conn = RoadUtil.findConnector(v, nextJunc.getJunction());
					if (conn != null) {
						double angle = nextJunc.getJunction().getCachedRelativeAngle(conn.getSourceLaneSegment(), conn.getSinkLaneSegment());
						if (RoadUtil.turnsLeft(angle)) {
							v.setBlinkerState(BlinkerState.LEFT);
						} else if (RoadUtil.turnsRight(angle)) {
							v.setBlinkerState(BlinkerState.RIGHT);
						}
					}

				} else {
					Integer dir = PropertyUtil.getIntProperty(v.getVehicleProperties(), VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name(),
							Lane.NO_CHANGE);
					if (dir == Lane.TO_LEFT) {
						v.setBlinkerState(BlinkerState.LEFT);
					} else if (dir == Lane.TO_RIGHT) {
						v.setBlinkerState(BlinkerState.RIGHT);
					} else {
						outOfRange.add(v);
					}
				}
			} else {
				outOfRange.add(v);
			}
			pause(2);
		}
		openVehiclesQueue.addAll(outOfRange);
	}

	@Override
	public void vehicleLeftSimulation(Vehicle v) {
		v.removeVehicleListener(this);
		openVehiclesQueue.remove(v);
	}

	@Override
	public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {
		openVehiclesQueue.offer(vehicle);
	}

	@Override
	public void vehicleGenerated(Vehicle vehicle) {
		openVehiclesQueue.offer(vehicle);
		vehicle.addVehicleListener(this);
	}

	@Override
	public void performFinish() {
		openVehiclesQueue.forEach(v -> v.removeVehicleListener(this));
		openVehiclesQueue.clear();
	}

}

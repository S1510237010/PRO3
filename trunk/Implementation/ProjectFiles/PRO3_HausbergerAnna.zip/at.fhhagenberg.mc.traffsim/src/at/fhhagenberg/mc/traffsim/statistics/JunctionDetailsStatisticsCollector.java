package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.tuple.Triple;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.esotericsoftware.kryo.io.Input;
import com.jmatio.io.MatFileReader;
import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.EnumUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Detailed statistics collectors used for obtaining statistics related to junctions (queue length and throughput), queue monitoring (load,
 * traffic flow, queue length, waiting time) and traffic light control specific quantities (e.g. service length, service period).
 *
 * @author Manuel Lindofer
 *
 */
public class JunctionDetailsStatisticsCollector extends CachingStatisticsCollector {

	private static final String COLUMN_NAMES_JUNCTION_STATISTICS = "column_names_junction_stats";
	private static final String COLUMN_NAMES_APPROACH_STATISTICS = "column_names_approach_stats";
	private static final String COLUMN_NAMES_TRAFFIC_CONTROLLER_STATISTICS = "column_names_traffic_controller_stats";
	private static final String COLUMN_NAMES_TRAFFIC_LIGHT_STATISTICS = "column_names_traffic_light_stats";
	private static final String COLUMN_NAMES_SO_TRAFFIC_LIGHT_STATISTICS = "column_names_so_traffic_light_stats";

	public enum JunctionFieldId {
		TIME("Time"), QUEUE_LENGTH_TOTAL("Total Queue Length [veh]"), THROUGHPUT("Throughput [veh]");

		public static int length() {
			return values().length;
		}

		private String description;

		private JunctionFieldId(final String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	public enum TrafficControllerFieldId {
		TIME("Time"), CYCLE_TIME("Cycle Time [s]"), STABILIZER_STATE("Is Stabilizer Active");

		public static int length() {
			return values().length;
		}

		private String description;

		private TrafficControllerFieldId(final String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	public enum BaseControlLogicFieldId {
		TIME("Time"), SERVICE_LENGTH("Service Length [s]"), SERVICE_STATE("Is Served");

		public static int length() {
			return values().length;
		}

		private String description;

		private BaseControlLogicFieldId(final String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	public enum SelfOrganizingControlLogicFieldId {
		TIME("Time"), PRIORITY_INDEX("Priority Index"), CLEARING_TIME("Clearing Time"), TAU_SWITCHING_PENALTY(
				"Tau Switching Penalty"), SWITCHING_PENALTY("Switching Penalty"), RELEASE_PERIOD("Release Period"), WAITING_TIME_EXP(
						"Exp. Waiting Time"), TAU("Tau"), QUEUE_LENGTH_CRITICAL("Queue Length Critical"), QUEUE_LENGTH_CRITICAL_TIME_DEPENDENT(
								"Queue Length Critical Time Dependent"), QUEUE_LENGTH_EXP("Queue Length Exp."), EFFICIENCY(
										"Efficiency"), EFFICIENCY_EXP("Efficiency Exp."), EFFICIENCY_LAST_SERVICE(
												"Efficiency Last Service"), ADAPTIVITY("Adaptivity"), RELEASE_STATE("Is Released");

		public static int length() {
			return values().length;
		}

		private String description;

		private SelfOrganizingControlLogicFieldId(final String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	public enum QueueMonitorFieldId {
		TIME("Time"), AVERAGE_LOAD("Average Load"), COUNT_OUTFLOW("Count Outflow [veh]"), COUNT_EXPECTED("Count Expected [veh]"), COUNT_UPSTREAM(
				"Count Upstream [veh]"), QUEUE_LENGTH("Queue Length [veh]"), FLOW_AVG_30S("Traffic Flow 30s [veh/h]"), FLOW_AVG_10M(
						"Traffic Flow [600s]"), WAITING_TIME_TOTAL("Total Waiting Time [s]"), WAITING_TIME_SINCE_QUEUE_EMPTY(
								"Waiting Time Since Empty Queue [s]");

		public static int length() {
			return values().length;
		}

		private String description;

		private QueueMonitorFieldId(final String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return description;
		}
	}

	public JunctionDetailsStatisticsCollector(String name, SimulationModel model, long delay, boolean clearPreviousCaches) {
		super(name, model, delay, false, clearPreviousCaches);
	}

	protected void appendData(File matFile, Map<Triple<Long, Long, Long>, List<Double[]>> data, String[] columns, String columnNames,
			String variablePrefix, IProgressMonitor monitor) throws IOException {
		String baseMsg = String.format("Appending to MAT-file (current size: %.1f MB): ", ((double) matFile.length()) / 1024 / 1024);
		Map<String, MLArray> matFileData;
		matFile = findMatFile(matFile, false);

		if (matFile.exists() && matFile.length() < Math.pow(10, 9) / 2) {
			monitor.subTask(baseMsg + "Reading old file");
			matFileData = new MatFileReader(matFile).getContent();
		} else {
			matFile = findMatFile(matFile, true);
			matFileData = new HashMap<>();
		}

		Set<Triple<Long, Long, Long>> keys = new HashSet<>(data.keySet());

		boolean isEmpty = true;

		for (Triple<Long, Long, Long> id : keys) {
			monitor.subTask(baseMsg + "Appending object " + id);
			String prefix = String.format(variablePrefix, id.getLeft(), id.getMiddle());
			String varname = getVarName(id.getRight(), null, prefix);

			int arraySize = columns.length;

			double[][] newarr = new double[data.get(id).size()][arraySize];
			if (data.get(id).size() == 0) {
				Logger.logWarn("Found no recorded data for object #" + id);
				continue;
			}

			int i = 0;

			for (Double[] row : data.remove(id)) {
				newarr[i++] = CollectionUtil.toPrimitiveDoubleArray(row);
			}

			if (matFileData.containsKey(varname)) {
				double[][] oldarr = ((MLDouble) matFileData.get(varname)).getArray();
				int oldlen = oldarr.length;
				int newlen = newarr.length;
				double joined[][] = new double[oldlen + newlen][];
				System.arraycopy(oldarr, 0, joined, 0, oldlen);
				oldarr = null;
				System.arraycopy(newarr, 0, joined, oldlen, newlen);
				matFileData.put(varname, new MLDouble(varname, joined));
			} else {
				matFileData.put(varname, new MLDouble(varname, newarr));
			}

			if (!matFileData.get(varname).isEmpty()) {
				isEmpty = false;
			}
		}

		if (!isEmpty) {
			Collection<MLArray> finalData = new ArrayList<>(matFileData.values());

			// Add column names
			finalData.add(new MLChar(columnNames, columns));

			monitor.subTask(baseMsg + "Writing new file");
			new MatFileWriter(matFile, finalData);
		}
	}

	@Override
	public IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException {
		if (!cacheFolder.exists()) {
			Logger.logWarn("Expected cache folder " + cacheFolder.getName() + " does not exist");
			return Status.CANCEL_STATUS;
		}

		monitor.worked(1);

		// Get all relevant mat files
		File junctionMatFile = getStandardMatFile(outputFolder, date, getStandardSuffix(crashDetected, deadLockDetected));

		File approachMatFile = getStandardMatFile(outputFolder, date, "approach_statistics_", getStandardSuffix(crashDetected, deadLockDetected));

		File controllerMatFile = getStandardMatFile(outputFolder, date, "traffic_controller_statistics_",
				getStandardSuffix(crashDetected, deadLockDetected));

		File trafficLightMatFile = getStandardMatFile(outputFolder, date, "traffic_light_statistics_",
				getStandardSuffix(crashDetected, deadLockDetected));

		File selfOrgTrafficLightMatFile = getStandardMatFile(outputFolder, date, "so_traffic_light_statistics_",
				getStandardSuffix(crashDetected, deadLockDetected));

		Map<Triple<Long, Long, Long>, List<Double[]>> junctionStatisticsData = new HashMap<>();
		Map<Triple<Long, Long, Long>, List<Double[]>> approachStatisticsData = new HashMap<>();
		Map<Triple<Long, Long, Long>, List<Double[]>> trafficControllerStatisticsData = new HashMap<>();
		Map<Triple<Long, Long, Long>, List<Double[]>> trafficLightStatisticsData = new HashMap<>();
		Map<Triple<Long, Long, Long>, List<Double[]>> selfOrganizingTrafficLightStatisticsData = new HashMap<>();

		File[] files = cacheFolder.listFiles();

		if (files != null) {
			monitor.beginTask("Converting " + files.length + " cached files", files.length + 2);

			long totalLength = 0;

			for (File f : files) {
				Input input = new Input(new FileInputStream(f));
				List<?> objs = kryo.readObject(input, ArrayList.class);
				input.close();

				for (Object obj : objs) {
					if (obj instanceof JunctionStatisticsData) {
						JunctionStatisticsData jsd = (JunctionStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (junction " + jsd.getJunctionId() + ")");
						List<Double[]> dataToAdd;
						Triple<Long, Long, Long> key = Triple.of(jsd.getJunctionId(), jsd.getJunctionId(), jsd.getJunctionId());

						if (!junctionStatisticsData.containsKey(key)) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = junctionStatisticsData.get(key);
						}

						int arraySize = JunctionFieldId.length();

						for (int i = 0; i < jsd.getTime().size(); i++) {
							Double[] row = new Double[arraySize];
							row[JunctionFieldId.TIME.ordinal()] = jsd.getTime().get(i);
							row[JunctionFieldId.QUEUE_LENGTH_TOTAL.ordinal()] = jsd.getQueueLength().get(i);
							row[JunctionFieldId.THROUGHPUT.ordinal()] = jsd.getThroughput().get(i);
							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						junctionStatisticsData.put(key, dataToAdd);

					} else if (obj instanceof JunctionApproachStatisticsData) {
						JunctionApproachStatisticsData jasd = (JunctionApproachStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (approach " + jasd.getApproachId() + ")");
						List<Double[]> dataToAdd;
						Triple<Long, Long, Long> key = Triple.of(jasd.getJunctionId(), jasd.getApproachId(), jasd.getApproachId());

						if (!approachStatisticsData.containsKey(key)) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = approachStatisticsData.get(key);
						}

						int arraySize = QueueMonitorFieldId.length();

						for (int i = 0; i < jasd.getTime().size(); i++) {
							Double[] row = new Double[arraySize];
							row[QueueMonitorFieldId.TIME.ordinal()] = jasd.getTime().get(i);
							row[QueueMonitorFieldId.AVERAGE_LOAD.ordinal()] = jasd.getAverageLoad().get(i);
							row[QueueMonitorFieldId.COUNT_OUTFLOW.ordinal()] = jasd.getCountOutFlow().get(i);
							row[QueueMonitorFieldId.COUNT_EXPECTED.ordinal()] = jasd.getCountExpected().get(i);
							row[QueueMonitorFieldId.COUNT_UPSTREAM.ordinal()] = jasd.getCountUpstream().get(i);
							row[QueueMonitorFieldId.QUEUE_LENGTH.ordinal()] = jasd.getQueueLength().get(i);
							row[QueueMonitorFieldId.FLOW_AVG_30S.ordinal()] = jasd.getFlowAverage30s().get(i);
							row[QueueMonitorFieldId.FLOW_AVG_10M.ordinal()] = jasd.getFlowAverage10min().get(i);
							row[QueueMonitorFieldId.WAITING_TIME_TOTAL.ordinal()] = jasd.getWaitingTimeTotal().get(i);
							row[QueueMonitorFieldId.WAITING_TIME_SINCE_QUEUE_EMPTY.ordinal()] = jasd.getWaitingTimeSinceQueueEmpty().get(i);
							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						approachStatisticsData.put(key, dataToAdd);

					} else if (obj instanceof SelfOrganizingControllerStatisticsData) {
						SelfOrganizingControllerStatisticsData socsd = (SelfOrganizingControllerStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (controller " + socsd.getControllerId() + ")");
						List<Double[]> dataToAdd;
						Triple<Long, Long, Long> key = Triple.of(socsd.getJunctionId(), socsd.getControllerId(), socsd.getControllerId());

						if (!trafficControllerStatisticsData.containsKey(key)) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = trafficControllerStatisticsData.get(key);
						}

						int arraySize = TrafficControllerFieldId.length();

						for (int i = 0; i < socsd.getTime().size(); i++) {
							Double[] row = new Double[arraySize];
							row[TrafficControllerFieldId.TIME.ordinal()] = socsd.getTime().get(i);
							row[TrafficControllerFieldId.CYCLE_TIME.ordinal()] = socsd.getCycleTime().get(i);
							row[TrafficControllerFieldId.STABILIZER_STATE.ordinal()] = socsd.getStabilizerState().get(i);
							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						trafficControllerStatisticsData.put(key, dataToAdd);

					} else if (obj instanceof SelfOrganizingTrafficLightStatisticsData) {
						SelfOrganizingTrafficLightStatisticsData tlsd = (SelfOrganizingTrafficLightStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (traffic light " + tlsd.getTrafficLightId() + ")");
						List<Double[]> dataToAdd;
						Triple<Long, Long, Long> key = Triple.of(tlsd.getJunctionId(), tlsd.getApproachId(), tlsd.getTrafficLightId());

						if (!selfOrganizingTrafficLightStatisticsData.containsKey(key)) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = selfOrganizingTrafficLightStatisticsData.get(key);
						}

						int arraySize = SelfOrganizingControlLogicFieldId.length();

						for (int i = 0; i < tlsd.getTime().size(); i++) {
							Double[] row = new Double[arraySize];
							row[SelfOrganizingControlLogicFieldId.TIME.ordinal()] = tlsd.getTime().get(i);
							row[SelfOrganizingControlLogicFieldId.PRIORITY_INDEX.ordinal()] = tlsd.getPriorityIndex().get(i);
							row[SelfOrganizingControlLogicFieldId.CLEARING_TIME.ordinal()] = tlsd.getClearingTime().get(i);
							row[SelfOrganizingControlLogicFieldId.TAU_SWITCHING_PENALTY.ordinal()] = tlsd.getTauSwitchingPenalty().get(i);
							row[SelfOrganizingControlLogicFieldId.SWITCHING_PENALTY.ordinal()] = tlsd.getSwitchingPenalty().get(i);
							row[SelfOrganizingControlLogicFieldId.RELEASE_PERIOD.ordinal()] = tlsd.getReleasePeriod().get(i);
							row[SelfOrganizingControlLogicFieldId.WAITING_TIME_EXP.ordinal()] = tlsd.getWaitingTimeExp().get(i);
							row[SelfOrganizingControlLogicFieldId.TAU.ordinal()] = tlsd.getTau().get(i);
							row[SelfOrganizingControlLogicFieldId.QUEUE_LENGTH_CRITICAL.ordinal()] = tlsd.getQueueLengthCritical().get(i);
							row[SelfOrganizingControlLogicFieldId.QUEUE_LENGTH_CRITICAL_TIME_DEPENDENT.ordinal()] = tlsd
									.getQueueLengthCriticalTimeDependent().get(i);
							row[SelfOrganizingControlLogicFieldId.QUEUE_LENGTH_EXP.ordinal()] = tlsd.getQueueLengthExp().get(i);
							row[SelfOrganizingControlLogicFieldId.EFFICIENCY.ordinal()] = tlsd.getEfficiency().get(i);
							row[SelfOrganizingControlLogicFieldId.EFFICIENCY_EXP.ordinal()] = tlsd.getEfficiencyExp().get(i);
							row[SelfOrganizingControlLogicFieldId.EFFICIENCY_LAST_SERVICE.ordinal()] = tlsd.getEfficiencyLastService().get(i);
							row[SelfOrganizingControlLogicFieldId.ADAPTIVITY.ordinal()] = tlsd.getAdaptivity().get(i);
							row[SelfOrganizingControlLogicFieldId.RELEASE_STATE.ordinal()] = tlsd.getReleaseState().get(i);
							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						selfOrganizingTrafficLightStatisticsData.put(key, dataToAdd);

					} else if (obj instanceof TrafficLightStatisticsData) {
						TrafficLightStatisticsData tlsd = (TrafficLightStatisticsData) obj;
						monitor.subTask("Processing " + f.getName() + " (traffic light " + tlsd.getTrafficLightId() + ")");
						List<Double[]> dataToAdd;
						Triple<Long, Long, Long> key = Triple.of(tlsd.getJunctionId(), tlsd.getApproachId(), tlsd.getTrafficLightId());

						if (!trafficLightStatisticsData.containsKey(key)) {
							dataToAdd = new ArrayList<Double[]>();
						} else {
							dataToAdd = trafficLightStatisticsData.get(key);
						}

						int arraySize = BaseControlLogicFieldId.length();

						for (int i = 0; i < tlsd.getTime().size(); i++) {
							Double[] row = new Double[arraySize];
							row[BaseControlLogicFieldId.TIME.ordinal()] = tlsd.getTime().get(i);
							row[BaseControlLogicFieldId.SERVICE_LENGTH.ordinal()] = tlsd.getServiceLength().get(i);
							row[BaseControlLogicFieldId.SERVICE_STATE.ordinal()] = tlsd.getServiceState().get(i);
							dataToAdd.add(row);

							if (monitor.isCanceled()) {
								return Status.CANCEL_STATUS;
							}
						}

						trafficLightStatisticsData.put(key, dataToAdd);

					} else if (obj != null) {
						Logger.logWarn(
								"Found unexpected object type in cache: " + obj.getClass().getCanonicalName() + " | toString(): " + obj.toString());
					} else {
						Logger.logWarn("Found null object in cache");
					}
				}

				totalLength += f.length();
				long threshold = Runtime.getRuntime().freeMemory() / 2;

				if (totalLength > threshold) {
					appendData(junctionMatFile, junctionStatisticsData, EnumUtil.enumNameToStringArray(JunctionFieldId.values()),
							COLUMN_NAMES_JUNCTION_STATISTICS, getVariablePrefix(), monitor);

					if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_QUEUE_MONITORING_STATISTICS)) {
						appendData(approachMatFile, approachStatisticsData, EnumUtil.enumNameToStringArray(QueueMonitorFieldId.values()),
								COLUMN_NAMES_APPROACH_STATISTICS, "junc_%06d_approach_", monitor);
					}

					if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_CONTROLLER_STATISTICS)) {
						appendData(controllerMatFile, trafficControllerStatisticsData,
								EnumUtil.enumNameToStringArray(TrafficControllerFieldId.values()), COLUMN_NAMES_TRAFFIC_CONTROLLER_STATISTICS,
								"junc_%06d_controller_", monitor);
					}

					if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_LIGHT_STATISTICS)) {
						appendData(trafficLightMatFile, trafficLightStatisticsData, EnumUtil.enumNameToStringArray(BaseControlLogicFieldId.values()),
								COLUMN_NAMES_TRAFFIC_LIGHT_STATISTICS, "junc_%06d_approach_%06d_tl_", monitor);
						appendData(selfOrgTrafficLightMatFile, selfOrganizingTrafficLightStatisticsData,
								EnumUtil.enumNameToStringArray(SelfOrganizingControlLogicFieldId.values()), COLUMN_NAMES_SO_TRAFFIC_LIGHT_STATISTICS,
								"junc_%06d_approach_%06d_tl_", monitor);
					}

					junctionStatisticsData = new HashMap<>();
					totalLength = 0;
				}

				monitor.worked(1);

			}
		}

		// write and clear data
		appendData(junctionMatFile, junctionStatisticsData, EnumUtil.enumNameToStringArray(JunctionFieldId.values()),
				COLUMN_NAMES_JUNCTION_STATISTICS, getVariablePrefix(), monitor);

		if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_QUEUE_MONITORING_STATISTICS)) {
			appendData(approachMatFile, approachStatisticsData, EnumUtil.enumNameToStringArray(QueueMonitorFieldId.values()),
					COLUMN_NAMES_APPROACH_STATISTICS, "junc_%06d_approach_", monitor);
		}

		if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_CONTROLLER_STATISTICS)) {
			appendData(controllerMatFile, trafficControllerStatisticsData, EnumUtil.enumNameToStringArray(TrafficControllerFieldId.values()),
					COLUMN_NAMES_TRAFFIC_CONTROLLER_STATISTICS, "junc_%06d_controller_", monitor);
		}

		if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_LIGHT_STATISTICS)) {
			appendData(trafficLightMatFile, trafficLightStatisticsData, EnumUtil.enumNameToStringArray(BaseControlLogicFieldId.values()),
					COLUMN_NAMES_TRAFFIC_LIGHT_STATISTICS, "junc_%s_approach_%06d_tl_", monitor);
			appendData(selfOrgTrafficLightMatFile, selfOrganizingTrafficLightStatisticsData,
					EnumUtil.enumNameToStringArray(SelfOrganizingControlLogicFieldId.values()), COLUMN_NAMES_SO_TRAFFIC_LIGHT_STATISTICS,
					"junc_%06d_approach_%06d_tl_", monitor);
		}

		monitor.worked(2);

		if (clearCache) {
			clearCache(cacheFolder);
		}

		return Status.OK_STATUS;
	}

	@Override
	protected void collectStatistics(int itemsToKeep) {
		Map<Long, JunctionStatisticsData> junctionStats = model.getStatistics().getJunctionStats();
		Map<Long, JunctionApproachStatisticsData> approachStats = model.getStatistics().getApproachStats();
		Map<Long, TrafficControllerStatisticsData> controllerStats = model.getStatistics().getTrafficControllerStats();
		Map<Long, TrafficLightStatisticsData> trafficLightStats = model.getStatistics().getTrafficLightStats();

		List<TrafficLightController<?>> trafficLightControllers = new ArrayList<>();

		for (AbstractJunction junction : model.getNetwork().getJunctions()) {
			JunctionStatisticsData jsd = junctionStats.get(junction.getId());

			if (jsd != null) {
				JunctionStatisticsData data = jsd.collectData(itemsToKeep);
				dataList.add(data);
				pause(2);
			}

			if (junction.getTrafficLightController() != null) {
				trafficLightControllers.add(junction.getTrafficLightController());
			}
		}

		List<JunctionApproach> approaches = model.getNetwork().getJunctionApproaches();

		for (JunctionApproach approach : approaches) {
			JunctionApproachStatisticsData jasd = approachStats.get(approach.getId());

			if (jasd != null) {
				JunctionApproachStatisticsData data = jasd.collectData(itemsToKeep);
				dataList.add(data);
				pause(2);
			}
		}

		for (TrafficLightController<?> controller : trafficLightControllers) {
			TrafficControllerStatisticsData tcsd = controllerStats.get(controller.getId());

			if (tcsd != null) {
				TrafficControllerStatisticsData data = tcsd.collectData(itemsToKeep);
				dataList.add(data);
				pause(2);
			}
		}

		List<TrafficLight> trafficLights = model.getNetwork().getTrafficLights();

		for (TrafficLight trafficLight : trafficLights) {
			TrafficLightStatisticsData tlsd = trafficLightStats.get(trafficLight.getId());

			if (tlsd != null) {
				TrafficLightStatisticsData data = tlsd.collectData(itemsToKeep);
				dataList.add(data);
				pause(2);
			}
		}
	}

	@Override
	public String getCacheFolderPrefix() {
		return ".stat-junction-cache_";
	}

	@Override
	protected String getCacheFilePrefix() {
		return "traffsim_junction_stats";
	}

	@Override
	protected String getVariablePrefix() {
		return "junc_";
	}

	@Override
	protected String getStatisticsFilePrefix() {
		return "junction_statistics_";
	}

	private String getStandardSuffix(boolean crashDetected, boolean deadLockDetected) {
		return crashDetected ? String.format("-%s%s", CRASH_TAG, SIMPLE_MAT_FILE_SUFFIX)
				: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, SIMPLE_MAT_FILE_SUFFIX) : SIMPLE_MAT_FILE_SUFFIX;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange;

import java.util.List;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.CheckUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.util.types.JunctionWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle.VehicleProperties;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleListenerAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data.MOBILData;
import at.fhhagenberg.mc.util.StringUtil;

public class MOBIL extends LaneChangeModel {

	private static final double TIME_BEFORE_LANE_CHANGE_EXIT = 10;
	private static final double TIME_FOR_LANE_CHANGE = 3;
	private MOBILData data;
 
	public MOBIL(MOBILData data) {
		super(data.getIdentifier());
		this.data = data;
		this.fullname = data.getFullname();
	}

	public MOBIL() {

	}

	LaneChangeDecision checkForMandatoryLaneChangeAtEntrance() {
		final int currentLane = getVehicle().getLaneIndex();
		final VehiclesLane currentLaneSegment = getVehicle().getLaneSegment();

		if (currentLaneSegment.getLaneType() == Lane.Type.ENTRANCE) {
			int direction = (currentLane == Lane.MOST_LEFT_LANE) ? Lane.TO_RIGHT : Lane.TO_LEFT;
			final LaneSegment newLaneSegment = getVehicle().getRoadSegment().getLaneSegments().get(currentLane + direction);
			if (newLaneSegment != null && isSafeLaneChange(newLaneSegment)) {
				double distanceToRoadSegmentEnd = getVehicle().getDistanceToRoadSegmentEnd();
				if (distanceToRoadSegmentEnd < 0) {
					// just a hack. should not happen.
					Logger.logWarn("check this: roadSegmentLength not set. Do mandatory lane change anyway.", null);
					return (direction == Lane.TO_LEFT) ? new LaneChangeDecision(Lane.TO_LEFT) : new LaneChangeDecision(Lane.TO_RIGHT);
				}
				// evaluate additional motivation to leave entrance lane
				double accInCurrentLane = getVehicle().getLongitudinalControl().calcAccSolitary(getVehicle(), currentLaneSegment);
				double accInNewLane = getVehicle().getLongitudinalControl().calcAccSolitary(getVehicle(), newLaneSegment);
				double bias = biasForMandatoryChange(distanceToRoadSegmentEnd);
				if (accInNewLane + bias > accInCurrentLane) {
					return (direction == Lane.TO_LEFT) ? new LaneChangeDecision(Lane.TO_LEFT) : new LaneChangeDecision(Lane.TO_RIGHT);
				}
			}
		}
		return LaneChangeFactory.decisionStayInLane();
	}

	private double biasForMandatoryChange(double distanceToRoadSegmentEnd) {
		return biasForMandatoryChange(distanceToRoadSegmentEnd, 10);
	}

	private double biasForMandatoryChange(double distanceToRoadSegmentEnd, double interactionDistance) {
		double bias = -data.getMaxDec() * interactionDistance / Math.max(distanceToRoadSegmentEnd, interactionDistance);
		return bias;
	}

	private boolean isSafeLaneChange(LaneSegment newLaneSegment) {
		VehicleWithDistance vd_frontVeh = newLaneSegment.frontVehicle(getVehicle());
		VehicleWithDistance vd_backVeh = newLaneSegment.rearVehicle(getVehicle());

		// check distance to front vehicle
		if (vd_frontVeh != null && !vd_frontVeh.getVehicle().isObstacle()) {
			final double gapFront = vd_frontVeh.getDistance();
			if (gapFront < data.getsMin()) {
				return false;
			}
		}

		// check distance to vehicle at behind
		if (vd_backVeh != null && !vd_backVeh.getVehicle().isObstacle()) {
			final double gapBack = vd_backVeh.getDistance();
			if (gapBack < data.getsMin()) {
				return false;
			}
			// check acceleration of back vehicle
			Vehicle back = vd_backVeh.getVehicle();
			final double backNewAcc = vd_backVeh.getVehicle().getLongitudinalControl().calcAccSolitary(back, back.getLaneSegment(), 1, getVehicle(),
					vd_backVeh.getDistance());
			if (!CheckUtil.isTolerableAcceleration(backNewAcc)) {
				return false;
			}
		}

		// check acceleration of vehicle ahead
		final double meNewAcc = Math.max(data.getMaxDec(), getVehicle().getLongitudinalControl().calcAccSolitary(me, newLaneSegment, 1, null, 0));
		if (meNewAcc >= data.getSafeDec() || meNewAcc > me.getCurrentAcc()) {
			return true;
		}
		return false;
	}

	// from treiber/kesting
	LaneChangeDecision checkForLaneChangeForEnteringVehicle() {
		final int currentLane = getVehicle().getLaneIndex();
		final RoadSegment roadSegment = getVehicle().getRoadSegment();

		LaneSegment entryLaneSegment = roadSegment.laneSegment(roadSegment.getLaneSegments().size() - 1);
		if (currentLane == entryLaneSegment.getLaneIndex() - 1 && entryLaneSegment.getLaneType() == Lane.Type.ENTRANCE) {
			if (roadSegment.getLaneCount() <= 2) {
				// change to left not possible
				return LaneChangeFactory.decisionStayInLane();
			}
			VehicleWithDistance vd_frontVehicle = entryLaneSegment.frontVehicle(getVehicle());
			if (vd_frontVehicle == null || vd_frontVehicle.getVehicle().isObstacle()) {
				return LaneChangeFactory.decisionStayInLane();
			}

			double accToFront = getVehicle().getLongitudinalControl().calcAccSolitary(getVehicle(), getVehicle().getLaneSegment());
			if (accToFront > data.getSafeDec()) {
				// check own disadvantage to change to left to decide to make
				// room

				final int newLane = currentLane + Lane.TO_LEFT;
				final LaneSegment newLaneSegment = roadSegment.laneSegment(newLane);

				if (newLaneSegment.getLaneType() == Lane.Type.ENTRANCE) {
					// never change lane into an entrance lane
					return LaneChangeFactory.decisionStayInLane();
				}
				final VehicleWithDistance vd_newFront = newLaneSegment.frontVehicle(getVehicle());
				if (vd_newFront != null) {
					final Vehicle newFront = vd_newFront.getVehicle();
					if (newFront.isInProcessOfLaneChange()) {
						return LaneChangeFactory.decisionStayInLane();
					}
					final double gapFront = vd_newFront.getDistance();
					if (gapFront < data.getsMin()) {
						return LaneChangeFactory.decisionStayInLane();
					}
				}
				final VehicleWithDistance vd_newBack = newLaneSegment.rearVehicle(getVehicle());
				Vehicle newBack = null;
				if (vd_newBack != null) {
					newBack = vd_newBack.getVehicle();
					if (newBack.isInProcessOfLaneChange()) {
						return LaneChangeFactory.decisionStayInLane();
					}
					final double gapRear = vd_newBack.getDistance();
					if (gapRear < data.getsMin()) {
						return LaneChangeFactory.decisionStayInLane();
					}
				}
				final double newBackNewAcc = vd_newBack == null ? 0
						: vd_newBack.getVehicle().getLongitudinalControl().calcAccSolitary(vd_newBack.getVehicle(), newLaneSegment, 1, getVehicle(),
								vd_newBack.getDistance());

				final double meNewAcc = getVehicle().getLongitudinalControl().calcAccSolitary(getVehicle(), newLaneSegment);

				if (!CheckUtil.isTolerableAcceleration(newBackNewAcc) || !CheckUtil.isSafeAcceleration(meNewAcc)) {
					return LaneChangeFactory.decisionStayInLane();
				}
				// Logger.logInfo(me.getId() + " changed lane for entering vehicle");
				return new LaneChangeDecision(Lane.TO_LEFT);
			}
		}
		return LaneChangeFactory.decisionStayInLane();
	}

	@Override
	public LaneChangeDecision makeDecision() {

		if (getVehicle() == null || getVehicle().getRoadSegment() == null || getVehicle().isInJunction()) {
			// in junction
			return LaneChangeFactory.decisionStayInLane();
		}

		if (getVehicle().getRoadSegment().getLaneCount() == 1) {
			return LaneChangeFactory.decisionStayInLane();
		}
		if (getVehicle().getLaneSegment().getLaneType() == Lane.Type.ENTRANCE) {
			return checkForMandatoryLaneChangeAtEntrance();
		}
		LaneChangeDecision decision = checkForMandatoryLaneChangeAtExit();
		if (decision.getDirection() != Lane.NO_CHANGE || decision.isMandatory()) {
			LaneSegment potentialNewLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + decision.getDirection());
			boolean isSafe = isSafeLaneChange(potentialNewLane);
			VehicleWithDistance vdBack = potentialNewLane.rearVehicle(me);
			final double newBackNewAcc = vdBack == null || vdBack.getVehicle().isObstacle() ? 0
					: vdBack.getVehicle().getLongitudinalControl().calcAccSolitary(vdBack.getVehicle(), potentialNewLane, 1, getVehicle(),
							vdBack.getDistance());
			VehicleWithDistance potentialNewFront = potentialNewLane.frontVehicle(me);
			boolean changeOk = CheckUtil.isSafeAcceleration(newBackNewAcc)
					&& (potentialNewFront == null || CheckUtil.isSafeDistance(me, potentialNewFront.getVehicle(), potentialNewFront.getDistance()));
			if (decision.isMandatory() || getVehicle().isInProcessOfLaneChange()) {
				if (!isSafe || getVehicle().isInProcessOfLaneChange() || !changeOk) {
					// slow down until safe
					LaneChangeDecision stayMandatory = LaneChangeFactory.decisionStayInLaneMandatory();
					stayMandatory.setUrgency(decision.getUrgency());
					me.setProperty(VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name(), String.valueOf(decision.getDirection()));
					me.setProperty(VehicleProperties.LANE_CHANGE_URGENCY.name(), String.valueOf(decision.getUrgency()));
					return stayMandatory;
				}
				return addLaneRestrictions(decision);
			} else {
				if (decision.getDirection() != Lane.NO_CHANGE && isSafe) {
					return addLaneRestrictions(decision);
				}
			}
		}
		if (getVehicle().isInProcessOfLaneChange()) {
			return LaneChangeFactory.decisionStayInLane();
		}

		decision = checkForChangeByOwnNeeds();
		if (decision.getDirection() != Lane.NO_CHANGE || decision.isMandatory()) {
			LaneSegment potentialNewLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + decision.getDirection());
			if (potentialNewLane != null && isNewLaneOnRoute(potentialNewLane) && potentialNewLane.getLaneType() != Lane.Type.ENTRANCE) {
				if (decision.getDirection() != Lane.NO_CHANGE) {
					return addLaneRestrictions(decision);
				}
			} else {
				decision = LaneChangeFactory.decisionStayInLane();
			}
			decision = checkForLaneChangeForEnteringVehicle();
			if (decision.getDirection() == Lane.TO_LEFT && PropertyUtil.getBooleanProperty(me.getVehicleProperties(),
					VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name(), Boolean.TRUE)) {
				return LaneChangeFactory.decisionStayInLane();
			}
			if (decision.getDirection() == Lane.TO_RIGHT
					&& PropertyUtil.getBooleanProperty(me.getVehicleProperties(), VehicleProperties.NO_RIGHT_LANE_CHANGE.name(), Boolean.TRUE)) {
				return LaneChangeFactory.decisionStayInLane();
			}
		}

		return addLaneRestrictions(decision);
	}

	private LaneChangeDecision checkForChangeByOwnNeeds() {
		double accToRight = Double.NEGATIVE_INFINITY;
		double accToLeft = Double.NEGATIVE_INFINITY;
		if (getVehicle().getLaneIndex() < getVehicle().getRoadSegment().getLaneSegments().size() - 1) {
			LaneSegment rightLane = getVehicle().getRoadSegment().getLaneSegments().get(getVehicle().getLaneIndex() + 1);
			accToRight = calcAccelerationBalance(rightLane);
		}
		if (getVehicle().getLaneIndex() > 0) {
			LaneSegment leftLane = getVehicle().getRoadSegment().getLaneSegments().get(getVehicle().getLaneIndex() - 1);
			accToLeft = calcAccelerationBalance(leftLane);
		}
		if (accToLeft > 0 || accToRight > 0) {
			if (accToLeft > accToRight) {
				return LaneChangeFactory.decisionToLeft();
			} else {
				return LaneChangeFactory.decisionToRight();
			}
		}
		return LaneChangeFactory.decisionStayInLane();
	}

	/**
	 * adds lane restrictions to vehicle, if potential right or left lane do not lead to target. Additionally, the decision is changed - if
	 * it indicates a direction that is not applicable due to lane_restriction_properties
	 *
	 * @param original
	 *            the decision
	 * @return the original decision (vehicle me is modified)
	 */
	private LaneChangeDecision addLaneRestrictions(LaneChangeDecision original) {
		LaneSegment potentialLeftLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + Lane.TO_LEFT);
		boolean addListener = false;
		if (potentialLeftLane != null
				&& !StringUtil.ensureNotNull(me.getProperty(VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name())).equals(Boolean.TRUE.toString())
				&& !isNewLaneOnRoute(potentialLeftLane)) {
			me.setProperty(VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name(), Boolean.TRUE.toString());
			addListener = true;
		}
		LaneSegment potentialRightLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + Lane.TO_RIGHT);
		if (potentialRightLane != null
				&& !StringUtil.ensureNotNull(me.getProperty(VehicleProperties.NO_RIGHT_LANE_CHANGE.name())).equals(Boolean.TRUE.toString())
				&& (potentialRightLane.getLaneType() == Lane.Type.ENTRANCE
						|| (me.getRoadSegment().isRightMostLane(me.getLaneIndex()) && !isNewLaneOnRoute(potentialRightLane)))) {
			me.setProperty(VehicleProperties.NO_RIGHT_LANE_CHANGE.name(), Boolean.TRUE.toString());
			addListener = true;
		}
		if (addListener) {
			me.addVehicleListener(new VehicleListenerAdapter() {
				@Override
				public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {
					me.getVehicleProperties().remove(VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name());
					me.getVehicleProperties().remove(VehicleProperties.NO_RIGHT_LANE_CHANGE.name());
					me.removeVehicleListener(this);

				}
			});
		}
		if (original.getDirection() == Lane.TO_LEFT
				&& PropertyUtil.getBooleanProperty(me.getVehicleProperties(), VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT.name(), false)) {
			return LaneChangeFactory.decisionStayInLane();
		}
		if (original.getDirection() == Lane.TO_RIGHT
				&& PropertyUtil.getBooleanProperty(me.getVehicleProperties(), VehicleProperties.NO_RIGHT_LANE_CHANGE.name(), false)) {
			return LaneChangeFactory.decisionStayInLane();
		}
		LaneSegment potentialNewLane = me.getRoadSegment().laneSegment(me.getLaneIndex() + original.getDirection());
		if (!isSafeLaneChange(potentialNewLane)) {
			return LaneChangeFactory.decisionStayInLane();
		}
		return original;
	}

	LaneChangeDecision checkForMandatoryLaneChangeAtExit() {
		JunctionWithDistance nextJunction = RoadUtil.getNextJunction(me.getRoadSegment(), me.getFrontPosition());
		if (nextJunction.getJunction() == null) {
			return LaneChangeFactory.decisionStayInLane();
		}
		double maxDistForDecision = (TIME_BEFORE_LANE_CHANGE_EXIT + TIME_FOR_LANE_CHANGE * me.getRoadSegment().getLaneCount())
				* me.getRoadSegment().getSpeedLimitMps();
		if (nextJunction.getJunction().equals(me.getRoadSegment().getJunction())) {
			maxDistForDecision = Math.min(maxDistForDecision, me.getRoadSegment().getRoadLength());
		}
		double junctionDist = Math.max(1E-5, nextJunction.getDistance() - 20);
		if (junctionDist < maxDistForDecision) {
			// find road segment before junction
			/**
			 * lane segment which would be used if no lane change occurs any more until the next upcoming junction
			 */
			VehiclesLane lastLaneSegWithoutChange = getLastLaneBeforeJunction(me.getLaneSegment(), nextJunction.getJunction().getId());
			/** last road segment before next upcoming junction of route */
			RoadSegment lastRoadsegBeforeJunction = lastLaneSegWithoutChange.getRoadSegment();

			// find junction connector which must be used
			List<Long> routeIds = me.getRoute().getRouteIds();
			long routeIdBeforeJunction = lastRoadsegBeforeJunction.getRoutingId();
			long routeIdAfterJunction = routeIds.get(routeIds.indexOf(routeIdBeforeJunction) + 1);

			List<JunctionConnector> conns = nextJunction.getJunction().getConnectors(routeIdBeforeJunction, routeIdAfterJunction);
			if (conns.isEmpty()) {
				Logger.logError(" Problem: Cannot find connector for intended route in junction " + nextJunction.getJunction().getId() + ", vehicle "
						+ me.getLabel());
				return LaneChangeFactory.decisionStayInLane();
			}
			JunctionConnector fittingConn = null;
			int minLaneChangesForExit = Integer.MAX_VALUE;
			for (JunctionConnector jc : conns) {
				if (fittingConn == null) {
					fittingConn = jc;
				}
				int newLaneDiff = Math.abs(jc.getSourceLaneSegment().getLaneIndex() - lastLaneSegWithoutChange.getLaneIndex());
				// check if less lane changes are necessary when using the current connector to reach target
				if (minLaneChangesForExit > newLaneDiff) {
					fittingConn = jc;
					minLaneChangesForExit = newLaneDiff;
				}
			}

			int numLaneChangeBeforeExit = minLaneChangesForExit;
			/**
			 * lanechange must be complete before reaching last 20% of ending road segment
			 */
			double gapBeforeLaneChangeComplete = lastRoadsegBeforeJunction.getRoadLength() * 0.2;
			double realDistForDecision = Math.max(0,
					junctionDist - (TIME_FOR_LANE_CHANGE * numLaneChangeBeforeExit) * me.getCurrentSpeed() - gapBeforeLaneChangeComplete);
			double urgency = 1 - Math.min(1, Math.max(0, realDistForDecision / junctionDist));
			urgency *= numLaneChangeBeforeExit;

			if (numLaneChangeBeforeExit == 0) {
				// the current lane leads directly to the target lane, if no
				// lane change is performed any more until then
				LaneChangeDecision dec = new LaneChangeDecision(Lane.NO_CHANGE);
				if (urgency > 0.1 && !isNeighborLaneAlsoPossible(nextJunction, routeIdBeforeJunction, routeIdAfterJunction, fittingConn)) {
					dec.setMandatory(true);
				}
				return dec;
			} else {
				// lane change is necessary for reaching target
				int diff = lastLaneSegWithoutChange.getLaneIndex() - conns.get(0).getSourceLaneSegment().getLaneIndex();
				LaneChangeDecision intendedDecision;
				if (diff != 0 && me.getRoadSegment().laneSegment(me.getLaneIndex() - (int) Math.signum(diff)) != null) {
					if (diff < 0) {
						intendedDecision = new LaneChangeDecision(Lane.TO_RIGHT, true);
					} else {
						intendedDecision = new LaneChangeDecision(Lane.TO_LEFT, true);
					}
				} else {
					// stay
					setFlag(VehicleProperties.NO_LEFT_LANE_CHANGE_FOR_EXIT, Boolean.TRUE.toString());
					return LaneChangeFactory.decisionStayInLaneMandatory();
				}
				LaneSegment newLaneSegment = me.getLaneSegment().getRoadSegment().laneSegment(me.getLaneIndex() + intendedDecision.getDirection());
				if (newLaneSegment != null) {
					setFlag(VehicleProperties.PENDING_MANDATORY_LANE_CHANGE, String.valueOf(intendedDecision.getDirection()));
					intendedDecision.setUrgency(urgency);
					return intendedDecision;
				}
			}
		}
		return LaneChangeFactory.decisionStayInLane();
	}

	private VehiclesLane getLastLaneBeforeJunction(VehiclesLane current, long juncId) {
		VehiclesLane last = current;
		while (last.getRoadSegment().getJunction() == null || last.getRoadSegment().getJunction().getId() != juncId) {
			// consider potential road narrows - less lanes
			while (last.getSinkLaneSegment() == null) {
				last = last.getRoadSegment().laneSegment(last.getLaneIndex() - 1);
			}
			last = last.getSinkLaneSegment();
		}
		return last;
	}

	/**
	 * Returns whether any of the neighbor also leads to the target routing id
	 *
	 * @param nextJunction
	 * @param routeIdBeforeJunction
	 * @param routeIdAfterJunction
	 * @param fittingConn
	 * @return
	 */
	private boolean isNeighborLaneAlsoPossible(JunctionWithDistance nextJunction, long routeIdBeforeJunction, long routeIdAfterJunction,
			JunctionConnector fittingConn) {
		List<JunctionConnector> conns = nextJunction.getJunction().getConnectors();
		for (JunctionConnector conn : conns) {
			if ((!conn.equals(fittingConn)
					&& Math.abs(conn.getSourceLaneSegment().getLaneIndex() - fittingConn.getSourceLaneSegment().getLaneIndex()) == 1
					&& fittingConn.getSourceLaneSegment().getRoadSegment().getRoutingId() == routeIdBeforeJunction
					&& fittingConn.getSinkLaneSegment().getRoadSegment().getRoutingId() == routeIdAfterJunction)) {
				return true;
			}
		}
		return false;
	}

	private boolean isNewLaneOnRoute(LaneSegment potentialNewLane) {
		JunctionWithDistance nextJunction = RoadUtil.getNextJunction(me.getRoadSegment(), me.getFrontPosition());
		if (nextJunction == null || nextJunction.getJunction() == null) {
			return true;
		}
		VehiclesLane lastLane = getLastLaneBeforeJunction(potentialNewLane, nextJunction.getJunction().getId());
		if (!lastLane.getRoadSegment().equals(me.getRoadSegment())) {
			return true;
		}
		List<Long> routeIds = me.getRoute().getRouteIds();
		long routeIdBeforeJunction = lastLane.getRoadSegment().getRoutingId();
		long routeIdAfterJunction = routeIds.get(routeIds.indexOf(routeIdBeforeJunction) + 1);

		List<JunctionConnector> potentialConnectors = nextJunction.getJunction().getConnectors(potentialNewLane);
		for (JunctionConnector junctionConnector : potentialConnectors) {
			if (junctionConnector.getSourceLaneSegment().getRoadSegment().getRoutingId() == lastLane.getRoadSegment().getRoutingId()
					&& junctionConnector.getSinkLaneSegment().getRoadSegment().getRoutingId() == routeIdAfterJunction) {
				return true;
			}
		}
		return false;

	}

	private void setFlag(final VehicleProperties flag, String value) {
		if (!StringUtil.ensureNotNull(me.getProperty(flag.name())).equals(value)) {
			me.setProperty(flag.name(), value);
			me.addVehicleListener(new IVehicleListener() {

				@Override
				public void vehicleLeftSimulation(Vehicle v) {
				}

				@Override
				public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {
					if (newLane.getLaneType() == Lane.Type.EXIT) {
						me.getVehicleProperties().remove(flag.name());
						me.removeVehicleListener(this);
					}
				}
			});
		}
	}

	/**
	 * Calculates a balance of the acceleration in current lane compared to the acceleration in the given new {@link LaneSegment}, including
	 * all tolerances and offsets. A positive balance indicates an advantage in the new lane, a negative balance a disadvantage
	 *
	 * @param newLaneSegment
	 *            : The {@link LaneSegment} attempted to change to
	 * @param direction
	 *            1 for change to left, -1 for riht
	 * @return acceleration balance
	 */
	double calcAccelerationBalance(LaneSegment newLaneSegment) {
		// set prospectiveBalance to large negative to indicate no lane change
		// when not safe
		int direction = getVehicle().getLaneIndex() - newLaneSegment.getLaneIndex();
		double prospectiveBalance = Double.NEGATIVE_INFINITY;
		if (newLaneSegment.getLaneType() == Lane.Type.ENTRANCE) {
			// never change lane into an entrance lane
			return prospectiveBalance;
		}

		final VehicleWithDistance vdFront = newLaneSegment.frontVehicle(getVehicle());
		if (vdFront != null) {
			Vehicle newFront = vdFront.getVehicle();
			if (newFront.isObstacle()) {
				return prospectiveBalance;
			}
			if (newFront.isInProcessOfLaneChange()) {
				return prospectiveBalance;
			}
			final double gapFront = vdFront.getDistance();
			if (gapFront < data.getsMin()) {
				return prospectiveBalance;
			}
		}
		VehicleWithDistance vdBack = newLaneSegment.rearVehicle(getVehicle());
		if (vdBack != null) {
			final Vehicle newBack = vdBack.getVehicle();
			if (newBack.isInProcessOfLaneChange()) {
				return prospectiveBalance;
			}
			final double gapRear = vdBack.getDistance();
			if (gapRear < data.getsMin()) {
				return prospectiveBalance;
			}
		}
		final VehiclesLane currentLaneSegment = getVehicle().getLaneSegment();
		VehicleWithDistance vdOldFront = currentLaneSegment.frontVehicle(getVehicle());
		if (vdOldFront != null) {
			final Vehicle oldFront = vdOldFront.getVehicle();
			if (oldFront.isInProcessOfLaneChange()) {
				return prospectiveBalance;
			}
		}

		// new situation: newBack with me as leader and following left lane
		// cases
		// TO_LEFT --> just the actual situation
		// TO_RIGHT --> consideration of left-lane (with me's leader) has no
		// effect
		// temporarily add the current vehicle to the new lane to calculate the
		// new accelerations
		final double newBackNewAcc = vdBack == null ? 0
				: vdBack.getVehicle().getLongitudinalControl().calcAccSolitary(vdBack.getVehicle(), vdBack.getVehicle().getLaneSegment(), 1,
						getVehicle(), vdBack.getDistance());

		final double meNewAcc = getVehicle().getLongitudinalControl().calcAccSolitary(me, newLaneSegment);

		if (!CheckUtil.isSafeAcceleration(newBackNewAcc)) {
			return prospectiveBalance;
		}

		// check now incentive criterion
		// consider three vehicles: me, oldBack, newBack

		// old situation for me
		final double meOldAcc = getVehicle().getLongitudinalControl().calcAccSolitary(me, currentLaneSegment);

		// old situation for old back
		// in old situation same left lane as me
		VehicleWithDistance vdOldBack = currentLaneSegment.rearVehicle(getVehicle());
		double oldBackOldAcc = 0.0;
		if (vdOldBack != null) {
			final Vehicle oldBack = vdOldBack.getVehicle();
			oldBackOldAcc = oldBack.getLongitudinalControl().calcAccSolitary(oldBack, oldBack.getLaneSegment());
		}

		// old situation for new back: just provides the actual left-lane
		// situation
		final double newBackOldAcc = (vdBack != null)
				? vdBack.getVehicle().getLongitudinalControl().calcAccSolitary(vdBack.getVehicle(), vdBack.getVehicle().getLaneSegment()) : 0.0;

		// new situation for new back:
		final double oldBackNewAcc;
		if (vdOldBack == null) {
			oldBackNewAcc = 0.0;
		} else {
			if (currentLaneSegment.frontVehicle(getVehicle()) != null) {
				oldBackNewAcc = vdOldBack.getVehicle().getLongitudinalControl().calcAccSolitary(vdOldBack.getVehicle(),
						vdOldBack.getVehicle().getLaneSegment(), 2, null, 0);
			} else {
				oldBackNewAcc = 0.0;
			}
		}

		// MOBIL trade-off for driver and neighborhood
		final double oldBackDiffAcc = oldBackNewAcc - oldBackOldAcc;
		final double newBackDiffAcc = newBackNewAcc - newBackOldAcc;
		final double meDiffAcc = meNewAcc - meOldAcc;

		prospectiveBalance = meDiffAcc + data.getPoliteness() * (oldBackDiffAcc + newBackDiffAcc) - data.getThreshold()
				- direction * data.getBiasRight();

		return prospectiveBalance;
	}

	@Override
	public LaneChangeModel copyForVehicle(Vehicle v) {
		LaneChangeModel copy = new MOBIL(data);
		copy.setVehicle(v);
		return copy;
	}

}

package at.fhhagenberg.mc.traffsim.vehicle.model;

import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.MOBIL;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data.MOBILData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ACC;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.ACCData;

public class VehicleModelFactory {

	public static LaneChangeModel createDefaultLaneChangeModel(Vehicle v) {
		MOBIL defaultLaneChange = new MOBIL(createDefaultMobilData());
		defaultLaneChange.setVehicle(v);
		return defaultLaneChange;
	}

	public static LongitudinalControl<ILongitudinalModel> createDefaultLongitudinalControl(double targetSpeed) {
		LongitudinalControl<ILongitudinalModel> control = new LongitudinalControl<>("Default");
		ACCData data = createDefaultAccData();
		ACC accModel = new ACC(data);
		control.setLongitudinalModel(accModel);
		return control;
	}

	private static MOBILData createDefaultMobilData() {
		return new MOBILData(TrafficDefaults.DEFAULT_BIAS_RIGHT, TrafficDefaults.DEFAULT_MIN_DISTANCE_METERS,
				TrafficDefaults.DEFAULT_THRESHOLD, TrafficDefaults.DEFAULT_POLITENESS, TrafficDefaults.DEFAULT_SAFE_DECELERATION,
				TrafficDefaults.DEFAULT_MAX_DECELERATION);
	}

	private static ACCData createDefaultAccData() {
		return new ACCData(10, TrafficDefaults.DEFAULT_MIN_DISTANCE_SECONDS, TrafficDefaults.DEFAULT_MIN_DISTANCE_METERS,
				TrafficDefaults.DEFAULT_DELTA, TrafficDefaults.DEFAULT_COMFORTABLE_ACCELERATION, TrafficDefaults.DEFAULT_SAFE_DECELERATION,
				TrafficDefaults.DEFAULT_MAX_DECELERATION, TrafficDefaults.DEFAULT_MAX_ACCELERATION, TrafficDefaults.DEFAULT_COOLNESS);
	}

}

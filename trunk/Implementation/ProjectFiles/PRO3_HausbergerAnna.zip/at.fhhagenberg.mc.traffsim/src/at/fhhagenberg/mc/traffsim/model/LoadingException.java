package at.fhhagenberg.mc.traffsim.model;

public class LoadingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -743420024973194725L;

	public LoadingException(String message) {
		super(message);
	}

	public LoadingException(String message, Throwable throwable) {
		super(message, throwable);
	}

}

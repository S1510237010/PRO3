package at.fhhagenberg.mc.traffsim.statistics;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.model.IVehicleStatisticsChangedListener;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.SelfOrganizingControlLogic;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class Statistics implements ISimulationTimeUpdatable {

	private Map<Long, VehicleStatisticsData> vehicleStats = new ConcurrentHashMap<>();
	private Map<Long, JunctionStatisticsData> junctionStats = new ConcurrentHashMap<>();
	private Map<Long, TrafficControllerStatisticsData> controllerStats = new ConcurrentHashMap<>();
	private Map<Long, TrafficLightStatisticsData> trafficLightStats = new ConcurrentHashMap<>();
	private Map<Long, JunctionApproachStatisticsData> approachStats = new ConcurrentHashMap<>();
	private Map<Long, ModelInputStatisticsData> modelInputStats = new ConcurrentHashMap<>();
	private Map<Long, String> idLabelMapping = new HashMap<>();
	private Map<String, Long> labelIdMapping = new HashMap<>();
	private SimulationModel model;
	private Set<IVehicleStatisticsChangedListener> vehicleStatisticsChangedListeners = new HashSet<>();

	private boolean recordVehicleStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_STATISTICS);
	private boolean recordDetailedJunctionStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DETAILED_JUNCTION_STATISTICS);
	private boolean recordQueueMonitoringStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_QUEUE_MONITORING_STATISTICS);
	private boolean recordTrafficLightStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_LIGHT_STATISTICS);
	private boolean recordTrafficControllerStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_CONTROLLER_STATISTICS);
	private boolean recordModelInputStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS);

	public Statistics(SimulationModel model) {
		this.model = model;
	}

	public Map<Long, TrafficControllerStatisticsData> getTrafficControllerStats() {
		return controllerStats;
	}

	public Map<Long, TrafficLightStatisticsData> getTrafficLightStats() {
		return trafficLightStats;
	}

	public Map<Long, JunctionStatisticsData> getJunctionStats() {
		return junctionStats;
	}

	public Map<Long, JunctionApproachStatisticsData> getApproachStats() {
		return approachStats;
	}

	public Map<Long, VehicleStatisticsData> getVehicleStats() {
		return vehicleStats;
	}

	public Map<Long, ModelInputStatisticsData> getModelInputStats() {
		return modelInputStats;
	}

	public void addStatisticsChangedListener(IVehicleStatisticsChangedListener listener) {
		this.vehicleStatisticsChangedListeners.add(listener);
	}

	private void notifyVehicleAdded(long vehicleId) {
		for (IVehicleStatisticsChangedListener l : vehicleStatisticsChangedListeners) {
			l.vehicleAdded(vehicleId);
		}
	}

	private void notifyDataAdded(long vehicleId) {
		for (IVehicleStatisticsChangedListener l : vehicleStatisticsChangedListeners) {
			l.vehicleDataChanged(vehicleId);
		}
	}

	public void removeStatisticsChangedListener(IVehicleStatisticsChangedListener listener) {
		vehicleStatisticsChangedListeners.remove(listener);
	}

	public boolean containsLabel(String label) {
		return label == null || labelIdMapping.containsKey(label);
	}

	public long getId(String label) {
		return labelIdMapping.get(label);
	}

	public boolean containsId(long id) {
		return idLabelMapping.containsKey(id);
	}

	public String getLabel(long id) {
		return idLabelMapping.get(id);
	}

	@Override
	public void timeStep(double dt, Date time, double runTime) {
		if (recordVehicleStatistics) {
			for (Vehicle vehicle : model.getVehiclesInSimulation(false)) {
				// null check for position (when vehicle was just added,
				// position may be null in the beginning)
				if (vehicle.getAbsolutePosition() != null) {
					VehicleStatisticsData data;
					long vehicleId = vehicle.getUniqueId();
					if (vehicleStats.containsKey(vehicleId)) {
						data = vehicleStats.get(vehicleId);
					} else {
						data = new VehicleStatisticsData(vehicle);
						idLabelMapping.put(vehicleId, vehicle.getLabel());
						labelIdMapping.put(vehicle.getLabel(), vehicleId);
						notifyVehicleAdded(vehicleId);
					}
					data.addData(runTime, vehicle);
					vehicleStats.put(data.getVehicleId(), data);
					notifyDataAdded(vehicleId);
				}
			}
		}

		if (recordDetailedJunctionStatistics) {
			for (AbstractJunction junction : model.getNetwork().getJunctions()) {
				JunctionStatisticsData junctionData;
				long junctionId = junction.getId();
				TrafficLightController<?> controller = junction.getTrafficLightController();

				if (junctionStats.containsKey(junctionId)) {
					junctionData = junctionStats.get(junctionId);
				} else {
					junctionData = new JunctionStatisticsData(junctionId);
				}

				junctionData.addData(runTime, junction);
				junctionStats.put(junctionId, junctionData);

				if (recordQueueMonitoringStatistics) {
					for (JunctionApproach approach : junction.getApproaches()) {
						JunctionApproachStatisticsData approachData;
						long approachId = approach.getId();

						if (approachStats.containsKey(approachId)) {
							approachData = approachStats.get(approachId);
						} else {
							approachData = new JunctionApproachStatisticsData(approachId, junctionId);
						}

						approachData.addData(runTime, approach);
						approachStats.put(approachId, approachData);
					}
				}

				if (recordTrafficLightStatistics && controller != null) {
					for (ControlLogic logic : controller.getControlLogics()) {
						TrafficLightStatisticsData trafficLightData;
						long trafficLightId = logic.getTrafficLight().getId();
						JunctionApproach approach = junction.getApproachForTrafficLight(logic.getTrafficLight());

						if (trafficLightStats.containsKey(trafficLightId)) {
							trafficLightData = trafficLightStats.get(trafficLightId);
						} else {
							if (logic instanceof SelfOrganizingControlLogic) {
								trafficLightData = new SelfOrganizingTrafficLightStatisticsData(trafficLightId, approach.getId(), junctionId);
							} else {
								trafficLightData = new TrafficLightStatisticsData(trafficLightId, approach.getId(), junctionId);
							}
						}

						trafficLightData.addData(runTime, logic);
						trafficLightStats.put(trafficLightId, trafficLightData);
					}
				}

				if (recordTrafficControllerStatistics && controller != null) {
					TrafficControllerStatisticsData controllerData;
					long controllerId = controller.getId();

					if (controllerStats.containsKey(controllerId)) {
						controllerData = controllerStats.get(controllerId);
					} else {
						if (controller instanceof SelfOrganizingController) {
							controllerData = new SelfOrganizingControllerStatisticsData(controllerId, junctionId);
						} else {
							continue;
						}
					}

					controllerData.addData(runTime, controller);
					controllerStats.put(controllerId, controllerData);
				}
			}
		}

		if (recordModelInputStatistics) {
			for (Vehicle vehicle : model.getVehiclesInSimulation(false)) {
				if (vehicle.getAbsolutePosition() != null) {
					ModelInputStatisticsData data;
					long vehicleId = vehicle.getUniqueId();

					if (modelInputStats.containsKey(vehicleId)) {
						data = modelInputStats.get(vehicleId);
					} else {
						data = new ModelInputStatisticsData(vehicleId);
						idLabelMapping.put(vehicleId, vehicle.getLabel());
						labelIdMapping.put(vehicle.getLabel(), vehicleId);
					}

					data.addData(runTime, vehicle.getLongitudinalControl().getModelInputParameterSet());
					modelInputStats.put(data.getVehicleId(), data);
				}
			}
		}

	}

	/**
	 * Reset fields and set to null to free used memory
	 */
	public void reset() {
		vehicleStats = null;
		idLabelMapping = null;
		labelIdMapping = null;
	}
}
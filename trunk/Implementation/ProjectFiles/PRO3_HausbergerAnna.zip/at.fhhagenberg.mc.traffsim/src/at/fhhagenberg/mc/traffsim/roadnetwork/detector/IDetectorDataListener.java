package at.fhhagenberg.mc.traffsim.roadnetwork.detector;

import java.util.List;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public interface IDetectorDataListener {

	default void onDetectorDataSampled(long detectorId, long roadSegmentId, List<DetectorDataSample> dataSamplesPerLane) {

	}

	default void onVehiclePassed(long detectorId, Vehicle vehicle, int laneIdx) {

	}

	default void onPresenceChanged(long detectorId, boolean isVehiclePresent, int laneIdx) {

	}
}

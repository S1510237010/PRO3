package at.fhhagenberg.mc.traffsim.statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.detector.DetectorDataSample;

public class DetectorStatisticsData implements Serializable {

	private static final long serialVersionUID = 7660408927145231425L;

	protected final long detectorId;
	protected final long roadSegmentId;
	protected List<Integer> laneIndex = new ArrayList<>();
	protected List<Double> time = new ArrayList<>();
	protected List<Double> meanSpeed = new ArrayList<>();
	protected List<Double> trafficFlow = new ArrayList<>();
	protected List<Double> trafficDensity = new ArrayList<>();
	protected List<Double> occupancyRate = new ArrayList<>();

	protected long recordedItems;

	public DetectorStatisticsData() {
		detectorId = -1;
		roadSegmentId = -1;
	}

	public DetectorStatisticsData(long detectorId, long roadSegmentId) {
		this.detectorId = detectorId;
		this.roadSegmentId = roadSegmentId;
	}

	public long getDetectorId() {
		return detectorId;
	}

	public long getRoadSegmentId() {
		return roadSegmentId;
	}

	public List<Integer> getLaneIndices() {
		return laneIndex;
	}

	public List<Double> getTime() {
		return time;
	}

	public List<Double> getMeanSpeed() {
		return meanSpeed;
	}

	public List<Double> getTrafficFlow() {
		return trafficFlow;
	}

	public List<Double> getTrafficDensity() {
		return trafficDensity;
	}

	public List<Double> getOccupancyRate() {
		return occupancyRate;
	}

	public long getRecordedItems() {
		return recordedItems;
	}
	
	public synchronized void addData(DetectorDataSample sample) {
		laneIndex.add(sample.getLaneIndex());
		time.add(sample.getTime());
		meanSpeed.add(sample.getSpeed());
		trafficFlow.add(sample.getFlow());
		trafficDensity.add(sample.getDensity());
		occupancyRate.add(sample.getOccupancy());
		recordedItems++;
	}

	public DetectorStatisticsData collectData(int numItemsToKeep) {
		DetectorStatisticsData data = new DetectorStatisticsData(detectorId, roadSegmentId);
		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.laneIndex.addAll(laneIndex.subList(0, numItems));
				data.time.addAll(time.subList(0, numItems));
				data.meanSpeed.addAll(meanSpeed.subList(0, numItems));
				data.trafficFlow.addAll(trafficFlow.subList(0, numItems));
				data.trafficDensity.addAll(trafficDensity.subList(0, numItems));
				data.occupancyRate.addAll(occupancyRate.subList(0, numItems));

				// remove the collected sublist from statistics data
				laneIndex = new ArrayList<>(laneIndex.subList(numItems, lastIndex));
				time = new ArrayList<>(time.subList(numItems, lastIndex));
				meanSpeed = new ArrayList<>(meanSpeed.subList(numItems, lastIndex));
				trafficFlow = new ArrayList<>(trafficFlow.subList(numItems, lastIndex));
				trafficDensity = new ArrayList<>(trafficDensity.subList(numItems, lastIndex));
				occupancyRate = new ArrayList<>(occupancyRate.subList(numItems, lastIndex));
				data.recordedItems = recordedItems;
			}
		}

		return data;
	}
}

package at.fhhagenberg.mc.traffsim.ui.dialogs;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class LoadDialog extends Dialog {

	protected boolean resetRoadGeometries;
	private boolean resetEnabled;

	public LoadDialog(Shell parent, boolean resetEnabled) {
		super(parent);
		this.resetEnabled = resetEnabled;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(1, false));

		final Button btnResetRoadGeometries = new Button(container, SWT.CHECK);
		btnResetRoadGeometries.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				resetRoadGeometries = btnResetRoadGeometries.getSelection();
				PreferenceUtil.setBoolean(IPreferenceConstants.RESET_GEOMETRY_ON_LOAD, resetRoadGeometries);
			}
		});
		btnResetRoadGeometries.setText("Reset road geometries");
		resetRoadGeometries = PreferenceUtil.getBoolean(IPreferenceConstants.RESET_GEOMETRY_ON_LOAD);
		btnResetRoadGeometries.setSelection(resetRoadGeometries);

		if (!resetEnabled) {
			btnResetRoadGeometries.setEnabled(false);
			btnResetRoadGeometries.setSelection(true);
		}

		final Button btnDontShowThis = new Button(container, SWT.CHECK);
		btnDontShowThis.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				PreferenceUtil.setBoolean(IPreferenceConstants.SHOW_LOADING_OPTIONS_DIALOG, !btnDontShowThis.getSelection());
			}
		});
		btnDontShowThis.setText("Don't show this dialog again");
		return container;
	}

	public boolean isResetRoadGeometries() {
		return resetRoadGeometries;
	}

	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Loading options");
	}
}

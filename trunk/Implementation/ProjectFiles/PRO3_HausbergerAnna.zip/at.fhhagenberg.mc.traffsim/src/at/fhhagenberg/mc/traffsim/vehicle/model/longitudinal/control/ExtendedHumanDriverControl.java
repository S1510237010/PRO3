package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.vehicle.DrivingRegime;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleState;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.ExtendedHumanDriverControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.DynamicReactionTimeModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.DynamicReactionTimeModel.ReactionTimeTransition;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.ModelParameterSet;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.Noise;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.SpatialAnticipation;

/**
 * Implementation of a longitudinal model which incorporates various properties attributable to the human driver. The model is based on the
 * Intelligent Driver Model (@link IDM) and extends the thoughts and ideas of Treiber et al.'s Human Driver Model (HDM). It allows a more
 * realistic simulation of human driving behavior compared to other, idealistic models in literature, as it considers the following
 * characteristics:
 *
 * <p>
 * - Varying, situation dependent reaction times
 * </p>
 * <p>
 * - Imperfect estimation capabilities
 * </p>
 * <p>
 * - Driving errors
 * </p>
 * <p>
 * - Anticipation capabilities (temporal and spatial by considering more than one leading vehicle)
 * </p>
 * <p>
 * - Distractions
 * </p>
 *
 * @author Manuel Lindorfer
 *
 */
public class ExtendedHumanDriverControl extends HumanDriverControl implements IDistractibleLongitudinalControl {

	/** Parameter required for configuration */
	private ExtendedHumanDriverControlData data;

	/** Acceleration noise used to model driving errors */
	private Noise accelerationNoise = null;

	/** Dynamic reaction time model */
	private DynamicReactionTimeModel dynamicReactionTimeModel;

	/** The current driving regime **/
	private DrivingRegime currentDrivingRegime;

	/** Response time when the vehicle is in standstill */
	private double delayDriveAway = 0.0;

	/** Response time to expected situations */
	private double delayExpected = 0.0;

	/** Response time to unexpected situations */
	private double delayUnexpected = 0.0;

	private double delayFactor = 0.0;

	/** Headway threshold for determining the current driver regime */
	private double headwayThreshold = 0d;

	/** Store previous reaction time to avoid acc. fluctuations when coming to standstill */
	private double rtPrev = 0.0;

	private boolean isDistracted = false;

	private boolean isSeverelyDistracted = false;

	/** Anticipation parameters (required to allow for parameter adpation) **/
	private int numConsideredVehicles;
	private double sightDistance;
	private boolean isAnticipatingTemporally;

	public ExtendedHumanDriverControl() {

	}

	public ExtendedHumanDriverControl(ExtendedHumanDriverControlData data) {
		super(data.getIdentifier());
		this.data = data;

		if (data.getSpatialAnticipation() != null) {
			numConsideredVehicles = data.getSpatialAnticipation().getNumConsideredVehicles();
			sightDistance = data.getSpatialAnticipation().getSightDistance();
		} else {
			numConsideredVehicles = 0;
			sightDistance = 0;
		}

		isAnticipatingTemporally = data.getResponseTimes().getIsAnticipative();

		// Driver response times
		delayExpected = data.getResponseTimes().getExpected() / 1000.0;
		delayUnexpected = data.getResponseTimes().getUnexpected() / 1000.0;
		delayDriveAway = data.getResponseTimes().getDriveAway() / 1000.0;

		// Factor 2 is due to the reason that in case of a distraction the
		// history size is not exceeded
		maxDelay = Math.max(Math.max(delayExpected, delayDriveAway), delayUnexpected) * 2;

		headwayThreshold = data.getResponseTimes().getTimeHeadway() / 1000.0;
		history = new ArrayList<ModelParameterSet>();
		dynamicReactionTimeModel = new DynamicReactionTimeModel(ReactionTimeTransition.HARSH, 3);
	}

	/**
	 * Adds the given parameter set to the list of historical input parameters.
	 *
	 * @param parameterSet
	 *            the parameter set to be added
	 */
	private void addToHistory(ModelParameterSet parameterSet) {
		if (history != null) {
			if (history.size() > maxHistorySize) {
				history.remove(0);
			}

			history.add(parameterSet);
		}
	}

	/**
	 * Get's whether the underlying distraction model currently yields a distracted state or not.
	 *
	 * @return true if distracted - false else
	 */
	@Override
	public boolean isDistracted() {
		if (isDistracted) {
			// Set by behavior, thus privileged
			return isDistracted;
		}

		return false;
	}

	/**
	 * Get's whether the underlying distraction model currently yields a severe distraction or not.
	 *
	 * @return true if severely distracted - false else
	 */
	@Override
	public boolean isSeverelyDistracted() {
		if (isSeverelyDistracted) {
			// Set by behavior, thus privileged
			return isSeverelyDistracted;
		}

		return false;
	}

	/**
	 * Increases driver delay times by a given factor due to a minor distraction.
	 *
	 * @param delayFactor
	 *            the reaction time increase factor
	 */
	@Override
	public void distract(double delayFactor) {
		this.delayFactor = delayFactor;
		delayExpected *= delayFactor;
		delayUnexpected *= delayFactor;
		delayDriveAway *= delayFactor;
	}

	@Override
	public void setSeverelyDistracted(boolean isSeverelyDistracted) {
		this.isSeverelyDistracted = isSeverelyDistracted;
	}

	@Override
	public void setDistracted(boolean isDistracted) {
		this.isDistracted = isDistracted;
	}

	/**
	 * Gets the currently applied reaction time.
	 *
	 * @return the currently applied reaction time
	 */
	public double getCurrentReactionTime() {
		return rtPrev;
	}

	public double getDelayFactor() {
		return delayFactor;
	}

	@Override
	public void update(double dt, double simulationTime) {
		super.update(dt, simulationTime);

		/** Update acceleration noise **/
		if (accelerationNoise != null) {
			accelerationNoise.update(dt);
		}

		/** Update reaction time model **/
		dynamicReactionTimeModel.update(dt);
	}

	@Override
	public void updateHistory(Vehicle vehicle, AccUpdateData accData) {
		if (data.getResponseTimes().getIsActive()) {
			double s = accData.distance;
			double dv = accData.speedDiff;
			double v = vehicle.getCurrentSpeed();
			VehicleWithDistance frontVehicle = vehicle.getFrontVehicle();

			double headway = 0;

			if (!NumberUtil.doubleEquals(s, 0) && !NumberUtil.doubleEquals(v, 0, 0.1) && s > data.getSpaceHeadwayThreshold()) {
				headway = s / v;
			}

			List<VehicleWithDistance> vehiclesToConsider = getConsiderableVehicles(frontVehicle, numConsideredVehicles);

			updateDrivingRegime(vehicle, frontVehicle != null ? frontVehicle.getVehicle() : null, headway);

			dv = addSpeedDifferenceEstimationError(dv, s);
			s = addDistanceEstimationError(s);

			double rt = getReactionTime(vehicle, frontVehicle != null ? frontVehicle.getVehicle() : null);

			if (!dynamicReactionTimeModel.getIsInitialized()) {
				dynamicReactionTimeModel.setCurrentReactionTime(rt);
				dynamicReactionTimeModel.setTargetReactionTime(rt);
			} else {
				if (!NumberUtil.doubleEquals(dynamicReactionTimeModel.getTargetReactionTime(), rt)) {
					dynamicReactionTimeModel.setTargetReactionTime(rt);
					dynamicReactionTimeModel.update(updateTimeStep);
				}
			}

			rtPrev = rt = dynamicReactionTimeModel.getCurrentReactionTime();
			addToHistory(v, dv, s, vehiclesToConsider, vehicle.getCurrentAcc(), rt);
		}
	}

	public void setAccelerationNoise(Noise noise) {
		accelerationNoise = noise;
	}

	private void updateDrivingRegime(Vehicle vehicle, Vehicle frontVehicle, double headway) {
		if (headway <= headwayThreshold) {
			if (frontVehicle != null && (frontVehicle.getType() == VehicleType.CAR || frontVehicle.getType() == VehicleType.TRUCK)) {
				currentDrivingRegime = DrivingRegime.FOLLOWING;
			} else {
				currentDrivingRegime = DrivingRegime.FREE_DRIVING;
			}
		} else {
			currentDrivingRegime = DrivingRegime.FREE_DRIVING;
		}
	}

	private double addDrivingError(double acc) {
		if (accelerationNoise != null) {
			double accelerationError = accelerationNoise.getError();
			double amplifier = accelerationNoise.getAmplifier();

			// Update model input statistics
			if (modelInput != null) {
				modelInput.setAccelerationNoise(accelerationError * amplifier);
			}

			return acc * Math.exp(accelerationError * amplifier);
		}

		return acc;
	}

	private List<VehicleWithDistance> getConsiderableVehicles(VehicleWithDistance frontVehicle, int lookAhead) {
		List<VehicleWithDistance> vehiclesToConsider = new ArrayList<VehicleWithDistance>();

		if (frontVehicle != null && frontVehicle.getVehicle() != null && lookAhead > 1) {

			int consideredVehicles = 0;
			final double perceptionDistance = sightDistance;

			// Only look ahead if preceding object is a vehicle
			if (frontVehicle.getVehicle().getType() == VehicleType.CAR || frontVehicle.getVehicle().getType() == VehicleType.TRUCK) {

				double perceivedDistance = frontVehicle.getDistance();

				// Check if the first vehicle is within perception distance
				if (perceivedDistance <= perceptionDistance) {

					while (consideredVehicles < lookAhead) {

						// Add vehicles to considerable ones and increase count
						vehiclesToConsider.add(frontVehicle);
						consideredVehicles++;

						// Move on to the next vehicle
						frontVehicle = frontVehicle.getVehicle().getFrontVehicle();

						if (frontVehicle == null || frontVehicle.getVehicle() == null) {
							break;
						}

						perceivedDistance += frontVehicle.getDistance();

						// The vehicle to be considered is to far off
						if (perceivedDistance > perceptionDistance) {
							break;
						}

						// If an obstruction or an intersection is ahead,
						// consider it at last
						if (frontVehicle.getVehicle().getType() == VehicleType.OBSTACLE
								|| frontVehicle.getVehicle().getType() == VehicleType.OBSTRUCTION) {
							vehiclesToConsider.add(frontVehicle);
							break;
						}
					}
				}
			}
		}

		return vehiclesToConsider;
	}

	private double getReactionTime(Vehicle vehicle, Vehicle frontVehicle) {

		double rt = 0;

		// In following regime or if closing in to an obstruction, the
		// driver is alerted - shorter reaction time
		if (currentDrivingRegime == DrivingRegime.FOLLOWING || frontVehicle != null && frontVehicle.getType() == VehicleType.OBSTACLE) {
			rt = delayExpected;
		} else {
			rt = delayUnexpected;
		}

		// If the vehicle has stopped, the movement delay is applied
		if (vehicle.getState() == VehicleState.STOP) {
			rt = delayDriveAway;
		}

		return rt;
	}

	@Override
	public double calcAccCustom(Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA) {

		/** Duplicate previous history values due to severe distraction, and maintain current acceleration */
		if (isSeverelyDistracted()) {
			if (history.size() > 0) {
				ModelParameterSet parameterSet = history.get(history.size() - 1);
				addToHistory(parameterSet);
			}

			return 0;
		}

		double s = accData.distance;
		double dv = accData.speedDiff;
		double aLead = accData.accLead;
		double speedLimit = getSpeedLimitMps(me);
		double v = me.getCurrentSpeed();
		VehicleWithDistance frontVehicle = me.getFrontVehicle();

		// Delayed input parameters
		double sDelayed = 0.0;
		double dvDelayed = 0.0;
		double vDelayed = 0.0;

		// Anticipated input parameters (temporally)
		double vProg = 0.0;
		double sProg = 0.0;

		// Determine current driver regime
		double headway = 0;

		double sEst = s;
		double dvEst = dv;
		double vEst = v;

		/** Determine which vehicles are to be considered for multi-anticipation **/
		List<VehicleWithDistance> vehiclesToConsider = getConsiderableVehicles(frontVehicle, numConsideredVehicles);
		List<Double> netGapsToConsider = null;
		List<Double> speedsToConsider = null;

		/** Calculate time headway according to Ahmed, p. 48 */
		if (!NumberUtil.doubleEquals(s, 0) && !NumberUtil.doubleEquals(v, 0, 0.1) && s > data.getSpaceHeadwayThreshold()) {
			headway = s / v;
		}

		/**
		 * Time headway decides in which regime the driver is currently in (truncated normally according to Ahmed, p. 56 / log-normally
		 * Moridpour)
		 **/
		updateDrivingRegime(me, frontVehicle != null ? frontVehicle.getVehicle() : null, headway);

		/** Consider imperfect estimation capabilities [Velocity Difference] **/
		dvEst = dv = addSpeedDifferenceEstimationError(dv, s);

		/** Consider imperfect estimation capabilities [Net Gap] **/
		sEst = s = addDistanceEstimationError(s);

		/** Consider reaction time **/
		if (data.getResponseTimes().getIsActive()) {
			/** Get reaction time depending on driving regime and distraction state **/
			double rt = getReactionTime(me, frontVehicle != null ? frontVehicle.getVehicle() : null);

			/** Update reaction time using the dynamic reaction time model **/
			if (!dynamicReactionTimeModel.getIsInitialized()) {
				dynamicReactionTimeModel.setCurrentReactionTime(rt);
				dynamicReactionTimeModel.setTargetReactionTime(rt);
			} else {
				if (!NumberUtil.doubleEquals(dynamicReactionTimeModel.getTargetReactionTime(), rt)) {
					dynamicReactionTimeModel.setTargetReactionTime(rt);
					dynamicReactionTimeModel.update(updateTimeStep);
				}
			}

			rtPrev = rt = dynamicReactionTimeModel.getCurrentReactionTime();

			/**
			 * Field which determines the number of time steps the reaction time equals to with respect to the current update time interval
			 * (e.g. a reaction time of 1.5 seconds with a given update time interval of 50ms constitutes to n = 30).
			 */
			int n = NumberUtil.doubleEquals(updateTimeStep, 0) ? 0 : (int) (rt * (int) (1 / updateTimeStep));
			double weightFactor = NumberUtil.doubleEquals(updateTimeStep, 0) ? 0 : rt * (int) (1 / updateTimeStep) - n;

			/** Update history **/
			addToHistory(vEst, dvEst, sEst, vehiclesToConsider, me.getCurrentAcc(), rt);

			/**
			 * Kesting (Disseration): If the reaction time is a multiple n of the update time interval, all terms are calculated with the
			 * velocities and distances n time steps in the past.
			 *
			 * If the reaction time is not a multiple of the update time interval, a linear interpolation according to x(t-T') = beta *
			 * x(t-n-1) + (1-beta)*x(t-n), where the weight factor beta = T' / deltaT - n. ALL input stimuli are evaluated at the delayed
			 * time.
			 */
			if (history.size() > maxHistorySize - n + 1 && n > 0) {
				ModelParameterSet inputN = history.get(maxHistorySize - n);
				ModelParameterSet inputPrevN = history.get(maxHistorySize - n - 1);

				double vN = inputN.getV();
				double vPrevN = inputPrevN.getV();
				double dvN = inputN.getDv();
				double dvPrevN = inputPrevN.getDv();
				double sN = inputN.getS();
				double sPrevN = inputPrevN.getS();

				double vAntiN = inputN.getVAnti();
				double vAntiPrevN = inputPrevN.getVAnti();

				double sAntiN = inputN.getSAnti();
				double sAntiPrevN = inputPrevN.getSAnti();

				netGapsToConsider = inputN.getNetGaps();
				speedsToConsider = inputN.getVelocities();

				vDelayed = weightFactor * vPrevN + (1 - weightFactor) * vN;
				dvDelayed = weightFactor * dvPrevN + (1 - weightFactor) * dvN;
				sDelayed = weightFactor * sPrevN + (1 - weightFactor) * sN;
				vProg = weightFactor * vAntiPrevN + (1 - weightFactor) * vAntiN;
				sProg = weightFactor * sAntiPrevN + (1 - weightFactor) * sAntiN;
			} else {
				vDelayed = v;
				dvDelayed = dv;
				sDelayed = s;
				netGapsToConsider = null;
				speedsToConsider = null;
				vProg = v;
				sProg = s;
			}

			// Continue using delayed parameters
			s = sDelayed;
			dv = dvDelayed;
			v = vDelayed;
		}

		/** Consider the driver's temporal anticipation **/
		if (data.getResponseTimes().getIsActive() && isAnticipatingTemporally) {
			s = Math.max(sProg, 0);
			v = Math.max(vProg, 0);
		}

		// Computed acceleration value
		double acc = 0;

		// No spatial anticipation, just one or no preceding vehicle
		if (vehiclesToConsider.size() <= 1) {
			acc = longitudinalModel.calcAcc(me, v, s, dv, aLead, alphaT, alphaV0, alphaA, speedLimit);
		} else {
			// Determine current speed limit only once

			/** Free acceleration (no deceleration terms) **/
			double accFree = longitudinalModel.calcAccComponent(v, speedLimit, alphaT, alphaV0, alphaA);

			/** Interactions with considerable preceding vehicles **/
			double accInteraction = 0;

			/**
			 * Factors required for normalization and reduction in order to decrease unrealistic equilibrium distances (Treiber et al.
			 * 'Delays, inaccuracies...')
			 **/
			double gamma = SpatialAnticipation.getNormalizationFactor(vehiclesToConsider.size());

			// Specifies the distance to the vehicle under consideration
			double sDiff = 0;

			if (data.getResponseTimes().getIsActive() && netGapsToConsider != null && speedsToConsider != null) {
				for (int i = 0; i < netGapsToConsider.size(); i++) {
					double vDiff = v - speedsToConsider.get(i);

					// Determine distance to subject vehicle
					if (i == 0) {
						sDiff = netGapsToConsider.get(i);
					} else {
						sDiff += netGapsToConsider.get(i);
					}

					double accInt = longitudinalModel.calcBrakeComponent(v, speedLimit, sDiff, vDiff, aLead, alphaT, alphaV0, alphaA, gamma);
					accInteraction += accInt;
				}
			} else {
				for (int i = 0; i < vehiclesToConsider.size(); i++) {
					Vehicle veh = vehiclesToConsider.get(i).getVehicle();
					double vDiff = v - veh.getCurrentSpeed();

					// Determine distance to subject vehicle
					if (i == 0) {
						sDiff = vehiclesToConsider.get(i).getDistance();
					} else {
						sDiff += vehiclesToConsider.get(i).getDistance();
					}

					double accInt = longitudinalModel.calcBrakeComponent(v, speedLimit, sDiff, vDiff, aLead, alphaT, alphaV0, alphaA, gamma);
					accInteraction += accInt;
				}
			}

			/** Compute final acceleration **/
			acc = accFree + accInteraction;
		}

		/**
		 * Consider driving errors (Treiber & Kesting, Traffic Flow Dynamics)
		 **/
		acc = addDrivingError(acc);

		final double finalAcc = Math.min(acc, Double.MAX_VALUE);
		return finalAcc;
	}
}

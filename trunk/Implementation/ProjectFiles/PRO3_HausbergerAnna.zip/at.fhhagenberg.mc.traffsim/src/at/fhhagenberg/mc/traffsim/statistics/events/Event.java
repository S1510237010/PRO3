package at.fhhagenberg.mc.traffsim.statistics.events;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import at.fhhagenberg.mc.traffsim.ui.rcp.views.filter.IFilterEnabledElement;

public class Event implements Serializable, IFilterEnabledElement {
	private static final long serialVersionUID = -2162837241010230603L;
	private static long NEXT_ID = 0;

	private static final Map<String, Long> continuousEventNumber = new ConcurrentHashMap<>();

	protected long id;
	/** the creation date of the event */
	protected Date timestamp;
	/** an additional date, which can be set manually and marks the time when the event was logged */
	private Date logDate;
	protected EventType type;
	protected String details;

	protected String fullStringRepresentation;
	private long continuousNumber;
	private String modelId;
	private String shortString;
	private String typeInfo;

	/**
	 * No-arg constructor - only intended for serializatioN!
	 */
	public Event() {
	}

	private static long getNextContinuousNumber(String modelId) {
		Long continuousNumber = continuousEventNumber.get(modelId);
		if (continuousNumber == null) {
			continuousNumber = 0l;
		}
		continuousEventNumber.put(modelId, continuousNumber + 1);
		return continuousNumber;

	}

	public Event(String modelId, Date timestamp, EventType type, String typeInfo, String details, boolean reassignId) {
		super();

		if (reassignId) {
			this.id = NEXT_ID++;
		}
		this.continuousNumber = getNextContinuousNumber(modelId);

		this.timestamp = timestamp;
		this.type = type;
		this.details = details;
		this.typeInfo = typeInfo;
		this.modelId = modelId;
	}

	public String getDetails() {
		return details;
	}

	public long getId() {
		return id;
	}

	public long getContinuousNumber() {
		return continuousNumber;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public EventType getType() {
		return type;
	}

	public String getTypeAbbreviation() {
		return EventType.getAbbreviation(type);
	}

	@Override
	public String getInfoAsString() {
		if (fullStringRepresentation == null) {
			fullStringRepresentation = continuousNumber + " " + EventType.getAbbreviation(type) + " " + timestamp + " " + details;
		}
		return fullStringRepresentation;
	}

	public String getShortInfo() {
		if (shortString == null) {
			shortString = continuousNumber + " " + EventType.getAbbreviation(type) + " " + timestamp;
		}
		return shortString;
	}

	public String getModelId() {
		return modelId;
	}

	public String getTypeInfo() {
		return typeInfo;
	}

	public void setTypeInfo(String newInfo) {
		typeInfo = newInfo;
	}

	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}
}

package at.fhhagenberg.mc.traffsim.ui.color;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Stroke;

import at.fhhagenberg.mc.traffsim.ui.Matrix;

/**
 * A default color set, which can be extended for modifications
 * 
 * @author Christian
 * 
 */
public class DimensionLessColorSet extends DefaultColorSet {
	public DimensionLessColorSet() {
		streetMiddle = new Color(240, 240, 240); // light grey
	}

	public Color getColor(IElement element) {
		switch (element) {
		case STANDSTILL:
			return Color.DARK_GRAY;
		default:
			return super.getColor(element);
		}
	}

	@Override
	public Stroke getStroke(IElement stroke, Matrix matrix) {
		switch (stroke) {
		case ROAD_MIDDLE:
			return new BasicStroke((float) 1 / 5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
		case STREET_BACKGROUND:
			break;
		case STREET_EDGE:
			return new BasicStroke((float) 1 / 5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
		case STREET_GROUND_MARKINGS:
			return new BasicStroke((float) 1 / 6, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, new float[] { 3 }, 0f);
		case ROAD_SIGN_STAND:
			return new BasicStroke((float) 1 / 7, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
		default:
			return super.getStroke(stroke, matrix);

		}
		return new BasicStroke();
	}
}

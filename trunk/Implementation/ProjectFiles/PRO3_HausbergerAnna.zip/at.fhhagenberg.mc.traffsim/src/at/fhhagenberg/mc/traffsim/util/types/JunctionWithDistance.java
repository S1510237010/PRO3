package at.fhhagenberg.mc.traffsim.util.types;

import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;

/**
 * Utility class combining a junction object (@see AbstractJunction) with a distance value.
 *
 * @author Christian Backfrieder
 */
public class JunctionWithDistance {

	/** The distance to the junction */
	private double distance;

	/** The junction of interest */
	private AbstractJunction junction;

	/**
	 * Creates a new instance of JunctionWithDistance with the given parameters.
	 *
	 * @param junction
	 *            the junction of interest
	 * @param distance
	 *            the distance to the junction
	 */
	public JunctionWithDistance(AbstractJunction junction, double distance) {
		super();
		this.junction = junction;
		this.distance = distance;
	}

	/**
	 * Gets the distance to the junction.
	 *
	 * @return the distance
	 */
	public double getDistance() {
		return distance;
	}

	/**
	 * Gets the junction of interest.
	 *
	 * @return the junction
	 */
	public AbstractJunction getJunction() {
		return junction;
	}
}
package at.fhhagenberg.mc.traffsim.ui;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.model.geo.Line;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSign;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight.TrafficLightState;
import at.fhhagenberg.mc.traffsim.ui.color.ColorSet;
import at.fhhagenberg.mc.traffsim.ui.color.IElement;
import at.fhhagenberg.mc.traffsim.util.BitUtil;
import at.fhhagenberg.mc.traffsim.util.ImageUtil;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.ui.AWTAdapter;
import at.fhhagenberg.mc.traffsim.util.ui.DrawUtil;
import at.fhhagenberg.mc.traffsim.vehicle.BlinkerState;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Provides static methods to draw geo objects in a color depending on the type.
 *
 * @author Christian
 *
 */
public class DrawingContext {

	private static final double SPEED_LIMIT_SCALE = 3.5;
	private Map<LaneSegment, Path2D> lanePolygonCache = new HashMap<>();
	private Map<LaneSegment, Path2D> laneRightEdgeCache = new HashMap<>();
	private Map<RoadSegment, Path2D> roadMiddleCache = new HashMap<>();
	private Map<Long, Path2D> junctionBoundsCache = new HashMap<>();

	public void drawScaleIndicator(Graphics g, Matrix matrix, int imageHeight) {
		Graphics2D g2d = getGraphics2D(g);
		int offset = 20;
		int yPos = imageHeight - offset;
		double scaleFactor = matrix.getScaleFactor();
		int meters = (int) Math.max(1, Math.round((1 / scaleFactor * 4000) / 400) * 10);

		double xEndPixels = (meters * matrix.getScaleFactor());
		int xEndPixelsInt = (int) xEndPixels;

		g2d.setColor(Color.BLACK);
		g2d.drawLine((int) (offset + xEndPixels / 2), yPos + 4, (int) (offset + xEndPixels / 2), yPos - 4);
		g2d.drawLine((int) (offset + xEndPixels / 4), yPos + 2, (int) (offset + xEndPixels / 4), yPos - 2);
		g2d.drawLine((int) (offset + xEndPixels / 4 * 3), yPos + 2, (int) (offset + xEndPixels / 4 * 3), yPos - 2);
		g2d.setStroke(new BasicStroke(2f));
		g2d.drawLine(offset, yPos, offset + xEndPixelsInt, yPos);
		g2d.drawLine(offset, yPos + 3, offset, yPos - 3);
		g2d.drawLine(offset + xEndPixelsInt, yPos - 3, offset + xEndPixelsInt, yPos + 3);
		g2d.drawString(meters + " m", offset * 2, yPos - 15);
	}

	public void drawAxes(Vector leftUpper, Vector rightLower, Graphics g, Matrix matrix) {
		Graphics2D g2d = (Graphics2D) g;
		resetGraphics(g2d);

		Vector xMiddle = new Vector((rightLower.x + leftUpper.x) / 2, rightLower.y);
		Vector xMiddleScr = matrix.multiply(xMiddle);
		Vector yMiddle = new Vector(leftUpper.x, (rightLower.y + leftUpper.y) / 2);
		Vector yMiddleScr = matrix.multiply(yMiddle);

		// x-axis
		g2d.drawLine((int) xMiddleScr.x, (int) xMiddleScr.y, (int) xMiddleScr.x, (int) xMiddleScr.y - 7);
		g2d.drawString(String.format("%.2f m ", xMiddle.x), (int) xMiddleScr.x + 4, (int) xMiddleScr.y - 2);

		g2d.drawLine((int) xMiddleScr.x / 2, (int) xMiddleScr.y, (int) xMiddleScr.x / 2, (int) xMiddleScr.y - 7);
		g2d.drawString(String.format("%.2f m", leftUpper.x + (rightLower.x - leftUpper.x) / 4), (int) xMiddleScr.x / 2 + 4, (int) xMiddleScr.y - 2);

		g2d.drawLine((int) xMiddleScr.x * 3 / 2, (int) xMiddleScr.y, (int) xMiddleScr.x * 3 / 2, (int) xMiddleScr.y - 7);
		g2d.drawString(String.format("%.2f m", leftUpper.x + (rightLower.x - leftUpper.x) / 4 * 3), (int) xMiddleScr.x * 3 / 2 + 4,
				(int) xMiddleScr.y - 2);

		// y-axis
		g2d.drawLine((int) yMiddleScr.x, (int) yMiddleScr.y, (int) yMiddleScr.x + 7, (int) yMiddleScr.y);
		g2d.drawString(String.format("%.2f m ", yMiddle.y), (int) yMiddleScr.x + 4, (int) yMiddleScr.y - 2);

		g2d.drawLine((int) yMiddleScr.x, (int) yMiddleScr.y * 3 / 2, (int) yMiddleScr.x + 7, (int) yMiddleScr.y * 3 / 2);
		g2d.drawString(String.format("%.2f m", rightLower.y + (leftUpper.y - rightLower.y) / 4), (int) yMiddleScr.x + 4,
				(int) yMiddleScr.y * 3 / 2 - 2);

		g2d.drawLine((int) yMiddleScr.x, (int) yMiddleScr.y / 2, (int) yMiddleScr.x + 7, (int) yMiddleScr.y / 2);
		g2d.drawString(String.format("%.2f m", rightLower.y + (leftUpper.y - rightLower.y) / 4 * 3), (int) yMiddleScr.x + 4,
				(int) yMiddleScr.y / 2 - 2);

	}

	public void drawRoadSegment(RoadSegment seg, Graphics g, Matrix matrix, ColorSet colorSet, int flags) {
		Graphics2D g2d = getGraphics2D(g);
		g2d.setTransform(matrix.getAffineTransform());
		if (!BitUtil.isSet(flags, UiFlag.SCALE_LARGE)) {
			for (LaneSegment ls : seg.getLaneSegments()) {

				// background
				if (!BitUtil.isSet(flags, UiFlag.SCALE_MEDIUM) && !BitUtil.isSet(flags, UiFlag.TRANSPARENT_ROADS)) {
					Path2D lane = getLanePolygon(ls);
					g2d.setColor(colorSet.getColor(IElement.STREET_BACKGROUND));
					if (lane != null) {
						g2d.fill(lane);
					}
				}

				List<Vector> edge = seg.getRightMostLane().getRightEdge();
				/** speed limits */
				if (BitUtil.isSet(flags, UiFlag.SPEED_LIMITS) && seg.getSpeedLimitKmph() < Double.POSITIVE_INFINITY
						&& BitUtil.isSet(flags, UiFlag.SCALE_SMALL) && (seg.getSourceRoadSegment() == null
								|| !NumberUtil.doubleEquals(seg.getSourceRoadSegment().getSpeedLimitKmph(), seg.getSpeedLimitKmph()))) {
					g2d.setTransform(new AffineTransform());
					Vector v1 = edge.get(1).minus(edge.get(0));
					Vector v1normal = new Vector(v1.y, -v1.x);
					Vector speedLimitPos = edge.get(0).plus(v1normal.unify().multiplyBy(3)).plus(v1.unify().multiplyBy(4));
					speedLimitPos = matrix.multiply(speedLimitPos);
					g2d.setColor(Color.BLACK);
					Vector beginning = matrix.multiply(edge.get(0));
					g2d.setStroke(new BasicStroke((float) matrix.getScaleFactor() * 0.2f));
					g2d.drawLine((int) beginning.x, (int) beginning.y, (int) speedLimitPos.x, (int) speedLimitPos.y);
					g2d.setColor(Color.RED);
					double size = matrix.getScaleFactor() * SPEED_LIMIT_SCALE;
					int iSize = (int) size;
					g2d.fillArc((int) speedLimitPos.x - iSize / 2, (int) speedLimitPos.y - iSize / 2, iSize, iSize, 0, 360);
					g2d.setColor(Color.WHITE);
					iSize = (int) (size * 0.75);
					g2d.fillArc((int) speedLimitPos.x - iSize / 2, (int) speedLimitPos.y - iSize / 2, iSize, iSize, 0, 360);
					g2d.setColor(Color.BLACK);

					Font font = new Font("Arial", Font.BOLD, (int) (matrix.getScaleFactor() * SPEED_LIMIT_SCALE / 2.1));
					g2d.setFont(font);
					FontMetrics metrics = g2d.getFontMetrics();
					String limit = "" + (int) Math.round(seg.getSpeedLimitKmph());
					double height = metrics.getHeight();
					double width = metrics.stringWidth(limit);

					FontRenderContext frc = g2d.getFontRenderContext();
					GlyphVector gv = font.createGlyphVector(frc, limit);
					int length = gv.getNumGlyphs();
					for (int i = 0; i < length; i++) {
						double rotateAngle = Math.PI - v1normal.getAngle();
						double xoffs = -Math.sin(rotateAngle) * (height / 3) - Math.cos(rotateAngle) * (width / 2);
						double yoffs = Math.cos(rotateAngle) * (height / 3) - Math.sin(rotateAngle) * (width / 2);
						AffineTransform at = AffineTransform.getTranslateInstance(speedLimitPos.x + xoffs, speedLimitPos.y + yoffs);
						at.rotate(Math.PI - v1normal.getAngle());

						Shape glyph = gv.getGlyphOutline(i);
						Shape transformedGlyph = at.createTransformedShape(glyph);
						g2d.fill(transformedGlyph);
					}
					g2d.setTransform(matrix.getAffineTransform());
				}
				if (ls.getLaneIndex() >= 0 && ls.getLaneIndex() < ls.getRoadSegment().getLaneCount()) {
					Stroke old = g2d.getStroke();
					if (ls.getLaneIndex() < ls.getRoadSegment().getLaneCount() - 1) {
						g2d.setColor(colorSet.getColor(IElement.STREET_GROUND_MARKINGS));
						g2d.setStroke(colorSet.getStroke(IElement.STREET_GROUND_MARKINGS, matrix));
					} else {
						g2d.setColor(colorSet.getColor(IElement.STREET_EDGE));
						g2d.setStroke(colorSet.getStroke(IElement.STREET_EDGE, matrix));
					}
					Path2D linePath = getRightEdge(ls);
					g2d.draw(linePath);
					g2d.setStroke(old);
				}
				/** draw debug info (lane middle + sampling points) */
				if (BitUtil.isSet(flags, UiFlag.LANE_DEBUG)) {
					g2d.setColor(Color.DARK_GRAY);
					g2d.setStroke(new BasicStroke(0.1f));// , BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL));
					g2d.draw(AWTAdapter.toPath2D(ls.getRoadGeometry().getPoints()));
					for (Vector v : ls.getRoadGeometry().getPoints()) {
						g2d.draw(getDebugPointShape(v, 0.2));
					}
				}
				// end of background
			}
			g2d.setColor(colorSet.getColor(IElement.ROAD_MIDDLE));

		} else {
			g2d.setColor(colorSet.getColor(IElement.STREET_EDGE));
		}
		if (seg.isOneWay()) {
			g2d.setColor(colorSet.getColor(IElement.STREET_EDGE));
		}
		// draw center of road
		g2d.setStroke(colorSet.getStroke(IElement.ROAD_MIDDLE, matrix));
		g2d.draw(getRoadMiddle(seg));
		if (BitUtil.isSet(flags, UiFlag.LANE_DEBUG)) {
			g2d.setColor(colorSet.getColor(IElement.ROAD_MIDDLE));
			g2d.setStroke(new BasicStroke(0.4f));
			for (Vector v : seg.getRoadGeometry().getPoints()) {
				Shape rect = getDebugPointShape(v, 0.1f);
				g2d.draw(rect);
			}

		}
		resetGraphics(g2d);

		g2d.setTransform(new AffineTransform());

		if (BitUtil.isSet(flags, UiFlag.ROADSEGMENT_DEBUG)) {
			Font origFont = g2d.getFont();
			g2d.setFont(origFont.deriveFont(origFont.getSize() / 2 + origFont.getSize() * (float) matrix.getScaleFactor() / 4));

			Vector ptDirBase = seg.getRoadGeometry().mapPosition(seg.getRoadLength() / 2);
			Vector pt = seg.getRightMostLane().getRoadGeometry().mapPosition(seg.getRoadLength() / 2);
			pt = pt.plus(pt.minus(ptDirBase).unify().multiplyBy(5));
			pt = matrix.multiply(pt);
			g2d.setColor(Color.BLACK);
			FontMetrics metrics = g2d.getFontMetrics(g2d.getFont());
			// get the height of a line of text in this
			// font and render context
			int hgt = metrics.getHeight();
			// get the advance of my text in this font
			// and render context
			String txt = seg.getId() + "";
			int adv = metrics.stringWidth(txt);

			g2d.drawString(txt, pt.intX() - adv / 2, pt.intY() + hgt / 2);
			g2d.setFont(origFont);
		}
	}

	private Shape getRoadMiddle(RoadSegment seg) {
		if (!roadMiddleCache.containsKey(seg)) {
			roadMiddleCache.put(seg, AWTAdapter.toPath2D(seg.getRoadGeometry().getPoints()));
		}
		return roadMiddleCache.get(seg);
	}

	private Path2D getRightEdge(LaneSegment ls) {
		if (!laneRightEdgeCache.containsKey(ls)) {
			laneRightEdgeCache.put(ls, AWTAdapter.toPath2D(ls.getRightEdge()));
		}
		return laneRightEdgeCache.get(ls);
	}

	private Shape getDebugPointShape(Vector pos, double radius) {
		return new Rectangle2D.Double(pos.x - radius / 2, pos.y - radius / 2, radius, radius);
	}

	private Shape getCircleShape(Vector pos, double radius) {
		return new Ellipse2D.Double(pos.x - radius / 2, pos.y - radius / 2, radius, radius);
	}

	private Path2D getLanePolygon(LaneSegment ls) {
		if (!lanePolygonCache.containsKey(ls)) {
			Path2D lane = null;
			List<Vector> leftEdge = ls.getLeftEdge();
			for (int i = 0; i < leftEdge.size(); i++) {
				double x11 = leftEdge.get(i).x;
				double y11 = leftEdge.get(i).y;

				if (lane == null) {
					lane = new Path2D.Double();
					lane.moveTo(x11, y11);
				} else {
					lane.lineTo(x11, y11);
				}

			}
			List<Vector> rightEdge = ls.getRightEdge();
			for (int i = rightEdge.size() - 1; i >= 0; i--) {
				double x12 = rightEdge.get(i).x;
				double y12 = rightEdge.get(i).y;
				lane.lineTo(x12, y12);
			}
			lanePolygonCache.put(ls, lane);
		}
		return lanePolygonCache.get(ls);
	}

	public void drawVehicle(Vehicle vehicle, Graphics g, Matrix matrix, ColorSet colorSet, int flags) {
		if (vehicle == null || vehicle.getType() == VehicleType.OBSTACLE) {
			return;
		}
		Graphics2D g2d = getGraphics2D(g);
		if (vehicle.getType() == VehicleType.OBSTRUCTION) {
			int r = (int) (matrix.getScaleFactor() * 2.5);
			Vector loc = matrix.multiply(vehicle.getAbsolutePosition());
			Stroke s = g2d.getStroke();
			g2d.setStroke(new BasicStroke(2));
			g2d.setColor(Color.ORANGE);
			double crossLengths = Math.max(20, r * 3);
			g2d.drawLine((int) (loc.x - crossLengths), (int) loc.y, (int) (loc.x + crossLengths), (int) loc.y);
			g2d.drawLine((int) loc.x, (int) (loc.y - crossLengths), (int) loc.x, (int) (loc.y + crossLengths));
			g2d.setStroke(s);
			DrawUtil.drawStar(g2d, Color.RED, Color.YELLOW, 7, 4, (int) loc.x, (int) loc.y, r);
			return;
		}
		if (!vehicle.hasBoundsPolygon()) {
			return;
		}

		if (BitUtil.isSet(flags, UiFlag.SCALE_LARGE)) {
			g2d.setColor(colorSet.getColor(IElement.CAR_EDGE));
			g2d.draw(getCircleShape(matrix.multiply(vehicle.getAbsolutePosition()), 3));
		} else {

			List<Vector> bounds = vehicle.getBoundsPolygon();
			Polygon poly = AWTAdapter.toPolygon(matrix.multiply(bounds));
			// draw blinkers
			if (vehicle.getBlinkerState() == BlinkerState.LEFT) {
				int size = (int) matrix.getScaleFactor();
				g2d.setColor(Color.YELLOW);
				g2d.fillArc(poly.xpoints[0] - size / 2, poly.ypoints[0] - size / 2, size, size, 0, 360);
				g2d.fillArc(poly.xpoints[1] - size / 2, poly.ypoints[1] - size / 2, size, size, 0, 360);
			}
			if (vehicle.getBlinkerState() == BlinkerState.RIGHT) {
				int size = (int) matrix.getScaleFactor();
				g2d.setColor(Color.YELLOW);
				g2d.fillArc(poly.xpoints[2] - size / 2, poly.ypoints[2] - size / 2, size, size, 0, 360);
				g2d.fillArc(poly.xpoints[3] - size / 2, poly.ypoints[3] - size / 2, size, size, 0, 360);
			}
			// draw vehicle body
			g2d.setColor(colorSet.getColor(IElement.CAR));

			if (vehicle.getCurrentAcc() > 0.05 && !NumberUtil.doubleEquals(vehicle.getCurrentSpeed(), 0, 0.1)) {
				g2d.setColor(colorSet.getColor(IElement.ACCELERATE));
			}

			if (vehicle.getCurrentAcc() < -0.05 && !NumberUtil.doubleEquals(vehicle.getCurrentSpeed(), 0, 0.1)) {
				g2d.setColor(colorSet.getColor(IElement.BREAK));
			}

			if (vehicle.getCurrentAcc() < vehicle.getLongitudinalControl().getSafeDec()
					&& !NumberUtil.doubleEquals(vehicle.getCurrentSpeed(), 0, 0.1)) {
				g2d.setColor(colorSet.getColor(IElement.CRITICAL_ACC));
			}

			if (NumberUtil.doubleEquals(vehicle.getCurrentSpeed(), 0, 0.1)) {
				g2d.setColor(colorSet.getColor(IElement.STANDSTILL));
			}

			if (!BitUtil.isSet(flags, UiFlag.SCALE_LARGE)) {
				g2d.fillPolygon(poly);
			}

			if (vehicle.isVehiclePlatoonControlled()) {
				g2d.setColor(colorSet.getColor(IElement.CAR_EDGE_PLATOON));
			} else {
				g2d.setColor(colorSet.getColor(IElement.CAR_EDGE));
			}
			g2d.drawPolygon(poly);
		}
		g2d.setFont(new Font("Arial", Font.PLAIN, 9));
		if (BitUtil.isSet(flags, UiFlag.VEHICLE_IDS)) {
			try {

				Vector pos = matrix.multiply(vehicle.getAbsolutePosition());
				g.drawString(vehicle.getLabel(), (int) pos.x - 13, (int) pos.y);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		if (BitUtil.isSet(flags, UiFlag.VEHICLE_DETAILS) || BitUtil.isSet(flags, UiFlag.VEHICLE_DEBUG)) {
			drawDetails(vehicle.getDetails(), g, matrix, colorSet, vehicle.getAbsolutePosition(), 0.5f);
		}
	}

	public void drawDetails(String details, Graphics g, Matrix matrix, ColorSet colorSet, Vector posReal, float alpha) {
		Graphics2D g2d = (Graphics2D) g;
		int bleed = 4;
		g2d.setFont(new Font("Arial", Font.PLAIN, 9));

		String[] split = details.toString().split("\n");
		double maxlen = 0;
		for (String string : split) {
			maxlen = Math.max(maxlen, g2d.getFontMetrics().getStringBounds(string, g2d).getWidth());
		}
		Point pos = AWTAdapter.toPoint(matrix.multiply(posReal));
		Composite old = g2d.getComposite();
		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
		g2d.setColor(colorSet.getColor(IElement.INSERT_BACKGROUND));
		int fontHeight = g2d.getFontMetrics().getHeight();
		g2d.fillRect(pos.x - bleed, pos.y - fontHeight, (int) maxlen + 2 * bleed, split.length * fontHeight + bleed);
		g2d.setColor(colorSet.getColor(IElement.INSERT_FONT));
		g2d.drawRect(pos.x - bleed, pos.y - fontHeight, (int) maxlen + 2 * bleed, split.length * fontHeight + bleed);
		g2d.setComposite(old);
		for (String line : split) {
			g.drawString(line, pos.x, pos.y);
			pos.y += fontHeight;
		}
	}

	public void drawMarker(Location loc, Graphics g, Matrix matrix, ColorSet colorSet) {
		Graphics2D g2d = getGraphics2D(g);
		g2d.setColor(colorSet.getColor(IElement.MARKER));
		loc = matrix.multiply(loc);
		double radius = matrix.getScaleFactor() * 20;
		double crossLengths = Math.max(20, radius * 3);
		g2d.drawLine((int) (loc.x - crossLengths), (int) loc.y, (int) (loc.x + crossLengths), (int) loc.y);
		g2d.drawLine((int) loc.x, (int) (loc.y - crossLengths), (int) loc.x, (int) (loc.y + crossLengths));
		g2d.setStroke(new BasicStroke((int) radius / 3));
		g2d.drawArc((int) (loc.x - radius), (int) (loc.y - radius), (int) (radius * 2), (int) (radius * 2), 0, 360);
		g2d.setStroke(new BasicStroke());
		g2d.setColor(Color.BLACK);
	}

	public void drawDetector(Location loc, Graphics g, Matrix matrix, Color color, int flags) {
		Graphics2D g2d = getGraphics2D(g);
		loc = matrix.multiply(loc);
		double radius = matrix.getScaleFactor() / TrafficDefaults.DEFAULT_DETECTOR_RADIUS;

		if (BitUtil.isSet(flags, UiFlag.SELECTED)) {
			g2d.setColor(Color.GREEN);
		} else {
			g2d.setColor(color);
		}

		g2d.fillArc((int) (loc.x - radius), (int) (loc.y - radius), (int) (radius * 2), (int) (radius * 2), 0, 360);
		g2d.setStroke(new BasicStroke((int) radius / 5));
		g2d.setColor(Color.BLACK);
		g2d.drawArc((int) (loc.x - radius), (int) (loc.y - radius), (int) (radius * 2), (int) (radius * 2), 0, 360);
		g2d.setStroke(new BasicStroke());
	}

	public void drawArtifact(DrawableArtifact drawable, Graphics g, Matrix matrix) {
		Graphics2D g2d = getGraphics2D(g);
		double[][] m = matrix.get();
		AffineTransform t = new AffineTransform(m[0][0], m[1][0], m[0][1], m[1][1], m[0][2], m[1][2]);
		Shape transformed = t.createTransformedShape(drawable.getShape());
		Composite old = g2d.getComposite();
		if (drawable.getAlpha() < 1) {
			g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, drawable.getAlpha()));
		}
		if (drawable.getStroke() != null) {
			g2d.setStroke(drawable.getStroke());
		}
		if (drawable.getLineColor() != null) {
			g2d.setColor(drawable.getLineColor());
			g2d.draw(transformed);
		}
		if (drawable.getFillColor() != null) {
			g2d.setColor(drawable.getFillColor());
			g2d.fill(transformed);
		}
		g2d.setComposite(old);
		resetGraphics(g2d);
		g2d.setTransform(new AffineTransform());
	}

	private void resetGraphics(Graphics2D g2d) {
		g2d.setColor(Color.BLACK);
		g2d.setStroke(new BasicStroke());
	}

	private Graphics2D getGraphics2D(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		return g2d;

	}

	public void drawJunction(AbstractJunction j, Graphics g, Matrix matrix, ColorSet colorSet, int flags) {
		if (j.getOpenEdges() == null || j.getRoundedBounds() == null) {
			drawMarker(j.getJunctionCenter(), g, matrix, colorSet);
			return;
		}

		Graphics2D g2d = getGraphics2D(g);
		g2d.setTransform(matrix.getAffineTransform());
		if (BitUtil.isSet(flags, UiFlag.SCALE_LARGE)) {
			g2d.setStroke(new BasicStroke(3));
			g2d.draw(getCircleShape(j.getJunctionCenter(), 10));
			return;
		}
		g.setColor(colorSet.getColor(IElement.CROSSING_FONT_PRIMARY));
		Path2D bounds = getJunctionBounds(j);
		if (!BitUtil.isSet(flags, UiFlag.TRANSPARENT_ROADS)) {
			g2d.setColor(colorSet.getColor(IElement.STREET_BACKGROUND));
			g2d.fill(bounds);
		}
		g2d.setStroke(colorSet.getStroke(IElement.STREET_EDGE, matrix));
		g2d.setColor(colorSet.getColor(IElement.CROSSING_BORDER));
		for (Line line : j.getOpenEdges()) {
			g2d.draw(AWTAdapter.toPath2D(line.getPolyLine()));
		}
		if (BitUtil.isSet(flags, UiFlag.JUNCTION_DEBUG)) {
			// draw connectors and connector edges
			g2d.setColor(Color.CYAN);
			g2d.draw(AWTAdapter.toPath2D(j.getBounds()));
			g2d.setStroke(new BasicStroke(0.1f));
			for (JunctionConnector conn : j.getConnectors()) {
				if (conn.getSourceLaneSegment().getRoadSegment().getRoutingId() != conn.getSinkLaneSegment().getRoadSegment().getRoutingId()) {

					g2d.setColor(Color.GRAY);
					g2d.draw(AWTAdapter.toPath2D(conn.getRoadGeometry().getPoints()));
					for (Vector v : conn.getRoadGeometry().getPoints()) {
						g2d.draw(getDebugPointShape(v, 0.1));
					}
					g2d.setColor(Color.YELLOW);
					g2d.draw(AWTAdapter.toPath2D(conn.getLeftEdge()));
					g2d.draw(AWTAdapter.toPath2D(conn.getRightEdge()));
				}
			}
			//
		}
		/** ROAD SIGNS */
		if (BitUtil.isSet(flags, UiFlag.SCALE_SMALL) || BitUtil.isSet(flags, UiFlag.JUNCTION_DEBUG)) {
			g2d.setTransform(new AffineTransform());
			Map<LaneSegment, RoadSign> segmentSigns = new HashMap<>();
			for (JunctionConnector conn : j.getConnectors()) {
				if (conn.getRoadSign() != null) {
					segmentSigns.put(conn.getSourceLaneSegment(), conn.getRoadSign());
				}
			}
			for (LaneSegment seg : segmentSigns.keySet()) {
				if (!segmentSigns.get(seg).hasImage()) {
					continue;
				}
				BufferedImage img;
				try {
					img = ImageUtil.getAWTImage(segmentSigns.get(seg).getImagePath());
				} catch (IOException e) {
					Logger.logError("Could not load image file for " + segmentSigns.get(seg));
					continue;
				}
				Vector dirVec = seg.getRoadGeometry().getLastPoint().minus(CollectionUtil.getSecondToLastObject(seg.getRoadGeometry().getPoints()))
						.mirrorY();
				double angle = dirVec.getAngle() - Math.PI / 2;
				BufferedImage newImage = ImageUtil.rotateImage(img, angle);

				Vector loc = matrix.multiply(CollectionUtil.getLastObject(seg.getRightEdge()));
				Vector direction = dirVec.unify();
				loc = loc.minus(direction.multiplyBy(matrix.getScaleFactor() * 1.5))
						.minus(direction.normal(true).multiplyBy(matrix.getScaleFactor() * 1.5));
				double maxLength = seg.getLaneWidth();
				int len = (int) (matrix.getScaleFactor() * maxLength * 1.2f);
				Vector stand = loc.minus(direction.multiplyBy(matrix.getScaleFactor() * 3));
				g2d.setStroke(new BasicStroke((float) matrix.getScaleFactor() * 0.2f));
				g2d.setColor(colorSet.getColor(IElement.ROAD_SIGN_STAND));
				g2d.drawLine((int) loc.x, (int) loc.y, (int) stand.x, (int) stand.y);
				g2d.drawImage(newImage, (int) (loc.x - len / 2), (int) (loc.y - len / 2), len, len, null);
			}
		}

		g2d.setTransform(new AffineTransform());
	}

	private Path2D getJunctionBounds(AbstractJunction j) {
		if (!junctionBoundsCache.containsKey(j.getId())) {
			junctionBoundsCache.put(j.getId(), AWTAdapter.toPath2D(j.getRoundedBounds()));
		}

		return junctionBoundsCache.get(j.getId());
	}

	/**
	 *
	 * @param string
	 *            the string to draw
	 * @param g
	 *            graphics to use
	 * @param point
	 *            the point where to start
	 * @param isCenterPoint
	 *            flag whether the starting point is already the center, or if the center should be calculated by this method
	 * @param font
	 *            the font to use (or null if default)
	 * @param color
	 *            the color to use (or null if default)
	 */
	public void drawString(String string, Graphics g, Point point, boolean isCenterPoint, Font font, Color color) {
		Font f = g.getFont();
		Color c = g.getColor();

		if (font != null) {
			g.setFont(font);
		}

		if (color != null) {
			g.setColor(color);
		}

		if (isCenterPoint) {
			point = new Point(point.x - g.getFontMetrics().stringWidth(string), point.y);
		}

		g.drawString(string, point.x, point.y);
		g.setFont(f);
		g.setColor(c);
	}

	public void drawTrafficLight(TrafficLight tl, JunctionConnector connector, Graphics2D g, Matrix matrix, boolean highlight) {
		try {

			LaneSegment srcLaneSeg = connector.getSourceLaneSegment();
			List<Vector> rightEdge = srcLaneSeg.getRightEdge();

			Vector dirBackVector = CollectionUtil.getLastObject(rightEdge).minus(CollectionUtil.getSecondToLastObject(rightEdge)).unify().inverse();
			Vector pos = CollectionUtil.getLastObject(rightEdge).plus(dirBackVector.multiplyBy(2))
					.plus(dirBackVector.normal(false).multiplyBy(srcLaneSeg.getRoadSegment().getRoadWidth()));
			pos = matrix.multiply(pos);
			double rad = 1 * matrix.getScaleFactor();
			double dia = rad * 2;

			Vector posRed = new Vector(pos.x - rad, pos.y - rad);
			Vector posYellow = posRed.plus(dirBackVector.mirrorY().multiplyBy(dia));
			Vector posGreen = posYellow.plus(dirBackVector.mirrorY().multiplyBy(dia));
			Vector posGreenMid = pos.plus(dirBackVector.mirrorY().multiplyBy(dia * 2));

			Stroke old = g.getStroke();

			if (highlight) {
				g.setColor(Color.GREEN);
				g.setStroke(new BasicStroke((float) (dia + rad * 0.4f)));
				g.draw(new Line2D.Double(pos.x, pos.y, posGreenMid.x, posGreenMid.y));
			} else {

				g.setColor(Color.BLACK);
				g.setStroke(new BasicStroke((float) (dia + rad * 0.4f)));
				g.draw(new Line2D.Double(pos.x, pos.y, posGreenMid.x, posGreenMid.y));
				g.setStroke(new BasicStroke((float) rad * 0.1f));
				g.setColor(Color.RED);

				g.draw(new Ellipse2D.Double(posRed.x, posRed.y, dia, dia));
				g.setColor(Color.YELLOW);
				g.draw(new Ellipse2D.Double(posYellow.x, posYellow.y, dia, dia));
				g.setColor(Color.GREEN);
				g.draw(new Ellipse2D.Double(posGreen.x, posGreen.y, dia, dia));
				g.setStroke(old);

				if (tl.getCurrentState() == TrafficLightState.GREEN) {
					g.setColor(Color.GREEN);
					g.fill(new Ellipse2D.Double(posGreen.x, posGreen.y, dia, dia));
				} else if (tl.getCurrentState() == TrafficLightState.RED) {
					g.setColor(Color.RED);
					g.fill(new Ellipse2D.Double(posRed.x, posRed.y, dia, dia));
				} else if (tl.getCurrentState() == TrafficLightState.RED_YELLOW) {
					g.setColor(Color.RED);
					g.fill(new Ellipse2D.Double(posRed.x, posRed.y, dia, dia));
					g.setColor(Color.YELLOW);
					g.fill(new Ellipse2D.Double(posYellow.x, posYellow.y, dia, dia));
				} else if (tl.getCurrentState() == TrafficLightState.YELLOW) {
					g.setColor(Color.YELLOW);
					g.fill(new Ellipse2D.Double(posYellow.x, posYellow.y, dia, dia));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void drawRoute(List<RoadSegment> route, Graphics g, Matrix matrix, Color c) {
		Graphics2D g2d = getGraphics2D(g);
		g2d.setTransform(matrix.getAffineTransform());
		g2d.setColor(c);
		g2d.setStroke(new BasicStroke(Math.max(1, (int) (3 / matrix.getScaleFactor()))));

		for (RoadSegment roadSegment : route) {
			g2d.draw(AWTAdapter.toPath2D(roadSegment.getLeftMostLane().getRoadGeometry().getPoints()));
		}
	}

	public void clearCaches() {
		junctionBoundsCache = new HashMap<>();
		lanePolygonCache = new HashMap<>();
		laneRightEdgeCache = new HashMap<>();
	}
}

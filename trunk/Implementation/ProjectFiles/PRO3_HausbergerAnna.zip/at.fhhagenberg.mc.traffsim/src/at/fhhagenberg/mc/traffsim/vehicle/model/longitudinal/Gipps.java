package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.GippsData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;

/**
 *
 * @author Manuel Lindorfer
 *
 */
public class Gipps extends LongitudinalModel implements IUpdateTimeDependableLongitudinalModel, IComposableLongitudinalModel {

	private GippsData data;
	private double dt;

	public Gipps(){
		
	}
	
	public Gipps(double simulationTimestep, GippsData data) {
		super(data.getIdentifier());
		dt = simulationTimestep;
		fullname = data.getFullname();
		this.data = data;
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {

		final double v0Local = Math.min(alphaV0 * data.getvTarget(), speedLimit);
		final double TLocal = alphaT * dt;

		final double vp = v - dv;

		// safe speed
		final double a = data.getComfortableAcc();
		final double b = -data.getSafeDec();
		final double vSafe = -b * TLocal + Math.sqrt(b * b * TLocal * TLocal + vp * vp + 2 * b * Math.max(s - data.getsMin(), 0.));
		final double vNew = Math.min(vSafe, Math.min(v + a * TLocal, v0Local));
		final double aWanted = (vNew - v) / TLocal;
		return aWanted;
	}

	@Override
	public LongitudinalModel createCopyFor(double speed) {
		GippsData newData = new Kryo().copy(data);
		newData.setvTarget(speed);
		return new Gipps(dt, newData);
	}

	@Override
	public LongitudinalModelData getModelData() {
		return data;
	}

	@Override
	public boolean isSafeAcceleration(double acceleration) {
		return acceleration < data.getMaxAcc() && acceleration > data.getMaxDec();
	}

	@Override
	public void setSimulationTimestep(double simulationTimestep) {
		dt = simulationTimestep;
	}

	@Override
	public double calcAccComponent(double v, double speedLimit, double alphaT, double alphaV0, double alphaA) {
		final double v0Local = Math.min(alphaV0 * data.getvTarget(), speedLimit);
		final double TLocal = alphaT * dt;
		final double a = data.getComfortableAcc();
		final double vNew = Math.min(v + a * TLocal, v0Local);
		return (vNew - v) / TLocal;
	}

	@Override
	public double calcBrakeComponent(double v, double speedLimit, double s, double dv, double aLead, double alphaT, double alphaV0,
			double alphaA, double renormalizationFactor) {
		final double v0Local = Math.min(alphaV0 * data.getvTarget(), speedLimit);
		final double TLocal = alphaT * dt;
		final double vp = v - dv;
		final double b = -data.getSafeDec();
		final double vSafe = -b * TLocal + Math.sqrt(b * b * TLocal * TLocal + vp * vp + 2 * b * Math.max(s - data.getsMin(), 0.));
		final double vNew = Math.min(vSafe, v0Local);
		return (vNew - v) / TLocal;
	}
}
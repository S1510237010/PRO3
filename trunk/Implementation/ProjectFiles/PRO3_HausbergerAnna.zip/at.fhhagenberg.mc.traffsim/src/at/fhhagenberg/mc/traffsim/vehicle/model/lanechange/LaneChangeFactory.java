package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;

public class LaneChangeFactory {
	public static LaneChangeDecision decisionToLeft() {
		return new LaneChangeDecision(Lane.TO_LEFT);
	}

	public static LaneChangeDecision decisionToRight() {
		return new LaneChangeDecision(Lane.TO_RIGHT);
	}

	public static LaneChangeDecision decisionStayInLane() {
		return new LaneChangeDecision(Lane.NO_CHANGE);
	}

	public static LaneChangeDecision decisionStayInLaneMandatory() {
		LaneChangeDecision lcd = new LaneChangeDecision(Lane.NO_CHANGE);
		lcd.setMandatory(true);
		return lcd;
	}
}

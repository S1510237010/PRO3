package at.fhhagenberg.mc.traffsim.ui.rcp.helper;

import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;

/**
 * Multiple purpose {@link KeyAdapter} which only allows number digits as input for {@link Text} fields.
 * 
 * @author Christian Backfrieder
 * 
 */
public abstract class NumberOnlyKeyAdapter extends KeyAdapter {

	private String additionalChars;

	public NumberOnlyKeyAdapter() {
	}

	public NumberOnlyKeyAdapter(String additionalChars) {
		this.additionalChars = additionalChars;
	}

	@Override
	public void keyReleased(final KeyEvent e) {
		getCurrentDisplay().asyncExec(new Runnable() {
			public void run() {
				if (e.getSource() instanceof Text) {
					Text t = (Text) e.getSource();
					final String current = ((Text) e.getSource()).getText();
					final String newStr = t.getText().replaceAll("[^\\d." + additionalChars + "]", "");
					if (!current.equals(newStr)) {
						t.setText(newStr);
					}
				}
			}
		});
	}

	/**
	 * Must provide the current display in order to get the current {@link Display} thread for determination of {@link Text} contents
	 * 
	 * @return the current {@link Display}
	 */
	public abstract Display getCurrentDisplay();
}

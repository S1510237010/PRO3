package at.fhhagenberg.mc.traffsim.communication.messaging;

import at.fhhagenberg.mc.traffsim.model.geo.Location;

public class Message<T extends MessagePayload> {
	long id;
	static long NEXT_ID = 0;
	Location origin;
	Location destination;
	T payload;
	private Object metadata;

	public Message(Location origin) {
		this.id = NEXT_ID++;
		this.origin = origin;
	}

	public Message(Location origin, T payload) {
		this(origin);
		setPayload(payload);
	}

	public Message(Location origin, T payload, Object metadata) {
		this(origin);
		setPayload(payload);
		this.metadata = metadata;
	}

	public Location getOrigin() {
		return origin;
	}

	public T getPayload() {
		return payload;
	}

	public void setPayload(T payload) {
		this.payload = payload;
	}

	public final long getId() {
		return id;
	}

	public Object getMetadata() {
		return metadata;
	}

}

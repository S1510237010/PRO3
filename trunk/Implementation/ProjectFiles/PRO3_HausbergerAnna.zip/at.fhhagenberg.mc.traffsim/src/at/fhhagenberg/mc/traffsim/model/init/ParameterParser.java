package at.fhhagenberg.mc.traffsim.model.init;

import java.lang.reflect.Field;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.ParameterBean;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.PropertyValues;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.model.init.NameGenerator.NameFormat;
import at.fhhagenberg.mc.traffsim.routing.rerouter.AbstractCostEvaluator;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICongestionProvider;
import at.fhhagenberg.mc.traffsim.routing.rerouter.congestion.GlobalCongestionProvider;
import at.fhhagenberg.mc.traffsim.routing.rerouter.congestion.GreenshieldCostEvaluatorAndCongestionProvider;
import at.fhhagenberg.mc.traffsim.routing.rerouter.congestion.SpeedAverageCostEvaluatorAndCongestionProvider;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelRegistry;
import at.fhhagenberg.mc.util.LinkedProperties;
import at.fhhagenberg.mc.util.ReflectionUtil;

public class ParameterParser {
	/** separator between parameterset ID and potential appended arrayparameter-suffix */
	public static final String PARAMETER_ID_SEPARATOR = "#";
	/** the separator between multi-parameter sets */
	public static final String MULTIPARAMETERSET_SEPARATOR = "-";
	/** the separator between key and value of parameter setup */
	public static final String KEYVALUE_SEPARATOR = "=";
	/** keyword for changing a model's fields */
	public static final String MODEL_ADAPTION_PREFIX_KEYWORD = "ADJUSTMODEL";
	/** separator for model adaption between keyword, model name and value name */
	public static final String MODEL_ADAPTION_SEPARATOR = "-";

	private static final String ARRAY_PARAMETER_PREFIX = "array";
	private static final String ARRAY_PARAMETER_SEPARATOR = ":";
	private Properties simParameters;
	private SimulationModel model;
	private AbstractCostEvaluator costEval;
	private ICongestionProvider congProv;
	private boolean costAndCongestionProviderInitialized = false;

	public ParameterParser(SimulationModel model, Properties simParameters) {
		this.simParameters = simParameters;
		this.model = model;
	}

	private void initCostAndCongestionProvider() throws LoadingException {
		if (costAndCongestionProviderInitialized) {
			return;
		} else {
			costAndCongestionProviderInitialized = true;
		}

		String costEvalMode = PropertyUtil.getStringProperty(simParameters, PropertyKeys.ROUTING_COST_EVALUATION, PropertyValues.UNDEFINED);
		String congestionEvalMode = PropertyUtil.getStringProperty(simParameters, PropertyKeys.CONGESTION_EVALUATION, PropertyValues.UNDEFINED);
		if (!costEvalMode.equals(PropertyValues.UNDEFINED)) {
			int movingAverageSize = PropertyUtil.getIntProperty(simParameters, PropertyKeys.REROUTING_AVERAGEING_WINDOW_SIZE,
					TrafficDefaults.DEFAULT_REROUTING_AVERAGING_WINDOW_SIZE);
			int congestionLevel = PropertyUtil.getIntProperty(simParameters, PropertyKeys.CONGESTION_SEGMENT_LEVEL,
					PropertyValues.DEFAULT_CONGESTION_LEVEL);

			if (costEvalMode.equals(PropertyValues.GREENSHIELD)) {
				// cost evaluation by greenshields model
				costEval = createGreenShieldCECP(movingAverageSize, congestionLevel);
				Logger.logInfo("Initializing greenshield cost evaluator");
			} else if (costEvalMode.equals(PropertyValues.SPEED_AVERAGE)) {
				// cost evaluation by continuous model
				costEval = createSpeedAverageCECP(movingAverageSize, congestionLevel);
				Logger.logInfo("Initializing speed average cost evaluator");
			} else {
				throw new LoadingException("Unknown cost evaluation mode: " + costEvalMode + " Check parameters! Stopping simulation and exit.");
			}
			if (costEval != null) {
				costEval.setObservationCenter(model.getObservationCenter());
				Logger.logDebug("Set up " + costEval.getClass().getName());
			}

			if (!congestionEvalMode.equals(PropertyValues.UNDEFINED)) {
				if (congestionEvalMode.equals(PropertyValues.GREENSHIELD)) {
					if (costEvalMode.equals(PropertyValues.GREENSHIELD)) {
						congProv = (GreenshieldCostEvaluatorAndCongestionProvider) costEval;
					} else {
						congProv = createGreenShieldCECP(movingAverageSize, congestionLevel);
					}
				} else if (congestionEvalMode.equals(PropertyValues.SPEED_AVERAGE)) {
					if (costEvalMode.equals(PropertyValues.SPEED_AVERAGE)) {
						congProv = (SpeedAverageCostEvaluatorAndCongestionProvider) costEval;
					} else {
						congProv = createSpeedAverageCECP(movingAverageSize, congestionLevel);
					}
				} else if (congestionEvalMode.equals(PropertyValues.GLOBAL)) {
					congProv = new GlobalCongestionProvider(model);
				}
				if (congProv != null) {
					Logger.logDebug("Set up " + congProv.getClass().getCanonicalName());
				}
			} else {
				Logger.logWarn("Congestion mode is undefined: '" + congestionEvalMode + "'. Running without congestion detection!");
			}
		}
	}

	private GreenshieldCostEvaluatorAndCongestionProvider createGreenShieldCECP(int movingAverageSize, int congestionLevel) {
		float congestionThresholdDelta = PropertyUtil.getDoubleProperty(simParameters, PropertyKeys.GREENSHIELD_CONGESTION_THRESHOLD_DELTA,
				PropertyValues.DEFAULT_CONGESTION_THRESHOLD_DELTA).floatValue();
		final int minVehiclesForCongestion = PropertyUtil.getIntProperty(simParameters, PropertyKeys.MINIMUM_VEHICLES_FOR_CONGESTION,
				PropertyValues.DEFAULT_MINIMUM_VEHICLES_FOR_CONGESTION);
		return new GreenshieldCostEvaluatorAndCongestionProvider("Greenshield Cost Evaluator " + model.getUniqueId(), 500, 2500, model.getNetwork(),
				model.getRouteService(), movingAverageSize, congestionThresholdDelta, congestionLevel, minVehiclesForCongestion, model);
	}

	private SpeedAverageCostEvaluatorAndCongestionProvider createSpeedAverageCECP(int movingAverageSize, int congestionLevel) {
		float congestionThreshold = PropertyUtil
				.getDoubleProperty(simParameters, PropertyKeys.SPEED_AVERAGE_CONGESTION_THRESHOLD, PropertyValues.DEFAULT_CONGESTION_THRESHOLD_DELTA)
				.floatValue();
		final int minVehiclesForCongestion = PropertyUtil.getIntProperty(simParameters, PropertyKeys.MINIMUM_VEHICLES_FOR_CONGESTION,
				PropertyValues.DEFAULT_MINIMUM_VEHICLES_FOR_CONGESTION);
		return new SpeedAverageCostEvaluatorAndCongestionProvider("Speed Average Cost Evaluator " + model.getUniqueId(), 500, 2500,
				model.getNetwork(), model.getRouteService(), movingAverageSize, congestionThreshold, congestionLevel, minVehiclesForCongestion,
				model);
	}

	/**
	 * Parses the parameters provided in the constructor once and generates the configured {@link AbstractCostEvaluator}
	 *
	 * @return the generated cost evaluator, or <code>null</code> if no evaluator is defined
	 * @throws LoadingException
	 *             if the configured cost evaluation mode is unknown
	 */
	public AbstractCostEvaluator getCostEval() throws LoadingException {
		initCostAndCongestionProvider();
		return costEval;
	}

	public ICongestionProvider getCongProv() throws LoadingException {
		initCostAndCongestionProvider();
		return congProv;
	}

	/**
	 * Parses all parameters from the provided bean. Can handle array parameters in the format "array:&lt;val1&gt;,&lt;val2&gt;,...", i.e. a
	 * parameter staring with prefix "array:", followed by a comma separated list of values which are all handled as a specific parameter
	 * set
	 *
	 * The size of the returned map equals the number of combinations of all array parameters.<br>
	 * <b>Example:</b>
	 * <ul>
	 * <li>array:1,2,3</li>
	 * <li>array:4,5,6</li>
	 * <ul>
	 * The given example leads to 9 configurations labeled with index of used param, in order of occurence (#00 1-4, #01 1-5, #02 1-6, #10
	 * 2-4, #11 2-5, #12 2-6, #20 3-4, #21 3-5,#22 3-6)
	 *
	 * @param bean
	 * @return map of property set ID to properties that are already enrolled
	 */
	public static Map<String, LinkedProperties> getAllMultiParameters(ParameterBean bean) {
		Map<String, LinkedProperties> configsToCreate = new HashMap<>();
		configsToCreate.put(bean.getId() + "", bean.getProperties());
		/** finished indicates whether configstocreate contains any wildcard values */
		boolean foundArrayValue = true;
		while (foundArrayValue) {
			foundArrayValue = false;
			Map<String, LinkedProperties> enrolledConfigs = new HashMap<>();
			for (String lbl : configsToCreate.keySet()) {
				LinkedProperties properties = configsToCreate.get(lbl);
				for (Object o : properties.keySet()) {
					String key = (String) o;
					String val = properties.getProperty(key);
					if (val.startsWith(ARRAY_PARAMETER_PREFIX + ARRAY_PARAMETER_SEPARATOR)) {
						foundArrayValue = true;
						String arrayParam = val.replace(ARRAY_PARAMETER_PREFIX + ARRAY_PARAMETER_SEPARATOR, "");
						String paramNameAbbreviation = "";
						if (arrayParam.contains(ARRAY_PARAMETER_SEPARATOR)) {
							paramNameAbbreviation = arrayParam.substring(0, arrayParam.indexOf(ARRAY_PARAMETER_SEPARATOR));
							arrayParam = arrayParam.replace(paramNameAbbreviation + ARRAY_PARAMETER_SEPARATOR, "");
						}
						String[] array = arrayParam.split(",");
						for (int i = 0; i < array.length; i++) {
							String variedVal = array[i];
							LinkedProperties newProps = PropertyUtil.clone(properties);
							newProps.replace(key, variedVal);
							String insertion = "";
							String separator = "";
							if (!lbl.contains(PARAMETER_ID_SEPARATOR)) {
								insertion = PARAMETER_ID_SEPARATOR;
							} else {
								separator = MULTIPARAMETERSET_SEPARATOR;
							}
							String suffix = separator
									+ (paramNameAbbreviation.isEmpty() ? String.valueOf(i) : paramNameAbbreviation + "=" + variedVal);
							String identifier = lbl + insertion + suffix;
							enrolledConfigs.put(identifier, newProps);
						}
						break;
					}
				}
			}
			if (foundArrayValue) {
				configsToCreate = enrolledConfigs;
			}
		}
		return configsToCreate;
	}

	public static final void adaptModels(ModelRegistry registry, Properties parameters) {
		Enumeration<Object> e = parameters.keys();
		while (e.hasMoreElements()) {
			Object key = e.nextElement();
			if (key.toString().startsWith(MODEL_ADAPTION_PREFIX_KEYWORD)) {
				String value = parameters.getProperty(key.toString());
				String[] keysplit = key.toString().split(MODEL_ADAPTION_SEPARATOR);
				if (keysplit.length != 3) {
					Logger.logWarn("Could not parse model adaption parameter: " + key + " - " + value);
				}

				String modelname = keysplit[1];
				String fieldname = keysplit[2];
				Object m = registry.getModel(modelname);
				if (m == null) {
					Logger.logError("Could not find model to adapt: " + modelname);
					continue;
				}
				try {
					Field f = m.getClass().getDeclaredField(fieldname);
					Class<?> paramClassType = f.getType();
					f.setAccessible(true);
					f.set(m, ReflectionUtil.convertToTargetType(value, paramClassType));
				} catch (NoSuchFieldException | SecurityException | IllegalAccessException | IllegalArgumentException e1) {
					try {
						ReflectionUtil.callSetterForField(m, fieldname, value);
					} catch (Exception e2) {
						Logger.logError("Could not adapt the parameter " + fieldname + " of model " + modelname + " to " + value, e2);
					}
				}
			}
		}
	}

	public static Map<String, Properties> getSimulationParameterSets(List<? extends AbstractBean> parameterBeans) {
		Map<String, Properties> parameterSets = new HashMap<>();
		for (AbstractBean bean : parameterBeans) {
			ParameterBean params = (ParameterBean) bean;
			if (params.isEnabled()) {
				Map<String, LinkedProperties> enrolledProperties = ParameterParser.getAllMultiParameters(params);
				for (String propId : enrolledProperties.keySet()) {
					Properties prop = enrolledProperties.get(propId);

					PropertyUtil.set(prop, PropertyKeys.SIMULATION_SET_SUBFOLDER, NameGenerator.getIdentifier(propId, params, NameFormat.FILENAME));
					String label = "Set " + NameGenerator.getIdentifier(propId, params, NameFormat.LABEL);
					PropertyUtil.set(prop, PropertyKeys.PARAMETERSET_ID, propId);
					parameterSets.put(label, prop);
				}
			}
		}
		return parameterSets;
	}

}

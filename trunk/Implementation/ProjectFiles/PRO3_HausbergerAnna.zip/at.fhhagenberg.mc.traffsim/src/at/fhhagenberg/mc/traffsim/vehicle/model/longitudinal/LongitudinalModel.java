package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.AbstractModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;

public abstract class LongitudinalModel extends AbstractModel implements ILongitudinalModel {

	protected String identifier, fullname;

	public LongitudinalModel(){
		
	}
	
	public LongitudinalModel(String identifier) {
		this.identifier = identifier;
	}

	/* (non-Javadoc)
	 * @see at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel#calcAcc(at.fhhagenberg.mc.traffsim.vehicle.Vehicle, double, double, double, double, double, double, double, double)
	 */
	@Override
	public abstract double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit);

	/**
	 * Create a deep copy of this model, with the new target speed set to the given parameter
	 * 
	 * @param newSpeed
	 *            new targte speed
	 * @return deep copy of this model
	 */
	public LongitudinalModel createModelCopy(double newSpeed) {
		LongitudinalModel newModel = createCopyFor(newSpeed);
		return newModel;
	}

	public abstract LongitudinalModel createCopyFor(double speed);

	public String getFullname() {
		return fullname;
	}

	public String getIdentifier() {
		return identifier;
	}

	/* (non-Javadoc)
	 * @see at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel#getModelData()
	 */
	@Override
	public abstract LongitudinalModelData getModelData();

	@Override
	public String getName() {
		return identifier + (fullname == null ? "" : " (" + fullname + ")");
	}

	@Override
	public abstract boolean isSafeAcceleration(double acceleration);

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

}
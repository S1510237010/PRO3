package at.fhhagenberg.mc.traffsim.routing.rerouter.footprint;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import at.fhhagenberg.mc.traffsim.communication.IVehicleInformationReceiver;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICostProvider;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Additional {@link ICostProvider} which calculates the footprint of a {@link RoadSegment} as weight of planned routes crossing this
 * segment. Therewith, a heuristic can be provided which foresees the future congestion for a road segment
 * 
 * @author Christian Backfrieder
 * 
 */
public class RoadFootprintGenerator implements ICostProvider, IVehicleInformationReceiver {
	/** map of segment id to number of assigned routes which reference this segment */
	private Map<Long, Long> vehicleCount = new ConcurrentHashMap<>();
	/** map of segment id to associated weight */
	private Map<Long, Double> weightMap = new ConcurrentHashMap<>();
	private SimulationModel model;
	private double footprintSum;
	private int weight;

	private enum Operation {
		INCREASE(1), DECREASE(-1);
		private int dir;

		Operation(int dir) {
			this.dir = dir;
		}

		public int summand() {
			return dir;
		}
	};

	public RoadFootprintGenerator(SimulationModel model, int weight) {
		model.getObservationCenter().registerInformationReceiver(this);
		this.model = model;
		if (weight < 1 || weight > 99) {
			throw new IllegalArgumentException("Weight must be between 1 and 99 (was " + weight + ")");
		}
		this.weight = weight;
		initWeightSum();
	}

	private void initWeightSum() {
		// TODO: how to init footprint sum?

	}

	@Override
	public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {
		if (oldLane != null && oldLane.getRoadSegment() != null) {
			changeVehicleCount(oldLane.getRoadSegment().getId(), Operation.DECREASE);
		}
	}

	private void updateFootprint(IRoute route, RoadSegment currentRoadSegment, Operation op) {
		RoadSegment cur = currentRoadSegment;
		changeVehicleCount(cur.getId(), op);
		int start = currentRoadSegment.getRoutingId() == route.getNextRoutingId() ? 1 : 0;
		for (int i = start; i < route.getRouteIds().size(); i++) {
			Long routingId = route.getRouteIds().get(i);
			if (cur.getSinkRoadSegment() != null) {
				cur = cur.getSinkRoadSegment();
			} else if (cur.getJunction() != null) {
				for (Long segId : cur.getEndNode().getSinkReferences()) {
					RoadSegment segTesting = model.getNetwork().getRoadSegmentByKey(segId);
					if (model.getNetwork().getRoadSegmentByKey(segId).getRoutingId() == routingId) {
						cur = segTesting;
						break;
					}
				}
				// Logger.logError("Problem when updating footprint: could not find next routing id " + routingId);
			}
			if (cur.getRoutingId() != routingId) {
				Logger.logError(
						"Problem when updating footprint: expected routing id " + routingId + ", current value " + cur.getRoutingId());
				break;
			}
			changeVehicleCount(cur.getId(), op);
		}
	}

	@Override
	public double getCost(long segId) {
		Long vCnt = vehicleCount.get(segId);
		if (vCnt == null) {
			return 0;
		}
		return vCnt * getSegmentWeight(segId);
	}

	private double getSegmentWeight(long segId) {
		if (!weightMap.containsKey(segId)) {
			RoadSegment seg = model.getNetwork().getRoadSegmentByKey(segId);
			double weight = (model.getNetwork().getAverageSegmentLength() / seg.getRoadLength() * seg.getLaneCount())
					* (model.getNetwork().getAverageSpeedLimitMps() / seg.getSpeedLimitMps());
			weightMap.put(segId, weight);
		}
		return weightMap.get(segId);
	}

	/**
	 * Update the number of vehicles which have assigned paths passing the respective segment
	 * 
	 * @param id
	 * @param op
	 */
	private void changeVehicleCount(long id, Operation op) {
		if (!vehicleCount.containsKey(id)) {
			vehicleCount.put(id, (long) 0);
		}
		vehicleCount.put(id, Math.max(0, vehicleCount.get(id) + op.summand()));
		footprintSum += getSegmentWeight(id) * op.summand();
	}

	@Override
	public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute) {
		if (!v.isRoutable()) {
			return;
		}
		if (oldRoute != null) {
			updateFootprint(oldRoute, currentSegment, Operation.DECREASE);
		}
		updateFootprint(newRoute, currentSegment, Operation.INCREASE);
	}

	@Override
	public double getCurrentCostSum() {
		return footprintSum;
	}

	@Override
	public double getNormalizedCost(long segmentId) {
		return getCost(segmentId) / footprintSum;
	}

	@Override
	public int getWeight() {
		return weight;
	}

	public long getVehicleCount(long segmentId) {
		Long cnt = vehicleCount.get(segmentId);
		if (cnt == null) {
			return 0;
		}
		return cnt;
	}

	@Override
	public String getCommReceiverName() {
		// TODO Auto-generated method stub
		return null;
	}
}

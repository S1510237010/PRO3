package at.fhhagenberg.mc.traffsim.deadlock;

public interface IDeadlockListener {
	public void deadlockDetected();
}

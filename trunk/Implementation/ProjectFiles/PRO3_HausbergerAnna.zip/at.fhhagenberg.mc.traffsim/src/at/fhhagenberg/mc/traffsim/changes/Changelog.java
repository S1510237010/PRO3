package at.fhhagenberg.mc.traffsim.changes;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("changelog")
public class Changelog {
	@XStreamImplicit
	private List<ChangeSetList> changeSetLists;

	public List<ChangeSetList> getChangeSetLists() {
		return changeSetLists;
	}

	public void setChangeSetLists(List<ChangeSetList> changeSetLists) {
		this.changeSetLists = changeSetLists;
	}
}

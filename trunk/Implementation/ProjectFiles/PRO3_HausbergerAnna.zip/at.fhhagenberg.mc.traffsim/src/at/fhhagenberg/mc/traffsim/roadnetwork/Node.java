package at.fhhagenberg.mc.traffsim.roadnetwork;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.model.geo.Location;

public class Node {
	private Location location;
	private double altitude = Double.NaN;

	private long id;
	private List<Long> sourceReferences = new ArrayList<>();
	private List<Long> sinkReferences = new ArrayList<>();
	private Set<Long> routingReferences = new HashSet<>();
	private Map<Long, Long> segmentRoutingMapping = new HashMap<>();
	private NodeType type;

	private boolean ramp = false;

	public Node(long id) {
		this.id = id;
	}

	public Node(long id, double altitude, NodeType type) {
		this.id = id;
		this.altitude = altitude;
		this.type = type;
	}

	/**
	 * Add {@link RoadSegment} id as a source of this node
	 * 
	 * @param id
	 *            of road segment
	 * @param routingId
	 *            the routing id of the segment
	 */
	public void addSourceReference(long id, long routingId) {
		sourceReferences.add(id);
		routingReferences.add(routingId);
		segmentRoutingMapping.put(id, routingId);
	}

	/**
	 * Add a routing id as a reference of this node (independent of in or out)
	 * 
	 * @param id
	 */
	public void addRoutingReference(long id) {
		routingReferences.add(id);
	}

	/**
	 * Add a {@link RoadSegment} id as sink of this node
	 * 
	 * @param id
	 *            of road segment
	 * @param routingId
	 *            of road segment
	 */
	public void addSinkReference(long id, long routingId) {
		sinkReferences.add(id);
		routingReferences.add(routingId);
		segmentRoutingMapping.put(id, routingId);
	}

	public List<Long> getSourceReferences() {
		return sourceReferences;
	}

	public List<Long> getSinkReferences() {
		return sinkReferences;
	}

	/**
	 * 
	 * @return Id of this {@link Node}
	 */
	public long getId() {
		return id;
	}

	public Set<Long> getRoutingReferences() {
		return routingReferences;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		if (location != null && !location.equals(this.location)) {
			this.location = location;
			// update altitude
		}
	}

	/**
	 * Check if this node has zero sources
	 * 
	 * @return true if this road starts from outside area of interest (no incoming connections modeled)
	 */
	public boolean isSourceDeadEnd() {
		return sourceReferences.isEmpty() || isDeadEndWithMultipleLanes();
	}

	/**
	 * Check if this node has zero sinks
	 * 
	 * @return true if this road ends outside area of interest (no outgoing connections modeled, cars disappear)
	 */
	public boolean isSinkDeadEnd() {
		return sinkReferences.isEmpty() || isDeadEndWithMultipleLanes();
	}

	private boolean isDeadEndWithMultipleLanes() {
		if (sourceReferences.size() == 1 && sinkReferences.size() == 1 && segmentRoutingMapping.get(sourceReferences.get(0)) != null
				&& segmentRoutingMapping.get(sourceReferences.get(0)).equals(segmentRoutingMapping.get(sinkReferences.get(0)))) {
			return true;
		}
		return false;
	}

	public Map<Long, Long> getSegmentRoutingMapping() {
		return segmentRoutingMapping;
	}

	@Override
	public String toString() {
		return id + " (src " + Arrays.toString(sourceReferences.toArray()) + ", sink " + Arrays.toString(sinkReferences.toArray()) + ")";
	}

	public double getAltitude() {
		return altitude;
	}

	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	public boolean isRamp() {
		return ramp;
	}

	public void setRamp(boolean ramp) {
		this.ramp = ramp;
	}

	public NodeType getType() {
		return type;
	}

	public void setType(NodeType type) {
		this.type = type;
	}
}

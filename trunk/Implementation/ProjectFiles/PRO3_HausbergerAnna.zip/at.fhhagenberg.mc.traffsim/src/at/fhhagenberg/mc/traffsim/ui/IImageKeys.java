package at.fhhagenberg.mc.traffsim.ui;

public interface IImageKeys {
	final String ICON_FOLDER = "icons/";
	final String ROAD_SIGN_FOLDER = ICON_FOLDER + "roadsigns/";
	final String COMMANDS_FOLDER = ICON_FOLDER + "commands/";
	final String CURSOR_FOLDER = ICON_FOLDER + "cursors/";
	final String TRAFFIC_LIGHT_FOLDER = ICON_FOLDER + "trafficlights/";
	final String ACTIONS_FOLDER = ICON_FOLDER + "actions/";
	final String STATE_FOLDER = ICON_FOLDER + "states/";

	final String CLOCK_PLAY = ICON_FOLDER + "clock_play.png";

	final String CURSOR_DRAG = CURSOR_FOLDER + "cursor_drag.png";
	final String CURSOR_SELECT = CURSOR_FOLDER + "cursor_select.png";
	final String CURSOR_ZOOM = CURSOR_FOLDER + "cursor_zoom.gif";
	final String CURSOR_OBSTACLE = CURSOR_FOLDER + "obstruction.png";

	final String PAUSE = COMMANDS_FOLDER + "control_pause_blue.png";
	final String PLAY = COMMANDS_FOLDER + "control_play_blue.png";
	final String STOP = COMMANDS_FOLDER + "control_stop_blue.png";

	final String TRAFFICLIGHT_GREEN = TRAFFIC_LIGHT_FOLDER.concat("traffic_light_green.png");
	final String TRAFFICLIGHT_RED = TRAFFIC_LIGHT_FOLDER.concat("traffic_light_red.png");
	final String TRAFFICLIGHT_YELLOW = TRAFFIC_LIGHT_FOLDER.concat("traffic_light_yellow.png");

	final String ROAD_SIGN_GIVE_WAY = ROAD_SIGN_FOLDER + "give_way.png";
	final String ROAD_SIGN_PRIORITY_ROAD = ROAD_SIGN_FOLDER + "priority_road.png";
	final String ROAD_SIGN_STOP = ROAD_SIGN_FOLDER + "stop.png";

	final String ACTION_ADD = ACTIONS_FOLDER + "add.png";
	final String ACTION_MINUS_WHITE = ACTIONS_FOLDER + "white_minus.jpg";
	final String ACTION_PLUS_WHITE = ACTIONS_FOLDER + "white_plus.gif";
	final String ACTION_UPDATE = ACTIONS_FOLDER + "update.png";
	final String ACTION_ENTER = ACTIONS_FOLDER + "enter.png";
	final String ACTION_CRASH = ACTIONS_FOLDER + "crash.gif";
	final String ACTION_CONGESTION = ACTIONS_FOLDER + "traffic_jam.gif";
	final String ACTION_VARIABLE_CHANGED = ACTIONS_FOLDER + "debug_edit.png";
	final String ACTION_DRIVING_MODE_SWITCHED = ACTIONS_FOLDER + "switch.png";
	final String ACTION_DEBUG_SESSION_STARTED = ACTIONS_FOLDER + "debug_start.png";
	final String ACTION_DEBUG_SESSION_COMPLETED = ACTIONS_FOLDER + "debug_delete.png";

	final String STATE_RUNNING = STATE_FOLDER + "state_running.png";
	final String STATE_STOPPED = STATE_FOLDER + "state_stopped.png";
	final String ROUTE = ICON_FOLDER + "route.png";
}

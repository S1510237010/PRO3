package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

public class LongitudinalModelInputParameterSet {

	private long vehicleId;
	private double v;
	private double dv;
	private double s;
	private double aLead;
	private double alphaA;
	private double alphaT;
	private double alphaV0;
	private double appliedAcc;

	// Pseudo-random error variables for estimation and driving errors
	private double distanceNoise;
	private double vDiffNoise;
	private double accNoise;

	public LongitudinalModelInputParameterSet(long vId, double appliedAcc, double v, double dv, double s, double aLead, double alphaA,
			double alphaT, double alphaV0) {
		this.vehicleId = vId;
		this.appliedAcc = appliedAcc;
		this.v = v;
		this.dv = dv;
		this.s = s;
		this.aLead = aLead;
		this.alphaA = alphaA;
		this.alphaT = alphaT;
		this.alphaV0 = alphaV0;
		this.vDiffNoise = 0d;
		this.distanceNoise = 0d;
		this.accNoise = 0d;
	}

	public long getVehicleId() {
		return vehicleId;
	}

	public double getV() {
		return v;
	}

	public void setV(double v) {
		this.v = v;
	}

	public double getDv() {
		return dv;
	}

	public void setDv(double dv) {
		this.dv = dv;
	}

	public double getS() {
		return s;
	}

	public void setS(double s) {
		this.s = s;
	}

	public double getALead() {
		return aLead;
	}

	public void setALead(double aLead) {
		this.aLead = aLead;
	}

	public double getAlphaA() {
		return alphaA;
	}

	public void setAlphaA(double alphaA) {
		this.alphaA = alphaA;
	}

	public double getAlphaT() {
		return alphaT;
	}

	public void setAlphaT(double alphaT) {
		this.alphaT = alphaT;
	}

	public double getAlphaV0() {
		return alphaV0;
	}

	public void setAlphaV0(double alphaV0) {
		this.alphaV0 = alphaV0;
	}

	public double getAppliedAcc() {
		return appliedAcc;
	}

	public void setAppliedAcc(double a) {
		appliedAcc = a;
	}

	public double getDistanceNoise() {
		return distanceNoise;
	}

	public void setDistanceNoise(double distanceNoise) {
		this.distanceNoise = distanceNoise;
	}

	public double getSpeedDifferenceNoise() {
		return vDiffNoise;
	}

	public void setSpeedDifferenceNoise(double vDiffNoise) {
		this.vDiffNoise = vDiffNoise;
	}

	public double getAccelerationNoise() {
		return accNoise;
	}

	public void setAccelerationNoise(double accNoise) {
		this.accNoise = accNoise;
	}
}
package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.communication.MessageTransfer;
import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.filter.DefaultViewerFilter;
import at.fhhagenberg.mc.util.DateUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class MessageQueueView extends BaseTableViewerView implements IModelInputChangedListener, ISimulationStateListener {

	private List<MessageTransfer> messages = new ArrayList<>();
	private SimulationModel currentModel;
	private Text textFind;
	private Text textFilter;
	private PauseableThread msgUpdater = new PauseableThread("MessageQueueView updater", 1000) {

		@Override
		public void doWork() {
			updateMessages();
		}
	};

	private class MessageQueueComparator extends BaseViewerComparator {
		@Override
		public int compare(Viewer viewer, Object e1, Object e2) {
			MessageTransfer evt1 = (MessageTransfer) e1;
			MessageTransfer evt2 = (MessageTransfer) e2;
			int rc = 0;
			switch (propertyIndex) {
			case 0:
				rc = new Long(evt1.getMessage().getId()).compareTo(evt2.getMessage().getId());
				break;
			case 1:
				rc = new Long(evt1.getStartTime()).compareTo(evt2.getStartTime());
				break;
			case 2:
				rc = new Long(evt1.getEndTime()).compareTo(evt2.getEndTime());
				break;
			case 3:
				rc = evt1.getSender().getCommName().compareTo(evt2.getSender().getCommName());
				break;
			case 4:
				rc = evt1.getReceiver().getCommName().compareTo(evt2.getReceiver().getCommName());
				break;
			default:
				rc = 0;
			}
			
			// If descending order, flip the direction
			if (direction == DESCENDING) {
				rc = -rc;
			}
			
			return rc;
		}
	}

	@Override
	public void dispose() {
		msgUpdater.stopAndDestroy();
		super.dispose();
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout(SWT.HORIZONTAL));

		// Set the sorter for the table
		comparator = new MessageQueueComparator();

		Composite composite_1 = new Composite(parent, SWT.NONE);
		composite_1.setLayout(new GridLayout(1, false));

		Composite compositeTop = new Composite(composite_1, SWT.NONE);
		compositeTop.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));
		compositeTop.setLayout(new GridLayout(7, false));

		textFind = new Text(compositeTop, SWT.BORDER);
		textFind.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textFind.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.keyCode == SWT.CR || e.keyCode == SWT.KEYPAD_CR) {
					doFind();
				}
			}
		});
		Button btnFind = new Button(compositeTop, SWT.NONE);
		btnFind.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				doFind();
			}
		});
		btnFind.setText("Find");

		textFilter = new Text(compositeTop, SWT.BORDER);
		textFilter.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		final Button btnFilter = new Button(compositeTop, SWT.TOGGLE);
		btnFilter.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnFilter.getSelection()) {
					btnFilter.setText("Filter ON");
					refreshFilter(textFilter.getText());
				} else {
					btnFilter.setText("Filter OFF");
					refreshFilter("");
				}
			}
		});
		btnFilter.setText("Filter OFF");

		Label lblUpdateCycle = new Label(compositeTop, SWT.NONE);
		lblUpdateCycle.setText("Update Cycle [ms]");

		Spinner spinner = new Spinner(compositeTop, SWT.BORDER);
		spinner.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				msgUpdater.setDelayInMillis(spinner.getSelection());
			}
		});
		spinner.setIncrement(500);
		spinner.setPageIncrement(5000);
		spinner.setMaximum(100000);
		spinner.setMinimum(500);
		spinner.setSelection(1000);

		Button btnAutoupdate = new Button(compositeTop, SWT.TOGGLE);
		btnAutoupdate.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnAutoupdate.getSelection()) {
					if (msgUpdater.isAlive()) {
						msgUpdater.proceed();
					} else {
						msgUpdater.start();
					}
				} else {
					msgUpdater.pause();
				}
			}
		});
		btnAutoupdate.setText("Auto-Update");

		textFilter.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (btnFilter.getSelection()) {
					refreshFilter(textFilter.getText());
				}
			}
		});

		Composite composite = new Composite(composite_1, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		composite.setLayout(new FillLayout());

		viewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI);
		table = viewer.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		filter = new DefaultViewerFilter("");
		viewer.addFilter(filter);

		createColumns(viewer);
		viewer.setContentProvider(new ArrayContentProvider());
		viewer.setInput(messages);
		viewer.setComparator(comparator);

	}

	protected void doFind() {
		String toFind = textFind.getText();
		int selIndex = (viewer.getTable().getSelectionIndex());
		if (selIndex < 0) {
			selIndex = 0;
		}
		boolean found = false;
		for (int i = selIndex + 1; i <= selIndex + messages.size(); i++) {
			MessageTransfer mt = (MessageTransfer) viewer.getElementAt(i % messages.size());
			if ((String.valueOf(mt.getMessage().getId()).contains(toFind) || mt.getSender().getCommName().contains(toFind)
					|| mt.getReceiver().getCommName().contains(toFind))) {
				viewer.setSelection(new StructuredSelection(mt), true);
				found = true;
				break;
			}
		}
		if (!found) {
			MessageDialog.openInformation(textFind.getShell(), "Not found", "The entered string '" + toFind + "' was not found");
		}
	}

	private void createColumns(TableViewer viewer) {
		int colindex = 0;
		TableViewerColumn colId = createTableViewerColumn(viewer, "ID", 50, colindex++);
		colId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				MessageTransfer mt = (MessageTransfer) element;
				return mt.getMessage().getId() + "";
			}
		});

		TableViewerColumn colTypeName = createTableViewerColumn(viewer, "Start", 80, colindex++);
		colTypeName.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				MessageTransfer mt = (MessageTransfer) element;
				return DateUtil.formatWithMiliseconds(new Date(mt.getStartTime()), true);
			}

		});

		TableViewerColumn colDate = createTableViewerColumn(viewer, "End", 80, colindex++);
		colDate.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				MessageTransfer mt = (MessageTransfer) element;
				return DateUtil.formatWithMiliseconds(new Date(mt.getEndTime()), true);
			}
		});

		TableViewerColumn colDetails = createTableViewerColumn(viewer, "Sender", 100, colindex++);
		colDetails.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				MessageTransfer mt = (MessageTransfer) element;
				return mt.getSender().getCommName();
			}
		});

		TableViewerColumn colSegmentId = createTableViewerColumn(viewer, "Receiver", 100, colindex++);
		colSegmentId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				MessageTransfer mt = (MessageTransfer) element;
				return mt.getReceiver().getCommName();
			}
		});

		TableViewerColumn colNodeId = createTableViewerColumn(viewer, "Size", 50, colindex++);
		colNodeId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				MessageTransfer mt = (MessageTransfer) element;
				return StringUtil.humanReadableByteCount(mt.getMessage().getPayload().getSize(), false);
			}
		});

		TableViewerColumn colSeverity = createTableViewerColumn(viewer, "Payload", 150, colindex++);
		colSeverity.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				MessageTransfer mt = (MessageTransfer) element;
				return mt.getMessage().getPayload().getClass().getSimpleName();
			}
		});
	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (newModel != null) {
			if (currentModel != null) {
				currentModel.removeSimulationStateListener(this);
			}
			currentModel = newModel;
			newModel.addSimulationStateListener(this);
			updateMessages();
		}
	}

	private void updateMessages() {
		if (currentModel != null && currentModel.getCommunicator() != null) {
			messages = new ArrayList<>();
			Iterator<MessageTransfer> it = currentModel.getCommunicator().getMessageQueue().iterator();
			MessageTransfer cur = null;
			for (int i = 0; i < 100 && it.hasNext(); i++, cur = it.next()) {
				if (cur != null) {
					messages.add(cur);
				}
			}
			if (viewer != null) {
				getSite().getShell().getDisplay().asyncExec(new Runnable() {

					@Override
					public void run() {
						viewer.setInput(messages);
						viewer.refresh();
					}

				});
			}
		}

	}

	@Override
	public void simulationStateChanged(SimulationModel model, SimulationState oldState, SimulationState newState) {
		if (model.equals(currentModel)) {
			if (SimulationState.isSimulationRunningAfter(newState)) {
				msgUpdater.proceed();
			} else {
				msgUpdater.pause();
			}
		}
	}

	@Override
	protected BaseViewerComparator createComparator() {
		MessageQueueComparator comparator = new MessageQueueComparator();
		return comparator;
	}
}

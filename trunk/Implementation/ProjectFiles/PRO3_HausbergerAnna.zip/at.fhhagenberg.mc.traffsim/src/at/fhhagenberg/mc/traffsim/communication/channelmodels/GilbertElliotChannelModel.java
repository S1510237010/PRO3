package at.fhhagenberg.mc.traffsim.communication.channelmodels;

import java.util.Random;

import at.fhhagenberg.mc.traffsim.communication.IChannelModel;

public class GilbertElliotChannelModel implements IChannelModel, Cloneable {
	/** probability of staying in good state if already in good state (between 0 and 1) */
	private float pGoodGood;
	/** probability of staying in bad state (between 0 and 1) */
	private float pBadBad;
	/** the time to be added to delay if transmission failed */
	private long roundtripMillisMean;

	private double stdDevRoundTripMillis;

	private Random random = new Random();

	private enum State {
		GOOD, BAD
	}

	private State curState = State.GOOD;
	private String name;

	public GilbertElliotChannelModel() {
	}

	public GilbertElliotChannelModel(float pGoodGood, float pBadBad, long roundtripMillisMean, double stdDevRoundTripMillis) {
		super();
		this.pGoodGood = pGoodGood;
		this.pBadBad = pBadBad;
		this.roundtripMillisMean = roundtripMillisMean;
		this.stdDevRoundTripMillis = stdDevRoundTripMillis;
	}

	@Override
	public IChannelModel clone() throws CloneNotSupportedException {
		return new GilbertElliotChannelModel(pGoodGood, pBadBad, roundtripMillisMean, stdDevRoundTripMillis);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see at.fhhagenberg.mc.traffsim.communication.IChannelModel#getNextDelay()
	 */
	@Override
	public long getNextDelay() {
		long curRoundTrip = 0;
		do {
			double rand = random.nextDouble();
			if (curState == State.GOOD) {
				if (rand > pGoodGood) {
					curState = State.BAD;
				}
			} else {
				if (rand > pBadBad) {
					curState = State.GOOD;
				}
			}
			curRoundTrip += roundtripMillisMean + random.nextGaussian() * stdDevRoundTripMillis;
		} while (curState == State.BAD);
		return curRoundTrip;
	}

	public void setRandomSeed(long randomSeed) {
		random = new Random(randomSeed);
	}

	@Override
	public boolean isSuccessful() {
		return true;
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

package at.fhhagenberg.mc.traffsim.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

import com.itextpdf.awt.PdfGraphics2D;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.generator.AbstractVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.TrafficObstructionGenerator;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationObserver;
import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.routing.RoutingException;
import at.fhhagenberg.mc.traffsim.ui.color.ColorSet;
import at.fhhagenberg.mc.traffsim.ui.color.DimensionLessColorSet;
import at.fhhagenberg.mc.traffsim.ui.color.IElement;
import at.fhhagenberg.mc.traffsim.ui.controller.TraffSimController;
import at.fhhagenberg.mc.traffsim.ui.osm.TileType;
import at.fhhagenberg.mc.traffsim.ui.osm.TraffSimTileFactoryProvider;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.SimulationView;
import at.fhhagenberg.mc.traffsim.util.BitUtil;
import at.fhhagenberg.mc.traffsim.util.CoordinateUtil;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.ui.AWTAdapter;
import at.fhhagenberg.mc.traffsim.util.ui.SWTUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Obstruction;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;
import at.fhhagenberg.mc.util.DateUtil;

/**
 * Represents the model of the MVC pattern of TraffSim UI. Receives events from the {@link TraffSimController} and draws them on the
 * simulationView {@link SimulationView}.
 *
 * @author Christian
 */

public class UiModel extends BaseUiModel implements ISimulationTimeUpdatable {
	ScreenCapture capture = new ScreenCapture();
	/**
	 * Clipping area for drawing the items will be extended by the following amount of pixels to ensure no items are hidden even if a part
	 * of them should be visible
	 */
	private static final int CLIPPING_EXTENSION_PIXELS = 5;
	/**
	 * Necessary area will be enlarged by this factor to avoid feeling of cut-offs at the edges
	 */
	private static final double ZTF_BLEED_FACTOR = 1.05;
	private static final long NOT_VISIBILE = -1;
	/**
	 * Correction of loaded map to open street map background (any error in preprocessing queue from OSM to our format)
	 */
	private static final double ROTATION_CORRECTION = -0.007;
	/** controller of mvc-pattern */
	/** simulationView of mvc pattern */
	private SimulationView simulationView = null;
	private BufferedImage staticImage = null;
	private ColorSet activeColorSet = new DimensionLessColorSet();
	private PauseableThread updateThread;

	private List<Location> pointsToDraw = new ArrayList<>();
	private Map<Long, DrawableArtifact> shapesToDraw = new HashMap<>();
	private long shapeIndex = 0;

	private boolean forceRedraw;

	private double lastStatusUpdate = 0;

	private Map<String, DetailsOverlay> details = new HashMap<>();
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

	private int uiFlags;

	private SimulationModel simulationModel;
	private Rectangle selectedArea;
	private long selectedAreaShapeId = NOT_VISIBILE;

	private int osmZoomLevel = UiConstants.DEFAULT_ZOOM_LEVEL;
	private boolean osmZoomAvailable;
	private boolean showOsmMap;
	private TileType tileType;
	private SimulationObserver simObserver;
	protected DrawingContext drawingContext;
	protected boolean screenCapture = true;
	private List<Route> routesToDraw = new ArrayList<>();
	private List<Route> staticRoutesToDraw = new ArrayList<>();

	/**
	 * standard constructor that initializes members
	 *
	 * @param simulationView
	 *            the view to be connected
	 * @param model
	 *            the {@link SimulationModel} to be connected
	 */
	public UiModel(SimulationView simulationView, SimulationModel model) {
		transformMatrix = new Matrix(1, 0, 0, 0, 1, 0, 0, 0, 1);
		this.simulationView = simulationView;
		this.simulationModel = model;
	}

	private void createUiUpdateThread() {
		int uiUpdateTime = PreferenceUtil.getBoolean(IPreferenceConstants.UI_UPDATE_ENABLED)
				? PreferenceUtil.getInt(IPreferenceConstants.UI_UPDATE_TIME) : Integer.MAX_VALUE;
		updateThread = new PauseableThread("UI update", uiUpdateTime) {
			private boolean staticDataLoaded = false;
			private String vehiclesInSimulationString;
			private long vehiclesInSimulation = -1;
			private Point vehiclesInSimulationLocation;
			private int paintMapErrors = 0;
			private boolean captureResizeQuestionOpen;
			private boolean enableScreenCapturePref;

			/** listen to preference changes */
			private IPropertyChangeListener propChangeListener = new IPropertyChangeListener() {

				@Override
				public void propertyChange(PropertyChangeEvent event) {
					if (event.getProperty().equals(IPreferenceConstants.ENABLE_SCREEN_CAPTURE)) {
						enableScreenCapturePref = (boolean) event.getNewValue();
					} else if (event.getProperty().equals(IPreferenceConstants.UI_UPDATE_TIME)) {
						int newDelay = (int) event.getNewValue();
						setUiUpdateTime(newDelay);
						simulationView.updateResolutionAndDelay(-1, newDelay);
					}
				}
			};

			@Override
			public void init() {
				drawingContext = new DrawingContext();
				PreferenceUtil.addPropertyChangeListener(propChangeListener);
			}

			@Override
			public void doWork() {
				Matrix matrixWhenStartedDrawing = new Matrix(transformMatrix);
				BufferedImage completeImage = null;
				if (staticImage == null || forceRedraw) {
					// System.out.println("redraw");
					Image img = simulationView.createAWTImage();
					if (img == null) {
						return;
					}
					completeImage = (BufferedImage) img;

					// osm stuff ///////////////////////
					if (osmZoomAvailable) {
						Vector mapCenter = getMapPoint(new Vector((double) completeImage.getWidth() / 2, (double) completeImage.getHeight() / 2));
						Location wgs84 = CoordinateUtil.toWGS84Coordinate(mapCenter);
						simulationView.setCenterPoint(wgs84.y, wgs84.x);
					}
					simulationView.getDrawingPanel().setShowOsmMap(showOsmMap && osmZoomAvailable);
					// //////////////

					/** simply draw the polygon that was set before */
					Graphics g = completeImage.getGraphics();

					staticDataLoaded = drawStaticContent(g, completeImage.getWidth(), completeImage.getHeight(), matrixWhenStartedDrawing,
							drawingContext);
					staticImage = cloneImage(completeImage);
				} else {
					completeImage = new BufferedImage(staticImage.getWidth(), staticImage.getHeight(), staticImage.getType());
					completeImage.getGraphics().drawImage(staticImage, 0, 0, null);
				}

				Graphics g = completeImage.getGraphics();
				// dynamic objects
				drawDynamicContent(g, completeImage.getWidth(), completeImage.getHeight(), matrixWhenStartedDrawing, drawingContext);
				// draw details
				drawDetails(g, completeImage.getHeight(), matrixWhenStartedDrawing, drawingContext);
				// num vehicles
				if (simObserver != null) {
					long totalVeh = simObserver.getCurNumVehicles();
					if (vehiclesInSimulation != totalVeh || forceRedraw) {
						vehiclesInSimulationString = String.format("%d  vehicles in simulation (%.1f%% routable)", totalVeh,
								totalVeh > 0 ? (((double) simObserver.getCurNumRoutableVehicles()) / totalVeh * 100) : 0);
						vehiclesInSimulation = totalVeh;
						vehiclesInSimulationLocation = new Point(completeImage.getWidth() - 10, 15);
					}
					drawingContext.drawString(vehiclesInSimulationString, g, vehiclesInSimulationLocation, true, new Font("Arial", Font.PLAIN, 9),
							Color.BLACK);
				} // update image
				simulationView.setImage(completeImage);
				/** set scale only if data is loaded already */
				if (staticDataLoaded) {
					simulationView.setScale(calculateScale(transformMatrix));
				}

				if (enableScreenCapturePref && simulationModel.isSimulationRunning()) {
					if (!capture.isInitialized()) {
						capture.init(simulationModel.getOutputFolder(), "capture_" + DateUtil.formatForFile(simulationModel.getStartDate()),
								completeImage.getWidth(), completeImage.getHeight());
					}
					if (simulationModel.getCurrentSimTime() != null) {
						BufferedImage img = new BufferedImage(completeImage.getWidth(), completeImage.getHeight(), completeImage.getType());
						if (showOsmMap && paintMapErrors < 5) {
							Graphics2D g2 = (Graphics2D) img.getGraphics();
							g2.setClip(0, 0, completeImage.getWidth(), completeImage.getHeight());
							try {
								simulationView.getDrawingPanel().paintMapRaw(g2);
							} catch (Exception e) {
								paintMapErrors++;
								Logger.logError("Could not draw background map");
							}
						} else {
							img.getGraphics().setColor(Color.WHITE);
							img.getGraphics().fillRect(0, 0, img.getWidth(), img.getHeight());
						}
						img.getGraphics().drawImage(completeImage, 0, 0, null);
						try {
							capture.encode(img, (long) (simulationModel.getSimRuntimeSeconds() * 1000
									/ PreferenceUtil.getInt(IPreferenceConstants.SCREEN_CAPTURE_SPEEDUP)));
						} catch (Exception e) {
							PreferenceUtil.setBoolean(IPreferenceConstants.ENABLE_SCREEN_CAPTURE, false);
							if (e.getMessage().startsWith("could not resample")) {
								// problem: resized image
								Logger.logWarn("Cannot continue capture if screen is resized. Stop capturing");
								if (!captureResizeQuestionOpen) {
									simulationView.getSite().getWorkbenchWindow().getShell().getDisplay().asyncExec(new Runnable() {

										@Override
										public void run() {
											captureResizeQuestionOpen = true;
											simulationModel.setSimulationRunning(false);
											if (MessageDialog.openQuestion(simulationView.getSite().getWorkbenchWindow().getShell(),
													"Restart capturing",
													"Window was resized. Do you want to restart capturing?\n\nIf yes, old capture video is deleted and a new one is created. Otherwise, capture is disabled.")) {
												capture.reset();
												PreferenceUtil.setBoolean(IPreferenceConstants.ENABLE_SCREEN_CAPTURE, true);
											} else {
												capture.close();
											}
											captureResizeQuestionOpen = false;
										}
									});
								}
							}
						}
					}
				}
				// check if m changed during drawing, if yes, draw again
				// until id did not change
				Dimension size = simulationView.getDrawingSize();
				if (matrixWhenStartedDrawing.equals(transformMatrix) && completeImage.getWidth() + 2 == size.width
						&& completeImage.getHeight() + 2 == size.height) {
					forceRedraw = false;
					pause();
				}
			}

			@Override
			protected void preStop() {
				PreferenceUtil.removePropertyChangeListener(propChangeListener);
			}
		};
		updateThread.setPriority(Thread.MAX_PRIORITY);
		updateThread.start();
	}

	private boolean drawStaticContent(Graphics g, int width, int height, Matrix matrix, DrawingContext drawingContext) {
		/** draw background */
		g.setColor(Color.BLACK);
		Rectangle clippingArea = new Rectangle(getMapPoint(new Point(-CLIPPING_EXTENSION_PIXELS, -CLIPPING_EXTENSION_PIXELS)));
		clippingArea.add(getMapPoint(new Point(width + CLIPPING_EXTENSION_PIXELS * 2, height + CLIPPING_EXTENSION_PIXELS * 2)));
		if (simulationModel.getNetwork() != null) {
			// Graphics2D g2d = (Graphics2D)g;
			// AffineTransform trans = g2d.getTransform();
			// g2d.setTransform(matrix.getAffineTransform());
			((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			for (AbstractJunction c : simulationModel.getNetwork().getJunctions()) {
				if (c.getBoundsRectangle().intersects(clippingArea)) {
					drawingContext.drawJunction(c, g, matrix, activeColorSet, uiFlags);
				}
			}
			for (RoadSegment r : simulationModel.getNetwork().getRoadSegments()) {
				if (r.getBoundsRectangle().intersects(clippingArea) && r.getBounds().intersects(clippingArea)) {
					drawingContext.drawRoadSegment(r, g, matrix, activeColorSet, uiFlags);

					if (BitUtil.isSet(uiFlags, UiFlag.SHOW_DETECTORS) && PreferenceUtil.getBoolean(IPreferenceConstants.SHOW_LOOP_DETECTORS)) {
						for (LoopDetector detector : simulationModel.getNetwork().getDetectorsForRoadSegment(r.getId(), true)) {
							for (Vector loc : detector.getAbsolutePositions()) {
								Color color = activeColorSet.getColor(IElement.DETECTOR);
								drawingContext.drawDetector(loc, g, matrix, color, uiFlags);
							}
						}
					}
				}
			}

			// g2d.setTransform(trans);
			for (Location vec : pointsToDraw) {
				drawingContext.drawMarker(vec, g, matrix, activeColorSet);
			}
			for (DrawableArtifact da : shapesToDraw.values()) {
				drawingContext.drawArtifact(da, g, matrix);
			}

			// Draw routes
			List<Color> colors = SWTUtil.createColorCodeTable(routesToDraw.size(), Color.red, 0.85f);
			for (Route rt : routesToDraw) {
				List<RoadSegment> segList = new ArrayList<>();
				try {
					RoutingUtil.traverseRoute(rt, rt.getInitialSegment(), seg -> segList.add(seg));
					drawingContext.drawRoute(segList, g, matrix, colors.get(routesToDraw.indexOf(rt)));
				} catch (RoutingException e) {
					Logger.logWarn("Could not traverse route for UI output: " + e.getMessage());
				}
			}

			// Draw static routes
			colors = SWTUtil.createColorCodeTable(staticRoutesToDraw.size(), Color.blue, 0.6f);
			for (Route rt : staticRoutesToDraw) {
				List<RoadSegment> segList = new ArrayList<>();
				try {
					RoutingUtil.traverseRoute(rt, rt.getInitialSegment(), seg -> segList.add(seg));
					drawingContext.drawRoute(segList, g, matrix, colors.get(staticRoutesToDraw.indexOf(rt)));
				} catch (RoutingException e) {
					Logger.logWarn("Could not traverse static route for UI output: " + e.getMessage());
				}
			}
		} else {
			String loadingStr = "LOADING ...";
			Rectangle area = matrix.multiply(clippingArea);
			Font f = new Font("Tahoma", 0, 25);
			Point loc = new Point(10, 30);
			g.setColor(new Color(210, 210, 210));
			g.fillRect(0, 0, area.width, area.height);
			drawingContext.drawString(loadingStr, g, loc, false, f, Color.GRAY);
			return false;
		}
		// draw scale indicator
		drawingContext.drawAxes(getMapPoint(new Vector(0, 0)), getMapPoint(new Vector(width, height - CLIPPING_EXTENSION_PIXELS)), g,
				transformMatrix);
		return true;
	}

	private void drawDynamicContent(Graphics g, int width, int height, Matrix matrix, DrawingContext drawingContext) {
		Rectangle clippingArea = new Rectangle(getMapPoint(new Point(-CLIPPING_EXTENSION_PIXELS, -CLIPPING_EXTENSION_PIXELS)));
		clippingArea.add(getMapPoint(new Point(width + CLIPPING_EXTENSION_PIXELS * 2, height + CLIPPING_EXTENSION_PIXELS * 2)));
		if (simulationModel != null && simulationModel.getNetwork() != null) {
			((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			for (AbstractJunction c : simulationModel.getNetwork().getJunctions()) {
				for (Vehicle v : c.getVehicles()) {
					drawingContext.drawVehicle(v, g, matrix, activeColorSet, uiFlags);
				}
				for (JunctionConnector conn : c.getConnectors()) {
					if (conn.getTrafficLight() != null) {
						drawingContext.drawTrafficLight(conn.getTrafficLight(), conn, (Graphics2D) g, matrix, false);
					}
				}
			}
			for (RoadSegment r : simulationModel.getNetwork().getRoadSegments()) {
				if (r.getBounds().intersects(clippingArea)) {
					for (LaneSegment l : r.getLaneSegments()) {
						for (Iterator<Vehicle> it = l.getVehiclesCopy().iterator(); it.hasNext();) {
							Vehicle v = it.next();
							drawingContext.drawVehicle(v, g, matrix, activeColorSet, uiFlags);
						}
					}
				}
			}
		}
	}

	private void drawDetails(Graphics g, int height, Matrix matrix, DrawingContext drawingContext) {
		int lastY = -1;
		int offset = 0;
		for (DetailsOverlay d : details.values()) {
			if (NumberUtil.doubleEquals(lastY, d.getPos().y)) {
				offset -= 5;
			}
			drawingContext.drawDetails(d.getText(), g, matrix, activeColorSet, new Vector(d.getPos().x, d.getPos().y + offset), d.getAlpha());
			lastY = (int) d.getPos().y;
		}
		// draw scale indicator
		drawingContext.drawScaleIndicator(g, matrix, height);
	}

	public void generatePdf(File cellFile) {
		try {

			// save cell view
			Dimension size = simulationView.getDrawingSize();
			Document document = new Document(new com.itextpdf.text.Rectangle(size.width, size.height));

			File parent = cellFile.getParentFile();
			if (!parent.exists() && !parent.mkdirs()) {
				throw new IllegalStateException("Couldn't create dir: " + parent);
			}

			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(cellFile));
			document.open();

			PdfGraphics2D g2 = new PdfGraphics2D(writer.getDirectContent(), size.width, size.height);
			DrawingContext drawingContext = new DrawingContext();

			if (showOsmMap && osmZoomAvailable) {
				simulationView.getDrawingPanel().paintMap(g2);
			}
			drawStaticContent(g2, size.width, size.height, transformMatrix, drawingContext);
			drawDynamicContent(g2, size.width, size.height, transformMatrix, drawingContext);
			drawDetails(g2, size.height, transformMatrix, drawingContext);

			g2.dispose();
			document.close();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace(); // To change body of catch statement use File |
									// Settings | File Templates.
		}
	}

	/**
	 * Call this method if any geometries of the road network have been changed
	 */
	public void clearDrawingCaches() {
		if (drawingContext != null) {
			drawingContext.clearCaches();
		}
	}

	public BufferedImage toCompatibleImage(BufferedImage image) {
		// obtain the current system graphical settings
		GraphicsConfiguration gfx_config = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();

		/*
		 * if image is already compatible and optimized for current system settings, simply return it
		 */
		if (image.getColorModel().equals(gfx_config.getColorModel()))
			return image;

		// image is not optimized, so create a new image that is
		BufferedImage new_image = gfx_config.createCompatibleImage(image.getWidth(), image.getHeight(), image.getTransparency());

		// get the graphics context of the new image to draw the old image on
		Graphics2D g2d = (Graphics2D) new_image.getGraphics();

		// actually draw the image and dispose of context no longer needed
		g2d.drawImage(image, 0, 0, null);
		g2d.dispose();

		// return the new optimized image
		return new_image;
	}

	public void setView(SimulationView newView) {
		simulationView = newView;
	}

	/**
	 * Zoom with point as base for zooming
	 *
	 * @param pt
	 *            base point
	 * @param factor
	 *            to zoom in or out (should be greater than zero)
	 */
	@Override
	public void zoom(Point pt, double factor) {
		zoom(pt, factor, false);
	}

	public void zoom(Point pt, double factor, boolean adjustFactorIfOsmIncompatible) {
		if (factor > 0) {
			if (adjustFactorIfOsmIncompatible && showOsmMap) {
				if (factor > 1) {
					factor = Math.round(factor / 2) * 2;
				} else {
					factor = 1 / (double) Math.round(factor * 2);
				}
			}
			transformMatrix = Matrix.zoomPoint(transformMatrix, pt, factor);
			fixOSMScaleFit();
			updateView(true);
		}
	}

	/**
	 * Zoom in or out around _factor, using center as base point
	 *
	 * @param factor
	 *            to zoom in or out
	 */
	public void zoom(Double factor) {
		zoom(factor, false);
	}

	/**
	 * Zoom in or out around _factor, using center as base point
	 *
	 * @param _factor
	 *            to zoom in or out
	 * @param fixToOsmLevels
	 */
	public void zoom(Double _factor, boolean fixToOsmLevels) {
		Point zoomPoint = new Point(simulationView.getDrawingSize().width >> 1, simulationView.getDrawingSize().height >> 1);
		zoom(zoomPoint, _factor, fixToOsmLevels);
	}

	/**
	 * Zoom to fit the the drawing in the window area
	 */
	public void zoomToFit() {
		if (simulationModel.getNetwork() != null && simulationView != null) {
			Rectangle mapBounds = new Rectangle(getMapBounds(simulationModel.getNetwork().getRoadSegments()));
			mapBounds.x -= (mapBounds.width * ZTF_BLEED_FACTOR - mapBounds.width) / 2;
			mapBounds.y -= (mapBounds.height * ZTF_BLEED_FACTOR - mapBounds.height) / 2;
			mapBounds.width *= ZTF_BLEED_FACTOR;
			mapBounds.height *= ZTF_BLEED_FACTOR;
			Rectangle drawingSize = new Rectangle(simulationView.getDrawingSize());
			transformMatrix = Matrix.rotate(ROTATION_CORRECTION).multiply(Matrix.zoomToFit(mapBounds, drawingSize));
			zoomScale(fixOSMScaleFit());
		}
	}

	/**
	 *
	 * @return the scale factor which fits to the osm discrete levels
	 */
	private long fixOSMScaleFit() {
		int scale = calculateScale(transformMatrix);
		long mindiff = Long.MAX_VALUE;
		int index = 0;
		for (int i = 0; i < tileType.getScales().length; i++) {
			long diff = Math.abs(tileType.getScales()[i] - scale);
			if (diff < mindiff) {
				mindiff = diff;
				index = i;
			}
		}
		osmZoomLevel = index;
		osmZoomAvailable = (scale >= tileType.getScales()[0] && scale <= tileType.getScales()[tileType.getScales().length - 1]);
		return tileType.getScales()[Math.max(0, index)];
	}

	/**
	 * Calculate bounding box of all objects to draw
	 *
	 * @param _geoObjects
	 *            list of objects to iterate over
	 * @return Rectangle representing the bounding box
	 */
	private Rectangle getMapBounds(List<RoadSegment> objects) {
		Rectangle boundingBox = null;
		/** check if polygon array contains any elements */
		if (objects != null && objects.size() > 0) {
			for (RoadSegment rs : objects) {
				for (LaneSegment ls : rs.getLaneSegments()) {
					for (Vector vec : ls.getRoadGeometry().getPoints()) {
						Point pt = new Point((int) vec.x, (int) vec.y);
						if (boundingBox == null) {
							boundingBox = new Rectangle(pt);
						} else {
							boundingBox.add(pt);
						}
					}
				}
			}

		} else {
			return new Rectangle(simulationView.getDrawingSize());
		}
		return boundingBox;
	}

	/**
	 * set a new zoom rectangle to display
	 *
	 * @param _zoomRectangle
	 */
	public void setZoomRectangle(Rectangle _zoomRectangle) {
		simulationView.drawZoomRectangle(_zoomRectangle);
	}

	/**
	 * updates the simulationView by redrawing all polygons and the zoom rectangle
	 */
	@Override
	public void updateView(final boolean forceRedraw) {
		if (updateThread == null) {
			createUiUpdateThread();
			// init preferences
			IPreferenceStore prefStore = TraffSimCorePlugin.getDefault().getPreferenceStore();
			setUiFlag(UiFlag.VEHICLE_DETAILS, (prefStore.getString(IPreferenceConstants.VEHICLE_PRINT).equals(IPreferenceConstants.PRINT_DETAILS)));
			setUiFlag(UiFlag.VEHICLE_IDS, prefStore.getString(IPreferenceConstants.VEHICLE_PRINT).equals(IPreferenceConstants.PRINT_IDS));
			setUiFlag(UiFlag.JUNCTION_DEBUG, prefStore.getBoolean(IPreferenceConstants.DEBUG_JUNCTION_INFO));
			setUiFlag(UiFlag.LANE_DEBUG, prefStore.getBoolean(IPreferenceConstants.DEBUG_LANE_INFO));
			setUiFlag(UiFlag.SHOW_DETECTORS, prefStore.getBoolean(IPreferenceConstants.SHOW_LOOP_DETECTORS));
			setUiFlag(UiFlag.SPEED_LIMITS, prefStore.getBoolean(IPreferenceConstants.PRINT_SPEED_LIMITS));
			setUiFlag(UiFlag.TRANSPARENT_ROADS, prefStore.getBoolean(IPreferenceConstants.TRANSPARENT_ROADS));
		}
		synchronized (updateThread) {
			if (forceRedraw) {
				this.forceRedraw = true;
			}
			updateThread.proceed(forceRedraw);
		}
	}

	public void addPoint(Location point) {
		this.pointsToDraw.add(point);
	}

	public BufferedImage cloneImage(BufferedImage _source) {
		if (_source == null) {
			return _source;
		}
		WritableRaster raster = _source.copyData(null);
		return new BufferedImage(_source.getColorModel(), raster, _source.isAlphaPremultiplied(), null);
	}

	/**
	 * Zoom in to the rectangle given as a parameter - using the smaller factor of x and y difference
	 *
	 * @param zoomRect
	 *            rectangle to zoom in to
	 */
	public void zoomTo(Rectangle zoomRect) {
		/** ignore zoom if rectangle is too small */
		if (zoomRect == null || zoomRect.width < UiConstants.MIN_ZOOMRECT_SIZE || zoomRect.height < UiConstants.MIN_ZOOMRECT_SIZE) {
			return;
		}
		double factorX = simulationView.getDrawingSize().getWidth() / zoomRect.getWidth();
		double factorY = simulationView.getDrawingSize().getHeight() / zoomRect.getHeight();
		/** take smaller zoomfactor */
		double zoomFactor = factorX > factorY ? factorY : factorX;
		zoom(new Point((int) zoomRect.getCenterX(), (int) zoomRect.getCenterY()), zoomFactor);
		zoomScale(fixOSMScaleFit());
	}

	public void zoomTo(Location realCoordinates, double factor) {
		zoomToFit();
		Location screenCoords = transformMatrix.multiply(realCoordinates);
		Rectangle zoomRect = new Rectangle((int) screenCoords.x, (int) screenCoords.y, 10, 10);
		zoomTo(zoomRect);
		addPoint(realCoordinates);
	}

	public void zoomTo(Location realCoordinates) {
		zoomTo(realCoordinates, 0.5);
	}

	/**
	 * Recognizes a click on the drawing area. Display information of the clicked geo object.
	 *
	 * @param screenCoords
	 */
	@Override
	public void clickedOn(Point screenCoords, int mouseOptionState) {
		if (!simulationModel.isLoaded()) {
			return;
		}
		Point realCoordinates = getMapPoint(screenCoords);
		details.clear();

		if (mouseOptionState == UiConstants.MOUSE_STATE_SELECT) {

			if (PreferenceUtil.getBoolean(IPreferenceConstants.SHOW_DETAIL_UPON_SELECTION)) {

				if (PreferenceUtil.getBoolean(IPreferenceConstants.SHOW_LOOP_DETECTORS)) {
					for (LoopDetector detector : simulationModel.getNetwork().getLoopDetectors()) {
						List<Vector> signalPointPositions = detector.getAbsolutePositions();

						for (Vector position : signalPointPositions) {
							Ellipse2D bounds = AWTAdapter.toEllipse(position, TrafficDefaults.DEFAULT_DETECTOR_RADIUS);

							if (bounds != null && bounds.contains(realCoordinates)) {
								for (LaneSegment ls : detector.getRoadSegment().getLaneSegments()) {
									if (AWTAdapter.toPolygon(ls.getBounds()).contains(realCoordinates)) {
										details.put("DET_" + detector.getIdentifier(), new DetailsOverlay(
												new Vector(realCoordinates.x, realCoordinates.y), detector.getDetails(ls.getLaneIndex())));
										break;
									}
								}

								break;
							}
						}
					}
				}

				if (details.isEmpty()) {
					for (RoadSegment s : simulationModel.getNetwork().getRoadSegments()) {
						if ((s.getBounds()).contains(realCoordinates)) {
							List<Vehicle> allVeh = new ArrayList<>(s.getAllVehicles());
							if (s.getJunction() != null) {
								allVeh.addAll(s.getJunction().getVehicles());
							} else if (s.getSinkRoadSegment() != null) {
								allVeh.addAll(s.getSinkRoadSegment().getAllVehicles());
							}
							if (s.getSourceJunction() != null) {
								allVeh.addAll(s.getSourceJunction().getVehicles());
							} else if (s.getSourceRoadSegment() != null) {
								allVeh.addAll(s.getSourceRoadSegment().getAllVehicles());
							}

							for (Vehicle v : allVeh) {
								Polygon poly = AWTAdapter.toPolygon(v.getBoundsPolygon());
								if (poly != null && poly.contains(realCoordinates)) {
									details.put("VEH_" + v.getUniqueId(),
											new DetailsOverlay(new Vector(realCoordinates.x, realCoordinates.y), v.getDetails()));
									break;
								}
							}

							if (details.isEmpty()) {
								String lsDetails = "";
								for (LaneSegment ls : s.getLaneSegments()) {
									if (AWTAdapter.toPolygon(ls.getBounds()).contains(realCoordinates)) {
										lsDetails = String.format("LaneSegment %d, type %s\n%d vehicles", ls.getLaneIndex(), ls.getLaneType(),
												ls.getVehicles().size());
									}
								}
								String rsDetails = String.format("%s\nRouting Cost: %.2fm, %.2fs\n%s", s.toString(),
										simulationModel.getRouteService() != null
												? simulationModel.getRouteService().getKmCosts(s.getRoutingId(), s.isOsmReverse()) * 1000 : 0,
										simulationModel.getRouteService() != null
												? simulationModel.getRouteService().getHCosts(s.getRoutingId(), s.isOsmReverse()) * 3600 : 0,
										lsDetails);
								details.put("RS_" + s.getId(), new DetailsOverlay(new Vector(realCoordinates.x, realCoordinates.y), rsDetails));
							}
						}
					}
				}

				if (details.isEmpty()) {
					for (AbstractJunction j : simulationModel.getNetwork().getJunctions()) {
						if (AWTAdapter.toPolygon(j.getBounds()).contains(realCoordinates)) {
							ArrayList<Vehicle> allVeh = new ArrayList<>(j.getVehicles());

							for (RoadSegment seg : j.getAllSegments()) {
								allVeh.addAll(seg.getAllVehicles());
							}

							for (Vehicle v : allVeh) {
								Polygon poly = AWTAdapter.toPolygon(v.getBoundsPolygon());
								if (poly != null && poly.contains(realCoordinates)) {
									details.put("VEH_" + v.getUniqueId(),
											new DetailsOverlay(new Vector(realCoordinates.x, realCoordinates.y), v.getDetails()));
									break;
								}
							}

							details.put("JUNC_" + j.getId(), new DetailsOverlay(new Vector(realCoordinates.x, realCoordinates.y), j.toString()));
						}
					}
				}
			}

			Rectangle sel = new Rectangle(screenCoords);
			selectArea(sel);
		} else if (mouseOptionState == UiConstants.MOUSE_STATE_ADD_OBSTRUCTION) {

			for (RoadSegment s : simulationModel.getNetwork().getRoadSegments()) {
				if ((s.getBounds()).contains(realCoordinates)) {

					for (LaneSegment ls : s.getLaneSegments()) {

						Polygon laneBounds = AWTAdapter.toPolygon(ls.getBounds());

						if (laneBounds.contains(realCoordinates)) {

							double mappingDistance = SpatialUtil.getDistance(ls.getRightEdge().get(0),
									new Vector(realCoordinates.x, realCoordinates.y));
							Obstruction obstruction = VehicleFactory.createObstruction(s, mappingDistance, simulationModel.getSimRuntimeSeconds(), 0,
									true, ls.getLaneIndex());
							simulationModel.getNetwork().addObstruction(obstruction);

							for (AbstractVehicleGenerator trafficGenerator : simulationModel.getTrafficGenerators(true)) {
								if (trafficGenerator instanceof TrafficObstructionGenerator) {
									((TrafficObstructionGenerator) trafficGenerator).addActiveObstruction(obstruction,
											simulationModel.getSimRuntimeSeconds());
								}
							}

							break;
						}
					}
				}
			}
		}

		updateView(true);
	}

	/**
	 * Calculates the point in real coordinates from screen coordinates
	 *
	 * @param _point
	 *            Point on screen
	 * @return Point on real map
	 */
	public Point getMapPoint(Point _point) {
		return transformMatrix.invers().multiply(_point);
	}

	/**
	 * Calculates the point in real coordinates from screen coordinates
	 *
	 * @param vec
	 *            Point on screen
	 * @return Point on real map
	 */
	public Vector getMapPoint(Vector vec) {
		return transformMatrix.invers().multiply(vec);
	}

	/**
	 * Calculates visible scale of the map
	 *
	 * @param _matrix
	 *            the currently valid matrix
	 * @return the current scale
	 */
	protected int calculateScale(Matrix _matrix) {
		Vector vector = new Vector(0, 1.0);
		Vector vector_transformed = _matrix.multiplyMatrix(vector);
		double screenRatio = Toolkit.getDefaultToolkit().getScreenResolution() / 0.0254d;
		double scale = screenRatio / vector_transformed.magnitude();
		// TODO: configure this via preference
		if (scale > 10000) {
			if (scale > 20000) {
				setUiFlag(UiFlag.SCALE_LARGE, true);
			} else {
				setUiFlag(UiFlag.SCALE_LARGE, false);
				setUiFlag(UiFlag.SCALE_MEDIUM, true);
			}
		} else {
			setUiFlag(UiFlag.SCALE_LARGE, false);
			setUiFlag(UiFlag.SCALE_MEDIUM, false);
			if (scale < 3000) {
				setUiFlag(UiFlag.SCALE_SMALL, true);
			} else {
				setUiFlag(UiFlag.SCALE_SMALL, false);
			}
		}
		return ((int) scale) > 0 ? (int) scale : 1;
	}

	/**
	 * zoom to the scale given
	 *
	 * @param _factor
	 *            To this scale is zoomed (1: _factor)
	 */
	public void zoomScale(long _factor) {
		zoom((double) calculateScale(transformMatrix) / (double) _factor);
	}

	/**
	 * Store the image that is currently drawn as a specified type
	 *
	 * @param _type
	 *            Type of the image as string
	 */
	public void storeImage(String _type) {
		BufferedImage bufferedImg = ImageToBitmap.getImage(simulationView.getDrawingSize().width, simulationView.getDrawingSize().height);
		bufferedImg.getGraphics().drawImage(simulationView.getImage(), 0, 0, null);
		try {
			ImageToBitmap.storeImage(bufferedImg, new BufferedOutputStream(new FileOutputStream("map." + _type)), _type);
		} catch (FileNotFoundException _e) {
			Logger.logError("File not found.", _e);
		}
	}

	public void setSimulationRunning(boolean setRunning) {
		simulationModel.setSimulationRunning(setRunning, false);
	}

	public void setDelay(int value) {
		simulationModel.setDelay(value);
	}

	public void setResolution(int value) {
		simulationModel.setResolution(value);
	}

	@Override
	public void timeStep(double dt, Date time, double runTime) {
		long current = time.getTime();
		if (current - lastStatusUpdate >= UiConstants.STATUS_UPDATE_INTERVAL_SECONDS) {
			String timeStr = dateFormat.format(simulationModel.getCurrentSimTime()) + " ("
					+ DateUtil.getTimeSpan(simulationModel.getSimRuntimeSeconds()) + " from start)";
			String runtimeStr = DateUtil.getTimeSpan(((double) simulationModel.getRunningRealtimeMillis()) / 1000, 1);
			String factorStr = String.format("%.3f",
					(double) (simulationModel.getCurrentSimTime().getTime() - simulationModel.getStartSimTime().getTime())
							/ simulationModel.getRunningRealtimeMillis());
			simulationView.setTimes(timeStr, runtimeStr, factorStr);
			lastStatusUpdate = current;
		}
		updateView(false);
	}

	/**
	 * Set a ui flag which is used to configure the drawing output
	 *
	 * @param flag
	 *            the flag to set
	 * @param set
	 *            set or unset
	 * @return true if flag was set succesfully
	 */
	public boolean setUiFlag(int flag, boolean set) {
		int oldVal = uiFlags;
		if (set) {
			uiFlags = BitUtil.set(uiFlags, flag);
		} else {
			uiFlags = BitUtil.reset(uiFlags, flag);
		}
		if (oldVal != uiFlags) {
			updateView(true);
		}
		return oldVal != uiFlags;
	}

	public void stop() {
		if (updateThread != null) {
			synchronized (updateThread) {
				updateThread.stopAndDestroy();
			}
		}
		if (capture != null) {
			capture.close();
		}
	}

	/**
	 * Select the area as given in the parameter. If its null, the old selection is refreshed.
	 *
	 * @param zoomRectangle
	 */
	public void selectArea(Rectangle zoomRectangle) {
		if (zoomRectangle == null || !simulationModel.isLoaded()) {
			return;
		}
		zoomRectangle.height = Math.max(1, zoomRectangle.height);
		zoomRectangle.width = Math.max(1, zoomRectangle.width);
		Rectangle realCoordinates = transformMatrix.invers().multiply(zoomRectangle);
		realCoordinates.height = Math.max(1, realCoordinates.height);
		realCoordinates.width = Math.max(1, realCoordinates.width);
		this.selectedArea = realCoordinates;
		IntersectionResult result = checkIntersection(simulationModel.getNetwork().getRoadSegments(), simulationModel.getNetwork().getJunctions(),
				AWTAdapter.toVectorList(realCoordinates));
		if (selectedAreaShapeId != NOT_VISIBILE) {
			showSelectedArea(false);
			showSelectedArea(true);
		}
		simulationModel.selectedItems(result.getVehicles(), result.getRoadSegments(), result.getLaneSegments(), result.getJunctions(),
				result.getConnectors());
	}

	public void selectAll() {
		selectArea(simulationView.getDrawingPanel().getBounds());
		updateView(true);
	}

	public void showSelectedArea(boolean show) {
		if (show) {
			if (selectedArea != null)
				selectedAreaShapeId = addShapeToDraw(new DrawableArtifact(selectedArea, Color.BLACK, Color.LIGHT_GRAY, null, 0.2f));
		} else {
			removeShapeToDraw(selectedAreaShapeId);
			selectedAreaShapeId = NOT_VISIBILE;
		}
		updateView(true);
	}

	/**
	 * Adds an arbitrary shape which is drawn after all other artifacts on the screen
	 *
	 * @param da
	 *            the {@link DrawableArtifact}
	 * @return the shape index
	 */
	public long addShapeToDraw(DrawableArtifact da) {
		this.shapesToDraw.put(++shapeIndex, da);
		return shapeIndex;
	}

	public void removeShapeToDraw(long index) {
		shapesToDraw.remove(index);
	}

	public int getOsmZoomLevel() {
		return osmZoomLevel;
	}

	public void setShowOsmMap(boolean show) {
		this.showOsmMap = show;
		zoomScale(fixOSMScaleFit());
		updateView(true);
	}

	public void setTileType(TileType type) {
		this.tileType = type;
		fixOSMScaleFit();
		simulationView.getDrawingPanel().setTileFactory(TraffSimTileFactoryProvider.getTileFactory(type));
		updateView(true);
	}

	public void setSimulationObserver(SimulationObserver simObserver) {
		this.simObserver = simObserver;
	}

	public void addSimulationListener(ISimulationStateListener listener) {
		simulationModel.addSimulationStateListener(listener);
	}

	public void removeSimulationListener(ISimulationStateListener listener) {
		simulationModel.removeSimulationStateListener(listener);
	}

	public void clearPoints() {
		pointsToDraw.clear();
		updateView(true);
	}

	public void setRoutesToDraw(java.util.List<Route> routes, java.util.List<Route> staticRoutes) {
		routesToDraw = routes;
		staticRoutesToDraw = staticRoutes;
		updateView(true);
	}

	public void setUiUpdateTime(int uiUpdateTime) {
		updateThread.setDelayInMillis(uiUpdateTime);
		updateThread.proceed(true);
	}

	public long getSimulationResolution() {
		return simulationModel.getSimulationResolution();
	}

	public long getSimulationDelay() {
		return simulationModel.getSimulationDelay();
	}
}
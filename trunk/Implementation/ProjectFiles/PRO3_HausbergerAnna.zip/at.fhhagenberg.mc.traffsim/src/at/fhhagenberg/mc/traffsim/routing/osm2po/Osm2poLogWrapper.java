package at.fhhagenberg.mc.traffsim.routing.osm2po;

import at.fhhagenberg.mc.traffsim.log.Logger;
import de.cm.osm2po.logging.Log;
import de.cm.osm2po.logging.LogWriter;

/**
 * Wraps the osm2po logger to the internally used {@link Logger}
 * 
 * @author Christian Backfrieder
 * 
 */
public class Osm2poLogWrapper implements LogWriter {
	int loglevel;

	@Override
	public LogWriter setLogLevel(int i) {
		this.loglevel = i;
		return this;
	}

	@Override
	public int getLogLevel() {
		return loglevel;
	}

	@Override
	public void log(String s, int level) {
		if (level < this.loglevel) {
			if (level <= Log.LEVEL_DEBUG) {
				Logger.logDebug(s);
			} else if (level <= Log.LEVEL_WARN) {
				Logger.logWarn(s);
			} else if (level <= Log.LEVEL_INFO) {
				Logger.logInfo(s);
			} else {
				Logger.logError(s);
			}
		}
	}

	@Override
	public void close() {

	}

}

package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController.Mode;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.SelfOrganizingControlLogic;

public class SelfOrganizingRegulationConfigurationControl extends
		TrafficRegulationConfigurationControl<SelfOrganizingController, SelfOrganizingControlLogic, SelfOrganizingTrafficLightConfigurationParameters> {

	private Spinner spinnerTimeHorizon;
	private Spinner spinnerPassOverTime;
	private Spinner spinnerStartupLoss;
	private Spinner spinnerTargetCycleLength;
	private Spinner spinnerMaxCycleLength;
	private Spinner spinnerUpdateInterval;
	private Button btnUseHeuristics;
	private Combo comboMode;

	public SelfOrganizingRegulationConfigurationControl(Composite parent, int style) {
		super(parent, style);
	}

	@Override
	protected void intialize() {

		Label lblControllerHeader = new Label(container, SWT.CHECK);
		lblControllerHeader.setText("Controller Properties");
		lblControllerHeader.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		FontDescriptor boldDescriptor = FontDescriptor.createFrom(lblControllerHeader.getFont()).setStyle(SWT.BOLD);
		Font boldFont = boldDescriptor.createFont(lblControllerHeader.getDisplay());
		lblControllerHeader.setFont(boldFont);

		Label lblController = new Label(container, SWT.NONE);
		lblController.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblController.setText("Control Mode");

		comboMode = new Combo(container, SWT.READ_ONLY);
		comboMode.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		comboMode.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		for (Mode m : Mode.values()) {
			comboMode.add(m.toString());
		}

		comboMode.select(0);

		Label targetCycleLabel = new Label(container, SWT.NONE);
		targetCycleLabel.setText("Target cycle length [s]");
		spinnerTargetCycleLength = new Spinner(container, SWT.BORDER);
		spinnerTargetCycleLength.setDigits(3);
		spinnerTargetCycleLength.setMaximum(180000);
		spinnerTargetCycleLength.setMinimum(30000);
		spinnerTargetCycleLength.setPageIncrement(1000);
		spinnerTargetCycleLength.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label maxCycleLabel = new Label(container, SWT.NONE);
		maxCycleLabel.setText("Max. cycle length [s]");
		spinnerMaxCycleLength = new Spinner(container, SWT.BORDER);
		spinnerMaxCycleLength.setDigits(3);
		spinnerMaxCycleLength.setMaximum(180000);
		spinnerMaxCycleLength.setMinimum(30000);
		spinnerMaxCycleLength.setPageIncrement(1000);
		spinnerMaxCycleLength.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label updateIntervalLabel = new Label(container, SWT.NONE);
		updateIntervalLabel.setText("Update interval [s]");
		updateIntervalLabel.setToolTipText("Interval in which the signal controller is updated");
		spinnerUpdateInterval = new Spinner(container, SWT.BORDER);
		spinnerUpdateInterval.setDigits(3);
		spinnerUpdateInterval.setMaximum(60000);
		spinnerUpdateInterval.setMinimum(2500);
		spinnerUpdateInterval.setPageIncrement(1000);
		spinnerUpdateInterval.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		btnUseHeuristics = new Button(container, SWT.CHECK);
		btnUseHeuristics.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		btnUseHeuristics.setText("Use heuristics");
		btnUseHeuristics.setToolTipText("Determines if signal release periods are estimated using a heuristic approach or not");
		btnUseHeuristics.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label lblTrafficLightHeader = new Label(container, SWT.CHECK);
		lblTrafficLightHeader.setText("Traffic Light Properties");
		lblTrafficLightHeader.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		boldDescriptor = FontDescriptor.createFrom(lblTrafficLightHeader.getFont()).setStyle(SWT.BOLD);
		boldFont = boldDescriptor.createFont(lblTrafficLightHeader.getDisplay());
		lblTrafficLightHeader.setFont(boldFont);

		Label timeHorizonLabel = new Label(container, SWT.NONE);
		timeHorizonLabel.setText("Time horizon [s]");
		timeHorizonLabel.setToolTipText("Time offset at which loop detectors for queue monitoring are located upstream the intersection");
		spinnerTimeHorizon = new Spinner(container, SWT.BORDER);
		spinnerTimeHorizon.setDigits(3);
		spinnerTimeHorizon.setMaximum(60000);
		spinnerTimeHorizon.setMinimum(3000);
		spinnerTimeHorizon.setPageIncrement(1000);
		spinnerTimeHorizon.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label passOverTimeLabel = new Label(container, SWT.NONE);
		passOverTimeLabel.setText("Pass over time [s]");
		spinnerPassOverTime = new Spinner(container, SWT.BORDER);
		spinnerPassOverTime.setDigits(3);
		spinnerPassOverTime.setMaximum(10000);
		spinnerPassOverTime.setMinimum(1000);
		spinnerPassOverTime.setPageIncrement(1000);
		spinnerPassOverTime.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label startUpLossTimeLabel = new Label(container, SWT.NONE);
		startUpLossTimeLabel.setText("Startup loss time [s]");
		spinnerStartupLoss = new Spinner(container, SWT.BORDER);
		spinnerStartupLoss.setDigits(3);
		spinnerStartupLoss.setMaximum(120000);
		spinnerStartupLoss.setMinimum(1000);
		spinnerStartupLoss.setPageIncrement(1000);
		spinnerStartupLoss.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});
	}

	@Override
	protected void updateControls() {
		if (selectedControlLogic != null) {
			spinnerTimeHorizon.setSelection((int) selectedControlLogic.getTimeHorizon());
			spinnerPassOverTime.setSelection((int) selectedControlLogic.getPassOverTime());
			spinnerStartupLoss.setSelection((int) selectedControlLogic.getStartUpLossTime());
			spinnerTimeHorizon.setEnabled(true);
			spinnerPassOverTime.setEnabled(true);
			spinnerStartupLoss.setEnabled(true);
		} else {
			spinnerTimeHorizon.setSelection(0);
			spinnerPassOverTime.setSelection(0);
			spinnerStartupLoss.setSelection(0);
			spinnerTimeHorizon.setEnabled(false);
			spinnerPassOverTime.setEnabled(false);
			spinnerStartupLoss.setEnabled(false);
		}

		if (selectedController != null) {
			spinnerTargetCycleLength.setSelection((int) selectedController.getTargetCycleLength());
			spinnerMaxCycleLength.setSelection((int) selectedController.getMaxCycleLength());
			spinnerUpdateInterval.setSelection((int) selectedController.getUpdateInterval());
			btnUseHeuristics.setSelection(selectedController.getUseHeuristics());
			comboMode.setText(selectedController.getMode().toString());
			spinnerTargetCycleLength.setEnabled(true);
			spinnerMaxCycleLength.setEnabled(true);
			spinnerUpdateInterval.setEnabled(true);
			btnUseHeuristics.setEnabled(true);
			comboMode.setEnabled(true);
		} else {
			comboMode.select(0);
			spinnerTargetCycleLength.setSelection(0);
			spinnerMaxCycleLength.setSelection(0);
			spinnerUpdateInterval.setSelection(0);
			btnUseHeuristics.setSelection(false);
			spinnerTargetCycleLength.setEnabled(false);
			spinnerMaxCycleLength.setEnabled(false);
			spinnerUpdateInterval.setEnabled(false);
			btnUseHeuristics.setEnabled(false);
			comboMode.setEnabled(false);
		}
	}

	private void updateProperties() {
		if (selectedControlLogic != null) {
			selectedControlLogic.setTimeHorizon(spinnerTimeHorizon.getSelection());
			selectedControlLogic.setPassOverTime(spinnerPassOverTime.getSelection());
			selectedControlLogic.setStartUpLossTime(spinnerStartupLoss.getSelection());
		}

		if (selectedController != null) {
			selectedController.setTargetCycleLength(spinnerTargetCycleLength.getSelection());
			selectedController.setMaxCycleLength(spinnerMaxCycleLength.getSelection());
			selectedController.setUpdateInterval(spinnerUpdateInterval.getSelection());
			selectedController.setUseHeuristics(btnUseHeuristics.getSelection());
			selectedController.setMode(Mode.getModeByLabel(comboMode.getText()));
		}
	}

	@Override
	public void activate(boolean activate) {
		btnUseHeuristics.setEnabled(activate);
		comboMode.setEnabled(activate);
		spinnerMaxCycleLength.setEnabled(activate);
		spinnerPassOverTime.setEnabled(activate);
		spinnerStartupLoss.setEnabled(activate);
		spinnerTargetCycleLength.setEnabled(activate);
		spinnerTimeHorizon.setEnabled(activate);
		spinnerUpdateInterval.setEnabled(activate);
	}

	@Override
	public SelfOrganizingTrafficLightConfigurationParameters getConfigurationParameters() {
		SelfOrganizingTrafficLightConfigurationParameters params = new SelfOrganizingTrafficLightConfigurationParameters();
		params.timeHorizon = spinnerTimeHorizon.getSelection();
		params.passOverTime = spinnerPassOverTime.getSelection();
		params.startUpLossTime = spinnerStartupLoss.getSelection();
		params.targetCycle = spinnerTargetCycleLength.getSelection();
		params.maxCycle = spinnerMaxCycleLength.getSelection();
		params.updateInterval = spinnerUpdateInterval.getSelection();
		params.useHeuristics = btnUseHeuristics.getSelection();
		params.mode = Mode.getModeByLabel(comboMode.getText());
		return params;
	}
}

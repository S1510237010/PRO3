package at.fhhagenberg.mc.traffsim.ui;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;

public class DetailsOverlay {
	public static final float DEFAULT_ALPHA = 0.5f;

	/**
	 * Alpha value of trasnparency
	 */
	float alpha;
	/** Position in real world */
	private Vector pos;
	/** The text to draw, separated by \n */
	String text;

	public DetailsOverlay(Vector pos, String text) {
		super();
		this.pos = pos;
		this.text = text;
		this.alpha = DEFAULT_ALPHA;
	}

	public DetailsOverlay(Vector pos, String text, float alpha) {
		super();
		this.pos = pos;
		this.text = text;
		this.alpha = alpha;
	}

	public float getAlpha() {
		return alpha;
	}

	public void setAlpha(float alpha) {
		this.alpha = alpha;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Vector getPos() {
		return pos;
	}

	public void setPos(Vector pos) {
		this.pos = pos;
	}

}

package at.fhhagenberg.mc.traffsim.ui.osm;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Cursor;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jdesktop.swingx.JXMapKit;
import org.jdesktop.swingx.JXMapViewer;
import org.jdesktop.swingx.OSMTileFactoryInfo;
import org.jdesktop.swingx.input.CenterMapListener;
import org.jdesktop.swingx.input.PanKeyListener;
import org.jdesktop.swingx.input.PanMouseInputListener;
import org.jdesktop.swingx.input.ZoomMouseWheelListenerCursor;
import org.jdesktop.swingx.mapviewer.DefaultTileFactory;
import org.jdesktop.swingx.mapviewer.GeoPosition;
import org.jdesktop.swingx.mapviewer.LocalResponseCache;
import org.jdesktop.swingx.mapviewer.TileFactoryInfo;

/**
 * This class provides the functionality to define a rectangular bounding box by
 * dragging the mouse pointer on an OSM map view. This bounding box defines the
 * boundaries for the upcomming web import of OSM data.
 * 
 * @author Manuel Lindorfer, 2013
 * 
 */
public class OSMMapViewer extends PanMouseInputListener {

	public interface IMapViewerListener {
		public void mapViewClosed(double[] result);
	}

	/**
	 * Point objects used for defining start and end point of the bounding box
	 **/
	private Point prev;
	private Point origin;

	/** The actual bounding box **/
	private Rectangle rect = null;

	/** The bounding box coordinates (min. lat/lng, max. lat/lng) **/
	private double[] bounds = null;

	/** A specific overlay painter used to draw the rectangular bounding box **/
	private SelectionRectanglePainter<JXMapViewer> rectOverlay;

	/** The map kit required for displaying the OSM map **/
	private JXMapKit jXMapKit;

	/** A frame used for visualization **/
	private JFrame frame;
	private IMapViewerListener listener;

	/**
	 * Constructor
	 * 
	 * Creates a new OSM map viewer with the given parameters.
	 * 
	 * @param listener
	 * 
	 * @param mapCenter
	 *            the pre-defined map center
	 * @param bounds
	 *            the pre-defined bounding box coordinates
	 */
	public OSMMapViewer(IMapViewerListener listener, GeoPosition mapCenter, double[] bounds) {
		super(null);

		this.bounds = bounds;
		this.listener = listener;
		init(mapCenter);
	}

	/**
	 * Initializes the map kit with the given center position
	 * 
	 * @param mapCenter
	 *            the map center
	 */
	private void init(GeoPosition mapCenter) {

		// Create a TileFactoryInfo for OpenStreetMap
		TileFactoryInfo info = new OSMTileFactoryInfo();
		DefaultTileFactory tileFactory = new DefaultTileFactory(info);
		tileFactory.setThreadPoolSize(8);

		// Setup local file cache
		File cacheDir = new File(System.getProperty("user.home") + File.separator + ".jxmapviewer2");
		LocalResponseCache.installResponseCache(info.getBaseURL(), cacheDir, false);

		jXMapKit = new JXMapKit();
		jXMapKit.setDefaultProvider(org.jdesktop.swingx.JXMapKit.DefaultProviders.OpenStreetMaps);
		jXMapKit.setTileFactory(tileFactory);
		jXMapKit.setAddressLocation(mapCenter);
		jXMapKit.setAddressLocationShown(false);
		jXMapKit.setDataProviderCreditShown(false);
		jXMapKit.setMiniMapVisible(true);
		jXMapKit.setZoomSliderVisible(true);
		jXMapKit.setZoomButtonsVisible(true);
		jXMapKit.setZoom(8);

		// Add interactions
		jXMapKit.addMouseListener(this);
		jXMapKit.addMouseMotionListener(this);

		jXMapKit.addMouseListener(new CenterMapListener(jXMapKit.getMainMap()));
		jXMapKit.addMouseWheelListener(new ZoomMouseWheelListenerCursor(jXMapKit.getMainMap()));

		jXMapKit.addKeyListener(new PanKeyListener(jXMapKit.getMainMap()));
		rectOverlay = new SelectionRectanglePainter<JXMapViewer>();
		rectOverlay.setBoundaries(bounds);

		jXMapKit.getMainMap().setOverlayPainter(rectOverlay);

		frame = new JFrame("OSM Import");
		frame.getContentPane().setLayout(new BorderLayout());
		frame.getContentPane().add(jXMapKit);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1, 6));
		Button buttonOk = new Button();
		buttonOk.setLabel("Ok");

		buttonOk.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				listener.mapViewClosed(getSelection());
				frame.setVisible(false);
				frame.dispose();
			}
		});

		buttonPanel.add(new JPanel());
		buttonPanel.add(new JPanel());
		buttonPanel.add(buttonOk);
		buttonPanel.add(new JPanel());
		buttonPanel.add(new JPanel());

		frame.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.setVisible(true);
		jXMapKit.getMainMap().repaint();
	}

	@Override
	public void mouseMoved(MouseEvent evt) {
		prev = evt.getPoint();
	}

	private double[] getSelection() {
		if (bounds != null) {
			return bounds;
		}
		if (rect != null) {

			final GeoPosition pos = jXMapKit.getMainMap().convertPointToGeoPosition(new Point2D.Double(rect.x, rect.y));
			final GeoPosition pos2 = jXMapKit.getMainMap()
					.convertPointToGeoPosition(new Point2D.Double(rect.x + rect.width, rect.y + rect.height));
			bounds = new double[4];
			bounds[0] = (pos2.getLatitude());
			bounds[1] = (pos.getLongitude());
			bounds[2] = (pos.getLatitude());
			bounds[3] = (pos2.getLongitude());
		}
		return bounds;
	}

	@Override
	public void mousePressed(MouseEvent evt) {
		prev = evt.getPoint();

		if (rect != null && SwingUtilities.isLeftMouseButton(evt)) {
			rect = null;
			rectOverlay.setSelectionRectangle(rect, null);
		}
	}

	@Override
	public void mouseDragged(MouseEvent evt) {
		if (SwingUtilities.isLeftMouseButton(evt)) {
			Point p = evt.getPoint();

			if (rect == null) {
				origin = prev;
				rect = new Rectangle(prev);
			} else {
				rect = new Rectangle(origin);
				rect.add(p);
				rectOverlay.setSelectionRectangle(rect, jXMapKit.getMainMap());
				jXMapKit.getMainMap().repaint();
			}
		} else {
			Point current = evt.getPoint();
			double x = jXMapKit.getMainMap().getCenter().getX() - (current.x - prev.x);
			double y = jXMapKit.getMainMap().getCenter().getY() - (current.y - prev.y);

			if (!jXMapKit.getMainMap().isNegativeYAllowed()) {
				if (y < 0) {
					y = 0;
				}
			}

			int maxHeight = (int) (jXMapKit.getMainMap().getTileFactory().getMapSize(jXMapKit.getMainMap().getZoom())
					.getHeight() * jXMapKit.getMainMap().getTileFactory().getTileSize(jXMapKit.getMainMap().getZoom()));
			if (y > maxHeight) {
				y = maxHeight;
			}

			prev = current;
			jXMapKit.getMainMap().setCenter(new Point2D.Double(x, y));
			jXMapKit.getMainMap().repaint();
			jXMapKit.getMainMap().setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
		}
	}

	@Override
	public void mouseReleased(MouseEvent evt) {
		prev = null;
		bounds = null;
		jXMapKit.getMainMap().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				jXMapKit.getMainMap().requestFocusInWindow();
			}
		});
	}
}

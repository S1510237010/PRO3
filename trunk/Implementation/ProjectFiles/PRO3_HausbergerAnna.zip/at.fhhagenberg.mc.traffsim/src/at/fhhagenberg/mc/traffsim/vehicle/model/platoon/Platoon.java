package at.fhhagenberg.mc.traffsim.vehicle.model.platoon;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane.Type;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.TrafficUtil;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.CACCLaneChange;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeDecision;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.PlatoonLongitudinalControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonData;

/***
 *
 * Main class for platooning which handles joining and leaving of a platoon and switch the vehicle models
 *
 * @author Sebastian Huber
 *
 */
public class Platoon implements IVehicleListener {

	public enum State {
		IDLE, JOIN_REQUEST, JOIN, LEAVE, DISSOLVE, LANE_CHANGE
	};

	public enum ManeuverType {
		FRONT, TAIL, SIDE
	}

	public enum ManeuverResult {
		SUCCESS, SUCCESS_WITH_POSITION_CHANGE, PLATOON_BUSY, ALREADY_JOINED, PLATOON_FULL, IN_OTHER_PLATOON, ROAD_TOO_SMALL, WRONG_LANE_TYPE, NO_LEADER_CAPABILITY, NOT_IN_RANGE, TOO_SLOW_FOR_PLATOON, NOT_CAPABLE_FOR_PLATOONS, NOT_IN_PLATOON, NO_MANEUVER, NOT_ALLOWED, FAILURE
	};

	private static long NEXT_ID = 0;

	/**
	 * Id of platoon
	 */
	private long id;

	/**
	 * Vehicles are currently in the platoon
	 */
	private List<Vehicle> vehicles;

	/**
	 * Data of xml configuration
	 */
	private PlatoonData data;

	/**
	 * State of platoon
	 */
	private State state;

	/**
	 * For join maneuver future position inside platoon For leave maneuver current position inside platoon
	 */
	private int maneuverVehicleIndex;

	/**
	 * Type of current performed maneuver, if none null/last
	 */
	private ManeuverType maneuverType;

	/**
	 * Type of current performed maneuver, if none null/last
	 */
	private Date maneuverStartTime;

	/**
	 * index of vehicle (inclusive) until the platoon has to be dissolved
	 */
	private int dissolveVehicleIndex;

	/**
	 * Time since the platoon does not move (for dissolve timeou)
	 */
	private Date platoonStandStillStartTime;

	/**
	 * Flag if maneuver is already aborted
	 */
	private boolean maneuverAbortable = false;

	/**
	 * Lane change decision for platoon in state LANE_CHANGE
	 */
	private LaneChangeDecision laneChangeDecision;

	/**
	 * CTor
	 *
	 * @param id
	 *            id of platoon
	 * @param data
	 *            configuration data for platoon
	 */
	public Platoon(long id, PlatoonData data) {
		super();
		this.id = id;
		this.data = data;
		this.vehicles = new ArrayList<>();
		this.state = State.IDLE;
		this.maneuverVehicleIndex = -1;
		this.maneuverType = null;
		this.maneuverStartTime = null;
		this.laneChangeDecision = null;
	}

	/**
	 * CTor
	 *
	 * @param data
	 *            configuration data for platoon
	 */
	public Platoon(PlatoonData data) {
		this(NEXT_ID++, data);
	}

	/***
	 * Unique id of platoon
	 *
	 * @return id
	 */
	public long getId() {
		return id;
	}

	/**
	 * State of the platoon
	 *
	 * @return state
	 */
	public State getPlatoonState() {
		return state;
	}

	public State getVehicleState(Vehicle v) {
		if (vehicles.indexOf(v) == maneuverVehicleIndex) {
			return state;
		}
		if (state == State.LANE_CHANGE) {
			return state;
		}
		return State.IDLE;
	}

	/***
	 * List of all vehicles are currently in the platoon (ordered, first is leader)
	 *
	 * @return list
	 */
	public List<Vehicle> getAllVehicles() {
		return vehicles;
	}

	/**
	 * Size of the platoon
	 *
	 * @return size
	 */
	public int getSize() {
		return vehicles.size();
	}

	/**
	 * Max size of the platoon
	 *
	 * @return max size
	 */
	public int getMaxSize() {
		return data.getMaxVehiclesPerPlatoon();
	}

	/***
	 * Leader of platoon ignoring maneuver vehicles
	 *
	 * @return leader
	 */
	public Vehicle getLeader() {
		switch (state) {
		case IDLE:
		case LANE_CHANGE:
			return (vehicles.size() > 0) ? vehicles.get(0) : null;
		case JOIN_REQUEST:
		case JOIN:
		case LEAVE:
		case DISSOLVE:
			switch (maneuverType) {
			case FRONT:
				return (vehicles.size() > 1) ? vehicles.get(1) : null;
			case TAIL:
			case SIDE:
				return (vehicles.size() > 0) ? vehicles.get(0) : null;
			}
		}
		// should not happen
		return (vehicles.size() > 0) ? vehicles.get(0) : null;
	}

	/***
	 * Tail of platoon ignoring maneuver vehicles
	 *
	 * @return tail
	 */
	public Vehicle getTail() {
		switch (state) {
		case IDLE:
		case LANE_CHANGE:
			return (vehicles.size() > 0) ? vehicles.get(vehicles.size() - 1) : null;
		case JOIN_REQUEST:
		case JOIN:
		case LEAVE:
		case DISSOLVE:
			switch (maneuverType) {
			case FRONT:
			case SIDE:
				return (vehicles.size() > 0) ? vehicles.get(vehicles.size() - 1) : null;
			case TAIL:
				return (vehicles.size() > 1) ? vehicles.get(vehicles.size() - 2) : null;
			}
		}
		// should not happen
		return (vehicles.size() > 0) ? vehicles.get(vehicles.size() - 1) : null;
	}

	/***
	 * Preceding vehicle of me ignoring join request maneuver vehicles, null if me is leader
	 *
	 * @param me
	 *            Vehicle to get preceding
	 * @return Preceding vehicle
	 */
	public Vehicle getPreceding(Vehicle me) {
		// Not in platoon
		if (!contains(me)) {
			return null;
		}

		int indexOfPreceding = getIndex(me) - 1;

		switch (state) {
		case JOIN_REQUEST:
			if (indexOfPreceding == maneuverVehicleIndex) {
				indexOfPreceding = indexOfPreceding - 1;
			}
			return (indexOfPreceding >= 0) ? vehicles.get(indexOfPreceding) : null;
		case IDLE:
		case LANE_CHANGE:
		case JOIN:
		case LEAVE:
		case DISSOLVE:
			return (indexOfPreceding >= 0) ? vehicles.get(indexOfPreceding) : null;

		}
		// should not happen
		return (indexOfPreceding >= 0) ? vehicles.get(indexOfPreceding) : null;
	}

	/***
	 * Following vehicle of me ignoring join request maneuver vehicles, null if me is tail
	 *
	 * @param me
	 *            Vehicle to get following
	 * @return Following vehicle
	 */
	public Vehicle getFollowing(Vehicle me) {

		// Not in platoon
		if (!contains(me)) {
			return null;
		}

		int indexOfFollowing = getIndex(me) + 1;

		switch (state) {
		case JOIN_REQUEST:
			if (indexOfFollowing == maneuverVehicleIndex) {
				indexOfFollowing = indexOfFollowing + 1;
			}
			return (indexOfFollowing < vehicles.size()) ? vehicles.get(indexOfFollowing) : null;
		case IDLE:
		case LANE_CHANGE:
		case JOIN:
		case LEAVE:
		case DISSOLVE:
			return (indexOfFollowing < vehicles.size()) ? vehicles.get(indexOfFollowing) : null;

		}
		// should not happen
		return (indexOfFollowing < vehicles.size()) ? vehicles.get(indexOfFollowing) : null;
	}

	/***
	 * Index/Position of vehicle in platoon (start with zero)
	 *
	 * @param v
	 *            Vehicle to get index
	 * @return Index
	 */
	public int getIndex(Vehicle v) {
		return vehicles.indexOf(v);
	}

	/**
	 * Check if vehicles is in platoon
	 *
	 * @param v
	 *            vehicle to check
	 * @return true if vehicle is in platoon, otherwise false
	 */
	public boolean contains(Vehicle v) {
		return vehicles.contains(v);
	}

	/**
	 * If platoon is in any maneuver state return maneuver vehicle else null
	 *
	 * @return maneuver vehicle
	 */
	public Vehicle getManeuverVehicle() {
		switch (state) {
		case IDLE:
		case LANE_CHANGE:
			return null;
		case JOIN_REQUEST:
		case JOIN:
		case LEAVE:
		case DISSOLVE:
			return vehicles.get(maneuverVehicleIndex);
		}
		return null;
	}

	/**
	 * Get type of current join/leave maneuver
	 *
	 * @return type of maneuver
	 */
	public ManeuverType getManeuverType() {
		return maneuverType;
	}

	/**
	 * Setter for maneuver type due to some special cases to change type
	 *
	 * @param maneuverType
	 *            new type
	 */
	public void setManeuverType(ManeuverType maneuverType) {
		this.maneuverType = maneuverType;
	}

	/**
	 * Getter for lane change decision of LANE_CHANGE state
	 *
	 * @return decision
	 */
	public LaneChangeDecision getLaneChangeDecision() {
		return laneChangeDecision;
	}

	/**
	 * Desired speed for this platoon
	 *
	 * @return speed in m/s
	 */
	public double getDesiredSpeed() {
		return data.getDesiredSpeed();
	}

	/**
	 * Desired gap of this platoon
	 *
	 * @param me
	 *            current vehicle
	 *
	 * @return desired gap
	 */
	public double getDesiredGap(Vehicle me) {
		// maneuver gap for side join/leave
		if ((state == State.JOIN || state == State.LEAVE) && maneuverType == ManeuverType.SIDE) {
			int indexOfMe = getIndex(me);
			// maneuver vehicle or follower of maneuver vehicle
			if (indexOfMe == maneuverVehicleIndex || indexOfMe - 1 == maneuverVehicleIndex) {
				boolean maneuverVehicleOnPlatoonLane = getManeuverVehicle().getLaneIndex() == getLeader().getLaneIndex();
				boolean maneuverVehicleInProcessOfLaneChange = getManeuverVehicle().isInProcessOfLaneChange();

				if (state == State.JOIN && !maneuverVehicleOnPlatoonLane && !maneuverVehicleInProcessOfLaneChange) {
					// if join state and maneuver vehicle not on platoon lane -> maneuver gap
					return data.getManeuverGap();
				} else if ((maneuverVehicleOnPlatoonLane || maneuverVehicleInProcessOfLaneChange) && state == State.LEAVE) {
					// if leave state maneuver vehicle on platoon lane -> maneuver gap
					return data.getManeuverGap();
				} else {
					return data.getDesiredGap();
				}
			}
		}
		return data.getDesiredGap();
	}

	/**
	 * Get minimum lane count for platoon coordination
	 *
	 * @return minimum lane count
	 */
	public int getMinimumLaneCount() {
		return data.getMinimumLaneCount();
	}

	/**
	 * Get maximum distance to platoo for join maneuver
	 *
	 * @return distance
	 */
	public double getMaxDistanceForJoin() {
		return data.getMaxDistanceForJoin();
	}

	/**
	 * Maximum target speed difference for joining vehicles
	 *
	 * @return speed difference
	 */
	public double getMaxTargetSpeedDifferenceForJoin() {
		return data.getMaxTargetSpeedDifferenceForJoin();
	}

	/**
	 * Get timeout for join maneuver
	 *
	 * @return timeout in s
	 */
	public long getManeuverTimeout() {
		return data.getManeuverTimeout();
	}

	/**
	 * Get start time of current maneuver else -1
	 *
	 * @return start time of maneuver in ms
	 */
	public long getManeuverStartTime() {
		return maneuverStartTime == null ? -1 : maneuverStartTime.getTime();
	}

	/**
	 * Get timeout for resolving a platoon on zero speed
	 *
	 * @return timeout in s
	 */
	public long getDissolveTimeout() {
		return data.getResolveTimeout();
	}

	/**
	 * Get maneuver speed threshold factor
	 *
	 * @return factor
	 */
	public double getManeuverSpeedTOffset() {
		return data.getManeuverSpeedTOffset();
	}

	/**
	 * Get maneuver distance threshold offset
	 *
	 * @return offset
	 */
	public double getManeuverHumanDistanceThresholdOffset() {
		return data.getManeuverHumanDistanceThresholdOffset();
	}

	/**
	 * Get desired gap threshold offset
	 *
	 * @return offset
	 */
	public double getManeuverPlatoonDistanceThresholdOffset() {
		return data.getManeuverPlatoonDistanceThresholdOffset();
	}

	/***
	 * Let a vehicle join the platoon, vehicle has to be in simulation.
	 *
	 * @param v
	 *            Vehicle to join
	 * @param position
	 *            Position to apply the join
	 * @param simulationTime
	 *            current simulation time
	 * @param force
	 *            Forces the maneuver without any procedure
	 * @return join succeed true, else false
	 */
	public ManeuverResult join(Vehicle v, int position, Date simulationTime, boolean force) {
		if (v == null) {
			return ManeuverResult.FAILURE;
		}

		if (state != State.IDLE) {
			return ManeuverResult.PLATOON_BUSY;
		}

		if (!(v.getLongitudinalControl() instanceof PlatoonLongitudinalControl) || !(v.getLaneChangeModel() instanceof CACCLaneChange)) {
			return ManeuverResult.NOT_CAPABLE_FOR_PLATOONS;
		}

		if (getLeader() != null && v.getLongitudinalControl().getTargetSpeed() - getMaxTargetSpeedDifferenceForJoin() < getLeader()
				.getLongitudinalControl().getTargetSpeed()) {
			return ManeuverResult.TOO_SLOW_FOR_PLATOON;
		}

		if (vehicles.contains(v)) {
			return ManeuverResult.ALREADY_JOINED;
		}

		if (v.isVehiclePlatoonControlled()) {
			return ManeuverResult.IN_OTHER_PLATOON;
		}

		if (getSize() == getMaxSize() || vehicles.contains(v)) {
			return ManeuverResult.PLATOON_FULL;
		}

		if (getSize() == 0 && TrafficUtil.getTrafficLaneCountForVehicle(v) < getMinimumLaneCount()) {
			return ManeuverResult.ROAD_TOO_SMALL;
		}

		if (v.getLaneSegment().getLaneType() != Type.TRAFFIC) {
			return ManeuverResult.WRONG_LANE_TYPE;
		}

		// First vehicle joins platoon
		int index = -1;
		int offset = 0;
		if (getSize() == 0) {
			index = 0;
		} else {
			Vehicle leader = getLeader();
			Vehicle tail = getTail();

			VehicleWithDistance distanceToLeader = SpatialUtil.getDirectedDistanceBetween(leader, v);
			VehicleWithDistance distanceToTail = SpatialUtil.getDirectedDistanceBetween(v, tail);

			// check if distance to leader and tail are bigger than max join distance
			if (!isInRangeForJoin(distanceToLeader, distanceToTail)) {
				return ManeuverResult.NOT_IN_RANGE;
			}

			// position from parameter
			if (position >= 0 && position <= vehicles.size()) {
				index = position;
			} else {
				// calculate optimal position
				// Front join
				if (distanceToLeader != null && distanceToLeader.getDistance() > 0) {
					index = 0;
					// Tail join
				} else if (distanceToTail != null && distanceToTail.getDistance() > 0) {
					index = vehicles.size();
					// Side join
				} else {
					Vehicle preceding = null;
					for (int i = vehicles.size() - 1; i >= 0; --i) {
						Vehicle pv = vehicles.get(i);
						VehicleWithDistance distance = SpatialUtil.getDistanceBetween(v, pv);
						if (distance != null && (Math.abs(distance.getDistance()) < v.getLength() || distance.getDistance() > 0)) {
							preceding = pv;
							break;
						}
					}
					if (preceding == null) {
						index = 0;
					} else {
						index = vehicles.indexOf(preceding) + 1;
					}
				}
			}

			// ignore index adoption on force join
			if (!force) {
				// Adopt index based on speed and distance
				offset = calculateIndexOffsetForJoin(v, index);
			}
			index = index + offset;
		}

		// Apply maneuver type
		ManeuverType type = null;
		if (index == 0) {
			type = ManeuverType.FRONT;
		} else if (index == vehicles.size()) {
			type = ManeuverType.TAIL;
		} else {
			type = ManeuverType.SIDE;
		}

		if (type == ManeuverType.FRONT && !v.hasLeaderCapability()) {
			return ManeuverResult.NO_LEADER_CAPABILITY;
		}

		if (index >= 0 && index <= vehicles.size()) {
			vehicles.add(index, v);
		} else {
			return ManeuverResult.FAILURE;
		}

		// on force proceed with IDLE state
		if (!force) {
			state = State.JOIN_REQUEST;
			maneuverStartTime = simulationTime;
			maneuverVehicleIndex = index;
			maneuverType = type;
		}

		// add vehicle listener for checking vehicles in the platoon leaving the simulation
		v.addVehicleListener(this);

		// set platoon on control models
		((PlatoonLongitudinalControl) v.getLongitudinalControl()).setPlatoon(this);
		((CACCLaneChange) v.getLaneChangeModel()).setPlatoon(this);

		maneuverAbortable = true;
		if (offset != 0) {
			return ManeuverResult.SUCCESS_WITH_POSITION_CHANGE;
		}
		return ManeuverResult.SUCCESS;
	}

	/***
	 * Method for @PlatoonManager to initiate the leave of a platoon for a vehicle
	 *
	 * @param v
	 *            Vehicle which shall leave the platoon
	 * @param force
	 *            Forces the maneuver without any procedure
	 * @return result of leave maneuver
	 */
	public ManeuverResult leave(Vehicle v, boolean force) {
		if (v == null) {
			return ManeuverResult.FAILURE;
		}

		if (state != State.IDLE) {
			return ManeuverResult.PLATOON_BUSY;
		}
		int index = -1;
		ManeuverType type = null;

		if (vehicles.contains(v)) {
			index = getIndex(v);
			// leader leaves
			if (v.equals(getLeader())) {

				Vehicle follower = getFollowing(v);
				if (follower != null && !follower.hasLeaderCapability()) {
					return ManeuverResult.NO_LEADER_CAPABILITY;
				}
				type = ManeuverType.FRONT;
				// tail leaves
			} else if (v.equals(getTail())) {
				type = ManeuverType.TAIL;
				// middle vehicle leaves
			} else {
				type = ManeuverType.SIDE;
			}
			maneuverVehicleIndex = index;
			maneuverType = type;
			state = State.LEAVE;

			if (force) {
				removeVehicleFromPlatoon(vehicles.get(maneuverVehicleIndex));
			}
			maneuverAbortable = true;
			return ManeuverResult.SUCCESS;
		}
		return ManeuverResult.NOT_IN_PLATOON;
	}

	/**
	 * Method for @PlatoonManager to dissolve a platoon
	 *
	 * @param untilVehicle
	 *            dissolve until vehicle (inclusive)
	 * @param force
	 *            Forces the maneuver without any procedure
	 * @return result for action
	 */
	public ManeuverResult dissolve(Vehicle untilVehicle, boolean force) {
		if (state != State.IDLE) {
			return ManeuverResult.PLATOON_BUSY;
		}
		int index = vehicles.indexOf(untilVehicle);
		if (index < 0 || index >= getSize()) {
			return ManeuverResult.NOT_IN_PLATOON;
		}
		maneuverAbortable = true;
		if (force) {
			for (int i = getSize() - 1; i >= index; i--) {
				removeVehicleFromPlatoon(vehicles.get(i));
			}
			return ManeuverResult.SUCCESS;
		} else {
			dissolveVehicleIndex = index;
			dissolveNext();
			return ManeuverResult.SUCCESS;
		}
	}

	public ManeuverResult abort() {
		if (!maneuverAbortable) {
			return ManeuverResult.NOT_ALLOWED;
		}
		switch (state) {
		case IDLE:
			return ManeuverResult.NO_MANEUVER;
		case LANE_CHANGE:
			return ManeuverResult.NOT_ALLOWED;
		case JOIN_REQUEST:
			removeVehicleFromPlatoon(getManeuverVehicle());
			maneuverAbortable = false;
			return ManeuverResult.SUCCESS;
		case JOIN:
			state = State.LEAVE;
			maneuverAbortable = false;
			return ManeuverResult.SUCCESS;
		case LEAVE:
			state = State.JOIN;
			maneuverAbortable = false;
			return ManeuverResult.SUCCESS;
		case DISSOLVE:
			state = State.JOIN;
			dissolveVehicleIndex = -1;
			maneuverAbortable = false;
			return ManeuverResult.SUCCESS;
		}
		return ManeuverResult.FAILURE;
	}

	/**
	 * Check for a defined timeout for maneuvers IDLE -> do nothing JOIN_REQUEST -> remove vehicle on timeout JOIN -> leave on timeout based
	 * on progress LEAVE -> join on timeout based on progress
	 *
	 * @param simulationTime
	 *            current time in simulation
	 */
	public void checkTimeouts(Date simulationTime) {
		// check state timeouts
		switch (state) {
		case IDLE:
			// Nothing to do
			break;
		case LANE_CHANGE:
			// Nothing to do
			break;
		case JOIN_REQUEST:
			double dt = (simulationTime.getTime() - maneuverStartTime.getTime()) / 1000.0; // seconds
			if (getManeuverTimeout() < dt) {
				Logger.logInfo("Platoon " + id + ": Reached timeout for state " + state + " of vehicle " + getManeuverVehicle().getUniqueId());
				removeVehicleFromPlatoon(getManeuverVehicle());
			}
			break;
		case JOIN:
			// Nothing to do
			break;
		case LEAVE:
			// Nothing to do
			break;
		case DISSOLVE:
			// Nothing to do
			break;
		}

		// check dissolve timeout
		Vehicle leader = getLeader();
		if (leader != null && leader.getCurrentSpeed() < 0.1) {
			if (platoonStandStillStartTime == null) {
				platoonStandStillStartTime = simulationTime;
			} else {
				double dt = (simulationTime.getTime() - platoonStandStillStartTime.getTime()) / 1000.0; // seconds
				if (getDissolveTimeout() < dt) {
					Logger.logInfo("Platoon " + id + ": Dissolve timeout for standig platoon reached");
					dissolve(getLeader(), true);
				}
			}
		} else {
			platoonStandStillStartTime = null;
		}
	}

	// ##########################
	// # VEHICLE LISTENER #
	// ##########################

	@Override
	public void vehicleLeftSimulation(Vehicle v) {
		removeVehicleFromPlatoon(v);
	}

	@Override
	public void vehicleEntered(Vehicle v) {
		// join(v);
	}

	// ##########################
	// # MODEL CALLBACKS #
	// ##########################

	/**
	 * Cooperative lane change for whole platoon
	 *
	 * @param decision
	 *            lane change decision
	 * @return result for lane change
	 */
	public boolean onReadyForLaneChange(LaneChangeDecision decision) {
		if (state != State.IDLE) {
			return false;
		}
		state = State.LANE_CHANGE;
		laneChangeDecision = decision;
		return true;
	}

	private boolean stateReadyLat = false;
	private boolean stateReadyLong = false;

	/**
	 * Callback for lane change model state ready
	 *
	 * @param v
	 *            Maneuver Vehicle
	 */
	public void onVehicleStateReadyLat(Vehicle v) {
		stateReadyLat = true;
		if (isStateReady()) {
			stateReadyLat = false;
			stateReadyLong = false;
			proceedVehicleStateReady(v);
		}
	}

	/**
	 * Callback for longitudinal model state ready
	 *
	 * @param v
	 *            Maneuver Vehicle
	 */
	public void onVehicleStateReadyLong(Vehicle v) {
		stateReadyLong = true;
		if (isStateReady()) {
			if (state == State.LANE_CHANGE || isValidManeuverVehicle(v)) {
				stateReadyLat = false;
				stateReadyLong = false;
				proceedVehicleStateReady(v);
			}
		}
	}

	/**
	 * Callback for model state error
	 *
	 * @param v
	 *            Maneuver Vehicle
	 */
	public void onVehicleStateError(Vehicle v) {
		stateReadyLat = false;
		stateReadyLong = false;
		processVehicleStateError(v);
	}

	private boolean isValidManeuverVehicle(Vehicle v) {
		return maneuverVehicleIndex >= 0 && maneuverVehicleIndex < vehicles.size() && vehicles.get(maneuverVehicleIndex).equals(v);
	}

	private boolean isStateReady() {
		return stateReadyLat && stateReadyLong;
	}

	// ##########################
	// # STATE MACHINE #
	// ##########################

	/**
	 * Helper to jump to next state in state machine
	 */
	private void proceedVehicleStateReady(Vehicle v) {
		switch (state) {
		case IDLE:
			break;
		case LANE_CHANGE:
			int laneIndex = getLeader().getLaneIndex();
			boolean notInLane = false;
			for (Vehicle vehicle : vehicles) {
				if (vehicle.getLaneIndex() != laneIndex) {
					notInLane = true;
				}
			}
			if (!notInLane) {
				state = State.IDLE;
				laneChangeDecision = null;
			}
			break;
		case JOIN_REQUEST:
			state = State.JOIN;
			break;
		case JOIN:
			state = State.IDLE;
			maneuverType = null;
			maneuverVehicleIndex = -1;
			maneuverStartTime = null;
			break;
		case LEAVE:
			Vehicle follower = getFollowing(getManeuverVehicle());
			boolean joinAfterLeave = false;
			if (maneuverType == ManeuverType.SIDE && follower != null) {
				joinAfterLeave = true;
			}
			removeVehicleFromPlatoon(getManeuverVehicle());
			if (joinAfterLeave) {
				state = State.JOIN;
				maneuverType = ManeuverType.TAIL;
				maneuverVehicleIndex = vehicles.indexOf(follower);
				maneuverStartTime = null;
				maneuverAbortable = false;
			}

			break;
		case DISSOLVE:
			removeVehicleFromPlatoon(vehicles.get(maneuverVehicleIndex));
			dissolveNext();
			break;
		}
	}

	/**
	 * Helper to handle an error in current vehicle state
	 */
	private void processVehicleStateError(Vehicle v) {
		Logger.logInfo("Platoon " + id + ":Error on state " + state + "with vehicle " + v.getUniqueId());
		switch (state) {
		case IDLE:
			// TODO improve / check the state of the platoon
			dissolve(v, false);
			break;
		case LANE_CHANGE:
			// TODO improve / check the state of the platoon
			dissolve(v, false);
			break;
		case JOIN_REQUEST:
			removeVehicleFromPlatoon(vehicles.get(maneuverVehicleIndex));
			break;
		case JOIN:
			state = State.JOIN_REQUEST;
			maneuverType = null;
			maneuverVehicleIndex = -1;
			maneuverStartTime = null;
			break;
		case LEAVE:
			state = State.JOIN_REQUEST;
			break;
		case DISSOLVE:
			state = State.JOIN_REQUEST;
			dissolveVehicleIndex = -1;
			break;
		}
	}

	private boolean dissolveNext() {
		int currentIndex = getSize() - 1;
		if (currentIndex >= dissolveVehicleIndex) {
			state = State.DISSOLVE;
			maneuverType = ManeuverType.TAIL;
			maneuverVehicleIndex = currentIndex;
			return true;
		}
		state = State.IDLE;
		maneuverType = null;
		maneuverVehicleIndex = -1;
		maneuverStartTime = null;
		dissolveVehicleIndex = -1;
		return false;
	}

	/**
	 * Helper to remove vehicle from platoon (HARD REMOVE) Method also considers state and adopts it accordingly
	 *
	 * @param v
	 *            Vehicle to remove from platoon
	 */
	private void removeVehicleFromPlatoon(Vehicle v) {
		if (vehicles.contains(v)) {
			Vehicle maneuver = getManeuverVehicle();

			((PlatoonLongitudinalControl) v.getLongitudinalControl()).setPlatoon(null);
			((CACCLaneChange) v.getLaneChangeModel()).setPlatoon(null);

			v.removeVehicleListener(this);
			vehicles.remove(v);

			if (state != State.IDLE && maneuver.equals(v)) {
				state = State.IDLE;
				maneuverType = null;
				maneuverVehicleIndex = -1;
				maneuverStartTime = null;
			} else {
				maneuverVehicleIndex = getIndex(maneuver);
			}
		}
	}

	/**
	 * Check if is in range for join maneuver
	 *
	 * @param distanceToLeader
	 *            distance to leader
	 * @param distanceToTail
	 *            distance to tail
	 * @return true if is in range, false otherwise
	 */
	private boolean isInRangeForJoin(VehicleWithDistance distanceToLeader, VehicleWithDistance distanceToTail) {
		if (distanceToLeader == null && distanceToTail == null
				|| distanceToTail != null && distanceToTail.getDistance() > data.getMaxDistanceForJoin()
				|| distanceToLeader != null && distanceToLeader.getDistance() > data.getMaxDistanceForJoin()) {
			return false;
		}
		return true;
	}

	/**
	 * Helper to calculate join index offset based on speed and distance to preceding
	 *
	 * @param v
	 *            vehicle which joins the platoon
	 * @param index
	 *            preferred index for join
	 * @return index offset for new position in platoon, to ensure a safe deceleration towards the preceding vehicle
	 */
	private int calculateIndexOffsetForJoin(Vehicle v, int index) {
		int newIndex = index;
		if (index > 0) {
			Vehicle preceding = vehicles.get(index - 1);
			VehicleWithDistance distanceToPreceding = SpatialUtil.getDistanceBetween(v, preceding);
			double dv = v.getCurrentSpeed() - preceding.getCurrentSpeed();
			double desiredBrakeDistance = TrafficUtil.getIntelligentSaftyDistance(v.getCurrentSpeed(), dv, v.getLongitudinalControl().getTimeGap(),
					v.getLongitudinalControl().getMinGap(), v.getLongitudinalControl().getComfortableAcc(), v.getLongitudinalControl().getSafeDec());

			if (distanceToPreceding.getDistance() < desiredBrakeDistance) {
				VehicleWithDistance distanceToLeader = SpatialUtil.getDistanceBetween(v, vehicles.get(0));
				if (distanceToLeader.getDistance() < desiredBrakeDistance) {
					newIndex = 0;
				} else {
					int i = 1;
					while (i < index - 1) {
						VehicleWithDistance distance = SpatialUtil.getDistanceBetween(v, vehicles.get(i));
						if (distance.getDistance() < desiredBrakeDistance) {
							break;
						}
						++i;
					}
					newIndex = i - 1;
				}
			}
		}
		return newIndex - index;
	}

}

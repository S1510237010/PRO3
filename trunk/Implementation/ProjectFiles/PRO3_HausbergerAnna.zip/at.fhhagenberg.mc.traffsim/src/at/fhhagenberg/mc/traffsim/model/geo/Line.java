package at.fhhagenberg.mc.traffsim.model.geo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Class representing a line being composed of a number of {@link Vector}
 * elements.
 *
 * @author Christian Backfrieder
 */
public class Line {

	/** The list of vectors shaping the line */
	private List<Vector> points = new ArrayList<>();

	/**
	 * Creates a new {@link Line} from the given list of {@link Vector}s.
	 *
	 * @param points
	 *            a list of {@link Vector} shaping the line
	 */
	public Line(List<Vector> points) {
		this.points = points;
	}

	/**
	 * Creates a new {@link Line} connecting the provided {@link Vector}s.
	 *
	 * @param p1
	 *            the line's starting point
	 * @param p2
	 *            the line's end point
	 */
	public Line(Vector p1, Vector p2) {
		super();
		points.add(p1);
		points.add(p2);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		Line other = (Line) obj;

		if (points == null) {
			if (other.points != null) {
				return false;
			}
		} else if (!points.equals(other.points)) {
			return false;
		}

		return true;
	}

	/**
	 * Gets the line's starting point if present.
	 *
	 * @return a {@link Vector} representing the line's starting point - or null
	 */
	public Vector getP1() {
		return points.size() > 0 ? points.get(0) : null;
	}

	/**
	 * Gets the line's end point if present.
	 *
	 * @return a {@link Vector} representing the line's end point - or null
	 */
	public Vector getP2() {
		return points.size() > 1 ? points.get(1) : null;
	}

	/**
	 * Gets the line's n'th point if present.
	 *
	 * @param n
	 *            the index of the point
	 * @return a {@link Vector} representing the line's n'th point - or null
	 */
	public Vector getPn(int n) {
		return points.size() > n ? points.get(n) : null;
	}

	/**
	 * Gets the line's points as unmodifiable list.
	 *
	 * @return an unmodifiable list of {@link Vector}s defining the line's shape
	 */
	public List<Vector> getPoints() {
		return Collections.unmodifiableList(points);
	}

	/**
	 * Gets the line's points.
	 *
	 * @return a list of {@link Vector}s defining the line's shape
	 */
	public List<Vector> getPolyLine() {
		return points;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (points == null ? 0 : points.hashCode());
		return result;
	}

	/**
	 * Determines whether the {@link Line} is <i>empty</i> (number of points is
	 * zero) or not.
	 *
	 * @return true, if the line does not contain any points - false else
	 */
	public boolean isEmpty() {
		return points.isEmpty();
	}

	/**
	 * Reverses the current {@link Line}.
	 *
	 * @return a new {@link Line} with reversed direction
	 */
	public Line reverse() {
		return new Line(getP2(), getP1());
	}

	/**
	 * Sets the line's starting point.
	 *
	 * @param p1
	 *            a {@link Vector} constituting the line's starting point
	 */
	public void setP1(Vector p1) {
		points.set(0, p1);
	}

	/**
	 * Sets the line's end point.
	 *
	 * @param p2
	 *            a {@link Vector} constituting the line's end point
	 */
	public void setP2(Vector p2) {
		points.set(1, p2);
	}

	@Override
	public String toString() {
		return "[" + getP1().toString() + ", " + getP2().toString() + "]";
	}
}
package at.fhhagenberg.mc.traffsim.roadnetwork;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.util.CheckUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;

/**
 * Worker which adds vehicles to road segments as soon as they are scheduled to be added
 *
 * @author Christian Backfrieder
 *
 */
public class VehicleProcessor implements ISimulationTimeUpdatable {
	private Map<RoadSegment, ConcurrentLinkedQueue<Vehicle>> vehiclesMap = new ConcurrentHashMap<>();
	private SimulationModel model;
	private AtomicLong vehiclesToSchedule = new AtomicLong(0);

	public VehicleProcessor(SimulationModel model) {
		this.model = model;
	}

	public void scheduleVehicle(RoadSegment segment, Vehicle vehicle) {
		if (vehicle == null) {
			Logger.logWarn("Cannot schedule null vehicle");
			return;
		}
		// synchronize on segment to avoid creation of multiple queues for the same segment simultaneously
		synchronized (segment) {
			vehiclesToSchedule.incrementAndGet();
			ConcurrentLinkedQueue<Vehicle> segQueue = vehiclesMap.get(segment);
			if (segQueue != null) {
				segQueue.offer(vehicle);
			} else {
				segQueue = new ConcurrentLinkedQueue<>();
				segQueue.offer(vehicle);
				vehiclesMap.put(segment, segQueue);
			}
		}
	}

	@Override
	public void timeStep(double dt, Date simulationTime, double simulationRunTime) {
		if (vehiclesToSchedule.get() == 0) {
			return;
		}
		for (Iterator<Entry<RoadSegment, ConcurrentLinkedQueue<Vehicle>>> it = vehiclesMap.entrySet().iterator(); it.hasNext();) {
			Entry<RoadSegment, ConcurrentLinkedQueue<Vehicle>> entry = it.next();
			RoadSegment seg = entry.getKey();
			ConcurrentLinkedQueue<Vehicle> vehiclesToAdd = entry.getValue();
			for (Iterator<Vehicle> vIt = vehiclesToAdd.iterator(); vIt.hasNext();) {
				Vehicle v = vIt.next();
				for (int i = seg.getLaneCount() - 1; i >= 0; i--) {
					LaneSegment laneSeg = seg.laneSegment(i);
					VehicleWithDistance front = laneSeg.frontVehicle(v, -1);
					if (front == null || front.getDistance() > v.getLongitudinalControl().getMinGap()
							&& CheckUtil.isSafeDistance(v, front.getVehicle(), front.getDistance())
							&& v.getLongitudinalControl().calcAccSolitary(v, laneSeg) > 0) {
						if (i > 0) {
							VehicleWithDistance frontRightSeg = seg.getLaneSegments().get(i - 1).frontVehicle(v, -1);
							if (frontRightSeg != null && frontRightSeg.getVehicle().isInProcessOfLaneChange()
									&& v.getLongitudinalControl().calcAccSolitary(v, laneSeg, 1, frontRightSeg.getVehicle(),
											frontRightSeg.getVehicle().getRearPosition() - v.getFrontPosition()) < 0) {
								break;
							}
						}
						if (i < seg.getLaneCount() - 1) {
							VehicleWithDistance frontLeftSeg = seg.getLaneSegments().get(i + 1).frontVehicle(v, -1);
							if (frontLeftSeg != null && frontLeftSeg.getVehicle().isInProcessOfLaneChange()
									&& v.getLongitudinalControl().calcAccSolitary(v, laneSeg, 1, frontLeftSeg.getVehicle(),
											frontLeftSeg.getVehicle().getRearPosition() - v.getFrontPosition()) < 0) {
								break;
							}
						}
						v.resetProcessOfLaneChange();
						laneSeg.addVehicle(v);
						v.notifyListenersVehicleEntered();
						v.setEntryTime(model.getCurrentSimTime().getTime());
						model.logEvent(EventType.VEHICLE_ENTERED, v, "in RS " + laneSeg.getRoadSegment().getId() + ", routing ID "
								+ laneSeg.getRoadSegment().getRoutingId() + ", lane " + laneSeg.getLaneIndex());
						if (v.getRoute() != null) {
							v.getRoute().removeNextSegmentIdIfMatches(seg.getRoutingId());
						}
						v.setRoadSegment(seg);
						vIt.remove();
						vehiclesToSchedule.decrementAndGet();
						break;
					}
				}
			}
		}
	}

}
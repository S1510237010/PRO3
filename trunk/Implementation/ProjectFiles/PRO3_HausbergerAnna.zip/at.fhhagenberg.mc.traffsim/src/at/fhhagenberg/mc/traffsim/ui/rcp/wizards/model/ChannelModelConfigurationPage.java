package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.GeometricDistributionChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.GilbertElliotChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.UniformlyDistributedChannelDataBean;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.ChannelModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;

public class ChannelModelConfigurationPage extends ModelConfigurationPage {

	private Spinner spinnerPSuccess;
	private Spinner spinnerLambda;
	private Spinner spinnerSeed;
	private Spinner spinnerPGood;
	private Spinner spinnerPBad;
	private Spinner spinnerRoundtripMean;
	private Spinner spinnerRoundtripStdDev;

	private ChannelModels currentModel;

	protected ChannelModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		Label lblPSuccess = new Label(grpModelParameters, SWT.NONE);
		lblPSuccess.setText("Probability Success");

		spinnerPSuccess = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerPSuccess.setPageIncrement(10);
		spinnerPSuccess.setIncrement(1);
		spinnerPSuccess.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerPSuccess.setMaximum(100);
		spinnerPSuccess.setMinimum(0);
		spinnerPSuccess.setSelection(50);
		spinnerPSuccess.setDigits(0);

		Label lblLambda = new Label(grpModelParameters, SWT.NONE);
		lblLambda.setText("Lambda");

		spinnerLambda = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerLambda.setPageIncrement(10);
		spinnerLambda.setIncrement(1);
		spinnerLambda.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerLambda.setMaximum(100);
		spinnerLambda.setMinimum(1);
		spinnerLambda.setSelection(50);
		spinnerLambda.setDigits(2);

		Label lblGoodGood = new Label(grpModelParameters, SWT.NONE);
		lblGoodGood.setText("Probability good-good");

		spinnerPGood = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerPGood.setPageIncrement(10);
		spinnerPGood.setIncrement(1);
		spinnerPGood.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerPGood.setMaximum(100);
		spinnerPGood.setMinimum(0);
		spinnerPGood.setSelection(50);
		spinnerPGood.setDigits(0);

		Label lblBadBad = new Label(grpModelParameters, SWT.NONE);
		lblBadBad.setText("Probability bad-bad");

		spinnerPBad = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerPBad.setPageIncrement(10);
		spinnerPBad.setIncrement(1);
		spinnerPBad.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerPBad.setMaximum(100);
		spinnerPBad.setMinimum(0);
		spinnerPBad.setSelection(50);
		spinnerPBad.setDigits(0);

		Label lblRoundtripMean = new Label(grpModelParameters, SWT.NONE);
		lblRoundtripMean.setText("Avg. roundtrip [ms]");

		spinnerRoundtripMean = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerRoundtripMean.setPageIncrement(10);
		spinnerRoundtripMean.setIncrement(1);
		spinnerRoundtripMean.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerRoundtripMean.setMaximum(100000);
		spinnerRoundtripMean.setMinimum(0);
		spinnerRoundtripMean.setSelection(1000);
		spinnerRoundtripMean.setDigits(0);

		Label lblRoundTripStd = new Label(grpModelParameters, SWT.NONE);
		lblRoundTripStd.setText("Std. dev. roundtrip");

		spinnerRoundtripStdDev = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerRoundtripStdDev.setPageIncrement(10);
		spinnerRoundtripStdDev.setIncrement(1);
		spinnerRoundtripStdDev.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerRoundtripStdDev.setMaximum(100000);
		spinnerRoundtripStdDev.setMinimum(0);
		spinnerRoundtripStdDev.setSelection(1000);
		spinnerRoundtripStdDev.setDigits(2);

		Label lblSeed = new Label(grpModelParameters, SWT.NONE);
		lblSeed.setText("Random seed");

		spinnerSeed = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerSeed.setPageIncrement(10);
		spinnerSeed.setIncrement(1);
		spinnerSeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerSeed.setMaximum(1000000);
		spinnerSeed.setMinimum(0);
		spinnerSeed.setSelection(1000);
		spinnerSeed.setDigits(0);
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			currentModel = ChannelModels.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' model parameters", currentModel.toString()));
			setupUiFor(currentModel);
		}
	}

	@Override
	protected void addModelToList() {
		if (currentModel == ChannelModels.UNIFORM) {
			UniformlyDistributedChannelDataBean bean = new UniformlyDistributedChannelDataBean();
			bean.setModelIdentifier(txtIdentifier.getText());
			bean.setFullName(txtFullName.getText());
			bean.setpSuccess((double) spinnerPSuccess.getSelection() / 100.0 / Math.pow(10, spinnerPSuccess.getDigits()));
			bean.setRandomSeed(spinnerSeed.getSelection() / (long) Math.pow(10, spinnerSeed.getDigits()));
			modelSet.add(bean);
		} else if (currentModel == ChannelModels.GEOMETRIC) {
			GeometricDistributionChannelDataBean bean = new GeometricDistributionChannelDataBean();
			bean.setModelIdentifier(txtIdentifier.getText());
			bean.setFullName(txtFullName.getText());
			bean.setLambda(spinnerLambda.getSelection() / (float) Math.pow(10, spinnerLambda.getDigits()));
			bean.setRandomSeed(spinnerSeed.getSelection() / (long) Math.pow(10, spinnerSeed.getDigits()));
			bean.setRoundtripMillisMean(spinnerRoundtripMean.getSelection() / (long) Math.pow(10, spinnerRoundtripMean.getDigits()));
			bean.setRoundtripStdDev(spinnerRoundtripStdDev.getSelection() / Math.pow(10, spinnerRoundtripStdDev.getDigits()));
			modelSet.add(bean);
		} else if (currentModel == ChannelModels.GILBERT_ELLIOT) {
			GilbertElliotChannelDataBean bean = new GilbertElliotChannelDataBean();
			bean.setModelIdentifier(txtIdentifier.getText());
			bean.setFullName(txtFullName.getText());
			bean.setpBadBad(spinnerPBad.getSelection() / 100.0f / (float) Math.pow(10, spinnerPBad.getDigits()));
			bean.setpGoodGood(spinnerPGood.getSelection() / 100.0f / (float) Math.pow(10, spinnerPGood.getDigits()));
			bean.setRandomSeed(spinnerSeed.getSelection() / (long) Math.pow(10, spinnerSeed.getDigits()));
			bean.setRoundtripMillisMean(spinnerRoundtripMean.getSelection() / (long) Math.pow(10, spinnerRoundtripMean.getDigits()));
			bean.setRoundtripStdDev(spinnerRoundtripStdDev.getSelection() / Math.pow(10, spinnerRoundtripStdDev.getDigits()));
			modelSet.add(bean);
		}
	}

	private void setupUiFor(ChannelModels model) {

		controlMapping.clear();
		modelProperties.clear();

		// Model property initialization
		ModelProperty pSuccess = new ModelProperty("Probability success", "setpSuccess", Double.TYPE, 0, 1);
		ModelProperty lambda = new ModelProperty("Lambda", "setLambda", Float.TYPE, 0.01f, 1.0f);
		ModelProperty pGood = new ModelProperty("Probability good-good", "setpGoodGood", Float.TYPE, 0, 1);
		ModelProperty pBad = new ModelProperty("Probability bad-bad", "setpBadBad", Float.TYPE, 0, 1);
		ModelProperty roundtripMean = new ModelProperty("Avg. roundtrip [ms]", "setRoundtripMillisMean", Long.TYPE, 0, 100000);
		ModelProperty roundtripStd = new ModelProperty("Std. dev. roundtrip", "setRoundtripStdDev", Double.TYPE, 0, 1000);
		ModelProperty seed = new ModelProperty("Random seed", "setRandomSeed", Long.class, 0, 1000000);

		switch (model) {
		case GEOMETRIC:
			spinnerLambda.setEnabled(true);
			spinnerPBad.setEnabled(false);
			spinnerPGood.setEnabled(false);
			spinnerPSuccess.setEnabled(false);
			spinnerRoundtripMean.setEnabled(true);
			spinnerRoundtripStdDev.setEnabled(true);
			spinnerSeed.setEnabled(true);

			modelProperties.add(lambda);
			modelProperties.add(roundtripMean);
			modelProperties.add(roundtripStd);
			modelProperties.add(seed);

			controlMapping.put(roundtripMean, spinnerRoundtripMean);
			controlMapping.put(roundtripStd, spinnerRoundtripStdDev);
			controlMapping.put(lambda, spinnerLambda);
			controlMapping.put(seed, spinnerSeed);
			break;
		case UNIFORM:
			spinnerLambda.setEnabled(false);
			spinnerPBad.setEnabled(false);
			spinnerPGood.setEnabled(false);
			spinnerPSuccess.setEnabled(true);
			spinnerRoundtripMean.setEnabled(false);
			spinnerRoundtripStdDev.setEnabled(false);
			spinnerSeed.setEnabled(true);

			modelProperties.add(pSuccess);
			modelProperties.add(seed);

			controlMapping.put(pSuccess, spinnerPSuccess);
			controlMapping.put(seed, spinnerSeed);
			break;
		case GILBERT_ELLIOT:
			spinnerLambda.setEnabled(false);
			spinnerPBad.setEnabled(true);
			spinnerPGood.setEnabled(true);
			spinnerPSuccess.setEnabled(false);
			spinnerRoundtripMean.setEnabled(true);
			spinnerRoundtripStdDev.setEnabled(true);
			spinnerSeed.setEnabled(true);

			modelProperties.add(pGood);
			modelProperties.add(pBad);
			modelProperties.add(roundtripMean);
			modelProperties.add(roundtripStd);
			modelProperties.add(seed);

			controlMapping.put(pGood, spinnerPGood);
			controlMapping.put(pBad, spinnerPBad);
			controlMapping.put(roundtripMean, spinnerRoundtripMean);
			controlMapping.put(roundtripStd, spinnerRoundtripStdDev);
			controlMapping.put(seed, spinnerSeed);
			break;
		default:
			break;
		}
	}

	@Override
	protected void createColumns(TableViewer tv, String modelIdentifier) {
		ChannelModels model = ChannelModels.valueOfLabel(modelIdentifier);

		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ModelBean) element).getModelIdentifier() + "";
			}
		});

		if (model == ChannelModels.UNIFORM) {
			TableViewerColumn colPSuccess = createTableViewerColumn("Probability success", 120);
			colPSuccess.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return String.valueOf(((UniformlyDistributedChannelDataBean) element).getpSuccess()) + "";
				}
			});
		}

		if (model == ChannelModels.GEOMETRIC) {
			TableViewerColumn colLambda = createTableViewerColumn("Lambda", 100);
			colLambda.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return String.valueOf(((GeometricDistributionChannelDataBean) element).getLambda()) + "";
				}
			});
		}

		if (model == ChannelModels.GILBERT_ELLIOT) {
			TableViewerColumn colPBadBad = createTableViewerColumn("Probability Bad-Bad", 120);
			colPBadBad.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return String.valueOf(((GilbertElliotChannelDataBean) element).getpBadBad()) + "";
				}
			});
		}

		if (model == ChannelModels.GILBERT_ELLIOT) {
			TableViewerColumn colPGoodGood = createTableViewerColumn("Probability Good-Good", 120);
			colPGoodGood.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return String.valueOf(((GilbertElliotChannelDataBean) element).getpGoodGood()) + "";
				}
			});
		}

		if (model == ChannelModels.GILBERT_ELLIOT || model == ChannelModels.GEOMETRIC) {
			TableViewerColumn colRoundtripMean = createTableViewerColumn("Avg. roundtrip [ms]", 120);
			colRoundtripMean.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					if (model == ChannelModels.GEOMETRIC) {
						return String.valueOf(((GeometricDistributionChannelDataBean) element).getRoundtripMillisMean()) + "";
					} else {
						return String.valueOf(((GilbertElliotChannelDataBean) element).getRoundtripMillisMean()) + "";
					}
				}
			});
		}

		if (model == ChannelModels.GILBERT_ELLIOT || model == ChannelModels.GEOMETRIC) {
			TableViewerColumn colRoundtripStd = createTableViewerColumn("Std. dev. roundtrip", 120);
			colRoundtripStd.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					if (model == ChannelModels.GEOMETRIC) {
						return String.valueOf(((GeometricDistributionChannelDataBean) element).getRoundtripStdDev()) + "";
					} else {
						return String.valueOf(((GilbertElliotChannelDataBean) element).getRoundtripStdDev()) + "";
					}
				}
			});
		}

		TableViewerColumn colRandomSeed = createTableViewerColumn("Random Seed", 100);
		colRandomSeed.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (model == ChannelModels.UNIFORM) {
					return ((UniformlyDistributedChannelDataBean) element).getRandomSeed() != null
							? String.valueOf(((UniformlyDistributedChannelDataBean) element).getRandomSeed()) + "" : "";
				} else if (model == ChannelModels.GEOMETRIC) {
					return ((GeometricDistributionChannelDataBean) element).getRandomSeed() != null
							? String.valueOf(((GeometricDistributionChannelDataBean) element).getRandomSeed()) + "" : "";
				} else {
					return ((GilbertElliotChannelDataBean) element).getRandomSeed() != null
							? String.valueOf(((GilbertElliotChannelDataBean) element).getRandomSeed()) + "" : "";
				}
			}
		});
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {
		try {
			Class<?> cls = null;

			if (currentModel == ChannelModels.UNIFORM) {
				cls = UniformlyDistributedChannelDataBean.class;
			} else if (currentModel == ChannelModels.GEOMETRIC) {
				cls = GeometricDistributionChannelDataBean.class;
			} else if (currentModel == ChannelModels.GILBERT_ELLIOT) {
				cls = GilbertElliotChannelDataBean.class;
			}

			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();
				cls.getMethod("setModelIdentifier", String.class).invoke(obj,
						currentModel.getShortName() + "_gen_" + generationTime + "-" + (i + 1));
				cls.getMethod("setFullName", String.class).invoke(obj, "Auto. generated channel model");

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Method setter = cls.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);

						if (property.getType() == Integer.TYPE || property.getType() == Integer.class) {
							setter.invoke(obj, (int) (sampledValue * property.getConversionFactor()));
						} else if (property.getType() == Long.TYPE || property.getType() == Long.class) {
							setter.invoke(obj, (long) (sampledValue * property.getConversionFactor()));
						} else if (property.getType() == Float.TYPE || property.getType() == Float.class) {
							setter.invoke(obj, (float) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(obj, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(obj, (int) (spinner.getSelection() / Math.pow(10, spinner.getDigits())
										* property.getConversionFactor()));
							} else if (property.getType() == Long.TYPE || property.getType() == Long.class) {
								setter.invoke(obj, (long) (spinner.getSelection() / Math.pow(10, spinner.getDigits())
										* property.getConversionFactor()));
							} else if (property.getType() == Float.TYPE || property.getType() == Float.class) {
								setter.invoke(obj, (float) (spinner.getSelection() / Math.pow(10, spinner.getDigits())
										* property.getConversionFactor()));
							} else {
								setter.invoke(obj,
										(spinner.getSelection() / Math.pow(10, spinner.getDigits()) * property.getConversionFactor()));
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(obj, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(obj, text.getText());
						}
					}
				}

				if (currentModel == ChannelModels.UNIFORM) {
					modelSet.add((UniformlyDistributedChannelDataBean) obj);
				} else if (currentModel == ChannelModels.GEOMETRIC) {
					modelSet.add((GeometricDistributionChannelDataBean) obj);
				} else if (currentModel == ChannelModels.GILBERT_ELLIOT) {
					modelSet.add((GilbertElliotChannelDataBean) obj);
				}
			}
		} catch (

		Exception ex)

		{
			ex.printStackTrace();
		}
	}
}

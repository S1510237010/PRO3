package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.io.File;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.widgets.Composite;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.LongitudinalModelInputDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.DefaultLongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControls;

public class DefaultLongitudinalControlConfigurationPage extends LongitudinalControlConfigurationPage {

	private LongitudinalControls currentControl;
	
	protected DefaultLongitudinalControlConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);
		grpModelParameters.setVisible(false);
	}
	
	@Override
	protected boolean isStochasticAddPossible() {
		return false;
	}
	
	@Override
	protected boolean isAddPossible() {
		if (comboLongitudinalModel == null) {
			return false;
		}

		return comboLongitudinalModel.getItemCount() > 0;
	}
	
	@Override
	protected void addModelToList() {
		DefaultLongitudinalControlBean control = new DefaultLongitudinalControlBean();
		control.setIdentifier(txtIdentifier.getText());
		control.setLongitudinalModelIdentifier(comboLongitudinalModel.getText());
		modelSet.add(control);
	}

	@Override
	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((DefaultLongitudinalControlBean) element).getIdentifier() + "";
			}
		});

		TableViewerColumn colLongitudinalModel = createTableViewerColumn("Underlying longitudinal model", 210);
		colLongitudinalModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((DefaultLongitudinalControlBean) element).getLongitudinalModelIdentifier() + "";
			}
		});
	}
	
	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			initializeModels();
			currentControl = LongitudinalControls.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' control parameters", currentControl.toString()));
		}
	}
	
	private void initializeModels() {
		try {
			comboLongitudinalModel.removeAll();

			DataSerializer ser = new DataSerializer();
			File configFile = ((ModelSelectionPage) ((ModelGeneratorWizard) getWizard()).getPage(ModelGeneratorWizard.PAGE_MODEL_SELECTION))
					.getConfigFile();
			ser.readConfiguration(configFile);

			List<? extends AbstractBean> beans = ser.readData(ModelBean.class);

			for (AbstractBean abstractBean : beans) {
				if (abstractBean instanceof LongitudinalModelInputDataBean) {
					comboLongitudinalModel.add(((LongitudinalModelInputDataBean) abstractBean).getModelIdentifier());
				}
			}

			if (comboLongitudinalModel.getItemCount() > 0) {
				comboLongitudinalModel.setEnabled(true);
				comboLongitudinalModel.select(0);
				lblModelWarning.setVisible(false);
			} else {
				comboLongitudinalModel.setEnabled(false);
				lblModelWarning.setVisible(true);
			}

			validatePage();
		} catch (Exception exc) {
			setErrorMessage("Controls couldn't be loaded. Ensure that the configuration file is not corrupt.");
			comboLongitudinalModel.setEnabled(false);
			return;
		}
	}
}
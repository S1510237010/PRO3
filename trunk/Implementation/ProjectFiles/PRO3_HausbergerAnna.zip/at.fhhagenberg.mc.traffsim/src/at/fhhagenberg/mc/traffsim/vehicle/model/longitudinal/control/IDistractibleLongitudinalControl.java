package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

public interface IDistractibleLongitudinalControl {

	void distract(double delayFactor);

	boolean isSeverelyDistracted();

	void setSeverelyDistracted(boolean isSeverelyDistracted);

	boolean isDistracted();

	void setDistracted(boolean isDistracted);

	double getDelayFactor();
}

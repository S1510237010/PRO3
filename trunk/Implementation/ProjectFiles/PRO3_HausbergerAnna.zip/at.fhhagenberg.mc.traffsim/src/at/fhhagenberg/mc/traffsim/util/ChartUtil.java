package at.fhhagenberg.mc.traffsim.util;

import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider;
import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider.PlotMode;
import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider.UpdateMode;

/**
 * Utility class providing chart-related functionality.
 *
 * @author Christian Backfrieder
 */
public class ChartUtil {

	/**
	 * Creates a circular buffer data provider with the given buffer size and delay.
	 *
	 * @param bufferSize
	 *            the buffer size
	 * @param updateDelay
	 *            the update delay
	 * @return the resulting circular buffer data provider
	 */
	public static CircularBufferDataProvider createDataProvider(int bufferSize, int updateDelay) {
		CircularBufferDataProvider dataprov = new CircularBufferDataProvider(false);
		dataprov.setBufferSize(bufferSize);
		dataprov.setUpdateDelay(updateDelay);
		dataprov.setUpdateMode(UpdateMode.X_AND_Y);
		dataprov.setPlotMode(PlotMode.LAST_N);
		return dataprov;
	}
}
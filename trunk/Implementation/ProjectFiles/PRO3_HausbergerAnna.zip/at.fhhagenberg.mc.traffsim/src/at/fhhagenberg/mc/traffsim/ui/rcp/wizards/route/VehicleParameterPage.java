package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.MOBILDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.MemoryDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.routing.routegenerator.VehicleAttributes;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route.RouteParameterPage.RouteParameters;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class VehicleParameterPage extends WizardPage {
	private static final String CONTIGUOUS = "CONTIGUOUS";
	private static final String RANDOM = "RANDOM";
	private Table table;
	private List<VehicleAttributes> vehicleSets = new ArrayList<>();
	private TableViewer viewer;

	private Combo comboLongitudinalControl;
	private Combo comboLaneChangeModel;
	private Combo comboMemoryModel;
	private Combo comboConsumptionModel;
	private Combo comboRoutes;

	private List<? extends AbstractBean> modelBeans;
	private List<? extends AbstractBean> controlBeans;
	private Button btnAdd;
	private Button btnRemove;
	private Button btnRandomAssignment;

	private Button btnAppend;
	private boolean appendToExistingConfig;
	private Random randomGenerator;
	private Label lblRouteUpdateInterval;
	private Spinner spinnerStaticUpdateInterval;
	private Label lblDynamicRouteUpdate;
	private Spinner spinnerDynamicThreshold;
	private Label lblDataCommunicationInterval;
	private Spinner spinnerDataCommInterval;

	protected VehicleParameterPage(String pageName) {
		super(pageName);
		setPageComplete(true);
		setDescription("Set up vehicle details");
		setTitle("Vehicle parameters");
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new GridLayout(2, false));

		Group grpSetOverview = new Group(container, SWT.NONE);
		grpSetOverview.setLayout(new FillLayout(SWT.HORIZONTAL));
		grpSetOverview.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		grpSetOverview.setText("Set Overview");

		viewer = new TableViewer(grpSetOverview, SWT.BORDER | SWT.FULL_SELECTION);
		table = viewer.getTable();
		table.setHeaderVisible(true);

		createColumns(viewer);

		Group grpVehicleSet = new Group(container, SWT.NONE);
		grpVehicleSet.setText("Vehicle set");
		grpVehicleSet.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, true, false, 1, 1));
		grpVehicleSet.setLayout(new GridLayout(7, false));

		Label lblProbability = new Label(grpVehicleSet, SWT.NONE);
		lblProbability.setText("Probability");

		final Spinner spinnerProbability = new Spinner(grpVehicleSet, SWT.BORDER);
		spinnerProbability.setMaximum(10000);
		spinnerProbability.setSelection(1);

		Label lblType = new Label(grpVehicleSet, SWT.NONE);
		lblType.setText("Type");

		final Combo comboType = new Combo(grpVehicleSet, SWT.READ_ONLY);
		comboType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		for (VehicleType t : VehicleType.values()) {
			if (!Vehicle.isObstacle(t)) {
				comboType.add(t.toString());
			}
		}
		comboType.select(0);

		Label lblInitialSpeed = new Label(grpVehicleSet, SWT.NONE);
		lblInitialSpeed.setText("Initial speed [mps]");

		final Spinner spinnerInitialSpeed = new Spinner(grpVehicleSet, SWT.BORDER);
		spinnerInitialSpeed.setSelection(2);
		spinnerInitialSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Group grpCommunication = new Group(grpVehicleSet, SWT.NONE);
		grpCommunication.setLayout(new GridLayout(2, false));
		grpCommunication.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 1, 3));
		grpCommunication.setText("Communication");

		Button btnCommunicationEnabled = new Button(grpCommunication, SWT.CHECK);
		btnCommunicationEnabled.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setCommAreaEnabled(btnCommunicationEnabled.getSelection());
			}
		});
		btnCommunicationEnabled.setText("Communication Enabled");
		new Label(grpCommunication, SWT.NONE);

		lblRouteUpdateInterval = new Label(grpCommunication, SWT.NONE);
		lblRouteUpdateInterval.setEnabled(false);
		lblRouteUpdateInterval.setToolTipText("Update interval for static routing (route update is considered every ... seconds)");
		lblRouteUpdateInterval.setText("Static route update interval [s]");

		spinnerStaticUpdateInterval = new Spinner(grpCommunication, SWT.BORDER);
		spinnerStaticUpdateInterval.setEnabled(false);
		spinnerStaticUpdateInterval.setMaximum(36000000);
		spinnerStaticUpdateInterval.setSelection(300);
		spinnerStaticUpdateInterval.setDigits(1);

		lblDynamicRouteUpdate = new Label(grpCommunication, SWT.NONE);
		lblDynamicRouteUpdate.setEnabled(false);
		lblDynamicRouteUpdate.setText("Dynamic route update threshold [s]");

		spinnerDynamicThreshold = new Spinner(grpCommunication, SWT.BORDER);
		spinnerDynamicThreshold.setEnabled(false);
		spinnerDynamicThreshold.setMaximum(3600000);
		spinnerDynamicThreshold.setSelection(300);
		spinnerDynamicThreshold.setDigits(1);
		spinnerDynamicThreshold.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		lblDataCommunicationInterval = new Label(grpCommunication, SWT.NONE);
		lblDataCommunicationInterval.setEnabled(false);
		lblDataCommunicationInterval.setText("Data communication interval [s]");

		spinnerDataCommInterval = new Spinner(grpCommunication, SWT.BORDER);
		spinnerDataCommInterval.setEnabled(false);
		spinnerDataCommInterval.setDigits(1);
		spinnerDataCommInterval.setMaximum(36000000);
		spinnerDataCommInterval.setSelection(300);
		spinnerDataCommInterval.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblWidth = new Label(grpVehicleSet, SWT.NONE);
		lblWidth.setText("Width [m]");

		final Spinner spinnerWidth = new Spinner(grpVehicleSet, SWT.BORDER);
		spinnerWidth.setPageIncrement(50);
		spinnerWidth.setIncrement(10);
		spinnerWidth.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerWidth.setMaximum(5000);
		spinnerWidth.setMinimum(10);
		spinnerWidth.setSelection(170);
		spinnerWidth.setDigits(2);

		Label lblLength = new Label(grpVehicleSet, SWT.NONE);
		lblLength.setText("Length [m]");

		final Spinner spinnerLength = new Spinner(grpVehicleSet, SWT.BORDER);
		spinnerLength.setIncrement(10);
		spinnerLength.setPageIncrement(50);
		spinnerLength.setMaximum(5000);
		spinnerLength.setMinimum(50);
		spinnerLength.setSelection(400);
		spinnerLength.setDigits(2);
		spinnerLength.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblRoutes = new Label(grpVehicleSet, SWT.NONE);
		lblRoutes.setText("Route");
		comboRoutes = new Combo(grpVehicleSet, SWT.READ_ONLY);
		comboRoutes.add(CONTIGUOUS);
		comboRoutes.add(RANDOM);

		Composite composite = new Composite(grpVehicleSet, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 6, 1));
		GridLayout gl_composite = new GridLayout(5, false);
		gl_composite.marginWidth = 0;
		composite.setLayout(gl_composite);

		Label lblModel = new Label(composite, SWT.NONE);
		lblModel.setText("Longitudinal control");
		comboLongitudinalControl = new Combo(composite, SWT.READ_ONLY);

		Label lblLaneChangeModel = new Label(composite, SWT.NONE);
		lblLaneChangeModel.setText("Lane change model");
		comboLaneChangeModel = new Combo(composite, SWT.READ_ONLY);

		btnRandomAssignment = new Button(composite, SWT.CHECK);
		btnRandomAssignment.setText("Assign models randomly");
		btnRandomAssignment.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				comboLongitudinalControl.setEnabled(!btnRandomAssignment.getSelection());
				comboLaneChangeModel.setEnabled(!btnRandomAssignment.getSelection());
				comboMemoryModel.setEnabled(!btnRandomAssignment.getSelection());
				comboConsumptionModel.setEnabled(!btnRandomAssignment.getSelection());
			}
		});

		Label lblMemoryModel = new Label(composite, SWT.NONE);
		lblMemoryModel.setText("Memory model");
		comboMemoryModel = new Combo(composite, SWT.READ_ONLY);

		Label lblConsumptionModel = new Label(composite, SWT.NONE);
		lblConsumptionModel.setText("Consumption model");
		comboConsumptionModel = new Combo(composite, SWT.READ_ONLY);
		new Label(composite, SWT.NONE);

		Composite buttons = new Composite(container, SWT.NONE);
		buttons.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, false, false, 1, 1));
		buttons.setLayout(new GridLayout(1, false));
		btnAdd = new Button(buttons, SWT.NONE);
		btnAdd.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				long routeIdentifier = -1;

				if (comboRoutes.isEnabled()) {
					if (comboRoutes.getText().equals(RANDOM)) {
						routeIdentifier = Long.parseLong(CollectionUtil.getRandomElement(comboRoutes.getItems(), 1));
					} else if (comboRoutes.getText().equals(CONTIGUOUS)) {
						routeIdentifier = -1;
					} else {
						routeIdentifier = Long.parseLong(comboRoutes.getText());
					}
				}

				if (btnRandomAssignment.getSelection()) {

					String longitudinalControl = CollectionUtil.getRandomElement(comboLongitudinalControl.getItems(), 0);
					String laneChangeModel = CollectionUtil.getRandomElement(comboLaneChangeModel.getItems(), 0);
					String consumptionModel = CollectionUtil.getRandomElement(comboConsumptionModel.getItems(), 0);
					String memoryModel = CollectionUtil.getRandomElement(comboMemoryModel.getItems(), 0);

					vehicleSets.add(new VehicleAttributes(VehicleType.valueOfLabel(comboType.getText()), spinnerInitialSpeed.getSelection(),
							((double) spinnerWidth.getSelection()) / 100, ((double) spinnerLength.getSelection()) / 100,
							spinnerProbability.getSelection(), routeIdentifier, longitudinalControl, laneChangeModel, memoryModel, consumptionModel,
							btnCommunicationEnabled.getSelection(), spinnerDataCommInterval.getSelection() * 100,
							spinnerStaticUpdateInterval.getSelection() * 100, spinnerDynamicThreshold.getSelection() * 100));
				} else {
					vehicleSets.add(new VehicleAttributes(VehicleType.valueOfLabel(comboType.getText()), spinnerInitialSpeed.getSelection(),
							((double) spinnerWidth.getSelection()) / 100, ((double) spinnerLength.getSelection()) / 100,
							spinnerProbability.getSelection(), routeIdentifier, comboLongitudinalControl.getText(), comboLaneChangeModel.getText(),
							comboMemoryModel.getText(), comboConsumptionModel.getText(), btnCommunicationEnabled.getSelection(),
							spinnerDataCommInterval.getSelection() * 100, spinnerStaticUpdateInterval.getSelection() * 100,
							spinnerDynamicThreshold.getSelection() * 100));
				}

				viewer.refresh();
				getWizard().getContainer().updateButtons();
				btnAdd.setFocus();
			}
		});
		btnAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnAdd.setText("Add");

		btnRemove = new Button(buttons, SWT.NONE);
		btnRemove.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				vehicleSets.remove(((IStructuredSelection) viewer.getSelection()).getFirstElement());
				viewer.refresh();
				getWizard().getContainer().updateButtons();
			}
		});

		btnRemove.setText("Remove");

		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		btnAppend = new Button(container, SWT.CHECK);
		btnAppend.setText("Appended generated vehicles to existing configuration.");
		btnAppend.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, true, false, 2, 1));
		btnAppend.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				appendToExistingConfig = btnAppend.getSelection();
			}
		});

		viewer.setContentProvider(new ArrayContentProvider());
		viewer.setInput(vehicleSets);
	}

	private void setCommAreaEnabled(boolean enable) {
		lblRouteUpdateInterval.setEnabled(enable);
		spinnerStaticUpdateInterval.setEnabled(enable);
		lblDynamicRouteUpdate.setEnabled(enable);
		spinnerDynamicThreshold.setEnabled(enable);
		lblDataCommunicationInterval.setEnabled(enable);
		spinnerDataCommInterval.setEnabled(enable);
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);
		if (visible) {

			RouteParameters params = ((RouteParameterPage) getWizard().getPage(RouteGeneratorWizard.PAGE_ROUTE_PAREMTERS)).getResult();

			try {
				DataSerializer ser = new DataSerializer();
				ser.readConfiguration(params.configFile);
				modelBeans = ser.readData(ModelBean.class);
				controlBeans = ser.readData(LongitudinalControlBean.class);
			} catch (Exception exc) {
				setErrorMessage("Models / controls couldn't be loaded. Ensure that the configuration file is not corrupt.");
				getWizard().getContainer().updateButtons();
				enableControls(false);
				return;
			}

			comboLongitudinalControl.removeAll();
			comboConsumptionModel.removeAll();
			comboLaneChangeModel.removeAll();
			comboMemoryModel.removeAll();
			comboRoutes.removeAll();

			if (modelBeans != null && !modelBeans.isEmpty()) {
				for (AbstractBean abstractBean : modelBeans) {

					String modelIdentifier = ((ModelBean) abstractBean).getModelIdentifier();

					if (abstractBean instanceof MOBILDataBean) {
						comboLaneChangeModel.add(modelIdentifier);
					} else if (abstractBean instanceof MemoryDataBean) {
						comboMemoryModel.add(modelIdentifier);
					} else if (abstractBean instanceof ConsumptionBean) {
						comboConsumptionModel.add(modelIdentifier);
					}
				}
			}

			if (controlBeans != null && !controlBeans.isEmpty()) {
				for (AbstractBean abstractBean : controlBeans) {

					String modelIdentifier = ((LongitudinalControlBean) abstractBean).getIdentifier();

					if (abstractBean instanceof LongitudinalControlBean) {
						comboLongitudinalControl.add(modelIdentifier);
					}
				}
			}

			if (params.existingRoutes != null) {
				comboRoutes.setEnabled(true);
				comboRoutes.add(CONTIGUOUS);
				comboRoutes.add(RANDOM);

				for (RouteBean route : params.existingRoutes) {
					comboRoutes.add(String.valueOf(route.getId()));
				}

				comboRoutes.select(0);

				List<VehicleAttributes> vehicleSetsToRemove = new ArrayList<VehicleAttributes>();

				for (VehicleAttributes attr : vehicleSets) {
					if (attr.getRouteIdentifier() < 0) {
						vehicleSetsToRemove.add(attr);
					}
				}

				for (VehicleAttributes attr : vehicleSetsToRemove) {
					vehicleSets.remove(attr);
				}

				viewer.refresh();
				getWizard().getContainer().updateButtons();

			} else {
				comboRoutes.setEnabled(false);

				List<VehicleAttributes> vehicleSetsToRemove = new ArrayList<VehicleAttributes>();

				for (VehicleAttributes attr : vehicleSets) {
					if (attr.getRouteIdentifier() >= 0) {
						vehicleSetsToRemove.add(attr);
					}
				}

				for (VehicleAttributes attr : vehicleSetsToRemove) {
					vehicleSets.remove(attr);
				}

				viewer.refresh();
				getWizard().getContainer().updateButtons();
			}

			String errorMessage = null;

			if (comboLongitudinalControl.getItemCount() > 0) {
				comboLongitudinalControl.select(0);
			} else {
				errorMessage = "Please ensure that the configuration file contains at least one longitudinal model / control.";
			}

			if (comboLaneChangeModel.getItemCount() > 0) {
				comboLaneChangeModel.select(0);
			} else {
				if (errorMessage == null) {
					errorMessage = "Please ensure that the configuration file contains at least one lane change model.";
				}
			}

			if (comboMemoryModel.getItemCount() > 0) {
				comboMemoryModel.select(0);
			} else {
				if (errorMessage == null) {
					errorMessage = "Please ensure that the configuration file contains at least one memory model.";
				}
			}

			if (comboConsumptionModel.getItemCount() > 0) {
				comboConsumptionModel.select(0);
			} else {
				if (errorMessage == null) {
					errorMessage = "Please ensure that the configuration file contains at least one consumption model.";
				}
			}

			setErrorMessage(errorMessage == null ? null : errorMessage.toString());
			getWizard().getContainer().updateButtons();

			if (getErrorMessage() == null) {
				enableControls(true);
			} else {
				enableControls(false);
			}
		}
	}

	private void enableControls(boolean enabled) {
		btnAdd.setEnabled(enabled);
		btnRemove.setEnabled(enabled);
		comboConsumptionModel.setEnabled(enabled);
		comboLongitudinalControl.setEnabled(enabled);
		comboLaneChangeModel.setEnabled(enabled);
		comboMemoryModel.setEnabled(enabled);
		btnRandomAssignment.setEnabled(enabled);
	}

	private void createColumns(TableViewer tv) {
		TableViewerColumn colProb = createTableViewerColumn("Probability", 50);
		colProb.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((VehicleAttributes) element).getProbability() + "";
			}
		});

		TableViewerColumn colType = createTableViewerColumn("Type", 50);
		colType.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((VehicleAttributes) element).getType().toString();
			}
		});

		TableViewerColumn colInitSpd = createTableViewerColumn("Initial speed [m/s]", 70);
		colInitSpd.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return String.format("%.1f", ((VehicleAttributes) element).getInitialSpeed());
			}
		});

		TableViewerColumn colWid = createTableViewerColumn("Width [m]", 60);
		colWid.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return String.format("%.2f", ((VehicleAttributes) element).getWidth());
			}
		});

		TableViewerColumn colLen = createTableViewerColumn("Length [m]", 60);
		colLen.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return String.format("%.2f", ((VehicleAttributes) element).getLength());
			}
		});

		TableViewerColumn colRoute = createTableViewerColumn("Route", 60);
		colRoute.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (((VehicleAttributes) element).getRouteIdentifier() < 0) {
					return "-";
				}

				return String.valueOf(((VehicleAttributes) element).getRouteIdentifier());
			}
		});

		TableViewerColumn colLongModel = createTableViewerColumn("Longitudinal Control", 100);
		colLongModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((VehicleAttributes) element).getLongitudinalControlIdentifier().toString();
			}
		});

		TableViewerColumn cloLaneChangeModel = createTableViewerColumn("Lane Change Model", 100);
		cloLaneChangeModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((VehicleAttributes) element).getLaneChangeModelIdentifier().toString();
			}
		});

		TableViewerColumn colMemoryModel = createTableViewerColumn("Memory Model", 100);
		colMemoryModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((VehicleAttributes) element).getMemoryModelIdentifier().toString();
			}
		});

		TableViewerColumn colConsumptionModel = createTableViewerColumn("Consumption Model", 100);
		colConsumptionModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((VehicleAttributes) element).getConsumptionModelIdentifier().toString();
			}
		});

		TableViewerColumn colCommEnabled = createTableViewerColumn("Communication capabilities", 50);
		colCommEnabled.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return String.format("%s", ((VehicleAttributes) element).isCommEnabled() ? "\u2714" : "\u2718");
			}
		});

		TableViewerColumn colUpdInt = createTableViewerColumn("Static Update interval [ms]", 70);
		colUpdInt.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return String.format("%d", ((VehicleAttributes) element).getStaticRouteUpdateInterval());
			}
		});

		TableViewerColumn colUpdDyn = createTableViewerColumn("Dynamic Update interval [ms]", 70);
		colUpdDyn.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return String.format("%d", ((VehicleAttributes) element).getDynamicRouteUpdateThreshold());
			}
		});
		TableViewerColumn colDataComm = createTableViewerColumn("Dynamic Update interval [ms]", 70);
		colDataComm.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return String.format("%d", ((VehicleAttributes) element).getVehicleDataCommInterval());
			}
		});
	}

	private TableViewerColumn createTableViewerColumn(String title, int width) {
		final TableViewerColumn viewerColumn = new TableViewerColumn(viewer, SWT.NONE);
		final TableColumn column = viewerColumn.getColumn();
		column.setText(title);
		column.setWidth(width);
		column.setResizable(true);
		column.setMoveable(true);
		return viewerColumn;
	}

	@Override
	public boolean canFlipToNextPage() {
		return !vehicleSets.isEmpty() && StringUtil.isNullOrEmpty(getErrorMessage());
	}

	@Override
	public boolean isPageComplete() {
		return !vehicleSets.isEmpty() && StringUtil.isNullOrEmpty(getErrorMessage());
	}

	public List<VehicleAttributes> getResult() {
		return vehicleSets;
	}

	public boolean getAppendToExistingConfig() {
		return appendToExistingConfig;
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.BeanConfigurationContainer;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.util.ReflectionUtil;

public class ConfigurationEditorView extends ViewPart {
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.configurationeditor";

	private Text textConfiguration;
	private Text textClassname;
	private Text textFilename;
	private Table table;

	private Combo comboClasses;

	private DataSerializer currentSerializer;

	public ConfigurationEditorView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(3, false));

		Label lblConfigurationFile = new Label(parent, SWT.NONE);
		lblConfigurationFile.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblConfigurationFile.setText("Configuration File");

		textConfiguration = new Text(parent, SWT.BORDER);
		textConfiguration.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Button btnBrowse = new Button(parent, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(Display.getCurrent().getActiveShell(), SWT.SINGLE);
				dialog.setText("Select configuration file");
				dialog.setFilterExtensions(new String[] { Constants.FILE_FILTER_TRAFFSIM_XML });
				dialog.setFilterNames(new String[] { Constants.FILTER_NAME_TRAFFSIM });
				dialog.open();
				File f = new File(dialog.getFilterPath(), dialog.getFileName());
				if (f.exists()) {
					textConfiguration.setText(f.getAbsolutePath());
					updateConfigurationFile(f);
				}
			}
		});
		btnBrowse.setText("Browse");

		Label lblClassfileMapping = new Label(parent, SWT.NONE);
		lblClassfileMapping.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblClassfileMapping.setText("Class-File Mapping");

		comboClasses = new Combo(parent, SWT.READ_ONLY);
		comboClasses.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateClassDetails(comboClasses.getText());
			}
		});
		comboClasses.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(parent, SWT.NONE);

		Group grpMappingDetails = new Group(parent, SWT.NONE);
		grpMappingDetails.setLayout(new GridLayout(2, false));
		grpMappingDetails.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 3, 1));
		grpMappingDetails.setText("Mapping Details");

		Label lblClassName = new Label(grpMappingDetails, SWT.NONE);
		lblClassName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblClassName.setText("Class Name");

		textClassname = new Text(grpMappingDetails, SWT.BORDER);
		textClassname.setEditable(false);
		textClassname.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblFileName = new Label(grpMappingDetails, SWT.NONE);
		lblFileName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblFileName.setText("File Name");

		textFilename = new Text(grpMappingDetails, SWT.BORDER);
		textFilename.setEditable(false);
		textFilename.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		table = new Table(grpMappingDetails, SWT.BORDER | SWT.FULL_SELECTION);
		GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1);
		gd_table.heightHint = 200;
		table.setLayoutData(gd_table);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn column1 = new TableColumn(table, SWT.NONE);
		column1.setText("Class");
		TableColumn column2 = new TableColumn(table, SWT.NONE);
		column2.setText("Filename");
		TableColumn column3 = new TableColumn(table, SWT.NONE);
		column3.setText("Extracted");

		TableColumn column4 = new TableColumn(table, SWT.NONE);
		column4.setText("Perform extraction");
		column1.pack();
		column2.pack();

		final TableEditor editor = new TableEditor(table);
		// The editor must have the same size as the cell and must
		// not be any smaller than 50 pixels.
		editor.horizontalAlignment = SWT.LEFT;
		editor.grabHorizontal = true;
		editor.minimumWidth = 50;
		// editing the second column
		final int EDITABLECOLUMN = 1;

		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// Clean up any previous editor control
				Control oldEditor = editor.getEditor();
				if (oldEditor != null)
					oldEditor.dispose();

				// Identify the selected row
				TableItem item = (TableItem) e.item;
				if (item == null)
					return;

				// The control that will be the editor must be a child of the Table
				Text newEditor = new Text(table, SWT.NONE);
				newEditor.setText(item.getText(EDITABLECOLUMN));
				newEditor.addModifyListener(me -> {
					Text text = (Text) editor.getEditor();
					editor.getItem().setText(EDITABLECOLUMN, text.getText());
				});
				newEditor.selectAll();
				newEditor.setFocus();
				editor.setEditor(newEditor, item, EDITABLECOLUMN);
			}
		});

	}

	private void updateClassDetails(String selectedClass) {
		BeanConfigurationContainer beanConf = currentSerializer.getConfiguration().getBeanConfigurationsMapping().get(selectedClass);
		textClassname.setText(beanConf.getClassName());
		textFilename.setText(beanConf.getFileName());

		table.clearAll();
		for (Control child : table.getChildren()) {
			child.dispose();
		}
		table.setItemCount(0);

		List<String> alreadyExtractedProperties = new ArrayList<>();
		for (Pair<String, String> additional : beanConf.getAdditionalAttributes()) {
			if (new File(currentSerializer.getConfiguration().getConfigurationFile().getParentFile(),
					additional.getRight()).exists()) {
				alreadyExtractedProperties.add(additional.getKey());
			}
		}
		for (Pair<String, String> additional : beanConf.getAdditionalAttributes()) {
			TableItem item = new TableItem(table, SWT.NONE);
			item.setText(new String[] { additional.getLeft(), additional.getRight() });
			TableEditor ed = new TableEditor(table);
			Button button = new Button(table, SWT.CHECK);
			boolean isAlreadyExtracted = alreadyExtractedProperties.contains(additional.getKey());
			button.setSelection(isAlreadyExtracted);
			button.setEnabled(false);
			button.pack();
			ed.minimumWidth = button.getSize().x;
			ed.horizontalAlignment = SWT.LEFT;
			ed.setEditor(button, item, 2);

			ed = new TableEditor(table);
			button = new Button(table, SWT.NONE);
			button.setText("Extract");
			button.setEnabled(!isAlreadyExtracted);
			button.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					doExtract(currentSerializer, beanConf, additional, alreadyExtractedProperties);
				}
			});
			button.pack();
			ed.minimumWidth = button.getSize().x;
			ed.horizontalAlignment = SWT.LEFT;
			ed.setEditor(button, item, 3);
		}
		for (TableColumn col : table.getColumns()) {
			col.pack();
		}
	}

	@SuppressWarnings("unchecked")
	private void doExtract(DataSerializer currentSerializer, BeanConfigurationContainer cont, Pair<String, String> toExtract,
			List<String> alreadyExtractedProperties) {
		try {
			Class<?> toLoad = Class.forName(cont.getClassName());
			List<? extends AbstractBean> data = currentSerializer.readData((Class<? extends AbstractBean>) toLoad);
			List<Object> extractedData = new ArrayList<>();
			for (AbstractBean bean : data) {
				extractedData.add(ReflectionUtil.callGetterForField(bean, toExtract.getLeft()));
				ReflectionUtil.callSetterForField(bean, toExtract.getLeft(), null);
				for (String prop : alreadyExtractedProperties) {
					ReflectionUtil.callSetterForField(bean, prop, null);
				}
			}
			currentSerializer.writeObject(extractedData, toExtract.getRight());
			currentSerializer.writeData(data);
			updateConfigurationFile(currentSerializer.getConfiguration().getConfigurationFile());
			comboClasses.setText(cont.getClassName());
			updateClassDetails(cont.getClassName());
		} catch (Exception e) {
			MessageDialog.openError(getSite().getShell(), "Extraction failed", e.getClass().getName() + "\n" + e.getMessage());
			e.printStackTrace();
		}

	}

	private void updateConfigurationFile(File f) {
		if (currentSerializer == null) {
			currentSerializer = new DataSerializer();
		}
		if (currentSerializer.readConfiguration(f)) {
			comboClasses.setItems(currentSerializer.getConfiguration().getBeanConfigurationsMapping().keySet().toArray(new String[0]));
			if (comboClasses.getItemCount() > 0) {
				comboClasses.select(0);
				updateClassDetails(comboClasses.getText());
			}
		}
	}

	@Override
	public void setFocus() {

	}
}

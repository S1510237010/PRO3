package at.fhhagenberg.mc.traffsim.roadnetwork.route;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class RouteRegistry {
	private Map<Long, IRoute> routes = new ConcurrentHashMap<>();

	public Map<Long, IRoute> getRoutes() {
		return routes;
	}

	public List<IRoute> getDistinctRoutes() {
		List<IRoute> distinctRoutes = new ArrayList<>();

		for (IRoute route : routes.values()) {
			if (!distinctRoutes.contains(route)) {
				distinctRoutes.add(route);
			}
		}

		return distinctRoutes;
	}

	public void addRoute(long id, IRoute route) {
		routes.put(id, route);
	}

	public IRoute getRoute(long id) {
		return routes.get(id);
	}

	public boolean hasRoute(long id) {
		return routes.containsKey(id);
	}

}

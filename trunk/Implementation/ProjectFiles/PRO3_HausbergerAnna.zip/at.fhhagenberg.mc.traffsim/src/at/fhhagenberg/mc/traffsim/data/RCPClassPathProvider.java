package at.fhhagenberg.mc.traffsim.data;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;

import com.thoughtworks.xstream.XStream;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.log.Logger;

/**
 * This class provides the class path for looking up all classes derived from
 * {@link AbstractBean}. Those are used by {@link XStream} for annotation
 * processing prior to reading the XML files.
 *
 * @author Christian Backfrieder
 *
 */
public class RCPClassPathProvider {

	/** Name of the library folder */
	public static final String LIB_FOLDER = "lib";

	/**
	 * A string format outlining files to be added to the class path (e.g.
	 * '*.jar')
	 */
	private String pattern;

	/** The identifier of the plugin to consider for class path construction */
	private String pluginId;

	/**
	 * Flag indicating whether sub directories should be looked up recursively
	 * when creating the class path
	 */
	private final boolean recurse;

	/**
	 * Name of the sub folder to also consider when constructing the class path
	 */
	private String subFolder;

	private String separator;
	
	/**
	 * Instantiates a new instance of RCP class path provider.
	 *
	 * @param pluginId
	 *            the plugin identifier
	 * @param subFolder
	 *            the name of the sub folder to be looked up
	 * @param pattern
	 *            the file type to be considered for class path construction
	 *            (e.g. '*.jar*)
	 * @param recurse
	 *            flag indicating whether sub directories should be looked up
	 *            recursively when creating the class path
	 * @param separator 
	 * 			  separator for classpath, necessary because os specific (win32 ; and unix/osx :)
	 */
	public RCPClassPathProvider(String pluginId, String subFolder, String pattern, boolean recurse, String separator) {
		this.recurse = recurse;
		this.pluginId = pluginId;
		this.pattern = pattern;
		this.subFolder = subFolder;
		this.separator = separator;
		
	}

	/**
	 * Gets the class path under consideration of the plugin identifier, the sub
	 * folder's name, the file pattern and the recursion flag.
	 *
	 * @return the resulting class path
	 */
	public String getClassPath() {
		StringBuffer buf = new StringBuffer();
		Enumeration<URL> urls = Platform.getBundle(pluginId).findEntries(subFolder, pattern, recurse);

		if (urls == null) {
			return "";
		}

		while (urls.hasMoreElements()) {
			URL next = urls.nextElement();
			try {
				buf.append(new File(FileLocator.toFileURL(next).getPath()).getAbsolutePath());
			} catch (IOException e) {
				Logger.logWarn(e.getMessage(), e);
			}

			buf.append(this.separator);
		}

		return buf.substring(0, buf.length() - 1).toString();
	}
}
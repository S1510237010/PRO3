package at.fhhagenberg.mc.traffsim.routing.routegenerator;

import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;

public class VehicleAttributes {
	private double initialSpeed, width, length;
	private boolean commEnabled = false;
	private long staticRouteUpdateInterval;
	private long dynamicRouteUpdateThreshold;
	private long vehicleDataCommInterval;

	private VehicleType type;
	private long probability;
	private String longitudinalControlIdentifier;
	private String laneChangeModelIdentifier;
	private String memoryModelIdentifier;
	private String consumptionModelIdentifier;
	private long routeIdentifier;

	public VehicleAttributes(VehicleType type, double initialSpeed, double width, double length, long probability, long routeIdentifier,
			String longitudinalControlIdentifier, String laneChangeModelIdentifier, String memoryModelIdentifier,
			String consumptionModelIdentifier) {
		this(type, initialSpeed, width, length, probability, routeIdentifier, longitudinalControlIdentifier, laneChangeModelIdentifier,
				memoryModelIdentifier, consumptionModelIdentifier, false, -1, -1, -1);
	}

	public VehicleAttributes(VehicleType type, double initialSpeed, double width, double length, long probability, long routeIdentifier,
			String longitudinalControlIdentifier, String laneChangeModelIdentifier, String memoryModelIdentifier,
			String consumptionModelIdentifier, boolean commEnabled, long dataCommInterval, long staticRouteUpdateInterval,
			long dynamicRouteUpdateThreshold) {
		super();
		this.type = type;
		this.initialSpeed = initialSpeed;
		this.width = width;
		this.length = length;
		this.probability = probability;
		this.routeIdentifier = routeIdentifier;
		this.longitudinalControlIdentifier = longitudinalControlIdentifier;
		this.laneChangeModelIdentifier = laneChangeModelIdentifier;
		this.memoryModelIdentifier = memoryModelIdentifier;
		this.consumptionModelIdentifier = consumptionModelIdentifier;
		this.vehicleDataCommInterval = dataCommInterval;
		this.staticRouteUpdateInterval = staticRouteUpdateInterval;
		this.dynamicRouteUpdateThreshold = dynamicRouteUpdateThreshold;
		this.commEnabled = commEnabled;
	}

	public double getInitialSpeed() {
		return initialSpeed;
	}

	public double getWidth() {
		return width;
	}

	public double getLength() {
		return length;
	}

	public VehicleType getType() {
		return type;
	}

	public long getProbability() {
		return probability;
	}

	public long getRouteIdentifier() {
		return routeIdentifier;
	}

	public String getLongitudinalControlIdentifier() {
		return longitudinalControlIdentifier;
	}

	public String getLaneChangeModelIdentifier() {
		return laneChangeModelIdentifier;
	}

	public String getMemoryModelIdentifier() {
		return memoryModelIdentifier;
	}

	public String getConsumptionModelIdentifier() {
		return consumptionModelIdentifier;
	}

	public long getStaticRouteUpdateInterval() {
		return staticRouteUpdateInterval;
	}

	public long getDynamicRouteUpdateThreshold() {
		return dynamicRouteUpdateThreshold;
	}

	public long getVehicleDataCommInterval() {
		return vehicleDataCommInterval;
	}

	public boolean isCommEnabled() {
		return commEnabled;
	}
}

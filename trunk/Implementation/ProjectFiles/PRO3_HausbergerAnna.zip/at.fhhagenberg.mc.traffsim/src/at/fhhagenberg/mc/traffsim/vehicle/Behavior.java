package at.fhhagenberg.mc.traffsim.vehicle;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.data.beans.BehaviorBean;
import at.fhhagenberg.mc.traffsim.data.csv.CFDataSet;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class Behavior implements Comparable<Behavior> {

	private BehaviorType behaviorType;
	private String vehicleLabel;
	private double intensity;
	private double duration;
	private double offset;
	private double param;
	private List<CFDataSet> controlTrace;

	public static Behavior createBehavior(BehaviorBean bean) {
		BehaviorType type = BehaviorType.valueOfLabel(bean.getBehaviorType());

		if (type == null) {
			return null;
		}

		List<CFDataSet> controlTrace = new ArrayList<>();

		if (bean.getControlTrace() != null) {
			controlTrace.addAll(bean.getControlTrace());
		}

		return new Behavior(type, bean.getVehicleLabel(), bean.getIntensity(), bean.getDuration(), bean.getOffset(),
				bean.getParam(), controlTrace);
	}

	public Behavior(BehaviorType behaviorType, String vehicleLabel, double intensity,
			double duration, double offset, double param, List<CFDataSet> controlTrace) {
		this.behaviorType = behaviorType;
		this.vehicleLabel = vehicleLabel;
		this.intensity = intensity;
		this.duration = duration;
		this.offset = offset;
		this.param = param;
		this.controlTrace = controlTrace;
	}

	public BehaviorType getBehaviorType() {
		return behaviorType;
	}

	public void setBehaviorType(BehaviorType behaviorType) {
		this.behaviorType = behaviorType;
	}

	public String getVehicleLabel() {
		return vehicleLabel;
	}

	public void setVehicleLabel(String vehicleLabel) {
		this.vehicleLabel = vehicleLabel;
	}

	public double getIntensity() {
		return intensity;
	}

	public void setIntensity(double intensity) {
		this.intensity = intensity;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public double getOffset() {
		return offset;
	}

	public void setOffset(double offset) {
		this.offset = offset;
	}

	public double getParam() {
		return param;
	}

	public void setParam(double param) {
		this.param = param;
	}

	public List<CFDataSet> getControlTrace() {
		return controlTrace;
	}

	public void setControlTrace(List<CFDataSet> controlTrace) {
		this.controlTrace = controlTrace;
	}

	public double getInitialTraceSpeed() {
		if (controlTrace == null || controlTrace.isEmpty()) {
			return 0d;
		}

		return controlTrace.get(0).getSpeedLeadVehicle();
	}

	public boolean readyForExecution(double simTime) {
		return simTime >= offset;
	}

	public boolean isExecuting(double simTime) {
		return simTime >= offset && simTime <= offset + duration;
	}

	public boolean finishedExecution(double simTime) {
		return simTime > offset + duration;
	}

	@Override
	public int compareTo(Behavior behavior) {

		if (behavior.getOffset() == this.getOffset()) {
			return 0;
		}

		return behavior.getOffset() > this.getOffset() ? -1 : 1;
	}

	@Override
	public String toString() {
		if (behaviorType == BehaviorType.ACCELERATION || behaviorType == BehaviorType.DECELERATION) {
			return behaviorType.toString() + ": " + intensity + " m/s�, " + duration + "s";
		} else {
			return behaviorType.toString() + "(" + String.format("%.2f", duration) + "s)";
		}
	}
}

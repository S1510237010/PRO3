package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.FixedTimeControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightControllerBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.FixedTimeControlLogic;

/**
 * Implementation of a traffic light controller realizing a fixed time control scheme. Each traffic light at an intersection is operated
 * indivually considering it's green and red phase lengths and initial offsets.
 *
 * @author Manuel Lindorfer
 *
 */
public class FixedTimeController extends TrafficLightController<FixedTimeControlLogic> {

	/**
	 * Creates a new fixed time traffic light controller for the target junction.
	 *
	 * @param id
	 *            unique identifier
	 * @param junction
	 *            the target junction to be operated
	 */
	public FixedTimeController(long id, AbstractJunction junction) {
		super(id, junction);

		for (FixedTimeControlLogic logic : controlLogics) {
			if (logic.isGreenInitially()) {
				logic.requestChange(true);
			}
		}
	}

	@Override
	protected void update(long dt, long simulationRuntime) {
		for (FixedTimeControlLogic logic : controlLogics) {
			if (logic.isGreen()) {
				if (logic.getTimeEllapsed() >= logic.getTimeGreen()) {
					logic.requestChange(false, logic.getDelay());
					logic.setGreen(false);
					logic.setTimeEllapsed(0 - logic.getDelay());
				}
			} else {
				if (logic.getOffset() > 0) {
					if (logic.getTimeEllapsed() >= logic.getOffset()) {
						logic.requestChange(true, logic.getDelay());
						logic.setGreen(true);
						logic.setTimeEllapsed(0 - logic.getDelay());
						logic.setOffset(0);
					}
				} else {
					if (logic.getTimeEllapsed() >= logic.getTimeRed()) {
						logic.requestChange(true, logic.getDelay());
						logic.setGreen(true);
						logic.setTimeEllapsed(0 - logic.getDelay());
					}
				}
			}
		}
	}

	@Override
	public TrafficLightControllerBean toBean() {
		FixedTimeControllerBean bean = new FixedTimeControllerBean();
		bean.setId(id);
		bean.setJunctionId(junction.getId());
		bean.setAreLanesOperatedIndividually(areLanesOperatedIndividually);

		List<ControlLogicBean> controlBeans = new ArrayList<>();

		for (FixedTimeControlLogic logic : controlLogics) {
			controlBeans.add(logic.toBean());
		}

		bean.setControlLogic(controlBeans);

		return bean;
	}

	@Override
	public TrafficLightControllers getControlMode() {
		return TrafficLightControllers.FIXED_TIMED;
	}
}

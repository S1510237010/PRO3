package at.fhhagenberg.mc.traffsim.ui;

import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Line;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;

/**
 * Class representing a m that is used to transform, zoom the polygons to be drawn
 * 
 * @author Christian
 * 
 */
public class Matrix {

	/** m -first coordinate: row, second coordinate: column */
	private double[][] matrix = new double[UiConstants.MATRIX_SIZE][UiConstants.MATRIX_SIZE];

	/**
	 * Copy Constructor
	 * 
	 * @param matrix
	 *            a <code>Matrix</code> object
	 */
	public Matrix(Matrix matrix) {
		this.matrix = new double[matrix.get().length][];
		for (int i = 0; i < matrix.get().length; i++) {
			this.matrix[i] = matrix.get()[i].clone();
		}
	}

	/**
	 * creates a new m which is initialized with zero values
	 */
	public Matrix() {
		for (int row = 0; row < UiConstants.MATRIX_SIZE; row++) {
			for (int col = 0; col < UiConstants.MATRIX_SIZE; col++) {
				matrix[row][col] = 0;
			}
		}
	}

	/**
	 * Creates a new 3x3 Matrix with initial values
	 * 
	 * @param _m11
	 *            init value 11
	 * @param _m12
	 *            init value 12
	 * @param _m13
	 *            init value 13
	 * @param _m21
	 *            init value 21
	 * @param _m22
	 *            init value 22
	 * @param _m23
	 *            init value 23
	 * @param _m31
	 *            init value 31
	 * @param _m32
	 *            init value 32
	 * @param _m33
	 *            init value 33
	 */
	public Matrix(double _m11, double _m12, double _m13, double _m21, double _m22, double _m23, double _m31, double _m32, double _m33) {
		matrix[0][0] = _m11;
		matrix[0][1] = _m12;
		matrix[0][2] = _m13;
		matrix[1][0] = _m21;
		matrix[1][1] = _m22;
		matrix[1][2] = _m23;
		matrix[2][0] = _m31;
		matrix[2][1] = _m32;
		matrix[2][2] = _m33;

	}

	/**
	 * Returns a single element of the m.
	 * 
	 * @param _row
	 *            Row of element (from 1-3) - starting at 1 (not zero!)
	 * @param _col
	 *            Column of element (from 1-3) - starting at 1 (not zero!)
	 * @return value at specified positionf
	 */
	private double get(int _row, int _col) {
		return matrix[_row - 1][_col - 1];
	}

	/**
	 * Set a single element of the m
	 * 
	 * @param _row
	 *            row of element
	 * @param _column
	 *            column of element
	 * @param _val
	 *            value to set
	 */
	public void set(int _row, int _column, double _val) {
		matrix[_row - 1][_column - 1] = _val;
	}

	/**
	 * Liefert eine Translationsmatrix
	 * 
	 * @param _x
	 *            Der Translationswert der Matrix in X-Richtung
	 * @param _y
	 *            Der Translationswert der Matrix in Y-Richtung
	 * @return Die Translationsmatrix
	 */
	public static Matrix translate(double _x, double _y) {
		Matrix translate = new Matrix(1, 0, _x, 0, 1, _y, 0, 0, 1);
		return translate;
	}

	/**
	 * Liefert eine Translationsmatrix
	 * 
	 * @param _pt
	 *            Ein Punkt, der die Translationswerte enthält
	 * @return Die Translationsmatrix
	 * @see java.awt.Point
	 */
	public static Matrix translate(java.awt.Point _pt) {
		return translate(_pt.x, _pt.y);
	}

	/**
	 * Liefert eine Skalierungsmatrix
	 * 
	 * @param _scaleVal
	 *            Der Skalierungswert der Matrix
	 * @return Die Skalierungsmatrix
	 */
	public static Matrix scale(double _scaleVal) {
		Matrix scale = new Matrix();

		scale.set(1, 1, _scaleVal);
		scale.set(2, 2, _scaleVal);
		scale.set(3, 3, 1);
		return scale;

	}

	/**
	 * Liefert eine Spiegelungsmatrix (X-Achse)
	 * 
	 * @return Die Spiegelungsmatrix
	 */
	public static Matrix mirrorX() {
		Matrix mirrorX = new Matrix(1, 0, 0, 0, -1, 0, 0, 0, 1);
		return mirrorX;
	}

	/**
	 * Liefert eine Spiegelungsmatrix (Y-Achse)
	 * 
	 * @return Die Spiegelungsmatrix
	 */
	public static Matrix mirrorY() {
		Matrix mirrorY = new Matrix(-1, 0, 0, 0, 1, 0, 0, 0, 1);
		return mirrorY;
	}

	/**
	 * Liefert eine Rotationsmatrix
	 * 
	 * @param _alpha
	 *            Der Winkel (in rad), um den rotiert werden soll
	 * @return Die Rotationsmatrix
	 */
	public static Matrix rotate(double _alpha) {
		Matrix rotate = new Matrix();
		rotate.set(1, 1, Math.cos(_alpha));
		rotate.set(1, 2, -Math.sin(_alpha));

		rotate.set(2, 1, Math.sin(_alpha));
		rotate.set(2, 2, Math.cos(_alpha));

		rotate.set(3, 3, 1);

		return rotate;
	}

	/**
	 * Liefert den Faktor, der benötigt wird, um das _world- Rechteck in das _win-Rechteck zu skalieren (einzupassen) bezogen auf die
	 * X-Achse  Breite
	 * 
	 * @param _world
	 *            Das Rechteck in Weltkoordinaten
	 * @param _win
	 *            Das Rechteck in Bildschirmkoordinaten
	 * @return Der Skalierungsfaktor
	 * @see java.awt.Rectangle
	 */
	public static double getZoomFactorX(java.awt.Rectangle _world, java.awt.Rectangle _win) {
		return _win.getWidth() / _world.getWidth();
	}

	/**
	 * Liefert den Faktor, der benötigt wird, um das _world- Rechteck in das _win-Rechteck zu skalieren (einzupassen) bezogen auf die
	 * Y-Achse  Höhe
	 * 
	 * @param _world
	 *            Das Rechteck in Weltkoordinaten
	 * @param _win
	 *            Das Rechteck in Bildschirmkoordinaten
	 * @return Der Skalierungsfaktor
	 * @see java.awt.Rectangle
	 */
	public static double getZoomFactorY(java.awt.Rectangle _world, java.awt.Rectangle _win) {
		return _win.getHeight() / _world.getHeight();
	}

	/**
	 * Liefert eine Matrix, die alle notwendigen Transformationen beinhaltet (Translation, Skalierung, Spiegelung und Translation), um ein
	 * _world-Rechteck in ein _win-Rechteck abzubilden
	 * 
	 * @param _world
	 *            Das Rechteck in Weltkoordinaten
	 * @param _win
	 *            Das Rechteck in Bildschirmkoordinaten
	 * @return Die Transformationsmatrix
	 * @see java.awt.Rectangle
	 */
	public static Matrix zoomToFit(java.awt.Rectangle _world, java.awt.Rectangle _win) {

		// move the world rectangle to zero coordinates
		Matrix trans1 = translate(-_world.getCenterX(), -_world.getCenterY());

		double zoomFactor = getZoomFactorX(_world, _win);
		double zoomFactorY = getZoomFactorY(_world, _win);

		if (zoomFactor > zoomFactorY) {
			zoomFactor = zoomFactorY;
		}

		Matrix scale = scale(zoomFactor);
		Matrix mirror = mirrorX();
		Matrix trans2 = translate(_win.getCenterX(), _win.getCenterY());

		return trans2.multiply(mirror.multiply(scale.multiply(trans1)));
	}

	/**
	 * Liefert eine Matrix, die eine vorhandene Transformations- m erweitert, um an einem bestimmten Punkt um einen bestimmten Faktor in die
	 * Karte hinein- bzw. heraus zu zoomen
	 * 
	 * @param _old
	 *            Die zu erweiternde Transformationsmatrix
	 * @param _zoomPt
	 *            Der Punkt an dem gezoomt werden soll
	 * @param _zoomScale
	 *            Der Zoom-Faktor um den gezoomt werden soll
	 * @return Die neue Transformationsmatrix
	 * @see java.awt.Point
	 */
	public static Matrix zoomPoint(Matrix _old, java.awt.Point _zoomPt, double _zoomScale) {
		Matrix translateMinus = (translate(-_zoomPt.x, -_zoomPt.y));
		Matrix scale = (scale(_zoomScale));
		Matrix translatePlus = (translate(_zoomPt.x, _zoomPt.y));
		return translatePlus.multiply(scale.multiply(translateMinus.multiply(_old)));
	}

	/**
	 * Liefert eine Matrix, die das Ergebnis einer Matrizen- multiplikation zwischen dieser und der übergebenen Matrix ist
	 * 
	 * @param _other
	 *            Die Matrix mit der Multipliziert werden soll
	 * @return Die Ergebnismatrix der Multiplikation
	 */
	public Matrix multiply(Matrix _other) {
		Matrix result = new Matrix();
		for (int row = 1; row <= UiConstants.MATRIX_SIZE; row++) {
			for (int i = 1; i <= UiConstants.MATRIX_SIZE; i++) {
				double value = 0;
				for (int j = 1; j <= UiConstants.MATRIX_SIZE; j++) {
					value += get(row, j) * _other.get(j, i);
				}
				result.set(row, i, value);
			}
		}
		return result;
	}

	/**
	 * Multipliziert einen Punkt mit der Matrix und liefert das Ergebnis der Multiplikation zurück
	 * 
	 * @param _pt
	 *            Der Punkt, der mit der Matrix multipliziert werden soll
	 * @return Ein neuer Punkt, der das Ergebnis der Multiplikation repräsentiert
	 * @see java.awt.Point
	 */
	public java.awt.Point multiply(java.awt.Point _pt) {
		int x = (int) (get(1, 1) * _pt.x + get(1, 2) * _pt.y + get(1, 3));
		int y = (int) (get(2, 1) * _pt.x + get(2, 2) * _pt.y + get(2, 3));
		return new Point(x, y);
	}

	/**
	 * Multipliziert ein Rechteck mit der Matrix und liefert das Ergebnis der Multiplikation zurück
	 * 
	 * @param _rect
	 *            Das Rechteck, das mit der Matrix multipliziert werden soll
	 * @return Ein neues Rechteck, das das Ergebnis der Multiplikation repräsentiert
	 * @see java.awt.Rectangle
	 */
	public java.awt.Rectangle multiply(java.awt.Rectangle _rect) {
		Point p1 = new Point(_rect.x, _rect.y);
		Point p2 = new Point(_rect.x + _rect.width, _rect.y + _rect.height);
		p1 = this.multiply(p1);
		p2 = this.multiply(p2);
		Rectangle rect = new Rectangle(p1);
		rect.add(p2);
		return rect;
	}

	/**
	 * Multipliziert ein Polygon mit der Matrix und liefert das Ergebnis der Multiplikation zurück
	 * 
	 * @param _poly
	 *            Das Polygon, das mit der Matrix multipliziert werden soll
	 * @return Ein neues Polygon, das das Ergebnis der Multiplikation repräsentiert (jeder Punkt des Polygons wird mit der Matrix
	 *         multipliziert und als neues Polygon zurückgegeben)
	 * @see java.awt.Polygon
	 */
	public java.awt.Polygon multiply(java.awt.Polygon _poly) {
		Polygon result = new Polygon();

		for (int i = 0; i < _poly.npoints; i++) {
			Point p = new Point(_poly.xpoints[i], _poly.ypoints[i]);
			Point multiplied = multiply(p);
			result.addPoint(multiplied.x, multiplied.y);
		}

		return result;
	}

	// public LineObject multiply(LineObject _obj) {
	// LineObject result = new LineObject();
	// for (Point p : _obj.getPoints()) {
	// result.addPoint(multiply(p));
	// }
	// return result;
	// }

	/**
	 * Liefert die Invers-Matrix der Transformationsmatrix
	 * 
	 * @return Die Invers-Matrix
	 */
	public Matrix invers() {
		Matrix invMatrix = new Matrix();

		/** first row */
		invMatrix.set(1, 1, determinant(get(2, 2), get(2, 3), get(3, 2), get(3, 3)));
		invMatrix.set(1, 2, determinant(get(1, 3), get(1, 2), get(3, 3), get(3, 2)));
		invMatrix.set(1, 3, determinant(get(1, 2), get(1, 3), get(2, 2), get(2, 3)));

		/** second row */
		invMatrix.set(2, 1, determinant(get(2, 3), get(2, 1), get(3, 3), get(3, 1)));
		invMatrix.set(2, 2, determinant(get(1, 1), get(1, 3), get(3, 1), get(3, 3)));
		invMatrix.set(2, 3, determinant(get(1, 3), get(1, 1), get(2, 3), get(2, 1)));

		/** third row */
		invMatrix.set(3, 1, determinant(get(2, 1), get(2, 2), get(3, 1), get(3, 2)));
		invMatrix.set(3, 2, determinant(get(1, 2), get(1, 1), get(3, 2), get(3, 1)));
		invMatrix.set(3, 3, determinant(get(1, 1), get(1, 2), get(2, 1), get(2, 2)));

		for (int rowIndex = 1; rowIndex <= UiConstants.MATRIX_SIZE; rowIndex++) {
			for (int colIndex = 1; colIndex <= UiConstants.MATRIX_SIZE; colIndex++) {
				double value = (1 / determinant()) * invMatrix.get(rowIndex, colIndex);
				invMatrix.set(rowIndex, colIndex, value);
			}
		}
		return invMatrix;

	}

	/**
	 * Returns a determinant of the 2-dimensional m in the parameters
	 * 
	 * @param _m11
	 *            Matrix element 11
	 * @param _m12
	 *            Matrix element 12
	 * @param _m21
	 *            Matrix element 21
	 * @param _m22
	 *            Matrix element 22
	 * @return determinant value of given m
	 */
	private double determinant(double _m11, double _m12, double _m21, double _m22) {
		return _m11 * _m22 - _m12 * _m21;
	}

	/**
	 * Calculates determinant of this Matrix (3-dimensional)
	 * 
	 * @return determinant of m
	 */
	private double determinant() {
		double result = get(1, 1) * get(2, 2) * get(3, 3) + get(1, 2) * get(2, 3) * get(3, 1) + get(1, 3) * get(2, 1) * get(3, 2)
				- get(1, 1) * get(2, 3) * get(3, 2) - get(1, 2) * get(2, 1) * get(3, 3) - get(1, 3) * get(2, 2) * get(3, 1);

		return result;

	}

	/**
	 * 
	 * @return The current scale factor, meaning a relationship from map projection coordinates to reality coordinates
	 */
	public double getScaleFactor() {
		return Math.sqrt(Math.abs(determinant()));
	}

	/**
	 * Returns a String represenation of the m
	 * 
	 * @return String containing the m content
	 * @see java.lang.String
	 */
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				sb.append(matrix[i][j] + "\t");
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	/**
	 * Multiplies the Matrix with a GeoDoublePoint
	 * 
	 * @param vec
	 *            Point to multiply
	 * @return Multiplied point
	 */
	public Vector multiplyMatrix(Vector vec) {
		double srcx = vec.x;
		double srcy = vec.y;
		double destx = get(1, 1) * srcx + get(1, 2) * srcy;
		double desty = get(2, 1) * srcx + get(2, 2) * srcy;
		if (Double.isNaN(destx)) {
			destx = 0;
		}
		if (Double.isNaN(desty)) {
			desty = 0;
		}
		return new Vector(destx, desty);
	}

	public Vector multiply(Location pos) {
		double x = (get(1, 1) * pos.x + get(1, 2) * pos.y + get(1, 3));
		double y = (get(2, 1) * pos.x + get(2, 2) * pos.y + get(2, 3));
		return new Vector(x, y);

	}

	public RoadGeometry multiply(RoadGeometry rm) {
		RoadGeometry result = new RoadGeometry(rm);
		result.resetPoints();
		for (int i = 0; i < rm.getPoints().size(); i++) {
			result.addPoint(multiply(rm.getPoints().get(i)));
		}
		return result;
	}

	public List<Vector> multiply(List<Vector> pts) {
		List<Vector> vec = new ArrayList<Vector>();
		for (int i = 0; i < pts.size(); i++) {
			vec.add(multiply(pts.get(i)));
		}
		return vec;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(matrix);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Matrix other = (Matrix) obj;
		if (!Arrays.deepEquals(matrix, other.matrix))
			return false;
		return true;
	}

	public Line multiply(Line line) {
		return new Line(multiply(line.getPolyLine()));
	}

	public double[][] get() {
		return matrix;
	}

	public AffineTransform getAffineTransform() {
		return new AffineTransform(matrix[0][0], matrix[1][0], matrix[0][1], matrix[1][1], matrix[0][2], matrix[1][2]);
	}

}

package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.util.HashMap;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControls;
import at.fhhagenberg.mc.util.StringUtil;

public abstract class LongitudinalControlConfigurationPage extends ModelConfigurationPage {

	protected Combo comboLongitudinalModel;
	protected Label lblModelWarning;
	protected Label lblLongitudinalModel;
	protected LongitudinalControls currentControl;

	protected LongitudinalControlConfigurationPage(String pageName) {
		super(pageName);
		setPageComplete(true);
		setDescription("Configure control parameters");
		setTitle("Longitudinal Control Configuration");
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		grpModelParameters.setVisible(false);

		lblLongitudinalModel = new Label(grpGeneral, SWT.NONE);
		lblLongitudinalModel.setText("Longitudinal model");

		comboLongitudinalModel = new Combo(grpGeneral, SWT.READ_ONLY);
		comboLongitudinalModel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		lblModelWarning = new Label(grpGeneral, SWT.NONE);
		lblModelWarning.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		lblModelWarning.setText("A longitudinal model is required.");
		lblModelWarning.setForeground(new Color(Display.getCurrent(), 255, 0, 0));
		lblModelWarning.setVisible(false);

		txtFullName.setEnabled(false);

		btnAppend.setText(
				"Overwrite existing control configuration. Otherwise the newly added controls will be appended to the configuration file.");
	}

	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {
		// Implement in sub classes if required
	}

	protected Class<? extends AbstractBean> getModelClass() {
		return LongitudinalControlBean.class;
	}

	protected boolean isStochasticAddPossible() {
		return true;
	}

	protected void validatePage() {
		StringBuilder sb = new StringBuilder();

		if (StringUtil.isNullOrEmpty(txtIdentifier.getText())) {
			sb.append(" Control identifier must not be empty.\n");
		} else {
			boolean isValidIdentifier = true;

			if (modelBeans != null) {
				for (AbstractBean bean : modelBeans) {
					if (bean instanceof LongitudinalControlBean) {
						if (((LongitudinalControlBean) bean).getIdentifier().toLowerCase()
								.compareTo(txtIdentifier.getText().toLowerCase()) == 0) {
							sb.append(" The given control identifier is invalid. A control with the same identifier exists already.\n");
							isValidIdentifier = false;
							break;
						}
					}
				}
			}

			if (isValidIdentifier && modelSet != null && !modelSet.isEmpty()) {
				for (AbstractBean bean : modelSet) {
					if (bean instanceof LongitudinalControlBean) {
						if (((LongitudinalControlBean) bean).getIdentifier().toLowerCase()
								.compareTo(txtIdentifier.getText().toLowerCase()) == 0) {
							sb.append(" The given control identifier is invalid. A control with the same identifier already exists.\n");
							isValidIdentifier = false;
							break;
						}
					}
				}
			}
		}

		btnAddStochastically.setEnabled(isAddPossible() && isStochasticAddPossible());

		if (sb.length() == 0) {
			setErrorMessage(null);
			btnAdd.setEnabled(isAddPossible());
		} else {
			setErrorMessage(sb.toString());
			btnAdd.setEnabled(false);
		}
	}
}

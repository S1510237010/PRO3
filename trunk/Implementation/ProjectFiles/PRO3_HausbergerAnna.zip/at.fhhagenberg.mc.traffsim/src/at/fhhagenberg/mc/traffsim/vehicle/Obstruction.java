package at.fhhagenberg.mc.traffsim.vehicle;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;

public class Obstruction extends Vehicle {

	private double offset;
	private double duration;
	private boolean isPermanent;
	private int laneId;
	private Vector absolutePosition;

	public Obstruction(double position, double offset, double duration, boolean isPermanent, int laneId) {
		super(position);
		setType(VehicleType.OBSTRUCTION);
		setLength(10);
		setLabel("Obstruction");
		this.offset = offset;
		this.duration = duration;
		this.laneId = laneId;
		this.isPermanent = isPermanent;
	}

	public double getOffset() {
		return offset;
	}

	public void setOffset(double offset) {
		this.offset = offset;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public boolean isPermanent() {
		return isPermanent;
	}

	public void setPermanent(boolean isPermanent) {
		this.isPermanent = isPermanent;
	}

	public int getLaneId() {
		return laneId;
	}

	public void setLaneId(int laneId) {
		this.laneId = laneId;
	}

	@Override
	public Vector getAbsolutePosition() {
		return absolutePosition;
	}

	public void setAbsolutePosition(Vector absolutePosition) {
		this.absolutePosition = absolutePosition;
	}
}

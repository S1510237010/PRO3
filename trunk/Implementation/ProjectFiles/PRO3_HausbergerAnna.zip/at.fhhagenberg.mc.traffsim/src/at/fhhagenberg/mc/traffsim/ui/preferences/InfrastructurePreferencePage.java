package at.fhhagenberg.mc.traffsim.ui.preferences;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class InfrastructurePreferencePage extends PreferencePage implements IWorkbenchPreferencePage {

	private Group grpTrafficLights;
	private Group grpLoopDetectors;
	private Button btnEnableLoopDetectors;
	private Spinner spinnerQueueMonitoringTimeHorizon;
	private Spinner spinnerDefaultSamplingInterval;
	private Spinner spinnerDefaultIntergreenTime;
	private Spinner spinnerDefaultGreenTime;
	private Spinner spinnerDefaultRedTime;
	private Spinner spinnerDefaultYellowTime;
	private Spinner spinnerDefaultRedYellowTime;
	private Spinner spinnerDefaultDelay;
	private Spinner spinnerDefaultPhaseLength;

	public InfrastructurePreferencePage() {
	}

	public InfrastructurePreferencePage(String title, ImageDescriptor image) {
		super(title, image);
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(1, false));

		grpLoopDetectors = new Group(container, SWT.NONE);
		grpLoopDetectors.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		grpLoopDetectors.setText("Loop Detectors");
		grpLoopDetectors.setLayout(new GridLayout(2, false));

		btnEnableLoopDetectors = new Button(grpLoopDetectors, SWT.CHECK);
		btnEnableLoopDetectors.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnEnableLoopDetectors.setText("Enable loop detectors");

		Label queueMonitoringLabel = new Label(grpLoopDetectors, SWT.NONE);
		queueMonitoringLabel.setText("Queue monitoring time horizon [s]");
		queueMonitoringLabel
				.setToolTipText("The time in seconds the loop detectors used for queue monitoring are place upstream an intersection approach");
		spinnerQueueMonitoringTimeHorizon = new Spinner(grpLoopDetectors, SWT.BORDER);
		spinnerQueueMonitoringTimeHorizon.setMinimum(1);
		spinnerQueueMonitoringTimeHorizon.setMaximum(100);

		Label queueMonitoringSamplingInterval = new Label(grpLoopDetectors, SWT.NONE);
		queueMonitoringSamplingInterval.setText("Sampling interval [s]");
		queueMonitoringSamplingInterval
				.setToolTipText("The interval in which the detector aggregates samples the recorded data (e.g. flow, mean speed)");
		spinnerDefaultSamplingInterval = new Spinner(grpLoopDetectors, SWT.BORDER);
		spinnerDefaultSamplingInterval.setMinimum(1);
		spinnerDefaultSamplingInterval.setMaximum(3600);

		grpTrafficLights = new Group(container, SWT.NONE);
		grpTrafficLights.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		grpTrafficLights.setText("Traffic Lights");
		grpTrafficLights.setLayout(new GridLayout(2, false));

		Label trafficLightGreenLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightGreenLabel.setText("Green time [s]");
		trafficLightGreenLabel.setToolTipText("Duration of the traffic light's green phase");
		spinnerDefaultGreenTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerDefaultGreenTime.setMaximum(120000);
		spinnerDefaultGreenTime.setDigits(3);
		spinnerDefaultGreenTime.setMinimum(5000);
		spinnerDefaultGreenTime.setPageIncrement(1000);

		Label trafficLightYellowLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightYellowLabel.setText("Yellow time [s]");
		trafficLightYellowLabel.setToolTipText("Duration of the traffic light's yellow phase");
		spinnerDefaultYellowTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerDefaultYellowTime.setDigits(3);
		spinnerDefaultYellowTime.setMaximum(10000);
		spinnerDefaultYellowTime.setMinimum(1000);
		spinnerDefaultYellowTime.setPageIncrement(1000);

		Label trafficLightRedLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightRedLabel.setText("Red time [s]");
		trafficLightRedLabel.setToolTipText("Duration of the traffic light's red phase");
		spinnerDefaultRedTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerDefaultRedTime.setDigits(3);
		spinnerDefaultRedTime.setMaximum(120000);
		spinnerDefaultRedTime.setMinimum(5000);
		spinnerDefaultRedTime.setPageIncrement(1000);

		Label trafficLightIntegreenLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightIntegreenLabel.setText("Intergreen time [s]");
		trafficLightIntegreenLabel.setToolTipText("Delay when traffic light switches from the red to red-yellow phase");
		spinnerDefaultIntergreenTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerDefaultIntergreenTime.setDigits(3);
		spinnerDefaultIntergreenTime.setMaximum(10000);
		spinnerDefaultIntergreenTime.setMinimum(1000);
		spinnerDefaultIntergreenTime.setPageIncrement(1000);

		Label trafficLightRedYellowLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightRedYellowLabel.setText("Red-yellow time [s]");
		trafficLightRedYellowLabel.setToolTipText("Duration of the traffic light's red-yellow phase");
		spinnerDefaultRedYellowTime = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerDefaultRedYellowTime.setDigits(3);
		spinnerDefaultRedYellowTime.setMaximum(10000);
		spinnerDefaultRedYellowTime.setMinimum(1000);
		spinnerDefaultRedYellowTime.setPageIncrement(1000);

		Label trafficLightDelayLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightDelayLabel.setText("Phase delay [s]");
		trafficLightDelayLabel.setToolTipText("Delay introduced before a traffic light changes its phase");
		spinnerDefaultDelay = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerDefaultDelay.setDigits(3);
		spinnerDefaultDelay.setMaximum(120000);
		spinnerDefaultDelay.setMinimum(0);
		spinnerDefaultDelay.setPageIncrement(1000);

		Label trafficLightPhaseLengthLabel = new Label(grpTrafficLights, SWT.NONE);
		trafficLightPhaseLengthLabel.setText("Phase length [s]");
		trafficLightPhaseLengthLabel.setToolTipText("Duration of the traffic light's green phase");
		spinnerDefaultPhaseLength = new Spinner(grpTrafficLights, SWT.BORDER);
		spinnerDefaultPhaseLength.setDigits(3);
		spinnerDefaultPhaseLength.setMaximum(120000);
		spinnerDefaultPhaseLength.setMinimum(5000);
		spinnerDefaultPhaseLength.setPageIncrement(1000);

		initializePreferences();
		return container;
	}

	@Override
	public void init(IWorkbench workbench) {

	}

	private void initializePreferences() {
		spinnerQueueMonitoringTimeHorizon.setSelection(PreferenceUtil.getInt(IPreferenceConstants.QUEUE_MONITORING_TIME_HORIZON_S));
		spinnerDefaultSamplingInterval.setSelection(PreferenceUtil.getInt(IPreferenceConstants.LOOP_DETECTOR_SAMPLE_INTERVAL));
		spinnerDefaultDelay.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_DELAY));
		spinnerDefaultIntergreenTime.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_INTERGREEN_TIME));
		spinnerDefaultYellowTime.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_YELLOW_TIME));
		spinnerDefaultRedYellowTime.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_RED_YELLOW_TIME));
		spinnerDefaultPhaseLength.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_PHASE_LENGTH));
		spinnerDefaultGreenTime.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_GREEN_TIME));
		spinnerDefaultRedTime.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_RED_TIME));
		btnEnableLoopDetectors.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.ENABLE_LOOP_DETECTORS));
	}

	@Override
	protected void performApply() {
		PreferenceUtil.setInt(IPreferenceConstants.QUEUE_MONITORING_TIME_HORIZON_S, spinnerQueueMonitoringTimeHorizon.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.LOOP_DETECTOR_SAMPLE_INTERVAL, spinnerDefaultSamplingInterval.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.TRAFFIC_LIGHT_DELAY, spinnerDefaultDelay.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.TRAFFIC_LIGHT_INTERGREEN_TIME, spinnerDefaultIntergreenTime.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.TRAFFIC_LIGHT_YELLOW_TIME, spinnerDefaultYellowTime.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.TRAFFIC_LIGHT_RED_YELLOW_TIME, spinnerDefaultRedYellowTime.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.TRAFFIC_LIGHT_PHASE_LENGTH, spinnerDefaultPhaseLength.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.TRAFFIC_LIGHT_GREEN_TIME, spinnerDefaultGreenTime.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.TRAFFIC_LIGHT_RED_TIME, spinnerDefaultRedTime.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.ENABLE_LOOP_DETECTORS, btnEnableLoopDetectors.getSelection());
	}

	@Override
	public boolean performOk() {
		performApply();
		return super.performOk();
	}
}
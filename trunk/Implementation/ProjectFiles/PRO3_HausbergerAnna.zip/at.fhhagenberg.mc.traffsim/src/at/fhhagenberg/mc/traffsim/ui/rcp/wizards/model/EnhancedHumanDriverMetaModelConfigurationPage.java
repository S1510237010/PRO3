package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.LongitudinalModelInputDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ExtendedHumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.RTDataBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControls;
import at.fhhagenberg.mc.util.StringUtil;

public class EnhancedHumanDriverMetaModelConfigurationPage extends LongitudinalControlConfigurationPage {

	private Button btnIsAnticipative;
	private Button btnIsReactive;
	private Combo comboDistanceNoise;
	private Combo comboDrivingErrors;
	private Combo comboVelocityDifferenceNoise;

	private Spinner spinnerDelayExpected;
	private Spinner spinnerDelayDriveAway;
	private Spinner spinnerDelayUnexpected;
	private Spinner spinnerNumAnticipatedVehicles;
	private Spinner spinnerSightDistance;
	private Spinner spinnerSpaceHeadway;
	private Spinner spinnerTimeHeadway;

	private LongitudinalControls currentControl;

	protected EnhancedHumanDriverMetaModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	protected void addModelToList() {
		ExtendedHumanDriverControlBean control = new ExtendedHumanDriverControlBean();
		control.setIdentifier(txtIdentifier.getText());
		control.setLongitudinalModelIdentifier(comboLongitudinalModel.getText());

		if (comboDistanceNoise.getSelectionIndex() > 0) {
			control.setDistanceNoiseIdentifier(comboDistanceNoise.getText());
		}

		if (comboDrivingErrors.getSelectionIndex() > 0) {
			control.setAccelerationNoiseIdentifier(comboDrivingErrors.getText());
		}

		if (comboVelocityDifferenceNoise.getSelectionIndex() > 0) {
			control.setVelocityDifferenceNoiseIdentifier(comboVelocityDifferenceNoise.getText());
		}

		control.setSpaceHeadwayThreshold(spinnerSpaceHeadway.getSelection() / Math.pow(10, spinnerSpaceHeadway.getDigits()));
		control.setNumConsideredVehicles(spinnerNumAnticipatedVehicles.getSelection());
		control.setSightDistance(spinnerSightDistance.getSelection());

		RTDataBean delays = new RTDataBean();
		delays.setIsReactive(btnIsReactive.getSelection());
		delays.setIsAnticipative(btnIsAnticipative.getSelection());

		delays.setExpected(spinnerDelayExpected.getSelection() * 10);
		delays.setUnexpected(spinnerDelayUnexpected.getSelection() * 10);
		delays.setDriveAway(spinnerDelayDriveAway.getSelection() * 10);
		delays.setTimeHeadway(spinnerTimeHeadway.getSelection() * 10);
		control.setResponseTimes(delays);

		modelSet.add(control);
	}

	@Override
	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((LongitudinalControlBean) element).getIdentifier() + "";
			}
		});

		TableViewerColumn colLongitudinalModel = createTableViewerColumn("Underlying longitudinal model", 210);
		colLongitudinalModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((LongitudinalControlBean) element).getLongitudinalModelIdentifier() + "";
			}
		});

		TableViewerColumn colSpaceHeadwayThreshold = createTableViewerColumn("Space headway threshold [m]", 180);
		colSpaceHeadwayThreshold.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getSpaceHeadwayThreshold() + "";
			}
		});

		TableViewerColumn colTimeHeadwayTreshold = createTableViewerColumn("Time headway threshold [s]", 160);
		colTimeHeadwayTreshold.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getResponseTimes().getTimeHeadway() / 1000.0 + "";
			}
		});

		TableViewerColumn colNumAnticipatedVehicles = createTableViewerColumn("Num. of anticipated vehicles", 180);
		colNumAnticipatedVehicles.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getNumConsideredVehicles() + "";
			}
		});

		TableViewerColumn colSightDistance = createTableViewerColumn("Max. sight distance [m]", 150);
		colSightDistance.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getSightDistance() + "";
			}
		});

		TableViewerColumn colDelayExpected = createTableViewerColumn("T' expected [s]", 130);
		colDelayExpected.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getResponseTimes().getExpected() / 1000.0 + "";
			}
		});

		TableViewerColumn colDelayUnexpected = createTableViewerColumn("T' unexpected [s]", 140);
		colDelayUnexpected.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getResponseTimes().getUnexpected() / 1000.0 + "";
			}
		});

		TableViewerColumn colDelayMovement = createTableViewerColumn("T' movement [s]", 140);
		colDelayMovement.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getResponseTimes().getDriveAway() / 1000.0 + "";
			}
		});

		TableViewerColumn colEnableDelays = createTableViewerColumn("Is reactive", 100);
		colEnableDelays.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getResponseTimes().getIsReactive() ? "\u2714" : "\u2718";
			}
		});

		TableViewerColumn colEnableTimelyAnticipation = createTableViewerColumn("Timely Anticipation", 120);
		colEnableTimelyAnticipation.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ExtendedHumanDriverControlBean) element).getResponseTimes().getIsAnticipative() ? "\u2714" : "\u2718";
			}
		});

		TableViewerColumn colEnableDrivingErrors = createTableViewerColumn("Driving error model", 100);
		colEnableDrivingErrors.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				String identifier = ((ExtendedHumanDriverControlBean) element).getAccelerationNoiseIdentifier();
				return StringUtil.isNotNullOrEmpty(identifier) ? identifier : "\u2718";
			}
		});

		TableViewerColumn colEnableEstimationErrorsV = createTableViewerColumn("Estimation error model [dv]", 130);
		colEnableEstimationErrorsV.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				String identifier = ((ExtendedHumanDriverControlBean) element).getVelocityDifferenceNoiseIdentifier();
				return StringUtil.isNotNullOrEmpty(identifier) ? identifier : "\u2718";
			}
		});

		TableViewerColumn colEnableEstimationErrorsS = createTableViewerColumn("Estimation error model [s]", 130);
		colEnableEstimationErrorsS.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				String identifier = ((ExtendedHumanDriverControlBean) element).getDistanceNoiseIdentifier();
				return StringUtil.isNotNullOrEmpty(identifier) ? identifier : "\u2718";
			}
		});
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		grpModelParameters.setVisible(true);

		Label lblSpaceHeadway = new Label(grpModelParameters, SWT.NONE);
		lblSpaceHeadway.setText("Space headway threshold [m]");
		lblSpaceHeadway
				.setToolTipText("Distance threshold to determine in which driving regime (free-flow, following) a particular vehicle currently is.");

		spinnerSpaceHeadway = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerSpaceHeadway.setPageIncrement(5);
		spinnerSpaceHeadway.setIncrement(1);
		spinnerSpaceHeadway.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerSpaceHeadway.setMaximum(100);
		spinnerSpaceHeadway.setMinimum(10);
		spinnerSpaceHeadway.setSelection(30);
		spinnerSpaceHeadway.setDigits(0);

		Label lblTimeHeadway = new Label(grpModelParameters, SWT.NONE);
		lblTimeHeadway.setText("Time headway threshold [s]");

		spinnerTimeHeadway = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerTimeHeadway.setPageIncrement(10);
		spinnerTimeHeadway.setIncrement(1);
		spinnerTimeHeadway.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerTimeHeadway.setMaximum(600);
		spinnerTimeHeadway.setMinimum(50);
		spinnerTimeHeadway.setSelection(317);
		spinnerTimeHeadway.setDigits(2);

		Label lblNumAntizipatedVehicles = new Label(grpModelParameters, SWT.NONE);
		lblNumAntizipatedVehicles.setText("Num. of anticipated vehicles");
		lblNumAntizipatedVehicles.setToolTipText("Number of preceding vehicles the driver considers during his driving task.");

		spinnerNumAnticipatedVehicles = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerNumAnticipatedVehicles.setPageIncrement(1);
		spinnerNumAnticipatedVehicles.setIncrement(1);
		spinnerNumAnticipatedVehicles.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerNumAnticipatedVehicles.setMaximum(7);
		spinnerNumAnticipatedVehicles.setMinimum(1);
		spinnerNumAnticipatedVehicles.setSelection(3);
		spinnerNumAnticipatedVehicles.setDigits(0);

		Label lblSightDistance = new Label(grpModelParameters, SWT.NONE);
		lblSightDistance.setText("Max. sight distance [m]");
		lblSightDistance.setToolTipText("Max. distance in front of vehicle to consider for spatial anticipation.");

		spinnerSightDistance = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerSightDistance.setPageIncrement(1);
		spinnerSightDistance.setIncrement(1);
		spinnerSightDistance.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerSightDistance.setMaximum(500);
		spinnerSightDistance.setMinimum(30);
		spinnerSightDistance.setSelection(200);
		spinnerSightDistance.setDigits(0);

		Label lblDelayExpected = new Label(grpModelParameters, SWT.NONE);
		lblDelayExpected.setText("T' expected [s]");
		lblDelayExpected.setToolTipText("Delay of driver actions in expected scenarios (car-following, approaching an intersection)");

		spinnerDelayExpected = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerDelayExpected.setPageIncrement(10);
		spinnerDelayExpected.setIncrement(1);
		spinnerDelayExpected.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerDelayExpected.setMaximum(400);
		spinnerDelayExpected.setMinimum(0);
		spinnerDelayExpected.setSelection(60);
		spinnerDelayExpected.setDigits(2);

		Label lblDelayUnexpected = new Label(grpModelParameters, SWT.NONE);
		lblDelayUnexpected.setText("T' unexpected [s]");
		lblDelayUnexpected.setToolTipText("Delay of driver actions in unexpected scenarios (free-flow traffic)");

		spinnerDelayUnexpected = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerDelayUnexpected.setPageIncrement(10);
		spinnerDelayUnexpected.setIncrement(1);
		spinnerDelayUnexpected.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerDelayUnexpected.setMaximum(400);
		spinnerDelayUnexpected.setMinimum(0);
		spinnerDelayUnexpected.setSelection(120);
		spinnerDelayUnexpected.setDigits(2);

		Label lblDelayMovement = new Label(grpModelParameters, SWT.NONE);
		lblDelayMovement.setText("T' movement [s]");
		lblDelayMovement.setToolTipText("Delay of driver actions when vehicle is in standstill");

		spinnerDelayDriveAway = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerDelayDriveAway.setPageIncrement(10);
		spinnerDelayDriveAway.setIncrement(1);
		spinnerDelayDriveAway.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerDelayDriveAway.setMaximum(400);
		spinnerDelayDriveAway.setMinimum(0);
		spinnerDelayDriveAway.setSelection(237);
		spinnerDelayDriveAway.setDigits(2);

		btnIsReactive = new Button(grpModelParameters, SWT.CHECK);
		btnIsReactive.setText("Consider reaction times");
		btnIsReactive.setLayoutData(new GridData(SWT.LEFT, SWT.BOTTOM, false, false, 2, 1));

		btnIsAnticipative = new Button(grpModelParameters, SWT.CHECK);
		btnIsAnticipative.setText("Consider timely anticipation");
		btnIsAnticipative.setLayoutData(new GridData(SWT.LEFT, SWT.BOTTOM, false, false, 2, 1));

		Label lblDrivingErrors = new Label(grpModelParameters, SWT.NONE);
		lblDrivingErrors.setText("Driving error noise model");
		lblDrivingErrors.setToolTipText("Defines the noise model used for modeling estimation errors with respect to accelerations");

		comboDrivingErrors = new Combo(grpModelParameters, SWT.READ_ONLY);
		comboDrivingErrors.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblDistanceNoise = new Label(grpModelParameters, SWT.NONE);
		lblDistanceNoise.setText("Distance estimation noise model");
		lblDistanceNoise.setToolTipText("Defines the noise model used for modeling estimation errors with respect to distances");

		comboDistanceNoise = new Combo(grpModelParameters, SWT.READ_ONLY);
		comboDistanceNoise.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblVelocityDifferenceNoise = new Label(grpModelParameters, SWT.NONE);
		lblVelocityDifferenceNoise.setText("Speed diff. estimation noise model");
		lblVelocityDifferenceNoise.setToolTipText("Defines the noise model used for modeling estimation errors with respect to speed differences");

		comboVelocityDifferenceNoise = new Combo(grpModelParameters, SWT.READ_ONLY);
		comboVelocityDifferenceNoise.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		// Model property initialization
		ModelProperty spaceHeadwayThreshold = new ModelProperty("Space headway threshold [m]", "setSpaceHeadwayThreshold", Double.TYPE, 10, 100);

		ModelProperty longitudinalModel = new ModelProperty("Underlying longitudinal model", "setLongitudinalModelIdentifier", String.class);
		longitudinalModel.setCanBeDistributed(false);
		ModelProperty distanceNoise = new ModelProperty("Distance noise", "setDistanceNoiseIdentifier", String.class);
		distanceNoise.setCanBeDistributed(false);
		ModelProperty velocityDifferenceNoise = new ModelProperty("Velocity difference noise", "setVelocityDifferenceNoiseIdentifier", String.class);
		velocityDifferenceNoise.setCanBeDistributed(false);
		ModelProperty accelerationNoise = new ModelProperty("Acceleration noise", "setAccelerationNoiseIdentifier", String.class);
		accelerationNoise.setCanBeDistributed(false);

		ModelProperty timeHeadwayThreshold = new ModelProperty("Time headway threshold [s]", "setTimeHeadway", Double.TYPE, 0.5, 6);
		timeHeadwayThreshold.setParentType(RTDataBean.class);
		timeHeadwayThreshold.setConversionFactor(1000);

		ModelProperty numAnticipatedVehicles = new ModelProperty("Num. of anticipated vehicles", "setNumConsideredVehicles", Integer.TYPE, 1, 10);
		ModelProperty sightDistance = new ModelProperty("Max. sight distance [m]", "setSightDistance", Double.TYPE, 30, 500);

		ModelProperty delayExpected = new ModelProperty("T' expected [s]", "setExpected", Double.TYPE, 0, 4);
		delayExpected.setParentType(RTDataBean.class);
		delayExpected.setConversionFactor(1000);

		ModelProperty delayUnexpected = new ModelProperty("T' unexpected [s]", "setUnexpected", Double.TYPE, 0, 4);
		delayUnexpected.setParentType(RTDataBean.class);
		delayUnexpected.setConversionFactor(1000);

		ModelProperty delayMovement = new ModelProperty("T' movement [s]", "setDriveAway", Double.TYPE, 0, 4);
		delayMovement.setParentType(RTDataBean.class);
		delayMovement.setConversionFactor(1000);

		modelProperties.add(spaceHeadwayThreshold);
		modelProperties.add(timeHeadwayThreshold);
		modelProperties.add(numAnticipatedVehicles);
		modelProperties.add(sightDistance);
		modelProperties.add(delayExpected);
		modelProperties.add(delayUnexpected);
		modelProperties.add(delayMovement);
		modelProperties.add(distanceNoise);
		modelProperties.add(velocityDifferenceNoise);
		modelProperties.add(accelerationNoise);
		modelProperties.add(longitudinalModel);

		controlMapping.put(spaceHeadwayThreshold, spinnerSpaceHeadway);
		controlMapping.put(timeHeadwayThreshold, spinnerTimeHeadway);
		controlMapping.put(numAnticipatedVehicles, spinnerNumAnticipatedVehicles);
		controlMapping.put(sightDistance, spinnerSightDistance);
		controlMapping.put(delayExpected, spinnerDelayExpected);
		controlMapping.put(delayUnexpected, spinnerDelayUnexpected);
		controlMapping.put(delayMovement, spinnerDelayDriveAway);
		controlMapping.put(distanceNoise, comboDistanceNoise);
		controlMapping.put(velocityDifferenceNoise, comboVelocityDifferenceNoise);
		controlMapping.put(accelerationNoise, comboDrivingErrors);
		controlMapping.put(longitudinalModel, comboLongitudinalModel);
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {
		try {
			Class<?> cls = ExtendedHumanDriverControlBean.class;
			Class<?> delaysCls = RTDataBean.class;

			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();
				Object delaysObj = delaysCls.newInstance();

				cls.getMethod("setIdentifier", String.class).invoke(obj, currentControl.getShortName() + "_gen_" + generationTime + "-" + (i + 1));

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Object currentObject = null;
					Class<?> currentClass = null;

					if (property.getParentType() == RTDataBean.class) {
						currentObject = delaysObj;
						currentClass = delaysCls;
					} else {
						currentObject = obj;
						currentClass = cls;
					}

					Method setter = currentClass.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);

						if (property.getType() == Integer.TYPE) {
							setter.invoke(currentObject, (int) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(currentObject, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(currentObject,
										(int) (spinner.getSelection() / Math.pow(10, spinner.getDigits()) * property.getConversionFactor()));
							} else {
								setter.invoke(currentObject,
										spinner.getSelection() / Math.pow(10, spinner.getDigits()) * property.getConversionFactor());
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(currentObject, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(currentObject, text.getText());
						} else if (control instanceof Combo) {
							Combo combo = (Combo) control;
							setter.invoke(currentObject, combo.getText());
						}
					}
				}

				// Set boolean properties manually
				delaysCls.getMethod("setIsReactive", Boolean.TYPE).invoke(delaysObj, btnIsReactive.getSelection());
				delaysCls.getMethod("setIsAnticipative", Boolean.TYPE).invoke(delaysObj, btnIsAnticipative.getSelection());

				// Set child beans
				cls.getMethod("setResponseTimes", RTDataBean.class).invoke(obj, delaysObj);
				modelSet.add((LongitudinalControlBean) obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void initializeModels() {
		try {
			comboLongitudinalModel.removeAll();
			comboDistanceNoise.removeAll();
			comboDrivingErrors.removeAll();
			comboVelocityDifferenceNoise.removeAll();

			DataSerializer ser = new DataSerializer();
			File configFile = ((ModelSelectionPage) ((ModelGeneratorWizard) getWizard()).getPage(ModelGeneratorWizard.PAGE_MODEL_SELECTION))
					.getConfigFile();
			ser.readConfiguration(configFile);

			List<? extends AbstractBean> beans = ser.readData(ModelBean.class);

			for (AbstractBean abstractBean : beans) {
				if (abstractBean instanceof NoiseDataBean) {
					comboDistanceNoise.add(((NoiseDataBean) abstractBean).getModelIdentifier());
					comboDrivingErrors.add(((NoiseDataBean) abstractBean).getModelIdentifier());
					comboVelocityDifferenceNoise.add(((NoiseDataBean) abstractBean).getModelIdentifier());
				} else if (abstractBean instanceof LongitudinalModelInputDataBean) {
					comboLongitudinalModel.add(((LongitudinalModelInputDataBean) abstractBean).getModelIdentifier());
				}
			}

			if (comboDistanceNoise.getItemCount() > 0) {
				comboDistanceNoise.add("NONE", 0);
				comboDrivingErrors.add("NONE", 0);
				comboVelocityDifferenceNoise.add("NONE", 0);

				comboDistanceNoise.setEnabled(true);
				comboDrivingErrors.setEnabled(true);
				comboVelocityDifferenceNoise.setEnabled(true);

				comboDistanceNoise.select(0);
				comboDrivingErrors.select(0);
				comboVelocityDifferenceNoise.select(0);
			} else {
				comboDistanceNoise.setEnabled(false);
				comboDrivingErrors.setEnabled(false);
				comboVelocityDifferenceNoise.setEnabled(false);
			}

			if (comboLongitudinalModel.getItemCount() > 0) {
				comboLongitudinalModel.setEnabled(true);
				comboLongitudinalModel.select(0);
				lblModelWarning.setVisible(false);
			} else {
				comboLongitudinalModel.setEnabled(false);
				lblModelWarning.setVisible(true);
			}

			validatePage();
		} catch (Exception exc) {
			setErrorMessage("Controls couldn't be loaded. Ensure that the configuration file is not corrupt.");
			comboDistanceNoise.setEnabled(false);
			comboDrivingErrors.setEnabled(false);
			comboVelocityDifferenceNoise.setEnabled(false);
			return;
		}
	}

	@Override
	protected boolean isAddPossible() {
		if (comboLongitudinalModel == null) {
			return false;
		}

		return comboLongitudinalModel.getItemCount() > 0;
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			initializeModels();
			currentControl = LongitudinalControls.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' control parameters", currentControl.toString()));
		}
	}
}

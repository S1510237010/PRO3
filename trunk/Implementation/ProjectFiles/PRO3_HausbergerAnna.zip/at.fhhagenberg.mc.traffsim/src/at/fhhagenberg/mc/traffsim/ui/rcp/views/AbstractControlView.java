package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

public abstract class AbstractControlView extends ViewPart {

	protected Button btnApply;

	protected void createButtonComposite(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		GridData gd_composite = new GridData(SWT.RIGHT, SWT.CENTER, false, false, ((GridLayout) parent.getLayout()).numColumns, 1);
		gd_composite.verticalIndent = 10;
		composite.setLayoutData(gd_composite);
		composite.setLayout(new RowLayout(SWT.HORIZONTAL));

		btnApply = new Button(composite, SWT.NONE);
		btnApply.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				applyChanges();
			}
		});
		btnApply.setLayoutData(new RowData(70, SWT.DEFAULT));
		btnApply.setText("Apply");
	}

	protected void enableButtons(boolean enable) {
		btnApply.setEnabled(enable);
	}

	protected abstract void applyChanges();

	protected abstract String getViewId();
}

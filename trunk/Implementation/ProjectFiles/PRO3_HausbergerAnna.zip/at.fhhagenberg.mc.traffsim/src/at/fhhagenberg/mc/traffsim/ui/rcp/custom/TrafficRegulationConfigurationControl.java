package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;

public abstract class TrafficRegulationConfigurationControl<T extends TrafficLightController<?>, F extends ControlLogic, X extends TrafficLightConfigurationParameters>
		extends Composite {

	protected Composite container;
	protected T selectedController;
	protected F selectedControlLogic;
	private GridData layoutData;

	public TrafficRegulationConfigurationControl(Composite parent, int style) {
		super(parent, style);
		setLayout(new GridLayout());
		container = new Composite(this, SWT.NONE);
		container.setLayout(new GridLayout(2, false));
		layoutData = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		container.setLayoutData(layoutData);
		intialize();
	}

	public void update(F selectedControlLogic, T selectedController) {
		this.selectedControlLogic = selectedControlLogic;
		this.selectedController = selectedController;
		updateControls();
	}

	public void show() {
		container.setVisible(true);
		layoutData.exclude = false;
		container.pack();
	}

	public void hide() {
		container.setVisible(false);
		layoutData.exclude = true;
		container.pack();
	}

	public abstract void activate(boolean activate);

	protected abstract void intialize();

	protected abstract void updateControls();

	public abstract X getConfigurationParameters();
}

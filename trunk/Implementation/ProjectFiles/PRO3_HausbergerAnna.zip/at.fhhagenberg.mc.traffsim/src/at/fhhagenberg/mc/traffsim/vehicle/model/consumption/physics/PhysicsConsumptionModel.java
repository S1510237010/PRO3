package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionCarDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.EngineDataBean;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConstants;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConsumptionModel;

/**
 * Physics-based fuel consumption model originally developed at the Technical University of Dresden. The model implements the functionality
 * defined in {@link FuelConsumptionModel} and calculates a vehicle's fuel consumption taking a number of car- and engine-related parameters
 * into consideration (see {@link CarModel}, {@link EngineModel}.
 *
 * @author Christian Backfrieder
 */
public class PhysicsConsumptionModel extends FuelConsumptionModel {

	/** Model containing various vehicle-specific parameters */
	private final CarModel carModel;

	/** Model containing various engine-related parameters */
	private final EngineModel engineModel;

	/**
	 * Constant required for fuel error calculation; 3-4 times the specific consumption
	 */
	private static final double LIMIT_SPEC_CONS = 900 * FuelConstants.CONVERSION_GRAMM_PER_KWH_TO_SI;

	/**
	 * Error constant denoting extremely high fuel flow in motor regimes that cannot be reached (10.000 kW)
	 */
	private static final double POW_ERROR = 1e7;

	/** Error constant denoting the fuel flow error */
	private static final double FUELFLOW_ERROR = POW_ERROR * LIMIT_SPEC_CONS;

	/** The model's unique identifier */
	private String identifier;

	/**
	 * Creates a new {@link PhysicsConsumptionModel} using the given parameters.
	 *
	 * @param modelIdentifier
	 *            the model's unique identifier
	 * @param carInput
	 *            a data entity containing relevant car-related parameters (see {@link CarModel})
	 * @param engineInput
	 *            a data entity containing relevant engine-related parameters (see {@link EngineModel})
	 */
	public PhysicsConsumptionModel(String modelIdentifier, ConsumptionCarDataBean carInput, EngineDataBean engineInput) {
		this.identifier = modelIdentifier;
		carModel = new CarModel(carInput);
		engineModel = new EngineModel(engineInput, carModel);
	}

	@Override
	public double fuelflowError() {
		return FUELFLOW_ERROR;
	}

	@Override
	public double getFuelFlow(double v, double acc, double angle, int gearIndex, boolean withJante) {

		final double fMot = engineModel.getEngineFrequency(v, gearIndex);

		// final double forceMech=getForceMech(v,acc); // can be <0
		final double powMech = v * carModel.getForceMech(v, acc, angle); // can
		// be
		// <0

		// electric generator is not active near or at in standstill
		// (v<1*3.6km/h)
		// resulting in idle fuel consumption from engine specification
		// modeling assumption becomes invalid if lot of standstills are
		// considered
		// electric consumption is active and no electric energy is provided by
		// generator
		final double elecPower = v < 1 ? 0 : carModel.getElectricPower();

		final double powMechEl = powMech + elecPower;// can be <0

		double fuelFlow = FUELFLOW_ERROR;

		if (engineModel.isFrequencyPossible(v, gearIndex) || gearIndex == 0) {
			fuelFlow = engineModel.getFuelFlow(fMot, powMechEl);
		}

		// check if motor regime can be reached; otherwise increase fuelFlow
		// prohibitively

		// indicates that too high power required
		if (powMech > engineModel.getMaxPower()) {
			fuelFlow = FUELFLOW_ERROR;
		}

		// indicates that too high motor frequency
		if (withJante && fMot > engineModel.getMaxFrequency()) {
			Logger.logDebug(
					String.format("v_kmh=%f, acc=%f, gear=%d, motor frequency=%d/min too high -- > return fuelErrorConsumption: %.2f",
							3.6 * v, acc, gearIndex + 1, (int) (fMot * 60), FUELFLOW_ERROR));
			fuelFlow = FUELFLOW_ERROR;
		}

		// indicates too low motor frequency
		if (withJante && fMot < engineModel.getMinFrequency()) {
			if (gearIndex == 0) {
				fuelFlow = carModel.getElectricPower() * LIMIT_SPEC_CONS;
				Logger.logDebug(String.format("v=%f, gear=%d, fuelFlow=%f %n", v, gearIndex + 1, fuelFlow));
			} else {
				fuelFlow = FUELFLOW_ERROR;
			}
		}

		return fuelFlow;

	}

	@Override
	public String getIdentifier() {
		return identifier;
	}

	@Override
	public double[] getMinFuelFlow(double v, double acc, double slope, boolean withJante) {
		int gear = 1;
		double fuelFlow = FUELFLOW_ERROR;

		for (int testGearIndex = engineModel.getMaxGearIndex(); testGearIndex >= 0; testGearIndex--) {
			final double fuelFlowGear = getFuelFlow(v, acc, slope, testGearIndex, withJante);

			if (fuelFlowGear < fuelFlow) {
				gear = testGearIndex + 1;
				fuelFlow = fuelFlowGear;
			}
		}

		final double[] retValue = { fuelFlow, gear };
		return retValue;
	}

	@Override
	public double getCO2EmissionsInKgPerS(double fuelFlow) {

		double conversionFactor = 0d;

		if (engineModel.getFuelType() == null) {
			conversionFactor = FuelConstants.LITERS_TO_CARBON_DIOXIDE_GASOLINE;
			return fuelFlow * conversionFactor;
		}

		switch (engineModel.getFuelType()) {
		case GASOLINE:
			conversionFactor = FuelConstants.LITERS_TO_CARBON_DIOXIDE_GASOLINE;
			break;
		case DIESEL:
			conversionFactor = FuelConstants.LITERS_TO_CARBON_DIOXIDE_DIESEL;
			break;
		case PETROLEUM_GAS:
			conversionFactor = FuelConstants.LITERS_TO_CARBON_DIOXIDE_PETROLEUM_GAS;
			break;
		case NATURAL_GAS:
			conversionFactor = FuelConstants.LITERS_TO_CARBON_DIOXIDE_NATURAL_GAS;
			break;
		}

		return fuelFlow * conversionFactor;
	}

	@Override
	public String getName() {
		return "TU Dresden Model";
	}
}
package at.fhhagenberg.mc.traffsim.communication.messaging;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;

public class InitialPayload extends MessagePayload {
	RoadSegment source, destination;

	public InitialPayload(RoadSegment source, RoadSegment destination) {
		super();
		this.source = source;
		this.destination = destination;
	}

	@Override
	public int getSize() {
		return Long.SIZE / 8 * 2;
	}

	public RoadSegment getSource() {
		return source;
	}

	public RoadSegment getDestination() {
		return destination;
	}

}

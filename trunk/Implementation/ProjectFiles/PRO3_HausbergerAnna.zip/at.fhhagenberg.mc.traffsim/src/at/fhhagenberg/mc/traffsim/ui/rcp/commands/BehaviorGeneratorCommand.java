package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.data.TraffsimDefaultData;
import at.fhhagenberg.mc.traffsim.data.beans.BehaviorBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.behaviors.BehaviorGenerationWizard;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class BehaviorGeneratorCommand implements IHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		BehaviorGenerationWizard behaviorWizard = new BehaviorGenerationWizard();
		WizardDialog dialog = new WizardDialog(Display.getCurrent().getActiveShell(), behaviorWizard);
		int result = dialog.open();

		if (result == Dialog.CANCEL) {
			return null;
		}

		if (behaviorWizard.getBehaviors() != null) {
			try {
				DataSerializer serializer = new DataSerializer();
				serializer.readConfiguration(behaviorWizard.getConfigFile());

				TraffSimConfiguration config = serializer.getConfiguration();

				if (!config.getBeanConfigurationsMapping().containsKey(BehaviorBean.class.getName())) {
					config.registerFilenameForClass(BehaviorBean.class, TraffsimDefaultData.BEHAVIORS_XML_NAME);
					serializer.setConfiguration(config);
					serializer.writeConfiguration(config.getConfigurationFile());
				}

				if (behaviorWizard.getBehaviors().isEmpty()) {
					serializer.clearData(BehaviorBean.class);
				} else {
					serializer.writeData(behaviorWizard.getBehaviors());
				}

				MessageDialog messageDialog = new MessageDialog(Display.getCurrent().getActiveShell(),
						"Behavior generation completed", null,
						"The behavior specification file has been updated successfully.", MessageDialog.INFORMATION,
						new String[] { "Ok" }, 0);
				messageDialog.open();
			} catch (Exception exc) {
				MessageDialog messageDialog = new MessageDialog(Display.getCurrent().getActiveShell(),
						"Behavior generation failed", null,
						"An error occurred while updating the behavior specification file.", MessageDialog.ERROR,
						new String[] { "Ok" }, 0);
				messageDialog.open();
				Logger.logError(
						"Something went wrong while serializing the generated behaviors.\n\n" + exc.getMessage());
			}
		}

		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// Not implemented
	}

	@Override
	public void dispose() {
		// Not implemented
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// Not implemented
	}
}
package at.fhhagenberg.mc.traffsim.util.ui;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;

/**
 * Utility class providing the funcionality to draw a star shape onto a Graphics2D object.
 *
 * @author Christian Backfrieder
 */
public class DrawUtil {

	/**
	 * Generates a path describing a star shape with the given number of sides, considering the provided jumpwith, position (x/y) and
	 * radius.
	 *
	 * @param sides
	 *            the path's number of sides of the star
	 * @param jumpWidth
	 *            the jump width between the separate sides
	 * @param x
	 *            the x-coordinate of the path's center location
	 * @param y
	 *            the y-coordinate of the path's center location
	 * @param r
	 *            the path's radius
	 * @return a list of vectors (@see Vector) describing the generated path
	 */
	private static List<Vector> createPath(int sides, int jumpWidth, double x, double y, double r) {
		double delta = 2 * Math.PI / sides;
		ArrayList<Vector> polygon = new ArrayList<Vector>();

		for (double idx = 0, angle = 0; idx < sides; idx++, angle += delta) {
			polygon.add(new Vector(Math.sin(angle) * r + x, Math.cos(angle) * r + y));
		}

		ArrayList<Vector> sorted = new ArrayList<>();
		int current = 0;

		while (sorted.size() != polygon.size()) {
			sorted.add(polygon.get(current % polygon.size()));
			current += jumpWidth;
		}

		return sorted;
	}

	/**
	 * Draws a star shape on a graphics object (@see Graphics2D) considering the provided parameters.
	 *
	 * @param g
	 *            the graphics object to be drawn on
	 * @param border
	 *            the star's border color
	 * @param fill
	 *            the star's fill color
	 * @param sides
	 *            the star's number of sides
	 * @param jumpWidth
	 *            the jump width between the separate sides
	 * @param x
	 *            the x-coordinate of the star's center location
	 * @param y
	 *            the <-coordinate of the star's center location
	 * @param r
	 *            the star's radius
	 */
	public static void drawStar(Graphics2D g, Color border, Color fill, int sides, int jumpWidth, double x, double y, double r) {
		List<Vector> outer = createPath(sides, jumpWidth, x, y, r);
		List<Vector> inner = createPath(sides, jumpWidth, x, y, r * 0.8);
		Color before = g.getColor();
		g.setColor(border);
		g.fill(AWTAdapter.toPolygon(outer));
		g.setColor(fill);
		g.fill(AWTAdapter.toPolygon(inner));
		g.setColor(before);
	}
}
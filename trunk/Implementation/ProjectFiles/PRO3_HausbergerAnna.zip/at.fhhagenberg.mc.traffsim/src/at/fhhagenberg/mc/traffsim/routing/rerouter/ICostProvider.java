package at.fhhagenberg.mc.traffsim.routing.rerouter;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;

/**
 * Interface for calculators of dynamic {@link RoadSegment} cost
 * 
 * @author Christian Backfrieder
 * 
 */
public interface ICostProvider {
	/**
	 * Determine the current cost for the given segment id
	 * 
	 * @param segmentId
	 *            the {@link RoadSegment} id (not routing id) for the segment to determine the cost
	 * @return the current footprint, or 0 if not available (can also be zero if available, but no vehicles crossing segment)
	 */
	public double getCost(long segmentId);

	/**
	 * Determine the sum of all cost, used for normalization of a single value
	 * 
	 * @return the current sum of all cost in the {@link RoadNetwork}
	 */
	public double getCurrentCostSum();

	/**
	 * 
	 * @param segmentId
	 * @return normalized cost value for defined {@link RoadSegment}, from 0 to 1, where 1 means the maximum cost sum of the whole network (
	 *         {@link #getCurrentCostSum()})
	 */
	public double getNormalizedCost(long segmentId);

	/**
	 * @return the weight of the provider, from 0 to 100
	 */
	public int getWeight();
}

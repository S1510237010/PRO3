package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;

import com.google.common.collect.Maps;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.PriorityState;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * Entity representing an ordinary traffic light. Provides the possibility to switch between the following states in order to grant or
 * refuse access to signalized intersections: off, green, red, yellow, red-yellow. A traffic light operates all junction connectors leaving
 * from the associated target lane.
 *
 * @author Manuel Lindorfer
 *
 */
public class TrafficLight {
	public static long NEXT_ID = 0;

	public enum TrafficLightState {
		GREEN("GREEN", PriorityState.TRAFFIC_LIGHTS_GREEN), //
		OFF("OFF", PriorityState.TRAFFIC_LIGHTS_OOO), //
		RED("RED", PriorityState.TRAFFIC_LIGHTS_RED), //
		RED_YELLOW("RED_YELLOW", PriorityState.TRAFFIC_LIGHTS_RED_YELLOW), //
		YELLOW("YELLOW", PriorityState.TRAFFIC_LIGHTS_YELLOW);
		private static final Map<String, TrafficLightState> map = Maps.newHashMap();

		static {
			for (TrafficLightState state : TrafficLightState.values()) {
				map.put(state.name, state);
			}
		}

		public static TrafficLightState fromString(String name) {
			if (StringUtil.isNullOrEmpty(name) || !map.containsKey(name)) {
				return null;
			}

			return map.get(name);
		}

		private String name;
		private int priority;

		private TrafficLightState(String name, int priority) {
			this.name = name;
			this.priority = priority;
		}

		public int getPriority() {
			return priority;
		}

		@Override
		public String toString() {
			return name;
		}
	};

	private long id;
	private boolean isOperating;
	private boolean isServiced;
	private TrafficLightState currentState;

	private double serviceLength;

	private long timeIntergreen;
	private long timeYellow;
	private long timeRedYellow;

	private List<Long> connectorIds;

	protected final DelayQueue<DelayedTask> scheduledTasks = new DelayQueue<>();

	/**
	 * Creates a new traffic light with the given identifier which operates the given set of connectors.
	 *
	 * @param id
	 *            the traffic light's unique identifier
	 * @param connectorIds
	 *            the unique identifiers of the connectors being operated
	 */
	public TrafficLight(long id, List<Long> connectorIds) {
		this.id = id;
		this.connectorIds = connectorIds;
		isOperating = true;
		currentState = TrafficLightState.RED;
		timeIntergreen = PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_INTERGREEN_TIME);
		timeYellow = PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_YELLOW_TIME);
		timeRedYellow = PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_RED_YELLOW_TIME);
	}

	/**
	 * Gets the traffic light's unique identifier.
	 *
	 * @return unique identifier
	 */
	public long getId() {
		return id;
	}

	/**
	 * Get's the list of identifiers of the junction connectors operated by this traffic light.
	 *
	 * @return a list of unique identifiers
	 */
	public List<Long> getJunctionConnectorIds() {
		return connectorIds;
	}

	/**
	 * Get's the current traffic light state.
	 *
	 * @return the traffic light's curret state
	 */
	public TrafficLightState getCurrentState() {
		return currentState;
	}

	/**
	 * Changes the traffic light's state to the given target state.
	 *
	 * @param newState
	 *            the traffic light's new state
	 */
	public void changeState(TrafficLightState newState) {
		currentState = newState;
	}

	/**
	 * Get's the traffic light's intergreen time, i.e. the timespan until the traffic light switches from the red to the red-yellow state.
	 *
	 * @return timespan in milliseconds
	 */
	public long getTimeIntergreen() {
		return timeIntergreen;
	}

	/**
	 * Set's the traffic light's intergreen time.
	 *
	 * @param timeIntergreen
	 *            timespan in milliseconds
	 */
	public void setTimeIntergreen(long timeIntergreen) {
		this.timeIntergreen = timeIntergreen;
	}

	/**
	 * Get's the traffic light's yellow time, i.e. the duration of the yellow phase.
	 *
	 * @return timespan in milliseconds
	 */
	public long getTimeYellow() {
		return timeYellow;
	}

	/**
	 * Set's the traffic light's yellow time.
	 *
	 * @param timeYellow
	 *            timespan in milliseconds
	 */
	public void setTimeYellow(long timeYellow) {
		this.timeYellow = timeYellow;
	}

	/**
	 * Get's the traffic light's red-yellow time, i.e. the duration of the red-yellow phase.
	 *
	 * @return timespan in milliseconds
	 */
	public long getTimeRedYellow() {
		return timeRedYellow;
	}

	/**
	 * Set's the traffic light's red-yellow time.
	 *
	 * @param timeRedYellow
	 *            timespan in milliseconds
	 */
	public void setTimeRedYellow(long timeRedYellow) {
		this.timeRedYellow = timeRedYellow;
	}

	/**
	 * Determines whether the traffic light is currently serviced, i.e. it's in the green state or transitioning to the very same.
	 *
	 * @return true if the traffic light is currently serviced, false else
	 */
	public boolean isServiced() {
		return isServiced;
	}

	/**
	 * Set's the traffic light's service state to the provided value.
	 *
	 * @param isServiced
	 *            true if the service light is serviced, false else
	 */
	public void setServiced(boolean isServiced) {
		if (!isServiced) {
			serviceLength = 0;
		}

		this.isServiced = isServiced;
	}

	/**
	 * Determines whether the traffic light is currently operated or not (state: off).
	 *
	 * @return true if the traffic light is operated, false else
	 */
	public boolean isOperating() {
		return isOperating;
	}

	/**
	 * Set's the traffic light's operating mode to the provided value.
	 *
	 * @param isOperating
	 *            true if the traffic light is operated, false else
	 */
	public void setOperating(boolean isOperating) {
		if (!isOperating) {
			setServiced(false);
			currentState = TrafficLightState.OFF;
		}

		this.isOperating = isOperating;
	}

	/**
	 * Get's the duration of the current service interval, i.e. timespan since traffic light switched to serviced mode.
	 *
	 * @return service length in seconds
	 */
	public double getServiceLength() {
		return serviceLength;
	}

	/**
	 * Converts the traffic light to the corresponding data entity.
	 *
	 * @return a serializable traffic light entity
	 */
	public TrafficLightBean toBean() {
		TrafficLightBean bean = new TrafficLightBean();
		bean.id = id;
		bean.setConnectors(connectorIds);
		bean.setTimeIntergreen(timeIntergreen);
		bean.setTimeYellow(timeYellow);
		bean.setTimeRedYellow(timeRedYellow);
		return bean;
	}

	/**
	 * Initiates the traffic light to switch either to the green or the red phase after the given delay has elapsed.
	 *
	 * @param toGreen
	 *            true if traffic light should switch to green, false else
	 * @param delay
	 *            delay in milliseconds before the phase switch is initiated
	 */
	public void toggleService(boolean toGreen, long delay) {
		scheduledTasks.add(new DelayedTask(delay, TimeUnit.MILLISECONDS) {
			final boolean var = toGreen;

			@Override
			public void run() {
				toggleService(var);
			}
		});
	}

	/**
	 * Performs all steps necessary to transition a traffic light either from the red to the green state or the other way round. This
	 * comprises transitions to the red-yellow and the yellow state using the traffic light's integreen, yellow and red-yellow times.
	 *
	 * @param toGreen
	 *            true if traffic light should switch to green, false else
	 */
	private void toggleService(boolean toGreen) {
		if (!isOperating) {
			return;
		}
		if (toGreen == isServiced) {
			return;
		}

		// Start service
		if (toGreen) {
			// Transition to red yellow and green
			setServiced(true);

			scheduledTasks.add(new DelayedTask(timeIntergreen, TimeUnit.MILLISECONDS) {
				@Override
				public void run() {
					changeState(TrafficLightState.RED_YELLOW);
				}
			});

			scheduledTasks.add(new DelayedTask(timeIntergreen + timeRedYellow, TimeUnit.MILLISECONDS) {
				@Override
				public void run() {
					changeState(TrafficLightState.GREEN);
				}
			});
		} else {
			// Stop Service
			setServiced(false);

			// Transition from green to yellow
			if (currentState.equals(TrafficLightState.GREEN)) {
				changeState(TrafficLightState.YELLOW);
				scheduledTasks.clear();

				// Transition from yellow to red
				scheduledTasks.add(new DelayedTask(timeYellow, TimeUnit.MILLISECONDS) {

					@Override
					public void run() {
						changeState(TrafficLightState.RED);
					}
				});
			} else {
				changeState(TrafficLightState.RED);
				scheduledTasks.clear();
				setServiced(false);
			}
		}
	}

	/**
	 * Updates the traffic light in the configured simulation update interval. Verifies whether any of the scheduled tasks (e.g. phase
	 * switches) have to be executed or not.
	 *
	 * @param dt
	 *            the update interval in seconds
	 * @param time
	 *            the absolute simulation time
	 * @param runTime
	 *            the simulation runtime in seconds
	 */
	public void update(double dt, Date time, double runTime) {

		long delayMillis = Math.round(dt * 1000);

		for (final DelayedTask task : scheduledTasks) {
			task.updateDelay(delayMillis);
		}

		if (isServiced) {
			serviceLength += dt;
		}

		DelayedTask task;

		while ((task = scheduledTasks.poll()) != null) {
			task.run();
		}
	}

	@Override
	public String toString() {
		return "" + id;
	}
}

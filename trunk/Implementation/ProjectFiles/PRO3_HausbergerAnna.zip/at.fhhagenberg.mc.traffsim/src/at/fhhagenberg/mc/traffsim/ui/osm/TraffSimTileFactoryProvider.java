package at.fhhagenberg.mc.traffsim.ui.osm;

import java.util.HashMap;
import java.util.Map;

import org.jdesktop.swingx.VirtualEarthTileFactoryInfo;
import org.jdesktop.swingx.mapviewer.DefaultTileFactory;
import org.jdesktop.swingx.mapviewer.TileFactoryInfo;

/**
 * This class makes it possible to display MapQuest-tiles in JXMapKit. Simply use jxMapKit.setTileFactory(new MapQuestTileFactory());
 * 
 * Please visit http://developer.mapquest.com/web/products/open/map for more information about the license under which this tiles are released.
 * 
 * @author twalcari
 * 
 */
public class TraffSimTileFactoryProvider {

	private static final int MAX_ZOOM = 19;
	private static final int THREAD_POOL_SIZE = 8;

	private static final Map<TileType, TileFactoryInfo> infos = new HashMap<>();

	private static final TileFactoryInfo osmDeInfo = new TileFactoryInfo(0, MAX_ZOOM - 2, MAX_ZOOM, 256, true, true,
	// "http://oatile1.mqcdn.com/tiles/1.0.0/sat", //aerial tiles
	// "http://tile.openstreetmap.de/tiles/osmde", // Mapquest OSM
	// "http://otile1.mqcdn.com/tiles/1.0.0/sat", // no labels
	// "http://a.www.toolserver.org/tiles/osm-labels-de", // labels
			"http://a.tile.openstreetmap.org", "x", "y", "z") {
		public String getTileUrl(int x, int y, int zoom) {
			zoom = MAX_ZOOM - zoom;
			String url = this.baseURL + "/" + zoom + "/" + x + "/" + y + ".png";
			return url;
		}
	};
	private static final TileFactoryInfo stamenInfo = new TileFactoryInfo(0, MAX_ZOOM - 2, MAX_ZOOM, 256, true, true,
			"http://a.tile.stamen.com/toner", // Mapquest OSM
			"x", "y", "z") {
		public String getTileUrl(int x, int y, int zoom) {
			zoom = MAX_ZOOM - zoom;
			String url = this.baseURL + "/" + zoom + "/" + x + "/" + y + ".png";
			return url;
		}
	};

	public TraffSimTileFactoryProvider() {
	}

	public static DefaultTileFactory getTileFactory(TileType type) {
		if (infos.isEmpty()) {
			infos.put(TileType.BING_HYBRID, new CustomVirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.HYBRID));
			infos.put(TileType.BING_MAP, new CustomVirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.MAP));
			infos.put(TileType.BING_SAT, new CustomVirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.SATELLITE));
			infos.put(TileType.OSMDE, osmDeInfo);
			infos.put(TileType.STAMEN_BLACKWHITE, stamenInfo);
		}
		DefaultTileFactory tileFact = new DefaultTileFactory(infos.get(type));
		tileFact.setThreadPoolSize(THREAD_POOL_SIZE);
		return tileFact;
	}

}
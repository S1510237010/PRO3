package at.fhhagenberg.mc.traffsim.vehicle.model;

public enum LongitudinalModels {

	ACC("Adaptive Cruise Control", "ACC"), GIPPS("Gipps", "GIPPS"), IDM("Intelligent Driver Model",
			"IDM"), IIDM("Improved Intelligent Driver Model", "IIDM"), KRAUSS("Krauss", "KRAUSS"), OVM("Optimal Velocity", "OVM");

	public static LongitudinalModels valueOfLabel(String label) {
		for (LongitudinalModels t : LongitudinalModels.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}

		return null;
	}

	private String shortName;

	private String type;

	private LongitudinalModels(final String type, final String shortName) {
		this.type = type;
		this.shortName = shortName;
	}

	public String getShortName() {
		return shortName;
	}

	@Override
	public String toString() {
		return type;
	}
}

package at.fhhagenberg.mc.traffsim.ui;

import java.awt.Color;
import java.awt.Shape;
import java.awt.Stroke;

public class DrawableArtifact {
	private Color lineColor, fillColor;
	private Shape shape;
	/** transparency in the range [0.0 1.0], where 0.0 means fully transparent, 1.0 fully opaque */
	private float alpha;

	public DrawableArtifact(Shape shape, Color lineColor, Color fillColor, Stroke stroke) {
		this(shape, lineColor, fillColor, stroke, 1);
	}

	public DrawableArtifact(Shape shape, Color lineColor, Color fillColor, Stroke stroke, float alpha) {
		super();
		this.shape = shape;
		this.lineColor = lineColor;
		this.fillColor = fillColor;
		this.stroke = stroke;
		this.alpha = alpha;
	}

	public Color getLineColor() {
		return lineColor;
	}

	public void setLineColor(Color lineColor) {
		this.lineColor = lineColor;
	}

	public Color getFillColor() {
		return fillColor;
	}

	public void setFillColor(Color fillColor) {
		this.fillColor = fillColor;
	}

	public Stroke getStroke() {
		return stroke;
	}

	public void setStroke(Stroke stroke) {
		this.stroke = stroke;
	}

	private Stroke stroke;

	public Shape getShape() {
		return shape;
	}

	public void setShape(Shape shape) {
		this.shape = shape;
	}

	public float getAlpha() {
		return alpha;
	}

	public void setAlpha(float alpha) {
		this.alpha = alpha;
	}

}

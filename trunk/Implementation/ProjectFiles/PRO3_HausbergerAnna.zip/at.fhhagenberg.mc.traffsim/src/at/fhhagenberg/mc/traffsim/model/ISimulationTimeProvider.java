package at.fhhagenberg.mc.traffsim.model;

import java.util.Date;

public interface ISimulationTimeProvider {

	Date getCurrentSimTime();

}
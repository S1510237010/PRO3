package at.fhhagenberg.mc.traffsim.roadnetwork.detector;

public class DetectorDataSample {

	/** Index of the target lane, starting from 0 **/
	private int laneIndex;

	/** Time ellapsed since simulation start in seconds **/
	private double time;

	/** Traffic flow in vehicles per hour **/
	private double flow;

	/** Traffic density in vehicles per kilometer **/
	private double density;

	/** Mean speed in km/h **/
	private double speed;

	/** Detector occupancy in percent of the sampling interval **/
	private double occupancy;

	public DetectorDataSample() {
		this.occupancy = 0;
		this.laneIndex = 0;
		this.time = 0;
		this.flow = 0;
		this.density = 0;
		this.speed = 0;
	}

	public DetectorDataSample(int laneIndex, double time, double occupancy, double flow,
			double density, double speed) {
		this.laneIndex = laneIndex;
		this.time = time;
		this.occupancy = occupancy;
		this.flow = flow;
		this.density = density;
		this.speed = speed;
	}

	public int getLaneIndex() {
		return laneIndex;
	}

	public void setLaneIndex(int laneIndex) {
		this.laneIndex = laneIndex;
	}

	public double getOccupancy() {
		return occupancy;
	}

	public void setOccupancy(double occupancy) {
		this.occupancy = occupancy;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}

	public double getFlow() {
		return flow;
	}

	public void setFlow(double flow) {
		this.flow = flow;
	}

	public double getDensity() {
		return density;
	}

	public void setDensity(double density) {
		this.density = density;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}
}

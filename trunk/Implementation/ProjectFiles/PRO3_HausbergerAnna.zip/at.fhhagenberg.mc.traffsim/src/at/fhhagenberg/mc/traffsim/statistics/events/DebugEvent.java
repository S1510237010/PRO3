package at.fhhagenberg.mc.traffsim.statistics.events;

import java.util.Date;

public class DebugEvent extends Event {

	private static final long serialVersionUID = -2639929963461136590L;
	private static long NEXT_DEBUG_ID = 0;

	private String variableName;
	private double variableValue;

	/**
	 * For serialization reasons
	 */
	public DebugEvent() {

	}

	public DebugEvent(String modelId, Date currentSimTime, EventType type, String typeInfo, String message, String varName, double varValue) {
		super(modelId, currentSimTime, type, typeInfo, message, false);

		this.id = NEXT_DEBUG_ID++;
		this.variableName = varName;
		this.variableValue = varValue;
	}

	public String getVariableName() {
		return variableName;
	}

	public double getVariableValue() {
		return variableValue;
	}

	@Override
	public String getInfoAsString() {
		if (fullStringRepresentation == null) {
			fullStringRepresentation = id + " " + EventType.getAbbreviation(type) + " " + timestamp + " " + details + " " + variableName;
		}
		return fullStringRepresentation;
	}
}

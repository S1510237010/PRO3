package at.fhhagenberg.mc.traffsim.routing;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.Node;
import at.fhhagenberg.mc.traffsim.routing.osm2po.Osm2poLogWrapper;
import at.fhhagenberg.mc.traffsim.routing.rerouter.AbstractCostEvaluator;
import at.fhhagenberg.mc.util.types.IDisposable;
import de.cm.osm2po.logging.Log;
import de.cm.osm2po.routing.Graph;
import de.cm.osm2po.routing.GraphCostsOverrider;
import de.cm.osm2po.routing.MlgRouter;

/**
 * Thic class is used to create route with the osm2po library
 */
public abstract class AbstractRouteService implements IDisposable {
	File graphFile;
	protected OverrideableGraph graph;
	/** dynamic second graph, which can be used to temporarily override things, usually for a single calculation */
	OverrideableGraph dynamicGraph;

	Properties params;
	private GraphCostsOverrider gcoH;
	private GraphCostsOverrider gcoKm;
	private TransientGraphCostsOverrider dynamicTempOverrider;
	protected Set<Long> removedRoutingIds;
	private Map<Long, Double> unfilteredTimeCostMap = new ConcurrentHashMap<>();
	private Map<Long, Double> filteredNormalizedTimeCostMap = new ConcurrentHashMap<>();
	private Map<Long, Double> additionalNormalizedCostMap = new ConcurrentHashMap<>();
	private Map<Long, Double> totalNormalizedCostMap = new ConcurrentHashMap<>();
	protected Log osm2poLog;

	/**
	 * Creates a new RouteServer with the specified graph file
	 *
	 * @param graphFile
	 *            path to the graph file
	 *
	 * @param removedRoutingIds
	 *
	 */
	public AbstractRouteService(File graphFile, Set<Long> removedRoutingIds) {
		Logger.logDebug("Loading graph...");
		this.graphFile = graphFile;
		graph = new OverrideableGraph(graphFile);
		Logger.logDebug("Graph loaded.");
		osm2poLog = new Log();
		osm2poLog.addLogWriter(new Osm2poLogWrapper());
		gcoH = new GraphCostsOverrider(graph, true, osm2poLog);
		gcoKm = new GraphCostsOverrider(graph, false, osm2poLog);
		graph.setHOverrider(gcoH);
		graph.setKmOverrider(gcoKm);
		params = new Properties();
		params.setProperty("findShortestPath", "false");
		params.setProperty("ignoreRestrictions", "false");
		params.setProperty("ignoreOneWays", "false");
		params.setProperty("heuristicFactor", "1.0");
		this.removedRoutingIds = removedRoutingIds;
	}

	/**
	 * Resets the cost of the maintained dynamic graph to the currently valid values, which are provided by the
	 * {@link AbstractCostEvaluator}. Changes to the dynamic graph by calls to {@link #overrideDynamicSegmentHCost(long, float, boolean)},
	 * which influence this second graph temporarily, are reset to the currently valid weighted graph.
	 *
	 * @deprecated unused
	 */
	@Deprecated
	protected void resetDynamicGraph() {
		if (dynamicGraph == null) {
			dynamicGraph = new OverrideableGraph(graphFile);
			dynamicTempOverrider = new TransientGraphCostsOverrider(dynamicGraph, true, osm2poLog);
			dynamicGraph.setHOverrider(dynamicTempOverrider);
		}
		dynamicTempOverrider.resetToCosts(gcoH.getCurrentCosts());
	}

	/**
	 * Temporarily override cost in the dynamic transient graph, which is not used for normal route calculations, but only for a short
	 * period of time. The override is valid until the next call of {@link #resetDynamicGraph()} is called. <br>
	 * <br>
	 * Important: Parallel execution is <b>NOT</b> recommended, since there is only one dynamic grpah which is overrided. All instances
	 * using this one dynamic graph instance use the very same object!
	 *
	 * @param routingId
	 * @param costH
	 * @param reverse
	 */
	public void overrideDynamicSegmentHCost(long routingId, float costH, boolean reverse) {
		try {
			dynamicTempOverrider.overrideCost((int) routingId, costH, reverse);
		} catch (ArrayIndexOutOfBoundsException ex) {
			Logger.logWarn("Could not find segment " + routingId + " in dynamic routing graph");
		}
	}

	public void removedRoutingIdsChanged(Set<Long> removedRoutingIds) {
		this.removedRoutingIds = removedRoutingIds;
	}

	/**
	 * Override the total (time or normalized common) cost of the given segment
	 *
	 * @param routingId
	 * @param costH
	 *            the cost (hours or any other coefficient representing cost)
	 * @param reverse
	 */
	public void overrideSegmentHCost(long routingId, float costH, boolean reverse) {
		try {
			gcoH.overrideCost((int) routingId, costH, reverse);
			totalNormalizedCostMap.put(getKey(routingId, reverse), (double) costH);
		} catch (ArrayIndexOutOfBoundsException ex) {
			Logger.logWarn("Could not find segment " + routingId + " in routing graph");
		}
	}

	/**
	 * Override the distance cost of the given segment
	 *
	 * @param segmentId
	 * @param costKm
	 *            in km
	 * @param reverse
	 */
	public void overrideSegmentKmCost(int segmentId, float costKm, boolean reverse) {
		gcoKm.overrideCost(segmentId, costKm, reverse);
	}

	/**
	 * Gets the osm id of point with float coordinates
	 *
	 * @param lat
	 *            latitude coordinate
	 * @param lon
	 *            longitude coordinate
	 * @return the id of the point
	 */
	public int getId(float lat, float lon) {
		return graph.findClosestVertexId(lat, lon);
	}

	/**
	 * Gets the osm id of point with double coordinates
	 *
	 * @param lat
	 *            latitude coordinate
	 * @param lon
	 *            longitude coordinate
	 * @return the id of the point
	 */
	public int getId(double lat, double lon) {
		return graph.findClosestVertexId((float) lat, (float) lon);
	}

	/**
	 * Creates a route between the start and end point. Fast method which only returns routing ids and total time cost
	 *
	 * @param sourceNode
	 *            osm2po node id of the start point
	 * @param targetNode
	 *            osm2po node id id of the end point
	 * @return a list of osm segment ids (traffsim routing ids)
	 */
	public abstract SimpleRouteResult findRoute(Node sourceNode, Node targetNode);

	public float getKmCosts(long routingId, boolean reverse) {
		try {
			return graph.getKmCostsForSegment(routingId, reverse);
		} catch (ArrayIndexOutOfBoundsException e) {
			Logger.logWarn("Cannot find km costs for " + routingId);
		}
		return Float.MAX_VALUE;
	}

	public float getHCosts(long routingId, boolean reverse) {
		return graph.getHCostsForSegment(routingId, reverse);
	}

	/**
	 * Closes the handle to the grpah file
	 */
	@Override
	public void dispose() {
		unfilteredTimeCostMap.clear();
		additionalNormalizedCostMap.clear();
		filteredNormalizedTimeCostMap.clear();
		totalNormalizedCostMap.clear();
		if (dynamicGraph != null)
			dynamicGraph.close();
		if (dynamicTempOverrider != null)
			dynamicTempOverrider.close();
		gcoH.close();
		gcoKm.close();
		graph.close();
	}

	public void setSegmentUnfilteredHCost(long routingId, double cost, boolean osmReverse) {
		unfilteredTimeCostMap.put(getKey(routingId, osmReverse), cost);
	}

	public void setSegmentNormalizedAdditionalCost(long routingId, double cost, boolean osmReverse) {
		additionalNormalizedCostMap.put(getKey(routingId, osmReverse), cost);
	}

	/**
	 * Returns only average of all vehicle's speed, without filtering, do not use for routing calculations.
	 *
	 * @param routingId
	 * @param reverse
	 * @return the current time cost for segment, without applied filters, or zero if not exists yet
	 */
	public double getSegmentUnfilteredHCost(long routingId, boolean reverse) {
		long key = getKey(routingId, reverse);
		return unfilteredTimeCostMap.containsKey(key) ? unfilteredTimeCostMap.get(key) : getHCosts(routingId, reverse);
	}

	public double getSegmentNormalizedTotalCost(long routingId, boolean reverse) {
		long key = getKey(routingId, reverse);
		return totalNormalizedCostMap.containsKey(key) ? totalNormalizedCostMap.get(key) : 0;
	}

	public double getSegmentAdditionalNormalizedCost(long routingId, boolean reverse) {
		long key = getKey(routingId, reverse);
		return additionalNormalizedCostMap.containsKey(key) ? additionalNormalizedCostMap.get(key) : 0;
	}

	private long getKey(long routingId, boolean osmReverse) {
		return osmReverse ? (-1) * routingId : routingId;
	}

	public void setSegmentNormalizedFilteredHCost(int routingId, double cost, boolean reverse) {
		filteredNormalizedTimeCostMap.put(getKey(routingId, reverse), cost);
	}

	public double getSegmentFilteredNormalizedCost(long routingId, boolean reverse) {
		long key = getKey(routingId, reverse);
		if (!filteredNormalizedTimeCostMap.containsKey(key)) {
			return getSegmentUnfilteredHCost(routingId, reverse);
		}
		return filteredNormalizedTimeCostMap.get(getKey(routingId, reverse));
	}

	public void resetGraphHCost() {
		gcoH.resetToOriginalCosts();
		totalNormalizedCostMap = new HashMap<>();
	}

	/**
	 * Find a single route from source to destination by using simple A* algorithm and the currently valid routing graph (including all
	 * overridden segments)
	 *
	 * @param sourceNode
	 * @param targetNode
	 * @return the calculated route
	 */
	protected SimpleRouteResult findSingleRoute(Node sourceNode, Node targetNode) {
		return findSingleRoute(sourceNode, targetNode, graph);
	}

	/**
	 * Find a single route from source to destination {@link Node} by using simple A* algorithm. Can use the currently valid routing graph,
	 * or another graph which can be overridden temporarily.
	 *
	 * @param sourceNode
	 *            source of route
	 * @param targetNode
	 *            destination of route
	 * @return the calculated route, or <code>null</code> if no route could be found.
	 */
	protected SimpleRouteResult findSingleRoute(Node sourceNode, Node targetNode, Graph graph) {
		try {
			int sourceNodeId = (int) sourceNode.getId();
			int targetNodeId = (int) targetNode.getId();
			MlgRouter router = new MlgRouter();

			int[] path = router.findPath(graph, sourceNodeId, targetNodeId, Float.MAX_VALUE, params);
			List<Long> result = new ArrayList<>();
			List<Boolean> reverse = new ArrayList<>();
			List<Float> cost = new ArrayList<>();
			if (path != null) { // Found!
				for (int i = 0; i < path.length; i++) {
					int edgeId = graph.getEdgeIds()[path[i]];
					int segId = Graph.toSegmentId(edgeId);
					Long segIdLng = new Long(segId);
					if (!removedRoutingIds.contains(segIdLng)) {
						result.add(segIdLng);
						reverse.add(Graph.isReverse(edgeId));
						cost.add(graph.getEdgeCostsH()[path[i]]);
					}
				}
				return new SimpleRouteResult(result, reverse, cost);
			}
			return null;
		} catch (Exception e) {
			Logger.logError("Could not find route: " + e.getMessage(), e);
			return null;
		}

	}
}

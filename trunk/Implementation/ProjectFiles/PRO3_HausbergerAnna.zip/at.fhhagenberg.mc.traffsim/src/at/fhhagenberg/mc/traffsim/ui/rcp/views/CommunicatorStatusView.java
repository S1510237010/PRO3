package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.communication.Communicator;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.util.StringUtil;

public class CommunicatorStatusView extends ViewPart implements IModelInputChangedListener, ISimulationStateListener {
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.communicatorstatus";

	int pauseCycles = 3;

	private SimulationModel model;
	private PauseableThread updater = new PauseableThread("CommunicatorStatusView updater", 500) {

		@Override
		public void doWork() {
			if (getSite() != null && textMsgQueue != null && !textMsgQueue.isDisposed()) {
				getSite().getShell().getDisplay().syncExec(new Runnable() {

					@Override
					public void run() {
						if (model == null) {
							return;
						}
						Communicator comm = model.getCommunicator();
						textMsgQueue.setText(comm.getMessageQueueSize() + "");
						textTransferredData.setText(StringUtil.humanReadableByteCount(comm.getTotalBytes(), true));
						textSubmittedMsg.setText(comm.getTotalSubmittedMsg() + "");
						textTransmittedMessages.setText(comm.getTotalTransmittedMsg() + "");
					}
				});
			}
		}
	};
	private Text textMsgQueue;
	private Text textTransferredData;
	private Text textSubmittedMsg;
	private Text textTransmittedMessages;

	public CommunicatorStatusView() {
		SimulationKernel.getInstance().addInputChangedListener(this);
		updater.startPaused();
		inputChanged(SimulationKernel.getInstance().getActiveModel());
		simulationStateChanged(model, null, model.getCurrentState());
	}

	@Override
	public void createPartControl(Composite parent) {

		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(2, false));

		Label lblUpdateFrequency = new Label(composite, SWT.NONE);
		lblUpdateFrequency.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblUpdateFrequency.setText("Update interval");

		Spinner spinnerUpdateFrequency = new Spinner(composite, SWT.BORDER);
		spinnerUpdateFrequency.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				updater.setDelayInMillis(spinnerUpdateFrequency.getSelection());
			}
		});
		spinnerUpdateFrequency.setMaximum(10000);
		spinnerUpdateFrequency.setMinimum(10);
		spinnerUpdateFrequency.setSelection(500);
		spinnerUpdateFrequency.setIncrement(100);

		Label lblMessageQueueSize = new Label(composite, SWT.NONE);
		lblMessageQueueSize.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMessageQueueSize.setText("Message Queue Size");

		textMsgQueue = new Text(composite, SWT.BORDER);
		textMsgQueue.setEditable(false);
		textMsgQueue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblTransferredData = new Label(composite, SWT.NONE);
		lblTransferredData.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTransferredData.setText("Transferred Data");

		textTransferredData = new Text(composite, SWT.BORDER);
		textTransferredData.setEditable(false);
		textTransferredData.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblTransferredMessages = new Label(composite, SWT.NONE);
		lblTransferredMessages.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTransferredMessages.setText("Submitted Messages");

		textSubmittedMsg = new Text(composite, SWT.BORDER);
		textSubmittedMsg.setEditable(false);
		textSubmittedMsg.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblTransmittedMessage = new Label(composite, SWT.NONE);
		lblTransmittedMessage.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTransmittedMessage.setText("Transmitted Message");

		textTransmittedMessages = new Text(composite, SWT.BORDER);
		textTransmittedMessages.setEditable(false);
		textTransmittedMessages.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		// TODO Auto-generated method stub

	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (model != null) {
			model.removeSimulationStateListener(this);
		}
		this.model = newModel;
		if (model != null) {
			model.addSimulationStateListener(this);
		}
	}

	@Override
	public void dispose() {
		updater.stopAndDestroy();
		super.dispose();
		SimulationKernel.getInstance().removeInputChangedListener(this);
	}

	@Override
	public void simulationStateChanged(SimulationModel model, SimulationState oldState, SimulationState newState) {
		if (SimulationState.isSimulationRunningAfter(newState)) {
			updater.proceed();
		} else {
			updater.pauseAfter(3);
		}
	}

}

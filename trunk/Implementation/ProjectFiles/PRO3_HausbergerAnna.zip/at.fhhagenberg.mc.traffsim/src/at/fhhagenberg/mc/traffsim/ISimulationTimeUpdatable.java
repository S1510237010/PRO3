package at.fhhagenberg.mc.traffsim;

import java.util.Date;

/**
 * Implementors of this interface are all objects which are interested in
 * updates of the time in simulation.
 *
 * @author Christian Backfrieder
 *
 */
public interface ISimulationTimeUpdatable {

	/**
	 * Time continues progression. Implementation should perform necessary
	 * updates due to this time advance! Implementors are notified of the time
	 * step by this method.
	 *
	 * @param dt
	 *            The time difference compared to last notification of this
	 *            method in seconds (precision of 3 digits after comma -
	 *            milliseconds)
	 * @param simulationTime
	 *            The current time in simulation (this is NOT the real time!)
	 * @param simulationRunTime
	 *            The current run time of the simulation in seconds
	 */
	public void timeStep(double dt, Date simulationTime, double simulationRunTime);
}
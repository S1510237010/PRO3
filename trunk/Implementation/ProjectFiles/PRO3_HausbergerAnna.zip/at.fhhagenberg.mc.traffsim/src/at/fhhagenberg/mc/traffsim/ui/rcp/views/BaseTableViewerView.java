package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.filter.DefaultViewerFilter;

public abstract class BaseTableViewerView extends ViewPart implements IModelInputChangedListener {
	protected Table table;
	protected TableViewer viewer;
	protected BaseViewerComparator comparator;
	protected DefaultViewerFilter filter;

	protected BaseTableViewerView(){
		SimulationKernel.getInstance().addInputChangedListener(this);
		comparator = createComparator();
	}
	
	protected abstract class BaseViewerComparator extends ViewerComparator {
		protected int propertyIndex = 0;
		protected static final int DESCENDING = 1;
		protected int direction = DESCENDING;

		public int getDirection() {
			return direction == 1 ? SWT.DOWN : SWT.UP;
		}

		public void setColumn(int column) {
			if (column == this.propertyIndex) {
				direction = 1 - direction;
			} else {
				this.propertyIndex = column;
				direction = DESCENDING;
			}
		}
	}

	protected abstract BaseViewerComparator createComparator();

	protected SelectionAdapter getSelectionAdapter(final TableColumn column, final int index) {
		SelectionAdapter selectionAdapter = new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				comparator.setColumn(index);
				int dir = comparator.getDirection();
				viewer.getTable().setSortDirection(dir);
				viewer.getTable().setSortColumn(column);
				viewer.refresh();
			}
		};

		return selectionAdapter;
	}

	protected TableViewerColumn createTableViewerColumn(TableViewer viewer, String title, int width, int colNumber) {
		final TableViewerColumn viewerColumn = new TableViewerColumn(viewer, SWT.NONE);
		final TableColumn column = viewerColumn.getColumn();
		column.setText(title);
		column.setWidth(width);
		column.setResizable(true);
		column.setMoveable(true);
		column.addSelectionListener(getSelectionAdapter(column, colNumber));
		return viewerColumn;
	}
	
	protected void refreshFilter(String text) {
		filter.setFilterString(text);
		viewer.refresh();
	}
	
	@Override
	public void setFocus() {
		// No required
	}
	
	@Override
	public void dispose() {
		SimulationKernel.getInstance().removeInputChangedListener(this);
	}
}

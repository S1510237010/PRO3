package at.fhhagenberg.mc.traffsim.ui;

import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;

/**
 * Implementing class is capable of providing information in order to visualize certain routes
 * 
 * @author Christian Backfrieder
 *
 */
public interface IRouteProvider {
	/**
	 * @return Idenifier of route provider
	 */
	public String getName();

	/**
	 * Determines whether the route provider is initialised already
	 * 
	 * @return <code>true</code> if initialized, <code>false</code> otherwise
	 */
	public boolean isInitialized();
	
	/**
	 * 
	 * @return {@link IRoute}s which can be provided by this class, or an empty list if no routes are available.
	 */
	public List<IRoute> getAvailableRoutes();
	
	public List<IRoute> getAllRoutes();

	/**
	 * Add a listener which is notified as soon as the provided routes are updated
	 * 
	 * @param listener
	 */
	public void setUpdateListener(IRouteUpdateListener listener);

}

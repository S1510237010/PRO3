package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers;

import at.fhhagenberg.mc.traffsim.vehicle.DrivingRegime;

public class Regime {

	private DrivingRegime regime;
	private double fallbackProbability;

	public Regime() {
		regime = DrivingRegime.FREE_DRIVING;
		fallbackProbability = 0;
	}

	public Regime(DrivingRegime regime, double fallbackProbability) {
		this.regime = regime;
		this.fallbackProbability = fallbackProbability;
	}

	public DrivingRegime getDrivingRegime() {
		return regime;
	}

	public void setDrivingRegime(DrivingRegime regime) {
		this.regime = regime;
	}

	public double getFallbackProbability() {
		return fallbackProbability;
	}

	public void setFallbackProbability(double fallbackProbability) {
		this.fallbackProbability = fallbackProbability;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers;

public class SpeedRange {

	private double fromSpeed;
	private double toSpeed;
	private double fallbackProbability;

	public SpeedRange() {
		fromSpeed = 0;
		toSpeed = 0;
		fallbackProbability = 0;
	}

	public SpeedRange(double fromSpeed, double toSpeed, double fallbackProbability) {
		this.fromSpeed = fromSpeed;
		this.toSpeed = toSpeed;
		this.fallbackProbability = fallbackProbability;
	}

	public double getFromSpeed() {
		return fromSpeed;
	}

	public void setFromSpeed(double fromSpeed) {
		this.fromSpeed = fromSpeed;
	}

	public double getToSpeed() {
		return toSpeed;
	}

	public void setToSpeed(double toSpeed) {
		this.toSpeed = toSpeed;
	}

	public double getFallbackProbability() {
		return fallbackProbability;
	}

	public void setFallbackProbability(double fallbackProbability) {
		this.fallbackProbability = fallbackProbability;
	}
}

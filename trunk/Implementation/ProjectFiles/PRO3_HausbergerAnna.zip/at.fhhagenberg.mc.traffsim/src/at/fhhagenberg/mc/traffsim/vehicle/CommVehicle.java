package at.fhhagenberg.mc.traffsim.vehicle;

import java.util.Date;

import at.fhhagenberg.mc.traffsim.communication.Communicator;
import at.fhhagenberg.mc.traffsim.communication.IChannelModel;
import at.fhhagenberg.mc.traffsim.communication.ICommunicationPartner;
import at.fhhagenberg.mc.traffsim.communication.MessageTransfer;
import at.fhhagenberg.mc.traffsim.communication.ObservationCenter;
import at.fhhagenberg.mc.traffsim.communication.messaging.MessageFactory;
import at.fhhagenberg.mc.traffsim.communication.messaging.RoutePayload;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.util.types.JunctionWithDistance;

public class CommVehicle extends Vehicle implements ICommunicationPartner {

	private long vehicleDataCommunicationInterval = 200;
	private long staticRouteUpdateInterval;
	private long dynamicRouteUpdateThreshold;
	// TODO: message nur schicken, wenn sich werte wesentlich ge�ndert haben
	long lastupdate = 0;
	private Communicator communicator;
	private ObservationCenter observationCenter;
	boolean initialState = true;

	private IChannelModel demandChannelModel;
	private IChannelModel continuousChannelModel;

	public CommVehicle(double position, long id, Communicator comm, ObservationCenter observationCenter) {
		super(position, id);
		this.communicator = comm;
		this.observationCenter = observationCenter;
		comm.registerCommunicationReceiver(this);

	}

	@Override
	public void updateSpeedAndPosition(double dt, Date time) {
		super.updateSpeedAndPosition(dt, time);
		if (initialState) {
			communicator.sendMessage(this, observationCenter,
					MessageFactory.createInitialMessage(getAbsolutePosition(), getRoute().getInitialSegment(), getRoute().getTargetSegment()),
					demandChannelModel);
			communicator.sendMessage(this, observationCenter, MessageFactory.createRouteMessage(getAbsolutePosition(), getRoute(), getLaneSegment()),
					demandChannelModel);
			initialState = false;
		}
		if (time.getTime() - lastupdate > vehicleDataCommunicationInterval && getAbsolutePosition() != null) {
			communicator.sendMessage(this, observationCenter, MessageFactory.createVehicleDataMessage(getAbsolutePosition(), getAbsolutePosition(),
					getCurrentSpeed(), getFrontPosition(), getLaneSegment()), continuousChannelModel);
			lastupdate = time.getTime();
		}
	}

	@Override
	public void messageReceived(MessageTransfer msg) {
		if (!this.equals(msg.getReceiver())) {
			return;
		}
		if (msg.getMessage().getPayload() instanceof RoutePayload) {
			IRoute newRoute = ((RoutePayload) msg.getMessage().getPayload()).getRoute();
			boolean success = setRoute(newRoute);
			Object meta = msg.getMessage().getMetadata();
			if (success && meta instanceof Event) {
				eventLog.logEvent((Event) meta);
			}
		}
	}

	@Override
	public boolean setRoute(IRoute route) {
		if (getRoadSegment() != null) {
			route = RoutingUtil.trimUntilId(route, getRoadSegment().getRoutingId());
			route.removeNextSegmentIdIfMatches(getRoadSegment().getRoutingId());
		}
		JunctionWithDistance nextJunc = RoadUtil.getNextJunction(getLaneSegment());
		if (initialState) {
			super.setRoute(route);
			return true;
		}
		if (RoutingUtil.isRouteAssignmentOk(this, route) && nextJunc.getJunction().removeEntryGrant(this, route)) {
			super.setRoute(route);
			communicator.sendMessage(this, observationCenter, MessageFactory.createRouteMessage(getAbsolutePosition(), route, getLaneSegment()),
					demandChannelModel);
			return true;
		}
		return false;
	}

	public long getVehicleDataCommunicationInterval() {
		return vehicleDataCommunicationInterval;
	}

	public void setVehicleDataCommunicationInterval(long vehicleDataCommunicationInterval) {
		this.vehicleDataCommunicationInterval = vehicleDataCommunicationInterval;
	}

	@Override
	public String getCommName() {
		return "CommVehicle #" + getUniqueId();
	}

	public long getStaticRouteUpdateInterval() {
		return staticRouteUpdateInterval;
	}

	public void setStaticRouteUpdateInterval(long staticRouteUpdateInterval) {
		this.staticRouteUpdateInterval = staticRouteUpdateInterval;
	}

	public long getDynamicRouteUpdateThreshold() {
		return dynamicRouteUpdateThreshold;
	}

	public void setDynamicRouteUpdateThreshold(long dynamicRouteUpdateThreshold) {
		this.dynamicRouteUpdateThreshold = dynamicRouteUpdateThreshold;
	}

	@Override
	public boolean isRoutable() {
		return true;
	}

	public IChannelModel getDemandChannelModel() {
		return demandChannelModel;
	}

	public void setDemandChannelModel(IChannelModel channelModel) {
		this.demandChannelModel = channelModel;
	}

	public IChannelModel getContinuousChannelModel() {
		return continuousChannelModel;
	}

	public void setContinuousChannelModel(IChannelModel continuousChannelModel) {
		this.continuousChannelModel = continuousChannelModel;
	}

}

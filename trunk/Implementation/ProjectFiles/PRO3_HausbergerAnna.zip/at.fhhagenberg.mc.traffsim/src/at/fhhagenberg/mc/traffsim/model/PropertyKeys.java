package at.fhhagenberg.mc.traffsim.model;

import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;

public abstract class PropertyKeys {
	/************************************/
	/** DATA LOADING PROPERTIES */
	/************************************/
	public static final String RESET_GEOMETRY = "reset_geometry";

	/************************************/
	/** SIMULATION PARAMETER PROPERTIES */
	/************************************/
	public static final String REROUTING_MODE = "rerouting_mode";
	public static final String ROUTING_COST_EVALUATION = "routing_cost_evaluation";
	public static final String CONGESTION_EVALUATION = "congestion_evaluation";

	/** greenshield cost evaluator parameters */
	public static final String GREENSHIELD_CONGESTION_THRESHOLD_DELTA = "greenshield_congestion_threshold";
	public static final String SPEED_AVERAGE_CONGESTION_THRESHOLD = "speed_average_congestion_threshold";
	/**
	 * number of segments to consider for vehicle rerouting (Level, farthest distance (in number of segments) a candiate vehicle can be away
	 * from the congested segment to be rerouted
	 */
	public static final String CONGESTION_SEGMENT_LEVEL = "congestion_level";

	/** window size for lowpass filtering of cost average calculation */
	public static final String REROUTING_AVERAGEING_WINDOW_SIZE = "rerouting_averaging_window_size";
	/** factor for time: new route time must be better by factor ... compared to old time (in order to avoid constant route switching) */
	public static final String REROUTING_THRESHOLD_TIME = "rerouting_threshold_time";
	/** second time threshold which is taken into account when calculating dynamically predicted routes */
	public static final String REROUTING_THRESHOLD_TIME_DYNAMIC = "rerouting_threshold_time_dynamic";
	/** second distance threshold which is taken when calculating dynamically predicted routes */
	public static final String REROUTING_THRESHOLD_DISTANCE_DYNAMIC = "rerouting_threshold_distance_dynamic";
	/** factor for distance: new route distance must not be longer than ... times the old distance */
	public static final String REROUTING_THRESHOLD_DISTANCE = "rerouting_threshold_distance";
	/** with this parameter, a simulation set can be defined where simulations with equal parameters are stored in the specified folder */
	public static final String SIMULATION_SET_SUBFOLDER = "simulation_set_subfolder";
	/** parameter for mode of rerouting footprint heuristics (e.g. route_footprint) */
	public static final String REROUTING_FOOTPRINT_HEURISTICS = "rerouting_footprint_heuristics";
	/** parameter for route_footprint mode: the weight of the heuristics cost */
	public static final String REROUTING_FOOTPRINT_HEURISTICS_ROUTE_WEIGHT = "rerouting_footprint_heuristics_route_weight";
	/** switch for simulation of rerouting: congestions will be detected / predicted, but no rerouting will be performed */
	public static final String REROUTING_SIMULATION_ONLY = "rerouting_simulation_only";
	public static final String PARAMETERSET_ID = "parameterset_short_label";
	/**
	 * if true, a vehicle is not taken into consideration for reactive routes any more if it has been assigned a new route by dynamic
	 * rerouter
	 */
	public static final String AVOID_MULTI_REROUTES = "avoid_multi_reroutes";
	public static final String BATCH_EXECUTION = "batch_execution";

	public static final String GLOBAL_OUTPUT_FOLDER = "global_output_folder";

	public static final String USE_TIME_DYNAMIC_CONGESTION_EXTENSION = "time_dynamic_congestion_extension";

	// *********************************************/
	/** parameters for rerouting_footprint_heuristics_prediction */
	/** time reoslution in miliseconds */
	public static final String REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_TIME_RESOLUTION = "footprint_prediction_time_resolution";
	/** max forecast in miliseconds */
	public static final String REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_MAX_FORECAST = "footprint_prediction_max_forecast";
	/** threshold for identifying congestions (vehicles per second per node) */
	public static final String CONGESTION_THRESHOLD_VEHICLES_PER_SECOND = "congestion_threshold_vehicles_per_second";

	public static final String KSP_VALUE_K = "ksp_value_k";

	public static final String REROUTING_UPDATE_TIME = "rerouting_update_time";

	/** communication related parameters */
	public static final String COMM_DELAY_ENABLED = "communication_delay_enabled";
	public static final String DEMAND_CHANNEL_MODEL_IDENTIFIER = "demand_channel_model_identifier";
	public static final String CONTINUOUS_CHANNEL_MODEL_IDENTIFIER = "continuous_channel_model_identifier";

	public static final String SIMULATION_RESOLUTION_MS = IPreferenceConstants.SIMULATION_RESOLUTION_MS.toLowerCase();
	public static final String SIMULATION_DELAY_MS = IPreferenceConstants.SIMULATION_DELAY_MS.toLowerCase();

	public static final String MINIMUM_VEHICLES_FOR_CONGESTION = "minimum_vehicles_for_congestion";

	public static final String USE_NONOVERLAPPING_ROUTEPART_FOR_COMPARISON_ONLY = "use_nonoverlapping_routepart_for_comparison_only";
}

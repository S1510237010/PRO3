package at.fhhagenberg.mc.traffsim.vehicle;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.communication.IChannelModel;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleCommDataBean;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.VehicleModelFactory;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConsumptionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.Memory;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.StaticLongitudinalControl;

public class VehicleFactory {
	private static long obstacleId = -1;
	private static double averageLength = 0;
	private static double numVehiclesCreated = 0;
	private static double minLongitudinalGap = Double.MAX_VALUE;

	public static Vehicle createObstacle(double position) {
		Vehicle obstacle = new Vehicle(position, 0, 0, obstacleId--, VehicleType.OBSTACLE);
		return obstacle;
	}

	/**
	 * Create an obstruction
	 *
	 * @param seg
	 *            the road segment to set (this obstruction is NOT added to this segment by the factory! this has to be done subsequently!)
	 * @param position
	 *            the position where to create the obstruction
	 * @param offset
	 *            offset from simulation start time in seconds
	 * @param duration
	 *            duration in seconds
	 * @param laneId
	 *            the lane id where obstruction is present
	 * @param isPermanent
	 *            flag indicating whether the obstruction is permanent or not
	 * @return the created {@link Obstruction}
	 */
	public static Obstruction createObstruction(RoadSegment seg, double position, double offset, double duration, boolean isPermanent, int laneId) {
		Obstruction obs = new Obstruction(position, offset, duration, isPermanent, laneId);
		obs.setRoadSegment(seg);
		obs.setAbsolutePosition(seg.laneSegment(laneId).getRoadGeometry().mapPosition(position));
		obs.setLongitudinalControl(new StaticLongitudinalControl());
		return obs;
	}

	/**
	 * Create new car bounds as vector list of the car edges (rotated rectangle)
	 *
	 * @param absolutePosition
	 *            the absolute position of the car center
	 * @param drivingAngle
	 *            the driving angle in radians
	 * @param length
	 *            length of the car (rear-front dimension)
	 * @param width
	 *            width of the car (left-right dimension)
	 * @return list of car bounds, in the order front left - back left - back right - front right
	 */
	public static List<Vector> createCarBounds(Vector absolutePosition, double drivingAngle, double length, double width) {
		List<Vector> newBounds = new ArrayList<>();
		for (int i = 0; i < 4; i++) {
			newBounds.add(new Vector());
		}
		return updateCarBounds(absolutePosition, drivingAngle, length, width, newBounds);
	}

	/**
	 * Update car bounds as vector list of the car edges (rotated rectangle)
	 *
	 * @param absolutePosition
	 *            the absolute position of the car center
	 * @param drivingAngle
	 *            the driving angle in radians
	 * @param length
	 *            length of the car (rear-front dimension)
	 * @param width
	 *            width of the car (left-right dimension)
	 * @param oldBounds
	 *            the olds bounds, that will be updated (NOT newly generated)
	 * @return updated list of car bounds, in the order front left - back left - back right - front right
	 */
	public static List<Vector> updateCarBounds(Vector absolutePosition, double drivingAngle, double length, double width, List<Vector> oldBounds) {
		double x = absolutePosition.x;
		double y = absolutePosition.y;
		double sin = Math.sin(drivingAngle);
		double cos = Math.cos(drivingAngle);
		double halfLen = length / 2;
		double halfWid = width / 2;
		oldBounds.get(2).x = x + (halfLen) * cos - (halfWid) * sin;
		oldBounds.get(2).y = y + (halfWid) * cos + (halfLen) * sin;
		oldBounds.get(3).x = x - (halfLen) * cos - (halfWid) * sin;
		oldBounds.get(3).y = y + (halfWid) * cos - (halfLen) * sin;
		oldBounds.get(1).x = x + (halfLen) * cos + (halfWid) * sin;
		oldBounds.get(1).y = y - (halfWid) * cos + (halfLen) * sin;
		oldBounds.get(0).x = x - (halfLen) * cos + (halfWid) * sin;
		oldBounds.get(0).y = y - (halfWid) * cos - (halfLen) * sin;
		return oldBounds;
	}

	public static List<Vector> createObstructionBounds(double length, double width) {
		List<Vector> bounds = new ArrayList<>(4);
		bounds.add(new Vector(-0, -width / 2));
		bounds.add(new Vector(length, -width / 2));
		bounds.add(new Vector(length, width / 2));
		bounds.add(new Vector(0, width / 2));
		return bounds;
	}

	public static Vehicle createDummy(double speed, double position, double targetSpeed) {
		Vehicle v = createObstacle(position);
		v.setCurrentSpeed(speed);
		v.setLongitudinalControl(VehicleModelFactory.createDefaultLongitudinalControl(targetSpeed));
		return v;
	}

	public static Vehicle createDummy(Vehicle toCopy) {
		Vehicle v = createObstacle(toCopy.getFrontPosition());
		v.setCurrentSpeed(toCopy.getCurrentSpeed());
		v.setLongitudinalControl(VehicleModelFactory.createDefaultLongitudinalControl(toCopy.getLongitudinalControl().getTargetSpeed()));
		return v;
	}

	public static Vehicle createVehicle(SimulationModel model, double targetSpeed, double position, IRoute route, double initialSpeed,
			String longControlRef, String laneModelRef, String memoryModelRef, String noiseModelRef, String fuelModelRef) {
		Vehicle veh = new Vehicle(position);
		veh.setRoute(route);
		veh.setCurrentSpeed(initialSpeed);
		LongitudinalControl<?> longControl = model.getModelRegistry().getModel(longControlRef, LongitudinalControl.class);

		if (longControl == null) {
			Logger.logWarn("No longitudinal control found for reference " + longControlRef + ". Using default model");
			longControl = VehicleModelFactory.createDefaultLongitudinalControl(targetSpeed);
		}

		veh.setLongitudinalControl(longControl.copy(targetSpeed));
		minLongitudinalGap = Math.min(minLongitudinalGap, longControl.getMinGap());
		averageLength = (averageLength + veh.getLength()) / ++numVehiclesCreated;
		LaneChangeModel lchModel = model.getModelRegistry().getModel(laneModelRef, LaneChangeModel.class);
		if (lchModel == null) {
			Logger.logWarn("No lanechange model found for reference " + laneModelRef + ". Using default model");
			lchModel = VehicleModelFactory.createDefaultLaneChangeModel(veh);
		}
		FuelConsumptionModel consModel = model.getModelRegistry().getModel(fuelModelRef, FuelConsumptionModel.class);
		if (consModel == null) {
			Logger.logWarn("No consumption model found for reference " + fuelModelRef + ". Not available!");
		}

		veh.setLaneChangeModel(lchModel);
		veh.setConsumptionModel(consModel);
		veh.setLabel(veh.getUniqueId() + "");
		veh.setMemory(model.getModelRegistry().getModel(memoryModelRef, Memory.class));
		veh.setEventLog(model);
		return veh;
	}

	public static Vehicle createVehicle(SimulationModel model, VehicleBean bean, Map<Long, VehicleCommDataBean> commDataBeans)
			throws LoadingException, CloneNotSupportedException {
		Vehicle v;
		if (bean.isCommEnabled()) {
			CommVehicle commV = new CommVehicle(0, bean.getId(), model.getCommunicator(), model.getObservationCenter());
			VehicleCommDataBean commData = commDataBeans.get(bean.getCommDataId());
			if (commData == null) {
				throw new LoadingException(
						"Could not find referenced communication data with id " + bean.getCommDataId() + " (vehicle " + bean.getId() + ")");
			}
			commV.setVehicleDataCommunicationInterval(commData.getVehicleDataCommInterval());
			commV.setDynamicRouteUpdateThreshold(commData.getDynamicRouteUpdateThreshold());
			commV.setStaticRouteUpdateInterval(commData.getStaticRouteUpdateInterval());
			String demandIdentifier = PropertyUtil.getStringProperty(model.getSimulationParameters(), PropertyKeys.DEMAND_CHANNEL_MODEL_IDENTIFIER,
					"");
			IChannelModel demandChannelModel = model.getModelRegistry().getModel(demandIdentifier, IChannelModel.class);
			String continuousIdentifier = PropertyUtil.getStringProperty(model.getSimulationParameters(),
					PropertyKeys.CONTINUOUS_CHANNEL_MODEL_IDENTIFIER, "");
			IChannelModel continuousChannelModel = model.getModelRegistry().getModel(continuousIdentifier, IChannelModel.class);

			commV.setDemandChannelModel(demandChannelModel != null ? demandChannelModel.clone() : null);
			commV.setContinuousChannelModel(continuousChannelModel != null ? continuousChannelModel.clone() : null);
			v = commV;
		} else {
			v = new Vehicle(0, bean.getId());
		}
		v.setLeaderCapability(bean.hasLeaderCapability());
		v.setLength(bean.getLength());
		averageLength = (averageLength * numVehiclesCreated + v.getLength()) / ++numVehiclesCreated;
		v.setWidth(bean.getWidth());
		v.setLaneChangeModel(model.getModelRegistry().getModel(bean.getLaneChaneModelIdentifier(), LaneChangeModel.class));

		LongitudinalControl<?> longControl = model.getModelRegistry().getModel(bean.getLongitudinalControlIdentifier(), LongitudinalControl.class);
		v.setLongitudinalControl(longControl.copy(longControl.getTargetSpeed()));
		minLongitudinalGap = Math.min(minLongitudinalGap, v.getLongitudinalControl().getMinGap());
		v.setConsumptionModel(model.getModelRegistry().getModel(bean.getConsumptionIdentifier(), FuelConsumptionModel.class));
		IRoute route = model.getRouteRegistry().getRoute(bean.getRouteId());
		if (route != null) {
			v.setRoute(new Route(route));
		}
		v.setStartTime(bean.getStartDate());
		v.setType(VehicleType.valueOf(bean.getVehicleType().toUpperCase()));
		v.setMemory(model.getModelRegistry().getModel(bean.getMemoryIdentifier(), Memory.class));
		v.setCurrentSpeed(bean.getInitialSpeed());
		v.setEventLog(model);
		if (v.getCurrentSpeed() > 0) {
			v.setState(VehicleState.STEADY);
		}

		final String lblExt = bean.getLabel().isEmpty() ? "" : "_" + bean.getLabel();
		String label = bean.getId() + lblExt;
		// label = label.replaceAll("_[^\\d]", "");
		v.setLabel(label);
		return v;
	}

	/**
	 *
	 * @return the average length of all vehicles created so far
	 */
	public static double getAverageVehicleLength() {
		return averageLength;
	}

	/**
	 *
	 * @return get the minimal longitudinal gap of all vehicles created so far
	 */
	public static double getMinLongitudinalGap() {
		return minLongitudinalGap;
	}

}

package at.fhhagenberg.mc.traffsim.statistics;

public class OutlineVehicleStatisticsData implements Cloneable {
	long vehicleId;
	double totalFuel;
	double totalCarbonEmissions;
	double totalDistance;
	double totalTime;
	double cpuSeconds;
	long routeUpdateCount;

	public OutlineVehicleStatisticsData(long vehicleId, double totalFuel, double totalCarbonEmissions, double totalDistance,
			double totalTime) {
		super();
		this.vehicleId = vehicleId;
		this.totalFuel = totalFuel;
		this.totalCarbonEmissions = totalCarbonEmissions;
		this.totalDistance = totalDistance;
		this.totalTime = totalTime;
	}

	@Override
	public OutlineVehicleStatisticsData clone() {
		OutlineVehicleStatisticsData ovsd = new OutlineVehicleStatisticsData(vehicleId, totalFuel, totalCarbonEmissions, totalDistance,
				totalTime);
		ovsd.routeUpdateCount = routeUpdateCount;
		return ovsd;
	}

	public void update(double fuel, double carbonEmissions, double distance, double time) {
		this.totalFuel = fuel;
		this.totalCarbonEmissions = carbonEmissions;
		this.totalDistance = distance;
		this.totalTime = time;
	}

	public void increaseRouteUpdates() {
		routeUpdateCount++;
	}

	public void setCpuSeconds(double cpuSeconds) {
		this.cpuSeconds = cpuSeconds;
	}

	public double getCpuSeconds() {
		return cpuSeconds;
	}
}
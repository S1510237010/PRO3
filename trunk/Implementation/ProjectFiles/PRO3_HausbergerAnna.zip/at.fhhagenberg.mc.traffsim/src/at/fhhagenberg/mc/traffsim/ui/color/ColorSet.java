package at.fhhagenberg.mc.traffsim.ui.color;

import java.awt.Color;
import java.awt.Stroke;

import at.fhhagenberg.mc.traffsim.ui.Matrix;

/**
 * Abstract class for a colorset to use within the gisView
 * 
 * @author Christian
 * 
 */
public abstract class ColorSet {
	/**
	 * Provide the color for the specified element
	 * 
	 * @param _color
	 *            which color area to use
	 * @return {@link Color} to paint with
	 */

	public abstract Color getColor(IElement _color);

	/**
	 * Provide the stroke for the defined element
	 * 
	 * @param stroke
	 * @param matrix
	 * @return the stroke for the defined element
	 */
	public abstract Stroke getStroke(IElement stroke, Matrix matrix);
}

package at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data;

import java.util.Date;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Representation of a platoon action loaded
 *
 * @author Sebastian Huber
 *
 */
public class PlatoonActionData {

	/**
	 * Id of platoon to perform action on
	 */
	private long platoonId;

	/**
	 * Id of vehicle
	 */
	private long vehicleId;

	/**
	 * Vehicle to perform action on
	 */
	private Vehicle vehicle;

	/**
	 * Position for maneuver (not mandatory)
	 */
	private int position;

	/**
	 * Action to perform
	 */
	private PlatoonActionType action;

	/**
	 * Time to perform action
	 */
	private Date time;

	/**
	 * Flag to force an action (force means do it without join procedure)
	 */
	private boolean force;

	/**
	 * CTor
	 *
	 * @param platoonId
	 *            Id of platoon
	 * @param vehicleId
	 *            id of vehicle
	 * @param vehicle
	 *            vehicle
	 * @param position
	 *            position for/of vehicle
	 * @param action
	 *            action to perform
	 * @param time
	 *            time to perform action
	 * @param force
	 *            force flag for action
	 */
	public PlatoonActionData(long platoonId, long vehicleId, Vehicle vehicle, int position, PlatoonActionType action, Date time, boolean force) {
		super();
		this.platoonId = platoonId;
		this.vehicleId = vehicleId;
		this.vehicle = vehicle;
		this.position = position;
		this.action = action;
		this.time = time;
		this.force = force;
	}

	/**
	 * Id of platoon
	 *
	 * @return id
	 */
	public long getPlatoonId() {
		return platoonId;
	}

	/**
	 * Vehicle id
	 *
	 * @return id
	 */
	public long getVehicleId() {
		return vehicleId;
	}

	/**
	 * Vehicle
	 *
	 * @return vehicle
	 */
	public Vehicle getVehicle() {
		return vehicle;
	}

	/**
	 * Get position for maneuver
	 *
	 * @return position
	 */
	public int getPosition() {
		return position;
	}

	/**
	 * Action type
	 *
	 * @return type
	 */
	public PlatoonActionType getAction() {
		return action;
	}

	/**
	 * Time to perfrom action
	 *
	 * @return time
	 */
	public Date getTime() {
		return time;
	}

	/**
	 * Get force flag for action (do action without maneuver procedure)
	 *
	 * @return force flag
	 */
	public boolean isForce() {
		return force;
	}

	@Override
	public String toString() {
		return "PlatoonAction(Action:" + action + ", PlatoonId:" + platoonId + ", VehicleId:" + vehicleId + ", Position:" + position + ", Time:"
				+ time + ", Force:" + force + ")";
	}

}

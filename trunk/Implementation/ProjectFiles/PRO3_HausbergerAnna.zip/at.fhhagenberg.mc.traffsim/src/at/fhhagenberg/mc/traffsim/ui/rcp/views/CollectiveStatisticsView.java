package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.IViewSite;
import org.eclipse.ui.PartInitException;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.util.DateUtil;

public class CollectiveStatisticsView extends BaseTableViewerView implements ISimulationStateListener {
	public CollectiveStatisticsView() {
	}

	private class PauseWatcher implements ISimulationTimeUpdatable {

		private SimulationModel model;

		public PauseWatcher(SimulationModel model) {
			this.model = model;
		}

		@Override
		public void timeStep(double dt, Date simulationTime, double simulationRunTime) {
			if (NumberUtil.doubleEquals(simulationRunTime, pauseTime, 1e-5) || simulationRunTime > pauseTime) {
				model.setSimulationRunning(false);
				model.removeSimulationTimeUpdatable(PauseWatcher.this);
			}
		}

	}

	private PauseableThread updater = new PauseableThread("Statistics updater", 500) {

		@Override
		public void doWork() {
			for (SimulationModel m : models) {
				if (m != null && m.getOutlineStatisticsCollector() != null) {
					outlineStats.put(m.getUniqueId(), m.getOutlineStatisticsCollector().getContinuousOutlineStatistics());
				}
			}
			if (getSite() != null) {
				getSite().getShell().getDisplay().syncExec(new Runnable() {

					@Override
					public void run() {
						viewer.refresh();
					}
				});
			}

			if (stopOnDifferingEvents && !models.isEmpty()) {
				List<List<String>> eventNumberLists = new ArrayList<>();
				int minSize = Integer.MAX_VALUE;
				for (SimulationModel m : models) {
					List<String> idRef = m.getEventLog().getEvents().parallelStream().map(ev -> ev.getShortInfo()).collect(Collectors.toList());
					eventNumberLists.add(idRef);

					minSize = Math.min(minSize, idRef.size());
				}
				for (Iterator<List<String>> it = eventNumberLists.iterator(); it.hasNext() && minSize > 1;) {
					List<String> list = it.next();
					list = list.subList(0, minSize - 1);
					for (int i = 1; i < eventNumberLists.size(); i++) {
						if (!eventNumberLists.get(i).containsAll(list)) {
							ArrayList<String> listCopy = new ArrayList<>(eventNumberLists.get(i));
							listCopy.removeAll(list);
							setSimsRunning(false);
							pause();
							getSite().getShell().getDisplay().asyncExec(new Runnable() {
								@Override
								public void run() {
									MessageDialog.openWarning(getSite().getShell(), "Found differing events", String.join("\n", listCopy));
								}
							});
						}
					}
					it.remove();
				}
			}
		}
	};

	private class StatisticsComparator extends BaseViewerComparator {
		@Override
		public int compare(Viewer viewer, Object e1, Object e2) {
			SimulationModel mod1 = (SimulationModel) e1;
			SimulationModel mod2 = (SimulationModel) e2;
			double[] stat1 = outlineStats.get(mod1.getUniqueId());
			double[] stat2 = outlineStats.get(mod2.getUniqueId());
			int rc = 0;
			switch (propertyIndex) {
			case 0:
				rc = mod1.getUniqueId().compareTo(mod2.getUniqueId());
				break;
			default:
				rc = stat1 != null ? new Double(stat1[propertyIndex + 1]).compareTo(new Double(stat2[propertyIndex + 1])) : 0;
				break;
			}

			// If descending order, flip the direction
			if (direction == DESCENDING) {
				rc = -rc;
			}

			return rc;
		}
	}

	Set<SimulationModel> models = new HashSet<>();
	Map<String, double[]> outlineStats = new ConcurrentHashMap<>();
	Map<String, PauseWatcher> pauseWatchers = new ConcurrentHashMap<>();
	private Table table;
	private Spinner spinner;
	protected double pauseTime = -1;
	protected boolean stopOnDifferingEvents;

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (newModel == null)
			return;
		models = new HashSet<SimulationModel>(SimulationKernel.getInstance().getOpenModels());
		models.add(newModel);
		newModel.addSimulationStateListener(this);
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (viewer != null) {
					viewer.setInput(models);
				}
			}
		});
	}

	@Override
	protected BaseViewerComparator createComparator() {
		return new StatisticsComparator();
	}

	@Override
	public void init(IViewSite site) throws PartInitException {
		super.init(site);
		models = new HashSet<SimulationModel>(SimulationKernel.getInstance().getOpenModels());
		site.getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				viewer.setInput(models);
			}
		});
	}

	@Override
	public void createPartControl(Composite parent) {

		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(7, false));

		Label lblUpdateInterval = new Label(composite, SWT.NONE);
		lblUpdateInterval.setText("Update Interval");
		Spinner spinnerUpdateFrequency = new Spinner(composite, SWT.BORDER);
		spinnerUpdateFrequency.setSize(297, 469);
		spinnerUpdateFrequency.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				updater.setDelayInMillis(spinnerUpdateFrequency.getSelection());
			}
		});
		spinnerUpdateFrequency.setMaximum(10000);
		spinnerUpdateFrequency.setMinimum(10);
		spinnerUpdateFrequency.setSelection(500);
		spinnerUpdateFrequency.setIncrement(100);

		Button btnPauseAt = new Button(composite, SWT.CHECK);
		btnPauseAt.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnPauseAt.getSelection()) {
					pauseTime = ((double) spinner.getSelection()) / 1000;
					for (SimulationModel simulationModel : models) {
						PauseWatcher pauseWatcher = new PauseWatcher(simulationModel);
						pauseWatchers.put(simulationModel.getUniqueId(), pauseWatcher);
						simulationModel.addSimulationTimeUpdatable(pauseWatcher);
					}
				} else {
					for (SimulationModel simulationModel : models) {
						simulationModel.removeSimulationTimeUpdatable(pauseWatchers.get(simulationModel.getUniqueId()));
						pauseWatchers.remove(simulationModel.getUniqueId());
					}
					pauseTime = -1;
				}
			}
		});
		btnPauseAt.setText("Stop at");

		spinner = new Spinner(composite, SWT.BORDER);
		spinner.setMaximum(1000000000);
		spinner.setTextLimit(50000);
		spinner.setDigits(3);

		Button btnStopWhenEvents = new Button(composite, SWT.CHECK);
		btnStopWhenEvents.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stopOnDifferingEvents = btnStopWhenEvents.getSelection();
			}
		});
		btnStopWhenEvents.setText("Stop when events differ");

		Button btnContinueAll = new Button(composite, SWT.NONE);
		GridData gd_btnContinueAll = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnContinueAll.widthHint = 80;
		btnContinueAll.setLayoutData(gd_btnContinueAll);
		btnContinueAll.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updater.proceed();
				setSimsRunning(true);
			}
		});
		btnContinueAll.setText("Continue All");

		Button btnPauseAll = new Button(composite, SWT.NONE);
		btnPauseAll.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setSimsRunning(false);
			}
		});
		GridData gd_btnPauseAll = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnPauseAll.widthHint = 80;
		btnPauseAll.setLayoutData(gd_btnPauseAll);
		btnPauseAll.setText("Pause All");

		viewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table = viewer.getTable();
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 7, 1));
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		createColumns(viewer);
		viewer.setContentProvider(new ArrayContentProvider());
		viewer.setInput(models);
		viewer.setComparator(comparator);

		updater.start();
	}

	private void setSimsRunning(boolean run) {
		for (SimulationModel m : models) {
			m.setSimulationRunning(run);
		}
	}

	private void createColumns(TableViewer viewer) {
		int colindex = 0;
		TableViewerColumn colId = createTableViewerColumn(viewer, "ID", 50, colindex++);
		colId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return model.getUniqueId();
			}
		});

		TableViewerColumn colEventnum = createTableViewerColumn(viewer, "No. of events", 50, colindex++);
		colEventnum.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return model.getEventLog().getEvents().isEmpty() ? "0"
						: "" + model.getEventLog().getEvents().stream().mapToLong(ev -> ev.getContinuousNumber()).max().getAsLong();
			}
		});

		TableViewerColumn simulationRuntime = createTableViewerColumn(viewer, "Runtime [s]", 80, colindex++);
		simulationRuntime.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return outlineStats.containsKey(model.getUniqueId()) ? String.format("%.3f", model.getSimRuntimeSeconds()) : "";
			}

		});

		TableViewerColumn colDate = createTableViewerColumn(viewer, "Simulation time", 80, colindex++);
		colDate.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return DateUtil.formatWithMiliseconds(model.getCurrentSimTime(), true);
			}
		});

		TableViewerColumn colTime = createTableViewerColumn(viewer, "Time [s]", 100, colindex++);
		colTime.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return outlineStats.containsKey(model.getUniqueId()) ? String.format("%.3f", outlineStats.get(model.getUniqueId())[0]) : "";
			}
		});

		TableViewerColumn colFuel = createTableViewerColumn(viewer, "Fuel [l]", 100, colindex++);
		colFuel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				if (outlineStats.containsKey(model.getUniqueId()))
					return String.format("%.3f", outlineStats.get(model.getUniqueId())[1]);
				else
					return "";
			}
		});
		TableViewerColumn colCarbon = createTableViewerColumn(viewer, "CO2 [kg]", 100, colindex++);
		colCarbon.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return outlineStats.containsKey(model.getUniqueId()) ? String.format("%.3f", outlineStats.get(model.getUniqueId())[2]) : "";
			}
		});
		TableViewerColumn colDistance = createTableViewerColumn(viewer, "Distance [m]", 100, colindex++);
		colDistance.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return outlineStats.containsKey(model.getUniqueId()) ? String.format("%.3f", outlineStats.get(model.getUniqueId())[3]) : "";
			}
		});
		TableViewerColumn colRouteUpdates = createTableViewerColumn(viewer, "Route updates", 100, colindex++);
		colRouteUpdates.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return outlineStats.containsKey(model.getUniqueId()) ? String.format("%d", (int) outlineStats.get(model.getUniqueId())[4]) : "";
			}
		});
		TableViewerColumn colCrashes = createTableViewerColumn(viewer, "Crashes", 70, colindex++);
		colCrashes.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				SimulationModel model = (SimulationModel) element;
				return outlineStats.containsKey(model.getUniqueId()) ? String.format("%d", (int) outlineStats.get(model.getUniqueId())[5]) : "";
			}
		});
	}

	@Override
	public void dispose() {
		updater.stopAndDestroy();
		for (SimulationModel simulationModel : models) {
			simulationModel.removeSimulationStateListener(this);
			simulationModel.removeSimulationTimeUpdatable(pauseWatchers.get(simulationModel.getUniqueId()));
		}
		pauseWatchers.clear();
		models.clear();
		super.dispose();
	}

	@Override
	public void simulationStateChanged(SimulationModel model, SimulationState oldState, SimulationState newState) {
		if (newState == SimulationState.ENDED) {
			model.removeSimulationStateListener(this);
			models.remove(model);
		}
	}

}

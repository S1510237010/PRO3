package at.fhhagenberg.mc.traffsim.ui.rcp.views.performancemonitor;

import org.eclipse.jface.viewers.ColumnLabelProvider;

public class ThreadInfoLabelProvider extends ColumnLabelProvider {

	private ThreadInfoCollector updater;
	private ThreadInfoColumn col;

	public ThreadInfoLabelProvider(ThreadInfoCollector updater, ThreadInfoColumn col) {
		this.updater = updater;
		this.col = col;
	}

	@Override
	public String getText(Object element) {
		Long id = (Long) element;
		DetailThreadInfo info = updater.getInfo(id);
		boolean isNull = info == null || info.getInfo() == null;
		switch (col) {
		case CPU_TIME:
			return isNull ? "" : String.format("%.3f s", info.getCputime());
		case ID:
			return String.valueOf(id);
		case NAME:
			return isNull ? "" : info.getInfo().getThreadName();
		case STATE:
			return isNull ? "" : info.getInfo().getThreadState().toString();
		default:
			return "unknown column type";
		}
	}
}
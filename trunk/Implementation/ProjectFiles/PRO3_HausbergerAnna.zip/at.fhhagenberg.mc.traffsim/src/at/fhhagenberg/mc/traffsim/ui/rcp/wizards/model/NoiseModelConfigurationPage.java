package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;
import at.fhhagenberg.mc.traffsim.vehicle.model.NoiseModels;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class NoiseModelConfigurationPage extends ModelConfigurationPage {

	private Spinner spinnerTau;
	private Spinner spinnerFluctStrength;
	private Spinner spinnerAmplifier;

	private NoiseModels currentModel;

	protected NoiseModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		Label lblTau = new Label(grpModelParameters, SWT.NONE);
		lblTau.setText("Tau");

		spinnerTau = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerTau.setPageIncrement(50);
		spinnerTau.setIncrement(1);
		spinnerTau.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerTau.setMaximum(1000000);
		spinnerTau.setMinimum(0);
		spinnerTau.setSelection(20000);
		spinnerTau.setDigits(3);

		Label lblFluctStrength = new Label(grpModelParameters, SWT.NONE);
		lblFluctStrength.setText("Fluctuation strength");

		spinnerFluctStrength = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerFluctStrength.setPageIncrement(50);
		spinnerFluctStrength.setIncrement(1);
		spinnerFluctStrength.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerFluctStrength.setMaximum(1000000);
		spinnerFluctStrength.setMinimum(0);
		spinnerFluctStrength.setSelection(800);
		spinnerFluctStrength.setDigits(3);

		Label lblAmplifier = new Label(grpModelParameters, SWT.NONE);
		lblAmplifier.setText("Amplifier");

		spinnerAmplifier = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerAmplifier.setPageIncrement(50);
		spinnerAmplifier.setIncrement(1);
		spinnerAmplifier.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerAmplifier.setMaximum(1000000);
		spinnerAmplifier.setMinimum(0);
		spinnerAmplifier.setSelection(10);
		spinnerAmplifier.setDigits(3);

		// Model property initialization
		ModelProperty tau = new ModelProperty("Tau", "setTau", Double.TYPE, 0, 1000);
		ModelProperty fluctStrength = new ModelProperty("Fluctuation strength", "setFluctStrength", Double.TYPE, 0, 1000);
		ModelProperty amplifier = new ModelProperty("Amplifier", "setAmplifier", Double.TYPE, 0, 1000);

		modelProperties.add(tau);
		modelProperties.add(fluctStrength);
		modelProperties.add(amplifier);

		controlMapping.put(tau, spinnerTau);
		controlMapping.put(fluctStrength, spinnerFluctStrength);
		controlMapping.put(amplifier, spinnerAmplifier);
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			currentModel = NoiseModels.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' model parameters", currentModel.toString()));
		}
	}

	protected void addModelToList() {
		NoiseDataBean noiseModel = new NoiseDataBean();
		noiseModel.setModelIdentifier(txtIdentifier.getText());
		noiseModel.setFullName(txtFullName.getText());
		noiseModel.setTau(spinnerTau.getSelection() / Math.pow(10, spinnerTau.getDigits()));
		noiseModel
				.setFluctStrength(spinnerFluctStrength.getSelection() / Math.pow(10, spinnerFluctStrength.getDigits()));
		noiseModel.setAmplifier(spinnerAmplifier.getSelection() / Math.pow(10, spinnerAmplifier.getDigits()));

		modelSet.add(noiseModel);
	}

	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((NoiseDataBean) element).getModelIdentifier() + "";
			}
		});

		TableViewerColumn colTau = createTableViewerColumn("Tau", 160);
		colTau.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((NoiseDataBean) element).getTau() + "";
			}
		});

		TableViewerColumn colResigAlphaT = createTableViewerColumn("Fluctuation strength", 160);
		colResigAlphaT.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((NoiseDataBean) element).getFluctStrength() + "";
			}
		});

		TableViewerColumn colResigAlphaV0 = createTableViewerColumn("Amplifier", 160);
		colResigAlphaV0.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((NoiseDataBean) element).getAmplifier() + "";
			}
		});
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {

		try {
			Class<?> cls = NoiseDataBean.class;
			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();
				cls.getMethod("setModelIdentifier", String.class).invoke(obj,
						currentModel.getShortName() + "_gen_" + generationTime + "-" + (i + 1));
				cls.getMethod("setFullName", String.class).invoke(obj, "Auto. generated noise model");

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Method setter = cls.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);

						if (property.getType() == Integer.TYPE) {
							setter.invoke(obj, (int) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(obj, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(obj, (int) (spinner.getSelection() / Math.pow(10, spinner.getDigits())
										* property.getConversionFactor()));
							} else {
								setter.invoke(obj, (spinner.getSelection() / Math.pow(10, spinner.getDigits())
										* property.getConversionFactor()));
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(obj, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(obj, text.getText());
						}
					}
				}

				modelSet.add((NoiseDataBean) obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
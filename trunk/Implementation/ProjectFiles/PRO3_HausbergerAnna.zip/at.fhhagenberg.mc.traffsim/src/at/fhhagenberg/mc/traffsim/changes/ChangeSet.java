package at.fhhagenberg.mc.traffsim.changes;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("changeSet")
public class ChangeSet {
	@XStreamImplicit
	private List<ChangeSetItem> items;

	public List<ChangeSetItem> getItems() {
		return items;
	}

	public void setItems(List<ChangeSetItem> items) {
		this.items = items;
	}
}

package at.fhhagenberg.mc.traffsim.util.types;

import java.util.ArrayList;

/**
 * Implementation of a cyclic list data structure.
 *
 * @author Christian Backfrieder
 *
 * @param <E>
 *            the element type
 */
public class CyclicList<E> extends ArrayList<E> {

	/** Unique identifier for serialization */
	private static final long serialVersionUID = 8009802948479106447L;

	/**
	 * Gets the element which is left to the given one.
	 *
	 * @param element
	 *            the current element
	 * @return the element left to the current one
	 */
	public E elementLeftTo(E element) {
		int index = (indexOf(element) - 1 + size()) % size();
		return get(index);
	}

	/**
	 * Gets the element which is right to the given one.
	 *
	 * @param element
	 *            the current element
	 * @return the element right to the current one
	 */
	public E elementRightTo(E element) {
		int index = (indexOf(element) + 1 + size()) % size();
		return get(index);
	}
}
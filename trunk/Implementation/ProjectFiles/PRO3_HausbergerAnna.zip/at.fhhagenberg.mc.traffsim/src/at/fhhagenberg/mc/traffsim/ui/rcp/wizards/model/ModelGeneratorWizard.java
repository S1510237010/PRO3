package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.io.File;
import java.util.List;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;

/**
 *
 * @author Manuel Lindorfer
 *
 */
public class ModelGeneratorWizard extends Wizard {

	public static final String PAGE_CONSUMPTION_MODEL_CONFIGURATION = "consumption_model_configuration";
	public static final String PAGE_LANE_CHANGE_MODEL_CONFIGURATION = "lane_change_model_configuration";
	public static final String PAGE_CHANNEL_MODEL_CONFIGURATION = "channel_model_configuration";
	public static final String PAGE_LONGITUDINAL_MODEL_CONFIGURATION = "longitudinal_model_configuration";
	public static final String PAGE_MEMORY_MODEL_CONFIGURATION = "memory_model_configuration";
	public static final String PAGE_MODEL_CONFIGURATION = "model_configuration";
	public static final String PAGE_MODEL_SELECTION = "model_selection";
	public static final String PAGE_NOISE_MODEL_CONFIGURATION = "noise_model_configuration";

	public static final String PAGE_DEFAULT_LONG_CONTROL_CONFIGURATION = "default_control_configuration";
	public static final String PAGE_EHDM_LONG_CONTROL_CONFIGURATION = "ehdm_control_configuration";
	public static final String PAGE_HDM_LONG_CONTROL_CONFIGURATION = "hdm_control_configuration";
	public static final String PAGE_VEHICLE_AUTOMATION_CONTROL_CONFIGURATION = "vehicle_automation_control_configuration";

	private File configFile;
	private ConsumptionModelConfigurationPage consumptionModelConfigurationPage;
	private ChannelModelConfigurationPage channelModelConfigurationPage;
	private LaneChangeModelConfigurationPage laneChangeModelConfigurationPage;
	private LongitudinalModelConfigurationPage longitudinalModelConfigurationPage;
	private MemoryModelConfigurationPage memoryModelConfigurationPage;

	private EnhancedHumanDriverMetaModelConfigurationPage enhancedHumanDriverControlConfigurationPage;
	private HumanDriverMetaModelConfigurationPage humanDriverControlConfigurationPage;
	private DefaultLongitudinalControlConfigurationPage defaultControlConfigurationPage;
	private VehicleAutomationControlConfigurationPage vehicleAutomationControlConfigurationPage;

	private List<AbstractBean> models;
	private List<AbstractBean> controls;

	private NoiseModelConfigurationPage noiseModelConfigurationPage;

	private String previousModelIdentifier;
	private ModelSelectionPage selectionPage;

	public ModelGeneratorWizard() {
		setWindowTitle("Model Generation");

		previousModelIdentifier = null;

		selectionPage = new ModelSelectionPage(PAGE_MODEL_SELECTION);
		longitudinalModelConfigurationPage = new LongitudinalModelConfigurationPage(PAGE_LONGITUDINAL_MODEL_CONFIGURATION);
		laneChangeModelConfigurationPage = new LaneChangeModelConfigurationPage(PAGE_LANE_CHANGE_MODEL_CONFIGURATION);
		consumptionModelConfigurationPage = new ConsumptionModelConfigurationPage(PAGE_CONSUMPTION_MODEL_CONFIGURATION);
		memoryModelConfigurationPage = new MemoryModelConfigurationPage(PAGE_MEMORY_MODEL_CONFIGURATION);
		noiseModelConfigurationPage = new NoiseModelConfigurationPage(PAGE_NOISE_MODEL_CONFIGURATION);
		humanDriverControlConfigurationPage = new HumanDriverMetaModelConfigurationPage(PAGE_HDM_LONG_CONTROL_CONFIGURATION);
		enhancedHumanDriverControlConfigurationPage = new EnhancedHumanDriverMetaModelConfigurationPage(PAGE_EHDM_LONG_CONTROL_CONFIGURATION);
		defaultControlConfigurationPage = new DefaultLongitudinalControlConfigurationPage(PAGE_DEFAULT_LONG_CONTROL_CONFIGURATION);
		channelModelConfigurationPage = new ChannelModelConfigurationPage(PAGE_CHANNEL_MODEL_CONFIGURATION);
		vehicleAutomationControlConfigurationPage = new VehicleAutomationControlConfigurationPage(PAGE_VEHICLE_AUTOMATION_CONTROL_CONFIGURATION);
	}

	@Override
	public void addPages() {
		addPage(selectionPage);
		addPage(longitudinalModelConfigurationPage);
		addPage(laneChangeModelConfigurationPage);
		addPage(consumptionModelConfigurationPage);
		addPage(memoryModelConfigurationPage);
		addPage(noiseModelConfigurationPage);
		addPage(humanDriverControlConfigurationPage);
		addPage(enhancedHumanDriverControlConfigurationPage);
		addPage(defaultControlConfigurationPage);
		addPage(vehicleAutomationControlConfigurationPage);
		addPage(channelModelConfigurationPage);
	}

	@Override
	public boolean canFinish() {

		IWizardPage currentPage = getContainer().getCurrentPage();

		if (currentPage == null) {
			return false;
		}

		return currentPage.equals(longitudinalModelConfigurationPage) && longitudinalModelConfigurationPage.isPageComplete()
				|| currentPage.equals(laneChangeModelConfigurationPage) && laneChangeModelConfigurationPage.isPageComplete()
				|| currentPage.equals(consumptionModelConfigurationPage) && consumptionModelConfigurationPage.isPageComplete()
				|| currentPage.equals(memoryModelConfigurationPage) && memoryModelConfigurationPage.isPageComplete()
				|| currentPage.equals(humanDriverControlConfigurationPage) && humanDriverControlConfigurationPage.isPageComplete()
				|| currentPage.equals(enhancedHumanDriverControlConfigurationPage) && enhancedHumanDriverControlConfigurationPage.isPageComplete()
				|| currentPage.equals(defaultControlConfigurationPage) && defaultControlConfigurationPage.isPageComplete()
				|| currentPage.equals(noiseModelConfigurationPage) && noiseModelConfigurationPage.isPageComplete()
				|| currentPage.equals(channelModelConfigurationPage) && channelModelConfigurationPage.isPageComplete()
				|| currentPage.equals(vehicleAutomationControlConfigurationPage) && vehicleAutomationControlConfigurationPage.isPageComplete();
	}

	public File getConfigFile() {
		return configFile;
	}

	public List<AbstractBean> getModels() {
		return models;
	}

	public List<AbstractBean> getControls() {
		return controls;
	}

	public String getPreviousModelIdentifier() {
		return previousModelIdentifier;
	}

	@Override
	public boolean performFinish() {

		IWizardPage currentPage = getContainer().getCurrentPage();

		List<AbstractBean> existingModels = null;
		List<AbstractBean> models = null;
		List<AbstractBean> existingControls = null;
		List<AbstractBean> controls = null;
		boolean performOverride = false;

		if (currentPage.equals(longitudinalModelConfigurationPage)) {
			models = longitudinalModelConfigurationPage.getModelSet();
			existingModels = longitudinalModelConfigurationPage.getExistingModels();
			performOverride = longitudinalModelConfigurationPage.performOverride();
		} else if (currentPage.equals(defaultControlConfigurationPage)) {
			controls = defaultControlConfigurationPage.getModelSet();
			existingControls = defaultControlConfigurationPage.getExistingModels();
			performOverride = defaultControlConfigurationPage.performOverride();
		} else if (currentPage.equals(humanDriverControlConfigurationPage)) {
			controls = humanDriverControlConfigurationPage.getModelSet();
			existingControls = humanDriverControlConfigurationPage.getExistingModels();
			performOverride = humanDriverControlConfigurationPage.performOverride();
		} else if (currentPage.equals(enhancedHumanDriverControlConfigurationPage)) {
			controls = enhancedHumanDriverControlConfigurationPage.getModelSet();
			existingControls = enhancedHumanDriverControlConfigurationPage.getExistingModels();
			performOverride = enhancedHumanDriverControlConfigurationPage.performOverride();
		} else if (currentPage.equals(vehicleAutomationControlConfigurationPage)) {
			controls = vehicleAutomationControlConfigurationPage.getModelSet();
			existingControls = vehicleAutomationControlConfigurationPage.getExistingModels();
			performOverride = vehicleAutomationControlConfigurationPage.performOverride();
		} else if (currentPage.equals(consumptionModelConfigurationPage)) {
			models = consumptionModelConfigurationPage.getModelSet();
			existingModels = consumptionModelConfigurationPage.getExistingModels();
			performOverride = consumptionModelConfigurationPage.performOverride();
		} else if (currentPage.equals(memoryModelConfigurationPage)) {
			models = memoryModelConfigurationPage.getModelSet();
			existingModels = memoryModelConfigurationPage.getExistingModels();
			performOverride = memoryModelConfigurationPage.performOverride();
		} else if (currentPage.equals(laneChangeModelConfigurationPage)) {
			models = laneChangeModelConfigurationPage.getModelSet();
			existingModels = laneChangeModelConfigurationPage.getExistingModels();
			performOverride = laneChangeModelConfigurationPage.performOverride();
		} else if (currentPage.equals(noiseModelConfigurationPage)) {
			models = noiseModelConfigurationPage.getModelSet();
			existingModels = noiseModelConfigurationPage.getExistingModels();
			performOverride = noiseModelConfigurationPage.performOverride();
		} else if (currentPage.equals(channelModelConfigurationPage)) {
			models = channelModelConfigurationPage.getModelSet();
			existingModels = channelModelConfigurationPage.getExistingModels();
			performOverride = channelModelConfigurationPage.performOverride();
		}

		// Create model configuration, or extend / override existing one
		if (existingModels == null || existingModels.isEmpty() || performOverride) {
			this.models = models;
		} else {
			existingModels.addAll(models);
			this.models = existingModels;
		}

		// Create control configuration, or extend / override existing one
		if (existingControls == null || existingControls.isEmpty() || performOverride) {
			this.controls = controls;
		} else {
			existingControls.addAll(controls);
			this.controls = existingControls;
		}

		long id = 0;

		if (this.models != null) {
			for (AbstractBean bean : this.models) {
				bean.setId(id);
				id++;
			}

			id = 0;
		}

		if (this.controls != null) {
			for (AbstractBean bean : this.controls) {
				bean.setId(id);
				id++;
			}
		}

		configFile = ((ModelSelectionPage) getPage(PAGE_MODEL_SELECTION)).getConfigFile();
		return true;
	}

	public void setPreviousModelIdentifier(String modelIdentifier) {
		previousModelIdentifier = modelIdentifier;
	}
}

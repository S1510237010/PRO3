package at.fhhagenberg.mc.traffsim.data.osm;

import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.StringEscapeUtils;

import at.fhhagenberg.mc.traffsim.model.osm.OSMNode;
import at.fhhagenberg.mc.traffsim.model.osm.OSMWay;

/**
 * This class provides functionalities to write OSM data to an OSM-compatible traffsim configuration file.
 *
 * @author Manuel Lindorfer
 *
 */
public class OSMWriter {

	/** Map containing all relevant encodings for UTF-8 */
	private final static HashMap<Character, String> encoding = new HashMap<Character, String>();

	static {
		encoding.put(new Character('<'), "&lt;");
		encoding.put(new Character('>'), "&gt;");
		encoding.put(new Character('"'), "&quot;");
		encoding.put(new Character('\''), "&#039;");

		encoding.put(new Character('\''), "&#039;");
		encoding.put(new Character('-'), "&#045;");
		encoding.put(new Character('&'), "&amp;");
		encoding.put(new Character('\n'), "&#xA;");
		encoding.put(new Character('\r'), "&#xD;");
		encoding.put(new Character('\t'), "&#x9;");

		encoding.put(new Character('�'), "&#145;");
		encoding.put(new Character('�'), "&#146;");
		encoding.put(new Character('�'), "&#147;");
		encoding.put(new Character('�'), "&#148;");
		encoding.put(new Character('�'), "&#149;");
		encoding.put(new Character('�'), "&#150;");
		encoding.put(new Character('�'), "&#151;");

		encoding.put(new Character('�'), "&#161;");
		encoding.put(new Character('�'), "&#162;");
		encoding.put(new Character('�'), "&#163;");
		encoding.put(new Character('�'), "&#164;");
		encoding.put(new Character('�'), "&#165;");
		encoding.put(new Character('�'), "&#166;");
		encoding.put(new Character('�'), "&#167;");
		encoding.put(new Character('�'), "&#168;");
		encoding.put(new Character('�'), "&#169;");
		encoding.put(new Character('�'), "&#170;");
		encoding.put(new Character('�'), "&#171;");
		encoding.put(new Character('�'), "&#172;");
		encoding.put(new Character('�'), "&#174;");
		encoding.put(new Character('�'), "&#175;");
		encoding.put(new Character('�'), "&#176;");
		encoding.put(new Character('�'), "&#177;");
		encoding.put(new Character('�'), "&#178;");
		encoding.put(new Character('�'), "&#179;");
		encoding.put(new Character('�'), "&#180;");
		encoding.put(new Character('�'), "&#181;");
		encoding.put(new Character('�'), "&#182;");
		encoding.put(new Character('�'), "&#183;");
		encoding.put(new Character('�'), "&#184;");
		encoding.put(new Character('�'), "&#185;");
		encoding.put(new Character('�'), "&#186;");
		encoding.put(new Character('�'), "&#187;");
		encoding.put(new Character('�'), "&#188;");
		encoding.put(new Character('�'), "&#189;");
		encoding.put(new Character('�'), "&#190;");
		encoding.put(new Character('�'), "&#191;");
		encoding.put(new Character('�'), "&#192;");
		encoding.put(new Character('�'), "&#193;");
		encoding.put(new Character('�'), "&#194;");
		encoding.put(new Character('�'), "&#195;");
		encoding.put(new Character('�'), "&#196;");
		encoding.put(new Character('�'), "&#197;");
		encoding.put(new Character('�'), "&#198;");
		encoding.put(new Character('�'), "&#199;");
		encoding.put(new Character('�'), "&#200;");
		encoding.put(new Character('�'), "&#191;");
		encoding.put(new Character('�'), "&#192;");
		encoding.put(new Character('�'), "&#193;");
		encoding.put(new Character('�'), "&#194;");
		encoding.put(new Character('�'), "&#195;");
		encoding.put(new Character('�'), "&#196;");
		encoding.put(new Character('�'), "&#197;");
		encoding.put(new Character('�'), "&#198;");
		encoding.put(new Character('�'), "&#199;");
		encoding.put(new Character('�'), "&#200;");
		encoding.put(new Character('�'), "&#201;");
		encoding.put(new Character('�'), "&#202;");
		encoding.put(new Character('�'), "&#203;");
		encoding.put(new Character('�'), "&#204;");
		encoding.put(new Character('�'), "&#205;");
		encoding.put(new Character('�'), "&#206;");
		encoding.put(new Character('�'), "&#207;");
		encoding.put(new Character('�'), "&#208;");
		encoding.put(new Character('�'), "&#209;");
		encoding.put(new Character('�'), "&#210;");
		encoding.put(new Character('�'), "&#211;");
		encoding.put(new Character('�'), "&#212;");
		encoding.put(new Character('�'), "&#213;");
		encoding.put(new Character('�'), "&#214;");
		encoding.put(new Character('�'), "&#215;");
		encoding.put(new Character('�'), "&#216;");
		encoding.put(new Character('�'), "&#217;");
		encoding.put(new Character('�'), "&#218;");
		encoding.put(new Character('�'), "&#219;");
		encoding.put(new Character('�'), "&#220;");
		encoding.put(new Character('�'), "&#221;");
		encoding.put(new Character('�'), "&#222;");
		encoding.put(new Character('�'), "&#223;");
		encoding.put(new Character('�'), "&#224;");
		encoding.put(new Character('�'), "&#225;");
		encoding.put(new Character('�'), "&#226;");
		encoding.put(new Character('�'), "&#227;");
		encoding.put(new Character('�'), "&#228;");
		encoding.put(new Character('�'), "&#229;");
		encoding.put(new Character('�'), "&#230;");
		encoding.put(new Character('�'), "&#231;");
		encoding.put(new Character('�'), "&#232;");
		encoding.put(new Character('�'), "&#233;");
		encoding.put(new Character('�'), "&#234;");
		encoding.put(new Character('�'), "&#235;");
		encoding.put(new Character('�'), "&#236;");
		encoding.put(new Character('�'), "&#237;");
		encoding.put(new Character('�'), "&#238;");
		encoding.put(new Character('�'), "&#239;");
		encoding.put(new Character('�'), "&#240;");
		encoding.put(new Character('�'), "&#241;");
		encoding.put(new Character('�'), "&#242;");
		encoding.put(new Character('�'), "&#243;");
		encoding.put(new Character('�'), "&#244;");
		encoding.put(new Character('�'), "&#245;");
		encoding.put(new Character('�'), "&#246;");
		encoding.put(new Character('�'), "&#247;");
		encoding.put(new Character('�'), "&#248;");
		encoding.put(new Character('�'), "&#249;");
		encoding.put(new Character('�'), "&#250;");
		encoding.put(new Character('�'), "&#251;");
		encoding.put(new Character('�'), "&#252;");
		encoding.put(new Character('�'), "&#253;");
		encoding.put(new Character('�'), "&#254;");
		encoding.put(new Character('�'), "&#255;");
		encoding.put(new Character('A'), "&#256;");
		encoding.put(new Character('a'), "&#257;");
		encoding.put(new Character('A'), "&#258;");
		encoding.put(new Character('a'), "&#259;");
		encoding.put(new Character('A'), "&#260;");
		encoding.put(new Character('a'), "&#261;");
		encoding.put(new Character('C'), "&#262;");
		encoding.put(new Character('c'), "&#263;");
		encoding.put(new Character('C'), "&#264;");
		encoding.put(new Character('c'), "&#265;");
		encoding.put(new Character('C'), "&#266;");
		encoding.put(new Character('c'), "&#267;");
		encoding.put(new Character('C'), "&#268;");
		encoding.put(new Character('c'), "&#269;");
		encoding.put(new Character('D'), "&#270;");
		encoding.put(new Character('d'), "&#271;");
		encoding.put(new Character('�'), "&#272;");
		encoding.put(new Character('d'), "&#273;");
		encoding.put(new Character('E'), "&#274;");
		encoding.put(new Character('e'), "&#275;");
		encoding.put(new Character('E'), "&#276;");
		encoding.put(new Character('e'), "&#277;");
		encoding.put(new Character('E'), "&#278;");
		encoding.put(new Character('e'), "&#279;");
		encoding.put(new Character('E'), "&#280;");
		encoding.put(new Character('e'), "&#281;");
		encoding.put(new Character('E'), "&#282;");
		encoding.put(new Character('e'), "&#283;");
		encoding.put(new Character('G'), "&#284;");
		encoding.put(new Character('g'), "&#285;");
		encoding.put(new Character('G'), "&#286;");
		encoding.put(new Character('g'), "&#287;");
		encoding.put(new Character('G'), "&#288;");
		encoding.put(new Character('g'), "&#289;");
		encoding.put(new Character('G'), "&#290;");
		encoding.put(new Character('g'), "&#291;");
		encoding.put(new Character('H'), "&#292;");
		encoding.put(new Character('h'), "&#293;");
		encoding.put(new Character('H'), "&#294;");
		encoding.put(new Character('h'), "&#295;");
		encoding.put(new Character('I'), "&#296;");
		encoding.put(new Character('i'), "&#297;");
		encoding.put(new Character('I'), "&#298;");
		encoding.put(new Character('i'), "&#299;");
		encoding.put(new Character('I'), "&#300;");
		encoding.put(new Character('i'), "&#301;");
		encoding.put(new Character('I'), "&#302;");
		encoding.put(new Character('i'), "&#303;");
		encoding.put(new Character('I'), "&#304;");
		encoding.put(new Character('i'), "&#305;");
		encoding.put(new Character('?'), "&#306;");
		encoding.put(new Character('?'), "&#307;");
		encoding.put(new Character('J'), "&#308;");
		encoding.put(new Character('j'), "&#309;");
		encoding.put(new Character('K'), "&#310;");
		encoding.put(new Character('k'), "&#311;");
		encoding.put(new Character('?'), "&#312;");
		encoding.put(new Character('L'), "&#313;");
		encoding.put(new Character('l'), "&#314;");
		encoding.put(new Character('L'), "&#315;");
		encoding.put(new Character('l'), "&#316;");
		encoding.put(new Character('L'), "&#317;");
		encoding.put(new Character('l'), "&#318;");
		encoding.put(new Character('?'), "&#319;");
		encoding.put(new Character('?'), "&#320;");
		encoding.put(new Character('L'), "&#321;");
		encoding.put(new Character('l'), "&#322;");
		encoding.put(new Character('N'), "&#323;");
		encoding.put(new Character('n'), "&#324;");
		encoding.put(new Character('N'), "&#325;");
		encoding.put(new Character('n'), "&#326;");
		encoding.put(new Character('N'), "&#327;");
		encoding.put(new Character('n'), "&#328;");
		encoding.put(new Character('?'), "&#329;");
		encoding.put(new Character('?'), "&#330;");
		encoding.put(new Character('?'), "&#331;");
		encoding.put(new Character('O'), "&#332;");
		encoding.put(new Character('o'), "&#333;");
		encoding.put(new Character('O'), "&#334;");
		encoding.put(new Character('o'), "&#335;");
		encoding.put(new Character('O'), "&#336;");
		encoding.put(new Character('o'), "&#337;");
		encoding.put(new Character('�'), "&#338;");
		encoding.put(new Character('�'), "&#339;");
		encoding.put(new Character('R'), "&#340;");
		encoding.put(new Character('r'), "&#341;");
		encoding.put(new Character('R'), "&#342;");
		encoding.put(new Character('r'), "&#343;");
		encoding.put(new Character('R'), "&#344;");
		encoding.put(new Character('r'), "&#345;");
		encoding.put(new Character('S'), "&#346;");
		encoding.put(new Character('s'), "&#347;");
		encoding.put(new Character('S'), "&#348;");
		encoding.put(new Character('s'), "&#349;");
		encoding.put(new Character('S'), "&#350;");
		encoding.put(new Character('s'), "&#351;");
		encoding.put(new Character('�'), "&#352;");
		encoding.put(new Character('�'), "&#353;");
		encoding.put(new Character('T'), "&#354;");
		encoding.put(new Character('t'), "&#355;");
		encoding.put(new Character('T'), "&#356;");
		encoding.put(new Character('t'), "&#357;");
		encoding.put(new Character('T'), "&#358;");
		encoding.put(new Character('t'), "&#359;");
		encoding.put(new Character('U'), "&#360;");
		encoding.put(new Character('u'), "&#361;");
		encoding.put(new Character('U'), "&#362;");
		encoding.put(new Character('u'), "&#363;");
		encoding.put(new Character('U'), "&#364;");
		encoding.put(new Character('u'), "&#365;");
		encoding.put(new Character('U'), "&#366;");
		encoding.put(new Character('u'), "&#367;");
		encoding.put(new Character('U'), "&#368;");
		encoding.put(new Character('u'), "&#369;");
		encoding.put(new Character('U'), "&#370;");
		encoding.put(new Character('u'), "&#371;");
		encoding.put(new Character('W'), "&#372;");
		encoding.put(new Character('w'), "&#373;");
		encoding.put(new Character('Y'), "&#374;");
		encoding.put(new Character('y'), "&#375;");
		encoding.put(new Character('Z'), "&#377;");
		encoding.put(new Character('z'), "&#378;");
		encoding.put(new Character('Z'), "&#379;");
		encoding.put(new Character('z'), "&#380;");
		encoding.put(new Character('�'), "&#381;");
		encoding.put(new Character('�'), "&#382;");
	}

	/**
	 * Encodes the given string in XML 1.0 format. Optimized to fast pass strings that don't need encoding (normal case).
	 *
	 * @param unencoded
	 *            the unencoded string
	 *
	 * @return an encoded string
	 */
	public static String encode(String unencoded) {
		StringBuffer buffer = null;

		for (int i = 0; i < unencoded.length(); ++i) {
			String encS = encoding.get(new Character(unencoded.charAt(i)));
			if (encS != null) {
				if (buffer == null) {
					buffer = new StringBuffer(unencoded.substring(0, i));
				}
				buffer.append(encS);
			} else if (buffer != null) {
				buffer.append(unencoded.charAt(i));
			}
		}

		return buffer == null ? unencoded : buffer.toString();
	}

	/**
	 * Serialises the given lists of {@link OSMNode}s and {@link OSMWay}s using the provided {@link Writer}.
	 *
	 * @param out
	 *            the writer object used for writing OSM data
	 * @param minlat
	 *            the minimum latitude of the bounding rectangle
	 * @param minlon
	 *            the minimum longitude of the bounding rectangle
	 * @param maxlat
	 *            the maximum latitude of the bounding rectangle
	 * @param maxlon
	 *            the maximum longitude of the bounding rectangle
	 * @param nodes
	 *            the list of OSM nodes to be serialised
	 * @param ways
	 *            the list of OSM ways to be serialised
	 */
	public static void writeOSM(Writer out, double minlat, double minlon, double maxlat, double maxlon, ArrayList<OSMNode> nodes,
			ArrayList<OSMWay> ways) {
		OSMWriter writer = new OSMWriter(out);
		writer.out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		writer.out.println("<osm version=\"0.6\" generator=\"traffsim\">");
		writer.out
				.println(String.format("  <bounds minlat=\"%.7f\" minlon=\"%.7f\" maxlat=\"%.7f\" maxlon=\"%.7f\"/>", minlat, minlon, maxlat, maxlon)
						.replace(',', '.'));

		if (nodes != null) {
			for (OSMNode n : nodes) {
				writer.visit(n);
			}
		}

		if (ways != null) {
			for (OSMWay w : ways) {
				writer.visit(w);
			}
		}

		writer.out.println("</osm>");
		writer.out.flush();
	}

	/** The used writer object */
	private PrintWriter out;

	/**
	 * Initialises a new instance of {@link OSMWriter} using the given {@link Writer}.
	 *
	 * @param out
	 *            the writer object to be used for serialisation
	 */
	private OSMWriter(Writer out) {
		if (out instanceof PrintWriter) {
			this.out = (PrintWriter) out;
		} else {
			this.out = new PrintWriter(out);
		}
	}

	/**
	 * Write references to the given set of {@link OSMNode}s (required for establishing a link between OSM ways and nodes).
	 *
	 * @param nodes
	 *            the nodes to be written as reference
	 */
	private void addReferences(ArrayList<OSMNode> nodes) {
		for (OSMNode n : nodes) {
			out.println("    <nd ref=\"" + n.getId() + "\"/>");
		}
	}

	/**
	 * Serialises the given set of OSM tags.
	 *
	 * @param tags
	 *            the tags to be serialised
	 * @param tagname
	 *            the name of the tag
	 * @param tagOpen
	 *            flag to determine whether the tag is open or not
	 */
	private void addTags(Map<String, String> tags, String tagname, boolean tagOpen) {
		if (!tags.isEmpty()) {
			if (tagOpen) {
				out.println(">");
			}

			for (Iterator<String> it = tags.keySet().iterator(); it.hasNext();) {
				String key = StringEscapeUtils.escapeXml10(it.next());
				String value = StringEscapeUtils.escapeXml10(tags.get(key));
				out.println("    <tag k=\"" + key + "\" v=\"" + value + "\"/>");
			}

			out.println("  </" + tagname + ">");
		} else if (tagOpen) {
			out.println("/>");
		} else {
			out.println("  </" + tagname + ">");
		}
	}

	/**
	 * Serialises the given {@link OSMNode}.
	 *
	 * @param n
	 *            the OSM node to be serialised
	 */
	public void visit(OSMNode n) {
		out.print("  <node id=\"" + n.getId() + "\" visible=\"true\" version=\"1\"");
		out.print(" lat=\"" + n.getLatitude() + "\" lon=\"" + n.getLongitude() + "\"");
		addTags(n.getTags(), "node", true);
	}

	/**
	 * Serialises the given {@link OSMWay}.
	 *
	 * @param w
	 *            the OSM way to be serialised
	 */
	public void visit(OSMWay w) {
		out.print("  <way id=\"" + w.getId() + "\" visible=\"true\" version=\"1\"");
		out.println(">");
		addReferences(w.getNodes());
		addTags(w.getTags(), "way", false);
	}
}
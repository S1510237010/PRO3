package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.ui.BaseUiModel;
import at.fhhagenberg.mc.traffsim.ui.DrawableArtifact;
import at.fhhagenberg.mc.traffsim.ui.DrawingContext;
import at.fhhagenberg.mc.traffsim.ui.Matrix;
import at.fhhagenberg.mc.traffsim.ui.UiFlag;
import at.fhhagenberg.mc.traffsim.ui.color.ColorSet;
import at.fhhagenberg.mc.traffsim.ui.color.DimensionLessColorSet;
import at.fhhagenberg.mc.traffsim.ui.color.IElement;
import at.fhhagenberg.mc.traffsim.util.BitUtil;
import at.fhhagenberg.mc.traffsim.util.ui.AWTAdapter;
import at.fhhagenberg.mc.util.CollectionUtil;

public class InfrastructureUiModel extends BaseUiModel {

	private InfrastructureEditorView view;
	private DrawingContext drawingContext = new DrawingContext();
	private JunctionConnector currentlySelected = null;
	protected ColorSet colorSet = new DimensionLessColorSet();

	public InfrastructureUiModel(InfrastructureEditorView v) {
		this.view = v;
	}

	/**
	 * Convenience method, forceredraw is irrelevant in this implementation
	 */
	public void updateView() {
		updateView(true);
	}

	@Override
	public void updateView(final boolean forceRedraw) {
		if (view.getSelectedJunction() != null) {
			view.getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					if (view.getSelectedJunction() != null) {
						Image img = view.createAWTImage();

						AbstractJunction selectedJunction = view.getSelectedJunction();
						List<RoadSegment> rss = new ArrayList<>();
						rss.addAll(selectedJunction.getSegmentsIn());
						rss.addAll(selectedJunction.getSegmentsOut());

						for (RoadSegment rs : rss) {
							drawingContext.drawRoadSegment(rs, img.getGraphics(), transformMatrix, colorSet, BitUtil.set(0, UiFlag.LANE_DEBUG));
						}

						drawingContext.drawJunction(selectedJunction, img.getGraphics(), transformMatrix, colorSet,
								BitUtil.set(0, UiFlag.JUNCTION_DEBUG));

						view.getDrawingPanel().setImage(img);

						TrafficLight selectedTrafficLight = view.getSelectedTrafficLight();

						// Draw traffic lights
						for (JunctionConnector connector : selectedJunction.getConnectors()) {
							if (connector.getTrafficLight() != null && connector.getTrafficLight() != selectedTrafficLight) {
								drawingContext.drawTrafficLight(connector.getTrafficLight(), connector, (Graphics2D) img.getGraphics(),
										transformMatrix, false);
							} else if (connector.getTrafficLight() != null && connector.getTrafficLight() == selectedTrafficLight) {
								drawingContext.drawTrafficLight(connector.getTrafficLight(), connector, (Graphics2D) img.getGraphics(),
										transformMatrix, true);
							}
						}

						if (!view.getActiveConnectors().isEmpty()) {
							for (JunctionConnector activeConnector : view.getActiveConnectors()) {
								DrawableArtifact artifact = new DrawableArtifact(AWTAdapter.toPath2D(activeConnector.getBounds()), Color.RED,
										Color.ORANGE, new BasicStroke(4));
								artifact.setAlpha(0.4f);
								drawingContext.drawArtifact(artifact, img.getGraphics(), transformMatrix);
							}
							view.getDrawingPanel().repaint();
						}
					}
				}
			});
		} else if (view.getSelectedRoadSegment() != null) {
			view.getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					if (view.getSelectedRoadSegment() != null) {
						Image img = view.createAWTImage();
						drawingContext.drawRoadSegment(view.getSelectedRoadSegment(), img.getGraphics(), transformMatrix, colorSet,
								BitUtil.set(0, new int[] { UiFlag.LANE_DEBUG, UiFlag.SPEED_LIMITS, UiFlag.SHOW_DETECTORS }));

						Map<String, LoopDetector> loopDetectors = view.getDetectors();

						if (loopDetectors != null && !loopDetectors.isEmpty()) {

							LoopDetector selectedDetector = view.getSelectedDetector();

							for (LoopDetector detector : loopDetectors.values()) {
								if (selectedDetector == null
										|| selectedDetector != null && selectedDetector.getIdentifier() != detector.getIdentifier()) {

									Color color = colorSet.getColor(IElement.DETECTOR);

									for (Vector loc : detector.getAbsolutePositions()) {
										drawingContext.drawDetector(loc, img.getGraphics(), transformMatrix, color, 0);
									}
								}
							}

							if (selectedDetector != null) {
								for (Vector loc : selectedDetector.getAbsolutePositions()) {
									drawingContext.drawDetector(loc, img.getGraphics(), transformMatrix, Color.BLACK,
											BitUtil.set(0, new int[] { UiFlag.SELECTED }));
								}
							}
						}

						view.getDrawingPanel().setImage(img);
					}
				}
			});
		} else {
			view.getDisplay().asyncExec(new Runnable() {
				@Override
				public void run() {
					Image img = view.createAWTImage();
					view.getDrawingPanel().setImage(img);
				}
			});
		}
	}

	@Override
	public void clickedOn(Point screenCoords, int mouseOptionState) {
		if (transformMatrix == null) {
			return;
		}

		IntersectionResult result;
		if (view.getSelectedJunction() != null) {
			result = checkIntersection(view.getSelectedJunction().getAllSegments(), CollectionUtil.toArrayList(view.getSelectedJunction()),
					transformMatrix.invers().multiply(AWTAdapter.toVector(screenCoords)));
		} else {
			result = checkIntersection(CollectionUtil.toArrayList(view.getSelectedRoadSegment()),
					CollectionUtil.toArrayList(view.getSelectedJunction()), transformMatrix.invers().multiply(AWTAdapter.toVector(screenCoords)));
		}

		// TAB ROAD SIGN
		/*
		 * if multiple connectors are behind the clicked point, choose the one after the currently selected to enable walking through them
		 * by multiple clicks
		 */
		if (!result.getConnectors().isEmpty()) {
			int nextIndex = (result.getConnectors().indexOf(currentlySelected) + 1) % result.getConnectors().size();
			currentlySelected = result.getConnectors().get(nextIndex);
			view.setSelectedConnector(currentlySelected);
		}

		// TAB GEOMETRY
		view.itemsSelected(new ArrayList<AbstractJunction>(), result.getConnectors(), result.getRoadSegments(), result.getLaneSegments(),
				result.getVehicles());
	}

	/**
	 * Resets the UI to default zoom level
	 *
	 * @param newSelection
	 */
	public void updateActiveJunction(AbstractJunction newSelection) {
		if (newSelection == null) {
			return;
		}

		Rectangle bds = view.getDrawingPanel().getBounds();
		transformMatrix = Matrix.zoomToFit(newSelection.getBoundsRectangle(), bds);
		zoom(0.2);
	}

	public void zoom(double zoomFactorStep) {
		Rectangle bds = view.getDrawingPanel().getBounds();
		transformMatrix = Matrix.zoomPoint(transformMatrix, new Point(bds.width >> 1, bds.height >> 1), zoomFactorStep);
		updateView(true);
	}

	public void updateActiveRoadSegment(RoadSegment selectedRoadSegment) {
		if (selectedRoadSegment == null) {
			return;
		}

		Rectangle bds = view.getDrawingPanel().getBounds();
		transformMatrix = Matrix.zoomToFit(selectedRoadSegment.getBounds().getBounds(), bds);
		zoom(0.9);
	}
}

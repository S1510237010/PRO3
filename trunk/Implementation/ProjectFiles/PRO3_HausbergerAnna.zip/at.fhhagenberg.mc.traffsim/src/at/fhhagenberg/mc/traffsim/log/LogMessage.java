package at.fhhagenberg.mc.traffsim.log;

import java.util.Date;

import at.fhhagenberg.mc.util.DateUtil;

/**
 * Class representing a log message being composed of a message and a date.
 *
 * @author Christian Backfrieder
 */
public class LogMessage {

	/** The log message's date */
	private Date date;

	/** The actual log message */
	private String message;

	/**
	 * Instantiates a new {@link LogMessage} with the given date and message.
	 *
	 * @param date
	 *            the log message's date
	 * @param message
	 *            the actual log message
	 */
	public LogMessage(Date date, String message) {
		super();
		this.date = date;
		this.message = message;
	}

	/**
	 * Instantiates a new {@link LogMessage} with the given message.
	 *
	 * @param message
	 *            the actual log message
	 */
	public LogMessage(String message) {
		this(new Date(), message);
	}

	/**
	 * NOTE: Equality is verified by considering the log message's text only
	 * (not the date).
	 *
	 * @param obj
	 *            the object to be checked for equality
	 * @return true, if equal - false else
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		LogMessage other = (LogMessage) obj;

		if (message == null) {
			if (other.message != null) {
				return false;
			}
		} else if (!message.equals(other.message)) {
			return false;
		}

		return true;
	}

	/**
	 * Gets the a formatted string representation of the log message in the
	 * format <i>yyyy-MM-dd HH:mm:ss.SSS</i>.
	 *
	 * @return the log message's formatted string representation
	 */
	public String getFullMessage() {
		return DateUtil.formatWithMiliseconds(date, false) + ": " + message;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (message == null ? 0 : message.hashCode());
		return result;
	}
}
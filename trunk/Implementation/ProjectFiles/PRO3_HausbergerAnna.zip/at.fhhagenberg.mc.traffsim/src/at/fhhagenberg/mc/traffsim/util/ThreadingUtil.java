package at.fhhagenberg.mc.traffsim.util;

import java.util.Collection;
import java.util.function.Consumer;

import at.fhhagenberg.mc.traffsim.log.Logger;

public class ThreadingUtil {
	/**
	 * Executes an action for each element of the provided collection. The option whether parallel or serial execution is chosen according
	 * to the setup preferences within TraffSim.
	 *
	 * @param coll
	 *            The collection of objects for which the action should be executed
	 * @param action
	 *            the action to be executed for each item
	 * @param description
	 *            description of the task, in case an error occurs
	 * @param forceSerialExecution
	 *            if <code>true</code>, the collection is traversed serially independent of the preference setting
	 */
	public static <T> void executeAction(Collection<T> coll, Consumer<T> action, String description, boolean forceSerialExecution) {
		try {
			if (forceSerialExecution) {
				coll.forEach(action);
			} else {
				coll.parallelStream().forEach(action);
			}
		} catch (Exception e) {
			Logger.logError("error occured while " + description, e);
		}
	}

	/**
	 * @see #executeAction(Collection, Consumer, String, boolean) with default parameter <code>false</code> for force serial execution
	 *
	 * @param coll
	 * @param action
	 * @param description
	 */
	public static <T> void executeAction(Collection<T> coll, Consumer<T> action, String description) {
		executeAction(coll, action, description, false);
	}
}

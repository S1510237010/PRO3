package at.fhhagenberg.mc.traffsim.util.ui;

import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;

/**
 * Conversion utility which acts as an interface for the conversion between local classes and AWT classes.
 *
 * @author Christian Backfrieder
 */
public class AWTAdapter {

	/**
	 * Converts the given list of vectors (@see Vector) into a general path (@see GeneralPath).
	 *
	 * @param pointList
	 *            the list of vectors to be converted
	 * @return the resulting general path
	 */
	public static GeneralPath toPath(List<Vector> pointList) {
		GeneralPath path = new GeneralPath();

		if (pointList.isEmpty()) {
			return path;
		}

		Iterator<Vector> it = pointList.iterator();
		Vector vector = it.next();
		path.moveTo(vector.x, vector.y);

		while (it.hasNext()) {
			vector = it.next();
			path.lineTo(vector.x, vector.y);
		}

		return path;
	}

	/**
	 * Converts the given list of vectors (@see Vector) into a path2D double (@see Path2D.Double).
	 *
	 * @param pointList
	 *            the list of vectors to be converted
	 * @return the resulting path2D double
	 */
	public static Path2D.Double toPath2D(List<Vector> pointList) {
		Path2D.Double path = new Path2D.Double();

		if (pointList == null || pointList.isEmpty()) {
			return path;
		}

		Iterator<Vector> it = pointList.iterator();
		Vector vector = it.next();
		path.moveTo(vector.x, vector.y);

		while (it.hasNext()) {
			vector = it.next();
			path.lineTo(vector.x, vector.y);
		}

		return path;
	}

	/**
	 * Converts the given vector (@see Vector) into a point (@see Point).
	 *
	 * @param vec
	 *            the vector to be converted
	 * @return the resulting point
	 */
	public static Point toPoint(Vector vec) {
		return new Point((int) vec.x, (int) vec.y);
	}

	/**
	 * Converts the given vector (@see Vector) into a point2D (@see Point2D).
	 *
	 * @param vec
	 *            the vector to be converted
	 * @return the resulting point2D
	 */
	public static Point2D toPoint2D(Vector vec) {
		return new Point2D.Double(vec.x, vec.y);
	}

	/**
	 * Converts the given list of vectors (@see Vector) into a polygon (@see Polygon).
	 *
	 * @param pointList
	 *            the list of vectors to be converted
	 * @return the resulting polygon
	 */
	public static Polygon toPolygon(List<Vector> pointList) {
		if (pointList == null) {
			return null;
		}

		Polygon poly = new Polygon();

		for (Vector vector : pointList) {
			poly.addPoint((int) vector.x, (int) vector.y);
		}

		return poly;
	}
	
	public static Ellipse2D toEllipse(Vector vector, double radius){
		if(vector == null){
			return null;
		}
		
		Ellipse2D ellipse = new Ellipse2D.Double(vector.x - radius, vector.y - radius, 2 * radius, 2 * radius);
		return ellipse;
	}

	/**
	 * Converts the given rectangle (@see Rectangle) into a polygon (@see Polygon).
	 *
	 * @param rect
	 *            the rectangle to be converted
	 * @return the resulting polygon
	 */
	public static Polygon toPolygon(Rectangle rect) {
		Polygon result = new Polygon();
		result.addPoint(rect.x, rect.y);
		result.addPoint(rect.x + rect.width, rect.y);
		result.addPoint(rect.x + rect.width, rect.y + rect.height);
		result.addPoint(rect.x, rect.y + rect.height);
		return result;
	}

	/**
	 * Converts the given list of vectors (@see Vector) into a rectangle (@see Rectangle).
	 *
	 * @param bounds
	 *            the list of vectors to be converted
	 * @return the resulting rectangle
	 */
	public static Rectangle toRectangle(List<Vector> bounds) {
		if (bounds == null || bounds.size() == 0) {
			return null;
		}

		Rectangle rect = new Rectangle(toPoint(bounds.get(0)));

		for (Vector vector : bounds) {
			rect.add(toPoint(vector));
		}

		return rect;
	}

	/**
	 * Converts the given list of vectors (@see Vector) into a rectangle2D (@see Rectangle2D).
	 *
	 * @param bounds
	 *            the list of vectors to be converted
	 * @return the resulting rectangle2D
	 */
	public static Rectangle2D toRectangle2D(List<Vector> bounds) {
		if (bounds == null || bounds.size() == 0) {
			return null;
		}

		Point2D init = toPoint2D(bounds.get(0));
		Rectangle2D rect = new Rectangle2D.Double(init.getX(), init.getY(), 0, 0);

		for (Vector vector : bounds) {
			rect.add(toPoint2D(vector));
		}

		return rect;
	}

	/**
	 * Converts the given point (@see Point) into a vector (@see Vector).
	 *
	 * @param pt
	 *            the point to be converted
	 * @return the resulting vector
	 */
	public static Vector toVector(Point pt) {
		return new Vector(pt.x, pt.y);
	}

	/**
	 * Converts the given rectangle (@see Rectangle) into a list of vectors (@see Vector).
	 *
	 * @param rect
	 *            the rectangle to be converted
	 * @return the resulting list of vectors
	 */
	public static List<Vector> toVectorList(Rectangle rect) {
		List<Vector> result = new ArrayList<>();
		Polygon p = toPolygon(rect);

		for (int i = 0; i < p.npoints; i++) {
			result.add(new Vector(p.xpoints[i], p.ypoints[i]));
		}

		return result;
	}
}
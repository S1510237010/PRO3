package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.io.File;
import java.util.Properties;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;

import at.fhhagenberg.mc.traffsim.data.beans.BeanConfigurationContainer;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.dialogs.LoadDialog;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class OpenConfigCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// unused

	}

	@Override
	public void dispose() {
		// unused

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		FileDialog dialog = new FileDialog(Display.getCurrent().getActiveShell(), SWT.MULTI);
		dialog.setText("Open configuration file");
		dialog.setFilterExtensions(new String[] { Constants.FILE_FILTER_TRAFFSIM_XML });
		dialog.setFilterNames(new String[] { Constants.FILTER_NAME_TRAFFSIM });
		dialog.open();
		for (String selected : dialog.getFileNames()) {
			if (selected != null) {
				File selectedFile = new File(dialog.getFilterPath(), selected);
				DataSerializer ser = new DataSerializer();
				ser.readConfiguration(selectedFile);
				TraffSimConfiguration conf = ser.getConfiguration();
				conf.setConfigurationFile(selectedFile);
				BeanConfigurationContainer container = conf.getBeanConfigurationsMapping().get(InfrastructureBean.class.getName());
				String name = container != null ? container.getFileName() : null;
				boolean geomAvailable = name != null && new File(conf.getConfigurationFile().getParentFile(), name).exists();

				if (PreferenceUtil.getBoolean(IPreferenceConstants.SHOW_LOADING_OPTIONS_DIALOG)) {
					LoadDialog loadDialog = new LoadDialog(Display.getCurrent().getActiveShell(), geomAvailable);
					int result = loadDialog.open();
					if (result == Dialog.CANCEL) {
						return null;
					}
				}
				Properties properties = new Properties();
				properties.put(PropertyKeys.RESET_GEOMETRY,
						!geomAvailable || (geomAvailable && PreferenceUtil.getBoolean(IPreferenceConstants.RESET_GEOMETRY_ON_LOAD)));
				properties.put(PropertyKeys.GLOBAL_OUTPUT_FOLDER, PreferenceUtil.getString(IPreferenceConstants.GLOBAL_OUTPUT_FOLDER));
				SimulationKernel.getInstance().createNewSimulation(selectedFile, properties);
			}
		}
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// unused

	}

}

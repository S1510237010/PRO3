package at.fhhagenberg.mc.traffsim.generator;

import java.util.HashSet;
import java.util.Set;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.types.IDisposable;

/**
 * Base class for vehicle generators. Capable of notifying a number of registered {@link IVehicleGeneratorListener}s when a new vehicle is
 * generated and added to the simulation.
 *
 * @author Christian Backfrieder
 */
public abstract class AbstractVehicleGenerator implements ISimulationTimeUpdatable, IDisposable {

	public static long NEXT_GENERATOR_ID = 0;

	/** The generator's unique identifier */
	private long id;

	/** Set of listeners which are notified upon a new vehicle is generated */
	private Set<IVehicleGeneratorListener> listeners = new HashSet<>();

	/** The associated simulation model */
	protected SimulationModel model;

	/**
	 * Registers the given {@link IVehicleGeneratorListener} to be notified upon vehicle generation.
	 *
	 * @param listener
	 *            the listener to be notified upon vehicle generation
	 */
	public void addVehicleObserver(IVehicleGeneratorListener listener) {
		listeners.add(listener);
	}

	/**
	 * Gets the generator's unique identifier
	 *
	 * @return the unique identifier
	 */
	public long getId() {
		return id;
	}

	/**
	 * Gets the set of currently registered {@link IVehicleGeneratorListener}s.
	 *
	 * @return the currently registered listeners
	 */
	public Set<IVehicleGeneratorListener> getListeners() {
		return listeners;
	}

	/**
	 * Indicates whether this vehicle generator has more vehicles to generate. This is used to determine the end of a simulation.
	 *
	 * @return true if the there are still more vehicles to be generated - false else
	 */
	public abstract boolean hasMoreVehicles();

	/**
	 * Notifies all registered {@link IVehicleGeneratorListener}s that the given {@link Vehicle} has been generated.
	 *
	 * @param v
	 *            the vehicle which was generated recently
	 */
	protected void notifyVehicleGenerated(Vehicle v) {
		for (IVehicleGeneratorListener vl : listeners) {
			vl.vehicleGenerated(v);
		}

		if (!hasMoreVehicles()) {
			for (AbstractVehicleGenerator gen : model.getTrafficGenerators(true)) {
				if (gen.hasMoreVehicles()) {
					return;
				}
			}

			// no more vehicles -> last vehicle generated
			model.logEvent(EventType.LAST_VEHICLE_GENERATED, "generated last vehicle " + v.getUniqueId() + " (lbl " + v.getLabel() + ")");
		}
	}

	/**
	 * Unregisters the given {@link IVehicleGeneratorListener} from being notified upon vehicle generation.
	 *
	 * @param listener
	 *            the listener to be unregistered
	 */
	public void removeVehicleObserver(IVehicleGeneratorListener listener) {
		listeners.remove(listener);
	}

	/**
	 * Sets the generator's unique identifier.
	 *
	 * @param id
	 *            the new identifier
	 */
	protected void setId(long id) {
		this.id = id;
	}

	/**
	 * Sets the generator's associated {@link SimulationModel}.
	 *
	 * @param simulationModel
	 *            the new simulation model
	 */
	public void setSimulationModel(SimulationModel simulationModel) {
		this.model = simulationModel;
	}
}
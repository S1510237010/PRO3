package at.fhhagenberg.mc.traffsim.statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;

public class JunctionApproachStatisticsData implements Serializable {

	private static final long serialVersionUID = 7630408927145231445L;

	protected final long approachId;
	protected final long junctionId;
	protected List<Double> time = new ArrayList<>();
	protected List<Double> averageLoad = new ArrayList<>();
	protected List<Double> countOutflow = new ArrayList<>();
	protected List<Double> countExpected = new ArrayList<>();
	protected List<Double> countUpstream = new ArrayList<>();
	protected List<Double> queueLength = new ArrayList<>();
	protected List<Double> flowAverage30s = new ArrayList<>();
	protected List<Double> flowAverage10min = new ArrayList<>();
	protected List<Double> waitingTimeTotal = new ArrayList<>();
	protected List<Double> waitingTimeSinceQueueEmpty = new ArrayList<>();

	protected long recordedItems;

	public JunctionApproachStatisticsData() {
		approachId = -1;
		junctionId = -1;
	}

	public JunctionApproachStatisticsData(long approachId, long junctionId) {
		this.approachId = approachId;
		this.junctionId = junctionId;
	}

	public long getApproachId() {
		return approachId;
	}

	public long getJunctionId() {
		return junctionId;
	}

	public List<Double> getTime() {
		return time;
	}

	public List<Double> getAverageLoad() {
		return averageLoad;
	}

	public List<Double> getCountOutFlow() {
		return countOutflow;
	}

	public List<Double> getCountExpected() {
		return countExpected;
	}

	public List<Double> getCountUpstream() {
		return countUpstream;
	}

	public List<Double> getQueueLength() {
		return queueLength;
	}

	public List<Double> getFlowAverage30s() {
		return flowAverage30s;
	}

	public List<Double> getFlowAverage10min() {
		return flowAverage10min;
	}

	public List<Double> getWaitingTimeTotal() {
		return waitingTimeTotal;
	}

	public List<Double> getWaitingTimeSinceQueueEmpty() {
		return waitingTimeSinceQueueEmpty;
	}

	public synchronized void addData(double time, JunctionApproach approach) {
		Map<String, Number> data = approach.getQueueMonitor().obtainStatistics();
		this.averageLoad.add((double) data.get(IStatsConstants.QUEUE_MONITOR_AVERAGE_LOAD));
		this.countOutflow.add((double) data.get(IStatsConstants.QUEUE_MONITOR_COUNT_OUTFLOW));
		this.countExpected.add((double) data.get(IStatsConstants.QUEUE_MONITOR_COUNT_EXPECTED));
		this.countUpstream.add((double) data.get(IStatsConstants.QUEUE_MONITOR_COUNT_UPSTREAM));
		this.queueLength.add((double) data.get(IStatsConstants.QUEUE_MONITOR_QUEUE_LENGTH));
		this.flowAverage30s.add((double) data.get(IStatsConstants.QUEUE_MONITOR_FLOW_AVG_30_SEC));
		this.flowAverage10min.add((double) data.get(IStatsConstants.QUEUE_MONITOR_FLOW_AVG_10_MIN));
		this.waitingTimeTotal.add((double) data.get(IStatsConstants.QUEUE_MONITOR_WAITING_TIME_TOTAL));
		this.waitingTimeSinceQueueEmpty.add((double) data.get(IStatsConstants.QUEUE_MONITOR_WAITING_TIME_SINCE_QUEUE_EMPTY));
		this.time.add(time);
		recordedItems++;
	}

	public JunctionApproachStatisticsData collectData(int numItemsToKeep) {
		JunctionApproachStatisticsData data = new JunctionApproachStatisticsData(approachId, junctionId);
		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.time.addAll(time.subList(0, numItems));
				data.averageLoad.addAll(averageLoad.subList(0, numItems));
				data.countOutflow.addAll(countOutflow.subList(0, numItems));
				data.countExpected.addAll(countExpected.subList(0, numItems));
				data.countUpstream.addAll(countUpstream.subList(0, numItems));
				data.queueLength.addAll(queueLength.subList(0, numItems));
				data.flowAverage30s.addAll(flowAverage30s.subList(0, numItems));
				data.flowAverage10min.addAll(flowAverage10min.subList(0, numItems));
				data.waitingTimeTotal.addAll(waitingTimeTotal.subList(0, numItems));
				data.waitingTimeSinceQueueEmpty.addAll(waitingTimeSinceQueueEmpty.subList(0, numItems));

				// remove the collected sublist from statistics data
				time = new ArrayList<>(time.subList(numItems, lastIndex));
				averageLoad = new ArrayList<>(averageLoad.subList(numItems, lastIndex));
				countOutflow = new ArrayList<>(countOutflow.subList(numItems, lastIndex));
				countExpected = new ArrayList<>(countExpected.subList(numItems, lastIndex));
				countUpstream = new ArrayList<>(countUpstream.subList(numItems, lastIndex));
				queueLength = new ArrayList<>(queueLength.subList(numItems, lastIndex));
				flowAverage30s = new ArrayList<>(flowAverage30s.subList(numItems, lastIndex));
				flowAverage10min = new ArrayList<>(flowAverage10min.subList(numItems, lastIndex));
				waitingTimeTotal = new ArrayList<>(waitingTimeTotal.subList(numItems, lastIndex));
				waitingTimeSinceQueueEmpty = new ArrayList<>(waitingTimeSinceQueueEmpty.subList(numItems, lastIndex));

				data.recordedItems = recordedItems;
			}
		}

		return data;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

public enum BatteryType {
	LEADACID("Lead Acid"), NICKELBASED("Nickel based");

	private String type;

	private BatteryType(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type;
	}

	public static BatteryType valueOfLabel(String label) {
		for (BatteryType t : BatteryType.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}
		return null;
	}
}

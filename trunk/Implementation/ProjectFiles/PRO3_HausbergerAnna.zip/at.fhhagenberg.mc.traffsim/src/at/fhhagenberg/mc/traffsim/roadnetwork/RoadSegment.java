package at.fhhagenberg.mc.traffsim.roadnetwork;

import java.awt.Polygon;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.IRoadStatisticsChangedListener;
import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.statistics.LaneStatisticsData;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.exceptions.SpatialException;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle.VehicleProperties;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeDecision;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class RoadSegment implements IRoadStatisticsChangedListener {

	private static final double CORRECTION_LENGTH_ON_LANE_DIFFERENCE = 7;
	public static long NEXT_ID = 0;
	private long id;
	private List<LaneSegment> laneSegments = new ArrayList<>();
	private RoadGeometry roadGeometry;

	private RoadSegment sourceRoadSegment;
	private RoadSegment sinkRoadSegment;

	private AbstractJunction junction;

	private int laneCount;
	private long routingId;

	// TODO: this must be defined in road segment input!
	private double laneWidth = TrafficDefaults.DEFAULT_LANE_WIDTH;

	private double speedLimitKmh = Double.POSITIVE_INFINITY;
	private Polygon bounds;

	private Set<IRoadStatisticsChangedListener> roadListeners = new HashSet<>();

	/** the streetname */
	private String name;

	private Node startNode, endNode;
	private Double slope = null;

	private boolean osmReverse;
	private Rectangle boundsRect;

	private boolean oneWay;
	private double roadWidth;
	private AbstractJunction sourceJunction;

	public RoadSegment(RoadGeometry geom, int laneCount) {
		this(geom, laneCount, NEXT_ID++);
	}

	public RoadSegment(RoadGeometry geom, int laneCount, long id) {
		roadGeometry = geom;
		this.laneCount = laneCount;
		for (int i = 0; i < laneCount; i++) {
			LaneSegment ls = new LaneSegment(this, i, Lane.Type.TRAFFIC, new RoadGeometry(geom));
			laneSegments.add(ls);
		}
		this.id = id;
		NEXT_ID = id + 1;
		updateLaneGeometries();
	}

	/**
	 * Constructor for already generated lane segments
	 * 
	 * @param geom
	 * @param lanes
	 * @param id
	 */
	public RoadSegment(RoadGeometry geom, List<LaneSegment> lanes, long id) {
		roadGeometry = geom;
		this.laneCount = lanes.size();
		for (LaneSegment ls : lanes) {
			ls.setRoadSegment(this);
		}
		laneSegments = lanes;
		this.id = id;
		updateBounds();
	}

	/**
	 * 
	 * @return the average slope of this segment, in radians. A positive value means hill upwards, a negative value hill downwards.
	 */
	public double getSlope() {
		if (slope == null) {
			if (endNode == null || startNode == null) {
				slope = new Double(0);
			} else {
				slope = Math.atan2(endNode.getAltitude() - startNode.getAltitude(), getRoadLength());
				if (Double.isNaN(slope)) {
					// still NaN? no altitudes availalbe.
					slope = new Double(0);
				}
			}
		}
		return slope;
	}

	public double getSlopePercentage() {
		return Math.tan(getSlope()) * 100;
	}

	public int getLaneCount() {
		return laneSegments.size();
	}

	public double getMinLaneLength() {
		double roadLength = Double.POSITIVE_INFINITY;

		for (LaneSegment segment : laneSegments) {
			if (segment.getRoadGeometry().getRoadLength() < roadLength) {
				roadLength = segment.getRoadGeometry().getRoadLength();
			}
		}

		return roadLength;
	}

	public double getRoadLength() {
		return roadGeometry.getRoadLength();
	}

	/**
	 * Force adding the vehicle to given lane
	 * 
	 * @param v
	 * @param laneIndex
	 * @return <code>true</code> if the vehicle was added, <code>false</code> if the lane index was out of range
	 */
	public boolean addVehicle(Vehicle v, int laneIndex) {
		if (laneIndex >= laneCount) {
			return false;
		}
		laneSegments.get(laneIndex).addVehicle(v);
		v.setRoadSegment(this);
		return true;
	}

	public void makeLaneChanges(double dt, Date time) {
		for (LaneSegment seg : laneSegments) {
			HashMap<Vehicle, LaneChangeDecision> decisions = new HashMap<>();
			for (Iterator<Vehicle> vehIterator = seg.iterator(); vehIterator.hasNext();) {
				Vehicle vehicle = vehIterator.next();

				LaneChangeDecision decision = vehicle.considerLaneChange();
				if (decision.getUrgency() != -1) {
					vehicle.setProperty(VehicleProperties.SLOW_DOWN_PERCENTAGE_DUE_TO_LANE_CHANGE.name(),
							String.valueOf(decision.getUrgency()));
				}
				decisions.put(vehicle, decision);
			}
			for (Vehicle vehicle : decisions.keySet()) {
				LaneChangeDecision decision = decisions.get(vehicle);
				if (decision.getDirection() == Lane.TO_LEFT || decision.getDirection() == Lane.TO_RIGHT) {
					vehicle.clearProperty(VehicleProperties.SLOW_DOWN_PERCENTAGE_DUE_TO_LANE_CHANGE.name());
					vehicle.clearProperty(VehicleProperties.LANE_CHANGE_URGENCY.name());
					vehicle.clearProperty(VehicleProperties.PENDING_MANDATORY_LANE_CHANGE.name());
				}
				switch (decision.getDirection()) {
				case Lane.TO_LEFT:
					LaneSegment newLeftLaneSegment = vehicle.getRoadSegment().getLaneSegments().get(vehicle.getLaneIndex() - 1);
					vehicle.setInProcessOfLaneChange(-TrafficDefaults.LANE_CHANGE_TIME);
					seg.getVehicles().remove(vehicle);
					// System.out.println(vehicle.getLabel() + " removed RS " + vehicle.getRoadSegment().getId() + " lane "
					// + vehicle.getLaneIndex() + " front pos " + vehicle.getFrontPosition());
					vehicle.setFrontPosition(
							SpatialUtil.translatePosition(vehicle.getLaneSegment(), newLeftLaneSegment, vehicle.getFrontPosition()));
					// System.out.println(vehicle.getLabel() + " set front RS " + vehicle.getRoadSegment().getId() + " lane "
					// + vehicle.getLaneIndex());
					newLeftLaneSegment.addVehicle(vehicle);
					// System.out.println(vehicle.getLabel() + " added RS " + vehicle.getRoadSegment().getId() + " lane "
					// + vehicle.getLaneIndex() + " front pos " + vehicle.getFrontPosition());
					// System.out.println(vehicle.getLabel() + " to left");
					// vehicle.updateGeometry();
					break;
				case Lane.TO_RIGHT:
					LaneSegment newRightLaneSegment = vehicle.getRoadSegment().getLaneSegments().get(vehicle.getLaneIndex() + 1);
					vehicle.setInProcessOfLaneChange(TrafficDefaults.LANE_CHANGE_TIME);
					vehicle.clearProperty(VehicleProperties.SLOW_DOWN_PERCENTAGE_DUE_TO_LANE_CHANGE.name());
					seg.getVehicles().remove(vehicle);
					vehicle.setFrontPosition(
							SpatialUtil.translatePosition(vehicle.getLaneSegment(), newRightLaneSegment, vehicle.getFrontPosition()));
					newRightLaneSegment.addVehicle(vehicle);
					// System.out.println(vehicle.getLabel() + "to right ");
					vehicle.updateGeometry();
				default:
					break;
				}
			}
		}
	}

	public void updateSpeedsAndPositions(double dt, Date time) {
		for (LaneSegment seg : laneSegments) {
			for (Iterator<Vehicle> vehIterator = seg.iterator(); vehIterator.hasNext();) {
				vehIterator.next().updateSpeedAndPosition(dt, time);
			}
		}
	}

	public void updateAccelerations(double dt, double runTime) {
		for (LaneSegment seg : laneSegments) {
			for (Iterator<Vehicle> vehIterator = seg.iterator(); vehIterator.hasNext();) {
				vehIterator.next().updateAcceleration(dt, runTime);
			}
		}
	}

	public double angleAt(double position) {
		return roadGeometry.angleAt(position);
	}

	public RoadGeometry getRoadGeometry() {
		return roadGeometry;
	}

	public List<LaneSegment> getLaneSegments() {
		return laneSegments;
	}

	public LaneSegment getLeftMostLane() {
		if (laneSegments.size() > 0) {
			return laneSegment(0);
		}
		return null;
	}

	/**
	 * Sets the current lane segments of this road segment, and ensures that each {@link LaneSegment} has the correct {@link RoadSegment}
	 * -affinity
	 * 
	 * @param laneSegments
	 */
	public void setLaneSegments(List<LaneSegment> laneSegments) {
		// ensure the correct affinity of lanesegment to roadsegment
		if (laneSegments != null) {
			for (LaneSegment laneSegment : laneSegments) {
				laneSegment.setRoadSegment(this);
			}
		}
		this.laneSegments = laneSegments;
	}

	public RoadSegment getSourceRoadSegment() {
		return sourceRoadSegment;
	}

	public void setSourceRoadSegment(RoadSegment newSourceRoadSegment) {

		this.sourceRoadSegment = newSourceRoadSegment;
		if (newSourceRoadSegment == null) {
			return;
		}
		for (int i = 0; i < laneCount; i++) {
			if (newSourceRoadSegment.laneCount > i) {
				laneSegments.get(i).setSourceLaneSegment(newSourceRoadSegment.laneSegments.get(i));
				newSourceRoadSegment.laneSegments.get(i).setSinkLaneSegment(laneSegments.get(i));
			}
		}
		if (newSourceRoadSegment.getSinkRoadSegment() != this) {
			newSourceRoadSegment.setSinkRoadSegment(this);
		}
		updateLaneGeometries();
	}

	public RoadSegment getSinkRoadSegment() {
		return sinkRoadSegment;
	}

	public void setSinkRoadSegment(RoadSegment newSinkRoadSegment) {
		this.sinkRoadSegment = newSinkRoadSegment;
		if (newSinkRoadSegment == null) {
			return;
		}
		for (int i = 0; i < laneCount; i++) {
			if (newSinkRoadSegment.laneCount > i) {
				laneSegments.get(i).setSinkLaneSegment(newSinkRoadSegment.laneSegments.get(i));
				newSinkRoadSegment.laneSegments.get(i).setSourceLaneSegment(laneSegments.get(i));
			}
		}
		if (newSinkRoadSegment.getSourceRoadSegment() != this) {
			newSinkRoadSegment.setSourceRoadSegment(this);
		}
		updateLaneGeometries();
	}

	public void updateLaneGeometries() {
		boolean addedFront = false;
		boolean addedBack = false;
		if (roadGeometry == null || roadGeometry.getPoints().size() < 2) {
			Logger.logWarn("Found empty road geometry in RS " + id + " routing ID " + routingId);
			return;
		}
		List<Vector> extendedPoints = new ArrayList<>(roadGeometry.getPoints());
		if (sourceRoadSegment != null && sourceRoadSegment.getRoadGeometry() != null) {
			List<Vector> sourcePoints = sourceRoadSegment.getRoadGeometry().getPoints();
			if (sourcePoints.get(sourcePoints.size() - 1).equals(extendedPoints.get(0))) {
				extendedPoints.add(0, sourcePoints.get(sourcePoints.size() - 2));
			} else {
				extendedPoints.add(0, sourcePoints.get(sourcePoints.size() - 1));
			}
			addedFront = true;
		}
		if (sinkRoadSegment != null && sinkRoadSegment.getRoadGeometry() != null) {
			List<Vector> sinkPoints = sinkRoadSegment.getRoadGeometry().getPoints();
			if (sinkPoints.get(0).equals(extendedPoints.get(extendedPoints.size() - 1))) {
				extendedPoints.add(sinkPoints.get(1));
			} else {
				extendedPoints.add(0, sinkPoints.get(0));
			}
			addedBack = true;
		}
		double simplificationTolerance = PreferenceUtil.getDouble(IPreferenceConstants.NETWORK_SIMPLIFICATION_TOLERANCE) / 10;
		if (simplificationTolerance > 0) {
			try {
				List<Vector> pts = SpatialUtil.simplifyCurve(roadGeometry.getPoints(), simplificationTolerance);
				roadGeometry.setPoints(pts);
			} catch (SpatialException e) {
				Logger.logWarn("Continuing without simplification of RS " + getId(), e);
			}
		}
		for (int i = 0; i < laneCount; i++) {
			// Logger.logInfo("Creating lane segments for RS " + getId());
			List<Vector> points = null;
			List<Vector> leftEdge = null;
			List<Vector> rightEdge = null;
			try {
				points = SpatialUtil.createOffsetCurve(extendedPoints, -laneWidth * (2 * (i + 1) - 1) / 2, true);
				leftEdge = SpatialUtil.createOffsetCurve(extendedPoints, -laneWidth * i, true);
				rightEdge = SpatialUtil.createOffsetCurve(extendedPoints, -laneWidth * (i + 1), true);
			} catch (SpatialException e) {
				Logger.logError("Could not create offset curve for lane", e);
				break;
			}
			/** only remove self intersections outside */

			if (addedFront) {
				points.remove(0);
				leftEdge.remove(0);
				rightEdge.remove(0);
			}
			if (addedBack) {
				points.remove(points.size() - 1);
				leftEdge.remove(leftEdge.size() - 1);
				rightEdge.remove(rightEdge.size() - 1);

			}
			// check if segment after this or segment before has more lanes
			if (sinkRoadSegment != null && sinkRoadSegment.getLaneCount() > this.getLaneCount() && i == laneCount - 1) {
				Vector ptStart = CollectionUtil.getLastObject(rightEdge).moveTowards(CollectionUtil.getSecondToLastObject(rightEdge),
						CORRECTION_LENGTH_ON_LANE_DIFFERENCE);
				if (rightEdge.size() > 1) {
					double origLength = SpatialUtil.getLength(rightEdge);
					while (rightEdge.size() > 0
							&& origLength - SpatialUtil.getLength(rightEdge) < CORRECTION_LENGTH_ON_LANE_DIFFERENCE * 1.1) {
						rightEdge.remove(rightEdge.size() - 1);
					}
					rightEdge.add(ptStart);
				}
				rightEdge.add(CollectionUtil.getFirstObject(sinkRoadSegment.getRightMostLane().getRightEdge()));
			}
			if (sourceRoadSegment != null && sourceRoadSegment.getLaneCount() > this.getLaneCount()) {
				Vector ptStart = CollectionUtil.getFirstObject(rightEdge).moveTowards(CollectionUtil.getSecondObject(rightEdge),
						CORRECTION_LENGTH_ON_LANE_DIFFERENCE);
				if (rightEdge.size() > 1) {
					double origLength = SpatialUtil.getLength(rightEdge);
					while (origLength - SpatialUtil.getLength(rightEdge) < CORRECTION_LENGTH_ON_LANE_DIFFERENCE * 1.1) {
						rightEdge.remove(0);
					}
					rightEdge.add(0, ptStart);
				}
				rightEdge.add(0, CollectionUtil.getLastObject(sourceRoadSegment.getRightMostLane().getRightEdge()));
			}

			if (simplificationTolerance > 0) {
				try {
					points = SpatialUtil.simplifyCurve(points, simplificationTolerance);
					leftEdge = SpatialUtil.simplifyCurve(leftEdge, simplificationTolerance);
					rightEdge = SpatialUtil.simplifyCurve(rightEdge, simplificationTolerance);
				} catch (SpatialException e) {
					Logger.logWarn("Could not simplify curve", e);
				}
			}
			if (laneSegments.size() > i) {
				laneSegments.get(i).getRoadGeometry().setPoints(points);
				laneSegments.get(i).setLeftEdge(leftEdge);
				laneSegments.get(i).setRightEdge(rightEdge);
				laneSegments.set(i, filterPoints(laneSegments.get(i)));
			}
		}

		updateBounds();
	}

	/**
	 * This method ensures that no points occur in two consecutive lane segments due to appending points for edge compensation
	 * 
	 * Example: SOURCE: ___....... <br>
	 * _____________LS: _______..........<br>
	 * ___________SINK: _______________....... <br>
	 * ________returns: _________.......
	 * 
	 * @param laneSegment
	 * @return lanesegment, with middle points filtered
	 */
	private LaneSegment filterPoints(LaneSegment laneSegment) {
		List<Vector> points = laneSegment.getRoadGeometry().getModifiablePoints();
		if (laneSegment.getSourceLaneSegment() != null && laneSegment.getSourceLaneSegment().getRoadGeometry() != null) {
			List<Vector> sourcePoints = laneSegment.getSourceLaneSegment().getRoadGeometry().getPoints();
			Vector lastRemoved = null;
			for (int i = 0; i < sourcePoints.size(); i++) {
				if (points.contains(sourcePoints.get(i))) {
					lastRemoved = sourcePoints.get(i);
					points.remove(sourcePoints.get(i));
				}
			}
			if (lastRemoved != null) {
				points.add(0, lastRemoved);
			}
		}
		if (laneSegment.getSinkLaneSegment() != null && laneSegment.getSinkLaneSegment().getRoadGeometry() != null) {
			List<Vector> sinkPoints = laneSegment.getSinkLaneSegment().getRoadGeometry().getPoints();
			Vector lastRemoved = null;
			for (int i = sinkPoints.size() - 1; i >= 0; i--) {
				if (points.contains(sinkPoints.get(i))) {
					lastRemoved = sinkPoints.get(i);
					points.remove(sinkPoints.get(i));
				}
			}
			if (lastRemoved != null) {
				points.add(lastRemoved);
			}
		}
		laneSegment.getRoadGeometry().geometryChanged();
		return laneSegment;
	}

	public LaneSegment laneSegment(int lane) {
		try {
			return laneSegments.get(lane);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}

	public AbstractJunction getJunction() {
		return junction;
	}

	public void setJunction(AbstractJunction abstractJunction) {
		this.junction = abstractJunction;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		String sourceId = "Source: " + (sourceRoadSegment != null ? "RS-" + sourceRoadSegment.getId() + " (ND-" + startNode.getId() + ")"
				: startNode != null ? "ND-" + startNode.getId() : "none");
		String sinkId = "Sink: " + (sinkRoadSegment != null ? "RS-" + sinkRoadSegment.getId() + " (ND-" + endNode.getId() + ")"
				: endNode != null ? "ND-" + endNode.getId() : "none");

		return String.format(
				"RoadSegment %d (%s)\nRouting ID  %d, %d lane%s\n%s | %s\nSlope: %.2f %%, Length: %.2fm\nSpeed limit: %.2fkm/h, reverse: %s",
				id, StringUtil.ensureNotEmpty(name, "unnamed"), routingId, laneCount, laneCount > 1 ? "s" : "", sourceId, sinkId,
				getSlopePercentage(), roadGeometry.getRoadLength(), speedLimitKmh, osmReverse);
	}

	public Polygon getBounds() {
		return bounds;
	}

	public Rectangle getBoundsRectangle() {
		return boundsRect;
	}

	/**
	 * This method should only be called during initialization phase!
	 */
	private void updateBounds() {
		bounds = new Polygon();
		boundsRect = null;
		for (Vector vec : roadGeometry.getPoints()) {
			bounds.addPoint((int) vec.x, (int) vec.y);
			if (boundsRect == null) {
				boundsRect = new Rectangle((int) vec.x, (int) vec.y, 0, 0);
			} else {
				boundsRect.add((int) vec.x, (int) vec.y);
			}
		}
		List<Vector> outerPoints = new ArrayList<>(laneSegments.get(laneCount - 1).getRightEdge());
		Collections.reverse(outerPoints);
		for (Vector vec : outerPoints) {
			bounds.addPoint((int) vec.x, (int) vec.y);
			boundsRect.add((int) vec.x, (int) vec.y);
		}
	}

	/**
	 * @return all vehicles in this road segment as an unmodifiable list, without obstacles!
	 */
	public List<Vehicle> getAllVehicles() {
		List<Vehicle> vehicles = new ArrayList<>();
		for (LaneSegment s : laneSegments) {
			for (Vehicle v : s.getVehicles()) {
				if (!v.isObstacle()) {
					vehicles.add(v);
				}
			}
		}
		return Collections.unmodifiableList(vehicles);
	}

	/**
	 * @return all routable vehicles in this road segment as an unmodifiable list, without obstacles!
	 */
	public List<Vehicle> getAllRoutableVehicles() {
		List<Vehicle> vehicles = new ArrayList<>();
		for (LaneSegment s : laneSegments) {
			for (Vehicle v : s.getVehicles()) {
				if (!v.isObstacle() && v.isRoutable()) {
					vehicles.add(v);
				}
			}
		}
		return Collections.unmodifiableList(vehicles);
	}

	public long getRoutingId() {
		return routingId;
	}

	public void setRoutingId(long routingId) {
		this.routingId = routingId;
	}

	public LaneSegment getRightMostLane() {
		if (laneCount > 0) {
			return laneSegment(laneCount - 1);
		}
		return null;

	}

	public double getSpeedLimitKmph() {
		return speedLimitKmh;
	}

	public double getSpeedLimitMps() {
		return speedLimitKmh / 3.6;
	}

	public void setSpeedLimitKmh(double speedLimitKmh) {
		if (speedLimitKmh > 0) {
			this.speedLimitKmh = speedLimitKmh;
		}
	}

	public void activateStatisticsMonitor() {
		for (LaneSegment seg : laneSegments) {
			seg.setListener(this);
		}
	}

	public void deactivateStatisticsMonitor() {
		for (LaneSegment seg : laneSegments) {
			seg.setListener(null);
		}
	}

	/**
	 * 
	 * @return the road statistics merged for all lanes from this road.
	 */
	public LaneStatisticsData getCompleteRoadStatistics() {
		LaneStatisticsData result = new LaneStatisticsData();
		for (LaneSegment seg : laneSegments) {
			result = result.merge(seg.getLaneStatistics());
		}
		return result;
	}

	@Override
	public void roadDataChanged(long roadSegmentId, int laneIndex) {
		for (IRoadStatisticsChangedListener listener : roadListeners) {
			listener.roadDataChanged(id, laneIndex);
		}
	}

	public void addRoadDataChangedListener(IRoadStatisticsChangedListener listener) {
		if (listener != null) {
			activateStatisticsMonitor();
			this.roadListeners.add(listener);
		}
	}

	public void removeRoadDataChangedListener(IRoadStatisticsChangedListener listener) {
		this.roadListeners.remove(listener);
		if (roadListeners.isEmpty()) {
			deactivateStatisticsMonitor();
		}
	}

	public Node getStartNode() {
		return startNode;
	}

	public void setStartNode(Node startNode) {
		this.startNode = startNode;
	}

	public Node getEndNode() {
		return endNode;
	}

	public void setEndNode(Node endNode) {
		this.endNode = endNode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Snapshot of original points of this geometry, before cutting off the edges due to creation of jucntions. This method should only be
	 * called once!
	 */
	public void originalPointsSnapshot() {
		if (roadGeometry.getOriginalPoints().isEmpty()) {
			roadGeometry.copyOriginalPoints();
		}
	}

	public boolean isOsmReverse() {
		return osmReverse;
	}

	public void setOsmReverse(boolean osmReverse) {
		this.osmReverse = osmReverse;
	}

	public boolean isOneWay() {
		return oneWay;
	}

	public void setOneWay(boolean oneWay) {
		this.oneWay = oneWay;
	}

	public void updateRoadGeometry(RoadGeometry newGeom) {
		if (roadGeometry.getPoints().size() > 1) {
			roadGeometry = newGeom;
			updateLaneGeometries();
		} else {
			Logger.logWarn("Cannot use road geometry with empty points for RS " + getId());
		}
	}

	public double getRoadWidth() {
		if (roadWidth <= 0) {
			for (LaneSegment seg : laneSegments) {
				roadWidth += seg.getLaneWidth();
			}
		}
		return roadWidth;
	}

	public void setSourceJunction(AbstractJunction j) {
		sourceJunction = j;
	}

	public AbstractJunction getSourceJunction() {
		return sourceJunction;
	}

	public boolean isRightMostLane(int laneIndex) {
		return laneIndex == laneCount - 1;
	}
}

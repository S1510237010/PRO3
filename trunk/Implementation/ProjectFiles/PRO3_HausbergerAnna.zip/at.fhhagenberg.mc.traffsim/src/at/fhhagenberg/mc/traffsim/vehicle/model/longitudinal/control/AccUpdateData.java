package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;

/**
 * Data Container which contains values that are necessary to update the acceleration of a vehicle by the {@link LongitudinalControl}
 *
 * @author Christian
 *
 */
public class AccUpdateData {
	double distance;
	double speedDiff;
	double accLead;
	VehicleType frontVehicleType;
	Vehicle frontVehicle;
	VehiclesLane laneSegment;

	public AccUpdateData(double distance, double speedDiff, double accLead, VehicleType frontVehicleType) {
		super();
		this.distance = distance;
		this.speedDiff = speedDiff;
		this.accLead = accLead;
		this.frontVehicleType = frontVehicleType;
	}

	public AccUpdateData(double distance, double speedDiff, double accLead, VehicleType frontVehicleType, Vehicle frontVehicle,
			VehiclesLane laneSegment) {
		super();
		this.distance = distance;
		this.speedDiff = speedDiff;
		this.accLead = accLead;
		this.frontVehicleType = frontVehicleType;
		this.frontVehicle = frontVehicle;
		this.laneSegment = laneSegment;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public double getSpeedDiff() {
		return speedDiff;
	}

	public void setSpeedDiff(double speedDiff) {
		this.speedDiff = speedDiff;
	}

	public double getAccLead() {
		return accLead;
	}

	public void setAccLead(double accLead) {
		this.accLead = accLead;
	}

	public VehicleType getFrontVehicleType() {
		return frontVehicleType;
	}

	public void setFrontVehicleType(VehicleType frontVehicleType) {
		this.frontVehicleType = frontVehicleType;
	}

	public Vehicle getFrontVehicle() {
		return frontVehicle;
	}

	public void setFrontVehicle(Vehicle frontVehicle) {
		this.frontVehicle = frontVehicle;
	}

	public VehiclesLane getLaneSegment() {
		return laneSegment;
	}

	public void setLaneSegment(VehiclesLane laneSegment) {
		this.laneSegment = laneSegment;
	}

}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IComposableLongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IUpdateTimeDependableLongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.HumanDriverControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.ModelParameterSet;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.Noise;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.SpatialAnticipation;

/**
 * Implementation of Treiber et al.'s Human Driver Model (HDM). Compared to the idealized IDM this longitudinal model considers the
 * following characteristics which can be attributed to the human driver:
 *
 * <p>
 * - Finite, invariable reaction time
 * </p>
 * <p>
 * - Imperfect estimation capabilities
 * </p>
 * <p>
 * - Anticipation capabilities (temporal and spatial by considering more than one leading vehicle)
 * </p>
 *
 * @author Manuel Lindorfer
 *
 */
public class HumanDriverControl extends LongitudinalControl<IComposableLongitudinalModel>implements IReactiveLongitudinalControl {

	/** Parameter required for configuration */
	private HumanDriverControlData data;

	/** Distance noise used to model imperfect estimation capabilities */
	protected Noise distanceNoise = null;

	/** Velocity difference noise used for modeling imperfect estimation capabilities */
	protected Noise velocityDifferenceNoise = null;

	/** List maintaining historical values for various input parameters; required for implemented a delayed driver response */
	protected ArrayList<ModelParameterSet> history;

	/** Variable to store the maximum delay */
	protected double maxDelay = 0.0;

	/** History to persist input parameters for a certain time */
	protected int maxHistorySize = 0;

	/** Finite reaction time */
	private double reactionTime = 0.0;

	/** Current simulation time step */
	protected double updateTimeStep = 0.0;

	public HumanDriverControl() {

	}

	public HumanDriverControl(String identifier) {
		super(identifier);
	}

	public HumanDriverControl(HumanDriverControlData data) {
		super(data.getIdentifier());
		this.data = data;
		reactionTime = data.getReactionTime() / 1000.0;
		maxDelay = reactionTime;
		history = new ArrayList<ModelParameterSet>();
	}

	/**
	 * Gets the currently applied reaction time.
	 *
	 * @return the currently applied reaction time
	 */
	public double getReactionTime() {
		return reactionTime;
	}

	@Override
	public void update(double dt, double simulationTime) {
		super.update(dt, simulationTime);
		updateTimeStep = dt;

		/** Update underlying longitudinal model if feasible **/
		if (longitudinalModel != null && longitudinalModel instanceof IUpdateTimeDependableLongitudinalModel) {
			((IUpdateTimeDependableLongitudinalModel) longitudinalModel).setSimulationTimestep(dt);
		}

		/** Update noises **/
		if (distanceNoise != null) {
			distanceNoise.update(dt);
		}

		if (velocityDifferenceNoise != null) {
			velocityDifferenceNoise.update(dt);
		}

		int var = (int) (maxDelay * (int) (1 / dt)) + 1;

		if (var > maxHistorySize) {
			maxHistorySize = var;
		}
	}

	public void setVelocityDifferenceNoise(Noise noise) {
		velocityDifferenceNoise = noise;
	}

	public void setDistanceNoise(Noise noise) {
		distanceNoise = noise;
	}

	/**
	 * Adds the given parameter values to the list of historical input parameters.
	 *
	 * @param v
	 *            the current velocity
	 * @param dv
	 *            the current speed difference to the preceding vehicle
	 * @param s
	 *            the current net gap to the preceding vehicle
	 * @param vehiclesToConsider
	 *            the vehicles to consider
	 */
	protected void addToHistory(double v, double dv, double s, List<VehicleWithDistance> vehiclesToConsider, double a, double rt) {
		if (history != null) {
			if (history.size() > maxHistorySize) {
				history.remove(0);
			}

			history.add(new ModelParameterSet(v, dv, s, vehiclesToConsider, a, rt));
		}
	}

	protected double addDistanceEstimationError(double distance) {
		if (distanceNoise != null) {
			double estError = distanceNoise.getError();
			double amplifier = distanceNoise.getAmplifier();

			// Update model input statistics
			if (modelInput != null) {
				modelInput.setDistanceNoise(estError * amplifier);
			}

			/**
			 * Calculate estimated distance according to Kesting, A. "Microscopic Modeling of Human and Automated Driving: Towards
			 * Traffic-Adaptive Cruise Control"
			 */
			return distance * Math.exp(amplifier * estError);
		}

		return distance;
	}

	protected double addSpeedDifferenceEstimationError(double speedDifference, double distance) {
		if (velocityDifferenceNoise != null) {
			double estError = velocityDifferenceNoise.getError();
			double amplifier = velocityDifferenceNoise.getAmplifier();

			// Update model input statistics
			if (modelInput != null) {
				modelInput.setSpeedDifferenceNoise(estError * amplifier);
			}

			/**
			 * Calculate estimated velocity difference according to Kesting, A. "Microscopic Modeling of Human and Automated Driving:
			 * Towards Traffic-Adaptive Cruise Control"
			 */
			return speedDifference + distance * estError * amplifier;
		}

		return speedDifference;
	}

	private List<VehicleWithDistance> getConsiderableVehicles(VehicleWithDistance frontVehicle, int lookAhead) {
		List<VehicleWithDistance> vehiclesToConsider = new ArrayList<VehicleWithDistance>();

		if (frontVehicle != null && frontVehicle.getVehicle() != null && lookAhead > 1) {
			int numVehicles = 0;
			VehicleWithDistance predecessor = frontVehicle;

			while (numVehicles < lookAhead) {

				// Add vehicles to considerable ones and increase count
				vehiclesToConsider.add(predecessor);
				numVehicles++;

				// Move on to the next vehicle
				predecessor = predecessor.getVehicle().getFrontVehicle();

				if (predecessor == null || predecessor.getVehicle() == null) {
					break;
				}
			}
		}

		return vehiclesToConsider;
	}

	@Override
	public double calcAccCustom(Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA) {

		double s = accData.distance;
		double dv = accData.speedDiff;
		double aLead = accData.accLead;
		double speedLimit = getSpeedLimitMps(me);

		double v = me.getCurrentSpeed();
		VehicleWithDistance frontVehicle = me.getFrontVehicle();

		// Delayed input parameters
		double sDelayed = 0.0;
		double dvDelayed = 0.0;
		double vDelayed = 0.0;

		// Anticipated input parameters (temporally)
		double vProg = 0.0;
		double sProg = 0.0;

		double sEst = s;
		double dvEst = dv;
		double vEst = v;

		/** Determine which vehicles are to be considered for multi-anticipation **/
		List<VehicleWithDistance> vehiclesToConsider = getConsiderableVehicles(frontVehicle, data.getNumConsideredVehicles());
		List<Double> netGapsToConsider = null;
		List<Double> speedsToConsider = null;

		/** Consider imperfect estimation capabilities [Velocity Difference] **/
		dvEst = dv = addSpeedDifferenceEstimationError(dv, s);

		/** Consider imperfect estimation capabilities [Net Gap] **/
		sEst = s = addDistanceEstimationError(s);

		/** Consider reaction time **/
		if (data.getIsReactive()) {

			/** Update history **/
			addToHistory(vEst, dvEst, sEst, vehiclesToConsider, me.getCurrentAcc(), reactionTime);

			/**
			 * Field which determines the number of time steps the reaction time equals to with respect to the current update time interval
			 * (e.g. a reaction time of 1.5 seconds with a given update time interval of 50ms constitutes to n = 30).
			 */
			int n = NumberUtil.doubleEquals(updateTimeStep, 0) ? 0 : (int) (reactionTime * (int) (1 / updateTimeStep));
			double weightFactor = NumberUtil.doubleEquals(updateTimeStep, 0) ? 0 : reactionTime * (int) (1 / updateTimeStep) - n;

			/**
			 * Kesting (Disseration): If the reaction time is a multiple n of the update time interval, all terms are calculated with the
			 * velocities and distances n time steps in the past.
			 *
			 * If the reaction time is not a multiple of the update time interval, a linear interpolation according to x(t-T') = beta *
			 * x(t-n-1) + (1-beta)*x(t-n), where the weight factor beta = T' / deltaT - n. ALL input stimuli are evaluated at the delayed
			 * time.
			 */
			if (history.size() > maxHistorySize - n + 1 && n > 0) {
				ModelParameterSet inputN = history.get(maxHistorySize - n);
				ModelParameterSet inputPrevN = history.get(maxHistorySize - n - 1);

				double vN = inputN.getV();
				double vPrevN = inputPrevN.getV();
				double dvN = inputN.getDv();
				double dvPrevN = inputPrevN.getDv();
				double sN = inputN.getS();
				double sPrevN = inputPrevN.getS();

				double vAntiN = inputN.getVAnti();
				double vAntiPrevN = inputPrevN.getVAnti();

				double sAntiN = inputN.getSAnti();
				double sAntiPrevN = inputPrevN.getSAnti();

				netGapsToConsider = inputN.getNetGaps();
				speedsToConsider = inputN.getVelocities();

				vDelayed = weightFactor * vPrevN + (1 - weightFactor) * vN;
				dvDelayed = weightFactor * dvPrevN + (1 - weightFactor) * dvN;
				sDelayed = weightFactor * sPrevN + (1 - weightFactor) * sN;
				vProg = weightFactor * vAntiPrevN + (1 - weightFactor) * vAntiN;
				sProg = weightFactor * sAntiPrevN + (1 - weightFactor) * sAntiN;
			} else {
				vDelayed = v;
				dvDelayed = dv;
				sDelayed = s;
				netGapsToConsider = null;
				speedsToConsider = null;
				vProg = v;
				sProg = s;
			}

			// Continue using delayed parameters
			s = sDelayed;
			dv = dvDelayed;
			v = vDelayed;
		}

		/** Consider the driver's temporal anticipation **/
		if (data.getIsReactive() && data.getIsAnticipative()) {
			s = Math.max(sProg, 0);
			v = Math.max(vProg, 0);
		}

		// Computed acceleration value
		double acc = 0;

		// No spatial anticipation, just one or no preceding vehicle
		if (vehiclesToConsider.size() <= 1) {
			acc = longitudinalModel.calcAcc(me, v, s, dv, aLead, alphaT, alphaV0, alphaA, speedLimit);
		} else {
			// Determine current speed limit only once

			/** Free acceleration (no deceleration terms) **/
			double accFree = longitudinalModel.calcAccComponent(v, speedLimit, alphaT, alphaV0, alphaA);

			/** Interactions with considerable preceding vehicles **/
			double accInteraction = 0;

			/**
			 * Factors required for normalization and reduction in order to decrease unrealistic equilibrium distances (Treiber et al.
			 * 'Delays, inaccuracies...')
			 **/
			double gamma = SpatialAnticipation.getNormalizationFactor(vehiclesToConsider.size());

			// Specifies the distance to the vehicle under consideration
			double sDiff = 0;

			if (data.getIsReactive() && netGapsToConsider != null && speedsToConsider != null) {
				for (int i = 0; i < netGapsToConsider.size(); i++) {
					double vDiff = v - speedsToConsider.get(i);

					// Determine distance to subject vehicle
					if (i == 0) {
						sDiff = netGapsToConsider.get(i);
					} else {
						sDiff += netGapsToConsider.get(i);
					}

					double accInt = longitudinalModel.calcBrakeComponent(v, speedLimit, sDiff, vDiff, aLead, alphaT, alphaV0, alphaA,
							gamma);
					accInteraction += accInt;
				}
			} else {
				for (int i = 0; i < vehiclesToConsider.size(); i++) {
					Vehicle veh = vehiclesToConsider.get(i).getVehicle();
					double vDiff = v - veh.getCurrentSpeed();

					// Determine distance to subject vehicle
					if (i == 0) {
						sDiff = vehiclesToConsider.get(i).getDistance();
					} else {
						sDiff += vehiclesToConsider.get(i).getDistance();
					}

					double accInt = longitudinalModel.calcBrakeComponent(v, speedLimit, sDiff, vDiff, aLead, alphaT, alphaV0, alphaA,
							gamma);
					accInteraction += accInt;
				}
			}

			/** Compute final acceleration **/
			acc = accFree + accInteraction;
		}

		final double finalAcc = Math.min(acc, Double.MAX_VALUE);
		return finalAcc;
	}

	@Override
	public void updateHistory(Vehicle vehicle, AccUpdateData accData) {
		if (data.getIsReactive()) {
			double s = accData.distance;
			double dv = accData.speedDiff;
			double v = vehicle.getCurrentSpeed();

			VehicleWithDistance frontVehicle = vehicle.getFrontVehicle();
			List<VehicleWithDistance> vehiclesToConsider = getConsiderableVehicles(frontVehicle, data.getNumConsideredVehicles());

			dv = addSpeedDifferenceEstimationError(dv, s);
			s = addDistanceEstimationError(s);

			addToHistory(v, dv, s, vehiclesToConsider, vehicle.getCurrentAcc(), reactionTime);
		}
	}
}

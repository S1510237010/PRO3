package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.csstudio.swt.widgets.figures.GaugeFigure;
import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider;
import org.csstudio.swt.xygraph.dataprovider.Sample;
import org.csstudio.swt.xygraph.figures.Axis;
import org.csstudio.swt.xygraph.figures.ToolbarArmedXYGraph;
import org.csstudio.swt.xygraph.figures.Trace;
import org.csstudio.swt.xygraph.figures.Trace.PointStyle;
import org.csstudio.swt.xygraph.figures.XYGraph;
import org.csstudio.swt.xygraph.linearscale.AbstractScale.LabelSide;
import org.csstudio.swt.xygraph.util.XYGraphMediaFactory;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IViewSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.IItemSelectionListener;
import at.fhhagenberg.mc.traffsim.model.IVehicleStatisticsChangedListener;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.statistics.Statistics;
import at.fhhagenberg.mc.traffsim.statistics.VehicleStatisticsData;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.ChartUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class VehicleStatisticsView extends ViewPart
		implements IModelInputChangedListener, IVehicleStatisticsChangedListener, IItemSelectionListener {
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.statistics.vehicle";
	int oldComboSize = -1;

	private long currentVehicleId = -1;

	private Statistics statistics;
	private Combo combo;
	private int updateDelayVal = PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL);
	private boolean autoUpdate = true;
	private CircularBufferDataProvider accDataProvider;
	private XYGraph xyGraph;
	private CircularBufferDataProvider spdDataProvider;
	private boolean updateOnce;
	private long lastArraySize = 0;
	private CircularBufferDataProvider posDataProvider, fuelDataProvider;
	private long lastUpdate = 0;
	private Label valFuelAvg;
	private Label valConsumed;
	private Label valLiter100km;
	private GaugeFigure gaugeFigure;
	private Map<Long, Long> idLabelMapping = new HashMap<>();
	private SimulationModel currentSimModel;

	public VehicleStatisticsView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(2, false));

		Composite chartComposite = createChart(container);
		chartComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		Composite controls = new Composite(container, SWT.NONE);
		controls.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, true, 1, 1));
		controls.setLayout(new GridLayout(1, false));

		Group statisticsControls = new Group(controls, SWT.SHADOW_NONE);
		statisticsControls.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD | SWT.ITALIC));
		statisticsControls.setText("View controls");
		GridLayout gl_statisticsControls = new GridLayout(2, false);
		gl_statisticsControls.verticalSpacing = 2;
		statisticsControls.setLayout(gl_statisticsControls);

		Label lblVehicleId = new Label(statisticsControls, SWT.NONE);
		lblVehicleId.setSize(52, 15);
		lblVehicleId.setText("Vehicle ID");

		combo = new Combo(statisticsControls, SWT.READ_ONLY);
		GridData gd_combo = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_combo.widthHint = 20;
		combo.setLayoutData(gd_combo);
		combo.setSize(56, 23);

		final Button btnAutoUpdate = new Button(statisticsControls, SWT.CHECK);
		btnAutoUpdate.setSize(88, 16);
		btnAutoUpdate.setSelection(true);
		btnAutoUpdate.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnAutoUpdate.getSelection()) {
					autoUpdate = true;
				} else {
					autoUpdate = false;
				}
			}
		});
		btnAutoUpdate.setText("Auto Update");
		new Label(statisticsControls, SWT.NONE);

		TraffSimCorePlugin.getDefault().getPreferenceStore().addPropertyChangeListener(new IPropertyChangeListener() {

			@Override
			public void propertyChange(PropertyChangeEvent event) {
				if (event.getProperty().equals(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL)) {
					accDataProvider.setUpdateDelay((int) event.getNewValue());
					spdDataProvider.setUpdateDelay((int) event.getNewValue());
					posDataProvider.setUpdateDelay((int) event.getNewValue());
					fuelDataProvider.setUpdateDelay((int) event.getNewValue());
					updateDelayVal = (int) event.getNewValue();
				}
			}
		});

		Group vehicleDetails = new Group(controls, SWT.NONE);
		vehicleDetails.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD | SWT.ITALIC));
		vehicleDetails.setText("Fuel consumption");
		vehicleDetails.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		GridLayout gl_vehicleDetails = new GridLayout(2, false);
		gl_vehicleDetails.verticalSpacing = 2;
		vehicleDetails.setLayout(gl_vehicleDetails);

		Label lblCurrentkm = new Label(vehicleDetails, SWT.NONE);
		lblCurrentkm.setText("l / 100km:");

		valLiter100km = new Label(vehicleDetails, SWT.NONE);
		valLiter100km.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblFuel = new Label(vehicleDetails, SWT.NONE);
		lblFuel.setBounds(0, 0, 55, 15);
		lblFuel.setText("\u00D8 / 100km:");

		valFuelAvg = new Label(vehicleDetails, SWT.NONE);
		valFuelAvg.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		valFuelAvg.setText("           ");

		Label lblConsumed = new Label(vehicleDetails, SWT.NONE);
		lblConsumed.setText("consumed:");

		valConsumed = new Label(vehicleDetails, SWT.NONE);
		valConsumed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Canvas gaugeCanvas = new Canvas(controls, SWT.NONE);
		gaugeCanvas.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		LightweightSystem lws = new LightweightSystem(gaugeCanvas);

		gaugeFigure = new GaugeFigure();

		gaugeFigure.setBackgroundColor(XYGraphMediaFactory.getInstance().getColor(0, 0, 0));
		gaugeFigure.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(255, 255, 255));

		gaugeFigure.setRange(0, 220.0D);
		gaugeFigure.setLoLevel(-150.0D);
		gaugeFigure.setLoloLevel(-150.0D);
		gaugeFigure.setHiLevel(160.0D);
		gaugeFigure.setHihiLevel(250.0D);
		gaugeFigure.setMajorTickMarkStepHint(20);
		gaugeFigure.getScale().setFont(SWTResourceManager.getFont("Arial", 7, SWT.NONE));
		gaugeFigure.setValue(0);

		lws.setContents(gaugeFigure);

		combo.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (statistics != null) {
					changeVehicleId(statistics.getId(String.valueOf(combo.getText())));
				}
			}

		});

		// register input changed listener after part is initialized
		SimulationKernel.getInstance().addInputChangedListener(this);
	}

	private void changeVehicleId(long newId) {
		currentVehicleId = newId;
		accDataProvider.clearTrace();
		spdDataProvider.clearTrace();
		posDataProvider.clearTrace();
		fuelDataProvider.clearTrace();
		updateOnce = true;
		lastArraySize = 0;
		vehicleDataChanged(currentVehicleId);
	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (newModel == null) {
			if (statistics != null) {
				statistics.removeStatisticsChangedListener(this);
				this.statistics = null;
			}
		} else {
			this.statistics = newModel.getStatistics();
			newModel.addItemSelectionListener(this);
			statistics.addStatisticsChangedListener(this);
			if (getViewSite() != null) {
				getViewSite().getShell().getDisplay().asyncExec(new Runnable() {
					@Override
					public void run() {
						combo.removeAll();
						oldComboSize = 0;
						accDataProvider.clearTrace();
						spdDataProvider.clearTrace();
						posDataProvider.clearTrace();
						fuelDataProvider.clearTrace();
						updateOnce = true;
					}
				});
			}
			// set to negative index to update vehicles in combo in each case
			oldComboSize = -1;
			vehicleAdded(-1);
		}
		if (currentSimModel != null) {
			currentSimModel.removeItemSelectionListener(this);
		}
		currentSimModel = newModel;
	}

	@Override
	public void dispose() {
		if (statistics != null) {
			statistics.removeStatisticsChangedListener(this);
		}
		SimulationKernel.getInstance().removeInputChangedListener(this);
		if (currentSimModel != null) {
			currentSimModel.removeItemSelectionListener(this);
		}
		super.dispose();
	}

	private Composite createChart(Composite parent) {
		Canvas canvas = new Canvas(parent, SWT.NONE);
		final LightweightSystem lws = new LightweightSystem(canvas);
		xyGraph = new XYGraph();
		xyGraph.setTitle("");
		xyGraph.primaryXAxis.setTitle("time [s]");
		xyGraph.primaryYAxis.setTitle("speed [m/s]");
		xyGraph.primaryYAxis.setAutoScale(true);
		xyGraph.primaryXAxis.setAutoScale(true);
		xyGraph.primaryXAxis.setShowMajorGrid(true);
		xyGraph.primaryYAxis.setShowMajorGrid(true);
		xyGraph.primaryXAxis.setAutoScaleThreshold(0.2);
		xyGraph.primaryYAxis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_BLUE));
		final Axis y2Axis = new Axis("acc [m/s^2]", true);
		// y2Axis.setAutoScale(true);
		y2Axis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_RED));
		y2Axis.setTickLableSide(LabelSide.Primary);
		y2Axis.setAutoScale(true);
		y2Axis.setAutoScaleThreshold(0.2);
		final Axis y3Axis = new Axis("distance [m]", true);
		y3Axis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_GREEN));
		y3Axis.setTickLableSide(LabelSide.Secondary);
		y3Axis.setAutoScale(true);
		y3Axis.setAutoScaleThreshold(0.2);
		final Axis y4Axis = new Axis("fuel [l/hour]", true);
		y4Axis.setForegroundColor(XYGraphMediaFactory.getInstance().getColor(XYGraphMediaFactory.COLOR_DARK_GRAY));
		y4Axis.setTickLableSide(LabelSide.Secondary);
		y4Axis.setAutoScale(true);
		y4Axis.setAutoScaleThreshold(0.2);
		xyGraph.addAxis(y2Axis);
		xyGraph.addAxis(y3Axis);
		xyGraph.addAxis(y4Axis);
		ToolbarArmedXYGraph toolbarArmedXYGraph = new ToolbarArmedXYGraph(xyGraph);
		lws.setContents(toolbarArmedXYGraph);
		int interval = PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL);
		if (interval == 0) {
			interval = IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL;
		}
		accDataProvider = ChartUtil.createDataProvider(5000, interval);
		spdDataProvider = ChartUtil.createDataProvider(5000, interval);
		posDataProvider = ChartUtil.createDataProvider(5000, interval);
		fuelDataProvider = ChartUtil.createDataProvider(5000, interval);
		Trace spdTrace = new Trace("Acceleration", xyGraph.primaryXAxis, y2Axis, accDataProvider);
		spdTrace.setPointStyle(PointStyle.NONE);
		spdTrace.setAntiAliasing(true);
		Trace accTrace = new Trace("Speed", xyGraph.primaryXAxis, xyGraph.primaryYAxis, spdDataProvider);
		accTrace.setPointStyle(PointStyle.NONE);
		accTrace.setAntiAliasing(true);
		Trace posTrace = new Trace("Distance travelled", xyGraph.primaryXAxis, y3Axis, posDataProvider);
		posTrace.setPointStyle(PointStyle.NONE);
		posTrace.setAntiAliasing(true);
		Trace fuelTrace = new Trace("Fuel consumption", xyGraph.primaryXAxis, y4Axis, fuelDataProvider);
		fuelTrace.setPointStyle(PointStyle.NONE);
		fuelTrace.setAntiAliasing(true);
		xyGraph.addTrace(accTrace);
		xyGraph.addTrace(spdTrace);
		xyGraph.addTrace(posTrace);
		xyGraph.addTrace(fuelTrace);
		return canvas;
	}

	@Override
	public void vehicleAdded(long vehicleId) {
		if (statistics == null || statistics.getVehicleStats() == null || statistics.getVehicleStats().size() == 0 || combo == null
				|| combo.isDisposed()) {
			return;
		}
		final List<String> newItems = new ArrayList<>();
		final List<Long> vehicleIds = new ArrayList<>(statistics.getVehicleStats().keySet());
		Collections.sort(vehicleIds);
		for (Long l : vehicleIds) {
			newItems.add(statistics.getLabel(l));
		}

		if (oldComboSize != newItems.size() && combo != null && !combo.isDisposed()) {
			getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					int index = combo.getSelectionIndex();
					combo.setItems(newItems.toArray(new String[] {}));
					combo.select(index);
					oldComboSize = newItems.size();
				}
			});
		}
	}

	@Override
	public void init(IViewSite site) throws PartInitException {
		super.init(site);
		vehicleAdded(-1);
	}

	private Display getDisplay() {
		return VehicleStatisticsView.this.getSite().getWorkbenchWindow().getShell().getDisplay();
	}

	@Override
	public void vehicleDataChanged(long vehicleId) {
		if ((autoUpdate || updateOnce) && vehicleId == currentVehicleId && System.currentTimeMillis() - lastUpdate > updateDelayVal) {
			lastUpdate = System.currentTimeMillis();
			final VehicleStatisticsData data = statistics.getVehicleStats().get(vehicleId);
			if (data == null) {
				return;
			}
			if (updateOnce) {
				lastArraySize = data.getRemovedItems();
			}
			getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					if (data.getRecordedItems() > lastArraySize) {
						for (long i = lastArraySize; i < data.getRecordedItems(); i++) {
							int ti = data.transformIndex(i);
							double time = data.getTime().get(ti);
							accDataProvider.addSample(new Sample(time, data.getAcc().get(ti)));
							spdDataProvider.addSample(new Sample(time, data.getSpeed().get(ti)));
							posDataProvider.addSample(new Sample(time, data.getTravelDistance().get(ti)));
							fuelDataProvider.addSample(new Sample(time, data.getFuelConsumptionPerHour().get(ti)));
						}
						lastArraySize = (int) data.getRecordedItems();
						valFuelAvg.setText(String.format("%.3f l", data.getAvgFuelConsumptionPer100km()));
						valConsumed.setText(String.format("%.3f l", data.getVehicle().getFuelConsumed()));
						valLiter100km.setText(String.format("%.3f l", data.getVehicle().getCurrentFuelConsumption()[1]));
						gaugeFigure.setValue((int) (data.getVehicle().getCurrentSpeed() * 3.6));
					}
				}
			});
			updateOnce = false;
		}

	}

	@Override
	public void setFocus() {
		// unimplemented
	}

	@Override
	public void itemsSelected(List<AbstractJunction> junctions, List<JunctionConnector> connectors, List<RoadSegment> roadSegments,
			List<LaneSegment> laneSegments, final List<Vehicle> vehicles) {
		if (!vehicles.isEmpty()) {
			getSite().getShell().getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					long id = vehicles.get(0).getUniqueId();
					combo.setText("" + id);
					changeVehicleId(vehicles.get(0).getUniqueId());
				}
			});
		}
	}
}

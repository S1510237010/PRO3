package at.fhhagenberg.mc.traffsim.model.batch;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.io.FileUtils;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;

import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.DummyLogConsumer;
import at.fhhagenberg.mc.traffsim.log.LogMessage;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.ILogConsumer;
import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.FileUtil;
import at.fhhagenberg.mc.util.StringUtil;
import matlabcontrol.MatlabConnectionException;
import matlabcontrol.MatlabInvocationException;

public class BatchExecutor extends PauseableThread implements ISimulationStateListener {
	private List<File> currentConfigurations;
	/** list of simulations that are currently scheduled (already running and finnished simulations are removed from this list!) */
	protected List<ScheduledSimulation> currentScheduledSimulations;
	private Properties prop;
	private IWorkbenchWindow activeWindow;
	private List<SimulationModel> activeModels;
	protected int maxParallelSimulations = PreferenceUtil.getInt(IPreferenceConstants.NUM_SIMULTANEOUS_SIMULATIONS);
	protected Map<SimulationModel, ScheduledSimulation> runningSimulations = new ConcurrentHashMap<>(maxParallelSimulations);
	private boolean mergeFiles;
	private boolean deleteMergedFiles;

	private ILogConsumer logConsumer = new DummyLogConsumer();
	protected IBatchListener batchListener = new DummyBatchListener();
	private List<File> createdTempDirectories = new ArrayList<>();
	private List<File> processedOutputFolders = new ArrayList<>();
	private AtomicBoolean isBatchStopping = new AtomicBoolean(false);
	private boolean avoidTempCopying = false;
	private int numericSimulationIdentifier = 0;

	private int numSimulationsDone = 0;
	private int numConfigurationsProcessed = 0;

	/**
	 * Init the executor with already loaded models, which avoids copying them to a temporary directory, since they may already be open
	 *
	 * @param loadedModels
	 * @param mergeFiles
	 * @param deleteMergedFiles
	 */
	public BatchExecutor(List<SimulationModel> loadedModels, boolean mergeFiles, boolean deleteMergedFiles) {
		super("Batch Executor (open models)", 500);
		this.currentScheduledSimulations = ScheduledSimulation.pack(loadedModels);
		this.mergeFiles = mergeFiles;
		this.deleteMergedFiles = deleteMergedFiles;
		avoidTempCopying = true;
		initializeProperties();
	}

	public BatchExecutor(List<File> configurationsToLoad, IWorkbenchWindow activeWindow, boolean mergeFiles, boolean deleteMergedFiles) {
		super("Batch Executor", 500);
		this.currentConfigurations = configurationsToLoad;
		this.activeWindow = activeWindow;
		this.mergeFiles = mergeFiles;
		this.deleteMergedFiles = deleteMergedFiles;
		initializeProperties();
	}

	private List<File> copyToLocalTemp(List<File> configurationsToLoad, List<File> createdTempDirectories) {
		batchListener.logLine("Copying " + configurationsToLoad.size() + " configurations to temporary directories (     )");
		Map<File, File> newToOldMapping = new HashMap<>();
		List<File> copiedConfigurations = new ArrayList<>();
		DataSerializer serializer = new DataSerializer();
		for (int i = 0; i < configurationsToLoad.size(); i++) {
			File conf = configurationsToLoad.get(i);
			batchListener.replaceLastLogCharacters(6, String.format("%5d)", i + 1));
			List<File> filesToCopy = new ArrayList<>();
			serializer.readConfiguration(conf);
			for (String val : serializer.getConfiguration().getAllFileNames(true)) {
				filesToCopy.add(new File(conf.getParentFile(), val));
			}
			filesToCopy.add(new File(conf.getParentFile(), serializer.getConfiguration().getGraphFile()));
			try {
				File temp = FileUtil.createTempDirectory(conf.getParentFile().getName());
				createdTempDirectories.add(temp);
				FileUtil.copyFiles(filesToCopy, temp);
				File newConfFile = new File(temp, conf.getName());
				if (!newConfFile.exists()) {
					throw new IOException();
				}
				newToOldMapping.put(newConfFile, conf);
				copiedConfigurations.add(newConfFile);
			} catch (IOException e) {
				Logger.logError("Unable to copy files to temporary directory", e);
			}
		}
		batchListener.replaceLastLogCharacters(0, " Done.\n");
		SimulationKernel.getInstance().setTempToOriginalFileMapping(newToOldMapping);
		batchListener.logLine("Copy finished.");
		return copiedConfigurations;
	}

	public void setLogConsumer(ILogConsumer logConsumer) {
		this.logConsumer = logConsumer;
	}

	public void setBatchListener(IBatchListener batchListener) {
		this.batchListener = batchListener;
	}

	private void initializeProperties() {
		prop = new Properties();
		prop.put(PropertyKeys.BATCH_EXECUTION, Boolean.TRUE.toString());
		prop.put(PropertyKeys.GLOBAL_OUTPUT_FOLDER, PreferenceUtil.getString(IPreferenceConstants.GLOBAL_OUTPUT_FOLDER));
	}

	@Override
	public void init() {
		activeModels = new CopyOnWriteArrayList<>();
		if (!avoidTempCopying) {
			if (PreferenceUtil.getBoolean(IPreferenceConstants.CLEANUP_BATCH_TEMP)) {
				batchListener.logLine("Cleaning up temporary directories...");
				try {
					FileUtil.cleanupTempFolders(true);
				} catch (IOException e) {
					Logger.logError(e.getMessage());
				}
			}
			currentConfigurations = copyToLocalTemp(currentConfigurations, createdTempDirectories);
		}
		batchListener.batchStarted(currentConfigurations, currentScheduledSimulations, this);
	}

	/**
	 * Optional tasks that should be executed before simulation start
	 *
	 * @param model
	 * @param curSchedSim
	 */
	protected void beforeSimulationStart(SimulationModel model, ScheduledSimulation curSchedSim) {
	}

	@Override
	public void doWork() {
		if (CollectionUtil.isNotNullOrEmpty(currentScheduledSimulations)) {
			// run all SimulationModels
			while (activeModels.size() < maxParallelSimulations && !isBatchStopping.get()
					&& CollectionUtil.isNotNullOrEmpty(currentScheduledSimulations)) {
				ScheduledSimulation curSchedSim = currentScheduledSimulations.remove(0);
				SimulationModel curNewModel = null;
				if (curSchedSim.hasModel()) {
					curNewModel = curSchedSim.getModel();

				} else if (!isStopped()) {
					// load model
					final int identifier = PreferenceUtil.getBoolean(IPreferenceConstants.NUMBER_PARAMETER_SET_OUTPUTS)
							? numericSimulationIdentifier++ : -1;
					try {
						curSchedSim.getLoader().loadParameters(curSchedSim.getConfigurationFile(), new NullProgressMonitor());
					} catch (LoadingException e) {
						Logger.logError("Unable to load parameters for configuration " + curSchedSim.getConfigurationFile());
					}
					curNewModel = CollectionUtil.getFirstObject(SimulationKernel.getInstance().createNewSimulation(curSchedSim.getLoader(), prop,
							getActiveWindow(), CollectionUtil.createArrayList(curSchedSim.getParameterSetKey()), identifier));
				} else {
					// batch stopped
					break;
				}
				beforeSimulationStart(curNewModel, curSchedSim);
				runningSimulations.put(curNewModel, curSchedSim);
				batchListener.currentSimulationsChanged(currentScheduledSimulations, runningSimulations.values(), false);

				curNewModel.addSimulationStateListener(this);
				curNewModel.setBatchMode(true);
				String logString = "Starting new simulation: " + curNewModel.getUniqueId() + " | " + curNewModel.getLongDescription();
				Logger.logInfo(logString);
				addLogToConsumer(new LogMessage(logString));
				curNewModel.setSimulationRunning(true);
				processedOutputFolders.add(curNewModel.getOutputFolder());
				activeModels.add(curNewModel);
				/* re-init maxParallelSimulations for being capable of changes during batch run */
				maxParallelSimulations = PreferenceUtil.getInt(IPreferenceConstants.NUM_SIMULTANEOUS_SIMULATIONS);
			}
			if (!currentScheduledSimulations.isEmpty() || activeModels.size() == maxParallelSimulations) {
				pause();
			}
		} else {
			// pause and stop batch execution, force restart; only if simulations left
			if (PreferenceUtil.getBoolean(IPreferenceConstants.RESTART_AFTER_N_CONFIGURATIONS)
					&& numConfigurationsProcessed >= PreferenceUtil.getInt(IPreferenceConstants.CONFIGURATIONS_BEFORE_RESTART)
					&& CollectionUtil.isNotNullOrEmpty(currentConfigurations)) {

				if (CollectionUtil.isNullOrEmpty(activeModels)) {
					StringBuilder batchStack = new StringBuilder();

					Map<File, File> mapping = SimulationKernel.getInstance().getTempToOriginalFileMapping();

					for (int i = 0; i < currentConfigurations.size(); i++) {

						File currentConfig = currentConfigurations.get(i);
						File originalFile = null;

						if (mapping.containsKey(currentConfig)) {
							originalFile = mapping.get(currentConfig);
						} else {
							continue;
						}

						if (i < currentConfigurations.size() - 1) {
							batchStack.append(originalFile.getAbsolutePath() + ";");
						} else {
							batchStack.append(originalFile.getAbsolutePath());
						}
					}

					String stringifiedBatchStack = batchStack.toString();
					PreferenceUtil.set(IPreferenceConstants.BATCH_SIMULATION_STACK, stringifiedBatchStack);
					setPause(true);
					stopBatch();

					Display.getDefault().asyncExec(new Runnable() {
						@Override
						public void run() {
							PlatformUI.getWorkbench().restart();
						}
					});
				} else {
					proceed();
				}
			} else {
				// no simulation models left
				if (CollectionUtil.isNotNullOrEmpty(currentConfigurations)) {
					// load new simulation models

					File curConf = currentConfigurations.remove(0);
					batchListener.currentConfigurationsChanged(currentConfigurations, curConf);
					currentScheduledSimulations = ScheduledSimulation.pack(curConf);
					addLogToConsumer(new LogMessage("Scheduled " + currentScheduledSimulations.size() + " simulation(s)"));
					numericSimulationIdentifier = 1;
					numConfigurationsProcessed++;
					batchListener.currentSimulationsChanged(currentScheduledSimulations, null, true);
				} else if (activeModels.isEmpty()) {
					// no simulation configurations left
					onModelsEmpty();
				} else {
					pause();
				}
			}
		}
	}

	protected IWorkbenchWindow getActiveWindow() {
		if (activeWindow == null) {
			activeWindow = PlatformUI.getWorkbench().getWorkbenchWindows()[0];
		}
		return activeWindow;
	}

	protected void onModelsEmpty() {
		String logString = "Batch simulation finished";
		Logger.logInfo(logString);
		addLogToConsumer(new LogMessage(logString));
		batchListener.batchFinished();
		if (mergeFiles) {
			Logger.logInfo("Merging generated files");
			// filter paths in order not to execute merging operation on
			// the same directory twice
			for (File processedOutputFolder : processedOutputFolders) {
				try {
					SimulationKernel.getInstance().mergeFilesInMatlab(PreferenceUtil.getString(IPreferenceConstants.MATLAB_PATH),
							processedOutputFolder, deleteMergedFiles);
					Logger.logInfo("Files merged");
				} catch (MatlabInvocationException | MatlabConnectionException | IOException e) {
					Logger.logError("Could not merge MATLAB files", e);
				}
			}
		}
		executeToolAfterFinish();

		stopAndDestroy();
		SimulationKernel.getInstance().resetActiveBatchExecutor();
	}

	private void executeToolAfterFinish() {
		// execute configured tool
		String toolPath = PreferenceUtil.getString(IPreferenceConstants.TOOL_PATH_AFTER_BATCH_FINISH);
		if (StringUtil.isNotNullOrEmpty(toolPath)) {
			try {
				StringBuffer output = FileUtil.startTool(toolPath, true);
				Logger.logInfo("Execution finished with output:\n" + output.toString());
			} catch (IOException e) {
				Logger.logError("Could not start specified tool " + toolPath);
			}
		}
	}

	@Override
	protected void preStop() {
		executeToolAfterFinish();
	}

	@Override
	public void performFinish() {
		if (createdTempDirectories != null) {
			Logger.logInfo("Deleting " + createdTempDirectories.size() + " local temp directories");
			for (File file : createdTempDirectories) {
				try {
					boolean tempDirContainsOutputFolder = false;
					for (File processedOutputFolder : processedOutputFolders) {
						if (FileUtils.directoryContains(file, processedOutputFolder)) {
							tempDirContainsOutputFolder = true;
							break;
						}
					}
					if (!tempDirContainsOutputFolder) {
						int tries = 3;
						for (int i = 0; i < tries;) {
							try {
								FileUtils.deleteDirectory(file);
								break;
							} catch (IOException e) {
								if (i >= tries) {
									throw e;
								}
								try {
									Thread.sleep(100);
								} catch (InterruptedException e1) {
								}
								i++;
							}
						}
					}
				} catch (IOException e) {
					Logger.logError("Unable to delete local temp directory: " + file.getAbsolutePath(), e);
				}
			}
		}
	}

	protected ScheduledSimulation onRestartRequired(SimulationModel model, ScheduledSimulation simToRestart, SimulationState newState) {
		String restartReason = model.resetRestartReason();
		addLogToConsumer(new LogMessage(
				String.format("Re-Queueing simulation %s (State: %s, Reason: %s)", model.getUniqueId(), newState.toString(), restartReason)));
		simToRestart = new ScheduledSimulation(simToRestart.getConfigurationFile(), simToRestart.getParameterSetKey(), simToRestart.getLoader());
		simToRestart.setLabelPrefix("(R) ");
		simToRestart.setLabelSuffix(" (restart due to " + restartReason.toUpperCase() + ")");
		simToRestart.setSimulationStateListeners(model.getSimulationStateListeners());
		return simToRestart;
	}

	@Override
	public void postSimulationStateChanged(final SimulationModel model, SimulationState oldState, SimulationState newState) {
		if (newState == SimulationState.COMPLETED || newState == SimulationState.ABORTED) {
			model.removeSimulationStateListener(this);
			Logger.logInfo("Simulation " + model.getUniqueId() + " finished (" + model.getLongDescription() + ")");
			SimulationKernel.getInstance().doClose(model.getUniqueId(), true);
			if (model.isRestartFlag()) {
				ScheduledSimulation simToRestart = onRestartRequired(model, runningSimulations.get(model), newState);
				currentScheduledSimulations.add(simToRestart);
			}
			activeModels.remove(model);
			runningSimulations.remove(model);
			batchListener.currentSimulationsChanged(currentScheduledSimulations, runningSimulations.values(), false);
			numSimulationsDone++;

			// execute configured tool
			if (numSimulationsDone % (PreferenceUtil.getInt(IPreferenceConstants.TOOL_EXECUTION_INTERVAL,
					IPreferenceConstants.DEFAULT_TOOL_EXECUTION_INTERVAL)) == 0) {
				String toolPath = PreferenceUtil.getString(IPreferenceConstants.TOOL_PATH_DURING_BATCH, "");
				try {
					StringBuffer output = FileUtil.startTool(toolPath, true);
					Logger.logInfo("Execution finished with output:\n" + output.toString());
				} catch (IOException e) {
					Logger.logError("Could not start specified tool " + toolPath);
				}
			}

			proceed();
		}
	}

	@Override
	public void simulationStateChanged(final SimulationModel model, SimulationState oldState, SimulationState newState) {
		// unused
	}

	public void setPause(boolean pause) {
		for (SimulationModel model : activeModels) {
			if (model != null) {
				model.setSimulationRunning(!pause);
			}
		}
		if (pause) {
			pause();
		} else {
			proceed();
		}
	}

	public void stopBatch() {
		isBatchStopping.set(true);
		stopAndDestroy();
		List<SimulationModel> modelsTemp = new ArrayList<>(activeModels);
		for (SimulationModel model : modelsTemp) {
			model.setSimulationRunning(false);
		}
		for (SimulationModel model : modelsTemp) {
			model.stopSimulation(true, false);
			model = null;
		}
		activeModels.clear();
		runningSimulations.clear();
		currentScheduledSimulations.clear();
	}

	protected void addLogToConsumer(LogMessage msg) {
		if (logConsumer != null) {
			logConsumer.addLogLine(msg);
		}
	}

	public int getNumSimulationsDone() {
		return numSimulationsDone;
	}
}

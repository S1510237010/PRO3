package at.fhhagenberg.mc.traffsim.ui.threed;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.TreeMap;
import java.util.Vector;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Mouse;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.poly2tri.Poly2Tri;
import org.poly2tri.geometry.polygon.PolygonPoint;
import org.poly2tri.triangulation.delaunay.DelaunayTriangle;

import com.itextpdf.awt.geom.Rectangle2D;
import com.threed.jpct.Camera;
import com.threed.jpct.Config;
import com.threed.jpct.FrameBuffer;
import com.threed.jpct.IRenderer;
import com.threed.jpct.Interact2D;
import com.threed.jpct.Loader;
import com.threed.jpct.Object3D;
import com.threed.jpct.SimpleVector;
import com.threed.jpct.Texture;
import com.threed.jpct.TextureInfo;
import com.threed.jpct.TextureManager;
import com.threed.jpct.World;
import com.threed.jpct.util.KeyMapper;
import com.threed.jpct.util.KeyState;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.geo.Line;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.ui.BaseUiModel;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.SimulationView;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

public class DDDInit extends BaseUiModel implements ISimulationTimeUpdatable {

	// world variable
	private static World world;
	// draw buffer
	private static FrameBuffer buffer;
	// view port
	private static Camera camera;
	// init distance
	private float distance = 100;

	// mouse button constants
	private final int LEFT_MOUSE_BUTTON = 0;
	private final int RIGHT_MOUSE_BUTTON = 1;

	private Vector<RoadSegment> listOfRoadSegments = new Vector<RoadSegment>();
	private Vector<AbstractJunction> listOfAbstractJunctions = new Vector<AbstractJunction>();

	private TreeMap<Vehicle, Object3D> vehicleMapping = new TreeMap<Vehicle, Object3D>();
	private HashMap<Long, Integer> vehicleColors = new HashMap<>();
	private float rotationFactorOverTheTop = 0;
	// camera rotation factor
	private float cameraRotationFactor = 0.005f;
	// fog color
	private final Color FOG_COLOR = new Color(94, 98, 106);

	// car.3ds object
	private Object3D[] ThreedsObjects;
	// app is running
	private boolean isRunning = false;

	// HUD text (size, form)
	private GLFont glFont = GLFont.getGLFont(new java.awt.Font("Dialog", Font.BOLD, 14));;

	// keymapper for hotkeys
	private KeyMapper keyMapper = new KeyMapper();
	private float verticalRotationSpeed = 0.001f;
	private float horizontalRotationSpeed = 0.001f;
	private int key_zoom_in_out_speed = 0;

	private final int FOGGING_DISTANCE = 10000;
	private final float BLACK_LINE_WIDTH = 0.2f;
	private float WHITE_LINE_WIDTH = 0.1f;
	private float BLUE_LINE_WIDTH = 0.2f;

	private boolean orbitalVerticalRotation = false;
	private boolean orbitalHorizontalRotation = false;
	private boolean key_zoom_in_out = false;
	private boolean moving = false;
	private float moveLeftRight = 0;
	private float moveFrontRear = 0;

	private SimpleVector startVector;
	private float worldOffsetX = 0, worldOffsetY = 0;
	private boolean firstTime = true;
	private Object3D underlayPlane = null;
	private SimulationModel mAktiveModel;
	protected double minX;
	protected double minY;

	private List<String> carTextures = CollectionUtil.createArrayList("carGreen", "carBlue", "carYellow", "carRed");
	private List<String> carTexturesBreak = CollectionUtil.createArrayList("carGreen_break", "carBlue_break", "carYellow_break", "carRed_break");

	private void Config() {
		// window name
		Config.glWindowName = "3D Perspective";
	}

	public DDDInit() {

		Config();

		world = new World();
		// world light values
		world.setAmbientLight(255, 255, 255);
		// set init postion of camera
		world.getCamera().setPosition(0, 0, distance);

		// set fogging
		world.setFogging(World.FOGGING_ENABLED);
		// fog distance
		world.setFogParameters(FOGGING_DISTANCE, FOG_COLOR.getRed(), FOG_COLOR.getGreen(), FOG_COLOR.getBlue());
		// render objects which are within 10000 range
		// world.setClippingPlanes(-100, CLIPPING_DISTANCE);

		camera = world.getCamera();

		Bundle bundle = FrameworkUtil.getBundle(SimulationView.class);

		URL url = FileLocator.find(bundle, new Path("data/texture"), null);

		// load textures
		TextureManager.getInstance().addTexture("skyDome", new Texture(10, 10, Color.blue));

		TextureManager.getInstance().addTexture("car.jpg", new Texture(url, "car.jpg"));
		TextureManager.getInstance().addTexture("carGreen", new Texture(url, "carGreen.jpg"));
		TextureManager.getInstance().addTexture("carBlue", new Texture(url, "carBlue.jpg"));
		TextureManager.getInstance().addTexture("carYellow", new Texture(url, "carYellow.jpg"));
		TextureManager.getInstance().addTexture("carRed", new Texture(url, "carRed.jpg"));
		TextureManager.getInstance().addTexture("carGreen_break", new Texture(url, "carGreen_break.jpg"));
		TextureManager.getInstance().addTexture("carBlue_break", new Texture(url, "carBlue_break.jpg"));
		TextureManager.getInstance().addTexture("carYellow_break", new Texture(url, "carYellow_break.jpg"));
		TextureManager.getInstance().addTexture("carRed_break", new Texture(url, "carRed_break.jpg"));

		TextureManager.getInstance().addTexture("White", new Texture(8, 8, Color.white));
		TextureManager.getInstance().addTexture("Gray", new Texture(8, 8, new Color(200, 200, 200)));
		TextureManager.getInstance().addTexture("Black", new Texture(8, 8, Color.BLACK));
		TextureManager.getInstance().addTexture("Blue", new Texture(8, 8, Color.BLUE));
		TextureManager.getInstance().addTexture("Underlay", new Texture(8, 8, new Color(229, 255, 204)));

		// load 3ds file once
		url = FileLocator.find(bundle, new Path("data/3dsObjects"), null);
		ThreedsObjects = Loader.load3DS(url, "car.3ds", 1);

		SimulationKernel.getInstance().addInputChangedListener(new IModelInputChangedListener() {

			@Override
			public void inputChanged(SimulationModel newModel) {
				mAktiveModel = newModel;
				if (newModel != null) {
					minX = mAktiveModel.getNetwork().getBounds().getMinX();
					minY = mAktiveModel.getNetwork().getBounds().getMinY();
				}
				resetWorld();
				// if (buffer != null) {
				// world.removeAllObjects();
				// listOfRoadSegments = new Vector<RoadSegment>();
				// listOfAbstractJunctions = new
				// Vector<AbstractJunction>();
				// vehicleMapping = new TreeMap<Vehicle, Object3D>();
				// firstTime = true;
				// worldOffsetX = 0;
				// worldOffsetY = 0;
				// underlayPlane = null;
				// }
			}
		});

	}

	private void resetWorld() {
		// System.out.println("RESET ALL !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		world.removeAllObjects();

		listOfRoadSegments = new Vector<RoadSegment>();
		listOfAbstractJunctions = new Vector<AbstractJunction>();
		vehicleMapping = new TreeMap<Vehicle, Object3D>();

		firstTime = true;
		worldOffsetX = 0;
		worldOffsetY = 0;
		underlayPlane = null;

		if (mAktiveModel != null && mAktiveModel.getNetwork() != null) {
			updateRoadnetwork();
		}

	}

	/**
	 * Initialize the 3D world
	 */
	public void init3D() {
		// app is running
		isRunning = true;
		// run in seperate thread
		try {
			new Thread(new Runnable() {
				private float moveUpDown;

				@Override
				public void run() {
					// window size
					buffer = new FrameBuffer(1024, 768, FrameBuffer.SAMPLINGMODE_GL_AA_4X);
					// hardware renderer
					buffer.disableRenderer(IRenderer.RENDERER_SOFTWARE);
					buffer.enableRenderer(IRenderer.RENDERER_OPENGL);
					// draw loop
					while (!org.lwjgl.opengl.Display.isCloseRequested()) {
						// background color
						buffer.clear(java.awt.Color.WHITE);
						world.renderScene(buffer);
						world.draw(buffer);
						buffer.update();

						// draw HUD
						blitString();

						buffer.displayGLOnly();
						// check for mouse or key event
						move();
						poll();

						if (listOfRoadSegments.size() > 0 && listOfAbstractJunctions.size() > 0) {
							updateVehicles();
						}

					}
					buffer.disableRenderer(IRenderer.RENDERER_OPENGL);
					buffer.dispose();
					// world.dispose();

					// clear variables if 3D Window closed
					listOfRoadSegments = new Vector<RoadSegment>();
					listOfAbstractJunctions = new Vector<AbstractJunction>();
					vehicleMapping = new TreeMap<Vehicle, Object3D>();
					isRunning = false;
					firstTime = true;
					worldOffsetX = 0;
					worldOffsetY = 0;
					// Display.destroy();
				}

				/**
				 * Use the KeyMapper to poll the keyboard
				 */
				private void poll() {
					KeyState state = null;
					while ((state = keyMapper.poll()) != KeyState.NONE) {
						if (state.getKeyCode() == KeyEvent.VK_ADD) {
							key_zoom_in_out = true;
							key_zoom_in_out_speed = 10;
						}
						if (state.getKeyCode() == KeyEvent.VK_SUBTRACT) {
							key_zoom_in_out = true;
							key_zoom_in_out_speed = -10;
						}
						if (state.getKeyCode() == KeyEvent.VK_C) {
							setCenteredCamera();
						}
						if (state.getKeyCode() == KeyEvent.VK_DOWN) {
							orbitalVerticalRotation = true;
							verticalRotationSpeed = 0.001f;
						}
						if (state.getKeyCode() == KeyEvent.VK_UP) {
							orbitalVerticalRotation = true;
							verticalRotationSpeed = -0.001f;
						}
						if (state.getKeyCode() == KeyEvent.VK_RIGHT) {
							orbitalHorizontalRotation = true;
							horizontalRotationSpeed = 0.001f;
						}
						if (state.getKeyCode() == KeyEvent.VK_LEFT) {
							orbitalHorizontalRotation = true;
							horizontalRotationSpeed = -0.001f;
						}

						if (state.getKeyCode() == 'A') {
							moving = true;
							moveLeftRight = 0.1f;
						}
						if (state.getKeyCode() == 'D') {
							moving = true;
							moveLeftRight = -0.1f;
						}
						if (state.getKeyCode() == 'W') {
							moving = true;
							moveFrontRear = 0.15f;
						}
						if (state.getKeyCode() == 'S') {
							moving = true;
							moveFrontRear = -0.15f;
						}
						if (state.getKeyCode() == 'Q') {
							moving = true;
							moveUpDown = 0.05f;
						}
						if (state.getKeyCode() == 'E') {
							moving = true;
							moveUpDown = -0.05f;
						}
						if (state.getState() == KeyState.RELEASED) {
							if (equalsAny(state.getKeyCode(), KeyEvent.VK_DOWN, KeyEvent.VK_UP)) {
								orbitalVerticalRotation = false;
								verticalRotationSpeed = 0f;
							}
							if (equalsAny(state.getKeyCode(), KeyEvent.VK_RIGHT, KeyEvent.VK_LEFT)) {
								orbitalHorizontalRotation = false;
								horizontalRotationSpeed = 0;
							}
							if (equalsAny(state.getKeyCode(), 'W', 'S')) {
								moveFrontRear = 0;
							}
							if (equalsAny(state.getKeyCode(), 'A', 'D')) {
								moveLeftRight = 0;
							}
							if (equalsAny(state.getKeyCode(), 'Q', 'E')) {
								moveUpDown = 0;
							}
							key_zoom_in_out = false;
						}
						try {
							Thread.sleep(2);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

				}

				/**
				 * Create HUD
				 */
				private void blitString() {
					if (world != null && buffer != null && camera != null) {
						glFont.blitString(buffer,
								"Camera Position: " + "x : " + (int) (camera.getPosition().x + worldOffsetX) + "; y: "
										+ (int) (camera.getPosition().y + worldOffsetY) + "; z: " + (int) camera.getPosition().z,
								0, 14, 0, Color.BLACK);

						glFont.blitString(buffer, "Rotation: " + (int) (toAngle() + rotationFactorOverTheTop), 0, 28, 0, Color.BLACK);

						glFont.blitString(buffer, "Options: Center camera: 'C'", 0, 42, 0, Color.BLACK);
					}
				}

				/**
				 * Vertical rotation of the orbital camera
				 *
				 * @param delta
				 *            mouse moving distance
				 */
				private void orbitalRotationVertical(float delta) {
					if (Math.abs(delta) > 0.3f) {
						return;
					}
					// additional factor if camera rotates to 90 degrees
					if (toAngle() >= 89) {
						if (toAngle() >= 90) {
							rotationFactorOverTheTop = 2;
						} else {
							rotationFactorOverTheTop = 1;
						}
					} else {
						rotationFactorOverTheTop = 0;
					}
					// factor for slow down
					float factor = 1;
					// current angle of the camera
					float angle = (float) toAngle() + rotationFactorOverTheTop;
					// if angle is bigger then 88 and tries to rotate
					// above
					// 90 degrees
					if (angle > 88.0f & delta < 0) {
						return;
					}
					// if angle is smaller than 6 and tries to rotate
					// below
					// 5 degrees
					if (angle < 6.0f & delta > 0) {
						return;
					}
					// reduce rotation speed
					if (angle > 85.0f | angle < 10.0f) {
						factor = 0.2f;
						if (delta > 0.2) {
							return;
						}
					}
					// dist of rotation point
					float dist = getCamDistance();
					// move camera in
					camera.moveCamera(Camera.CAMERA_MOVEIN, dist);
					// rotate camera inverted (-delta)
					camera.rotateCameraAxis(new SimpleVector(1, 0, 0), -delta * factor);
					// move camera out
					camera.moveCamera(Camera.CAMERA_MOVEOUT, dist);
				}

				/**
				 * Horizontal rotation of the orbital camera
				 *
				 * @param delta
				 *            mouse moving distance
				 */
				private void orbitalRotationHorizontal(float delta) {
					float dist = getCamDistance();
					camera.moveCamera(Camera.CAMERA_MOVEIN, dist);
					camera.rotateCameraAxis(camera.getZAxis(), delta);
					camera.moveCamera(Camera.CAMERA_MOVEOUT, dist);
				}

				private void move() {
					if (!Mouse.isCreated()) {
						try {
							Mouse.create();
						} catch (LWJGLException e1) {
							e1.printStackTrace();
						}
					}
					int deltaX = Mouse.getDX();
					int deltaY = Mouse.getDY();

					int w = Mouse.getDWheel();
					if (Mouse.isButtonDown(LEFT_MOUSE_BUTTON)) {
						if (deltaX != deltaY) {
							// vertical or horizontal rotation
							if (Math.abs(deltaY) >= Math.abs(deltaX)) {
								orbitalRotationVertical(deltaY * cameraRotationFactor);
							} else if (Math.abs(deltaY) < Math.abs(deltaX)) {
								orbitalRotationHorizontal(deltaX * cameraRotationFactor);
							}
						}
					}
					// zoom in-out
					if (w != 0) {
						zoomInOut(w);
					}
					// translate camera postion
					if (Mouse.isButtonDown(RIGHT_MOUSE_BUTTON)) {

						if (startVector == null) {
							startVector = convert2DMousePosto3DWorld(Mouse.getX(), Mouse.getY());
						} else {
							SimpleVector currentVector = convert2DMousePosto3DWorld(Mouse.getX(), Mouse.getY());
							float x = currentVector.x - startVector.x;
							float y = currentVector.y - startVector.y;

							worldOffsetX += x;
							worldOffsetY += y;
							translateWorldObjects(x, y);
							startVector = currentVector;
						}
					} else {
						startVector = null;
					}
					if (moving) {
						camera.moveCamera(Camera.CAMERA_MOVELEFT, moveLeftRight);
						camera.moveCamera(Camera.CAMERA_MOVEIN, moveFrontRear);
						camera.moveCamera(Camera.CAMERA_MOVEUP, moveUpDown);
					}
					if (orbitalHorizontalRotation) {
						orbitalRotationHorizontal(horizontalRotationSpeed);
					} else if (orbitalVerticalRotation) {
						orbitalRotationVertical(verticalRotationSpeed);
					}
					if (key_zoom_in_out) {
						zoomInOut(key_zoom_in_out_speed);
					}
				}
			}).start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private boolean equalsAny(int code, int... matches) {
		for (int b : matches) {
			if (b == code) {
				return true;
			}
		}
		return false;
	}

	private SimpleVector convert2DMousePosto3DWorld(int deltaX, int deltaY) {
		int x = deltaX;
		int y = buffer.getOutputHeight() - deltaY;

		SimpleVector dir = Interact2D.reproject2D3DWS(world.getCamera(), buffer, x, y).normalize();
		SimpleVector pos = world.getCamera().getPosition();

		float a = (0 - pos.z) / dir.z;

		float xn = pos.x + a * dir.x;
		float yn = pos.y + a * dir.y;

		return new SimpleVector(xn, yn, 0);

	}

	private void translateWorldObjects(float x, float y) {
		Enumeration<?> objs = world.getObjects();
		while (objs.hasMoreElements()) {
			Object o = objs.nextElement();
			if (o instanceof Object3D) {
				((Object3D) o).translate(x, y, 0);
			}
		}
	}

	private void zoomInOut(float delta) {
		camera.moveCamera(Camera.CAMERA_MOVEIN, (float) (delta * (camera.getPosition().z * 0.001)));
		// the camera can zoom till z = 0
		if (camera.getPosition().z < 0) {
			camera.moveCamera(Camera.CAMERA_MOVEOUT, (float) (delta * (camera.getPosition().z * 0.001)));
		}
	}

	/**
	 * Get camera distance which it looks at
	 *
	 * @return distance to point
	 */
	private float getCamDistance() {
		// move camera in till its z value is 0.
		// thats the distance
		SimpleVector pos = camera.getPosition();
		float dist = 0;
		do {
			dist++;
			camera.moveCamera(Camera.CAMERA_MOVEIN, 1);
		} while (camera.getPosition().z > 0 && pos.z > camera.getPosition().z);
		// reset camera position
		camera.setPosition(pos);
		return dist;
	}

	/**
	 * Calculate rotation angle
	 *
	 * @return
	 */
	private double toAngle() {
		return Math.toDegrees(Math.asin((camera.getPosition().z) / getCamDistance()));
	}

	/**
	 * Draw the road segment
	 *
	 * @param seg
	 *            Road segment
	 */
	private void drawRoadSegment(RoadSegment seg) {
		// if road segment is not part of the world
		if (!listOfRoadSegments.contains(seg)) {
			// add to world list
			listOfRoadSegments.add(seg);

			// calc lane line
			RoadGeometry geom = seg.getRoadGeometry();
			List<at.fhhagenberg.mc.traffsim.model.geo.Vector> points = geom.getPoints();
			SimpleVector linePoints[] = new SimpleVector[points.size()];
			for (int i = 0; i < points.size(); i++) {
				linePoints[i] = new SimpleVector(points.get(i).x - minX, points.get(i).y - minY, 0);
			}
			createObject3DLine(linePoints, "Blue", BLUE_LINE_WIDTH);

			// construct all lane segments in the road segment
			for (LaneSegment ls : seg.getLaneSegments()) {

				// background
				List<at.fhhagenberg.mc.traffsim.model.geo.Vector> leftEdge = ls.getLeftEdge();
				List<at.fhhagenberg.mc.traffsim.model.geo.Vector> rightEdge = ls.getRightEdge();

				// fill Vector with polygon points
				Vector<PolygonPoint> polygonPoints = new Vector<PolygonPoint>();
				PolygonPoint p;
				for (int i = 0; i < leftEdge.size(); i++) {
					p = new PolygonPoint(leftEdge.get(i).x - minX, leftEdge.get(i).y - minY);
					// setDomeCenter(p);
					polygonPoints.add(p);
				}
				for (int i = rightEdge.size() - 1; i >= 0; i--) {
					p = new PolygonPoint(rightEdge.get(i).x - minX, rightEdge.get(i).y - minY);
					// setDomeCenter(p);
					polygonPoints.add(p);
				}

				// remove collinear points
				// polygonPoints = removeCollinearPoint(polygonPoints);

				// create 3D object
				Object3D obj = createObject3DFromPolygonPoints(polygonPoints);

				// load lane texture
				TextureInfo ti = new TextureInfo(TextureManager.getInstance().getTextureID("Gray"));

				// set texture
				obj.setTexture(ti);
				obj.build();
				addObjectToWorld(obj);

				// right lane line
				SimpleVector linePointsLane[] = new SimpleVector[rightEdge.size()];
				for (int i = 0; i < rightEdge.size(); i++) {
					linePointsLane[i] = new SimpleVector(rightEdge.get(i).x - minX, rightEdge.get(i).y - minY, 0);
				}

				if (ls.getLaneIndex() >= 0 && ls.getLaneIndex() < ls.getRoadSegment().getLaneCount()) {
					if (ls.getLaneIndex() < ls.getRoadSegment().getLaneCount() - 1) {
						// fahrspurgegrenzung
						createObject3DLine(linePointsLane, "White", WHITE_LINE_WIDTH);
					} else {
						// randlinie
						createObject3DLine(linePointsLane, "Black", BLACK_LINE_WIDTH);

					}
				}
			}
		}
	}

	/**
	 * Adds a new vehicle to the world
	 *
	 * @param vehicle
	 */
	private void addVehicleToWorld(Vehicle vehicle) {
		// create 3D object
		Object3D car = createVehilceObject3D();
		if (!vehicleColors.containsKey(vehicle.getUniqueId())) {
			vehicleColors.put(vehicle.getUniqueId(), new Random().nextInt(carTextures.size()));
		}

		// set texture
		car.setTexture(carTextures.get(vehicleColors.get(vehicle.getUniqueId())));
		car.build();
		addObjectToWorld(car);
		// set vehicle position
		car.translate((float) (car.getTransformedCenter().x + worldOffsetX - minX), (float) (car.getTransformedCenter().y + worldOffsetY - minY), 1);
		// add to tree map
		vehicleMapping.put(vehicle, car);
	}

	/**
	 * Change vehicle position
	 *
	 * @param vehicle
	 */
	private void translateVehicle(Vehicle vehicle) {
		// get 3D object of the vehicle
		Object3D obj = vehicleMapping.get(vehicle);
		at.fhhagenberg.mc.traffsim.model.geo.Vector pos = vehicle.getAbsolutePosition();
		SimpleVector currentPos = obj.getTransformedCenter();
		SimpleVector newPos = new SimpleVector(pos.x + worldOffsetX - minX, pos.y + worldOffsetY - minY, 0);
		SimpleVector s = newPos.calcSub(currentPos);
		obj.translate(new SimpleVector(s.x, s.y, 0));
	}

	/**
	 * Rotate vehicle object
	 *
	 * @param vehicle
	 */
	private void rotateVehicle(Vehicle vehicle) {
		Object3D obj = vehicleMapping.get(vehicle);
		// clear rotation
		obj.clearRotation();
		// rotate around an absolute value
		obj.rotateZ((float) -vehicle.getDrivingAngle());
	}

	/**
	 * Change the vehicle texture based on vehicle status
	 *
	 * @param vehicle
	 */
	private void setVehicleTexture(Vehicle vehicle) {
		Object3D obj = vehicleMapping.get(vehicle);
		if (vehicle.getCurrentAcc() > 0.01 || NumberUtil.doubleEquals(vehicle.getCurrentSpeed(), 0)) {
			obj.setTexture(carTextures.get(vehicleColors.get(vehicle.getUniqueId())));
		}
		if (vehicle.getCurrentAcc() < -0.05 && !NumberUtil.doubleEquals(vehicle.getCurrentSpeed(), 0)) {
			obj.setTexture(carTexturesBreak.get(vehicleColors.get(vehicle.getUniqueId())));
		}
	}

	/**
	 * Update vehicles in the world (rotation, translation, texture)
	 *
	 * @param vehicle
	 */
	private void updateVehicleInWorld(Vehicle vehicle) {
		// if vehicle is part of the world
		if (vehicleMapping.containsKey(vehicle)) {
			translateVehicle(vehicle);
			// ------------------------------------------------------------------------------------
			rotateVehicle(vehicle);
			// ------------------------------------------------------------------------------------
			setVehicleTexture(vehicle);
			// ------------------------------------------------------------------------------------

		}
	}

	/**
	 * Delete vehicles from the world
	 */
	private void removeUnusedVehicles() {
		// List of which vehciles should be removed
		Vector<Vehicle> deathList = new Vector<Vehicle>();
		for (Vehicle vehicle : vehicleMapping.keySet()) {// listOfVehilces){
			boolean isUsed = false;
			for (RoadSegment seg : listOfRoadSegments) {
				for (Vehicle veh : seg.getAllVehicles()) {
					if (vehicle == veh) {
						isUsed = true;
					}
				}
			}
			for (AbstractJunction junc : listOfAbstractJunctions) {
				for (Vehicle vehicleInJunc : junc.getVehicles()) {
					if (vehicle == vehicleInJunc) {
						isUsed = true;
					}
				}
			}
			if (!isUsed) {
				deathList.add(vehicle);
			}
		}
		for (Vehicle v : deathList) {
			removeVehicleFromWorld(v);
		}
	}

	/**
	 * Update vehicles based on all roadsegments and junctions
	 */
	private void updateVehicles() {
		for (RoadSegment seg : listOfRoadSegments) {
			for (Vehicle vehicle : seg.getAllVehicles()) {
				if (vehicle.getBoundsPolygon() != null) {
					if (!vehicleMapping.containsKey(vehicle)) {
						addVehicleToWorld(vehicle);
					} else {
						updateVehicleInWorld(vehicle);
					}
				}
			}
		}
		for (AbstractJunction junc : listOfAbstractJunctions) {
			for (Vehicle vehicle : junc.getVehicles()) {
				if (vehicle.getBoundsPolygon() != null) {
					if (!vehicleMapping.containsKey(vehicle)) {
						addVehicleToWorld(vehicle);
					} else {
						updateVehicleInWorld(vehicle);
					}
				}
			}
		}
		removeUnusedVehicles();
	}

	private void updateRoadnetwork() {
		RoadNetwork network;
		if (mAktiveModel != null) {
			network = mAktiveModel.getNetwork();
			if (firstTime) {
				setCenteredCamera();
				firstTime = false;
			}
		} else {
			return;
		}

		if (underlayPlane == null) {
			drawUnderlay();
		}
		if (network != null) {
			for (RoadSegment seg : network.getRoadSegments()) {
				drawRoadSegment(seg);
			}
			for (AbstractJunction junc : network.getJunctions()) {
				drawJunction(junc);
			}
		}
	}

	/**
	 * Draw junctions
	 *
	 * @param junc
	 *            Junction
	 */
	private void drawJunction(AbstractJunction junc) {
		// if junction is not part of the world
		if (!listOfAbstractJunctions.contains(junc)) {
			// add junction to the world
			listOfAbstractJunctions.add(junc);

			// calc junction polygon points
			Vector<PolygonPoint> polygonPoints = new Vector<PolygonPoint>();
			PolygonPoint p;
			for (at.fhhagenberg.mc.traffsim.model.geo.Vector v : junc.getBounds()) {
				p = new PolygonPoint(v.x - minX, v.y - minY);
				polygonPoints.add(p);
			}
			// create junction object
			Object3D obj = createObject3DFromPolygonPoints(polygonPoints);
			obj.setTexture(new TextureInfo(TextureManager.getInstance().getTextureID("Gray")));
			obj.build();
			addObjectToWorld(obj);

			// junction outline
			for (Line l : junc.getOpenEdges()) {
				SimpleVector juncBounds[] = new SimpleVector[l.getPoints().size()];
				for (int i = 0; i < l.getPoints().size(); i++) {
					at.fhhagenberg.mc.traffsim.model.geo.Vector pt = l.getPoints().get(i);
					juncBounds[i] = new SimpleVector(pt.x + worldOffsetX - minX, pt.y + worldOffsetY - minY, 0);
				}
				createObject3DLine(juncBounds, "Black", BLACK_LINE_WIDTH);
			}
		}
	}

	private void createObject3DLine(SimpleVector[] polypoint, String string, float f) {
		Object3D obj;
		for (int i = 0; i < polypoint.length - 1; i++) {
			obj = createLine(polypoint[i], polypoint[i + 1], f, string);
			addObjectToWorld(obj);
		}

	}

	private Object3D createLine(SimpleVector pointA, SimpleVector pointB, float width, String texture) {
		Object3D line = new Object3D(12);
		float offset = width / 2.0f;
		float top = 0.1f;
		float zOffset = 0.05f;

		line.addTriangle(new SimpleVector(pointA.x, pointA.y - offset, top), 0, 0, new SimpleVector(pointA.x, pointA.y + offset, top), 0, 1,
				new SimpleVector(pointB.x, pointB.y + offset, top), 1, 1, TextureManager.getInstance().getTextureID(texture));
		line.addTriangle(new SimpleVector(pointB.x, pointB.y + offset, top), 0, 0, new SimpleVector(pointB.x, pointB.y - offset, top), 0, 1,
				new SimpleVector(pointA.x, pointA.y - offset, top), 1, 1, TextureManager.getInstance().getTextureID(texture));
		// Quad A, back-face:
		line.addTriangle(new SimpleVector(pointB.x, pointB.y - offset, top), 0, 0, new SimpleVector(pointB.x, pointB.y + offset, top), 0, 1,
				new SimpleVector(pointA.x, pointA.y + offset, top), 1, 1, TextureManager.getInstance().getTextureID(texture));
		line.addTriangle(new SimpleVector(pointA.x, pointA.y + offset, top), 0, 0, new SimpleVector(pointA.x, pointA.y - offset, top), 0, 1,
				new SimpleVector(pointB.x, pointB.y - offset, top), 1, 1, TextureManager.getInstance().getTextureID(texture));
		// Quad B:
		line.addTriangle(new SimpleVector(pointA.x, pointA.y, top + zOffset), 0, 0, new SimpleVector(pointA.x, pointA.y, top - zOffset), 0, 1,
				new SimpleVector(pointB.x, pointB.y, top - zOffset), 1, 1, TextureManager.getInstance().getTextureID(texture));
		line.addTriangle(new SimpleVector(pointB.x, pointB.y, top - zOffset), 0, 0, new SimpleVector(pointB.x, pointB.y, top + zOffset), 0, 1,
				new SimpleVector(pointA.x, pointA.y, top + zOffset), 1, 1, TextureManager.getInstance().getTextureID(texture));
		// Quad B, back-face:
		line.addTriangle(new SimpleVector(pointB.x, pointB.y, top + zOffset), 0, 0, new SimpleVector(pointB.x, pointB.y, top - zOffset), 0, 1,
				new SimpleVector(pointA.x, pointA.y, top - zOffset), 1, 1, TextureManager.getInstance().getTextureID(texture));
		line.addTriangle(new SimpleVector(pointA.x, pointA.y, top - zOffset), 0, 0, new SimpleVector(pointA.x, pointA.y, top + zOffset), 0, 1,
				new SimpleVector(pointB.x, pointB.y, top + zOffset), 1, 1, TextureManager.getInstance().getTextureID(texture));

		// done
		return line;
	}

	private void addObjectToWorld(Object3D obj) {
		world.addObject(obj);
		// System.out.println("Created new Object3D " + mObjCounter);
	}

	/**
	 * Remove specific vehicle from the world
	 *
	 * @param vehicle
	 */
	private void removeVehicleFromWorld(Vehicle vehicle) {
		if (vehicleMapping.containsKey(vehicle)) {
			Object3D obj = vehicleMapping.get(vehicle);
			// remove vehicle object
			world.removeObject(obj);
			// delete vehicle from tree map
			vehicleMapping.remove(vehicle);
		}
	}

	/**
	 * Constructs the 3D object based on poygon points
	 *
	 * @param polygonPoints
	 * @return
	 */
	private Object3D createObject3DFromPolygonPoints(Vector<PolygonPoint> polygonPoints) {
		org.poly2tri.geometry.polygon.Polygon poly = new org.poly2tri.geometry.polygon.Polygon(polygonPoints);
		// delunay trianglutation
		try {
			Poly2Tri.triangulate(poly);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// triangle net
		List<DelaunayTriangle> triangles = poly.getTriangles();

		// object as big as size of triangles
		Object3D obj = new Object3D(triangles.size());
		// add all triangles to object
		for (DelaunayTriangle tri : triangles) {
			SimpleVector s1 = new SimpleVector(tri.points[0].getX(), tri.points[0].getY(), 0);
			SimpleVector s2 = new SimpleVector(tri.points[1].getX(), tri.points[1].getY(), 0);
			SimpleVector s3 = new SimpleVector(tri.points[2].getX(), tri.points[2].getY(), 0);

			obj.addTriangle(s1, s2, s3);
		}
		obj.setCollisionMode(Object3D.COLLISION_CHECK_OTHERS);
		obj.setCollisionOptimization(true);
		return obj;
	}

	/**
	 * Create vehicle object
	 *
	 * @return Object3D
	 */
	private Object3D createVehilceObject3D() {
		// use 3ds object
		return new Object3D(ThreedsObjects[0]);
	}

	/**
	 * Zoom into a crash
	 *
	 * @param position
	 */
	public void zoomToCrash(SimpleVector position) {
		camera.setPosition(new SimpleVector(position.x, position.y, 100));
		camera.lookAt(position);
	}

	/**
	 * Is the app running
	 *
	 * @return true or false
	 */
	public boolean isRunning() {
		return isRunning;
	}

	private void drawUnderlay() {
		underlayPlane = createUnderlay();
	}

	private Object3D createUnderlay() {
		Rectangle2D boundingBox = mAktiveModel.getNetwork().getBounds();

		double x = boundingBox.getX() - minX;
		double y = boundingBox.getY() - minY;
		double width = boundingBox.getWidth();
		double height = boundingBox.getHeight();

		SimpleVector leftUp = new SimpleVector(x, y, -1);
		SimpleVector leftDown = new SimpleVector(x + width, y, -1);
		SimpleVector rightUp = new SimpleVector(x, y + height, -1);
		SimpleVector rightDown = new SimpleVector(x + width, y + height, -1);

		Object3D tmp = new Object3D(2);
		tmp.addTriangle(leftUp, rightDown, rightUp);
		tmp.addTriangle(leftDown, rightDown, leftUp);
		tmp.setTexture(new TextureInfo(TextureManager.getInstance().getTextureID("Underlay")));
		tmp.build();
		addObjectToWorld(tmp);
		return tmp;
	}

	/**
	 * Set the camera in the middle of the road network
	 */
	private void setCenteredCamera() {
		Rectangle2D boundingBox = (mAktiveModel.getNetwork().getBounds());
		// use width or height of the rectangle to move the camera to a
		// correct distance
		if (boundingBox.getHeight() >= boundingBox.getWidth()) {
			camera.setPosition(new SimpleVector(boundingBox.getCenterX() + worldOffsetX - minX, boundingBox.getCenterY() + worldOffsetY - minY,
					Math.min(boundingBox.getHeight(), FOGGING_DISTANCE * 0.8)));
		} else {
			camera.setPosition(new SimpleVector(boundingBox.getCenterX() + worldOffsetX - minX, boundingBox.getCenterY() + worldOffsetY - minY,
					Math.min(boundingBox.getWidth(), FOGGING_DISTANCE * 0.8)));
		}
		// lookAt the point below with a small rotation
		camera.lookAt(new SimpleVector(boundingBox.getCenterX() + worldOffsetX - 1 - minX, boundingBox.getCenterY() + worldOffsetY + 1 - minY, 0));
		// rotate camera around to look at the world correctly
		camera.rotateZ((float) Math.toRadians(180));
	}

	@Override
	public void timeStep(double dt, Date time, double runTime) {

	}

	@Override
	public void updateView(boolean forceRedraw) {

	}

	@Override
	public void clickedOn(Point screenCoords, int mouseOptionState) {
		// TODO Auto-generated method stub

	}
}

package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.CyclicControlLogicBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

/**
 * Implementation of a control logic providing all parameters required to realize a cyclic control scheme (e.g. phase length, delay for
 * phase switching).
 *
 * @author Manuel Lindorfer
 *
 */
public class CyclicControlLogic extends ControlLogic {

	private long delay;
	private long phaseLength;

	/**
	 * Creates a new instance of cyclic control logic for the target traffic light using the default phase length and phase switching delay.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 */
	public CyclicControlLogic(TrafficLight trafficLight) {
		super(trafficLight);
		this.delay = PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_DELAY);
		this.phaseLength = PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_PHASE_LENGTH);
	}

	/**
	 * Creates a new instance of cyclic control logic for the target traffic light using the given phase length and the default phase
	 * switching delay.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 * @param phaseLength
	 *            (green) phase length in milliseconds
	 */
	public CyclicControlLogic(TrafficLight trafficLight, long phaseLength) {
		super(trafficLight);
		this.phaseLength = phaseLength;
		this.delay = PreferenceUtil.getInt(IPreferenceConstants.TRAFFIC_LIGHT_DELAY);
	}

	/**
	 * Creates a new instance of cyclic control logic for the target traffic light using the given phase length and phase switching delay.
	 *
	 * @param trafficLight
	 *            the target traffic light
	 * @param phaseLength
	 *            (green) phase length in milliseconds
	 * @param delay
	 *            the delay introduced before switching phases in milliseconds
	 */
	public CyclicControlLogic(TrafficLight trafficLight, long phaseLength, long delay) {
		super(trafficLight);
		this.phaseLength = phaseLength;
		this.delay = delay;
	}

	/**
	 * Get's the control logic's (green) phase length.
	 *
	 * @return phase length in milliseconds
	 */
	public long getPhaseLength() {
		return phaseLength;
	}

	/**
	 * Set's the control logic's (green) phase length.
	 *
	 * @param phaseLength
	 *            phase length in milliseconds
	 */
	public void setPhaseLength(long phaseLength) {
		this.phaseLength = phaseLength;
	}

	/**
	 * Get's the control logic's phase switching delay.
	 *
	 * @return delay in milliseconds
	 */
	public long getDelay() {
		return delay;
	}

	/**
	 * Set's the control logic's phase switching delay.
	 *
	 * @param delay
	 *            delay in milliseconds
	 */
	public void setDelay(long delay) {
		this.delay = delay;
	}

	@Override
	public ControlLogicBean toBean() {
		CyclicControlLogicBean bean = new CyclicControlLogicBean();
		bean.setTrafficLightId(trafficLight.getId());
		bean.setDelay(delay);
		bean.setPhaseLength(phaseLength);
		return bean;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.distraction;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionType.DurationDistribution;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.IDistractibleLongitudinalControl;
import at.fhhagenberg.mc.util.CollectionUtil;

public class DistractionModel implements ISimulationTimeUpdatable, IVehicleGeneratorListener, IVehicleListener {

	private List<Vehicle> distractibleVehicles = new ArrayList<>();
	private Map<Vehicle, Double> distractedVehicles = new HashMap<>();
	private Map<DistractionType, Double> interArrivalTimes = new HashMap<>();
	private Map<Long, List<Vehicle>> vehiclesPerType = new HashMap<>();
	private List<DistractionType> distractionTypes = new ArrayList<>();
	private double updateInterval;
	private double timeElapsed;
	private Random randArrival = new Random(1l);
	private Random randExposure = new Random(3l);

	private Map<Long, List<Double>> durations = new HashMap<>();
	private Map<Long, List<Long>> exposure = new HashMap<>();
	private long numTargetVehicles = 0;
	private boolean isArrivalStochastic = false;
	private boolean isExposureStochastic = false;

	private Lock vehiclesLock = new ReentrantLock();

	public double getUpdateInterval() {
		return updateInterval;
	}

	public void setUpdateInterval(double updateInterval) {
		this.updateInterval = updateInterval;
	}

	public void setArrivalStochastic(boolean isStochastic) {
		this.isArrivalStochastic = isStochastic;
	}

	public void setExposureStochastic(boolean isExposureStochastic) {
		this.isExposureStochastic = isExposureStochastic;
	}

	public List<DistractionType> getDistractionTypes() {
		return distractionTypes;
	}

	public void addDistractionType(DistractionType distractionType) {
		if (distractionType != null && !distractionTypes.contains(distractionType)) {
			distractionType.initialize();
			distractionTypes.add(distractionType);
		}
	}

	public void removeDistractionType(DistractionType distractionType) {
		if (distractionType != null && distractionTypes.contains(distractionType)) {
			distractionTypes.remove(distractionType);
		}
	}

	public void initialize(List<? extends Vehicle> vehicles) {
		if (vehicles == null || vehicles.isEmpty()) {
			throw new IllegalArgumentException("Vehicles must not be null or empty");
		}

		if (distractionTypes.isEmpty()) {
			throw new IllegalArgumentException("Distraction types must be initialized first");
		}

		for (DistractionType type : distractionTypes) {
			double exposure = type.getExposure();
			List<Vehicle> veh = new ArrayList<>();

			for (Vehicle v : vehicles) {
				double rand = getNextRandom(isExposureStochastic, randExposure);

				if (rand < exposure) {
					veh.add(v);
				}
			}

			vehiclesPerType.put(type.getId(), veh);
		}
	}

	public void reset() {
		distractedVehicles.clear();
		interArrivalTimes.clear();
		durations.clear();
		exposure.clear();
		vehiclesPerType.clear();
		numTargetVehicles = 0;
	}

	@Override
	public void timeStep(double dt, Date simulationTime, double simulationRunTime) {

		if (timeElapsed < updateInterval) {
			timeElapsed += dt;
			return;
		}

		List<Vehicle> vehicles = new ArrayList<>(distractedVehicles.keySet());

		for (Vehicle vehicle : vehicles) {
			processDistractedVehicle(vehicle, timeElapsed > 0 ? timeElapsed : dt);
		}

		for (DistractionType type : distractionTypes) {
			processDistractionType(type, timeElapsed > 0 ? timeElapsed : dt);
		}

		timeElapsed = 0;
	}

	private void processDistractedVehicle(Vehicle vehicle, double dt) {
		double duration = distractedVehicles.get(vehicle);
		duration -= dt;

		if (duration < 0) {
			IDistractibleLongitudinalControl longControl = (IDistractibleLongitudinalControl) vehicle.getLongitudinalControl();

			if (longControl.isSeverelyDistracted()) {
				longControl.setSeverelyDistracted(false);
				longControl.setDistracted(false);
			} else {
				longControl.distract(1 / longControl.getDelayFactor());
				longControl.setDistracted(false);
			}

			distractedVehicles.remove(vehicle);
		} else {
			distractedVehicles.put(vehicle, duration);
		}
	}

	private void processDistractionType(DistractionType type, double dt) {
		if (!interArrivalTimes.containsKey(type)) {
			interArrivalTimes.put(type, getExponentialArrivalTime(1.0 / type.getAverageInterArrivalTime()));
		} else {
			double arrivalTime = interArrivalTimes.get(type);
			arrivalTime -= dt;

			if (arrivalTime < 0) {
				Vehicle targetVehicle = getTargetVehicle(type);

				if (targetVehicle != null) {
					IDistractibleLongitudinalControl longControl = (IDistractibleLongitudinalControl) targetVehicle.getLongitudinalControl();
					double duration = type.getDuration(DurationDistribution.LOG_NORMAL, false);

					if (type.isSevere()) {
						longControl.setDistracted(true);
						longControl.setSeverelyDistracted(true);
						targetVehicle.onVehicleDistracted(duration, true);
					} else {
						longControl.distract(1 + type.getResponseTimeIncrease() / 100.0);
						longControl.setDistracted(true);
						targetVehicle.onVehicleDistracted(duration, false);
					}

					updateStatistics(type.getId(), targetVehicle.getUniqueId(), duration);
					distractedVehicles.put(targetVehicle, duration);
				}

				interArrivalTimes.put(type, getExponentialArrivalTime(1.0 / type.getAverageInterArrivalTime()));
			} else {
				interArrivalTimes.put(type, arrivalTime);
			}
		}
	}

	private void updateStatistics(long typeId, long vehicleId, double duration) {
		if (!exposure.containsKey(typeId)) {
			List<Long> vehicleIds = new ArrayList<>();
			vehicleIds.add(vehicleId);
			exposure.put(typeId, vehicleIds);
		} else {
			List<Long> vehicleIds = exposure.get(typeId);

			if (!vehicleIds.contains(vehicleId)) {
				vehicleIds.add(vehicleId);
			}

			exposure.put(typeId, vehicleIds);
		}

		if (!durations.containsKey(typeId)) {
			List<Double> dur = new ArrayList<>();
			dur.add(duration);
			durations.put(typeId, dur);
		} else {
			List<Double> dur = durations.get(typeId);
			dur.add(duration);
			durations.put(typeId, dur);
		}
	}

	private Vehicle getTargetVehicle(DistractionType type) {
		List<Vehicle> vehicles = distractibleVehicles.stream()
				.filter(v -> !distractedVehicles.containsKey(v) && vehiclesPerType.get(type.getId()).contains(v)).collect(Collectors.toList());

		if (vehicles == null || vehicles.isEmpty()) {
			return null;
		}

		Vehicle targetVehicle = isExposureStochastic ? CollectionUtil.getRandomElement(vehicles, 0)
				: CollectionUtil.getRandomElement(vehicles, 0, randExposure);
		return targetVehicle;
	}

	private double getExponentialArrivalTime(double lambda) {
		return -Math.log(1 - getNextRandom(isArrivalStochastic, randArrival)) / lambda;
	}

	@Override
	public void vehicleGenerated(Vehicle vehicle) {
		if (vehicle.getLongitudinalControl() instanceof IDistractibleLongitudinalControl) {
			vehicle.addVehicleListener(this);
			numTargetVehicles++;

			try {
				vehiclesLock.lock();
				distractibleVehicles.add(vehicle);
			} finally {
				vehiclesLock.unlock();
			}
		}
	}

	@Override
	public void vehicleLeftSimulation(Vehicle vehicle) {
		try {
			vehiclesLock.lock();

			if (distractibleVehicles.contains(vehicle)) {
				distractibleVehicles.remove(vehicle);
			}

			if (distractedVehicles.containsKey(vehicle)) {
				distractedVehicles.remove(vehicle);
			}
		} finally {
			vehiclesLock.unlock();
		}
	}

	public long getNumTargetVehicles() {
		return numTargetVehicles;
	}

	public List<Double> getDurationsPerType(long typeId) {
		if (durations.containsKey(typeId)) {
			return durations.get(typeId);
		}

		List<Double> list = new ArrayList<>();
		list.add(0d);
		list.add(0d);
		return list;
	}

	public long getExposurePerType(long typeId) {
		if (exposure.containsKey(typeId)) {
			return exposure.get(typeId).size();
		}

		return 0;
	}

	private double getNextRandom(boolean isStochastic, Random random) {
		if (isStochastic) {
			return new Random().nextDouble();
		}

		return random.nextDouble();
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data;

/**
 * Platoon action types
 *
 * @author Sebastian Huber
 *
 */
public enum PlatoonActionType {
	JOIN("Join"), LEAVE("Leave"), DISSOLVE("Dissolve"), ABORT("Abort");

	private String type;

	private PlatoonActionType(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type;
	}

	public static PlatoonActionType valueOfLabel(String label) {
		for (PlatoonActionType t : PlatoonActionType.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}
		return null;
	}
}

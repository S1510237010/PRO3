package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

import at.fhhagenberg.mc.traffsim.generator.AbstractVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.ContinuousVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.PredefinedVehicleGenerator;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConsumptionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.Memory;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControl;

public class TrafficGeneratorEditorView extends AbstractControlView {
	private static final String CONTINUOUS = "continuous";

	private static final String GENERATOR = "Generator";
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.control.trafficGenerators";
	private static final String PREDEFINED = "predefined";

	private AbstractVehicleGenerator activeGenerator;

	private Combo comboLongitudinalControl;
	private Combo comboLaneChangeModel;
	private Combo comboMemoryModel;
	private Combo comboConsumptionModel;

	private Combo comboTrafficGenerators;
	private Label lblTrafficGenerator;
	private Spinner spinnerAverageSpeed;
	private Spinner spinnerAverageSpeedStdDev;
	private Spinner spinnerInitialSpeed;
	private Combo comboInitialRoadSegment;
	private Combo comboPossibleRoutes;
	private Combo comboAllRoutes;
	private Spinner spinnerInFlowMean;
	private Spinner spinnerInFlowStdDev;
	private Spinner spinnerSampleInterval;
	private Spinner spinnerVehicleLengthStdDev;
	private Spinner spinnerMaxVehicles;
	private Button btnIsStochastic;

	private List<AbstractVehicleGenerator> trafficGenerators;
	private List<Memory> memoryModels;
	private List<FuelConsumptionModel> consumptionModels;
	private List<LaneChangeModel> laneChangeModels;

	@SuppressWarnings("rawtypes")
	private List<LongitudinalControl> longitudinalControls;
	private List<RoadSegment> roadSegments;
	private List<Long> possibleRoutes;
	private List<Long> allRoutes;

	private Button btnAddGenerator;
	private Button btnRemoveGenerator;
	private Button btnAddRoute;
	private Button btnRemoveRoute;

	public TrafficGeneratorEditorView() {
		this.trafficGenerators = SimulationKernel.getInstance().getActiveModel().getTrafficGenerators(false);
		this.laneChangeModels = SimulationKernel.getInstance().getActiveModel().getModelRegistry().getModels(LaneChangeModel.class);
		this.consumptionModels = SimulationKernel.getInstance().getActiveModel().getModelRegistry().getModels(FuelConsumptionModel.class);
		this.memoryModels = SimulationKernel.getInstance().getActiveModel().getModelRegistry().getModels(Memory.class);
		this.longitudinalControls = SimulationKernel.getInstance().getActiveModel().getModelRegistry().getModels(LongitudinalControl.class);
		this.roadSegments = SimulationKernel.getInstance().getActiveModel().getNetwork().getRoadSegments();
		this.allRoutes = new ArrayList<>();

		List<IRoute> routes = SimulationKernel.getInstance().getActiveModel().getRouteRegistry().getDistinctRoutes();

		for (IRoute route : routes) {
			allRoutes.add(route.getId());
		}
	}

	@Override
	protected void applyChanges() {
		if (activeGenerator instanceof ContinuousVehicleGenerator) {
			ContinuousVehicleGenerator contGen = (ContinuousVehicleGenerator) activeGenerator;
			contGen.setSpeedAverage(spinnerAverageSpeed.getSelection() / Math.pow(10, spinnerAverageSpeed.getDigits()));
			contGen.setSpeedAverageStdDeviation(spinnerAverageSpeedStdDev.getSelection() / Math.pow(10, spinnerAverageSpeedStdDev.getDigits()));
			contGen.setInitialSpeed(spinnerInitialSpeed.getSelection() / Math.pow(10, spinnerInitialSpeed.getDigits()));
			contGen.setInFlowRateStdDeviation(spinnerInFlowStdDev.getSelection() / Math.pow(10, spinnerInFlowStdDev.getDigits()));
			contGen.setSampleInterval(spinnerSampleInterval.getSelection() / Math.pow(10, spinnerSampleInterval.getDigits()));
			contGen.setVehicleLengthStdDeviation(spinnerVehicleLengthStdDev.getSelection() / Math.pow(10, spinnerVehicleLengthStdDev.getDigits()));
			contGen.setIsStochastic(btnIsStochastic.getSelection());
			contGen.setLongitudinalControlIdentifier(comboLongitudinalControl.getText());
			contGen.setLaneChangeModelIdentifier(comboLaneChangeModel.getText());
			contGen.setFuelModelIdentifier(comboConsumptionModel.getText());
			contGen.setMemoryModelIdentifier(comboMemoryModel.getText());
			contGen.setTotalNumVehicles(spinnerMaxVehicles.getSelection());
			contGen.setInFlowRateMean(spinnerInFlowMean.getSelection() / Math.pow(10, spinnerInFlowMean.getDigits()));
			contGen.setInitialRoadSegment(SimulationKernel.getInstance().getActiveModel().getNetwork()
					.getRoadSegmentByKey(Long.parseLong(comboInitialRoadSegment.getText())));
			contGen.updatePossibleRoutes(possibleRoutes);
		}
	}

	@Override
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(3, false));

		lblTrafficGenerator = new Label(parent, SWT.NONE);
		lblTrafficGenerator.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTrafficGenerator.setText("Traffic Generator");

		comboTrafficGenerators = new Combo(parent, SWT.READ_ONLY);
		comboTrafficGenerators.setEnabled(true);
		comboTrafficGenerators.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		if (trafficGenerators != null) {
			for (AbstractVehicleGenerator gen : trafficGenerators) {
				comboTrafficGenerators.add(getLabel(gen));
			}
		}

		comboTrafficGenerators.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				activeGenerator = getGenerator(((Combo) e.getSource()).getText());
				updateData(parent);
			}
		});

		btnRemoveGenerator = new Button(parent, SWT.NONE);
		btnRemoveGenerator.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnRemoveGenerator.setText("Remove Generator");
		btnRemoveGenerator.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				trafficGenerators.remove(comboTrafficGenerators.getSelectionIndex());
				comboTrafficGenerators.remove(comboTrafficGenerators.getSelectionIndex());

				SimulationKernel.getInstance().getActiveModel().removeTrafficGenerator(activeGenerator);

				if (trafficGenerators.size() > 0) {
					comboTrafficGenerators.select(0);
					activeGenerator = getGenerator(comboTrafficGenerators.getText());
				} else {
					comboTrafficGenerators.setEnabled(false);
					btnRemoveGenerator.setEnabled(false);
					activeGenerator = null;
				}

				updateData(parent);
			}
		});

		new Label(parent, SWT.NONE);
		new Label(parent, SWT.NONE);

		btnAddGenerator = new Button(parent, SWT.NONE);
		btnAddGenerator.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnAddGenerator.setText("Add Generator");
		btnAddGenerator.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				ContinuousVehicleGenerator contGen = new ContinuousVehicleGenerator(SimulationKernel.getInstance().getActiveModel(),
						AbstractVehicleGenerator.NEXT_GENERATOR_ID++, 0, 180, 10, false, 0, null, 0, 0, 0);

				contGen.setSpeedAverage(spinnerAverageSpeed.getSelection() / Math.pow(10, spinnerAverageSpeed.getDigits()));
				contGen.setSpeedAverageStdDeviation(spinnerAverageSpeedStdDev.getSelection() / Math.pow(10, spinnerAverageSpeedStdDev.getDigits()));
				contGen.setInitialSpeed(spinnerInitialSpeed.getSelection() / Math.pow(10, spinnerInitialSpeed.getDigits()));
				contGen.setInFlowRateStdDeviation(spinnerInFlowStdDev.getSelection() / Math.pow(10, spinnerInFlowStdDev.getDigits()));
				contGen.setSampleInterval(spinnerSampleInterval.getSelection() / Math.pow(10, spinnerSampleInterval.getDigits()));
				contGen.setVehicleLengthStdDeviation(
						spinnerVehicleLengthStdDev.getSelection() / Math.pow(10, spinnerVehicleLengthStdDev.getDigits()));
				contGen.setIsStochastic(btnIsStochastic.getSelection());
				contGen.setLongitudinalControlIdentifier(comboLongitudinalControl.getText());
				contGen.setLaneChangeModelIdentifier(comboLaneChangeModel.getText());
				contGen.setFuelModelIdentifier(comboConsumptionModel.getText());
				contGen.setMemoryModelIdentifier(comboMemoryModel.getText());
				contGen.setTotalNumVehicles(spinnerMaxVehicles.getSelection());
				contGen.setInFlowRateMean(spinnerInFlowMean.getSelection() / Math.pow(10, spinnerInFlowMean.getDigits()));
				contGen.setInitialRoadSegment(SimulationKernel.getInstance().getActiveModel().getNetwork()
						.getRoadSegmentByKey(Long.parseLong(comboInitialRoadSegment.getText())));

				activeGenerator = contGen;
				comboTrafficGenerators.setEnabled(false);
				btnRemoveGenerator.setEnabled(false);
				trafficGenerators.add(contGen);
				comboTrafficGenerators.add(getLabel(contGen));
				comboTrafficGenerators.select(comboTrafficGenerators.getItemCount() - 1);

				SimulationKernel.getInstance().getActiveModel().addTrafficGenerator(activeGenerator);
				updateData(parent);
			}
		});

		Label lblRoadSegment = new Label(parent, SWT.NONE);
		lblRoadSegment.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRoadSegment.setText("Initial Road Segment");

		comboInitialRoadSegment = new Combo(parent, SWT.READ_ONLY);
		comboInitialRoadSegment.setEnabled(true);
		comboInitialRoadSegment.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		if (roadSegments != null) {
			for (RoadSegment gen : roadSegments) {
				comboInitialRoadSegment.add(String.valueOf(gen.getId()));
			}
		}

		new Label(parent, SWT.NONE);

		Label lblPossibleRoutes = new Label(parent, SWT.NONE);
		lblPossibleRoutes.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblPossibleRoutes.setText("Possible Routes");

		comboPossibleRoutes = new Combo(parent, SWT.READ_ONLY);
		comboPossibleRoutes.setEnabled(true);
		comboPossibleRoutes.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btnRemoveRoute = new Button(parent, SWT.NONE);
		btnRemoveRoute.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnRemoveRoute.setText("Remove Route");
		btnRemoveRoute.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				possibleRoutes.remove(Long.parseLong(comboPossibleRoutes.getText()));
				comboPossibleRoutes.remove(comboPossibleRoutes.getText());
				comboPossibleRoutes.select(0);

				if (possibleRoutes.isEmpty()) {
					comboPossibleRoutes.setEnabled(false);
					btnRemoveRoute.setEnabled(false);
				}
			}
		});

		Label lblAllRoutes = new Label(parent, SWT.NONE);
		lblAllRoutes.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblAllRoutes.setText("All Routes");

		comboAllRoutes = new Combo(parent, SWT.READ_ONLY);
		comboAllRoutes.setEnabled(true);
		comboAllRoutes.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		if (allRoutes != null) {
			for (Long gen : allRoutes) {
				comboAllRoutes.add(String.valueOf(gen));
			}
		}

		btnAddRoute = new Button(parent, SWT.NONE);
		btnAddRoute.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnAddRoute.setText("Add Route");
		btnAddRoute.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (!possibleRoutes.contains(Long.parseLong(comboAllRoutes.getText()))) {
					possibleRoutes.add(Long.parseLong(comboAllRoutes.getText()));
					comboPossibleRoutes.add(comboAllRoutes.getText());

					if (!possibleRoutes.isEmpty()) {
						comboPossibleRoutes.setEnabled(true);
						btnRemoveRoute.setEnabled(true);
						comboPossibleRoutes.select(comboPossibleRoutes.getItemCount() - 1);
					}
				}
			}
		});

		Label lblNewLabel = new Label(parent, SWT.NONE);
		lblNewLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblNewLabel.setText("Inflow");

		spinnerInFlowMean = new Spinner(parent, SWT.BORDER);
		GridData gd_spinnerInflow = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_spinnerInflow.widthHint = -41;
		spinnerInFlowMean.setLayoutData(gd_spinnerInflow);
		spinnerInFlowMean.setIncrement(10);
		spinnerInFlowMean.setMaximum(5000);
		spinnerInFlowMean.setPageIncrement(100);
		spinnerInFlowMean.setSelection(1080);

		Label lblVehHour = new Label(parent, SWT.NONE);
		lblVehHour.setText("veh./hour");

		Label lblInflowStd = new Label(parent, SWT.NONE);
		lblInflowStd.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblInflowStd.setText("Inflow Std. Deviation");

		spinnerInFlowStdDev = new Spinner(parent, SWT.BORDER);
		GridData gd_spinnerInflowStd = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_spinnerInflow.widthHint = -41;
		spinnerInFlowStdDev.setLayoutData(gd_spinnerInflowStd);
		spinnerInFlowStdDev.setIncrement(10);
		spinnerInFlowStdDev.setMaximum(5000);
		spinnerInFlowStdDev.setMinimum(1);
		spinnerInFlowStdDev.setPageIncrement(100);
		spinnerInFlowStdDev.setSelection(60);

		Label lblVehHour2 = new Label(parent, SWT.NONE);
		lblVehHour2.setText("veh./hour");

		btnIsStochastic = new Button(parent, SWT.CHECK);
		btnIsStochastic.setText("Vary inflow stochastically");
		btnIsStochastic.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 3, 1));
		btnIsStochastic.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				spinnerSampleInterval.setEnabled(btnIsStochastic.getSelection());
			}
		});

		Label lblSampleInterval = new Label(parent, SWT.NONE);
		lblSampleInterval.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblSampleInterval.setText("Sampling Interval");

		spinnerSampleInterval = new Spinner(parent, SWT.BORDER);
		spinnerSampleInterval.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerSampleInterval.setMaximum(3600);
		spinnerSampleInterval.setIncrement(10);
		spinnerSampleInterval.setPageIncrement(100);

		Label lblS = new Label(parent, SWT.NONE);
		lblS.setText("s");

		Label lblInitialSpeed = new Label(parent, SWT.NONE);
		lblInitialSpeed.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblInitialSpeed.setText("Initial Speed");

		spinnerInitialSpeed = new Spinner(parent, SWT.BORDER);
		spinnerInitialSpeed.setIncrement(10);
		spinnerInitialSpeed.setPageIncrement(50);
		spinnerInitialSpeed.setMaximum(500);
		spinnerInitialSpeed.setMinimum(1);
		spinnerInitialSpeed.setSelection(100);
		spinnerInitialSpeed.setDigits(1);
		spinnerInitialSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblMs = new Label(parent, SWT.NONE);
		lblMs.setText("m/s");

		Label lblAverageSpeed = new Label(parent, SWT.NONE);
		lblAverageSpeed.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblAverageSpeed.setText("Average Speed");

		spinnerAverageSpeed = new Spinner(parent, SWT.BORDER);
		spinnerAverageSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerAverageSpeed.setPageIncrement(50);
		spinnerAverageSpeed.setMaximum(500);
		spinnerAverageSpeed.setMinimum(1);
		spinnerAverageSpeed.setSelection(100);
		spinnerAverageSpeed.setIncrement(10);
		spinnerAverageSpeed.setDigits(1);

		Label lblMs_1 = new Label(parent, SWT.NONE);
		lblMs_1.setText("m/s");

		Label lblSpeedStdDeviation = new Label(parent, SWT.NONE);
		lblSpeedStdDeviation.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblSpeedStdDeviation.setText("Speed Std. Deviation");

		spinnerAverageSpeedStdDev = new Spinner(parent, SWT.BORDER);
		spinnerAverageSpeedStdDev.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerAverageSpeedStdDev.setPageIncrement(50);
		spinnerAverageSpeedStdDev.setMaximum(500);
		spinnerAverageSpeedStdDev.setIncrement(10);
		spinnerAverageSpeedStdDev.setDigits(1);

		Label lblMs_2 = new Label(parent, SWT.NONE);
		lblMs_2.setText("m/s");

		Label lblVehicleLengthStdDev = new Label(parent, SWT.NONE);
		lblVehicleLengthStdDev.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblVehicleLengthStdDev.setText("Vehicle Length Std. Deviation");

		spinnerVehicleLengthStdDev = new Spinner(parent, SWT.BORDER);
		spinnerVehicleLengthStdDev.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerVehicleLengthStdDev.setMaximum(20);
		spinnerVehicleLengthStdDev.setIncrement(1);
		spinnerVehicleLengthStdDev.setDigits(1);

		Label lblM = new Label(parent, SWT.NONE);
		lblM.setText("m");

		Label lblMaxVehicles = new Label(parent, SWT.NONE);
		lblMaxVehicles.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMaxVehicles.setText("Vehicles to generate");
		lblMaxVehicles.setToolTipText("If set to 0, vehicles will be generated continuously");

		spinnerMaxVehicles = new Spinner(parent, SWT.BORDER);
		spinnerMaxVehicles.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMaxVehicles.setMaximum(Integer.MAX_VALUE);
		spinnerMaxVehicles.setIncrement(10);
		spinnerMaxVehicles.setPageIncrement(100);
		spinnerMaxVehicles.setToolTipText("If set to 0, vehicles will be generated continuously");
		new Label(parent, SWT.NONE);

		Label lblLongitudinalControl = new Label(parent, SWT.NONE);
		lblLongitudinalControl.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblLongitudinalControl.setText("Longitudinal Control");

		comboLongitudinalControl = new Combo(parent, SWT.READ_ONLY);
		comboLongitudinalControl.setEnabled(true);
		comboLongitudinalControl.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		new Label(parent, SWT.NONE);

		if (longitudinalControls != null) {
			for (LongitudinalControl<?> gen : longitudinalControls) {
				comboLongitudinalControl.add(gen.getIdentifier());
			}
		}

		Label lblLaneChangeModel = new Label(parent, SWT.NONE);
		lblLaneChangeModel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblLaneChangeModel.setText("Lane Change Model");

		comboLaneChangeModel = new Combo(parent, SWT.READ_ONLY);
		comboLaneChangeModel.setEnabled(true);
		comboLaneChangeModel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		new Label(parent, SWT.NONE);

		if (laneChangeModels != null) {
			for (LaneChangeModel gen : laneChangeModels) {
				comboLaneChangeModel.add(gen.getIdentifier());
			}
		}

		Label lblConsumptionModel = new Label(parent, SWT.NONE);
		lblConsumptionModel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblConsumptionModel.setText("Consumption Model");

		comboConsumptionModel = new Combo(parent, SWT.READ_ONLY);
		comboConsumptionModel.setEnabled(true);
		comboConsumptionModel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		new Label(parent, SWT.NONE);

		if (consumptionModels != null) {
			for (FuelConsumptionModel gen : consumptionModels) {
				comboConsumptionModel.add(gen.getIdentifier());
			}
		}

		Label lblMemoryModel = new Label(parent, SWT.NONE);
		lblMemoryModel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMemoryModel.setText("Memory Model");

		comboMemoryModel = new Combo(parent, SWT.READ_ONLY);
		comboMemoryModel.setEnabled(true);
		comboMemoryModel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		new Label(parent, SWT.NONE);

		if (memoryModels != null) {
			for (Memory gen : memoryModels) {
				comboMemoryModel.add(gen.getIdentifier());
			}
		}

		createButtonComposite(parent);

		comboTrafficGenerators.select(0);
		comboLongitudinalControl.select(0);
		comboLaneChangeModel.select(0);
		comboConsumptionModel.select(0);
		comboInitialRoadSegment.select(0);
		comboMemoryModel.select(0);
		comboAllRoutes.select(0);

		activeGenerator = trafficGenerators != null && !trafficGenerators.isEmpty() ? trafficGenerators.get(0) : null;
		updateData(parent);
	}

	private AbstractVehicleGenerator getGenerator(String label) {
		String[] split = label.split(" ");
		try {
			long id = Long.parseLong(split[1]);
			for (AbstractVehicleGenerator gen : trafficGenerators) {
				if (gen.getId() == id) {
					return gen;
				}
			}
		} catch (Exception ex) {
			Logger.logWarn("Could not find generator " + label);
		}
		return null;
	}

	private String getLabel(AbstractVehicleGenerator gen) {
		StringBuilder label = new StringBuilder();
		label.append(GENERATOR);
		label.append(" ");
		label.append(gen.getId());
		label.append(" (");

		if (gen instanceof ContinuousVehicleGenerator) {
			label.append(CONTINUOUS);
		} else if (gen instanceof PredefinedVehicleGenerator) {
			label.append(PREDEFINED);
		} else {
			label.append("unknown");
		}

		label.append(")");
		return label.toString();
	}

	@Override
	protected String getViewId() {
		return ID;
	}

	private void setEnabled(Composite parent, boolean enabled) {
		for (Control c : parent.getChildren()) {
			if (c != btnAddGenerator) {
				c.setEnabled(enabled);
			}
		}

		if (longitudinalControls == null || longitudinalControls.isEmpty()) {
			comboLongitudinalControl.setEnabled(false);
		}

		if (memoryModels == null || memoryModels.isEmpty()) {
			comboMemoryModel.setEnabled(false);
		}

		if (laneChangeModels == null || laneChangeModels.isEmpty()) {
			comboLaneChangeModel.setEnabled(false);
		}

		if (consumptionModels == null || consumptionModels.isEmpty()) {
			comboConsumptionModel.setEnabled(false);
		}

		if (roadSegments == null || roadSegments.isEmpty()) {
			comboInitialRoadSegment.setEnabled(false);
		}

		if (possibleRoutes == null || possibleRoutes.isEmpty()) {
			comboPossibleRoutes.setEnabled(false);
			btnRemoveRoute.setEnabled(false);
		}

		if (allRoutes == null || allRoutes.isEmpty()) {
			comboAllRoutes.setEnabled(false);
			btnAddRoute.setEnabled(false);
		}

		enableButtons(enabled);
	}

	@Override
	public void setFocus() {
		// unused
	}

	protected void updateData(Composite parent) {
		if (activeGenerator instanceof ContinuousVehicleGenerator) {
			ContinuousVehicleGenerator contGen = (ContinuousVehicleGenerator) activeGenerator;
			spinnerInFlowMean.setSelection((int) (contGen.getInFlowRateMean() * Math.pow(10, spinnerInFlowMean.getDigits())));
			spinnerAverageSpeed.setSelection((int) (contGen.getSpeedAverage() * Math.pow(10, spinnerAverageSpeed.getDigits())));
			spinnerAverageSpeedStdDev
					.setSelection((int) (contGen.getSpeedAverageStdDeviation() * Math.pow(10, spinnerAverageSpeedStdDev.getDigits())));
			spinnerInitialSpeed.setSelection((int) (contGen.getSpeedInitial() * Math.pow(10, spinnerInitialSpeed.getDigits())));
			spinnerInFlowStdDev.setSelection((int) (contGen.getInFlowRateStdDeviation() * Math.pow(10, spinnerInFlowStdDev.getDigits())));
			spinnerSampleInterval.setSelection((int) (contGen.getSampleInterval() * Math.pow(10, spinnerSampleInterval.getDigits())));
			spinnerVehicleLengthStdDev
					.setSelection((int) (contGen.getVehicleLengthStdDeviation() * Math.pow(10, spinnerVehicleLengthStdDev.getDigits())));
			spinnerMaxVehicles.setSelection(contGen.getMaxNumVehicles());
			btnIsStochastic.setSelection(contGen.isStochastic());
			comboLongitudinalControl.setText(contGen.getLongitudinalControlIdentifier());
			comboLaneChangeModel.setText(contGen.getLaneChangeModelIdentifier());
			comboConsumptionModel.setText(contGen.getFuelConsumptionModelIdentifier());
			comboMemoryModel.setText(contGen.getMemoryModelIdentifier());
			comboInitialRoadSegment.setText(String.valueOf(contGen.getInitialRoadSegment().getId()));

			comboPossibleRoutes.removeAll();
			possibleRoutes = contGen.getPossibleRouteIds();

			for (Long routeId : possibleRoutes) {
				comboPossibleRoutes.add(String.valueOf(routeId));
			}

			comboPossibleRoutes.select(0);

			setEnabled(parent, true);

			spinnerSampleInterval.setEnabled(btnIsStochastic.getSelection());
		} else {
			setEnabled(parent, false);
		}
	}
}

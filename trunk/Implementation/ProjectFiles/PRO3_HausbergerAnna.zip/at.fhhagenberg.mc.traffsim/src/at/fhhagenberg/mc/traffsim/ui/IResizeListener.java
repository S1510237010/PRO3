package at.fhhagenberg.mc.traffsim.ui;

/**
 * Listener interface to notify components if the window size of a component has changed
 * 
 * @author Christian Backfrieder
 * 
 */
public interface IResizeListener {
	public void windowSizeChanged();
	
	public void windowSizeInitialized();
}

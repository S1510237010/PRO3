package at.fhhagenberg.mc.traffsim.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import at.fhhagenberg.mc.traffsim.generator.AbstractVehicleGenerator;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class SimulationObserver implements IVehicleGeneratorListener, IVehicleListener {
	private AtomicLong curNumRoutableVehicles = new AtomicLong(0);
	/** atomic reference for thread safety */
	private AtomicLong curNumUnroutableVehicles = new AtomicLong(0);
	private AtomicLong curNumVehicles = new AtomicLong(0);
	private AtomicLong totalNumVehicles = new AtomicLong(0);
	private ISimulationFinishedListener finishedListener;
	private boolean first;
	private SimulationModel model;
	private Map<Long, Vehicle> routableVehicles = new ConcurrentHashMap<>();
	private AtomicLong totalNumRoutableVehicles = new AtomicLong(0);
	private AtomicLong totalNumUnroutableVehicles = new AtomicLong(0);
	private Map<Long, Vehicle> unroutableVehicles = new ConcurrentHashMap<>();
	private Map<Long, Vehicle> enteredVehicles = new ConcurrentHashMap<>();

	public SimulationObserver(SimulationModel model) {
		this.model = model;
	}

	/**
	 * The current number of routable vehicles<br>
	 * + generated but not entered<br>
	 * - already left - not generated yet
	 *
	 * @return list of routable vehicle ids
	 */
	public long getCurNumRoutableVehicles() {
		return curNumRoutableVehicles.get();
	}

	/**
	 * The current number of unroutable vehicles in simulation<br>
	 * + generated but not entered<br>
	 * - already left - not generated yet
	 *
	 * @return list of {@link Vehicle#getUniqueId()}
	 */
	public long getCurNumUnroutableVehicles() {
		return curNumUnroutableVehicles.get();
	}

	/**
	 * The current number of vehicles in simulation<br>
	 * + generated but not entered<br>
	 * - already left - not generated yet
	 *
	 * @return list of {@link Vehicle#getUniqueId()}
	 */
	public long getCurNumVehicles() {
		return curNumVehicles.get();
	}

	public long getTotalNumVehicles() {
		return totalNumVehicles.get();
	}

	public ISimulationFinishedListener getFinishedListener() {
		return finishedListener;
	}

	/**
	 * The total number of vehicles in simulation<br>
	 * + generated but not entered<br>
	 * + already left - not generated yet
	 *
	 * @return list of {@link Vehicle#getUniqueId()}
	 */
	public long getTotalNumRoutableVehicles() {
		return totalNumRoutableVehicles.get();
	}

	/**
	 * The current number of vehicles in simulation<br>
	 * + generated but not entered<br>
	 * + already left<br>
	 * - not generated yet
	 *
	 * @return list of {@link Vehicle#getUniqueId()}
	 */
	public long getTotalNumUnroutableVehicles() {
		return totalNumUnroutableVehicles.get();
	}

	public Collection<Vehicle> getVehiclesInSimulation() {
		Map<Long, Vehicle> allVeh = new HashMap<>(routableVehicles);
		allVeh.putAll(unroutableVehicles);
		return allVeh.values();
	}

	/**
	 * The current vehicles in simulation <br>
	 * + generated but not entered<br>
	 * - already left - not generated yet
	 *
	 * @param onlyRoutable
	 *            return only the routable vehicles if <code>true</code>
	 *
	 * @return list of {@link Vehicle}
	 */
	public Collection<Vehicle> getVehiclesInSimulation(boolean onlyRoutable) {
		if (onlyRoutable) {
			return routableVehicles.values();
		} else {
			return getVehiclesInSimulation();
		}
	}

	@Override
	public void postLeftSimulation(Vehicle v) {
		v.removeVehicleListener(this);
		if (curNumVehicles.get() == 0) {
			for (AbstractVehicleGenerator gen : model.getTrafficGenerators(true)) {
				if (gen.hasMoreVehicles()) {
					return;
				}
			}
			// start in new thread to avoid blocking
			new Thread("Finished Invoker") {
				@Override
				public void run() {
					finishedListener.simulationFinished();
				};
			}.start();
		}
	}

	public void setFinishedListener(ISimulationFinishedListener finishedListener) {
		this.finishedListener = finishedListener;
	}

	@Override
	public void vehicleGenerated(Vehicle vehicle) {
		totalNumVehicles.incrementAndGet();
		curNumVehicles.incrementAndGet();
		if (vehicle.isRoutable()) {
			routableVehicles.put(vehicle.getUniqueId(), vehicle);
			curNumRoutableVehicles.incrementAndGet();
			totalNumRoutableVehicles.incrementAndGet();
		} else {
			unroutableVehicles.put(vehicle.getUniqueId(), vehicle);
			curNumUnroutableVehicles.incrementAndGet();
			totalNumUnroutableVehicles.incrementAndGet();
		}
		vehicle.addVehicleListener(this);
		model.logEvent(EventType.VEHICLE_CREATED, vehicle, "");
	}

	@Override
	public void vehicleLeftSimulation(Vehicle vehicle) {
		curNumVehicles.decrementAndGet();
		if (vehicle.isRoutable()) {
			routableVehicles.remove(vehicle.getUniqueId());
			curNumRoutableVehicles.decrementAndGet();
		} else {
			unroutableVehicles.remove(vehicle.getUniqueId());
			curNumUnroutableVehicles.decrementAndGet();
		}
		enteredVehicles.remove(vehicle.getUniqueId());

		if (vehicle.getWasInvolvedInCollision()) {
			model.logEvent(EventType.VEHICLE_LEFT, vehicle, "due to a crash with another vehicle");
		} else {
			model.logEvent(EventType.VEHICLE_LEFT, vehicle, "at " + vehicle.getRoadSegment().getRoutingId());
		}

		if (first) {
			first = false;
			model.logEvent(EventType.FIRST_VEHICLE_FINISHED, vehicle, "finished route");
		}
	}

	/**
	 *
	 * @param id
	 *            the unique id of the vehicle
	 * @return a vehicle that is already generated and has not yet left the simulation, by its id, or <code>null</code> if nothing found
	 */

	public Vehicle getVehicleById(long id) {
		if (routableVehicles.containsKey(id)) {
			return routableVehicles.get(id);
		}
		return unroutableVehicles.get(id);
	}

	@Override
	public void vehicleEntered(Vehicle vehicle) {
		enteredVehicles.put(vehicle.getUniqueId(), vehicle);
	}

	/**
	 * The current entered vehicles<br>
	 * - generated but not entered<br>
	 * - already left - not generated yet
	 *
	 * @return list of vehicles that are currently visible in simulation
	 */
	public Collection<Vehicle> getEnteredVehicles() {
		return enteredVehicles.values();
	}

}

package at.fhhagenberg.mc.traffsim.model;

public interface IRoadStatisticsChangedListener {
	public void roadDataChanged(long roadSegmentId, int laneIndex);
}

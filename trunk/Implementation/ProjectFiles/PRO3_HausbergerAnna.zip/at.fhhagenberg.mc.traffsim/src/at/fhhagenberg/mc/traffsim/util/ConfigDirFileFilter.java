package at.fhhagenberg.mc.traffsim.util;

import java.io.File;
import java.io.FileFilter;

import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;

public class ConfigDirFileFilter implements FileFilter {
	DataSerializer ser;

	public ConfigDirFileFilter(DataSerializer serializer) {
		this.ser = serializer;
	}

	@Override
	public boolean accept(File pathname) {
		if (pathname.getName().equals(ser.getConfiguration().getConfigurationFile().getName())) {
			return true;
		}
		for (String filename : ser.getConfiguration().getAllFileNames(true)) {
			if (ser.getFullFile(filename).getName().equals(pathname.getName()) && pathname.getName().endsWith("xml")) {
				return true;
			}
		}
		return false;
	}

}

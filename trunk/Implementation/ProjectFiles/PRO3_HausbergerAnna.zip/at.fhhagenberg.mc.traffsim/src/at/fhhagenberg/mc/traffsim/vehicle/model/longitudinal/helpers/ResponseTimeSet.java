package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers;

/**
 * Container class holding various types of driver response times.
 *
 * @author Manuel Lindorfer
 *
 */
public class ResponseTimeSet {

	/** The response time to expected situations [ms] */
	private double expected;

	/** Flag indicating whether a driver's response is delayed or not */
	private boolean isActive;

	/** Flag indicating whether timely anticipation is active or not */
	private boolean isAnticipative;

	/** The response time when the vehicle is in standstill [ms] */
	private double driveAway;

	/**
	 * The time headway threshold required for driving regime determination [s]
	 */
	private double timeHeadway;

	/** The response time to unexpected situations [ms] */
	private double unexpected;

	public ResponseTimeSet() {
		this(0, 0, 0, 0, false, false);
	}

	/**
	 * Instantiates a new response time parameter set
	 *
	 * @param expected
	 *            the response time to expected situations [ms]
	 * @param unexpected
	 *            the response time to unexpected situations [ms]
	 * @param driveAway
	 *            the response time when the vehicle is in standstill [ms]
	 * @param timeHeadway
	 *            the time headway required for driving regime determination [s]
	 * @param isActive
	 *            flag indicating whether a driver's response is delayed or not
	 * @param isAnticipative
	 *            flag indicating whether temporal anticipation is active or not
	 */
	public ResponseTimeSet(double expected, double unexpected, double driveAway, double timeHeadway, boolean isActive,
			boolean isAnticipative) {
		setExpected(expected);
		setUnexpected(unexpected);
		setDriveAway(driveAway);
		setTimeHeadway(timeHeadway);
		setIsActive(isActive);
		setIsAnticipative(isAnticipative);
	}

	/**
	 * Copy constructor
	 *
	 * @param other
	 *            the object to be copied
	 */
	public ResponseTimeSet(ResponseTimeSet other) {
		this(other.getExpected(), other.getUnexpected(), other.getDriveAway(), other.getTimeHeadway(), other.getIsActive(),
				other.getIsAnticipative());
	}

	public double getDriveAway() {
		return driveAway;
	}

	/**
	 * Gets the response time to expected situations.
	 *
	 * @return the response time
	 */
	public double getExpected() {
		return expected;
	}

	/**
	 * Gets whether a driver's response is delayed or not.
	 *
	 * @return true if the response is delayed - false else
	 */
	public boolean getIsActive() {
		return isActive;
	}

	/**
	 * Gets whether temporal anticipation is active or not.
	 *
	 * @return true if temporal anticipation is active - false else
	 */
	public boolean getIsAnticipative() {
		return isAnticipative;
	}

	/**
	 * Gets the time headway threshold required for determining the current driving regime.
	 *
	 * @return the time headway threshold
	 */
	public double getTimeHeadway() {
		return timeHeadway;
	}

	/**
	 * Gets the response time to unexpected situations.
	 *
	 * @return the response time
	 */
	public double getUnexpected() {
		return unexpected;
	}

	public void setDriveAway(double driveAway) {
		this.driveAway = driveAway;
	}

	/**
	 * Sets the response time to expected situations.
	 *
	 * @param expected
	 *            the new response time
	 */
	public void setExpected(double expected) {
		this.expected = expected;
	}

	/**
	 * Sets whether a driver's response is delayed or not.
	 *
	 * @param isActive
	 *            true if the response is delayed - false else
	 */
	public void setIsActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * Sets whether temporal anticipation is active.
	 *
	 * @param isAnticipative
	 *            true if active - false else
	 */
	public void setIsAnticipative(boolean isAnticipative) {
		this.isAnticipative = isAnticipative;
	}

	/**
	 * Sets the time headway threshold.
	 *
	 * @param timeHeadway
	 *            the new time headway threshold
	 */
	public void setTimeHeadway(double timeHeadway) {
		this.timeHeadway = timeHeadway;
	}

	/**
	 * Sets the response time to unexpected situations.
	 *
	 * @param unexpected
	 *            the new response time
	 */
	public void setUnexpected(double unexpected) {
		this.unexpected = unexpected;
	}
}

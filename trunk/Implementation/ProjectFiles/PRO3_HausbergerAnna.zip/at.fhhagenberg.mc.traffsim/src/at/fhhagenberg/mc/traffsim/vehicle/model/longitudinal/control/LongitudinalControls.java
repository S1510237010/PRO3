package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

public enum LongitudinalControls {

	DEFAULT("Default Longitudinal Control", "Default"), EHDMM("Enhanced Human Driver Meta Model", "EHDM"), HDMM("Human Driver Meta Model",
			"HDM"), AUTOMAT("Automated Vehicle Control", "AVC");

	public static LongitudinalControls valueOfLabel(String label) {
		for (LongitudinalControls t : LongitudinalControls.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}

		return null;
	}

	private String shortName;

	private String type;

	private LongitudinalControls(final String type, final String shortName) {
		this.type = type;
		this.shortName = shortName;
	}

	public String getShortName() {
		return shortName;
	}

	@Override
	public String toString() {
		return type;
	}
}
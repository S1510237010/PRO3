package at.fhhagenberg.mc.traffsim.data;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.stream.Collectors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;

import at.fhhagenberg.mc.elevation.AltitudeService;
import at.fhhagenberg.mc.osm2po.ext.OsmUtil.LaneDirection;
import at.fhhagenberg.mc.traffsim.communication.channelmodels.GeometricDistributedChannelModel;
import at.fhhagenberg.mc.traffsim.communication.channelmodels.GilbertElliotChannelModel;
import at.fhhagenberg.mc.traffsim.communication.channelmodels.UniformlyDistributedChannelModel;
import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.BehaviorBean;
import at.fhhagenberg.mc.traffsim.data.beans.CoordinateBean;
import at.fhhagenberg.mc.traffsim.data.beans.LabeledBean;
import at.fhhagenberg.mc.traffsim.data.beans.ParameterBean;
import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficGeneratorBean;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficObstructionBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleCommDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.BaseRoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ConnectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.DetectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.IntersectionControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.LaneSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RemovedRoutingIdsBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.GeometricDistributionChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.GilbertElliotChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.UniformlyDistributedChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.distraction.DistractionModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.CACCLaneChangeDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.MOBILDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.ACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.CACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.GippsDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IIDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.KraussDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.MemoryDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.OVMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ContainerControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.DefaultLongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ExtendedHumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.HumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.PlatoonLongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.VehicleAutomationControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.platoon.PlatoonManagerDataBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.generator.AbstractVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.ContinuousVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.PredefinedVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.TrafficObstructionGenerator;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.model.init.ParameterParser;
import at.fhhagenberg.mc.traffsim.roadnetwork.Node;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector.DetectionMode;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.QueueMonitor;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.DefaultJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.SpatialCache;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightControllers;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.routing.RoutingException;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.ObjectAdapter;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.types.MergeResult;
import at.fhhagenberg.mc.traffsim.vehicle.Behavior;
import at.fhhagenberg.mc.traffsim.vehicle.BehaviorType;
import at.fhhagenberg.mc.traffsim.vehicle.Obstruction;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConsumptionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics.PhysicsConsumptionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.CACCLaneChange;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.MOBIL;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data.CACCLaneChangeData;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data.MOBILData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ACC;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.CACC;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.Gipps;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IComposableLongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IDM;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IIDM;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.Krauss;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.LongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.Memory;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.OVM;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.ExtendedHumanDriverControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.HumanDriverControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.PlatoonLongitudinalControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.VehicleAutomationControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.ExtendedHumanDriverControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.HumanDriverControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.PlatoonLongitudinalControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.ACCData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.CACCData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.GippsData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.IDMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.IIDMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.KraussData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.MemoryInputData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.OVMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.Noise;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.PlatoonManager;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonManagerData;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.FileUtil;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * Loads simulation-relevant data from files, assuming all required files are in the same directory as the configuration.xml file.
 *
 * @author Christian Backfrieder
 */
public class DataLoader {

	/** Default name of the simulation model's output folder */
	private static final String DEFAULT_OUTPUT_FOLDER_NAME = "output";

	/** The minimum required road segment length in meters */
	private static final double MINIMUM_ROADSEGMENT_LENGTH = 7;

	/** Tolerance between simulation start and start time of first vehicle. */
	private static final long VEHICLE_STARTTIME_TOLERANCE_MS = 3000;

	/** Altitude service required to obtain elevation data */
	private AltitudeService altService = new AltitudeService();

	/**
	 * optional auxiliary labels for all stored beans, that can be used for storage in statistics, if needed
	 */
	private List<String> auxLabels = new ArrayList<>();

	/** Flag for test reasons to avoid initialisation of junctions. */
	private boolean donotInitialize = false;

	/** List of loaded traffic generators */
	private List<AbstractVehicleGenerator> generators;

	/**
	 * PlatoonManagerData for creation of PlatoonManager Includes platoon actions
	 */
	private PlatoonManager platoonManager;

	private List<Vehicle> predefinedVehicles;

	/** The loaded graph file used required for routing */
	private File graphFile;

	/** The loaded road network */
	private RoadNetwork network;

	/** Mapping for removed node identifiers, and their new values */
	private HashMap<Long, Long> newIdMapping;

	/**
	 * Routing identifiers which were removed due to merging of road segments
	 */
	private Set<Long> oldRoutingIds = new ConcurrentSkipListSet<>();

	/** The output folder */
	private File outputFolder;

	/** Cache for loaded road segments */
	private Map<Long, RoadSegment> segmentsCache;

	/** The simulation start time */
	private Date startTime;

	private boolean loaded;

	private boolean beansLoaded;

	private List<? extends AbstractBean> infrastructureBeans;

	private List<? extends AbstractBean> baseSegmentBeans;

	private List<? extends AbstractBean> routeBeans;

	private List<? extends AbstractBean> trafficGeneratorBeans;

	private List<? extends AbstractBean> vehicleBeans;

	private List<? extends AbstractBean> commDataBeans;

	private List<? extends AbstractBean> behaviorBeans;

	private List<? extends AbstractBean> platoonManagerBeans;

	private List<? extends AbstractBean> obstructionsBeans;

	private DataSerializer serializer;

	private List<? extends AbstractBean> modelBeans;

	private List<? extends AbstractBean> controlBeans;

	private List<? extends AbstractBean> intersectionControlBeans;

	private List<? extends AbstractBean> detectorBeans;

	private List<? extends AbstractBean> parameterBeans;

	private File configurationFile;

	private boolean parametersLoaded;

	public DataLoader() {
	}

	/**
	 * Create a new dataloader with all BEANS copied from the original loader. Note that ONLY the beans are copied, but nothing else. This
	 * means, {@link #loadConfiguration(SimulationModel, IProgressMonitor, Properties)} must be called again!
	 *
	 * @param loader
	 */
	public DataLoader(DataLoader loader) {
		beansLoaded = loader.beansLoaded;
		serializer = loader.serializer;
		configurationFile = loader.configurationFile;
		parameterBeans = loader.parameterBeans;
		infrastructureBeans = loader.infrastructureBeans;
		baseSegmentBeans = loader.baseSegmentBeans;
		routeBeans = loader.routeBeans;
		trafficGeneratorBeans = loader.trafficGeneratorBeans;
		vehicleBeans = loader.vehicleBeans;
		commDataBeans = loader.commDataBeans;
		behaviorBeans = loader.behaviorBeans;
		platoonManagerBeans = loader.platoonManagerBeans;
		obstructionsBeans = loader.obstructionsBeans;
		modelBeans = loader.modelBeans;
		controlBeans = loader.controlBeans;
		intersectionControlBeans = loader.intersectionControlBeans;
		detectorBeans = loader.detectorBeans;
	}

	/**
	 * Assigns the given list of {@link Behavior} the the given list of {@link Vehicle}.
	 *
	 * @param vehicles
	 *            list of loaded vehicles
	 * @param behaviors
	 *            list of behaviors to be assigned to particular vehicles
	 */
	private void assignBehaviors(List<Vehicle> vehicles, List<Behavior> behaviors) {

		Map<String, List<Behavior>> behaviorMap = behaviors.stream().collect(Collectors.groupingBy(Behavior::getVehicleLabel));

		for (String vehicleLabel : behaviorMap.keySet()) {
			Optional<Vehicle> vehicle = vehicles.stream().filter(v -> v.getLabel().compareTo(vehicleLabel) == 0).findFirst();

			if (vehicle.isPresent()) {
				List<Behavior> bs = behaviorMap.get(vehicleLabel);
				Optional<Behavior> controlBehavior = bs.stream().filter(b -> b.getBehaviorType() == BehaviorType.CONTROL).findFirst();
				Optional<Behavior> traceBehavior = bs.stream().filter(b -> b.getBehaviorType() == BehaviorType.TRACE).findFirst();

				// Don't add control behaviour to executable behaviours
				if (controlBehavior.isPresent()) {
					bs.remove(controlBehavior.get());
					vehicle.get().setIsVehicleBehaviorControlled(true);
				}

				// A trace behavior is somehow similar to a control behavior
				if (traceBehavior.isPresent()) {
					vehicle.get().setRequiredTargetSpeed(traceBehavior.get().getInitialTraceSpeed());
				}

				vehicle.get().setBehaviors(bs);
			} else {
				Logger.logWarn("Could not assign behaviors for vehicle " + vehicleLabel);
			}
		}
	}

	/**
	 *
	 * @return auxiliary labels, that can be defined for all lists of {@link LabeledBean}
	 */
	public List<String> getAuxLabels() {
		return auxLabels;
	}

	/**
	 * Gets a {@link RoadSegment} from the road segment cache identified by the given id.
	 *
	 * @param id
	 *            the id of the requested road segment
	 * @return the road segment identified by the given id
	 */
	private RoadSegment getFromSegmentsCache(long id) {
		if (newIdMapping != null && newIdMapping.containsKey(id)) {
			id = newIdMapping.get(id);
		}

		return segmentsCache.get(id);
	}

	/**
	 * Gets the loaded graph file.
	 *
	 * @return the graph file obtained from the simulation folder
	 */
	public File getGraphFile() {
		return graphFile;
	}

	/**
	 * Gets the list of routing identifiers which have been removed due to the merger of road segments.
	 *
	 * @return a set of routing identifiers
	 */
	public Set<Long> getOldRoutingIds() {
		return oldRoutingIds;
	}

	/**
	 * Gets the simulation model's output folder.
	 *
	 * @return the output folder
	 */
	public File getOutputFolder() {
		return outputFolder;
	}

	/**
	 * Gets the loaded {@link RoadNetwork}.
	 *
	 * @return the road network loaded
	 */
	public RoadNetwork getRoadNetwork() {
		return network;
	}

	public List<Vehicle> getPredefinedVehicles() {
		return predefinedVehicles;
	}

	/**
	 * Gets the simulation start time obtained from the configuration files.
	 *
	 * @return the simulation start time
	 */
	public Date getStartTime() {
		return startTime;
	}

	/**
	 * Gets the list of loaded traffic generators.
	 *
	 * @return a list of traffic generators
	 */
	public List<AbstractVehicleGenerator> getTrafficGenerators() {
		return generators;
	}

	/**
	 * Get PlatoonManager with data from config files
	 *
	 * @return PlatoonManager
	 */
	public PlatoonManager getPlatoonManager() {
		return this.platoonManager;
	}

	/**
	 * Loads the altitude values for the given set of {@link Node}s and assigns these values to the corresponding node locations.
	 *
	 * @param nodesCache
	 *            the nodes cache containing the requested nodes
	 * @param monitor
	 *            a {@link IProgressMonitor} for progress monitoring
	 */
	private void loadAltitudes(HashMap<Long, Node> nodesCache, IProgressMonitor monitor) {
		List<Location> nodeLocations = new ArrayList<>();

		for (Node n : nodesCache.values()) {
			nodeLocations.add(n.getLocation());
		}

		List<Double> altitudes = altService.getAltitudes(nodeLocations, monitor);

		for (Node n : nodesCache.values()) {
			n.setAltitude(altitudes.get(0));
			altitudes.remove(0);
		}
	}

	/**
	 * Loads ONLY the parameters from the provided configuration file. Use this method to save memory and loading time in case only the
	 * parameters are needed.
	 *
	 * @param configurationFile
	 * @param monitor
	 * @throws LoadingException
	 */
	public void loadParameters(File configurationFile, IProgressMonitor monitor) throws LoadingException {
		if (!parametersLoaded) {
			try {
				this.configurationFile = configurationFile;
				initSerializer();
				monitor.subTask("Reading simulation parameters");
				parameterBeans = serializer.readData(ParameterBean.class, PreferenceUtil.getBoolean(IPreferenceConstants.USE_CACHE_FOR_LOADING));
			} catch (Exception e) {
				throw new LoadingException("Could not load parameters", e);
			}
			parametersLoaded = true;
		}
	}

	/**
	 * Load ALL beans of the configuration, including {@link ParameterBean}s. <br>
	 * <b>ATTENTION:</b> This method does ONLY load the beans, but not process them!
	 * {@link #loadConfiguration(SimulationModel, IProgressMonitor, Properties)} must be called to process the beans and fill the model
	 *
	 * @param configurationFile
	 * @param monitor
	 * @throws LoadingException
	 */
	public void loadBeans(File configurationFile, IProgressMonitor monitor) throws LoadingException {
		if (!beansLoaded) {
			this.configurationFile = configurationFile;
			initSerializer();
			boolean useCache = PreferenceUtil.getBoolean(IPreferenceConstants.USE_CACHE_FOR_LOADING);
			try {
				monitor.beginTask("Reading configuration from XML", 13);
				monitor.worked(1);
				loadParameters(configurationFile, monitor);
				monitor.subTask("Reading routes");
				routeBeans = serializer.readData(RouteBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading traffic generators");
				trafficGeneratorBeans = serializer.readData(TrafficGeneratorBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading vehicles");
				vehicleBeans = serializer.readData(VehicleBean.class, auxLabels, useCache);
				monitor.worked(1);
				commDataBeans = serializer.readData(VehicleCommDataBean.class, useCache);
				// set start time
				startTime = serializer.getStartTime();
				monitor.worked(1);
				monitor.subTask("Reading infrastructure");
				infrastructureBeans = serializer.readData(InfrastructureBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading raw infrastructure");
				baseSegmentBeans = serializer.readData(BaseRoadSegmentBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading detectors");
				detectorBeans = serializer.readData(DetectorBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading intersection controls");
				intersectionControlBeans = serializer.readData(IntersectionControlBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading models");
				modelBeans = serializer.readData(ModelBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading longitudinal controls");
				controlBeans = serializer.readData(LongitudinalControlBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading behaviours and obstructions");
				behaviorBeans = serializer.readData(BehaviorBean.class, auxLabels, useCache);
				monitor.worked(1);
				obstructionsBeans = serializer.readData(TrafficObstructionBean.class, auxLabels, useCache);
				monitor.worked(1);
				monitor.subTask("Reading platoons");
				platoonManagerBeans = serializer.readData(PlatoonManagerDataBean.class, auxLabels, useCache);
				monitor.worked(1);
			} catch (Exception e1) {
				throw new LoadingException("error on loading data", e1);
			}
		}
		beansLoaded = true;
	}

	private void initSerializer() {
		if (serializer == null) {
			serializer = new DataSerializer();
			serializer.readConfiguration(configurationFile);
		}

	}

	public File getConfigurationFile() {
		return configurationFile;
	}

	/**
	 * Loads all simulation-related data from the configuration files being identified by the <i>configuration.xml</i> file.
	 *
	 * @param model
	 *            the {@link SimulationModel} to be initialised with the loaded data
	 * @param monitor
	 *            a {@link IProgressMonitor} for progress monitoring
	 * @param loadingOptions
	 *            a set of properties indicating various loading options (e.g. global output folder, geometry resetting)
	 * @throws LoadingException
	 *             a {@link LoadingException} being thrown when an error occurs while initialising the simulation model
	 */
	public void loadConfiguration(SimulationModel model, IProgressMonitor monitor, final Properties loadingOptions) throws LoadingException {
		if (monitor == null) {
			monitor = new NullProgressMonitor();
		}

		if (!beansLoaded) {
			throw new LoadingException("Beans must be loaded before loading configuration!");
		}
		monitor.beginTask("Processing configuration " + serializer.getConfiguration().getConfigurationFile().getName(), 100);
		network = new RoadNetwork();

		graphFile = serializer.getConfiguration().obtainGraphFile();

		outputFolder = new File(StringUtil.ensureNotEmpty(serializer.getConfiguration().getOutputFolder(), DEFAULT_OUTPUT_FOLDER_NAME));

		if (!outputFolder.isAbsolute()) {
			String rootFolder = PropertyUtil.getStringProperty(loadingOptions, PropertyKeys.GLOBAL_OUTPUT_FOLDER, "");

			if (rootFolder.isEmpty()) {
				// no global output folder set
				File originalConfPath;
				if ((originalConfPath = SimulationKernel.getInstance().getTempToOriginalFileMapping()
						.get(serializer.getConfiguration().getConfigurationFile())) != null) {
					// we are in batch mode and need to store output in
					// original, not temporary directory
					rootFolder = originalConfPath.getParent();
				} else {
					// we are not in batch mode and therefore use the
					// configuration directory as output
					rootFolder = serializer.getConfigurationDirectory();
				}
			} else {
				// global output folder is set
				String confDir = FileUtil.removeTempFileExtension(serializer.getConfigurationDirectory());
				rootFolder += "/" + confDir.substring(confDir.lastIndexOf('\\'));
			}

			outputFolder = new File(rootFolder, serializer.getConfiguration().getOutputFolder());
		}

		monitor.subTask("Processing infrastructure");
		List<BaseRoadSegmentBean> baseSegments = new ArrayList<>();

		for (AbstractBean ab : baseSegmentBeans) {
			if (ab instanceof BaseRoadSegmentBean) {
				baseSegments.add((BaseRoadSegmentBean) ab);
			}
		}

		segmentsCache = new HashMap<>();
		Map<Long, List<RoadSegment>> routingSegmentIdMapping = new HashMap<>();
		HashMap<Long, Node> nodesCache = new HashMap<>();

		try {
			loadTrafficModels(model, monitor);
		} catch (Exception e2) {
			throw new LoadingException("unable to read models", e2);
		}

		try {
			loadLongitudinalControls(model, monitor);
		} catch (Exception e2) {
			throw new LoadingException("unable to read longitudinal controls", e2);
		}
		if (model.getSimulationParameters() != null) {
			ParameterParser.adaptModels(model.getModelRegistry(), model.getSimulationParameters());
		}

		monitor.worked(10);

		// separate infrastructure list to nodes and roadsegments
		List<NodeBean> nodes = new ArrayList<>();
		List<RoadSegmentBean> roadSegments = new ArrayList<>();
		Map<Long, List<ConnectorBean>> connectors = new HashMap<>();
		separateInfrastructure(infrastructureBeans, nodes, roadSegments, connectors, oldRoutingIds);

		boolean reset = loadingOptions.containsKey(PropertyKeys.RESET_GEOMETRY) ? (Boolean) loadingOptions.get(PropertyKeys.RESET_GEOMETRY) : false;

		// ----------------------
		// LOAD NODES CACHE
		// ----------------------
		if (!reset) {
			Set<Long> warnedNodes = new HashSet<>();
			for (NodeBean bean : nodes) {
				if (nodesCache.containsKey(bean.getId()) && !warnedNodes.contains(bean.getId())) {
					Logger.logWarn("Node " + bean.getId() + " defined repeatedly!");
					warnedNodes.add(bean.getId());
				}
				nodesCache.put(bean.getId(), new Node(bean.getId(), bean.getAltitude(), bean.getType()));
			}
		}

		monitor.worked(10);
		// create segments cache and update nodes

		// ----------------------
		// LOAD ROAD SEGMENTS
		// ----------------------
		loadRoadSegments(monitor, baseSegments, roadSegments, nodesCache, routingSegmentIdMapping, reset);

		// ----------------------
		// LOAD ALTITUDES
		// ----------------------
		if (reset && PreferenceUtil.getBoolean(IPreferenceConstants.AUTO_LOAD_ALTITUDES)) {
			monitor.subTask("Loading altitudes");
			loadAltitudes(nodesCache, monitor);
		}

		monitor.worked(10);

		// ----------------------
		// INIT ROAD SEGMENTS
		// merge too short, link together
		// ----------------------
		newIdMapping = new HashMap<>();

		// set source and sink road segments and create crossings if needed
		for (Iterator<Node> nodeIt = nodesCache.values().iterator(); nodeIt.hasNext() && !donotInitialize;) {

			Node curNode = nodeIt.next();
			monitor.subTask("Connecting " + nodesCache.values().size() + " nodes (" + curNode.getId() + ")");

			// check special cases (entrance, exit or just through)
			if (reset && curNode.getSourceReferences().size() == 2 && curNode.getSinkReferences().size() == 1
					&& curNode.getRoutingReferences().size() == 3) {
				/**
				 * 1 sink, 2 sources - entrance ramp
				 */
				RoadSegment srcSeg1 = getFromSegmentsCache(curNode.getSourceReferences().get(0));
				RoadSegment srcSeg2 = getFromSegmentsCache(curNode.getSourceReferences().get(1));
				RoadSegment sinkSeg = getFromSegmentsCache(curNode.getSinkReferences().get(0));

				if (srcSeg1.getLaneCount() + srcSeg2.getLaneCount() == sinkSeg.getLaneCount()) {
					RoadSegment ramp, straight;

					if (srcSeg1.getLaneCount() > srcSeg2.getLaneCount()) {
						ramp = srcSeg2;
						straight = srcSeg1;
					} else {
						ramp = srcSeg1;
						straight = srcSeg2;
					}

					// update geometry of ramp
					Vector intersection = SpatialUtil.firstIntersection(ramp.getLeftMostLane().getLeftEdge(),
							straight.getRightMostLane().getRightEdge());

					if (intersection == null && srcSeg1.getLaneCount() == srcSeg2.getLaneCount()) {
						// no intersection found? maybe ramp and straight were
						// assigned wrongly, try exchanging the road segments
						// inwards
						RoadSegment temp = ramp;
						ramp = straight;
						straight = temp;
						intersection = SpatialUtil.firstIntersection(ramp.getLeftMostLane().getLeftEdge(),
								straight.getRightMostLane().getRightEdge());
					}

					Vector lastPt = SpatialUtil.closestPointOutOfList(intersection, ramp.getRoadGeometry().getPoints());
					List<Vector> newGeom = new ArrayList<>();

					for (Vector v : ramp.getRoadGeometry().getPoints()) {
						if (!v.equals(lastPt)) {
							newGeom.add(v);
						} else {
							break;
						}
					}

					if (newGeom.size() > 0) {
						newGeom.remove(newGeom.size() - 1);
					}
					newGeom.add(CollectionUtil.getFirstObject(sinkSeg.getRightMostLane().getLeftEdge()));
					ramp.updateRoadGeometry(new RoadGeometry(newGeom));
					curNode.setRamp(true);
				}
			} else if (reset && curNode.getSourceReferences().size() == 1 && curNode.getSinkReferences().size() == 2
					&& curNode.getRoutingReferences().size() == 3) {
				/**
				 * 2 sinks, 1 source - exit ramp
				 */
				RoadSegment sinkSeg1 = getFromSegmentsCache(curNode.getSinkReferences().get(0));
				RoadSegment sinkSeg2 = getFromSegmentsCache(curNode.getSinkReferences().get(1));
				RoadSegment srcSeg = getFromSegmentsCache(curNode.getSourceReferences().get(0));

				if (sinkSeg1.getLaneCount() + sinkSeg2.getLaneCount() == srcSeg.getLaneCount()) {
					RoadSegment ramp, straight;

					if (sinkSeg1.getLaneCount() > sinkSeg2.getLaneCount()) {
						ramp = sinkSeg2;
						straight = sinkSeg1;
					} else {
						ramp = sinkSeg1;
						straight = sinkSeg2;
					}

					// update geometry of ramp
					Vector intersection = SpatialUtil.firstIntersection(ramp.getLeftMostLane().getLeftEdge(),
							straight.getRightMostLane().getRightEdge());
					Vector lastPt = SpatialUtil.closestPointOutOfList(intersection, ramp.getRoadGeometry().getPoints());
					List<Vector> newGeom = new ArrayList<>();
					List<Vector> rampPts = ramp.getRoadGeometry().getPoints();

					for (int i = rampPts.size() - 1; i >= 0; i--) {
						Vector v = rampPts.get(i);

						if (!v.equals(lastPt)) {
							newGeom.add(0, v);
						} else {
							if (newGeom.isEmpty())
								newGeom.add(v);
							break;
						}
					}

					if (newGeom.size() > 1) {
						newGeom.remove(0);
					}
					newGeom.add(0, CollectionUtil.getLastObject(srcSeg.getRightMostLane().getLeftEdge()));
					ramp.updateRoadGeometry(new RoadGeometry(newGeom));
					curNode.setRamp(true);
				}
			} else if (curNode.getRoutingReferences().size() == 2 && curNode.getSourceReferences().size() < 3
					&& curNode.getSinkReferences().size() < 3) {
				/**
				 * check the amount of different routing ids connected to this node. If 2 -> eliminate node becasue its only a street
				 * passing. If >2 -> We have a crossing - create it
				 */
				// through street: assign source and sink road segments
				boolean merged = false;

				for (Long src : curNode.getSourceReferences()) {
					for (Long sink : curNode.getSinkReferences()) {
						RoadSegment srcSeg = getFromSegmentsCache(src);
						RoadSegment sinkSeg = getFromSegmentsCache(sink);

						if (srcSeg != null && sinkSeg != null && srcSeg.getRoutingId() != sinkSeg.getRoutingId()) {
							boolean srcShorter = false;

							if (reset && sinkSeg.getRoadLength() < MINIMUM_ROADSEGMENT_LENGTH
									&& srcSeg.getRoadLength() < MINIMUM_ROADSEGMENT_LENGTH) {
								/**
								 * if both are too short: the longer segment must survive. This is because neighbored segments must have the
								 * same routing id, and therefore we exchange segments if srcSeg is shorter than sinkseg. This way, the next
								 * if check is executed first, otherwise the result are two different routing ids next to each other
								 */
								if (srcSeg.getRoadLength() < sinkSeg.getRoadLength()) {
									// exchange to always retain the longer
									// segment
									srcShorter = true;
								}
							}

							if (reset && sinkSeg.getRoadLength() < MINIMUM_ROADSEGMENT_LENGTH && !srcShorter) {
								RoadSegment newSeg = SpatialUtil.mergeSegments(srcSeg, sinkSeg);
								if (newSeg == null || sinkSeg.getEndNode().equals(curNode) /*
																							 * avoid concurrentmodification
																							 */) {
									continue;
								}

								assert newSeg.getRoadGeometry().getPoints().size() > 1 : "segment too short: " + newSeg.getId();
								segmentsCache.put(newSeg.getId(), newSeg);
								sinkSeg.getEndNode().getSourceReferences().remove(sinkSeg.getId());
								sinkSeg.getEndNode().getSourceReferences().add(newSeg.getId());
								segmentsCache.remove(sinkSeg.getId());
								Logger.logDebug("Removed too short segment " + sinkSeg.getId() + " (routing id " + sinkSeg.getRoutingId() + " -> "
										+ newSeg.getRoutingId() + ")");
								newIdMapping.put(sinkSeg.getId(), newSeg.getId());
								oldRoutingIds.add(sinkSeg.getRoutingId());
								merged = true;
							} else if (reset && srcSeg.getRoadLength() < MINIMUM_ROADSEGMENT_LENGTH) {

								RoadSegment newSeg = SpatialUtil.mergeSegments(sinkSeg, srcSeg);
								if (newSeg == null || srcSeg.getStartNode().equals(curNode)) {
									continue;
								}

								assert newSeg.getRoadGeometry().getPoints().size() > 1 : "segment too short: " + newSeg.getId();
								segmentsCache.put(newSeg.getId(), newSeg);
								srcSeg.getStartNode().getSinkReferences().remove(srcSeg.getId());
								srcSeg.getStartNode().getSinkReferences().add(newSeg.getId());
								segmentsCache.remove(srcSeg.getId());
								Logger.logDebug("Removed too short segment " + srcSeg.getId() + " (routing id " + srcSeg.getRoutingId() + " -> "
										+ newSeg.getRoutingId() + ")");
								newIdMapping.put(srcSeg.getId(), newSeg.getId());
								oldRoutingIds.add(srcSeg.getRoutingId());
								merged = true;
							} else {
								if (srcSeg.getSinkRoadSegment() == null
										|| !NumberUtil.doubleEquals(srcSeg.getRoadLength(), sinkSeg.getRoadLength())) {
									// no merge, only link
									srcSeg.setSinkRoadSegment(sinkSeg);

									assert srcSeg.getRoadGeometry().getPoints().size() > 1 : "segment too short: " + srcSeg.getId();
									segmentsCache.put(srcSeg.getId(), srcSeg);
								}
							}
						}
					}
				}

				// possibly, segments were removed if they are too sort. Remove
				// also node references afterwards (to
				// avoid concurrent modification)
				if (merged) {
					nodeIt.remove();
				}
			}
		}

		monitor.worked(10);
		// ----------------------
		// CREATE JUNCTIONS (from nodes)
		// ----------------------
		// do this in a separate loop to ensure that all small segments are
		// merged
		SpatialCache spatialCache = new SpatialCache(30 * 1000);

		for (Iterator<Node> nodeIt = nodesCache.values().iterator(); nodeIt.hasNext() && !donotInitialize;) {
			Node curNode = nodeIt.next();

			if (curNode.getRoutingReferences().size() > 2 || curNode.getRoutingReferences().size() > 1 && curNode.getSourceReferences().size() >= 3
					&& curNode.getSinkReferences().size() >= 3) {
				// junction
				AbstractJunction j;
				j = new DefaultJunction(curNode.getId(), spatialCache);
				j.setSimulationTimeProvider(model);
				j.setType(curNode.getType());

				for (Long sink : curNode.getSinkReferences()) {
					RoadSegment snkseg = getFromSegmentsCache(sink);
					if (snkseg != null) {
						snkseg.setSourceJunction(j);
						j.addConnectionOut(snkseg);
					}
				}

				for (Long src : curNode.getSourceReferences()) {
					RoadSegment srcseg = getFromSegmentsCache(src);
					if (srcseg != null) {
						srcseg.setJunction(j);
						j.addConnectionIn(srcseg);
					}
				}

				j.setAltitude(curNode.getAltitude());

				if (curNode.isRamp()) {
					j.setType(NodeType.DRIVE_THROUGH);
				}

				network.addJunction(j);
			}
		}

		monitor.subTask("Adding road segments to network");
		// add road segments to network
		for (RoadSegment seg : segmentsCache.values()) {
			if (!newIdMapping.containsKey(seg.getId())) {
				network.addRoadSegment(seg);
			}
		}

		// ----------------------
		// SMOOTH NETWORK (check if fully defined before, if yes, smoothing has
		// already been done before)
		// ----------------------
		monitor.worked(10);

		if (reset) {
			monitor.subTask("Smoothing network..");
			double smoothing = PreferenceUtil.getDouble(IPreferenceConstants.NETWORK_SMOOTHING) / 100;
			if (!NumberUtil.doubleEquals(smoothing, 0)) {
				network = SpatialUtil.smoothNetwork(network, 1 - (float) smoothing);
			}
		}

		if (donotInitialize) {
			return;
		}

		// ----------------------
		// INITIALIZE JUNCTIONS
		// ----------------------
		monitor.worked(10);

		monitor.subTask("Initialize " + network.getJunctions().size() + " junctions ");
		try {
			network.getJunctions().stream().forEach(j -> {
				try {
					if (reset) {
						j.initializeInterior(connectors.get(j.getId()), true);
					} else {
						j.initializeInterior(connectors.get(j.getId()), false);
					}
				} catch (Exception e) {
					throw new RuntimeException("Cannot initialize junction " + j.getId(), e);
				}
			});
		} catch (RuntimeException e) {
			throw new LoadingException(e.getCause().getMessage(), e.getCause());
		}

		// ----------------------
		// MERGE JUNCTIONS
		// ----------------------
		if (reset) {
			// remember already processed junctions in case both interescting
			// junctions are contained in junctionsToCheck list
			List<AbstractJunction> alreadyProcessed = new ArrayList<>();
			double minimalJunctionDistance = PreferenceUtil.getDouble(IPreferenceConstants.JUNCTION_MERGE_LIMIT) / 10;
			List<AbstractJunction> allJunctions = new ArrayList<>(network.getJunctions()); // avoid
			// concurrentmodificationexception

			for (AbstractJunction intersecting : allJunctions) {
				if (alreadyProcessed.contains(intersecting) && true) {
					continue;
				}

				boolean intersectionFound = false;

				for (AbstractJunction mergedJunc : network.getJunctions()) {
					if (!intersecting.equals(mergedJunc)
							&& (SpatialUtil.getShortestDistance(intersecting.getBounds(), mergedJunc.getBounds()) < minimalJunctionDistance
									|| SpatialUtil.intersects(intersecting.getBounds(), mergedJunc.getBounds()))) {
						Logger.logInfo(
								"Found junction intersection which is merged (ids: " + mergedJunc.getId() + " / " + intersecting.getId() + ")");
						monitor.subTask("Merging junction ids: " + mergedJunc.getId() + " / " + intersecting.getId());
						// merge connectors
						MergeResult mergeResult;

						try {
							mergeResult = SpatialUtil.merge(mergedJunc, intersecting);
							if (intersecting.getType() != NodeType.SIMPLE) {
								mergeResult.getMergedJunction().setType(intersecting.getType());
							}
							for (RoadSegment rs : mergeResult.getRemovedRoadSegments()) {
								segmentsCache.remove(rs.getId());
								oldRoutingIds.add(rs.getRoutingId());
							}

							network.getRoadSegments().removeAll(mergeResult.getRemovedRoadSegments());
						} catch (Exception e) {
							throw new LoadingException("merge error", e);
						}

						alreadyProcessed.add(mergedJunc);
						intersectionFound = true;

						break;// if found -> do not search because it could
						// happen that both junctions are removed then
					}
				}

				if (intersectionFound) {
					// remove old junction
					network.getJunctions().remove(intersecting);
				}
			}

		}

		network.initializeJunctionConnectors();

		// LOAD TRAFFIC LIGHTS
		if (intersectionControlBeans != null) {
			long maxId = 0;

			for (AbstractBean bean : intersectionControlBeans) {
				if (bean instanceof TrafficLightBean) {
					TrafficLight trafficLight = ObjectAdapter.toTrafficLight((TrafficLightBean) bean);

					List<Long> connectorIds = ((TrafficLightBean) bean).getConnectors();

					for (Long connectorId : connectorIds) {
						JunctionConnector connector = network.getJunctionConnectorById(connectorId);

						if (connector != null) {
							connector.setTrafficLight(trafficLight);
						}
					}

					if (trafficLight.getId() > maxId) {
						maxId = trafficLight.getId();
					}

					network.addTrafficLight(trafficLight);
				}
			}

			TrafficLight.NEXT_ID = maxId + 1;
		}

		try {
			network.getJunctions().forEach(j -> {
				try {
					j.createApproaches();

					if (PreferenceUtil.getBoolean(IPreferenceConstants.ENABLE_LOOP_DETECTORS)) {
						for (JunctionApproach approach : j.getApproaches()) {
							QueueMonitor queueMonitor = approach.getQueueMonitor();
							network.addDetector(queueMonitor.getStopLineDetector());
							network.addDetector(queueMonitor.getUpstreamDetector());
						}
					}
				} catch (Exception e) {
					throw new RuntimeException("Cannot create junction approaches " + j.getId(), e);
				}
			});
		} catch (RuntimeException e) {
			throw new LoadingException(e.getMessage());
		}

		// LOAD TRAFFIC LIGHT CONTROLLERS
		if (intersectionControlBeans != null) {
			for (AbstractBean bean : intersectionControlBeans) {
				if (bean instanceof TrafficLightControllerBean) {
					AbstractJunction junction = network.getJunctionByKey(((TrafficLightControllerBean) bean).getJunctionId());
					List<ControlLogicBean> controlLogic = ((TrafficLightControllerBean) bean).getControlLogic();
					Collections.sort(controlLogic, (c1, c2) -> new Long(c1.getTrafficLightId()).compareTo(new Long(c2.getTrafficLightId())));

					if (junction == null) {
						throw new IllegalArgumentException("Invalid junction identifier or control logic.");
					}

					// Assign control logic to target connectors
					for (ControlLogicBean cb : controlLogic) {
						TrafficLight trafficLight = network.getTrafficLightById(cb.getTrafficLightId());

						if (trafficLight == null) {
							throw new IllegalArgumentException("Invalid traffic light identifier.");
						}

						JunctionApproach approach = junction.getApproachForTrafficLight(trafficLight);
						ControlLogic logic = ObjectAdapter.toControlLogic(cb, trafficLight, approach.getQueueMonitor());
						approach.addControlLogicFor(trafficLight, logic);
					}

					TrafficLightController<?> controller = ObjectAdapter.toTrafficLightController((TrafficLightControllerBean) bean, junction);

					// ML: Self-organizing control requires its detectors to be update
					if (controller.getControlMode() == TrafficLightControllers.SELF_ORGANIZING) {
						for (JunctionApproach approach : junction.getApproaches()) {
							QueueMonitor queueMonitor = approach.getQueueMonitor();
							network.addDetector(queueMonitor.getStopLineDetector());
							network.addDetector(queueMonitor.getUpstreamDetector());
						}
					}

					junction.setTrafficLightController(controller);
				}
			}
		}

		monitor.worked(10);

		// FIX Roadsegments leading to nirvana
		network.getRoadSegments().parallelStream().forEach(seg -> {
			if (!seg.getEndNode().isSinkDeadEnd() && seg.getJunction() == null && seg.getSinkRoadSegment() != null
					&& seg.getSinkRoadSegment().getLaneCount() < seg.getLaneCount()) {
				for (LaneSegment ls : seg.getLaneSegments()) {
					if (ls.getSinkLaneSegment() == null) {
						ls.setLaneType(Lane.Type.ENTRANCE);
						ls.addVehicle(VehicleFactory.createObstacle(ls.getRoadLength()));
					}
				}
			}
		});

		// READ ROUTES (for usage in traffic generators),

		monitor.subTask("Processing " + routeBeans.size() + " available routes");
		try {
			routeBeans.parallelStream().forEach(abstractBean -> {

				if (abstractBean instanceof RouteBean) {
					RouteBean bean = (RouteBean) abstractBean;
					// clean up route ids of segments that were deleted before
					// because too short
					List<Long> cleanedUpRouteIds = bean.getRoadSegmentIds();
					cleanedUpRouteIds.removeAll(oldRoutingIds);
					IRoute route = new Route(cleanedUpRouteIds, bean.getId());

					try {
						route = RoutingUtil.updateInitialAndTargetRoadSegments(route, routingSegmentIdMapping);
					} catch (RoutingException e) {
						throw new RuntimeException(e);
					}

					if (route != null) {
						model.getRouteRegistry().addRoute(route.getId(), route);
					}
				}
			});
		} catch (RuntimeException e) {
			throw new LoadingException(e.getMessage());
		}

		monitor.worked(10);

		// TRAFFIC GENERATORS

		generators = new ArrayList<>();
		long maxGeneratorId = 0;

		for (AbstractBean abstractBean : trafficGeneratorBeans) {
			monitor.subTask("Processing " + trafficGeneratorBeans.size() + " traffic generators (" + abstractBean.getId() + ")");

			if (abstractBean instanceof TrafficGeneratorBean) {
				TrafficGeneratorBean bean = (TrafficGeneratorBean) abstractBean;
				ContinuousVehicleGenerator generator = new ContinuousVehicleGenerator(model, bean.getId(), bean.getSpeedInitial(),
						bean.getInFlowRate(), bean.getInFlowRateStdDeviation(), bean.getIsStochastic(), bean.getSampleInterval(),
						getFromSegmentsCache(bean.getInitialRoadSegmentId()), bean.getSpeedAverage(), bean.getAverageSpeedStdDeviation(),
						bean.getMaxNumVehicles());

				generator.setVehicleLengthStdDeviation(bean.getVehicleLengthStdDeviation());
				generator.setLaneChangeModelIdentifier(bean.getLaneChangeModelRef());
				generator.setLongitudinalControlIdentifier(bean.getLongitudinalControlRef());
				generator.setVehicleLengthStdDeviation(bean.getVehicleLengthStdDeviation());
				generator.setMemoryModelIdentifier(bean.getMemoryModelRef());
				generator.setFuelModelIdentifier(bean.getFuelConsumptionModelRef());

				if (bean.getPossibleRouteIds() != null && !bean.getPossibleRouteIds().isEmpty()) {
					for (Long routeId : bean.getPossibleRouteIds()) {
						if (model.getRouteRegistry().hasRoute(routeId)) {
							generator.addPossibleRoute(model.getRouteRegistry().getRoute(routeId));
						} else {
							Logger.logWarn("Could not add generator with possible route with id " + routeId + ": Not found in data.");
						}
					}
				}

				if (generator.getId() > maxGeneratorId) {
					maxGeneratorId = generator.getId();
				}

				generators.add(generator);
			}
		}

		AbstractVehicleGenerator.NEXT_GENERATOR_ID = Math.max(maxGeneratorId + 1, AbstractVehicleGenerator.NEXT_GENERATOR_ID);

		// ----------------------
		// LOAD LOOP DETECTORS
		// ----------------------
		loadDetectors(model, monitor);

		// Load VEHICLES and create generator if necessary
		PredefinedVehicleGenerator predefGenerator = new PredefinedVehicleGenerator();
		predefGenerator.setSimulationModel(model);

		monitor.subTask("Processing vehicles");
		predefinedVehicles = new ArrayList<>();

		try {
			Map<Long, VehicleCommDataBean> commDataBeanMap = new HashMap<>();
			for (AbstractBean commDataBean : commDataBeans) {
				commDataBeanMap.put(commDataBean.getId(), (VehicleCommDataBean) commDataBean);
			}
			for (AbstractBean abstractBean : vehicleBeans) {
				if (abstractBean instanceof VehicleBean) {
					VehicleBean vehicleBean = (VehicleBean) abstractBean;

					if (!vehicleBean.getDeactivated()) {
						predefinedVehicles.add(VehicleFactory.createVehicle(model, vehicleBean, commDataBeanMap));
					}
				}
			}
		} catch (Exception e) {
			throw new LoadingException("unable to process vehicles:\n" + e.getMessage(), e);
		}

		// check if starttime matches

		if (predefinedVehicles.size() > 0) {
			if (predefinedVehicles.parallelStream().anyMatch(v -> v.getStartTime() == null)) {
				throw new LoadingException("missing start time for at least 1 vehicle");
			}
			if (startTime == null) {
				// start time unset? use minimum start time
				startTime = predefinedVehicles.stream().map(Vehicle::getStartTime).min(Date::compareTo).get();
			} else {
				long timeDiff = Math.abs(predefinedVehicles.get(0).getStartTime().getTime() - getStartTime().getTime());

				if (timeDiff > VEHICLE_STARTTIME_TOLERANCE_MS) {
					Logger.logWarn(
							String.format("Difference between first vehicle start and simulation start is %.3f seconds!", (double) timeDiff / 1000));

					if (!PropertyUtil.getBooleanProperty(loadingOptions, PropertyKeys.BATCH_EXECUTION, false)) {

						startTime = predefinedVehicles.get(0).getStartTime();
						serializer.getConfiguration().setStartTime(startTime);
						serializer.writeConfiguration(serializer.getConfiguration().getConfigurationFile());
					}
				}
			}
		} else {
			startTime = new Date();
		}

		predefGenerator.setVehicles(predefinedVehicles);

		if (!predefinedVehicles.isEmpty()) {
			generators.add(predefGenerator);
		}

		// Load vehicle behaviors
		monitor.subTask("Processing behaviours");
		ArrayList<Behavior> behaviors = new ArrayList<>();
		if (behaviorBeans != null && behaviorBeans.size() > 0) {
			for (AbstractBean abstractBean : behaviorBeans) {
				if (abstractBean instanceof BehaviorBean) {
					BehaviorBean behaviorBean = (BehaviorBean) abstractBean;
					behaviors.add(Behavior.createBehavior(behaviorBean));
				}
			}
		}

		if (!predefinedVehicles.isEmpty() && !behaviors.isEmpty()) {
			assignBehaviors(predefinedVehicles, behaviors);
		}

		// ///////////
		// PLATOONING
		// ///////////

		monitor.subTask("Processing platoons");

		if (platoonManagerBeans != null && platoonManagerBeans.size() > 0) {
			if (platoonManagerBeans.get(0) instanceof PlatoonManagerDataBean) {
				PlatoonManagerDataBean bean = (PlatoonManagerDataBean) platoonManagerBeans.get(0);
				PlatoonManagerData platoonManagerData = ObjectAdapter.toPlatoonManagerData(bean, model, predefinedVehicles);
				this.platoonManager = new PlatoonManager(platoonManagerData);
			} else {
				throw new LoadingException("unable to process platoon configuration!");
			}
		}
		monitor.worked(10);

		// Load obstructions
		monitor.subTask("Processing obstructions");

		TrafficObstructionGenerator obstrGenerator = new TrafficObstructionGenerator();
		ArrayList<Obstruction> obstructions = new ArrayList<>();

		for (AbstractBean abstractBean : obstructionsBeans) {
			if (abstractBean instanceof TrafficObstructionBean) {
				TrafficObstructionBean obs = (TrafficObstructionBean) abstractBean;

				Obstruction obstruction = VehicleFactory.createObstruction(segmentsCache.get(obs.getRoadSegmentId()), obs.getPosition(),
						obs.getOffset(), obs.getDuration(), obs.getIsPermanent(), obs.getLaneId());
				obstructions.add(obstruction);
				network.addObstruction(obstruction);
			}
		}

		if (!obstructions.isEmpty()) {
			obstrGenerator.setVehicles(obstructions);
		}

		generators.add(obstrGenerator);

		monitor.worked(10);
		loaded = true;
	}

	public boolean isLoaded() {
		return loaded;
	}

	/**
	 * Loads all road segments from the configuration files and fills the given parameter objects therewith.
	 *
	 * @param monitor
	 *            a {@link IProgressMonitor} for progress monitoring
	 * @param baseSegments
	 *            a list of pre-loaded entities of type {@link BaseRoadSegmentBean}
	 * @param roadSegments
	 *            a list of {@link BaseRoadSegmentBean}s read from the configuration file (or empty if not available yet)
	 * @param nodesCache
	 *            a list of {@link Node}s read from the configuration file, with set identifier and altitude (if known in bean file)
	 * @param routingSegmentIdMapping
	 *            mapping from routing identifier to road segment identifier(s) for easy lookup of {@link RoadSegment} for an existing
	 *            routing identifier
	 * @param reset
	 *            a reset flag
	 */
	private void loadRoadSegments(IProgressMonitor monitor, List<? extends BaseRoadSegmentBean> baseSegments, List<RoadSegmentBean> roadSegments,
			HashMap<Long, Node> nodesCache, Map<Long, List<RoadSegment>> routingSegmentIdMapping, boolean reset) {

		// create cache
		HashMap<Long, BaseRoadSegmentBean> baseRoadSegmentsBeanCache = new HashMap<>();
		HashMap<Long, RoadSegmentBean> roadSegmentsBeanCache = new HashMap<>();
		for (BaseRoadSegmentBean baseRoadSegmentBean : baseSegments) {
			baseRoadSegmentsBeanCache.put(baseRoadSegmentBean.getId(), baseRoadSegmentBean);
		}
		for (RoadSegmentBean roadSegmentBean : roadSegments) {
			roadSegmentsBeanCache.put(roadSegmentBean.getId(), roadSegmentBean);
		}

		if (reset && baseSegments.isEmpty()) {
			Logger.logError("Cannot reset if base not available");
			return;
		}

		List<? extends BaseRoadSegmentBean> tempRoadSegmentBeans;

		// /////////
		// 1. READ OR INITIALIZE NODES
		// /////////

		/**
		 * check if reset is checked and select appropriate source for reading nodes (in roadSegments, some nodes
		 */
		if (reset) {
			tempRoadSegmentBeans = baseSegments;
		} else {
			tempRoadSegmentBeans = roadSegments;
		}

		/** Read nodes from defined source */
		for (BaseRoadSegmentBean tempRsBean : tempRoadSegmentBeans) {
			monitor.subTask("Create " + tempRoadSegmentBeans.size() + " road segments (" + tempRsBean.getId() + ")");

			if (tempRsBean.getLaneCount() <= 0) {
				Logger.logWarn("Road Segment " + tempRsBean.getId() + " (" + tempRsBean.getName() + ") defined with 0 lanes. Ignoring");
				continue;
			}

			// add source node references
			Node node;

			if (nodesCache.containsKey(tempRsBean.getSourceNodeId())) {
				node = nodesCache.get(tempRsBean.getSourceNodeId());
			} else {
				Logger.logWarn("Could not find referenced node " + tempRsBean.getSourceNodeId());
				node = new Node(tempRsBean.getSourceNodeId());
			}

			if (tempRsBean.getMeta() != null && tempRsBean.getMeta().contains("r")) {
				node.setType(NodeType.ROUNDABOUT);
			}

			node.addSinkReference(tempRsBean.getId(), tempRsBean.getRoutingId());
			CoordinateBean loc = CollectionUtil.getFirstObject(tempRsBean.getPoints());
			node.setLocation(new Location(loc.getX(), loc.getY()));
			nodesCache.put(tempRsBean.getSourceNodeId(), node);

			// add sink node references
			if (nodesCache.containsKey(tempRsBean.getSinkNodeId())) {
				node = nodesCache.get(tempRsBean.getSinkNodeId());
			} else {
				Logger.logWarn("Could not find referenced node " + tempRsBean.getSinkNodeId());
				node = new Node(tempRsBean.getSinkNodeId());
			}

			if (tempRsBean.getMeta() != null && tempRsBean.getMeta().contains("r")) {
				node.setType(NodeType.ROUNDABOUT);
			}

			node.addSourceReference(tempRsBean.getId(), tempRsBean.getRoutingId());
			loc = CollectionUtil.getLastObject(tempRsBean.getPoints());
			node.setLocation(new Location(loc.getX(), loc.getY()));
			nodesCache.put(tempRsBean.getSinkNodeId(), node);
		}

		// nodes initialized
		for (BaseRoadSegmentBean tempBean : tempRoadSegmentBeans) {

			if (tempBean == null) {
				continue;
			}

			// ////////
			// load geometry
			// ////////
			RoadGeometry geom = new RoadGeometry();
			if (reset) {

				List<CoordinateBean> points = tempBean.getPoints();

				if (points != null) {
					// load geometry from base bean
					for (CoordinateBean c : points) {
						geom.addPoint(c.getX(), c.getY());
					}
				}
			} else {
				RoadSegmentBean completeBean = roadSegmentsBeanCache.get(tempBean.getId());
				for (CoordinateBean c : completeBean.getFittedPoints()) {
					geom.addPoint(c.getX(), c.getY());
				}
				for (CoordinateBean c : completeBean.getPoints()) {
					geom.addOriginalPoint(c.getX(), c.getY());
				}
			}

			// ////////
			// generate or load lane segments
			// ////////
			RoadSegment roadSegment;

			if (reset) {
				// generate lane segments
				roadSegment = new RoadSegment(geom, tempBean.getLaneCount(), tempBean.getId());
				// entry / exit lanes
				if (tempBean != null) {
					if (tempBean.getEntryLanes() != null || tempBean.getExitLanes() != null) {
						if (tempBean.getEntryLanes() != null) {
							for (int i : tempBean.getEntryLanes()) {
								LaneSegment seg = roadSegment.laneSegment(i);
								if (seg != null) {
									seg.setLaneType(Lane.Type.ENTRANCE);
									seg.addVehicle(VehicleFactory.createObstacle(seg.getRoadGeometry().getRoadLength() - 1));
								}
							}
						}
						if (tempBean.getExitLanes() != null) {
							for (int i : tempBean.getExitLanes()) {
								LaneSegment seg = roadSegment.laneSegment(i);
								if (seg != null) {
									seg.setLaneType(Lane.Type.EXIT);
								}
							}
						}
					}

					if (StringUtil.isNotNullOrEmpty(tempBean.getRestrictions())) {
						int i = 0;

						for (String s : tempBean.getRestrictions().split("\\|")) {
							LaneDirection dir = LaneDirection.valueOf(s);

							if (dir != null && roadSegment.getLaneCount() > i) {
								roadSegment.laneSegment(i).setRestriction(dir);
							}

							i++;
						}
					}
				}
			} else {
				// load lane segments
				List<LaneSegment> lss = new ArrayList<>();
				RoadSegmentBean completeBean = roadSegmentsBeanCache.get(tempBean.getId());

				for (LaneSegmentBean lsb : completeBean.getLaneSegments()) {
					LaneSegment ls = new LaneSegment();
					ls.setLaneIndex(lsb.getLaneIndex());
					ls.setLaneWidth(lsb.getLaneWidth());
					ls.setLeftEdge(ObjectAdapter.toVectorList(lsb.getLeftEdge()));
					ls.setRightEdge(ObjectAdapter.toVectorList(lsb.getRightEdge()));
					ls.setRoadGeometry(new RoadGeometry(ObjectAdapter.toVectorList(lsb.getPoints())));
					ls.setLaneType(Lane.Type.valueOf(lsb.getType()));

					if (Lane.Type.valueOf(lsb.getType()) == Lane.Type.ENTRANCE) {
						ls.addVehicle(VehicleFactory.createObstacle(ls.getRoadGeometry().getRoadLength() - 1));
					}

					lss.add(ls);
				}

				roadSegment = new RoadSegment(geom, lss, completeBean.getId());
			}

			roadSegment.setRoutingId(tempBean.getRoutingId());
			roadSegment.setSpeedLimitKmh(tempBean.getSpeedLimit());
			roadSegment.setStartNode(nodesCache.get(tempBean.getSourceNodeId()));
			roadSegment.setEndNode(nodesCache.get(tempBean.getSinkNodeId()));
			roadSegment.setOsmReverse(tempBean.isReverse());
			roadSegment.setName(tempBean.getName());
			roadSegment.setOneWay(tempBean.isOneWay());

			assert roadSegment.getRoadGeometry().getPoints().size() > 1 : "segment too short: " + roadSegment.getId();
			segmentsCache.put(roadSegment.getId(), roadSegment);

			if (routingSegmentIdMapping.containsKey(roadSegment.getRoutingId())) {
				routingSegmentIdMapping.get(roadSegment.getRoutingId()).add(roadSegment);
			} else {
				List<RoadSegment> segs = new ArrayList<>();
				segs.add(roadSegment);
				routingSegmentIdMapping.put(roadSegment.getRoutingId(), segs);
			}

			// create entry and exit lanes with obstacles. Must be done after
			// all
			// geometries are updated, because for obstacles length of lane
			// segment is used
		}
	}

	private void loadDetectors(SimulationModel model, IProgressMonitor monitor) {
		if (detectorBeans != null) {

			long maxDetectorId = 0;

			for (AbstractBean abstractBean : detectorBeans) {
				monitor.subTask("Loading detector (" + abstractBean.getId() + ")");

				if (abstractBean instanceof DetectorBean) {
					DetectorBean detectorBean = (DetectorBean) abstractBean;
					long detectorId = detectorBean.getId();
					long roadSegmentId = detectorBean.getRoadSegmentId();
					int sampleInterval = detectorBean.getSampleInterval();
					double position = detectorBean.getPosition();

					RoadSegment targetSegment = network.getRoadSegmentByKey(roadSegmentId);

					if (targetSegment == null) {
						Logger.logWarn("Detector '" + detectorId + "' cannot be assigned to road segment '" + roadSegmentId
								+ "' because such segment does not exist.");
						continue;
					} else {

						LoopDetector loopDetector = new LoopDetector(detectorId, targetSegment, position, sampleInterval, DetectionMode.DUAL);
						network.addDetector(loopDetector);

						if (detectorId > maxDetectorId) {
							maxDetectorId = detectorId;
						}
					}
				}
			}

			LoopDetector.NEXT_DETECTOR_ID = Math.max(maxDetectorId + 1, LoopDetector.NEXT_DETECTOR_ID);
		}
	}

	private void loadLongitudinalControls(SimulationModel model, IProgressMonitor monitor) throws Exception {
		if (controlBeans != null) {
			for (AbstractBean abstractBean : controlBeans) {

				if (abstractBean instanceof ContainerControlBean) {
					// Process container beans in a second iteration
					continue;
				}

				monitor.subTask("Loading longitudinal control (" + abstractBean.getId() + ")");

				LongitudinalModel longitudinalModel = null;

				if (abstractBean instanceof ExtendedHumanDriverControlBean) {
					ExtendedHumanDriverControlData data = ObjectAdapter.toEHDMxData((ExtendedHumanDriverControlBean) abstractBean);
					ExtendedHumanDriverControl ehdmx = new ExtendedHumanDriverControl(data);
					ehdmx.setCllxtEnabled(((ExtendedHumanDriverControlBean) abstractBean).getCllxtEnabled());

					// Assign longitudinal model
					longitudinalModel = model.getModelRegistry()
							.getModel(((ExtendedHumanDriverControlBean) abstractBean).getLongitudinalModelIdentifier(), LongitudinalModel.class);

					if (longitudinalModel != null && longitudinalModel instanceof IComposableLongitudinalModel) {
						ehdmx.setLongitudinalModel((IComposableLongitudinalModel) longitudinalModel);
					} else {
						Logger.logError("Invalid longitudinal model identifier '"
								+ ((ExtendedHumanDriverControlBean) abstractBean).getLongitudinalModelIdentifier() + "'.");
					}

					// Assign noise models
					Noise accelerationNoise = model.getModelRegistry()
							.getModel(((ExtendedHumanDriverControlBean) abstractBean).getAccelerationNoiseIdentifier(), Noise.class);
					Noise velocityDifferenceNoise = model.getModelRegistry()
							.getModel(((ExtendedHumanDriverControlBean) abstractBean).getVelocityDifferenceNoiseIdentifier(), Noise.class);
					Noise distanceNoise = model.getModelRegistry()
							.getModel(((ExtendedHumanDriverControlBean) abstractBean).getDistanceNoiseIdentifier(), Noise.class);

					if (accelerationNoise != null) {
						ehdmx.setAccelerationNoise(accelerationNoise);
					}

					if (velocityDifferenceNoise != null) {
						ehdmx.setVelocityDifferenceNoise(velocityDifferenceNoise);
					}

					if (distanceNoise != null) {
						ehdmx.setDistanceNoise(distanceNoise);
					}

					model.getModelRegistry().registerModel(data.getIdentifier(), ehdmx);
				} else if (abstractBean instanceof HumanDriverControlBean) {
					HumanDriverControlData data = ObjectAdapter.toHDMxData((HumanDriverControlBean) abstractBean);
					HumanDriverControl hdmx = new HumanDriverControl(data);
					hdmx.setCllxtEnabled(((HumanDriverControlBean) abstractBean).getCllxtEnabled());

					// Assign longitudinal model
					longitudinalModel = model.getModelRegistry().getModel(((HumanDriverControlBean) abstractBean).getLongitudinalModelIdentifier(),
							LongitudinalModel.class);

					if (longitudinalModel != null && longitudinalModel instanceof IComposableLongitudinalModel) {
						hdmx.setLongitudinalModel((IComposableLongitudinalModel) longitudinalModel);
					} else {
						Logger.logError("Invalid longitudinal model identifier '"
								+ ((HumanDriverControlBean) abstractBean).getLongitudinalModelIdentifier() + "'.");
					}

					// Assign noise models
					Noise velocityDifferenceNoise = model.getModelRegistry()
							.getModel(((HumanDriverControlBean) abstractBean).getVelocityDifferenceNoiseIdentifier(), Noise.class);
					Noise distanceNoise = model.getModelRegistry().getModel(((HumanDriverControlBean) abstractBean).getDistanceNoiseIdentifier(),
							Noise.class);

					if (velocityDifferenceNoise != null) {
						hdmx.setVelocityDifferenceNoise(velocityDifferenceNoise);
					}

					if (distanceNoise != null) {
						hdmx.setDistanceNoise(distanceNoise);
					}

					model.getModelRegistry().registerModel(data.getIdentifier(), hdmx);
				} else if (abstractBean instanceof PlatoonLongitudinalControlBean) {
					PlatoonLongitudinalControlBean bean = (PlatoonLongitudinalControlBean) abstractBean;
					PlatoonLongitudinalControlData data = ObjectAdapter.toPlatoonLogitudinalControlData(bean, model);
					PlatoonLongitudinalControl control = new PlatoonLongitudinalControl(data);
					model.getModelRegistry().registerModel(data.getIdentifier(), control);
				} else if (abstractBean instanceof DefaultLongitudinalControlBean) {
					// The default longitudinal control just has a longitudinal model identifier
					LongitudinalControl<ILongitudinalModel> defaultControl = ObjectAdapter
							.toDefaultLongitudinalControl((DefaultLongitudinalControlBean) abstractBean);

					longitudinalModel = model.getModelRegistry()
							.getModel(((DefaultLongitudinalControlBean) abstractBean).getLongitudinalModelIdentifier(), LongitudinalModel.class);

					if (longitudinalModel != null) {
						defaultControl.setLongitudinalModel(longitudinalModel);
					}

					model.getModelRegistry().registerModel(defaultControl.getIdentifier(), defaultControl);
				}
			}

			// Process container controls
			for (AbstractBean abstractBean : controlBeans) {

				if (!(abstractBean instanceof ContainerControlBean)) {
					continue;
				}

				if (abstractBean instanceof VehicleAutomationControlBean) {
					VehicleAutomationControlBean automationBean = (VehicleAutomationControlBean) abstractBean;
					List<String> controlIdentifiers = automationBean.getControlIdentifiers();

					// At least one control identifier must be specified
					if (controlIdentifiers.isEmpty()) {
						Logger.logError("At least one longitudinal control identifier must be specified in a container control.");
						continue;
					}

					VehicleAutomationControl automationControl = ObjectAdapter.toVehicleAutomationControl(automationBean);
					automationControl.setModelIdentifier(model.getUniqueId());
					LongitudinalControl<ILongitudinalModel> childControl = null;
					List<LongitudinalControl<ILongitudinalModel>> childControls = new ArrayList<>();

					for (String controlIdentifier : controlIdentifiers) {
						childControl = model.getModelRegistry().getModel(controlIdentifier, LongitudinalControl.class);

						if (childControl != null) {
							childControls.add(childControl);
						} else {
							Logger.logError("Invalid longitudinal control identifier '" + controlIdentifier + "'.");
						}
					}

					if (childControls.size() > 0) {
						automationControl.setChildControls(childControls);
						automationControl.initialize();
						model.getModelRegistry().registerModel(automationControl.getIdentifier(), automationControl);
					} else {
						Logger.logError("At least one valid longitudinal control identifier must be specified in a container control.");
					}
				}
			}
		}
	}

	/**
	 * Loads all traffic models from the configuration file <i>models.xml</i>.
	 *
	 * @param model
	 *            a {@link SimulationModel} to add the loaded traffic models to
	 * @param monitor
	 *            a {@link IProgressMonitor} for progress monitoring
	 * @throws Exception
	 *             an exception which occurred while loading the traffic models
	 */
	private void loadTrafficModels(SimulationModel model, IProgressMonitor monitor) throws Exception {

		if (modelBeans != null) {
			for (AbstractBean abstractBean : modelBeans) {
				monitor.subTask("Loading traffic model (" + abstractBean.getId() + ")");

				if (abstractBean instanceof ACCDataBean) {
					ACCData data = ObjectAdapter.toACCData((ACCDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new ACC(data));
				} else if (abstractBean instanceof CACCDataBean) {
					CACCData data = ObjectAdapter.toCACCData((CACCDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new CACC(data));
				} else if (abstractBean instanceof CACCLaneChangeDataBean) {
					CACCLaneChangeData data = ObjectAdapter.toCACCLaneChangeData((CACCLaneChangeDataBean) abstractBean, model);
					model.getModelRegistry().registerModel(data.getIdentifier(), new CACCLaneChange(data));
				} else if (abstractBean instanceof IIDMDataBean) {
					IIDMData data = ObjectAdapter.toIIDMData((IIDMDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new IIDM(data));
				} else if (abstractBean instanceof OVMDataBean) {
					OVMData data = ObjectAdapter.toOVMData((OVMDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new OVM(data));
				} else if (abstractBean instanceof KraussDataBean) {
					KraussData data = ObjectAdapter.toKraussData((KraussDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new Krauss(model.getSimulationResolution() / 1000.0, data));
				} else if (abstractBean instanceof IDMDataBean) {
					IDMData data = ObjectAdapter.toIDMData((IDMDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new IDM(data));
				} else if (abstractBean instanceof GippsDataBean) {
					GippsData data = ObjectAdapter.toGippsData((GippsDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new Gipps(model.getSimulationResolution() / 1000.0, data));
				} else if (abstractBean instanceof MOBILDataBean) {
					MOBILData data = ObjectAdapter.toMOBILData((MOBILDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new MOBIL(data));
				} else if (abstractBean instanceof MemoryDataBean) {
					MemoryInputData data = ObjectAdapter.toMemoryInputData((MemoryDataBean) abstractBean);
					model.getModelRegistry().registerModel(data.getIdentifier(), new Memory(data));
				} else if (abstractBean instanceof ConsumptionBean) {
					ConsumptionBean data = (ConsumptionBean) abstractBean;
					FuelConsumptionModel consumptionModel = new PhysicsConsumptionModel(data.getModelIdentifier(), data.getCarData(),
							data.getEngineData());
					model.getModelRegistry().registerModel(data.getModelIdentifier(), consumptionModel);
				} else if (abstractBean instanceof NoiseDataBean) {
					NoiseDataBean noiseBean = (NoiseDataBean) abstractBean;
					Noise noise = ObjectAdapter.toNoise(noiseBean);
					model.getModelRegistry().registerModel(noiseBean.getModelIdentifier(), noise);
				} else if (abstractBean instanceof DistractionModelBean) {
					DistractionModelBean distractionBean = (DistractionModelBean) abstractBean;
					DistractionModel distractionModel = ObjectAdapter.toDistractionModel(distractionBean);
					model.setDistractionModel(distractionModel);
				} else if (abstractBean instanceof GilbertElliotChannelDataBean) {
					GilbertElliotChannelDataBean geDataBean = (GilbertElliotChannelDataBean) abstractBean;
					GilbertElliotChannelModel geModel = new GilbertElliotChannelModel(geDataBean.getpGoodGood(), geDataBean.getpBadBad(),
							geDataBean.getRoundtripMillisMean(), geDataBean.getRoundtripStdDev());
					geModel.setName(geDataBean.getFullName());
					if (geDataBean.getRandomSeed() != null) {
						geModel.setRandomSeed(geDataBean.getRandomSeed());
					}
					model.getModelRegistry().registerModel(geDataBean.getModelIdentifier(), geModel);
				} else if (abstractBean instanceof GeometricDistributionChannelDataBean) {
					GeometricDistributionChannelDataBean geomDataBean = (GeometricDistributionChannelDataBean) abstractBean;
					GeometricDistributedChannelModel geomModel = new GeometricDistributedChannelModel(geomDataBean.getLambda(),
							geomDataBean.getRoundtripMillisMean(), geomDataBean.getRoundtripMillisOffset(), geomDataBean.getRoundtripStdDev());
					geomModel.setName(geomDataBean.getFullName());
					if (geomDataBean.getRandomSeed() != null) {
						geomModel.setRandomSeed(geomDataBean.getRandomSeed());
					}
					model.getModelRegistry().registerModel(geomDataBean.getModelIdentifier(), geomModel);
				} else if (abstractBean instanceof UniformlyDistributedChannelDataBean) {
					UniformlyDistributedChannelDataBean uniDataBean = (UniformlyDistributedChannelDataBean) abstractBean;
					UniformlyDistributedChannelModel uniModel = new UniformlyDistributedChannelModel(uniDataBean.getpSuccess());
					uniModel.setName(uniDataBean.getFullName());
					if (uniDataBean.getRandomSeed() != null) {
						uniModel.setRandomSeed(uniDataBean.getRandomSeed());
					}
					model.getModelRegistry().registerModel(uniDataBean.getModelIdentifier(), uniModel);
				}
			}
		}
	}

	/**
	 * Splits the infrastructure list into nodes and segments because nodes are needed first and order is not guaranteed.
	 *
	 * @param infrastructure
	 *            the list of infrastructure beans to be separated
	 * @param nodes
	 *            an empty list to which infrastructure entities of type {@link NodeBean} are added
	 * @param segments
	 *            an empty list to which infrastructure entities of type {@link RoadSegmentBean} are added
	 * @param connectors
	 *            an empty map to which infrastructure entities of type {@link ConnectorBean} are added
	 * @param removedRoutingIds
	 *            an empty set to which infrastructure entities of type {@link RemovedRoutingIdsBean} are added
	 */
	private void separateInfrastructure(List<? extends AbstractBean> infrastructure, List<NodeBean> nodes, List<RoadSegmentBean> segments,
			Map<Long, List<ConnectorBean>> connectors, Set<Long> removedRoutingIds) {

		long maxId = 0;
		List<Long> processedConnectors = new ArrayList<>();
		List<Long> processedNodes = new ArrayList<>();
		List<Long> processedRoadSegments = new ArrayList<>();

		List<Long> duplicateNodes = new ArrayList<>();
		List<Long> duplicateRoadSegments = new ArrayList<>();
		List<Long> duplicateConnectors = new ArrayList<>();

		for (AbstractBean bean : infrastructure) {
			if (bean instanceof RemovedRoutingIdsBean) {
				removedRoutingIds.addAll(((RemovedRoutingIdsBean) bean).getOldRoutingIds());
			} else if (bean instanceof NodeBean) {
				if (!processedNodes.contains(bean.getId())) {
					processedNodes.add(bean.getId());
				} else {
					duplicateNodes.add(bean.getId());
				}

				nodes.add((NodeBean) bean);
			} else if (bean instanceof RoadSegmentBean) {
				if (!processedRoadSegments.contains(bean.getId())) {
					processedRoadSegments.add(bean.getId());
				} else {
					duplicateRoadSegments.add(bean.getId());
				}

				segments.add((RoadSegmentBean) bean);
			} else if (bean instanceof ConnectorBean) {
				List<ConnectorBean> jcs;

				if (connectors.containsKey(((ConnectorBean) bean).getNodeId())) {
					jcs = connectors.get(((ConnectorBean) bean).getNodeId());
				} else {
					jcs = new ArrayList<>();
				}

				if (!processedConnectors.contains(bean.getId())) {
					processedConnectors.add(bean.getId());
				} else {
					duplicateConnectors.add(bean.getId());
				}

				jcs.add((ConnectorBean) bean);

				if (bean.getId() > maxId) {
					maxId = bean.getId();
				}

				connectors.put(((ConnectorBean) bean).getNodeId(), jcs);
			}
		}
		if (!duplicateNodes.isEmpty() || !duplicateRoadSegments.isEmpty() || !duplicateConnectors.isEmpty()) {
			Logger.logWarn(String.format("Found duplicates in road infrastructure: %d Nodes [%s], %d Road Segments [%s], %d Junction Connectors [%s]",
					duplicateNodes.size(), CollectionUtil.toString(duplicateNodes, ",", true), duplicateRoadSegments.size(),
					CollectionUtil.toString(duplicateRoadSegments, ",", true), duplicateConnectors.size(),
					CollectionUtil.toString(duplicateConnectors, ",", true)));
		}
		VehiclesLane.NEXT_ID = maxId + 1;
	}

	/**
	 * Sets the junction initialisation flag (for debug reasons only).
	 *
	 * @param donotInitialize
	 *            the flag's new value
	 */
	public void setDonotInitialize(boolean donotInitialize) {
		this.donotInitialize = donotInitialize;
	}

	public List<? extends AbstractBean> getBehaviorBeans() {
		return behaviorBeans;
	}

	public List<? extends AbstractBean> getCommDataBeans() {
		return commDataBeans;
	}

	public List<? extends AbstractBean> getInfrastructure() {
		return infrastructureBeans;
	}

	public List<? extends AbstractBean> getModelBeans() {
		return modelBeans;
	}

	public List<? extends AbstractBean> getControlBeans() {
		return controlBeans;
	}

	public List<? extends AbstractBean> getIntersectionControlBeans() {
		return intersectionControlBeans;
	}

	public List<? extends AbstractBean> getObstructionsBeans() {
		return obstructionsBeans;
	}

	public List<? extends AbstractBean> getVehicleBeans() {
		return vehicleBeans;
	}

	public List<? extends AbstractBean> getPlatoonManagerBeans() {
		return platoonManagerBeans;
	}

	public List<? extends AbstractBean> getParameterBeans() {
		return parameterBeans;
	}

}

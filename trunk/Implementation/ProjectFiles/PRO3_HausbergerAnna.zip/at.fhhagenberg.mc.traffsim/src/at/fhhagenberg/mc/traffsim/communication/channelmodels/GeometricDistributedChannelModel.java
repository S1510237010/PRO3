package at.fhhagenberg.mc.traffsim.communication.channelmodels;

import java.util.Random;

import org.apache.commons.math3.distribution.GeometricDistribution;
import org.apache.commons.math3.random.JDKRandomGenerator;
import org.apache.commons.math3.random.RandomGenerator;

import at.fhhagenberg.mc.traffsim.communication.IChannelModel;

public class GeometricDistributedChannelModel implements IChannelModel {
	/** lambda parameter characterization of distibution */
	private float lambda;
	/** the time to be added to delay if transmission failed */
	private final long roundtripMillisMean;
	/** gaussian standard deviation for round trip */
	private final double roundtripStdDev;
	/** offset for each calculated delay */
	private final long offset;

	private Random random;
	private String name;

	private GeometricDistribution geoDist;

	public GeometricDistributedChannelModel(float lambda, long roundtripMillisMean, long roundtripMillisOffset, double roundtripStdDev) {
		super();
		this.lambda = lambda;
		geoDist = new GeometricDistribution(lambda);
		this.roundtripMillisMean = roundtripMillisMean;
		this.roundtripStdDev = roundtripStdDev;
		offset = roundtripMillisOffset;
		random = new Random();
	}

	@Override
	public long getNextDelay() {
		int geomSample = geoDist.sample();
		return offset + geomSample * roundtripMillisMean + (long) (random.doubles(geomSample).sum() * roundtripStdDev);
	}

	@Override
	public boolean isSuccessful() {
		return true;
	}

	@Override
	public IChannelModel clone() throws CloneNotSupportedException {
		// clone not necessary because model is stateless and same instance can be used
		return this;
	}

	public void setRandomSeed(long seed) {
		RandomGenerator rng = new JDKRandomGenerator();
		rng.setSeed(seed);
		geoDist = new GeometricDistribution(rng, lambda);
		random = new Random(seed);
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getRoundtripMillisMean() {
		return roundtripMillisMean;
	}

	public double getRoundtripStdDev() {
		return roundtripStdDev;
	}

	@Override
	public String toString() {
		return name + " (lambda " + lambda + ", RoundTrip " + roundtripMillisMean + " ms, Std Dev: " + roundtripStdDev + ")";
	}
}

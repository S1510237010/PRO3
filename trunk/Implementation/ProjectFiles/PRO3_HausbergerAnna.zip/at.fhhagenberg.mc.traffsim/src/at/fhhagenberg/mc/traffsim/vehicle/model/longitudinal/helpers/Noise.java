package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers;

import java.util.Random;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.vehicle.model.AbstractModel;

/**
 * Class allowing to model noise within microscopic traffic models with (random process) models for white noise or correlated noise (Wiener
 * process).
 *
 * <p>
 * Paper for reference:
 * </p>
 * <p>
 * <a href="http://arxiv.org/abs/physics/0508222"> M. Treiber, A. Kesting, D. Helbing, Understanding widely scattered traffic flows, the
 * capacity drop, and platoons as effects of variance-driven time gaps. Phys. Rev. E 74, 016123 (2006).</a>
 * </p>
 */
public class Noise extends AbstractModel {

	/** Amplification variable */
	private double amplifier;

	/** The error as dynamic state variable */
	private double error;

	/**
	 * The fluctuation strength in m^2/s^3 of dv/dt = a_det + xi(t). In case of a Wiener process, the standard deviation.
	 */
	private double fluctStrength;

	/** The name of the noise model */
	private String fullname;

	/** Flag to determine if the noise is a Wiener process or not */
	private boolean isWienerProcess;

	/** Random object to create uniformly distributed random variables */
	private Random random;

	/** The correlation time [s] */
	private double tauRelaxAcc;

	/**
	 * Instantiates a new noise.
	 */
	public Noise() {
		error = 0.0;
		random = new Random(0l);
	}

	/**
	 * Instantiates a new noise from the given data bean.
	 *
	 * @param bean
	 *            the data bean holding all relevant configuration parameters
	 */
	public Noise(NoiseDataBean bean) {
		error = 0.0;
		this.fluctStrength = bean.getFluctStrength();
		this.tauRelaxAcc = bean.getTau();
		this.isWienerProcess = tauRelaxAcc != 0 ? true : false;
		this.amplifier = bean.getAmplifier();
		fullname = bean.getFullName();
		random = new Random(0l);
	}

	/**
	 * Creates a copy of the current noise instance.
	 *
	 * @return the copied noise instance
	 */
	public Noise createCopy() {
		Noise copy = new Noise();
		copy.setFullname(fullname);
		copy.setFluctStrength(fluctStrength);
		copy.setTau(tauRelaxAcc);
		copy.setAmplifier(amplifier);
		return copy;
	}

	/**
	 * Gets the amplification value.
	 *
	 * @return the amplification value
	 */
	public double getAmplifier() {
		return amplifier;
	}

	/**
	 * Gets the noise's time-correlated error.
	 *
	 * @return the time-correlated error
	 */
	public double getError() {
		return error;
	}

	/**
	 * Gets the noise's fluctuation strength. In case of a Wiener process, the standard deviation.
	 *
	 * @return the fluctuation strength
	 */
	public double getFluctStrength() {
		return fluctStrength;
	}

	/**
	 * Gets the name of the noise model.
	 *
	 * @return the model's name
	 */
	public String getFullname() {
		return fullname;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see at.fhhagenberg.mc.traffsim.vehicle.model.AbstractModel#getName()
	 */
	@Override
	public String getName() {
		return fullname;
	}

	/**
	 * Gets the noise's correlation time.
	 *
	 * @return the correlation time
	 */
	public double getTau() {
		return tauRelaxAcc;
	}

	/**
	 * Calculates a uniformly distributed random variable with mean=0 and variance=1.
	 *
	 * @return a random variable realization
	 */
	private double getUniformlyDistributedRealization() {
		final double randomVar = random.nextDouble();
		final double randomMu0Sigma1 = Math.sqrt(12.) * (randomVar - 0.5);
		return randomMu0Sigma1;
	}

	/**
	 * Sets the amplification value.
	 *
	 * @param amplifier
	 *            the new amplification value
	 */
	public void setAmplifier(double amplifier) {
		this.amplifier = amplifier;
	}

	/**
	 * Sets the noise's fluctuation strength
	 *
	 * @param fluctStrength
	 *            the new fluctuation strength
	 */
	public void setFluctStrength(double fluctStrength) {
		this.fluctStrength = fluctStrength;
	}

	/**
	 * Sets the noise model's name.
	 *
	 * @param fullName
	 *            the new name
	 */
	public void setFullname(String fullName) {
		this.fullname = fullName;
	}

	/**
	 * Sets the noise's correlation time.
	 *
	 * @param tau
	 *            the new correlation time
	 */
	public void setTau(double tau) {
		this.tauRelaxAcc = tau;
		isWienerProcess = tauRelaxAcc != 0 ? true : false;
	}

	/**
	 * Updates the noise based on the given time-interval. In every time step the error value is modified according to the noise
	 * parameterization.
	 *
	 * @param dt
	 *            the simulation time step [s]
	 */
	public void update(double dt) {
		final double randomMu0Sigma1 = getUniformlyDistributedRealization();

		if (isWienerProcess) {
			final double betaAcc = Math.exp(-dt / tauRelaxAcc);
			error = betaAcc * error + fluctStrength * Math.sqrt(2 * dt / tauRelaxAcc) * randomMu0Sigma1;
		} else {
			// Delta-correlated acceleration noise
			error = Math.sqrt(fluctStrength / dt) * randomMu0Sigma1;
		}
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.IItemSelectionListener;
import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.StringUtil;

/**
 *
 * @author Manuel Lindorfer
 *
 */
public class VehicleControlView extends ViewPart
		implements IModelInputChangedListener, ISimulationStateListener, IItemSelectionListener, ISimulationTimeUpdatable, IVehicleListener {

	// Update
	private long lastUpdate = 0;

	// Selection
	private long currentVehicleId = -1;

	private Map<Long, String> idLabelMapping = new HashMap<>();
	private Map<String, Long> labelIdMapping = new HashMap<>();
	private Map<Long, Vehicle> vehicleMap = new ConcurrentHashMap<>();
	// Statistics
	private double currentAcc;
	private double currentSpeed;
	private SimulationModel currentModel;

	// UI
	private Label lblSelectionHint;
	private Combo cmbVehicles;

	private Button btnControlVehicle;
	private Button btnFollowVehicle;
	private Group grpVehicleParameters;
	private Label lblCurrentAcceleration;
	private Spinner spinnerAcceleration;
	private Label lblCurrentSpeed;
	private Spinner spinnerSpeed;

	private boolean isCurrentlyControlling;
	private boolean isFollowing;

	public VehicleControlView() {

	}

	@Override
	public void dispose() {
		SimulationKernel.getInstance().removeInputChangedListener(this);
		currentVehicleId = -1;
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
			currentModel.removeSimulationStateListener(this);
			currentModel.removeSimulationTimeUpdatable(this);
		}

		super.dispose();
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout(SWT.HORIZONTAL));

		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(2, false));

		Label lblVehicles = new Label(composite, SWT.NONE);
		lblVehicles.setText("Select a vehicle: ");

		cmbVehicles = new Combo(composite, SWT.READ_ONLY);
		GridData gd_combo = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_combo.widthHint = 200;
		cmbVehicles.setLayoutData(gd_combo);
		cmbVehicles.setSize(200, 23);

		lblSelectionHint = new Label(composite, SWT.NONE);
		lblSelectionHint.setForeground(SWTResourceManager.getColor(SWT.COLOR_LINK_FOREGROUND));
		lblSelectionHint.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		GridData gd_label = new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1);
		gd_label.widthHint = 300;
		gd_label.heightHint = 23;
		lblSelectionHint.setLayoutData(gd_label);

		btnFollowVehicle = new Button(composite, SWT.CHECK);
		btnFollowVehicle.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnFollowVehicle.setText("Follow this vehicle");
		btnFollowVehicle.setEnabled(false);
		btnFollowVehicle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				isFollowing = btnFollowVehicle.getSelection();
			}
		});

		btnControlVehicle = new Button(composite, SWT.CHECK);
		btnControlVehicle.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnControlVehicle.setText("Manually control this vehicle");
		btnControlVehicle.setEnabled(false);
		new Label(composite, SWT.NONE);
		new Label(composite, SWT.NONE);

		btnControlVehicle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				if (cmbVehicles.getItemCount() > 0 && StringUtil.isNotNullOrEmpty(cmbVehicles.getText())) {
					long vehicleId = labelIdMapping.get(cmbVehicles.getText());
					Vehicle vehicle = vehicleMap.get(vehicleId);

					if (btnControlVehicle.getSelection()) {
						isCurrentlyControlling = true;
					} else {
						isCurrentlyControlling = false;
					}

					if (vehicle != null) {
						vehicle.setIsVehicleControlledManually(isCurrentlyControlling);

						if (isCurrentlyControlling) {
							spinnerAcceleration.setEnabled(true);
							cmbVehicles.setEnabled(false);

							double imposedAcc = spinnerAcceleration.getSelection() / Math.pow(10, spinnerAcceleration.getDigits());
							vehicle.setImposedAcc(imposedAcc);
						} else {
							spinnerAcceleration.setEnabled(false);
							cmbVehicles.setEnabled(true);
						}
					}
				}
			}
		});

		cmbVehicles.setEnabled(false);
		cmbVehicles.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				validateSelection();
			}
		});

		grpVehicleParameters = new Group(composite, SWT.NONE);
		grpVehicleParameters.setText("Vehicle parameters");
		grpVehicleParameters.setLayout(new GridLayout(2, false));
		grpVehicleParameters.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));

		lblCurrentAcceleration = new Label(grpVehicleParameters, SWT.NONE);
		lblCurrentAcceleration.setText("Current acceleration [m/s�] ");

		spinnerAcceleration = new Spinner(grpVehicleParameters, SWT.BORDER);
		spinnerAcceleration.setDigits(2);
		spinnerAcceleration.setMaximum(1000);
		spinnerAcceleration.setMinimum(-1000);
		spinnerAcceleration.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerAcceleration.setEnabled(false);
		spinnerAcceleration.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (vehicleMap != null && vehicleMap.containsKey(currentVehicleId) && isCurrentlyControlling) {
					Vehicle vehicle = vehicleMap.get(currentVehicleId);
					double imposedAcc = spinnerAcceleration.getSelection() / Math.pow(10, spinnerAcceleration.getDigits());
					vehicle.setImposedAcc(imposedAcc);
				}
			}
		});

		lblCurrentSpeed = new Label(grpVehicleParameters, SWT.NONE);
		lblCurrentSpeed.setText("Current speed [m/s] ");

		spinnerSpeed = new Spinner(grpVehicleParameters, SWT.BORDER);
		spinnerSpeed.setDigits(2);
		spinnerSpeed.setMaximum(10000);
		spinnerSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerSpeed.setEnabled(false);

		SimulationKernel.getInstance().addInputChangedListener(this);
	}

	public boolean containsLabel(String label) {
		return label == null || labelIdMapping.containsKey(label);
	}

	public long getId(String label) {
		return labelIdMapping.get(label);
	}

	public boolean containsId(long id) {
		return idLabelMapping.containsKey(id);
	}

	public String getLabel(long id) {
		return idLabelMapping.get(id);
	}

	private void updateControllerUI() {

		getDisplay().asyncExec(new Runnable() {
			@Override
			public void run() {
				if (!cmbVehicles.isDisposed()) {
					if (cmbVehicles.getItemCount() > 0) {
						cmbVehicles.setEnabled(true);

						if (cmbVehicles.getSelectionIndex() < 0) {
							cmbVehicles.select(0);
							validateSelection();
						}
					} else {
						cmbVehicles.setEnabled(false);
					}
				}
			}
		});
	}

	private void validateSelection() {
		getDisplay().asyncExec(new Runnable() {
			@Override
			public void run() {
				if (cmbVehicles.getSelectionIndex() >= 0) {
					changeVehicle(cmbVehicles.getText(), labelIdMapping.get(cmbVehicles.getText()));
				}
			}
		});
	}

	private void changeVehicle(String newLabel, long newId) {

		// Remove control from previously selected vehicle
		if (vehicleMap.containsKey(currentVehicleId)) {
			vehicleMap.get(currentVehicleId).setIsVehicleControlledManually(false);
		}

		currentVehicleId = newId;
		currentAcc = 0;
		currentSpeed = 0;

		getDisplay().asyncExec(new Runnable() {
			@Override
			public void run() {
				btnControlVehicle.setSelection(false);
				btnControlVehicle.setEnabled(true);
				btnFollowVehicle.setSelection(false);
				btnFollowVehicle.setEnabled(true);
				spinnerAcceleration.setSelection(0);
				spinnerAcceleration.setEnabled(false);
				spinnerSpeed.setSelection(0);
				spinnerSpeed.setEnabled(false);
				cmbVehicles.setEnabled(false);
				isCurrentlyControlling = false;
			}
		});

		vehicleDataChanged(currentVehicleId);
		updateControllerUI();
	}

	@Override
	public void inputChanged(SimulationModel newModel) {

		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
			currentModel.removeSimulationStateListener(this);
			currentModel.removeSimulationTimeUpdatable(this);
		}

		reset();
		if (newModel == null) {
			if (getViewSite() != null) {
				getViewSite().getShell().getDisplay().asyncExec(new Runnable() {
					@Override
					public void run() {
						if (!cmbVehicles.isDisposed() && !btnControlVehicle.isDisposed() && !spinnerAcceleration.isDisposed()
								&& !spinnerSpeed.isDisposed()) {
							cmbVehicles.removeAll();
							cmbVehicles.setEnabled(false);
							btnControlVehicle.setSelection(false);
							btnControlVehicle.setEnabled(false);
							btnFollowVehicle.setSelection(false);
							btnFollowVehicle.setEnabled(false);
							spinnerAcceleration.setEnabled(false);
							spinnerSpeed.setEnabled(false);
							spinnerSpeed.setSelection(0);
							spinnerAcceleration.setSelection(0);
							currentAcc = 0;
							currentSpeed = 0;
							isCurrentlyControlling = false;
						}
					}
				});
			}
		} else {
			newModel.addItemSelectionListener(this);
			newModel.addSimulationStateListener(this);
			newModel.addSimulationTimeUpdatable(this);
			currentModel = newModel;
			processVehicles();
		}
	}

	private Display getDisplay() {
		return VehicleControlView.this.getSite().getWorkbenchWindow().getShell().getDisplay();
	}

	@Override
	public void setFocus() {
		// Not implemented
	}

	@Override
	public void itemsSelected(List<AbstractJunction> junctions, List<JunctionConnector> connectors, List<RoadSegment> roadSegments,
			List<LaneSegment> laneSegments, List<Vehicle> vehicles) {
		if (!vehicles.isEmpty() && !isCurrentlyControlling) {
			getSite().getShell().getDisplay().asyncExec(new Runnable() {
				@Override
				public void run() {
					cmbVehicles.setText(vehicles.get(0).getLabel());
					changeVehicle(vehicles.get(0).getLabel(), vehicles.get(0).getUniqueId());
				}
			});
		}
	}

	public void vehicleDataChanged(long vehicleId) {
		if (vehicleId == currentVehicleId && vehicleMap.containsKey(vehicleId)
				&& System.currentTimeMillis() - lastUpdate > currentModel.getSimulationResolution()) {
			lastUpdate = System.currentTimeMillis();

			getViewSite().getShell().getDisplay().syncExec(new Runnable() {
				@Override
				public void run() {
					if (!spinnerAcceleration.isDisposed()) {
						Vehicle vehicle = vehicleMap.get(vehicleId);
						if (vehicle != null) {
							currentAcc = vehicle.getCurrentAcc();
							currentSpeed = vehicle.getCurrentSpeed();

							if (!isCurrentlyControlling) {
								spinnerAcceleration
										.setMinimum((int) (vehicle.getLongitudinalControl().getLongitudinalModel().getModelData().getMaxDec()
												* Math.pow(10, spinnerAcceleration.getDigits())));
								spinnerAcceleration
										.setMaximum((int) (vehicle.getLongitudinalControl().getLongitudinalModel().getModelData().getMaxAcc()
												* Math.pow(10, spinnerAcceleration.getDigits())));
								spinnerAcceleration.setSelection((int) (currentAcc * Math.pow(10, spinnerAcceleration.getDigits())));
							}

							spinnerSpeed.setSelection((int) (currentSpeed * Math.pow(10, spinnerSpeed.getDigits())));
						}
					}
				}
			});
		}
	}

	@Override
	public void simulationStateChanged(SimulationModel model, SimulationState oldState, SimulationState newState) {
		if (newState == SimulationState.ABORTED || newState == SimulationState.COMPLETED || newState == SimulationState.ENDED) {
			reset();
		}
	}

	@Override
	public void timeStep(double dt, Date simulationTime, double simulationRunTime) {
		processVehicles();
	}

	private void processVehicles() {
		if (currentModel != null) {
			for (Vehicle vehicle : currentModel.getVehiclesInSimulation(false)) {
				if (vehicle.getAbsolutePosition() != null) {

					long vehicleId = vehicle.getUniqueId();

					if (!vehicleMap.containsKey(vehicleId)) {
						idLabelMapping.put(vehicleId, vehicle.getLabel());
						labelIdMapping.put(vehicle.getLabel(), vehicleId);
						vehicleMap.put(vehicleId, vehicle);
						vehicle.addVehicleListener(this);

						getDisplay().asyncExec(new Runnable() {
							@Override
							public void run() {
								if (!cmbVehicles.isDisposed()) {
									cmbVehicles.add(vehicle.getLabel());
								}
							}
						});
					}
				}
			}

			updateControllerUI();
			vehicleDataChanged(currentVehicleId);
		}
	}

	@Override
	public void vehicleLeftSimulation(Vehicle v) {
		v.removeVehicleListener(this);
		long vehicleId = v.getUniqueId();

		if (vehicleMap.containsKey(vehicleId)) {
			// Remove control from previously selected vehicle
			idLabelMapping.remove(vehicleId);
			labelIdMapping.remove(v.getLabel());
			vehicleMap.remove(vehicleId);

			getDisplay().syncExec(new Runnable() {
				@Override
				public void run() {
					boolean doChange = false;

					// Change to another vehicle in case the currently selected vehicle is removed from the simulation
					if (!cmbVehicles.isDisposed()) {
						if (cmbVehicles.getText().compareTo(v.getLabel()) == 0) {
							doChange = true;
						}

						cmbVehicles.remove(v.getLabel());

						if (StringUtil.isNotNullOrEmpty(cmbVehicles.getText()) && doChange) {
							changeVehicle(cmbVehicles.getText(), labelIdMapping.get(cmbVehicles.getText()));
						}
					}
				}
			});

			updateControllerUI();
		}
	}

	private void reset() {
		for (Vehicle v : vehicleMap.values()) {
			v.removeVehicleListener(this);
		}
		vehicleMap.clear();
		labelIdMapping.clear();
		idLabelMapping.clear();

		getDisplay().asyncExec(new Runnable() {
			@Override
			public void run() {
				if (!cmbVehicles.isDisposed()) {
					cmbVehicles.removeAll();
					btnControlVehicle.setSelection(false);
					btnControlVehicle.setEnabled(false);
					btnFollowVehicle.setSelection(false);
					btnFollowVehicle.setEnabled(false);
					spinnerAcceleration.setSelection(0);
					spinnerAcceleration.setEnabled(false);
					spinnerSpeed.setSelection(0);
					spinnerSpeed.setEnabled(false);
					cmbVehicles.setEnabled(false);
					isCurrentlyControlling = false;
				}
			}
		});
	}
}
package at.fhhagenberg.mc.traffsim.statistics.events;

public interface IEventListener {
	public void newEvent(Event event);
}

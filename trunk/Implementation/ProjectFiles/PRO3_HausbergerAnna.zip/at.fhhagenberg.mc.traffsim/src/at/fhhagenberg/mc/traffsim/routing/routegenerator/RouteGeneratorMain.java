
package at.fhhagenberg.mc.traffsim.routing.routegenerator;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;

public class RouteGeneratorMain {
	/**
	 * Usage: index 0: configuration.xml index 1: number of routes to generate index 2: start interval in ms index 3 (optional): start date,
	 * in ms from 1/1/1970
	 *
	 * @param argv
	 */
	public static void main(String argv[]) {
		ArgumentDecoder decoder = new ArgumentDecoder(argv);
		String file = decoder.getValue("configuration");

		int nrRoutes = Integer.parseInt(decoder.getValue("numRoutes", "0"));
		int startInterval = Integer.parseInt(decoder.getValue("startInterval", "500"));

		Date startDate = new Date(Long.parseLong(decoder.getValue("startDate", new Date().getTime() + "")));
		List<Long> startIds = decoder.getValueAsList("startSegmentIds", ",");
		List<Long> endIds = decoder.getValueAsList("endSegmentIds", ",");

		File f = new File(file);

		if (!f.exists()) {
			Logger.logError("Given configuration file does not exist.");
			return;
		}

		List<VehicleAttributes> atts = new ArrayList<>();
		atts.add(new VehicleAttributes(VehicleType.CAR, 2, 1.74, 4.15, 1, -1, "IDM1", "MOBIL1", "MEMORY1", "Diesel_90kw"));
		RouteGenerator gen = new RouteGenerator(f, false, false, nrRoutes, startInterval, startDate, atts, startIds, endIds);
		gen.generateAndSave(false);
	}

}

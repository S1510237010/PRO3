package at.fhhagenberg.mc.traffsim.changes;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("changeSets")
public class ChangeSetList {
	@XStreamImplicit
	private List<ChangeSet> changeSetList;
	@XStreamAsAttribute
	private String buildNumber;
	@XStreamAsAttribute
	private String buildId;
	@XStreamAsAttribute
	@Deprecated
	private String svnRevision;
	@XStreamAsAttribute
	private String scmRevision;

	public List<ChangeSet> getChangeSetList() {
		return changeSetList;
	}

	public void setChangeSetList(List<ChangeSet> changeSetList) {
		this.changeSetList = changeSetList;
	}

	public String getBuildId() {
		return buildId;
	}

	public void setBuildId(String buildId) {
		this.buildId = buildId;
	}

	public String getSvnRevision() {
		return svnRevision;
	}

	public void setSvnRevision(String svnRevision) {
		this.svnRevision = svnRevision;
	}

	public String getBuildNumber() {
		return buildNumber;
	}

	public void setBuildNumber(String buildNumber) {
		this.buildNumber = buildNumber;
	}

	public String getScmRevision() {
		return scmRevision;
	}

	public void setScmRevision(String scmRevision) {
		this.scmRevision = scmRevision;
	}
}

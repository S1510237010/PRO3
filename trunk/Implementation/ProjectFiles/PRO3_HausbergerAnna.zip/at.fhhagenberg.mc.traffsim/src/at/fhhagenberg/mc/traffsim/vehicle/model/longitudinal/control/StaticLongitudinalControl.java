package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;

public class StaticLongitudinalControl extends LongitudinalControl<ILongitudinalModel> {

	public StaticLongitudinalControl() {

	}

	public StaticLongitudinalControl(String identifier) {
		super(identifier);
	}

	@Override
	protected double calcAccCustom(Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA) {
		return 0;
	}

	@Override
	public double calcAccSolitary(Vehicle me, VehiclesLane lane) {
		return 0;
	}

	@Override
	public double calcAccSolitary(Vehicle me, VehiclesLane seg, int lookForward, Vehicle virtualFront, double virtualFrontDistance) {
		return 0;
	}

	@Override
	public double calcAccComprehensive(Vehicle me, double alphaT, double alphaV0, double alphaA) {
		return 0;
	}
}

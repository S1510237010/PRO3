package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfigurationDialog;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public abstract class ModelConfigurationPage extends WizardPage {

	protected TableViewer viewer;
	protected Table table;

	protected Button btnAppend;
	protected Button btnAdd;
	protected Button btnAddStochastically;
	protected Button btnRemove;

	protected List<AbstractBean> modelSet;
	protected List<AbstractBean> modelBeans;

	// Input
	protected Label lblIdentifier;
	protected Label lblFullname;
	protected Text txtIdentifier;
	protected Text txtFullName;

	// General composits
	protected Composite container;
	protected Group grpSetOverview;
	protected Group grpGeneral;
	protected Group grpButtons;
	protected Group grpModelParameters;

	// List of properties
	protected List<ModelProperty> modelProperties;

	// Property / input control mapping
	protected HashMap<ModelProperty, Control> controlMapping;

	protected ModelConfigurationPage(String pageName) {
		super(pageName);
		setPageComplete(true);
		setDescription("Configure model parameters");
		setTitle("Model Configuration");

		modelProperties = new ArrayList<ModelProperty>();
		controlMapping = new HashMap<ModelProperty, Control>();
	}

	protected Class<? extends AbstractBean> getModelClass() {
		return ModelBean.class;
	}

	@Override
	public void createControl(Composite parent) {
		container = new Composite(parent, SWT.NULL);
		container.setLayout(new GridLayout(4, false));

		grpSetOverview = new Group(container, SWT.NONE);
		grpSetOverview.setLayout(new FillLayout(SWT.HORIZONTAL));
		GridData overviewData = new GridData(SWT.FILL, SWT.FILL, true, false, 4, 1);
		overviewData.heightHint = 150;
		grpSetOverview.setLayoutData(overviewData);
		grpSetOverview.setText("Overview");

		viewer = new TableViewer(grpSetOverview, SWT.BORDER | SWT.FULL_SELECTION);
		viewer.addSelectionChangedListener(new ISelectionChangedListener() {

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				onTableViewerSelectionChanged();
			}
		});

		table = viewer.getTable();
		table.setHeaderVisible(true);

		grpGeneral = new Group(container, SWT.NONE);
		grpGeneral.setLayout(new GridLayout(2, false));
		grpGeneral.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 3, 1));
		grpGeneral.setText("General");

		lblIdentifier = new Label(grpGeneral, SWT.NONE);
		lblIdentifier.setText("Identifier");

		txtIdentifier = new Text(grpGeneral, SWT.BORDER);
		txtIdentifier.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtIdentifier.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		lblFullname = new Label(grpGeneral, SWT.NONE);
		lblFullname.setText("Full Name");

		txtFullName = new Text(grpGeneral, SWT.BORDER);
		txtFullName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtFullName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		grpButtons = new Group(container, SWT.NONE);
		grpButtons.setLayout(new GridLayout(1, false));
		grpButtons.setLayoutData(new GridData(SWT.RIGHT, SWT.TOP, true, true, 1, 1));

		btnAdd = new Button(grpButtons, SWT.NONE);
		btnAdd.setText("Add model");
		btnAdd.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, true, false, 1, 1));
		btnAdd.setToolTipText("Adds a new model instance to the list using the provided parameter configuration");
		btnAdd.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				addModelToList();
				viewer.refresh();
				txtIdentifier.setText("");
				txtFullName.setText("");
				txtIdentifier.setFocus();
				validatePage();
				getWizard().getContainer().updateButtons();
			}
		});

		btnAddStochastically = new Button(grpButtons, SWT.NONE);
		btnAddStochastically.setText("Add model(s) stochastically");
		btnAddStochastically.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, true, false, 1, 1));
		btnAddStochastically.setToolTipText(
				"Adds one or multiple models to the list automatically considering the provided parameter configuration and statistical distributions");
		btnAddStochastically.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				showDistributionConfigurationDialog();
			}
		});

		btnRemove = new Button(grpButtons, SWT.NONE);
		btnRemove.setText("Remove model");
		btnRemove.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 1, 1));
		btnRemove.setToolTipText("Removes the selected model from the list");
		btnRemove.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				removeModelFromList();
				viewer.refresh();
				validatePage();
				getWizard().getContainer().updateButtons();
			}
		});

		grpModelParameters = new Group(container, SWT.NONE);
		GridLayout gl_grpMobil = new GridLayout(8, false);
		gl_grpMobil.horizontalSpacing = 10;
		grpModelParameters.setLayout(gl_grpMobil);
		grpModelParameters.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, true, 4, 1));
		grpModelParameters.setText("Model parameters");

		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		btnAppend = new Button(container, SWT.CHECK);
		btnAppend.setText(
				"Overwrite existing model configuration. Otherwise the newly added models will be appended to the configuration file.");
		btnAppend.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, true, false, 4, 1));

		setControl(container);

		validatePage();

		modelSet = new ArrayList<AbstractBean>();
		viewer.setContentProvider(new ArrayContentProvider());
		viewer.setInput(modelSet);
	}

	protected void onTableViewerSelectionChanged() {
		if (((IStructuredSelection) viewer.getSelection()).getFirstElement() != null) {
			btnRemove.setEnabled(true);
		} else {
			btnRemove.setEnabled(false);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {

			String modelIdentifier = ((ModelSelectionPage) getWizard().getPage(ModelGeneratorWizard.PAGE_MODEL_SELECTION))
					.getSelectedModelIdentifier();

			if (((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier() == null
					|| modelIdentifier.compareTo(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier()) != 0) {
				table.setRedraw(false);
				modelSet.clear();
				clearTableViewerColumns(viewer);
				createColumns(viewer, modelIdentifier);
				table.setRedraw(true);
				btnRemove.setEnabled(false);
				txtIdentifier.setText("");
				txtFullName.setText("");
				viewer.refresh();
			}

			((ModelGeneratorWizard) getWizard()).setPreviousModelIdentifier(modelIdentifier);

			// Load existing configuration
			try {
				DataSerializer ser = new DataSerializer();
				ser.readConfiguration(
						((ModelSelectionPage) getWizard().getPage(ModelGeneratorWizard.PAGE_MODEL_SELECTION)).getConfigFile());
				modelBeans = (List<AbstractBean>) ser.readData(getModelClass());
			} catch (Exception exc) {
				setErrorMessage("Models couldn't be loaded. Ensure that the configuration file is not corrupt.");
				getWizard().getContainer().updateButtons();
				return;
			}

			validatePage();
		}

	}

	protected boolean isAddPossible() {
		return true;
	}

	@Override
	public boolean canFlipToNextPage() {
		return false;
	}

	@Override
	public boolean isPageComplete() {
		return modelSet != null && !modelSet.isEmpty();
	}

	public List<AbstractBean> getModelSet() {
		return modelSet;
	}

	public List<AbstractBean> getExistingModels() {
		return modelBeans;
	}

	public boolean performOverride() {
		return btnAppend.getSelection();
	}

	protected void validatePage() {
		StringBuilder sb = new StringBuilder();

		if (StringUtil.isNullOrEmpty(txtIdentifier.getText())) {
			sb.append(" Model identifier must not be empty.\n");
		} else {
			boolean isValidIdentifier = true;

			if (modelBeans != null) {
				for (AbstractBean bean : modelBeans) {
					if (bean instanceof ModelBean) {
						if (((ModelBean) bean).getModelIdentifier().toLowerCase().compareTo(txtIdentifier.getText().toLowerCase()) == 0) {
							sb.append(" The given model identifier is invalid. A model with the same identifier exists already.\n");
							isValidIdentifier = false;
							break;
						}
					}
				}
			}

			if (isValidIdentifier && modelSet != null && !modelSet.isEmpty()) {
				for (AbstractBean bean : modelSet) {
					if (bean instanceof ModelBean) {
						if (((ModelBean) bean).getModelIdentifier().toLowerCase().compareTo(txtIdentifier.getText().toLowerCase()) == 0) {
							sb.append(" The given model identifier is invalid. A model with the same identifier already exists.\n");
							isValidIdentifier = false;
							break;
						}
					}
				}
			}
		}

		if (StringUtil.isNullOrEmpty(txtFullName.getText())) {
			sb.append("  Model name must not be empty.\n");
		}

		btnAddStochastically.setEnabled(isAddPossible());

		if (sb.length() == 0) {
			setErrorMessage(null);
			btnAdd.setEnabled(isAddPossible());
		} else {
			setErrorMessage(sb.toString());
			btnAdd.setEnabled(false);
		}
	}

	protected TableViewerColumn createTableViewerColumn(String title, int width) {
		final TableViewerColumn viewerColumn = new TableViewerColumn(viewer, SWT.NONE);
		final TableColumn column = viewerColumn.getColumn();
		column.setText(title);
		column.setWidth(width);
		column.setResizable(true);
		column.setMoveable(true);
		return viewerColumn;
	}

	protected void clearTableViewerColumns(TableViewer tv) {
		while (tv.getTable().getColumnCount() > 0) {
			table.getColumns()[0].dispose();
		}
	}

	protected void showDistributionConfigurationDialog() {
		DistributionConfigurationDialog dialog = new DistributionConfigurationDialog(getShell(), modelProperties);
		dialog.create();

		if (dialog.open() == Window.OK) {
			int numModels = dialog.getNumModels();
			HashMap<ModelProperty, DistributionConfig> propertyConfiguration = dialog.getPropertyConfiguration();
			generateModels(numModels, propertyConfiguration);
			viewer.refresh();
			getWizard().getContainer().updateButtons();
			txtIdentifier.setText("");
			txtFullName.setText("");
			txtIdentifier.setFocus();
			validatePage();
		}
	}

	protected abstract void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration);

	protected abstract void addModelToList();

	protected void removeModelFromList() {
		if (modelSet != null && !modelSet.isEmpty()) {
			modelSet.remove(((IStructuredSelection) viewer.getSelection()).getFirstElement());
		}
	}

	protected abstract void createColumns(TableViewer tv, String modelIdentifier);
}

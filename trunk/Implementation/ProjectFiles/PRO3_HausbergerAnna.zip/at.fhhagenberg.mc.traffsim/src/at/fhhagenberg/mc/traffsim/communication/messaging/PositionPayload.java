package at.fhhagenberg.mc.traffsim.communication.messaging;

import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;

public class PositionPayload extends MessagePayload {

	Location position;
	VehiclesLane lane;

	/**
	 * @param pos
	 *            absolute position
	 * @param lane
	 *            additional information
	 */
	public PositionPayload(Location pos, VehiclesLane lane) {
		this.position = pos;
		this.lane = lane;
	}

	@Override
	public int getSize() {
		return Double.SIZE / 8 * 2;
	}

	public Location getPosition() {
		return position;
	}

	public VehiclesLane getLane() {
		return lane;
	}
}

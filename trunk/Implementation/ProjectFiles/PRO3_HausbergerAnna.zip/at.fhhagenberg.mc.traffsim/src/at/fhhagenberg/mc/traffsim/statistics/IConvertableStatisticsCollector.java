package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.IOException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

public interface IConvertableStatisticsCollector {

	IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException;

}
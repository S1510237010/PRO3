package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.AbstractModel;

public abstract class LaneChangeModel extends AbstractModel {
	protected String identifier, fullname;
	protected Vehicle me;

	public LaneChangeModel(String identifier) {
		this.identifier = identifier;
	}

	public LaneChangeModel() {
	}

	public abstract LaneChangeDecision makeDecision();

	public Vehicle getVehicle() {
		return me;
	}

	public void setVehicle(Vehicle me) {
		this.me = me;
	}

	public String getFullname() {
		return fullname;
	}

	public String getIdentifier() {
		return identifier;
	}

	@Override
	public String getName() {
		return identifier + (fullname == null ? "" : " (" + fullname + ")");
	}

	public abstract LaneChangeModel copyForVehicle(Vehicle v);

}
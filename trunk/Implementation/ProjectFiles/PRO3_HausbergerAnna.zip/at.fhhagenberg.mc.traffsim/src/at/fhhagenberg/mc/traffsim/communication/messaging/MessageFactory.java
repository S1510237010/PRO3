package at.fhhagenberg.mc.traffsim.communication.messaging;

import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;

public class MessageFactory {
	public static Message<RoutePayload> createRouteMessage(Location origin, IRoute route, VehiclesLane lane) {
		return new Message<RoutePayload>(origin, new RoutePayload(origin, new Route(route), lane));
	}

	public static Message<RoutePayload> createRouteMessage(Location origin, IRoute route, VehiclesLane lane, Object meta) {
		return new Message<RoutePayload>(origin, new RoutePayload(origin, new Route(route), lane), meta);
	}

	public static Message<PositionPayload> createPositionMessage(Location origin, Location newPos, VehiclesLane lane) {
		return new Message<PositionPayload>(origin, new PositionPayload(newPos, lane));
	}

	public static Message<?> createInitialMessage(Vector origin, RoadSegment initialSegment, RoadSegment targetSegment) {
		return new Message<InitialPayload>(origin, new InitialPayload(initialSegment, targetSegment));
	}

	public static Message<?> createVehicleDataMessage(Vector origin, Location newPos, double speed, double frontPosition, VehiclesLane lane) {
		return new Message<VehicleDataPayload>(origin, new VehicleDataPayload(newPos, speed, frontPosition, lane));
	}
}

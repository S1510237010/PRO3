package at.fhhagenberg.mc.traffsim.model.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.eclipse.core.runtime.NullProgressMonitor;

import at.fhhagenberg.mc.traffsim.data.DataLoader;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.init.ParameterKeyComparator;
import at.fhhagenberg.mc.traffsim.model.init.ParameterParser;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * This class represents a scheduled simulation, which can EITHER be a fully loaded {@link SimulationModel}, or a combination of
 * configurationfile and identifier of a parameter set
 *
 * @author Christian Backfrieder
 *
 */
public final class ScheduledSimulation {
	private SimulationModel model;

	private File configurationFile;
	private String parameterSetKey;

	private String labelPrefix;

	private DataLoader loader;

	private String labelSuffix;

	private Set<ISimulationStateListener> simulationStateListeners;

	public ScheduledSimulation(SimulationModel model) {
		this.model = model;
		parameterSetKey = model.getParameterSetLabel();
	}

	public ScheduledSimulation(SimulationModel model, String labelPrefix) {
		this.model = model;
		this.labelPrefix = labelPrefix;
	}

	public ScheduledSimulation(File config, String parameterSetKey, DataLoader loader) {
		this.configurationFile = config;
		this.parameterSetKey = parameterSetKey;
		this.loader = loader;
	}

	public static List<ScheduledSimulation> pack(List<SimulationModel> models) {
		List<ScheduledSimulation> simulations = new ArrayList<>();
		for (SimulationModel s : models) {
			simulations.add(new ScheduledSimulation(s));
		}
		return simulations;
	}

	public DataLoader getLoader() {
		return loader;
	}

	public static List<ScheduledSimulation> pack(File configurationFile) {

		List<ScheduledSimulation> simulations = new ArrayList<>();

		DataLoader loader = new DataLoader();
		try {
			loader.loadParameters(configurationFile, new NullProgressMonitor());
		} catch (LoadingException e) {
			Logger.logError("Could not load parameters from configuration " + configurationFile);
			return simulations;
		}

		SortedSet<String> sortedParameterKeys = new TreeSet<>(new ParameterKeyComparator());
		sortedParameterKeys.addAll(ParameterParser.getSimulationParameterSets(loader.getParameterBeans()).keySet());

		for (String paramKey : sortedParameterKeys) {
			simulations.add(new ScheduledSimulation(configurationFile, paramKey, new DataLoader(loader)));
		}

		return simulations;
	}

	public File getConfigurationFile() {
		return configurationFile != null ? configurationFile : (model != null ? model.getInputFile() : null);
	}

	public SimulationModel getModel() {
		return model;
	}

	public String getParameterSetKey() {
		return parameterSetKey != null ? parameterSetKey : (model != null ? model.getParameterSetLabel() : null);
	}

	public boolean hasModel() {
		return model != null;
	}

	@Override
	public String toString() {
		return StringUtil.ensureNotNull(labelPrefix) + StringUtil.ensureNotNull(parameterSetKey)
				+ (model != null ? (" | " + model.getUniqueId()) : "") + StringUtil.ensureNotNull(labelSuffix)
				+ (configurationFile != null ? "   -   config. " + configurationFile.getAbsolutePath() : "");
	}

	public void setLabelPrefix(String labelPrefix) {
		this.labelPrefix = labelPrefix;
	}

	public void setLabelSuffix(String labelSuffix) {
		this.labelSuffix = labelSuffix;
	}

	public void setLoader(DataLoader loader) {
		this.loader = loader;
	}

	public void setConfigurationFile(File configurationFile) {
		this.configurationFile = configurationFile;
	}

	public void setModel(SimulationModel model) {
		this.model = model;
	}

	public Set<ISimulationStateListener> getSimulationStateListeners() {
		return simulationStateListeners;
	}

	public void setSimulationStateListeners(Set<ISimulationStateListener> simulationStateListeners) {
		this.simulationStateListeners = simulationStateListeners;
	}
}
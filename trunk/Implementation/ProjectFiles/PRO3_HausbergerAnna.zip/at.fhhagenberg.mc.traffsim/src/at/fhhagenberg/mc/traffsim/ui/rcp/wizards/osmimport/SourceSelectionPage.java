package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.osmimport;

import java.io.File;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import org.jdesktop.swingx.mapviewer.GeoPosition;

import com.thoughtworks.xstream.XStreamException;

import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.osm.OSMMapViewer;
import at.fhhagenberg.mc.traffsim.ui.osm.OSMMapViewer.IMapViewerListener;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class SourceSelectionPage extends WizardPage implements IResultProvider {
	private Text textFilePath;
	private Text textLatitudeMax;
	private Text textLatitudeMin;
	private Text textLongitudeMax;
	private Text textLongitudeMin;
	private StackLayout stackLayout;
	private Group grpFileSelection;
	private Group grpCoordinates;
	protected String fileFilter = Constants.FILE_FILTER_TRAFFSIM_XML;
	private Composite compositeDetails;
	protected String filterName = Constants.FILTER_NAME_TRAFFSIM;
	private Button btnTraffsimConfiguration;
	private Button btnSelectionOnMap;
	private Button btnOsmFilexml;
	private Composite compositeTraffsimInfo;
	private TraffSimConfiguration resultConfiguration;
	private boolean mustLoadOnline;
	private String selectedFilePath;

	class NumberKeyAdapter extends KeyAdapter {
		private final Text widget;

		public NumberKeyAdapter(Text widget) {
			this.widget = widget;
		}

		@Override
		public void keyReleased(KeyEvent e) {
			getContainer().getShell().getDisplay().asyncExec(new Runnable() {
				public void run() {
					final String current = widget.getText();
					int caret = widget.getCaretPosition();
					final String newStr = widget.getText().replaceAll("[^\\d\\.\\,]", "");
					if (!current.equals(newStr)) {
						widget.setText(newStr);
						widget.setSelection(caret - 1, caret - 1);
					}
				}
			});

		}
	}

	/**
	 * Create the wizard.
	 */
	public SourceSelectionPage() {
		super("OSM Import");
		setTitle("Network Source Selection");
		setDescription("Choose from where to import the road network data");
	}

	/**
	 * Create contents of the wizard.
	 * 
	 * @param parent
	 */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);

		setControl(container);
		container.setLayout(new GridLayout(1, false));

		Group grpRoadNetworkSource = new Group(container, SWT.NONE);
		grpRoadNetworkSource.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		grpRoadNetworkSource.setText("Road network source");
		grpRoadNetworkSource.setLayout(new GridLayout(1, false));

		btnTraffsimConfiguration = new Button(grpRoadNetworkSource, SWT.RADIO);
		btnTraffsimConfiguration.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stackLayout.topControl = grpFileSelection;
				compositeDetails.layout();
				fileFilter = Constants.FILE_FILTER_TRAFFSIM_XML;
				filterName = Constants.FILTER_NAME_TRAFFSIM;
				getWizard().getContainer().updateButtons();
			}
		});

		btnTraffsimConfiguration.setSelection(true);
		btnTraffsimConfiguration.setText("OSM from TraffSim configuration");

		btnOsmFilexml = new Button(grpRoadNetworkSource, SWT.RADIO);
		btnOsmFilexml.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stackLayout.topControl = grpFileSelection;
				compositeDetails.layout();
				fileFilter = Constants.FILE_FILTER_OSM;
				filterName = Constants.FILTER_NAME_OSM;
				getWizard().getContainer().updateButtons();
			}
		});
		btnOsmFilexml.setText("Raw OSM file (XML, PBF)");

		btnSelectionOnMap = new Button(grpRoadNetworkSource, SWT.RADIO);
		btnSelectionOnMap.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				stackLayout.topControl = grpCoordinates;
				compositeDetails.layout();
				validatePage();
			}
		});
		btnSelectionOnMap.setText("Selection on OSM map view");

		compositeDetails = new Composite(container, SWT.NONE);
		compositeDetails.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		stackLayout = new StackLayout();
		compositeDetails.setLayout(stackLayout);

		grpFileSelection = new Group(compositeDetails, SWT.NONE);
		grpFileSelection.setLayout(new GridLayout(2, false));
		grpFileSelection.setText("File selection");
		stackLayout.topControl = grpFileSelection;
		compositeDetails.layout();

		textFilePath = new Text(grpFileSelection, SWT.BORDER);
		textFilePath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textFilePath.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		Button btnBrowse = new Button(grpFileSelection, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(Display.getCurrent().getActiveShell());
				dialog.setText("Open");
				dialog.setFilterExtensions(new String[] { fileFilter });
				dialog.setFilterNames(new String[] { filterName });
				String selected = dialog.open();
				textFilePath.setText(selected);
				validatePage();
			}
		});
		btnBrowse.setText("Browse ...");

		compositeTraffsimInfo = new Composite(grpFileSelection, SWT.NONE);
		compositeTraffsimInfo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true, 2, 1));

		grpCoordinates = new Group(compositeDetails, SWT.NONE);
		grpCoordinates.setText("Coordinates");
		grpCoordinates.setLayout(new GridLayout(2, false));

		Composite compositeLatLonArea = new Composite(grpCoordinates, SWT.NONE);
		compositeLatLonArea.setLayout(new GridLayout(5, false));
		new Label(compositeLatLonArea, SWT.NONE);

		Label lblLongitudeMax = new Label(compositeLatLonArea, SWT.NONE);
		lblLongitudeMax.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.ITALIC));
		lblLongitudeMax.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 3, 1));
		lblLongitudeMax.setText("Latitude max.");
		new Label(compositeLatLonArea, SWT.NONE);

		Label lblLatitude = new Label(compositeLatLonArea, SWT.WRAP | SWT.CENTER);
		lblLatitude.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.ITALIC));
		lblLatitude.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 2));
		lblLatitude.setText("Longitude\nmin.");

		textLongitudeMin = new Text(compositeLatLonArea, SWT.BORDER);
		textLongitudeMin.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 2));
		textLongitudeMin.addKeyListener(new NumberKeyAdapter(textLongitudeMin));
		textLongitudeMin.setText(String.format("%.4f", PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LON_MIN)));

		textLatitudeMax = new Text(compositeLatLonArea, SWT.BORDER);
		textLatitudeMax.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		textLatitudeMax.addKeyListener(new NumberKeyAdapter(textLatitudeMax));
		textLatitudeMax.setText(String.format("%.4f", PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LAT_MAX)));

		textLongitudeMax = new Text(compositeLatLonArea, SWT.BORDER);
		textLongitudeMax.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 2));
		textLongitudeMax.addKeyListener(new NumberKeyAdapter(textLongitudeMax));
		textLongitudeMax.setText(String.format("%.4f", PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LON_MAX)));

		Label lblLatitudeMax = new Label(compositeLatLonArea, SWT.WRAP | SWT.CENTER);
		lblLatitudeMax.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.ITALIC));
		lblLatitudeMax.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 2));
		lblLatitudeMax.setText("Longitude\r\nmax.");

		textLatitudeMin = new Text(compositeLatLonArea, SWT.BORDER);
		textLatitudeMin.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textLatitudeMin.addKeyListener(new NumberKeyAdapter(textLatitudeMin));
		textLatitudeMin.setText(String.format("%.4f", PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LAT_MIN)));
		new Label(compositeLatLonArea, SWT.NONE);

		Label lblLongitudeMin = new Label(compositeLatLonArea, SWT.NONE);
		lblLongitudeMin.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.ITALIC));
		lblLongitudeMin.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 3, 1));
		lblLongitudeMin.setText("Latitude min.");
		new Label(compositeLatLonArea, SWT.NONE);

		Button btnSelectOnMap = new Button(grpCoordinates, SWT.NONE);
		btnSelectOnMap.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				double minLat = Double.parseDouble(textLatitudeMin.getText());
				double minLon = Double.parseDouble(textLongitudeMin.getText());
				double maxLat = Double.parseDouble(textLatitudeMax.getText());
				double maxLon = Double.parseDouble(textLongitudeMax.getText());

				GeoPosition mapCenter = new GeoPosition((minLat + maxLat) / 2, (minLon + maxLon) / 2);
				double[] bounds = new double[] { minLat, minLon, maxLat, maxLon };
				new OSMMapViewer(new IMapViewerListener() {

					@Override
					public void mapViewClosed(final double[] result) {
						Display.getDefault().asyncExec(new Runnable() {

							@Override
							public void run() {
								textLatitudeMin.setText(String.format("%.4f", result[0]));
								textLongitudeMin.setText(String.format("%.4f", result[1]));
								textLatitudeMax.setText(String.format("%.4f", result[2]));
								textLongitudeMax.setText(String.format("%.4f", result[3]));
								PreferenceUtil.setDouble(IPreferenceConstants.SELECTION_COORD_LAT_MIN, result[0]);
								PreferenceUtil.setDouble(IPreferenceConstants.SELECTION_COORD_LON_MIN, result[1]);
								PreferenceUtil.setDouble(IPreferenceConstants.SELECTION_COORD_LAT_MAX, result[2]);
								PreferenceUtil.setDouble(IPreferenceConstants.SELECTION_COORD_LON_MAX, result[3]);
							}
						});
					}
				}, mapCenter, bounds);

			}
		});
		btnSelectOnMap.setText("Open Map View");

		validatePage();
	}

	protected void validatePage() {
		try {
			if (!btnSelectionOnMap.getSelection()) {
				File f = new File(textFilePath.getText());
				if (!f.exists()) {
					error("Selected file does not exist");
					return;
				}
				if (btnTraffsimConfiguration.getSelection()) {
					DataSerializer ser = new DataSerializer();
					try {
						ser.readConfiguration(f);
					} catch (XStreamException e) {
						error("Selected file is not valid. \n" + e.getMessage());
						return;
					}
					File osmFile = new File(ser.getConfigurationDirectory(), ser.getConfiguration().getOsmNetworkFile());
					if (!osmFile.exists()) {
						error("Referenced OSM file does not exist");
						return;
					}
					resultConfiguration = ser.getConfiguration();
					if (getNextPage() != null) {
						((ConfigurationSelectionPage) getNextPage()).setFiles(resultConfiguration.getOsmNetworkFile(),
								resultConfiguration.getGraphFile(), resultConfiguration.getConfigurationFile().getParent());
					}
				} else if (btnOsmFilexml.getSelection()) {
					String osmFileName = new File(textFilePath.getText()).getName();
					((ConfigurationSelectionPage) getNextPage()).setFiles(osmFileName, StringUtil.removeFileExtension(osmFileName) + ".gph",
							new File(textFilePath.getText()).getParent());
				}
			}
			selectedFilePath = textFilePath.getText();
			setErrorMessage(null);
		} finally {
			if (getWizard().getContainer().getCurrentPage() != null) {
				getWizard().getContainer().updateButtons();
			}
			mustLoadOnline = btnSelectionOnMap.getSelection();
		}
	}

	private void error(String str) {
		setErrorMessage(str);
		resultConfiguration = null;
	}

	@Override
	public boolean canFlipToNextPage() {
		return StringUtil.isNullOrEmpty(getErrorMessage()) && !btnTraffsimConfiguration.getSelection();
	}

	@Override
	public IWizardPage getNextPage() {
		if (btnTraffsimConfiguration.getSelection()) {
			return null;
		}
		return super.getNextPage();
	}

	@Override
	public boolean isPageComplete() {
		return StringUtil.isNullOrEmpty(getErrorMessage()) && btnTraffsimConfiguration.getSelection();
	}

	@Override
	public TraffSimConfiguration getResult() {
		return resultConfiguration;
	}

	public boolean mustLoadFromOsmOnline() {
		return mustLoadOnline;
	}

	public String getSelectedFilePath() {
		return selectedFilePath;
	}

}

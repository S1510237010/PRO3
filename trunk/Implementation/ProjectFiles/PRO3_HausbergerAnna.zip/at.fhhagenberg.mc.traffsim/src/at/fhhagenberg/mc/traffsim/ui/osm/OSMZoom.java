package at.fhhagenberg.mc.traffsim.ui.osm;

public final class OSMZoom {
	public static final long LEVEL_0 = 500 * 10 ^ 6;
	public static final long LEVEL_1 = 250 * 10 ^ 6;
	public static final long LEVEL_2 = 150 * 10 ^ 6;
	public static final long LEVEL_3 = 70 * 10 ^ 6;
	public static final long LEVEL_4 = 35 * 10 ^ 6;
	public static final long LEVEL_5 = 15 * 10 ^ 6;
	public static final long LEVEL_6 = 10 * 10 ^ 6;
	public static final long LEVEL_7 = 4 * 10 ^ 6;
	public static final long LEVEL_8 = 2 * 10 ^ 6;
	public static final long LEVEL_9 = 1 * 10 ^ 6;
	public static final long LEVEL_10 = 500000;
	public static final long LEVEL_11 = 250000;
	public static final long LEVEL_12 = 150000;
	public static final long LEVEL_13 = 70000;
	public static final long LEVEL_14 = 35000;
	public static final long LEVEL_15 = 15000;
	public static final long LEVEL_16 = 8000;
	public static final long LEVEL_17 = 4000;
	public static final long LEVEL_18 = 2000;
	public static final long LEVEL_19 = 1000;

	public static final int SCALE_LEVEL1_OSM = 1507;
	public static final int SCALE_LEVEL1_BING = SCALE_LEVEL1_OSM;

	public static final long[] LEVELS = new long[] { LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4, LEVEL_5, LEVEL_6, LEVEL_7, LEVEL_8,
			LEVEL_9, LEVEL_10, LEVEL_11, LEVEL_12, LEVEL_13, LEVEL_14, LEVEL_15, LEVEL_16, LEVEL_17, LEVEL_18, LEVEL_19 };
	public static long[] SCALES_OSM = createScales(SCALE_LEVEL1_OSM);
	public static long[] SCALES_BING = createScales(SCALE_LEVEL1_BING);
	public static long[] SCALES_BING_SAT = SCALES_BING;// assignIndex(createScales(SCALE_LEVEL1_BING), 0, 1);

	public OSMZoom() {
		SCALES_BING_SAT[0] = SCALES_BING_SAT[1];
	}

	private static final long[] createScales(int scaleLevel1) {
		return new long[] { scaleLevel1 / 2, scaleLevel1, scaleLevel1 * 2, scaleLevel1 * 4, scaleLevel1 * 8, scaleLevel1 * 16,
				scaleLevel1 * 32, scaleLevel1 * 64, scaleLevel1 * 128, scaleLevel1 * 256, scaleLevel1 * 512, scaleLevel1 * 1024,
				scaleLevel1 * 2048, scaleLevel1 * 4096, scaleLevel1 * 8192, scaleLevel1 * 16384, scaleLevel1 * 32768, scaleLevel1 * 65536,
				scaleLevel1 * 131072 };
	}

}

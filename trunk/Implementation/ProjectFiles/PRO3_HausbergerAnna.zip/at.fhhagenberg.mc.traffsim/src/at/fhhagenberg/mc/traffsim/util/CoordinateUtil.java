package at.fhhagenberg.mc.traffsim.util;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import uk.me.jstott.jcoord.LatLng;
import uk.me.jstott.jcoord.UTMRef;

/**
 * Utility class providing helpful methods for coordinate transformations.
 *
 * @author Christian Backfrieder
 */
public class CoordinateUtil {

	/** The latitude zone character of the UTM coordinate system */
	private static char latZone = 'T';

	/** The longitude zone number of the UTM coordinate system */
	private static int lonZone = 33;

	/**
	 * Converts the given latitude-longitude pair into a UTM location.
	 *
	 * @param latitude
	 *            the latitude value
	 * @param longitude
	 *            the longitude value
	 * @return the converted UTM location
	 */
	public static Location toUTMCoordinate(double latitude, double longitude) {
		LatLng latlng = new LatLng(latitude, longitude);
		UTMRef utm = latlng.toUTMRef();
		latZone = utm.getLatZone();
		lonZone = utm.getLngZone();
		return new Location(utm.getEasting(), utm.getNorthing());
	}

	/**
	 * Converts the given list UTM locations into a list of WGS84 locations.
	 *
	 * @param utmLocations
	 *            the list of UTM locations to be converted
	 * @return the converted list of WGS64 locations
	 */
	public static List<Vector> toWGS84Coordinate(List<Vector> utmLocations) {
		List<Vector> result = new ArrayList<>();
		for (Location location : utmLocations) {
			result.add(new Vector(toWGS84Coordinate(location)));
		}
		return result;
	}

	/**
	 * Converts the given UTM coordinate into a WGS84 coordinate.
	 *
	 * @param utmCoordinate
	 *            the utm coordinate to be converted
	 * @return the converted WGS84 coordinate
	 */
	public static Location toWGS84Coordinate(Location utmCoordinate) {
		UTMRef utm = new UTMRef(utmCoordinate.x, utmCoordinate.y, latZone, lonZone);
		LatLng latlng = utm.toLatLng();
		return new Location(latlng.getLng(), latlng.getLat());
	}
}
package at.fhhagenberg.mc.traffsim.routing.routegenerator;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;

import at.fhhagenberg.mc.traffsim.data.DataLoader;
import at.fhhagenberg.mc.traffsim.data.TraffsimDefaultData;
import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleCommDataBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.routing.AbstractRouteService;
import at.fhhagenberg.mc.traffsim.routing.DefaultRouteService;
import at.fhhagenberg.mc.traffsim.routing.RoutingException;
import at.fhhagenberg.mc.traffsim.routing.SimpleRouteResult;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.FileUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class RouteGenerator {

	private File inputFile;
	private boolean appendToExistingConfig;
	private boolean useExistingRoutes;
	private int nrRoutes;
	private long maxRouteIndex;
	private int startInterval;
	private Date startDate;
	DataLoader loader = new DataLoader();
	private IProgressMonitor monitor;
	private Random randomGenerator;
	private List<VehicleAttributes> attributes;
	private ArrayList<VehicleBean> vehicles = new ArrayList<>();
	private ArrayList<RouteBean> routes = new ArrayList<>();
	private List<Long> startIds;
	private List<Long> endIds;

	// New file names
	private String configFileName;
	private String vehiclesFileName;
	private String routesFileName;
	private String outputFolderName;
	private ArrayList<VehicleCommDataBean> commData;
	private String commDataFileName;

	public RouteGenerator(File f, boolean appendToExistingConfig, boolean useExistingRoutes, int nrRoutes, int startInterval,
			Date startDate, List<VehicleAttributes> atts, List<Long> startIds, List<Long> endIds) {
		this(f, appendToExistingConfig, useExistingRoutes, nrRoutes, 0, startInterval, startDate, atts, startIds, endIds, -1, null, null,
				null, null, null, null, null);
	}

	public RouteGenerator(File f, boolean appendToExistingConfig, boolean useExistingRoutes, int nrRoutes, long maxRouteIndex,
			int startInterval, Date startDate, List<VehicleAttributes> atts, List<Long> startIds, List<Long> endIds, long randomSeed,
			String configFileName, String vehiclesFileName, String routesFileName, String parametersFileName, String commDataFilename,
			String outputFolderName, IProgressMonitor monitor) {
		this.inputFile = f;
		this.appendToExistingConfig = appendToExistingConfig;
		this.useExistingRoutes = useExistingRoutes;
		this.nrRoutes = nrRoutes;
		this.maxRouteIndex = maxRouteIndex;
		this.startInterval = startInterval;
		this.startDate = startDate;
		this.configFileName = configFileName;
		this.vehiclesFileName = vehiclesFileName;
		this.commDataFileName = commDataFilename;
		this.routesFileName = routesFileName;
		this.outputFolderName = outputFolderName;
		this.monitor = monitor;

		if (monitor == null) {
			this.monitor = new NullProgressMonitor();
		}

		this.attributes = atts;

		if (randomSeed != -1) {
			randomGenerator = new Random(randomSeed);
		} else {
			randomGenerator = new Random();
		}

		this.startIds = startIds;
		this.endIds = endIds;
	}

	/**
	 * Generate the routes given by the input parameters from constructor and save them
	 *
	 * @param updateMappings
	 *            flag to determine whether to updated configuration file mappings or not
	 */
	@SuppressWarnings("unchecked")
	public void generateAndSave(boolean updateMappings) {

		boolean updateMapping = updateMappings;

		// Create new configuration file if required
		if (configFileName != null && configFileName.compareTo(inputFile.getName()) != 0) {

			String confFile = FileUtil.copyFile(inputFile, configFileName);

			if (confFile == null) {
				Logger.logError("Could not copy/rename configuration files\n");
			} else {
				inputFile = new File(confFile);
				updateMapping = true;
			}
		}

		DataSerializer serializer = new DataSerializer();
		serializer.readConfiguration(inputFile);
		TraffSimConfiguration config = serializer.getConfiguration();
		config.setStartTime(startDate);

		// Update the output folder
		if (StringUtil.isNotNullOrEmpty(outputFolderName)) {
			config.setOutputFolder(outputFolderName);
		}

		serializer.setConfiguration(config);

		if (updateMapping && vehiclesFileName != null) {
			config.addOrUpdateBeanConfiguration(VehicleBean.class.getName(), vehiclesFileName);
		} else {
			if (!config.getBeanConfigurationsMapping().keySet().contains(VehicleBean.class.getName())) {
				config.addOrUpdateBeanConfiguration(VehicleBean.class.getName(), TraffsimDefaultData.VEHICLES_XML_NAME);
			}
		}

		if (updateMapping && commDataFileName != null) {
			config.addOrUpdateBeanConfiguration(VehicleCommDataBean.class.getName(), commDataFileName);
		} else {
			if (!config.getBeanConfigurationsMapping().keySet().contains(VehicleCommDataBean.class.getName())) {
				config.addOrUpdateBeanConfiguration(VehicleCommDataBean.class.getName(),
						TraffsimDefaultData.VEHICLE_COMMUNICATIONS_XML_NAME);
			}
		}

		if (updateMapping && routesFileName != null) {
			if (!useExistingRoutes) {
				config.addOrUpdateBeanConfiguration(RouteBean.class.getName(), routesFileName);
			}
		} else {
			if (!config.getBeanConfigurationsMapping().keySet().contains(RouteBean.class.getName())) {
				config.addOrUpdateBeanConfiguration(RouteBean.class.getName(), TraffsimDefaultData.ROUTES_XML_NAME);
			}
		}

		File graphFile = new File(serializer.getConfigurationDirectory(), serializer.getConfiguration().getGraphFile());

		List<VehicleBean> existingVehicles = new ArrayList<>();
		try {
			existingVehicles = (List<VehicleBean>) serializer.readData(VehicleBean.class);
		} catch (Exception e) {
			Logger.logWarn("Could not load existing vehicles, ignoring this and continuing");
		}

		if (!useExistingRoutes) {
			if (!updateMapping || (updateMapping && routesFileName.compareTo(TraffsimDefaultData.ROUTES_XML_NAME) == 0)) {
				serializer.clearData(RouteBean.class);
			}
		}

		if (!updateMapping || (updateMapping && vehiclesFileName.compareTo(TraffsimDefaultData.VEHICLES_XML_NAME) == 0)) {
			serializer.clearData(VehicleBean.class);
		}

		// add missing mappings

		Logger.logInfo("Generating...");
		generate(graphFile, existingVehicles);

		monitor.subTask("Generation finished. Writing vehicles...");
		serializer.writeConfiguration(inputFile);
		serializer.writeData(vehicles);

		if (!commData.isEmpty()) {
			serializer.writeData(commData);
		}

		monitor.worked(1);
		monitor.subTask("Writing routes...");
		serializer.writeData(routes);

		monitor.done();
		Logger.logInfo("Done. Exit.");
	}

	public void generate(File graph, List<VehicleBean> existingVehicles) {
		SimulationModel model;
		try {
			Properties options = new Properties();
			options.put(PropertyKeys.RESET_GEOMETRY, false);
			model = new SimulationModel("routeGeneratorModel");
			loader.loadBeans(inputFile, monitor);
			loader.loadConfiguration(model, monitor, options);
		} catch (LoadingException e) {
			Logger.logError("Could not load configuration\n", e);
			return;
		}

		monitor.beginTask("Creating routes", nrRoutes + 2);

		vehicles = new ArrayList<>();
		routes = new ArrayList<>();

		if (appendToExistingConfig && existingVehicles != null && !existingVehicles.isEmpty()) {
			vehicles.addAll(existingVehicles);
		}

		commData = new ArrayList<>();
		if (useExistingRoutes) {
			int index = 0;
			int routeIndex = 0;
			Date nextStartTime = startDate;

			while (index < nrRoutes) {
				VehicleAttributes usedAtts = getRandomAttributes(attributes);

				if (routeIndex > maxRouteIndex) {
					routeIndex = 0;
				}

				VehicleBean vb = createVehicleBean(usedAtts, index, routeIndex);
				nextStartTime = new Date(nextStartTime.getTime() + startInterval);
				vb.setStartDate(nextStartTime);
				vehicles.add(vb);
				monitor.worked(1);
				index++;
				routeIndex++;
			}
		} else {
			List<RoadSegment> segments = loader.getRoadNetwork().getRoadSegments();
			List<Long> coveredRoutingIds = new ArrayList<>();
			for (RoadSegment rs : segments) {
				if (!coveredRoutingIds.contains(rs.getRoutingId())) {
					coveredRoutingIds.add(rs.getRoutingId());
				}
			}

			// fill start and end segments
			List<RoadSegment> startSegments = new ArrayList<>(), endSegments = new ArrayList<>();
			if (startIds == null || startIds.isEmpty()) {
				startSegments = segments;
			} else {
				for (Long id : startIds) {
					startSegments.add(loader.getRoadNetwork().getRoadSegmentByKey(id));
				}
			}

			if (endIds == null || endIds.isEmpty()) {
				endSegments = segments;
			} else {
				for (Long id : endIds) {
					endSegments.add(loader.getRoadNetwork().getRoadSegmentByKey(id));
				}
			}

			Date nextStartTime = startDate;
			int index = 0;
			AbstractRouteService routeService = new DefaultRouteService(graph, loader.getOldRoutingIds());
			while (index < nrRoutes) {
				RoadSegment source = null;
				while (source == null || !source.getStartNode().isSourceDeadEnd()) {
					source = getRandomElement(startSegments);
				}
				RoadSegment target = null;
				while (target == null || target.getEndNode() == null || !target.getEndNode().isSinkDeadEnd()) {
					target = getRandomElement(endSegments);
				}
				String msg = "Created nodes for route " + index + " from " + source.getId() + " to " + target.getId() + ". Routing ...";
				monitor.subTask(msg);
				Logger.logDebug(msg);

				SimpleRouteResult routingResult = routeService.findRoute(source.getStartNode(), target.getEndNode());
				if (routingResult == null) {
					Logger.logWarn("No direct connection available. Discard route.");
					continue;
				}
				RouteBean route = RoutingUtil.toRouteBean(index, CollectionUtil.toPrimitiveLongArray(routingResult.getRoutingIds()),
						source);
				// check if all ids are found in area of interest
				boolean allSegmentsInArea = true;
				for (Long l : route.getRoadSegmentIds()) {
					if (!coveredRoutingIds.contains(l)) {
						allSegmentsInArea = false;
						break;
					}
				}
				if (!allSegmentsInArea || route.getRoadSegmentIds().size() < 2) {
					Logger.logInfo("Not all segments in area. Re-Creating route " + index);
					continue;
				}
				try {
					monitor.subTask("Update initial and target segments for " + index);
					RoutingUtil.updateInitialAndTargetRoadSegments(new Route(route.getRoadSegmentIds()),
							loader.getRoadNetwork().getRoadSegmentsByRoutingId());
				} catch (RoutingException e) {
					Logger.logError("Could not update initial and target segments", e);
					continue;
				}

				VehicleAttributes usedAtts = getRandomAttributes(attributes);
				routes.add(route);

				VehicleBean vb = createVehicleBean(usedAtts, index, index);
				nextStartTime = new Date(nextStartTime.getTime() + startInterval);
				vb.setStartDate(nextStartTime);
				vehicles.add(vb);
				monitor.worked(1);
				index++;
			}
		}

		// Re-assign identifiers
		if (appendToExistingConfig && existingVehicles != null && !existingVehicles.isEmpty()) {
			long id = 0;

			for (VehicleBean bean : vehicles) {
				bean.setId(id);
				id++;
			}
		}
	}

	private VehicleBean createVehicleBean(VehicleAttributes usedAtts, int id, int routeId) {
		VehicleBean vb = new VehicleBean();
		vb.setInitialSpeed(usedAtts.getInitialSpeed());
		vb.setWidth(usedAtts.getWidth());
		vb.setLength(usedAtts.getLength());
		vb.setInitialSpeed(usedAtts.getInitialSpeed());
		vb.setLongitudinalControlIdentifier(usedAtts.getLongitudinalControlIdentifier());
		vb.setLaneChaneModelIdentifier(usedAtts.getLaneChangeModelIdentifier());
		vb.setMemoryIdentifier(usedAtts.getMemoryModelIdentifier());
		vb.setConsumptionIdentifier(usedAtts.getConsumptionModelIdentifier());
		if (usedAtts.isCommEnabled()) {
			VehicleCommDataBean bean = new VehicleCommDataBean();
			bean.setStaticRouteUpdateInterval(usedAtts.getStaticRouteUpdateInterval());
			bean.setDynamicRouteUpdateThreshold(usedAtts.getDynamicRouteUpdateThreshold());
			bean.setVehicleDataCommInterval(usedAtts.getVehicleDataCommInterval());
			if (commData != null) {
				if (commData.contains(bean)) {
					vb.setCommDataId(commData.get(commData.indexOf(bean)).getId());
				} else {
					commData.add(bean);
				}
			}
			vb.setCommDataId(bean.getId());
		}
		vb.setRouteId(usedAtts.getRouteIdentifier() == -1 ? routeId : usedAtts.getRouteIdentifier());
		vb.setVehicleType(usedAtts.getType().toString());
		vb.setId(id);
		return vb;
	}

	private VehicleAttributes getRandomAttributes(List<VehicleAttributes> vaList) {
		List<Long> cumSum = new ArrayList<>();
		long sum = 0;
		for (VehicleAttributes va : vaList) {
			cumSum.add(sum + va.getProbability());
			sum += va.getProbability();
		}
		long randNumber = Math.abs(randomGenerator.nextLong() + 1) % sum;
		for (Long l : cumSum) {
			if (randNumber < l) {
				return vaList.get(cumSum.indexOf(l));
			}
		}
		return null;
	}

	private <T> T getRandomElement(Collection<T> list) {
		if (list.size() == 0) {
			return null;
		}
		int index = randomGenerator.nextInt(list.size());
		return new ArrayList<>(list).get(index);
	}

}

package at.fhhagenberg.mc.traffsim.util;

import java.util.Properties;

import at.fhhagenberg.mc.util.LinkedProperties;

/**
 * Utility class providing various property-related functionalities.
 *
 * @author Christian Backfrieder
 */
public class PropertyUtil {

	/**
	 * Clones the given entity of type {@link LinkedProperties}.
	 *
	 * @param original
	 *            the original entity
	 * @return the cloned entity of type {@link LinkedProperties}
	 */
	public static LinkedProperties clone(LinkedProperties original) {
		LinkedProperties prop = new LinkedProperties();
		prop.putAll(original);
		return prop;
	}

	/**
	 * Checks if the given set of properties contains a property identified by the provided key.
	 *
	 * @param properties
	 *            the property set to be looked up
	 * @param key
	 *            the key to be looked for
	 * @return true if the set of properties contains the given key - false else
	 */
	public static boolean containsProperty(Properties properties, String key) {
		return properties.containsKey(key);
	}

	/**
	 * Gets a {@link Boolean} property identified by the given key from a list of properties .
	 *
	 * @param properties
	 *            the property set to be looked up
	 * @param key
	 *            the key identified the requested property
	 * @param defaultValue
	 *            the default value used if the property is not set
	 * @return the property's value or the default value if property is not set
	 */
	public static Boolean getBooleanProperty(Properties properties, String key, Boolean defaultValue) {
		return properties.containsKey(key) ? Boolean.valueOf(properties.getProperty(key)) : defaultValue;
	}

	/**
	 * Gets a {@link Double} property identified by the given key from a list of properties .
	 *
	 * @param properties
	 *            the property set to be looked up
	 * @param key
	 *            the key identified the requested property
	 * @param defaultValue
	 *            the default value used if the property is not set
	 * @return the property's value or the default value if property is not set
	 */
	public static Double getDoubleProperty(Properties properties, String key, Double defaultValue) {
		return properties.containsKey(key) ? Double.valueOf(properties.getProperty(key)) : defaultValue;
	}

	/**
	 * Gets an {@link Integer} property identified by the given key from a list of properties .
	 *
	 * @param properties
	 *            the property set to be looked up
	 * @param key
	 *            the key identified the requested property
	 * @param defaultValue
	 *            the default value used if the property is not set
	 * @return the property's value or the default value if property is not set
	 */
	public static Integer getIntProperty(Properties properties, String key, Integer defaultValue) {
		Object val = properties.get(key);

		try {
			if (val instanceof Integer) {
				return (Integer) val;
			} else if (val instanceof String) {
				return Integer.valueOf((String) val);
			} else if (val == null) {
				return defaultValue;
			} else {
				return (Integer) val;
			}
		} catch (ClassCastException e) {
			return defaultValue;
		}
	}

	/**
	 * Get a {@link String} property identified by the given key from a list of properties .
	 *
	 * @param properties
	 *            the property set to be looked up
	 * @param key
	 *            the key identified the requested property
	 * @param defaultValue
	 *            the default value used if the property is not set
	 * @return the property's value or the default value if property is not set
	 */
	public static String getStringProperty(Properties properties, String key, String defaultValue) {
		return properties.containsKey(key) ? properties.getProperty(key) : defaultValue;
	}

	/**
	 * Sets a property identified by the given key to the provided value.
	 *
	 * @param properties
	 *            the property set to be updated
	 * @param key
	 *            the key identifying the property to be set
	 * @param value
	 *            the property's new value
	 */
	public static void set(Properties properties, String key, Object value) {
		properties.setProperty(key, String.valueOf(value));
	}
}
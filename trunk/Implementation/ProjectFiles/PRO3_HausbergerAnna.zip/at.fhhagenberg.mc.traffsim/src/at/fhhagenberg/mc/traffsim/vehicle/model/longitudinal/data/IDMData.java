package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

public class IDMData extends GippsData {
	private static final String IDENTIFIER = "IDM";

	private double delta;

	public IDMData() {
		setIdentifier(IDENTIFIER);
	}

	public IDMData(double vTarget, double sMin, double tMin, double comfortableAcc, double safeDec, double maxAcc, double maxDec,
			double delta) {
		super(vTarget, sMin, comfortableAcc, safeDec);
		settMin(tMin);
		setMaxDec(maxDec);
		setMaxAcc(maxAcc);
		setDelta(delta);
		setIdentifier(IDENTIFIER);
	}

	public double getDelta() {
		return delta;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}

}
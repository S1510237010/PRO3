package at.fhhagenberg.mc.traffsim.ui.preferences;

import java.util.concurrent.TimeUnit;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.ColorFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.jface.preference.ScaleFieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class UiPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {
	public static final String ID = "at.fhhagenberg.mc.traffsim.ui.preferences";
	private Spinner spinnerUpdateInterval, spinnerUiUpdateInterval;
	private Button btnUiUpdateDisabled;

	public UiPreferencePage() {
		super(GRID);
		setSize(new Point(0, 300));
		setTitle("UI Preferences");
	}

	@Override
	public void init(IWorkbench workbench) {
		setPreferenceStore(TraffSimCorePlugin.getDefault().getPreferenceStore());
		setDescription("Preferences for graphical output");
	}

	@Override
	protected void createFieldEditors() {
		addField(new RadioGroupFieldEditor(IPreferenceConstants.VEHICLE_PRINT,
				"Vehicle display", 1, new String[][] { { "Nothing", IPreferenceConstants.PRINT_NOTHING },
						{ "IDs only", IPreferenceConstants.PRINT_IDS }, { "Details", IPreferenceConstants.PRINT_DETAILS } },
				getFieldEditorParent(), false));
		addField(new BooleanFieldEditor(IPreferenceConstants.DEBUG_ROAD_INFO, "Print debug road info", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
		addField(new BooleanFieldEditor(IPreferenceConstants.DEBUG_LANE_INFO, "Print debug lane info", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
		addField(new BooleanFieldEditor(IPreferenceConstants.DEBUG_JUNCTION_INFO, "Print debug junction info", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
		addField(new BooleanFieldEditor(IPreferenceConstants.PRINT_SPEED_LIMITS, "Print speed limits", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
		addField(new BooleanFieldEditor(IPreferenceConstants.SHOW_LOOP_DETECTORS, "Show loop detectors", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
		addField(new BooleanFieldEditor(IPreferenceConstants.TRANSPARENT_ROADS, "Transparent roads", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferenceConstants.BACKGROUND_COLOR, "Background color", getFieldEditorParent()));
		addField(new ScaleFieldEditor(IPreferenceConstants.BACKGROUND_ALPHA, "Background Alpha", getFieldEditorParent(), 0, 100, 1, 10));
		addField(new BooleanFieldEditor(IPreferenceConstants.HIDE_CONTROLS_ON_START, "Hide control panel on start", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
		addField(new BooleanFieldEditor(IPreferenceConstants.SHOW_DETAIL_UPON_SELECTION, "Show selection details", BooleanFieldEditor.DEFAULT,
				getFieldEditorParent()));
	}

	@Override
	protected Control createContents(Composite parent) {

		super.createContents(parent);

		Composite additional = new Composite(parent, SWT.NONE);
		additional.setLayout(new GridLayout(2, false));
		Label lblUpdateInterval = new Label(additional, SWT.NONE);
		lblUpdateInterval.setText("Statistics graph update interval:");

		spinnerUpdateInterval = new Spinner(additional, SWT.BORDER);
		GridData gd_spinnerUpdateInterval = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_spinnerUpdateInterval.widthHint = 50;
		spinnerUpdateInterval.setLayoutData(gd_spinnerUpdateInterval);
		spinnerUpdateInterval.setIncrement(100);
		spinnerUpdateInterval.setPageIncrement(200);
		spinnerUpdateInterval.setMaximum(3000);
		spinnerUpdateInterval.setMinimum(50);
		spinnerUpdateInterval.setSelection(PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL));

		if (spinnerUpdateInterval.getSelection() == 0) {
			spinnerUpdateInterval.setSelection(IPreferenceConstants.DEFAULT_STATISTICS_UPDATE_INTERVAL);
		}

		Composite uiUpdate = new Composite(parent, SWT.NONE);
		uiUpdate.setLayout(new GridLayout(3, false));

		Label lblUiUpdateInterval = new Label(uiUpdate, SWT.NONE);
		lblUiUpdateInterval.setText("UI Update interval:");

		spinnerUiUpdateInterval = new Spinner(uiUpdate, SWT.BORDER);
		GridData gd_spinnerUiUpdateInterval = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_spinnerUiUpdateInterval.widthHint = 50;
		spinnerUiUpdateInterval.setLayoutData(gd_spinnerUiUpdateInterval);
		spinnerUiUpdateInterval.setIncrement(100);
		spinnerUiUpdateInterval.setPageIncrement(200);
		spinnerUiUpdateInterval.setMaximum((int) TimeUnit.MINUTES.toMillis(5));
		spinnerUiUpdateInterval.setMinimum(1);
		spinnerUiUpdateInterval.setSelection(getPreferenceStore().getInt(IPreferenceConstants.UI_UPDATE_TIME));
		spinnerUiUpdateInterval.setEnabled(PreferenceUtil.getBoolean(IPreferenceConstants.UI_UPDATE_ENABLED));

		btnUiUpdateDisabled = new Button(uiUpdate, SWT.CHECK);
		btnUiUpdateDisabled.setSelection(!PreferenceUtil.getBoolean(IPreferenceConstants.UI_UPDATE_ENABLED));
		btnUiUpdateDisabled.setText("Disable UI update");
		btnUiUpdateDisabled.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				spinnerUiUpdateInterval.setEnabled(!btnUiUpdateDisabled.getSelection());
			}
		});

		return parent;
	}

	@Override
	protected void performApply() {
		PreferenceUtil.setInt(IPreferenceConstants.STATISTICS_UPDATE_INTERVAL, spinnerUpdateInterval.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.UI_UPDATE_TIME, spinnerUiUpdateInterval.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.UI_UPDATE_ENABLED, !btnUiUpdateDisabled.getSelection());
	}

	@Override
	public boolean performOk() {
		performApply();
		return super.performOk();
	}
}

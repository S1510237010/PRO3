package at.fhhagenberg.mc.traffsim.model.geo;

import java.io.Serializable;

import at.fhhagenberg.mc.traffsim.util.NumberUtil;

/**
 * Class representing a location in a Cartesian coordinate system.
 *
 * @author Christian Backfrieder
 */
public class Location implements Serializable {

	/** Unique identifier required for serialisation */
	private static final long serialVersionUID = 2316218380421497328L;

	/** The x-coordinate of a Cartesian system, or the longitude */
	public double x;

	/** The y-coordinate of a Cartesian system, or the latitude */
	public double y;

	/**
	 * Parameterless constructor required for serialisation
	 */
	public Location() {
	}

	/**
	 * Creates a new {@link Location} with the given x- and y-coordinate
	 *
	 * @param x
	 *            the longitude, or x-coordinate
	 * @param y
	 *            the latitude, or y-coordinate
	 */
	public Location(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}

	/**
	 * Determines the distance from the current {@link Location} to the given
	 * one.
	 *
	 * @param other
	 *            the {@link Location} to calculate the distance to
	 * @return the distance to between the two locations
	 */
	public double distanceTo(Location other) {
		if (other == null) {
			return 0;
		}

		double xdiff = other.x - x;
		double ydiff = other.y - y;
		return Math.sqrt(xdiff * xdiff + ydiff * ydiff);
	}

	@Override
	public boolean equals(final Object obj) {
		return equals(obj, 10e-8);
	}

	/**
	 * Checks if the current {@link Location} is equal to the given
	 * {@link Object} using the provided tolerance for coordinate comparison.
	 *
	 * @param obj
	 *            the object to be checked for equality
	 * @param tolerance
	 *            the tolerance value used for comparing the {@link Location}s'
	 *            coordinates
	 * @return true, if both objects are equal - false else
	 */
	public boolean equals(final Object obj, double tolerance) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		Location other = (Location) obj;

		if (!NumberUtil.doubleEquals(x, other.x, tolerance)) {
			return false;
		}

		if (!NumberUtil.doubleEquals(y, other.y, tolerance)) {
			return false;
		}

		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(x);
		result = prime * result + (int) (temp ^ temp >>> 32);
		temp = Double.doubleToLongBits(y);
		result = prime * result + (int) (temp ^ temp >>> 32);
		return result;
	}

	@Override
	public String toString() {
		String retValue = this.x + " " + this.y;
		return retValue;
	}

	/**
	 * Converts the {@link Location} into a {@link Vector} instance.
	 *
	 * @return a {@link Vector} initialised with the location's coordinates
	 */
	public Vector toVector() {
		return new Vector(x, y);
	}
}
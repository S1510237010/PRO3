package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane;

public class LaneChangeDecision {
	private int direction = Lane.NO_CHANGE;

	/** urgency of lane change, from 0 (not urgent) to 1 (highly urgent) */
	private double urgency = -1;

	/** flag if lane change is mandatory (e.g. leave from entrance, move to exit lane) */
	private boolean mandatory = false;

	public LaneChangeDecision(int direction) {
		this.direction = direction;
	}

	public LaneChangeDecision(int index, boolean mandatory) {
		this(index);
		this.mandatory = true;
	}

	public LaneChangeDecision(int index, boolean mandatory, double urgency) {
		this(index, mandatory);
		this.urgency = urgency;
	}

	public double getUrgency() {
		return urgency;
	}

	public void setUrgency(double priority) {
		this.urgency = priority;
	}

	public boolean isMandatory() {
		return mandatory;
	}

	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

	public int getDirection() {
		return direction;
	}

}

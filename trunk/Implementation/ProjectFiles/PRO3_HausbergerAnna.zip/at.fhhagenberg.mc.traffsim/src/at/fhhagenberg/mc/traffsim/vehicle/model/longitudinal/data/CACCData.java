package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

/**
 * Data entity for platooning longitudinal model
 *
 * @author Sebastian Huber
 *
 */
public class CACCData extends LongitudinalModelData {
	private static final String IDENTIFIER = "CACC";

	/**
	 * weighting factor between acceleration of leader and the preceding vehicle
	 */
	private double c1;

	/**
	 * damping (ξ, Xi) ratio (default set to 1)
	 */
	private double damping;

	/**
	 * bandwidth (ω, omega) of controller
	 */
	private double bandwidth;

	/**
	 * Empty CTor
	 */
	public CACCData() {
		setIdentifier(IDENTIFIER);
	}

	/**
	 * CTor with all params
	 *
	 * @param vTarget
	 *            target speed
	 * @param sMin
	 *            minimum distance in m for a human driver
	 * @param tMin
	 *            minimum time in s to preceding vehicle for a human driver
	 * @param comfortableAcc
	 *            comfortable acceleration
	 * @param safeDec
	 *            safe deceleration
	 * @param maxAcc
	 *            max acceleration
	 * @param maxDec
	 *            max deceleration
	 * @param c1
	 *            weighting factor
	 * @param damping
	 *            damping
	 * @param bandwidth
	 *            bandwidth
	 */
	public CACCData(double vTarget, double sMin, double tMin, double comfortableAcc, double safeDec, double maxAcc, double maxDec, double c1,
			double damping, double bandwidth) {
		super(vTarget, sMin, tMin, comfortableAcc, safeDec, maxAcc, maxDec);
		setIdentifier(IDENTIFIER);
		this.c1 = c1;
		this.damping = damping;
		this.bandwidth = bandwidth;
	}

	/**
	 * Weighting factor
	 *
	 * @return c1
	 */
	public double getC1() {
		return c1;
	}

	/**
	 * Weighting factor
	 *
	 * @param c1
	 *            c1
	 */
	public void setC1(double c1) {
		this.c1 = c1;
	}

	/**
	 * Damping value
	 *
	 * @return damping
	 */
	public double getDamping() {
		return damping;
	}

	/**
	 * Damping value
	 *
	 * @param damping
	 *            damping
	 */
	public void setDamping(double damping) {
		this.damping = damping;
	}

	/**
	 * Bandwidth
	 *
	 * @return bandwidth
	 */
	public double getBandwidth() {
		return bandwidth;
	}

	/**
	 * Bandwidth
	 *
	 * @param bandwidth
	 *            bandwidth
	 */
	public void setBandwidth(double bandwidth) {
		this.bandwidth = bandwidth;
	}

	/**
	 * Precalculated value for longitudinal model
	 *
	 * @return alpha1
	 */
	public double getAlpha1() {
		return (1.0 - c1);
	}

	/**
	 * Precalculated value for longitudinal model
	 *
	 * @return alpha2
	 */
	public double getAlpha2() {
		return c1;
	}

	/**
	 * Precalculated value for longitudinal model
	 *
	 * @return alpha3
	 */
	public double getAlpha3() {
		return (-((2 * damping) - (c1 * (damping + Math.sqrt((Math.pow(damping, 2) - 1))))) * bandwidth);
	}

	/**
	 * Precalculated value for longitudinal model
	 *
	 * @return alpha4
	 */
	public double getAlpha4() {
		return (-c1 * (damping + Math.sqrt((Math.pow(damping, 2) - 1))) * bandwidth);
	}

	/**
	 * Precalculated value for longitudinal model
	 *
	 * @return alpha5
	 */
	public double getAlpha5() {
		return -(Math.pow(bandwidth, 2));
	}
}

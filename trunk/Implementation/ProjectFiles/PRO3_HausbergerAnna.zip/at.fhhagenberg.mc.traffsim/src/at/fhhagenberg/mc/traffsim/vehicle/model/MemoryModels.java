package at.fhhagenberg.mc.traffsim.vehicle.model;

public enum MemoryModels {

	MEMORY("Memory", "MEMORY");

	private String type;
	private String shortName;

	private MemoryModels(final String type, final String shortName) {
		this.type = type;
		this.shortName = shortName;
	}

	@Override
	public String toString() {
		return type;
	}

	public String getShortName() {
		return shortName;
	}

	public static MemoryModels valueOfLabel(String label) {
		for (MemoryModels t : MemoryModels.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}

		return null;
	}
}

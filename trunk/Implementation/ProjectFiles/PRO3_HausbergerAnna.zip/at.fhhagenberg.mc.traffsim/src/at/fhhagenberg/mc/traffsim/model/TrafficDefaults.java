package at.fhhagenberg.mc.traffsim.model;

/**
 * Constants relevant for traffic parameters.
 *
 * TODO: these constants should be induced by an input file
 *
 * @author Christian B.
 *
 */
public abstract class TrafficDefaults {

	public static final double DEFAULT_MAX_DECELERATION = -7;
	public static final double DEFAULT_COMFORTABLE_ACCELERATION = 1.5;
	public static final double DEFAULT_MAX_ACCELERATION = 5;
	public static final double DEFAULT_SAFE_DECELERATION = -2;
	public static final double DEFAULT_TOLERABLE_DECELERATION = -4;
	public static final double DEFAULT_MIN_DISTANCE_SECONDS = 1.1;
	public static final double DEFAULT_MIN_DISTANCE_METERS = 2;
	public static final double DEFAULT_DELTA = 4;
	public static final double LANE_CHANGE_TIME = 2.5;
	public static final double DEFAULT_POLITENESS = 0.05;
	public static final double DEFAULT_THRESHOLD = 0.1;
	public static final double DEFAULT_BIAS_RIGHT = 0.2;

	public static final double DEFAULT_PRESENCE_DETECTION_SPEED_THRESHOLD = 1.0;
	public static final double DEFAULT_VEHICLE_LENGTH = 4.5;
	public static final double DEFAULT_VEHICLE_WIDTH = 1.7;
	public static final int DEFAULT_INFLOW = 180;
	public static final double DEFAULT_INFLOW_SAMPLE_INTERVAL = 30;
	public static final double DEFAULT_INFLOW_STDDEV = 30;
	public static final double DEFAULT_LANE_WIDTH = 3;
	public static final double DEFAULT_DETECTOR_RADIUS = 1.3;
	public static final double DEFAULT_COOLNESS = 0.99;
	public static final double DEFAULT_REROUTING_THRESHOLD_TIME = 1.1;
	public static final double DEFAULT_REROUTING_THRESHOLD_DISTANCE = 2.5;
	public static final int DEFAULT_REROUTING_AVERAGING_WINDOW_SIZE = 10;
}

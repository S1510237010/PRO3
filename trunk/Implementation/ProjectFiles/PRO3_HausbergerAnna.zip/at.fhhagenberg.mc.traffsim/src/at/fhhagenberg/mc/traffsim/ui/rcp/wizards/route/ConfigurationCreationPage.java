package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.ParameterBean;
import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleCommDataBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.util.StringUtil;

public class ConfigurationCreationPage extends WizardPage {
	private Text textConfiguration;
	private Text textVehicles;
	private Text textRoutes;
	private Text textParameters;
	private Text textOutputFolder;
	private Text textCommData;

	private Button btnUpdateMappings;

	protected ConfigurationCreationPage(String pageName) {
		super(pageName);
		setDescription("Set up file names of current configuration. The newly created files will be named after the given filenames.");
		setTitle("File configuration");
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);
		if (visible) {
			DataSerializer ser = new DataSerializer();
			ser.readConfiguration(
					((RouteParameterPage) getWizard().getPage(RouteGeneratorWizard.PAGE_ROUTE_PAREMTERS)).getResult().configFile);
			String confFile = ser.getConfiguration().getConfigurationFile().getName();

			if (StringUtil.isNotNullOrEmpty(confFile)) {
				textConfiguration.setText(confFile);
			}

			String vehName = ser.getConfiguration().getFilenameFor(VehicleBean.class.getCanonicalName());
			if (StringUtil.isNotNullOrEmpty(vehName)) {
				textVehicles.setText(vehName);
			}

			String commClazz = VehicleCommDataBean.class.getCanonicalName();
			if (ser.getConfiguration().hasMappingFor(commClazz)) {
				String vehCommName = ser.getConfiguration().getBeanConfigurationsMapping().get(commClazz).getFileName();
				if (StringUtil.isNotNullOrEmpty(vehCommName)) {
					textCommData.setText(vehCommName);
				}
			}

			String routeName = ser.getConfiguration().getFilenameFor(RouteBean.class.getCanonicalName());
			if (StringUtil.isNotNullOrEmpty(routeName)) {
				textRoutes.setText(routeName);
			}

			String paramname = ser.getConfiguration().getFilenameFor(ParameterBean.class.getCanonicalName());
			if (StringUtil.isNotNullOrEmpty(paramname)) {
				textParameters.setText(paramname);
			}

			btnUpdateMappings.setSelection(false);

			validatePage();
		}
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new GridLayout(2, false));

		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblNewLabel.setText("Configuration");

		textConfiguration = new Text(container, SWT.BORDER);
		textConfiguration.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblVehicles = new Label(container, SWT.NONE);
		lblVehicles.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblVehicles.setText("Vehicles");

		textVehicles = new Text(container, SWT.BORDER);
		textVehicles.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textVehicles.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		Label lblCommData = new Label(container, SWT.NONE);
		lblCommData.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblCommData.setText("Comm. Data");

		textCommData = new Text(container, SWT.BORDER);
		textCommData.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textCommData.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		Label lblRoutes = new Label(container, SWT.NONE);
		lblRoutes.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRoutes.setText("Routes");

		textRoutes = new Text(container, SWT.BORDER);
		textRoutes.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textRoutes.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		Label lblParameters = new Label(container, SWT.NONE);
		lblParameters.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblParameters.setText("Parameters");

		textParameters = new Text(container, SWT.BORDER);
		textParameters.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textParameters.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		Label lblOutputFolder = new Label(container, SWT.NONE);
		lblOutputFolder.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblOutputFolder.setText("Output Folder");

		textOutputFolder = new Text(container, SWT.BORDER);
		textOutputFolder.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		new Label(container, SWT.NONE);
		btnUpdateMappings = new Button(container, SWT.CHECK);
		btnUpdateMappings.setText("Update file mappings");
	}

	private void validatePage() {
		if (textConfiguration.getText().isEmpty() || textVehicles.getText().isEmpty() || textRoutes.getText().isEmpty()
				|| textParameters.getText().isEmpty()) {
			setErrorMessage("Empty file names are not allowed");
		} else {
			if (!textConfiguration.getText().endsWith(".xml") || !textVehicles.getText().endsWith(".xml")
					|| !textRoutes.getText().endsWith(".xml") || !textParameters.getText().endsWith(".xml")) {
				setErrorMessage("File names must end with '.xml'");
			} else {

				setErrorMessage(null);
			}
		}

		getWizard().getContainer().updateButtons();
	}

	@Override
	public boolean isPageComplete() {
		return getErrorMessage() == null;
	}

	public String getConfigurationFileName() {
		return textConfiguration.getText();
	}

	public String getVehiclesFileName() {
		return textVehicles.getText();
	}

	public String getRoutesFileName() {
		return textRoutes.getText();
	}

	public String getParametersFileName() {
		return textParameters.getText();
	}

	public String getOutputFolder() {
		return textOutputFolder.getText();
	}

	public String getCommDataFileName() {
		return textCommData.getText();
	}

	public boolean getUpdateMappings() {
		return btnUpdateMappings.getSelection();
	}
}

package at.fhhagenberg.mc.traffsim.ui;

import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;

public interface IRouteUpdateListener {

	public void routesUpdated(List<IRoute> routes);
}

package at.fhhagenberg.mc.traffsim.model;

import at.fhhagenberg.mc.traffsim.log.LogMessage;

/**
 * A log provider which is able to consume debug information about the owner of the class. Can be used to be displayed in a separate console
 * window, for example
 * 
 * @author Christian Backfrieder
 * 
 */
public interface ILogConsumer {
	public void addLogLine(final LogMessage message);
}

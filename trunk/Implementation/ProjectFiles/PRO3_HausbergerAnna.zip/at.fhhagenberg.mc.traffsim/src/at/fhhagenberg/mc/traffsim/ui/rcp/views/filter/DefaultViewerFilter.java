package at.fhhagenberg.mc.traffsim.ui.rcp.views.filter;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

public class DefaultViewerFilter extends ViewerFilter {

	private String filterString;

	public DefaultViewerFilter(String filterString) {
		this.filterString = filterString.toLowerCase();
	}

	@Override
	public boolean select(Viewer viewer, Object parentElement, Object element) {
		if (element instanceof IFilterEnabledElement) {
			return ((IFilterEnabledElement) element).getInfoAsString().toLowerCase().contains(filterString);
		}
		return element.toString().toLowerCase().contains(filterString);
	}

	public void setFilterString(String filterString) {
		this.filterString = filterString.toLowerCase();
	}

}

package at.fhhagenberg.mc.traffsim.model;

public abstract class PropertyValues {
	/** general purpose constant */
	public static final String UNDEFINED = "undefined";
	public static final String DISABLED = "disabled";
	public static final String ENABLED = "enabled";

	/** values for rerouting mode */
	public static final String REROUTING_MODE_SINGLE = "single";
	public static final String REROUTING_MODE_KSP = "ksp";
	public static final String REROUTING_MODE_TIME_DYNAMIC = "timedynamic";
	public static final String GREENSHIELD = "greenshield";
	public static final String SPEED_AVERAGE = "speed_average";
	public static final String GLOBAL = "global";
	public static final String REROUTING_HEURISTICS_ROUTE_FOOTPRINT = "route_footprint";
	public static final String REROUTING_HEURISTICS_FOOTPRINT_PREDICTION = "footprint_prediction";

	/** defaults */
	public static final int DEFAULT_REROUTING_HEURISTICS_ROUTE_FOOTPRINT_WEIGHT = 5;
	public static final double DEFAULT_CONGESTION_THRESHOLD_DELTA = 0.7;
	public static final int DEFAULT_CONGESTION_LEVEL = 4;
	public static final int DEFAULT_REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_TIME_RESOLUTION = 5000;
	public static final int DEFAULT_REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_MAX_FORECAST = 2400000;
	public static final double DEFAULT_REROUTING_THRESHOLD_TIME_DYNAMIC = 1.1;
	public static final double DEFAULT_REROUTING_THRESHOLD_DISTANCE_DYNAMIC = 3;
	public static final double DEFAULT_CONGESTION_THRESHOLD_VEHICLES_PER_SECOND = 1.5;
	public static final boolean DEFAULT_REROUTING_SIMULATION_ONLY = false;
	public static final boolean DEFAULT_AVOID_MULTI_REROUTES = true;
	public static final int DEFAULT_REROUTING_UPDATE_TIME = 2500;
	public static final int DEFAULT_KSP_VALUE_K = 4;
	public static final boolean DEFAULT_COMM_DELAY_ENABLED = false;
	public static final Integer DEFAULT_MINIMUM_VEHICLES_FOR_CONGESTION = 2;

}

package at.fhhagenberg.mc.traffsim.deadlock;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import at.fhhagenberg.mc.traffsim.model.IntervalUpdateThread;
import at.fhhagenberg.mc.traffsim.model.SimulationObserver;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class DeadlockDetector extends IntervalUpdateThread {

	private List<IDeadlockListener> deadlockListeners = new ArrayList<>();
	private SimulationObserver observer;

	private long numVehiclesOnLastNotification = 0;

	public DeadlockDetector(String name, long updateIntervalMillis, SimulationObserver observer) {
		super(name, updateIntervalMillis, false);
		this.observer = observer;
	}

	@Override
	public void doWorkWaitForFinish() {
		if (getRunTime() > TimeUnit.MILLISECONDS.toSeconds(updateIntervalMillis) * 2) {
			double speedsum = 0;
			for (Vehicle v : observer.getEnteredVehicles()) {
				speedsum += v.getCurrentSpeed();
			}
			if (NumberUtil.doubleEquals(speedsum, 0, 10e-5) && observer.getEnteredVehicles().size() != 0
					&& observer.getCurNumVehicles() != numVehiclesOnLastNotification) {
				// avoid duplicate notification
				numVehiclesOnLastNotification = observer.getCurNumVehicles();
				for (IDeadlockListener deadlockListener : deadlockListeners) {
					deadlockListener.deadlockDetected();
				}
			}
		}
	}

	public void addDeadlockListener(IDeadlockListener listener) {
		this.deadlockListeners.add(listener);
	}

	public void removeDeadlockListener(IDeadlockListener listener) {
		deadlockListeners.remove(listener);
	}

}

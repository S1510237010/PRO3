package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.io.File;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.ChannelModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.ConsumptionModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.LaneChangeModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.LongitudinalModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.MemoryModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.NoiseModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControls;
import at.fhhagenberg.mc.util.StringUtil;

/**
 *
 * @author Manuel Lindorfer
 *
 */
public class ModelSelectionPage extends WizardPage {

	private Button btnBrowse;
	private Button btnConsumption;
	private Button btnLaneChange;
	private Button btnLongitudinal;
	private Button btnLongControl;
	private Button btnMemory;
	private Button btnChannelModels;

	private Button btnNoise;
	private Combo comboConsumption;
	private Combo comboLaneChange;
	private Combo comboLongitudinal;
	private Combo comboLongControl;
	private Combo comboMemory;
	private Combo comboChannelModels;

	private Combo comboNoise;
	private Text textConfigPath;

	protected ModelSelectionPage(String pageName) {
		super(pageName);
		setPageComplete(true);
		setDescription("Select a model of choice for customization");
		setTitle("Model Selection");
	}

	@Override
	public boolean canFlipToNextPage() {
		return StringUtil.isNullOrEmpty(getErrorMessage());
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new GridLayout(3, false));

		Label lblTraffsimConfiguration = new Label(container, SWT.NONE);
		lblTraffsimConfiguration.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTraffsimConfiguration.setText("TraffSim Configuration");

		textConfigPath = new Text(container, SWT.BORDER);
		textConfigPath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textConfigPath.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});

		textConfigPath.setText(PreferenceUtil.getString(IPreferenceConstants.WIZARD_MODEL_GENERATION_CONFIG_PATH, ""));

		btnBrowse = new Button(container, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(getWizard().getContainer().getShell());
				dialog.setText("Open configuration file");
				dialog.setFilterExtensions(new String[] { Constants.FILE_FILTER_TRAFFSIM_XML });
				dialog.setFilterNames(new String[] { Constants.FILTER_NAME_TRAFFSIM });
				String selected = dialog.open();

				if (StringUtil.isNotNullOrEmpty(selected)) {
					textConfigPath.setText(selected);
				}

				validatePage();

				// Update the wizard buttons
				if (getWizard() != null && getWizard().getContainer() != null) {
					getWizard().getContainer().updateButtons();
				}
			}
		});

		btnBrowse.setText("Browse");

		new Label(container, SWT.NONE);

		Group grpModelSelection = new Group(container, SWT.NONE);
		grpModelSelection.setText("Model Selection");
		grpModelSelection.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, true, false, 3, 1));
		grpModelSelection.setLayout(new GridLayout(2, false));

		btnLongitudinal = new Button(grpModelSelection, SWT.RADIO);
		btnLongitudinal.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnLongitudinal.getSelection()) {
					comboLongitudinal.setEnabled(true);
					comboChannelModels.setEnabled(false);
					comboMemory.setEnabled(false);
					comboConsumption.setEnabled(false);
					comboLaneChange.setEnabled(false);
					comboNoise.setEnabled(false);
					comboLongControl.setEnabled(false);
				}
			}
		});

		btnLongitudinal.setText("Longitudinal model");

		comboLongitudinal = new Combo(grpModelSelection, SWT.READ_ONLY);
		comboLongitudinal.setLayoutData(new GridData(SWT.NORMAL, SWT.CENTER, true, true, 1, 1));

		for (LongitudinalModels s : LongitudinalModels.values()) {
			comboLongitudinal.add(s.toString());
		}

		comboLongitudinal.select(0);

		btnLaneChange = new Button(grpModelSelection, SWT.RADIO);
		btnLaneChange.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnLaneChange.getSelection()) {
					comboLongitudinal.setEnabled(false);
					comboChannelModels.setEnabled(false);
					comboMemory.setEnabled(false);
					comboConsumption.setEnabled(false);
					comboLaneChange.setEnabled(true);
					comboNoise.setEnabled(false);
					comboLongControl.setEnabled(false);
				}
			}
		});

		btnLaneChange.setText("Lane change model");

		comboLaneChange = new Combo(grpModelSelection, SWT.READ_ONLY);
		comboLaneChange.setLayoutData(new GridData(SWT.NORMAL, SWT.CENTER, true, true, 1, 1));

		for (LaneChangeModels s : LaneChangeModels.values()) {
			comboLaneChange.add(s.toString());
		}

		comboLaneChange.select(0);

		btnMemory = new Button(grpModelSelection, SWT.RADIO);
		btnMemory.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnMemory.getSelection()) {
					comboLongitudinal.setEnabled(false);
					comboChannelModels.setEnabled(false);
					comboMemory.setEnabled(true);
					comboConsumption.setEnabled(false);
					comboLaneChange.setEnabled(false);
					comboNoise.setEnabled(false);
					comboLongControl.setEnabled(false);
				}
			}
		});

		btnMemory.setText("Memory model");

		comboMemory = new Combo(grpModelSelection, SWT.READ_ONLY);
		comboMemory.setLayoutData(new GridData(SWT.NORMAL, SWT.CENTER, true, true, 1, 1));

		for (MemoryModels s : MemoryModels.values()) {
			comboMemory.add(s.toString());
		}

		comboMemory.select(0);

		btnConsumption = new Button(grpModelSelection, SWT.RADIO);
		btnConsumption.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnConsumption.getSelection()) {
					comboLongitudinal.setEnabled(false);
					comboChannelModels.setEnabled(false);
					comboMemory.setEnabled(false);
					comboConsumption.setEnabled(true);
					comboLaneChange.setEnabled(false);
					comboNoise.setEnabled(false);
					comboLongControl.setEnabled(false);
				}
			}
		});

		btnConsumption.setText("Consumption model");

		comboConsumption = new Combo(grpModelSelection, SWT.READ_ONLY);
		comboConsumption.setLayoutData(new GridData(SWT.NORMAL, SWT.CENTER, true, true, 1, 1));

		for (ConsumptionModels s : ConsumptionModels.values()) {
			comboConsumption.add(s.toString());
		}

		comboConsumption.select(0);

		btnNoise = new Button(grpModelSelection, SWT.RADIO);
		btnNoise.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnNoise.getSelection()) {
					comboLongitudinal.setEnabled(false);
					comboChannelModels.setEnabled(false);
					comboMemory.setEnabled(false);
					comboConsumption.setEnabled(false);
					comboLaneChange.setEnabled(false);
					comboNoise.setEnabled(true);
					comboLongControl.setEnabled(false);
				}
			}
		});

		btnNoise.setText("Noise model");

		comboNoise = new Combo(grpModelSelection, SWT.READ_ONLY);
		comboNoise.setLayoutData(new GridData(SWT.NORMAL, SWT.CENTER, true, true, 1, 1));

		for (NoiseModels s : NoiseModels.values()) {
			comboNoise.add(s.toString());
		}

		comboNoise.select(0);

		btnChannelModels = new Button(grpModelSelection, SWT.RADIO);
		btnChannelModels.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnChannelModels.getSelection()) {
					comboChannelModels.setEnabled(true);
					comboLongControl.setEnabled(false);
					comboLongitudinal.setEnabled(false);
					comboMemory.setEnabled(false);
					comboConsumption.setEnabled(false);
					comboLaneChange.setEnabled(false);
					comboNoise.setEnabled(false);
				}
			}
		});

		btnChannelModels.setText("Channel model");

		comboChannelModels = new Combo(grpModelSelection, SWT.READ_ONLY);
		comboChannelModels.setLayoutData(new GridData(SWT.NORMAL, SWT.CENTER, true, true, 1, 1));

		for (ChannelModels s : ChannelModels.values()) {
			comboChannelModels.add(s.toString());
		}

		comboChannelModels.select(0);

		btnLongControl = new Button(grpModelSelection, SWT.RADIO);
		btnLongControl.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnLongControl.getSelection()) {
					comboChannelModels.setEnabled(false);
					comboLongControl.setEnabled(true);
					comboLongitudinal.setEnabled(false);
					comboMemory.setEnabled(false);
					comboConsumption.setEnabled(false);
					comboLaneChange.setEnabled(false);
					comboNoise.setEnabled(false);
				}
			}
		});

		btnLongControl.setText("Longitudinal control");

		comboLongControl = new Combo(grpModelSelection, SWT.READ_ONLY);
		comboLongControl.setLayoutData(new GridData(SWT.NORMAL, SWT.CENTER, true, true, 1, 1));

		for (LongitudinalControls s : LongitudinalControls.values()) {
			comboLongControl.add(s.toString());
		}

		comboLongControl.select(0);

		btnLongitudinal.setSelection(true);
		comboLongitudinal.setEnabled(true);
		comboChannelModels.setEnabled(false);
		comboLongControl.setEnabled(false);
		comboMemory.setEnabled(false);
		comboConsumption.setEnabled(false);
		comboLaneChange.setEnabled(false);
		comboNoise.setEnabled(false);

		validatePage();
	}

	public File getConfigFile() {
		return new File(textConfigPath.getText());
	}

	@Override
	public IWizardPage getNextPage() {
		if (btnLongitudinal.getSelection()) {
			return getWizard().getPage(ModelGeneratorWizard.PAGE_LONGITUDINAL_MODEL_CONFIGURATION);
		} else if (btnLongControl.getSelection()) {
			if (comboLongControl.getText().compareTo(LongitudinalControls.EHDMM.toString()) == 0) {
				return getWizard().getPage(ModelGeneratorWizard.PAGE_EHDM_LONG_CONTROL_CONFIGURATION);
			} else if (comboLongControl.getText().compareTo(LongitudinalControls.HDMM.toString()) == 0) {
				return getWizard().getPage(ModelGeneratorWizard.PAGE_HDM_LONG_CONTROL_CONFIGURATION);
			} else if (comboLongControl.getText().compareTo(LongitudinalControls.AUTOMAT.toString()) == 0) {
				return getWizard().getPage(ModelGeneratorWizard.PAGE_VEHICLE_AUTOMATION_CONTROL_CONFIGURATION);
			}

			return getWizard().getPage(ModelGeneratorWizard.PAGE_DEFAULT_LONG_CONTROL_CONFIGURATION);
		} else if (btnLaneChange.getSelection()) {
			return getWizard().getPage(ModelGeneratorWizard.PAGE_LANE_CHANGE_MODEL_CONFIGURATION);
		} else if (btnConsumption.getSelection()) {
			return getWizard().getPage(ModelGeneratorWizard.PAGE_CONSUMPTION_MODEL_CONFIGURATION);
		} else if (btnMemory.getSelection()) {
			return getWizard().getPage(ModelGeneratorWizard.PAGE_MEMORY_MODEL_CONFIGURATION);
		} else if (btnNoise.getSelection()) {
			return getWizard().getPage(ModelGeneratorWizard.PAGE_NOISE_MODEL_CONFIGURATION);
		} else if (btnChannelModels.getSelection()) {
			return getWizard().getPage(ModelGeneratorWizard.PAGE_CHANNEL_MODEL_CONFIGURATION);
		}

		// Per default
		return getWizard().getPage(ModelGeneratorWizard.PAGE_LONGITUDINAL_MODEL_CONFIGURATION);
	}

	public String getSelectedModelIdentifier() {
		if (btnLongitudinal.getSelection()) {
			return comboLongitudinal.getText();
		} else if (btnLongControl.getSelection()) {
			return comboLongControl.getText();
		} else if (btnLaneChange.getSelection()) {
			return comboLaneChange.getText();
		} else if (btnConsumption.getSelection()) {
			return comboConsumption.getText();
		} else if (btnMemory.getSelection()) {
			return comboMemory.getText();
		} else if (btnNoise.getSelection()) {
			return comboNoise.getText();
		} else if (btnChannelModels.getSelection()) {
			return comboChannelModels.getText();
		}

		return null;
	}

	@Override
	public boolean isPageComplete() {
		return getErrorMessage() == null;
	}

	private void validatePage() {
		StringBuffer msg = new StringBuffer();

		if (StringUtil.isNullOrEmpty(textConfigPath.getText())) {
			msg.append("Please specify a config file\n");
		} else {
			if (!new File(textConfigPath.getText()).exists()) {
				msg.append("Selected config file does not exist\n");
			}
		}

		setErrorMessage(msg.length() == 0 ? null : msg.toString());
		PreferenceUtil.set(IPreferenceConstants.WIZARD_MODEL_GENERATION_CONFIG_PATH, textConfigPath.getText());
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.ui.part.ViewPart;
import org.jdesktop.swingx.input.CenterMapListener;
import org.jdesktop.swingx.input.PanKeyListener;
import org.jdesktop.swingx.input.ZoomMouseWheelListenerCenter;
import org.jdesktop.swingx.mapviewer.DefaultTileFactory;
import org.jdesktop.swingx.mapviewer.GeoPosition;
import org.jdesktop.swingx.mapviewer.LocalResponseCache;

import at.fhhagenberg.mc.traffsim.model.ISimulationStateListener;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationState;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.ui.DrawingPanel;
import at.fhhagenberg.mc.traffsim.ui.IImageKeys;
import at.fhhagenberg.mc.traffsim.ui.IRouteProvider;
import at.fhhagenberg.mc.traffsim.ui.IRouteUpdateListener;
import at.fhhagenberg.mc.traffsim.ui.IViewInitialisationListener;
import at.fhhagenberg.mc.traffsim.ui.UiConstants;
import at.fhhagenberg.mc.traffsim.ui.UiModel;
import at.fhhagenberg.mc.traffsim.ui.controller.TraffSimController;
import at.fhhagenberg.mc.traffsim.ui.osm.OSMZoom;
import at.fhhagenberg.mc.traffsim.ui.osm.TileType;
import at.fhhagenberg.mc.traffsim.ui.osm.TraffSimTileFactoryProvider;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.ImageUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class SimulationView extends ViewPart implements ISimulationStateListener, IRouteProvider {

	private class InternalDropdownTextUpdater extends SelectionAdapter {
		@Override
		public void widgetSelected(SelectionEvent event) {
			MenuItem selected = (MenuItem) event.widget;
			menuToolItem.setText(selected.getText());
			menuToolItem.setImage(selected.getImage());
			menuToolItem.getParent().pack();
		}
	}

	/**
	 * This internal class is responsible for updating the current simulation time, simulation time span how long simulation is running and
	 * speed factor. It's outsourced in an own thread, which does only update the UI if the last update was processed completely. If all
	 * time updates are scheduled asynchronously and processed one after the other, it may happen that those label update requests queue up
	 * if execution time is too fast. In this case, the time is not displayed correctly and does not stop after simulation is paused or
	 * finished becasue the rest of the display update requests is processed before. Furtheremore, it unnecessarily uses resources of the
	 * display thread
	 *
	 * @author Christian Backfrieder
	 *
	 */
	private class TimeLabelUpdater extends PauseableThread {
		private String factor;

		private String runtime;
		private String time;

		public TimeLabelUpdater(String name, long delayInMillis) {
			super(name, delayInMillis);
		}

		@Override
		public void doWork() {
			getViewSite().getShell().getDisplay().asyncExec(new Runnable() {
				@Override
				public void run() {
					if (time != null && !lblTime.isDisposed() && !lblRuntime.isDisposed() && !lblFactorVal.isDisposed()) {
						lblTime.setText(time);
						lblRuntime.setText(runtime);
						lblRuntime.getParent().layout();
						lblFactorVal.setText("(" + factor + "x)");
					}
				}
			});
		}

		/**
		 * Set new values for the labels, which are only processed if last update was completely executed.
		 *
		 * @param time
		 * @param runtime
		 * @param speedFactor
		 */
		public void scheduleTimeUpdate(final String time, final String runtime, final String speedFactor) {
			this.time = time;
			this.runtime = runtime;
			this.factor = speedFactor;
			// check if last request was finished. If not, skip current update
			// and wait for next
		}

	}

	public static final String ID = "at.fhhagenberg.mc.traffsim.views.simulation";

	private static final TileType INITIAL_TILE_TYPE = TileType.OSMDE;
	private static final String TOOLTIP_START_PAUSE_SIMULATION = "Start/Pause Simulation";
	private Button btnDown;
	private Button btnLeft;
	private Button btnRight;
	private Button btnStartSimulation;
	private Button btnStartSimulationSmall;
	private Button btnUp;
	private Button btnZoomin;
	private Button btnZoomout;

	private Button btnZtf;

	private Composite compositeControl;

	private DrawingPanel drawingPanel;
	private boolean isInitialised;
	private MenuItem itemAddObstruction;
	private MenuItem itemDrag;

	private MenuItem itemSelect;

	private MenuItem itemZoom;

	private Label lblFactorVal;

	private Label lblRuntime;

	private Label lblTime;

	private Composite mainComposite;

	private ToolItem menuToolItem;

	private Composite parent;

	private SimulationModel simulationModel;

	private TimeLabelUpdater timeLabelUpdater;

	private Text txtLevel;

	private UiModel uiModel;

	private Set<IViewInitialisationListener> viewInitialisationListeners;

	private TraffSimController controller;

	private InternalDropdownTextUpdater updater;

	private Spinner spinnerDelay;

	private Button btnShowOsm;

	private Combo comboTileType;

	private Spinner spinnerResolution;
	private Button btnDisableUpdate;
	private Button btnUpdateNow;

	private Font smallFont;

	public SimulationView() {
		timeLabelUpdater = new TimeLabelUpdater("SimulationView TimeLabelUpdater", 100);
		viewInitialisationListeners = new HashSet<>();
	}

	public void addViewInitialisationListner(IViewInitialisationListener listener) {
		if (listener != null && !viewInitialisationListeners.contains(listener)) {
			viewInitialisationListeners.add(listener);
		}
	}

	public Image createAWTImage() {
		if (drawingPanel.getWidth() > 0) {
			return new BufferedImage(Math.max(drawingPanel.getWidth() - 2, 1), Math.max(drawingPanel.getHeight() - 2, 1),
					BufferedImage.TYPE_INT_ARGB);
		}
		return null;
	}

	/**
	 * This is a callback that will allow us to create the viewer and initialize it.
	 */
	@Override
	public void createPartControl(Composite parent) {
		// init(null, null, null); // uncomment this for using window builder
		this.parent = parent;
		parent.addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
				if (uiModel != null) {
					uiModel.updateView(true);
				}
			}
		});
	}

	/**
	 * Must be called immediatelly before disposing the view
	 */
	public void detachListeners() {

	}

	@Override
	public void dispose() {
		// dispose created font to avoid out of handles leak
		smallFont.dispose();

		if (timeLabelUpdater != null) {
			timeLabelUpdater.stopAndDestroy();
		}

		/////// CONTROLLER - be very careful when editing this section! memory leaks are dangerous...
		PreferenceUtil.removePropertyChangeListener(controller);
		uiModel.removeSimulationListener(controller);

		drawingPanel.removeMouseListener(controller);
		drawingPanel.removeMouseWheelListener(controller);
		drawingPanel.removeResizeListener(controller);
		drawingPanel.removeMouseMotionListener(controller);

		itemSelect.removeSelectionListener(controller);
		itemDrag.removeSelectionListener(controller);
		itemZoom.removeSelectionListener(controller);
		itemAddObstruction.removeSelectionListener(controller);

		itemSelect.removeSelectionListener(updater);
		itemDrag.removeSelectionListener(updater);
		itemZoom.removeSelectionListener(updater);
		itemAddObstruction.removeSelectionListener(updater);
		updater = null;

		itemDrag.dispose();
		itemAddObstruction.dispose();
		itemZoom.dispose();
		itemSelect.dispose();

		PreferenceUtil.removePropertyChangeListener(controller);
		drawingPanel.removeMouseListener(controller);
		drawingPanel.removeMouseWheelListener(controller);
		drawingPanel.removeResizeListener(controller);
		drawingPanel.removeMouseMotionListener(controller);
		uiModel.removeSimulationListener(controller);
		////// END of CONTROLLER
		simulationModel.removeSimulationStateListener(this);

		if (simulationModel != null) {
			simulationModel = null;
		}
		uiModel = null;
		super.dispose();
	}

	public void drawZoomRectangle(Rectangle _rect) {
		drawingPanel.setZoomRectangle(_rect);
	}

	@Override
	public List<IRoute> getAllRoutes() {
		if (simulationModel != null) {
			Map<Long, IRoute> routes = simulationModel.getRouteRegistry().getRoutes();
			return routes != null ? new ArrayList<>(routes.values()) : new ArrayList<>();
		}

		return new ArrayList<>();
	}

	@Override
	public List<IRoute> getAvailableRoutes() {
		if (simulationModel != null) {
			Collection<Vehicle> vehicles = simulationModel.getVehiclesInSimulation(false);
			return RoutingUtil.getVehicleRoutes(vehicles);
		}

		return new ArrayList<>();
	}

	public DrawingPanel getDrawingPanel() {
		return drawingPanel;
	}

	public Dimension getDrawingSize() {
		return drawingPanel.getSize();
	}

	public Image getImage() {
		return drawingPanel.getImage();
	}

	public UiModel getModel() {
		return uiModel;
	}

	@Override
	public String getName() {
		return getPartName();
	}

	private void hideControls(boolean hide) {
		((GridData) compositeControl.getLayoutData()).exclude = hide;
		compositeControl.setVisible(!hide);
		mainComposite.layout(true);
		btnStartSimulationSmall.setVisible(hide);
		String img = simulationModel != null && simulationModel.isSimulationRunning() ? IImageKeys.PAUSE : IImageKeys.PLAY;
		btnStartSimulationSmall.setImage(ImageUtil.getSWTImage(img));
		btnStartSimulation.setImage(ImageUtil.getSWTImage(img));
		TraffSimCorePlugin.getDefault().getPreferenceStore().setValue(IPreferenceConstants.HIDE_CONTROLS_ON_START, hide);
	}

	public void init(UiModel uiModel, SimulationModel simModel, TraffSimController controller) {
		this.simulationModel = simModel;
		this.uiModel = uiModel;
		this.controller = controller;
		controller.setView(this);

		mainComposite = new Composite(parent, SWT.None);
		mainComposite.setLayout(new GridLayout(1, false));

		final Composite drawingContainer = new Composite(mainComposite, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		drawingContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		drawingContainer.setLayout(new FillLayout());
		Frame f = SWT_AWT.new_Frame(drawingContainer);
		Panel rootPane = new Panel();
		rootPane.setLayout(new BorderLayout());
		drawingPanel = new DrawingPanel();

		// ////////////

		DefaultTileFactory tileFactory = TraffSimTileFactoryProvider.getTileFactory(INITIAL_TILE_TYPE);

		File cacheDir = new File(System.getProperty("user.home") + File.separator + ".jxmapviewer2");
		LocalResponseCache.installResponseCache(tileFactory.getInfo().getBaseURL(), cacheDir, false);

		drawingPanel.setTileFactory(tileFactory);

		drawingPanel.addMouseListener(new CenterMapListener(drawingPanel));
		drawingPanel.addMouseWheelListener(new ZoomMouseWheelListenerCenter(drawingPanel));
		drawingPanel.addKeyListener(new PanKeyListener(drawingPanel));
		uiModel.setTileType(INITIAL_TILE_TYPE);

		drawingPanel.setZoom(4);
		uiModel.zoomScale(OSMZoom.SCALES_OSM[5]);
		// ////////////

		rootPane.add(drawingPanel);
		f.add(rootPane);

		compositeControl = new Composite(mainComposite, SWT.NONE);
		compositeControl.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		GridLayout gl_compositeControl = new GridLayout(7, false);
		gl_compositeControl.marginHeight = 1;
		gl_compositeControl.verticalSpacing = 2;
		compositeControl.setLayout(gl_compositeControl);

		Group grpMouse = new Group(compositeControl, SWT.NONE);
		grpMouse.setLayout(new GridLayout(1, false));
		grpMouse.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));
		grpMouse.setText("Mouse");

		final ToolBar toolBar = new ToolBar(grpMouse, SWT.FLAT | SWT.RIGHT);
		final Menu menu = new Menu(toolBar.getShell(), SWT.POP_UP);
		menuToolItem = new ToolItem(toolBar, SWT.DROP_DOWN);
		menuToolItem.setText("Select ");
		menuToolItem.setImage(ImageUtil.getSWTImage(IImageKeys.CURSOR_SELECT));
		menuToolItem.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(Event event) {
				org.eclipse.swt.graphics.Rectangle rect = menuToolItem.getBounds();
				Point pt = new Point(rect.x, rect.y + rect.height);
				pt = toolBar.toDisplay(pt);
				menu.setLocation(pt.x, pt.y);
				menu.setVisible(true);
			}
		});
		toolBar.pack();
		updater = new InternalDropdownTextUpdater();
		itemSelect = new MenuItem(menu, SWT.PUSH);
		itemSelect.setText("Select");
		itemSelect.setData(UiConstants.ACTION_MOUSE_SELECT);
		itemSelect.setImage(ImageUtil.getSWTImage(IImageKeys.CURSOR_SELECT));
		itemDrag = new MenuItem(menu, SWT.PUSH);
		itemDrag.setText("Drag");
		itemDrag.setData(UiConstants.ACTION_MOUSE_DRAG);
		itemDrag.setImage(ImageUtil.getSWTImage(IImageKeys.CURSOR_DRAG));
		itemZoom = new MenuItem(menu, SWT.PUSH);
		itemZoom.setText("Zoom");
		itemZoom.setData(UiConstants.ACTION_MOUSE_ZOOM);
		itemZoom.setImage(ImageUtil.getSWTImage(IImageKeys.CURSOR_ZOOM));
		itemAddObstruction = new MenuItem(menu, SWT.PUSH);
		itemAddObstruction.setText("Obstacle");
		itemAddObstruction.setData(UiConstants.ACTION_MOUSE_ADD_OBSTRUCTION);
		itemSelect.addSelectionListener(updater);
		itemDrag.addSelectionListener(updater);
		itemZoom.addSelectionListener(updater);
		itemAddObstruction.addSelectionListener(updater);
		itemAddObstruction.setImage(ImageUtil.getSWTImage(IImageKeys.CURSOR_OBSTACLE));

		Group grpScroll = new Group(compositeControl, SWT.NONE);
		grpScroll.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));
		grpScroll.setText("Scroll");
		GridLayout gl_grpScroll = new GridLayout(3, true);
		gl_grpScroll.verticalSpacing = 0;
		gl_grpScroll.marginHeight = 0;
		grpScroll.setLayout(gl_grpScroll);

		btnLeft = new Button(grpScroll, SWT.NONE);
		btnLeft.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnLeft.setText("  \u2190  ");
		btnLeft.setData(UiConstants.ACTION_SCROLL_LEFT);

		Composite composite_1 = new Composite(grpScroll, SWT.NONE);
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		GridLayout gl_composite_1 = new GridLayout(1, false);
		gl_composite_1.horizontalSpacing = 0;
		gl_composite_1.verticalSpacing = 0;
		gl_composite_1.marginWidth = 0;
		gl_composite_1.marginHeight = 0;
		composite_1.setLayout(gl_composite_1);

		btnUp = new Button(composite_1, SWT.NONE);
		btnUp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		btnUp.setText("\u2191");
		btnUp.setData(UiConstants.ACTION_SCROLL_UP);

		btnDown = new Button(composite_1, SWT.NONE);
		btnDown.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		btnDown.setText("\u2193");
		btnDown.setData(UiConstants.ACTION_SCROLL_DOWN);

		btnRight = new Button(grpScroll, SWT.NONE);
		btnRight.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnRight.setText("\u2192");
		btnRight.setData(UiConstants.ACTION_SCROLL_RIGHT);

		Group grpZoom = new Group(compositeControl, SWT.NONE);
		grpZoom.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));
		grpZoom.setText("Zoom");
		GridLayout gl_grpZoom = new GridLayout(2, true);
		gl_grpZoom.verticalSpacing = 0;
		grpZoom.setLayout(gl_grpZoom);

		btnZoomin = new Button(grpZoom, SWT.NONE);
		btnZoomin.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnZoomin.setText("+");
		btnZoomin.setData(UiConstants.ACTION_ZOOM_IN);

		btnZtf = new Button(grpZoom, SWT.NONE);
		btnZtf.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnZtf.setText("Fit");
		btnZtf.setData(UiConstants.ACTION_ZOOM_TO_FIT);

		btnZoomout = new Button(grpZoom, SWT.NONE);
		btnZoomout.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnZoomout.setText("-");
		btnZoomout.setData(UiConstants.ACTION_ZOOM_OUT);

		txtLevel = new Text(grpZoom, SWT.BORDER);
		txtLevel.setEditable(true);
		GridData gd_txtLevel = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_txtLevel.widthHint = 45;
		txtLevel.setLayoutData(gd_txtLevel);
		txtLevel.setData(UiConstants.FIELD_SCALE);

		Group grpGrpsimulation = new Group(compositeControl, SWT.NONE);
		grpGrpsimulation.setText("Simulation");
		grpGrpsimulation.setLayout(new GridLayout(3, false));
		grpGrpsimulation.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));

		btnStartSimulation = new Button(grpGrpsimulation, SWT.NONE);
		GridData gd_btnStartsimulation = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2);
		gd_btnStartsimulation.minimumWidth = 40;
		btnStartSimulation.setLayoutData(gd_btnStartsimulation);
		btnStartSimulation.setData(UiConstants.ACTION_START_SIMULATION);
		btnStartSimulation.setImage(ImageUtil.getSWTImage(IImageKeys.PLAY));
		btnStartSimulation.setToolTipText(TOOLTIP_START_PAUSE_SIMULATION);
		btnStartSimulation.setEnabled(false);

		Label lblTimestepms = new Label(grpGrpsimulation, SWT.NONE);
		lblTimestepms.setToolTipText("The waiting time between two simulation runs in ms (useful for slow UI investigations)");
		lblTimestepms.setText("Delay (ms)");

		spinnerDelay = new Spinner(grpGrpsimulation, SWT.BORDER);
		spinnerDelay.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerDelay.setTextLimit(6);
		spinnerDelay.setValues(PreferenceUtil.getInt(IPreferenceConstants.SIMULATION_DELAY_MS), 0, 5000, 0, 1, 10);
		spinnerDelay.setData(UiConstants.ACTION_DELAY);

		Label lblResolution = new Label(grpGrpsimulation, SWT.NONE);
		lblResolution.setToolTipText("The time step between two simulation runs (i.e. the update interval of calculations)");
		lblResolution.setText("Resolution (ms)");

		spinnerResolution = new Spinner(grpGrpsimulation, SWT.BORDER);
		spinnerResolution.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerResolution.setMaximum(250);
		spinnerResolution.setToolTipText("ATTENTION: too high values may lead to accidents");
		spinnerResolution.setMinimum(1);
		spinnerResolution.setSelection((int) uiModel.getSimulationResolution());
		spinnerResolution.setIncrement(5);
		spinnerResolution.setData(UiConstants.ACTION_RESOLUTION);

		Group grpUiUpdate = new Group(compositeControl, SWT.NONE);
		grpUiUpdate.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1));
		grpUiUpdate.setText("UI Update");
		grpUiUpdate.setLayout(new GridLayout(2, false));

		Label lblInterval = new Label(grpUiUpdate, SWT.NONE);
		lblInterval.setText("Interval (ms)");

		Spinner spinnerUpdateInterval = new Spinner(grpUiUpdate, SWT.BORDER);
		spinnerUpdateInterval.setMaximum(100000);
		spinnerUpdateInterval.setMinimum(1);
		spinnerUpdateInterval.setSelection(PreferenceUtil.getInt(IPreferenceConstants.UI_UPDATE_TIME));
		spinnerUpdateInterval.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				SimulationView.this.uiModel.setUiUpdateTime(spinnerUpdateInterval.getSelection());
			}
		});
		spinnerUpdateInterval.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));

		btnDisableUpdate = new Button(grpUiUpdate, SWT.CHECK);
		btnDisableUpdate.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				boolean disabled = btnDisableUpdate.getSelection();
				spinnerUpdateInterval.setEnabled(!disabled);
				if (disabled) {
					SimulationView.this.uiModel.setUiUpdateTime(Integer.MAX_VALUE);
				} else {
					SimulationView.this.uiModel.setUiUpdateTime(spinnerUpdateInterval.getSelection());
				}
			}
		});
		boolean uiUpdateEnabled = PreferenceUtil.getBoolean(IPreferenceConstants.UI_UPDATE_ENABLED);
		btnDisableUpdate.setSelection(!uiUpdateEnabled);
		spinnerUpdateInterval.setEnabled(uiUpdateEnabled);
		btnDisableUpdate.setToolTipText("Disable the automatic UI update");
		btnDisableUpdate.setText("Disable");

		btnUpdateNow = new Button(grpUiUpdate, SWT.NONE);
		btnUpdateNow.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				uiModel.updateView(true);
			}
		});
		btnUpdateNow.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnUpdateNow.setText("Update Now");

		Group grpLookAndFeel = new Group(compositeControl, SWT.NONE);
		grpLookAndFeel.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, true, 1, 1));
		grpLookAndFeel.setText("Look and Feel");
		grpLookAndFeel.setLayout(new GridLayout(1, false));

		btnShowOsm = new Button(grpLookAndFeel, SWT.CHECK);
		btnShowOsm.setText("Show Map");
		btnShowOsm.setToolTipText("OpenStreetMap background and fit to OSM zoom levels");
		btnShowOsm.setData(UiConstants.ACTION_SHOW_OSM_MAP);

		comboTileType = new Combo(grpLookAndFeel, SWT.READ_ONLY);
		comboTileType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		comboTileType.setData(UiConstants.ACTION_TILE_TYPE_CHANGE);
		btnShowOsm.addSelectionListener(controller);
		comboTileType.addSelectionListener(controller);
		for (TileType tt : EnumSet.allOf(TileType.class)) {
			comboTileType.add(tt.toString());
		}
		comboTileType.select(0);
		Composite compositeSmallControl = new Composite(mainComposite, SWT.NONE);
		compositeSmallControl.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		GridLayout gl_compositeSmallControl = new GridLayout(7, false);
		gl_compositeSmallControl.verticalSpacing = 2;
		gl_compositeSmallControl.marginHeight = 0;
		compositeSmallControl.setLayout(gl_compositeSmallControl);

		IPreferenceStore prefStore = TraffSimCorePlugin.getDefault().getPreferenceStore();
		prefStore.setDefault(IPreferenceConstants.HIDE_CONTROLS_ON_START, true);
		boolean hide = prefStore.getBoolean(IPreferenceConstants.HIDE_CONTROLS_ON_START);

		Button b_1 = new Button(compositeSmallControl, SWT.CHECK);
		b_1.setText("Hide Controls");
		b_1.setSelection(hide);

		btnStartSimulationSmall = new Button(compositeSmallControl, SWT.NONE);
		btnStartSimulationSmall.setData(UiConstants.ACTION_START_SIMULATION);
		btnStartSimulationSmall.setImage(ImageUtil.getSWTImage(IImageKeys.PLAY));
		btnStartSimulationSmall.setVisible(false);
		btnStartSimulationSmall.setToolTipText(TOOLTIP_START_PAUSE_SIMULATION);

		lblTime = new Label(compositeSmallControl, SWT.NONE);
		lblTime.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));
		lblTime.setToolTipText("Time in Simulation");
		FontData[] fd = lblTime.getFont().getFontData();
		fd[0].setHeight(8);
		smallFont = new Font(lblTime.getDisplay(), fd[0]);
		lblTime.setFont(smallFont);

		String rtTooltip = "Effective runtime of simulation";

		Label clockImage = new Label(compositeSmallControl, SWT.NONE);
		clockImage.setImage(ImageUtil.getSWTImage(IImageKeys.CLOCK_PLAY));
		clockImage.setToolTipText(rtTooltip);
		lblRuntime = new Label(compositeSmallControl, SWT.NONE);
		lblRuntime.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRuntime.setToolTipText(rtTooltip);
		lblRuntime.setFont(smallFont);

		lblFactorVal = new Label(compositeSmallControl, SWT.NONE);
		lblFactorVal.setFont(smallFont);
		new Label(compositeSmallControl, SWT.NONE);

		b_1.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(Event e) {
				Button b = (Button) e.widget;
				hideControls(b.getSelection());
			}
		});

		PreferenceUtil.addPropertyChangeListener(controller);
		uiModel.addSimulationListener(controller);
		mainComposite.addControlListener(controller);
		spinnerResolution.addSelectionListener(controller);
		spinnerDelay.addSelectionListener(controller);

		drawingPanel.addMouseListener(controller);
		drawingPanel.addMouseWheelListener(controller);
		drawingPanel.addResizeListener(controller);
		drawingPanel.addMouseMotionListener(controller);

		itemSelect.addSelectionListener(controller);
		itemDrag.addSelectionListener(controller);
		itemZoom.addSelectionListener(controller);
		itemAddObstruction.addSelectionListener(controller);
		btnZtf.addSelectionListener(controller);
		btnZoomout.addSelectionListener(controller);
		txtLevel.addKeyListener(controller);
		btnLeft.addSelectionListener(controller);
		btnUp.addSelectionListener(controller);
		btnDown.addSelectionListener(controller);
		btnRight.addSelectionListener(controller);
		btnZoomin.addSelectionListener(controller);
		btnStartSimulation.addSelectionListener(controller);
		btnStartSimulationSmall.addSelectionListener(controller);
		hideControls(hide);
		parent.layout();

		simulationModel.addSimulationStateListener(this);
		isInitialised = true;
	}

	@Override
	public boolean isInitialized() {
		return isInitialised;
	}

	private void notifyViewInitialised() {
		for (IViewInitialisationListener listener : viewInitialisationListeners) {
			listener.onViewInitialised(this);
		}
	}

	@Override
	public void preSimulationStateChanged(final SimulationModel model, final SimulationState oldState, final SimulationState newState) {
		getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				switch (newState) {
				case INITIAL:
				case LOADING:
					btnStartSimulation.setEnabled(false);
					btnStartSimulationSmall.setEnabled(false);
					break;
				case LOADED:
					btnStartSimulation.setEnabled(true);
					btnStartSimulationSmall.setEnabled(true);
					break;
				case STARTED:
					timeLabelUpdater.start();
				case CONTINUED:
					timeLabelUpdater.proceed();
					if (!btnStartSimulation.isDisposed()) {
						btnStartSimulation.setImage(ImageUtil.getSWTImage(IImageKeys.PAUSE));
						btnStartSimulationSmall.setImage(ImageUtil.getSWTImage(IImageKeys.PAUSE));
					}
					break;
				case ABORTED:
				case COMPLETED:
				case ENDED:
					// check disposed, because it may happen that finished event
					// is notified because of application close
					timeLabelUpdater.stopAndDestroy(true);
					if (!btnStartSimulation.isDisposed()) {
						btnStartSimulation.setImage(ImageUtil.getSWTImage(IImageKeys.STOP));
						btnStartSimulation.setEnabled(false);
						btnStartSimulationSmall.setImage(ImageUtil.getSWTImage(IImageKeys.STOP));
						btnStartSimulationSmall.setEnabled(false);
					}
					break;
				case PAUSED:
					timeLabelUpdater.pause();
					if (!btnStartSimulation.isDisposed()) {
						btnStartSimulation.setImage(ImageUtil.getSWTImage(IImageKeys.PLAY));
						btnStartSimulationSmall.setImage(ImageUtil.getSWTImage(IImageKeys.PLAY));
					}
					break;
				default:
					break;

				}
			}
		});
	}

	public void removeViewInitialisationListener(IViewInitialisationListener listener) {
		if (listener != null && viewInitialisationListeners.contains(listener)) {
			viewInitialisationListeners.remove(listener);
		}
	}

	public void setCenterPoint(double lat, double lng) {
		GeoPosition pos = new GeoPosition(lat, lng);

		drawingPanel.setAddressLocation(pos);

		// drawingPanel.setZoom(5);

	}

	public void setDescriptionString(final String desc) {
		if (getViewSite() != null) {
			getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					setTitleToolTip(desc);
				}
			});
		}
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	@Override
	public void setFocus() {
	}

	/**
	 * Set image to draw in drawing area
	 *
	 * @param _image
	 */
	public void setImage(Image _image) {
		drawingPanel.setZoom(uiModel.getOsmZoomLevel());
		drawingPanel.setImage(_image);
	}

	public void setModel(UiModel model) {
		this.uiModel = model;
	}

	public void setNameString(final String name) {
		if (getViewSite() != null) {
			getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

				@Override
				public void run() {
					setPartName(name);
					notifyViewInitialised();
				}
			});
		}
	}

	public void setScale(final int _newScale) {
		Display.getDefault().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (!txtLevel.isDisposed()) {
					txtLevel.setText(UiConstants.SCALE_PREFIX + _newScale);
				}
			}
		});
	}

	public void setTimes(final String time, final String runtime, final String speedFactor) {
		timeLabelUpdater.scheduleTimeUpdate(time, runtime, speedFactor);
	}

	@Override
	public void setUpdateListener(IRouteUpdateListener listener) {
		// TODO Auto-generated method stub
	}

	@Override
	public void simulationStateChanged(final SimulationModel model, SimulationState oldState, SimulationState newState) {
		// unused
	}

	public void updateResolutionAndDelay(int resolution, int delay) {
		getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (resolution > 0) {
					spinnerResolution.setSelection(resolution);
				}
				if (delay > 0) {
					spinnerDelay.setSelection(delay);
				}
			}
		});
	}
}
package at.fhhagenberg.mc.traffsim.ui.rcp;

import java.io.File;
import java.util.Properties;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class ApplicationWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {

	public ApplicationWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		super(configurer);
	}

	public ActionBarAdvisor createActionBarAdvisor(IActionBarConfigurer configurer) {
		return new ApplicationActionBarAdvisor(configurer);
	}

	public void preWindowOpen() {
		IWorkbenchWindowConfigurer configurer = getWindowConfigurer();
		configurer.setShowCoolBar(true);
		configurer.setTitle("TraffSim     v "+SimulationKernel.getTraffSimVersionInfo());
		configurer.setShowProgressIndicator(true);
		PreferenceUtil.initializeDefaultPreferences();
	}

	@Override
	public void postWindowOpen() {
		IPreferenceStore prefStore = TraffSimCorePlugin.getDefault().getPreferenceStore();
		if (prefStore.getBoolean(IPreferenceConstants.LOAD_FILE_ON_STARTUP)) {
			File f = new File(prefStore.getString(IPreferenceConstants.FILE_TO_LOAD_ON_STARTUP));
			if (f.exists()) {
				Properties properties = new Properties();
				properties.put(PropertyKeys.RESET_GEOMETRY, PreferenceUtil.getBoolean(IPreferenceConstants.RESET_GEOMETRY_ON_LOAD));
				properties.put(PropertyKeys.GLOBAL_OUTPUT_FOLDER, PreferenceUtil.getString(IPreferenceConstants.GLOBAL_OUTPUT_FOLDER));
				SimulationKernel.getInstance().createNewSimulation(f, properties);
			}
		}
	}

}

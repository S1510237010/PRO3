package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data;

import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IPlatoonLongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalControlData;

public class PlatoonLongitudinalControlData extends LongitudinalControlData {

	/**
	 * Leader longitudinal model
	 */
	private ILongitudinalModel leaderLongitudinalModel = null;

	/**
	 * Follower longitudinal model
	 */
	private IPlatoonLongitudinalModel followerLongitudinalModel = null;

	/**
	 * Maneuver longitudinal model
	 */
	private ILongitudinalModel maneuverLongitudinalModel = null;

	/**
	 * Human longitudinal model
	 */
	private ILongitudinalModel humanLongitudinalModel = null;

	/**
	 * Get leader longitudinal model
	 *
	 * @return model
	 */
	public ILongitudinalModel getLeaderLongitudinalModel() {
		return leaderLongitudinalModel;
	}

	/**
	 * Set leader longitudinal model
	 *
	 * @param leaderLongitudinalModel
	 *            model
	 */
	public void setLeaderLongitudinalModel(ILongitudinalModel leaderLongitudinalModel) {
		this.leaderLongitudinalModel = leaderLongitudinalModel;
	}

	/**
	 * Get follower longitudinal model
	 *
	 * @return model
	 */
	public IPlatoonLongitudinalModel getFollowerLongitudinalModel() {
		return followerLongitudinalModel;
	}

	/**
	 * Set follower longitudinal model
	 *
	 * @param followerLongitudinalModel
	 *            model
	 */
	public void setFollowerLongitudinalModel(IPlatoonLongitudinalModel followerLongitudinalModel) {
		this.followerLongitudinalModel = followerLongitudinalModel;
	}

	/**
	 * Get maneuver longitudinal model
	 *
	 * @return model
	 */
	public ILongitudinalModel getManeuverLongitudinalModel() {
		return maneuverLongitudinalModel;
	}

	/**
	 * Set maneuver longitudinal model
	 *
	 * @param maneuverLongitudinalModel
	 *            model
	 */
	public void setManeuverLongitudinalModel(ILongitudinalModel maneuverLongitudinalModel) {
		this.maneuverLongitudinalModel = maneuverLongitudinalModel;
	}

	/**
	 * Get human longitudinal model
	 *
	 * @return model
	 */
	public ILongitudinalModel getHumanLongitudinalModel() {
		return humanLongitudinalModel;
	}

	/**
	 * Set human longitudinal model
	 *
	 * @param humanLongitudinalModel
	 *            model
	 */
	public void setHumanLongitudinalModel(ILongitudinalModel humanLongitudinalModel) {
		this.humanLongitudinalModel = humanLongitudinalModel;
	}
}

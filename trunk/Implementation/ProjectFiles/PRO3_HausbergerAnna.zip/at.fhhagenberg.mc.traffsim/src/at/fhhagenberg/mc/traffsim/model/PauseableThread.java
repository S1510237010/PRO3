package at.fhhagenberg.mc.traffsim.model;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.log.Logger;

/**
 * Abstract base class for tasks that are to be done cyclically by a thread. The delay in each loop cycle can be defined.
 *
 * Subclasses must implement {@link #doWork()} method where the tasks to be done can be defined. The thread is pausable and waits passively
 * until {@link #proceed()} is called.
 *
 * @author Christian B.
 *
 */
public abstract class PauseableThread extends Thread {
	private static final String PAUSED_SUFFIX = " (paused)";
	private static final String STOPPED_SUFFIX = " (stopping)";
	AtomicBoolean pause = new AtomicBoolean(false);
	AtomicBoolean stopped = new AtomicBoolean(false);
	AtomicBoolean sleeping = new AtomicBoolean(false);
	AtomicInteger runsBeforePause = new AtomicInteger(0);
	private long delayInMillis;
	/**
	 * flag indicating that all tasks have been finished and stop is really executed
	 */
	private AtomicBoolean stopCompleted = new AtomicBoolean(false);

	private final Object lockObj = new Object();

	public PauseableThread(String name, long delayInMillis) {
		super(name);
		this.delayInMillis = delayInMillis;
	}

	@Override
	public void run() {
		try {
			init();
			while (!stopped.get()) {
				if (!pause.get() || (pause.get() && runsBeforePause.get() > 0)) {
					doWork();
					if (runsBeforePause.get() > 0) {
						runsBeforePause.decrementAndGet();
					}
				}
				try {
					if (delayInMillis > 0) {
						sleeping.set(true);
						sleep(delayInMillis);
					}
					synchronized (lockObj) {
						while (pause.get() && runsBeforePause.get() <= 0) {
							lockObj.wait();
						}
					}
				} catch (InterruptedException e) {
					if (sleeping.get()) {
						sleeping.set(false);
					} else if (!stopped.get()) {
						// not intentionally stopped -> show error
						Logger.logError(getName() + " interrupted unexpectedly", e);
					}
				} finally {
					sleeping.set(false);
				}
			}
			stopCompleted.set(true);
		} catch (final Exception ex) {
			Display.getDefault().asyncExec(new Runnable() {

				@Override
				public void run() {
					MessageDialog.openError(Display.getDefault().getActiveShell(), "Error", "Error in worker " + getName() + ": " + ex.getMessage());
				}
			});
			Logger.logError("Error in worker " + getName(), ex);
		} finally {
			stopAndDestroy();
			// Logger.logInfo("Thread '" + getName() + "' terminated.");
		}
	}

	public void init() {
		// intended to override if initialization should be done
	}

	/**
	 * Perform the work to be done in each loop cycle
	 */
	public abstract void doWork();

	/**
	 * Pause this thread after the current loop cycle is finished
	 */
	public void pause() {
		if (!isPaused() && !stopped.get()) {
			setName(getName() + PAUSED_SUFFIX);
			pause.set(true);
		}
	}

	/**
	 * Pause the thread after a specific number of runs from now on. The {@link #doWork()} method is executed x times before going to paused
	 * state.
	 *
	 * @param numRunsBeforePause
	 *            the number of runs to execute before moving this thread in pause mode
	 */
	public void pauseAfter(int numRunsBeforePause) {
		runsBeforePause.set(numRunsBeforePause);
		pause.set(true);
	}

	/**
	 * Continue with work (after thread wakes up from current sleep cycle, if sleeping)
	 */
	public void proceed() {
		proceed(false);
	}

	/**
	 * Continue with work
	 *
	 * @param interruptSleep
	 *            <ul>
	 *            <li>if <code>true</code>, interrupt this thread if it is currently sleeping and continue work immediately</li>
	 *            <li>if <code>false</code>, it waits until it wakes up again)</li>
	 *            </ul>
	 */
	public void proceed(boolean interruptSleep) {
		if (getName().contains(PAUSED_SUFFIX)) {
			setName(getName().replace(PAUSED_SUFFIX, "").trim());
		}
		if (sleeping.get() && interruptSleep) {
			interrupt();
		}
		pause.set(false);
		synchronized (lockObj) {
			lockObj.notify();
		}
	}

	/**
	 * Determine if this thread is in paused state
	 *
	 * @return true if paused, false otherwise
	 */
	public boolean isPaused() {
		return pause.get();
	}

	public long getDelayInMillis() {
		return delayInMillis;
	}

	/**
	 * Set the delay for the endless loop
	 *
	 * @param delayInMillis
	 */
	public void setDelayInMillis(long delayInMillis) {
		this.delayInMillis = delayInMillis;
	}

	/**
	 * As soon as the working thread is not needed any more, this method should be called to destroy the thread. After stopping the thread,
	 * {@link #performFinish()} is called.
	 * <p>
	 * <b>NOTE:</b> This method can only be called <b>once</b>, all operations after this call won't trigger any actions any more and the
	 * thread will not wait for another call of {@link #proceed()}.
	 *
	 * @param ignoreCompletedFlag
	 *            do not wait until stop is completed (e.g. if this thread should be terminated before starting it), but execute
	 *            {@link #performFinish()} immediately
	 *
	 */
	public final void stopAndDestroy(boolean ignoreCompletedFlag) {
		if (!stopped.get()) {
			preStop();
			stopped.set(true);
			stopInitiated();
			interrupt();
			setName(getName() + STOPPED_SUFFIX);
			proceed();
			AtomicInteger waited = new AtomicInteger(50); // 5 seconds to wait
			// Logger.logInfo("Waiting to stop " + getName() + " ...");
			try {
				while (!stopCompleted.get() && isAlive() && !ignoreCompletedFlag) {
					if (waited.get() > 0) {
						Thread.sleep(100);
						waited.decrementAndGet();
						proceed();
					} else {
						break;
					}
				}
				join();
			} catch (InterruptedException e) {
				if (!stopCompleted.get()) {
					Logger.logWarn("Waiting for stop completed was interrupted (" + getName() + ")");
				}
			}
			performFinish();
		}
	}

	/**
	 * @see #stopAndDestroy(boolean) default parameter: ignorecompletedFlag <code>false</code>
	 */
	public final void stopAndDestroy() {
		stopAndDestroy(false);
	}

	/**
	 * Intended to override. This method can include tasks which are executed after the thread has been stopped.
	 */
	public void performFinish() {
	}

	@Override
	public String toString() {
		return getName();
	}

	public final void startPaused() {
		pause.set(true);
		start();
	}

	/**
	 * Convenience method which pauses for a specified amount of ms
	 *
	 * @param millis
	 */
	public final void pause(long millis) {
		try {
			sleep(millis);
		} catch (InterruptedException e) {
			if (!stopped.get()) {
				Logger.logWarn("Unexpected interruption of thread " + getName());
			}
		}
	}

	@Override
	public synchronized void start() {
		preStart();
		if (!isAlive()) {
			super.start();
		}
	}

	protected void preStart() {
		// operations to be done before start
	}

	public final boolean isStopped() {
		return stopped.get();
	}

	protected void preStop() {
		// operations to be done before stop
	}

	/**
	 * Stop has already been initiated (flag set)
	 */
	protected void stopInitiated() {
		// intended for override
	}

}

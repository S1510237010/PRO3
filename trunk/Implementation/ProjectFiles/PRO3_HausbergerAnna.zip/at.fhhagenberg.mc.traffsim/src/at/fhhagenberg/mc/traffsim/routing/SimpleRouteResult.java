package at.fhhagenberg.mc.traffsim.routing;

import java.util.List;

public class SimpleRouteResult {

	protected List<Long> routingIds;
	protected List<Boolean> reverse;
	protected List<Float> cost;

	public SimpleRouteResult() {
	}

	public SimpleRouteResult(List<Long> routingIds, List<Boolean> reverse, List<Float> cost) {
		this.routingIds = routingIds;
		this.reverse = reverse;
		this.cost = cost;
	}

	public List<Long> getRoutingIds() {
		return routingIds;
	}

	public List<Float> getCost() {
		return cost;
	}

	public List<Boolean> getReverse() {
		return reverse;
	}

	public double getCostSum() {
		double sum = 0;
		for (Float c : cost) {
			sum += c;
		}
		return sum;
	}

	@Override
	public String toString() {
		return "RouteIDs: " + routingIds.toString();
	}

}

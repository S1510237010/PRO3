package at.fhhagenberg.mc.traffsim.ui;

import java.util.List;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 *
 * This input dialog provides a field to edit and a checkbox
 *
 */
public class FindItemDialog extends Dialog {

	private Text text;

	private ItemType selected = ItemType.SELFDETECT;

	private Location zoomLocation;

	private Label lblError;

	private enum ItemType {
		SELFDETECT, VEHICLE, ROADSEGMENT, JUNCTION, ROUTING_ID
	}

	/**
	 *
	 * Constructor.
	 *
	 * @param parentShell
	 * @param dialogTitle
	 */
	public FindItemDialog(Shell parentShell, String dialogTitle) {
		super(parentShell);
	}

	/**
	 *
	 * @see org.eclipse.jface.dialogs.Dialog#createContents(org.eclipse.swt.widgets.Composite)
	 *
	 * @param parent
	 * @return the control
	 */
	@Override
	protected Control createContents(Composite parent) {
		parent.setLayout(new FillLayout());
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(2, false));

		Group grpItem = new Group(container, SWT.NONE);
		grpItem.setLayout(new GridLayout(2, false));
		grpItem.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpItem.setText("Item");

		Button btnSelfdetect = new Button(grpItem, SWT.RADIO);
		btnSelfdetect.setSelection(true);
		btnSelfdetect.setBounds(0, 0, 90, 16);
		btnSelfdetect.setText("Self-Detect");
		new Label(grpItem, SWT.NONE);

		Button btnRoadSegment = new Button(grpItem, SWT.RADIO);
		btnRoadSegment.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selected = ItemType.ROADSEGMENT;
			}
		});
		btnRoadSegment.setBounds(0, 0, 90, 16);
		btnRoadSegment.setText("Road Segment");

		Button btnJunction = new Button(grpItem, SWT.RADIO);
		btnJunction.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selected = ItemType.JUNCTION;
			}
		});
		btnJunction.setBounds(0, 0, 90, 16);
		btnJunction.setText("Junction");

		Button btnRoutingid = new Button(grpItem, SWT.RADIO);
		btnRoutingid.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selected = ItemType.ROUTING_ID;
			}
		});
		btnRoutingid.setText("Routing-ID");

		Button btnVehicle = new Button(grpItem, SWT.RADIO);
		btnVehicle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selected = ItemType.VEHICLE;
			}
		});
		btnVehicle.setBounds(0, 0, 90, 16);
		btnVehicle.setText("Vehicle");

		Label lblId = new Label(container, SWT.NONE);
		lblId.setText("ID:");

		text = new Text(container, SWT.BORDER);
		text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.keyCode == SWT.CR || e.keyCode == SWT.KEYPAD_CR) {
					findItem(text.getText());
					if (zoomLocation == null) {
						lblError.setText("Not found: " + text.getText());
					} else {
						close();
					}
				} else {
					// filter alphanumerics
					final String current = text.getText();
					final String newStr = text.getText().replaceAll("[^\\d.-]", "");
					if (!current.equals(newStr)) {
						text.setText(newStr);
					}
				}
			}
		});
		text.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		text.setFocus();
		lblError = new Label(container, SWT.NONE);
		lblError.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblError.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		Composite composite = new Composite(container, SWT.NONE);
		composite.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		composite.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, true, false, 2, 1));
		composite.setLayout(new GridLayout(3, false));

		Button btnFind = new Button(composite, SWT.NONE);
		btnFind.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				findItem(text.getText());
				if (zoomLocation == null) {
					lblError.setText("Not found: " + text.getText());
				} else {
					close();
				}
			}
		});
		GridData gd_btnFind = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnFind.widthHint = 70;
		btnFind.setLayoutData(gd_btnFind);
		btnFind.setBounds(0, 0, 75, 25);
		btnFind.setText("Find");

		Button btnCancel = new Button(composite, SWT.NONE);
		btnCancel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				close();
			}
		});
		GridData gd_btnCancel = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnCancel.widthHint = 70;
		btnCancel.setLayoutData(gd_btnCancel);
		btnCancel.setBounds(0, 0, 75, 25);
		btnCancel.setText("Cancel");
		new Label(composite, SWT.NONE);
		return parent;
	}

	public void findItem(String text) {
		long id;
		zoomLocation = null;
		try {
			id = Integer.parseInt(text);
		} catch (NumberFormatException ex) {
			return;
		}
		switch (selected) {
		case JUNCTION:
			zoomLocation = findJunction(id);
			break;
		case ROADSEGMENT:
			zoomLocation = findRoadSegment(id);
			break;
		case VEHICLE:
			zoomLocation = findVehicle(id);
			break;
		case ROUTING_ID:
			zoomLocation = findRoutingId(id);
			break;
		case SELFDETECT:
			zoomLocation = findVehicle(id);
			if (zoomLocation == null) {
				zoomLocation = findJunction(id);
			}
			if (zoomLocation == null) {
				zoomLocation = findRoutingId(id);
				zoomLocation = findRoadSegment(id);
			}
			break;
		}
	}

	private Location findRoutingId(long id) {
		for (RoadSegment rs : SimulationKernel.getInstance().getActiveModel().getNetwork().getRoadSegments()) {
			if (rs.getRoutingId() == id) {
				return rs.getRoadGeometry().getFirstPoint();
			}
		}
		return null;
	}

	private Location findVehicle(long id) {
		for (RoadSegment rs : SimulationKernel.getInstance().getActiveModel().getNetwork().getRoadSegments()) {
			for (Vehicle v : rs.getAllVehicles()) {
				if (v.getUniqueId() == id || v.getLabel().replaceAll("[^\\d]", "").equals(id + "")) {
					return v.getAbsolutePosition();
				}
			}
		}
		for (AbstractJunction j : SimulationKernel.getInstance().getActiveModel().getNetwork().getJunctions()) {
			for (Vehicle v : j.getVehicles()) {
				if (v.getUniqueId() == id || v.getLabel().replaceAll("[^\\d]", "").equals(id + "")) {
					return v.getAbsolutePosition();
				}
			}
		}
		return null;
	}

	private Location findRoadSegment(long id) {
		RoadSegment seg = SimulationKernel.getInstance().getActiveModel().getNetwork().getRoadSegmentByKey(id);
		if (seg != null) {
			List<Vector> pts = seg.getRightMostLane().getRightEdge();
			return pts.get(Math.floorDiv(pts.size(), 2));
		}
		return null;
	}

	private Location findJunction(long id) {
		for (AbstractJunction j : SimulationKernel.getInstance().getActiveModel().getNetwork().getJunctions()) {
			if (j.getId() == id) {
				return j.getJunctionCenter();
			}
		}
		return null;
	}

	public Location getZoomLocation() {
		return zoomLocation;
	}

	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Find");
	}
}
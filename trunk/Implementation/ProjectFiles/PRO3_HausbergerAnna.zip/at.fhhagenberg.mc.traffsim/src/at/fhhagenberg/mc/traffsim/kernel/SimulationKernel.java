package at.fhhagenberg.mc.traffsim.kernel;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Stack;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchListener;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.osgi.framework.Bundle;

import at.fhhagenberg.mc.traffsim.data.DataLoader;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.matlab.MatlabPlugin;
import at.fhhagenberg.mc.traffsim.model.LoadingException;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.batch.BatchExecutor;
import at.fhhagenberg.mc.traffsim.model.batch.IBatchListener;
import at.fhhagenberg.mc.traffsim.model.init.ParameterParser;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.statistics.CpuInfo;
import at.fhhagenberg.mc.traffsim.ui.dialogs.ParameterSetSelectionDialog;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.BatchMonitorView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.SimulationView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.performancemonitor.ThreadInfoCollector;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.util.ui.SWTUtil;
import at.fhhagenberg.mc.util.StringUtil;
import matlabcontrol.MatlabConnectionException;
import matlabcontrol.MatlabInvocationException;
import matlabcontrol.MatlabProxy;
import matlabcontrol.MatlabProxyFactory;
import matlabcontrol.MatlabProxyFactoryOptions;
import matlabcontrol.MatlabProxyFactoryOptions.Builder;

public class SimulationKernel implements IPartListener, IWorkbenchListener {
	private static final String MATLAB_STATISTICS_MERGE_FUNCTION = "matlab/statistics/mergeFiles.m";

	public static final String SECONDARY_ID_PREFIX = "M";

	private static SimulationKernel singleton = new SimulationKernel();

	private Map<String, SimulationModel> simulationModelRegistry = new HashMap<>();
	private Stack<SimulationModel> viewOrder = new Stack<>();

	private Set<IModelInputChangedListener> statisticsListeners = new HashSet<>();

	private SimulationModel currentModel;

	private static int nextViewId = 0;

	private boolean currentlyLoading = false;

	private BatchExecutor batchExecutor;

	private Set<IBatchListener> batchListeners = new HashSet<>();

	/** mapping of original filenames to filenames in temporary directory */
	private Map<File, File> tempToOriginalFileMapping = new HashMap<>();

	private ThreadInfoCollector threadInfoCollector;

	/**
	 * Singleton constructor
	 */
	private SimulationKernel() {

	}

	private static int getNextViewId() {
		return nextViewId++;
	}

	/**
	 * Create and fully load a new configuration in separate thread. Also interpreting all parameters, using the user interface for
	 * parameter set selection
	 *
	 * @param configuration
	 * @param loadingOptions
	 */
	public void createNewSimulation(File configuration, final Properties loadingOptions) {
		IWorkbenchWindow window = TraffSimCorePlugin.getDefault().getWorkbench().getActiveWorkbenchWindow();
		Thread creator = new Thread("Configuration loader") {
			@Override
			public void run() {
				DataLoader loader = new DataLoader();
				try {
					loader.loadParameters(configuration, new NullProgressMonitor());
				} catch (LoadingException e) {
					Logger.logError("Could not load beans from " + configuration.getAbsolutePath());
				}
				Map<String, Properties> parameterSets = ParameterParser.getSimulationParameterSets(loader.getParameterBeans());

				final List<String> parameterKeys = new ArrayList<>();
				if (!PropertyUtil.getBooleanProperty(loadingOptions, PropertyKeys.BATCH_EXECUTION, false)) {
					if (parameterSets.size() == 1) {
						// only one parameter set? do not display selection dialog
						parameterKeys.addAll(parameterSets.keySet());
					} else {
						window.getShell().getDisplay().syncExec(new Runnable() {

							@Override
							public void run() {
								ParameterSetSelectionDialog dialog = new ParameterSetSelectionDialog(window.getShell(),
										parameterSets.keySet());
								int result = dialog.open();
								if (result != Dialog.CANCEL) {
									parameterKeys.addAll(dialog.getSelectedElements());
								}
							}
						});
					}
				} else {
					parameterKeys.addAll(parameterSets.keySet());
				}
				createNewSimulation(loader, loadingOptions, window, parameterKeys, -1);
			};
		};
		creator.start();
	}

	/**
	 * Create and fully load a new configuration, also interpreting all parameters, using the parameterset provided
	 *
	 * @param loader
	 *            the loader to use <br>
	 *            <b>IMPORTANT</b>: the provided loader instance is ONLY used for the first instantiation of loaded data, for all other
	 *            loadings, a new instance is created!
	 * @param loadingOptions
	 * @param window
	 * @param parameterKeys
	 * @param simulationIdentifier
	 * @return list of {@link SimulationModel}s
	 */
	public List<SimulationModel> createNewSimulation(DataLoader loader, final Properties loadingOptions, IWorkbenchWindow window,
			List<String> parameterKeys, int simulationIdentifier) {
		currentlyLoading = true;
		List<SimulationModel> createdModels = new ArrayList<>();
		Map<String, Properties> parameterSets = ParameterParser.getSimulationParameterSets(loader.getParameterBeans());

		DataLoader currentLoader = loader;
		for (String key : parameterKeys) {
			SimulationModel simulationModel = createSimulationModel(key, parameterSets.get(key));
			initAndOpenSimulationView(simulationModel, window);
			DataLoader filledLoader = simulationModel.loadDataWithProgressMonitorDialog(currentLoader, loadingOptions,
					simulationIdentifier);
			registerNewSimulationModel(simulationModel);
			createdModels.add(simulationModel);
			// reuse the loaded data for the next parameter set
			currentLoader = new DataLoader(filledLoader);
		}
		currentlyLoading = false;
		return createdModels;
	}

	public void registerNewSimulationModel(SimulationModel model) {
		notifyInputChanged(model);
		simulationModelRegistry.put(model.getUniqueId(), model);
	}

	public SimulationModel createSimulationModel(String parameterLabel, Properties parameterSet) {
		String uniqueId = SECONDARY_ID_PREFIX + getNextViewId();
		SimulationModel simulationModel = new SimulationModel(uniqueId);
		simulationModel.setSimParameters(parameterSet);
		simulationModel.setParameterSetLabel(parameterLabel);
		return simulationModel;
	}

	public void startup() {
		if (PreferenceUtil.getBoolean(IPreferenceConstants.RESTART_AFTER_N_CONFIGURATIONS)) {
			String batchStack = PreferenceUtil.getString(IPreferenceConstants.BATCH_SIMULATION_STACK);

			if (StringUtil.isNotNullOrEmpty(batchStack)) {
				PreferenceUtil.set(IPreferenceConstants.BATCH_SIMULATION_STACK, "");
				SWTUtil.showView(BatchMonitorView.ID, "unused", true);

				String[] filenames = batchStack.split(";");
				List<File> files = new ArrayList<>();

				for (String filename : filenames) {
					files.add(new File(filename));
				}

				BatchExecutor executor = new BatchExecutor(files, TraffSimCorePlugin.getDefault().getWorkbench().getActiveWorkbenchWindow(),
						PreferenceUtil.getBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_BATCH),
						PreferenceUtil.getBoolean(IPreferenceConstants.MATLAB_DELETE_FILES_AFTER_MERGE));
				SimulationKernel.getInstance().setActiveBatchExecutor(executor);
				executor.start();
			}
		} else {
			PreferenceUtil.set(IPreferenceConstants.BATCH_SIMULATION_STACK, "");
		}
	}

	public void initAndOpenSimulationView(SimulationModel model, IWorkbenchWindow window) {
		if (window != null) {
			IWorkbenchPage page = window.getActivePage();
			if (page != null) {
				// open (create) and focus on the view
				if (Display.getDefault().getThread() == Thread.currentThread()) {
					openView(model, page);
				} else {
					window.getShell().getDisplay().syncExec(new Runnable() {

						@Override
						public void run() {
							openView(model, page);
						}
					});
				}
			}
		}
	}

	private void openView(SimulationModel model, IWorkbenchPage page) {
		IViewPart justActivated;
		try {
			page.showView(SimulationView.ID, model.getUniqueId(), IWorkbenchPage.VIEW_CREATE);
			justActivated = page.showView(SimulationView.ID, model.getUniqueId(), IWorkbenchPage.VIEW_ACTIVATE);
		} catch (PartInitException e) {
			Logger.logError("Cannot open view", e);
			return;
		}
		SimulationView view = ((SimulationView) justActivated);
		model.initView(view);
	}

	public static SimulationKernel getInstance() {
		return singleton;
	}

	public SimulationModel getSimulationModel(String key) {
		if (StringUtil.isNullOrEmpty(key)) {
			return null;
		}

		if (simulationModelRegistry.containsKey(key)) {
			return simulationModelRegistry.get(key);
		}

		return null;
	}

	@Override
	public void partActivated(IWorkbenchPart part) {
		String id = getPartId(part);
		if (simulationModelRegistry.containsKey(id)) {
			notifyInputChanged(simulationModelRegistry.get(id));
		}
	}

	@Override
	public void partBroughtToTop(IWorkbenchPart part) {
		// System.out.println("brought to top: " + getPartId(part));
	}

	@Override
	public void partClosed(IWorkbenchPart part) {
		// System.out.println("closed");
		String id = getPartId(part);
		doClose(id, false);
	}

	/**
	 * performs tasks which have to be performed after a simualtion view is closed
	 *
	 * @param id
	 *            the unique eclipse ID of the {@link IViewPart} to close
	 * @param closeView
	 *            if <code>true</code>, the view is closed automatically, if <code>false</code>, view is only removed from registry but the
	 *            UI element is not closed
	 */
	public void doClose(final String id, boolean closeView) {
		if (simulationModelRegistry.containsKey(id)) {
			simulationModelRegistry.get(id).stopSimulation(true, false);
			viewOrder.remove(simulationModelRegistry.get(id));
			simulationModelRegistry.remove(id);
			notifyInputChanged(viewOrder.isEmpty() ? null : viewOrder.peek());
		}
		if (closeView) {
			Display.getDefault().syncExec(new Runnable() {

				@Override
				public void run() {
					IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
					try {
						if (page != null) {
							IViewReference[] viewReferences = page.getViewReferences();
							for (IViewReference ivr : viewReferences) {
								if (ivr.getSecondaryId() != null && ivr.getSecondaryId().equalsIgnoreCase(id)) {
									page.hideView(ivr);
								}
							}
						}
					} catch (NullPointerException e) {
						Logger.logWarn("Could not close view", e);
					}
				}

			});
		}
	}

	@Override
	public void partDeactivated(IWorkbenchPart part) {
		// System.out.println("deactivated: " + getPartId(part));
		String id = getPartId(getActivePart());
		if (simulationModelRegistry.containsKey(id)) {
			notifyInputChanged(simulationModelRegistry.get(id));
		} else if (simulationModelRegistry.size() == 0) {
			notifyInputChanged(null);
		} else {
			notifyInputChanged(viewOrder.peek());
		}
	}

	@Override
	public void partOpened(IWorkbenchPart part) {
		// System.out.println("opened: " + getPartId(part));
	}

	public void addInputChangedListener(IModelInputChangedListener listener) {
		this.statisticsListeners.add(listener);
		if (currentModel != null) {
			listener.inputChanged(currentModel);
		}
	}

	public void removeInputChangedListener(IModelInputChangedListener listener) {
		this.statisticsListeners.remove(listener);
	}

	private void notifyInputChanged(SimulationModel newInput) {
		if (newInput != null && newInput.equals(currentModel)) {
			return;
		}
		for (IModelInputChangedListener sl : statisticsListeners) {
			sl.inputChanged(newInput);
		}
		currentModel = newInput;
		viewOrder.remove(currentModel);
		viewOrder.push(currentModel);
	}

	/**
	 * Returns the secondary id of the part in case its a {@link SimulationView}, the default part id otherwise
	 *
	 * @param part
	 * @return id as string
	 */
	private String getPartId(IWorkbenchPart part) {
		if (part == null) {
			return null;
		}
		if (part instanceof SimulationView) {
			return ((SimulationView) part).getViewSite().getSecondaryId();
		}
		return part.getSite().getId();
	}

	private IWorkbenchPart getActivePart() {
		IWorkbenchPage wbp = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		return wbp.getActivePart();
	}

	/**
	 * Get the currently active model of the simulation which is currently visible (the frontmost position). This is intended only for
	 * operations which are independent between {@link SimulationModel}s, such as any general purpose UI views.<br>
	 * <br>
	 * <b>WARNING:</b> Do NOT use this method for any logical read or write operations of members of the returned {@link SimulationModel}
	 * during simulation! If such an operation (e.g. on the {@link RoadNetwork}) is necessary, fetch the model by any non-static access
	 * method!
	 *
	 * @return The model of the active simulation
	 */
	public SimulationModel getActiveModel() {
		return currentModel;
	}

	public boolean isModelActive() {
		return currentModel != null || currentlyLoading;
	}

	/**
	 * Execute merge in matlab
	 *
	 * @param matlabPath
	 *            the path to matlab executable, including executable (usually ends with /bin/matlab.exe)
	 * @param parentFolder
	 *            the parent folder where to look for files to merge
	 * @param delete
	 *            whether or not to delete merged files
	 * @throws MatlabInvocationException
	 * @throws MatlabConnectionException
	 * @throws IOException
	 *             if m-file function is not found
	 * @throws IllegalArgumentException
	 *             if matlabpath or parentfolder do not exist
	 */
	public void mergeFilesInMatlab(String matlabPath, File parentFolder, boolean delete)
			throws MatlabInvocationException, MatlabConnectionException, IOException {
		if (StringUtil.isNullOrEmpty(matlabPath) || !new File(matlabPath).exists()) {
			throw new IllegalArgumentException("Matlab path not found");
		}
		if (parentFolder == null || !parentFolder.exists()) {
			throw new IllegalArgumentException("Could not find provided parent folder to search for mat files");
		}

		Bundle bundle = Platform.getBundle(MatlabPlugin.ID);
		URL fileURL = bundle.getEntry(MATLAB_STATISTICS_MERGE_FUNCTION);
		File file = null;
		try {
			fileURL = FileLocator.resolve(fileURL);
			file = new File(new URI(StringUtil.ensureURICompatible(fileURL.toString())));
		} catch (URISyntaxException | IOException e2) {
			throw new IOException("Cannot find function m-file to merge");
		}
		MatlabProxy proxy = null;
		try {
			Builder options = new MatlabProxyFactoryOptions.Builder();
			options.setMatlabLocation(matlabPath);
			options.setMatlabStartingDirectory(file.getParentFile());
			/** set class loader for avoiding classnotfoundexceptions due to RMI calls */
			Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
			proxy = new MatlabProxyFactory(options.build()).getProxy();
			proxy.feval("mergeFiles", parentFolder.getAbsolutePath(), (delete ? 1 : 0));
		} catch (MatlabConnectionException e) {
			Logger.logError("Cannot connect to MATLAB", e);
		} finally {
			if (proxy != null) {
				proxy.exit();
				proxy.disconnect();
			}
		}
	}

	public Collection<SimulationModel> getOpenModels() {
		return simulationModelRegistry.values();
	}

	public void setActiveBatchExecutor(BatchExecutor executor) {
		batchExecutor = executor;
		for (IBatchListener batchListener : batchListeners) {
			batchExecutor.setBatchListener(batchListener);
		}
	}

	/**
	 * Remove the current batch executor to enable GC
	 */
	public void resetActiveBatchExecutor() {
		batchExecutor = null;
	}

	public BatchExecutor getBatchExecutor() {
		return batchExecutor;
	}

	public void registerBatchListener(IBatchListener listener) {
		this.batchListeners.add(listener);
	}

	public void unregisterBatchListener(IBatchListener listener) {
		this.batchListeners.remove(listener);
	}

	@Override
	public boolean preShutdown(IWorkbench workbench, boolean forced) {
		if (batchExecutor != null) {
			batchExecutor.stopBatch();
		}
		return true;
	}

	@Override
	public void postShutdown(IWorkbench workbench) {
	}

	public Map<File, File> getTempToOriginalFileMapping() {
		return tempToOriginalFileMapping;
	}

	public void setTempToOriginalFileMapping(Map<File, File> oldToNewMapping) {
		this.tempToOriginalFileMapping = oldToNewMapping;
	}

	public static final String getTraffSimVersionInfo() {
		Bundle bundle = Platform.getBundle(TraffSimCorePlugin.PLUGIN_ID);
		if (bundle != null) {
			String ver = bundle.getVersion().toString();
			if (ver.contains("qualifier")) {
				// no bundle version has been set by maven build - current product is not a completed product build, but somehow executed
				// from development environment
				return "CURRENT DEV TRUNK";
			} else {
				return ver;
			}
		} else {
			Logger.logWarn("Could not determine bundle version of TraffSim core.");
			return "<unknown version>";
		}
	}

	public static final CpuInfo getCpuInfo() {
		return getInstance().getThreadInfoUpdater().getCpuInfo();
	}

	public ThreadInfoCollector getThreadInfoUpdater() {
		if (threadInfoCollector == null) {
			threadInfoCollector = new ThreadInfoCollector("Performance Monitor updater", 1000);
			threadInfoCollector.startPaused();
			if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_CPU_STATISTICS)) {
				threadInfoCollector.proceed();
			}
		}
		return threadInfoCollector;
	}

}

package at.fhhagenberg.mc.traffsim.vehicle.model;

public class VehicleModelInputData {
	private String identifier, fullname;

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	@Override
	public String toString() {
		return identifier + " (" + fullname + ")";
	}
}

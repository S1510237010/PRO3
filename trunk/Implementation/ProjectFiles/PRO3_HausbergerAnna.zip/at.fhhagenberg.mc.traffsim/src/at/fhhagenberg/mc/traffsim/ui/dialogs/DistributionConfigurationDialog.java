package at.fhhagenberg.mc.traffsim.ui.dialogs;

import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.math3.distribution.AbstractRealDistribution;
import org.apache.commons.math3.distribution.BetaDistribution;
import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.distribution.LogNormalDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.distribution.ParetoDistribution;
import org.apache.commons.math3.distribution.UniformRealDistribution;
import org.apache.commons.math3.distribution.WeibullDistribution;
import org.csstudio.swt.xygraph.dataprovider.CircularBufferDataProvider;
import org.csstudio.swt.xygraph.figures.Trace;
import org.csstudio.swt.xygraph.figures.Trace.TraceType;
import org.csstudio.swt.xygraph.figures.XYGraph;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;

public class DistributionConfigurationDialog extends TitleAreaDialog {

	private static final String DISTRIBUTION_NONE = "None";
	private static final String DISTRIBUTION_NORMAL = "Normal";
	private static final String DISTRIBUTION_LOG_NORMAL = "Log-normal";
	private static final String DISTRIBUTION_WEIBULL = "Weibull";
	private static final String DISTRIBUTION_BETA = "Beta";
	private static final String DISTRIBUTION_GAMMA = "Gamma";
	private static final String DISTRIBUTION_PARETO = "Pareto";
	private static final String DISTRIBUTION_EXPONENTIAL = "Exponential";
	private static final String DISTRIBUTION_UNIFORM = "Uniform";

	private static final int DISTRIBUTION_NONE_IDX = 0;
	private static final int DISTRIBUTION_BETA_IDX = 1;
	private static final int DISTRIBUTION_EXPONENTIAL_IDX = 2;
	private static final int DISTRIBUTION_GAMMA_IDX = 3;
	private static final int DISTRIBUTION_LOG_NORMAL_IDX = 4;
	private static final int DISTRIBUTION_NORMAL_IDX = 5;
	private static final int DISTRIBUTION_PARETO_IDX = 6;
	private static final int DISTRIBUTION_UNIFORM_IDX = 7;
	private static final int DISTRIBUTION_WEIBULL_IDX = 8;

	private Composite container;

	// Property selection
	private Combo comboProperty;

	// Model count selection
	private Spinner spinnerNumModels;

	// Distribution selection
	private Combo comboDistribution;
	private Combo comboGraphStyle;
	private Spinner spinnerResolution;

	// Distribution configuration
	private Label lblMean;
	private Spinner spinnerMean;
	private Label lblStd;
	private Spinner spinnerStd;
	private Label lblLowerBound;
	private Spinner spinnerLowerTruncationBound;
	private Label lblUpperBound;
	private Spinner spinnerUpperTruncationBound;

	private Button btnLowerTruncation;
	private Button btnUpperTruncation;

	// Visualization
	private XYGraph xyGraph;
	private CircularBufferDataProvider pdf;
	private Trace pdfTrace;
	private Display display;

	private int prevDistribution = -1;
	private int prevGraphStyle = 0;

	// Distribution properties
	private Label lblResultMean;
	private Label lblResultStd;
	private Label lblResultVar;
	private double mean;
	private double std;
	private double var;

	// Properties to be configured
	private List<ModelProperty> configurableProperties;

	// Property configuration
	private HashMap<ModelProperty, DistributionConfig> propertyConfiguration;

	// Number of models to be generated
	private int numModels;

	private ModelProperty currentProperty;
	private AbstractRealDistribution currentDistribution;

	public DistributionConfigurationDialog(Shell parentShell, List<ModelProperty> configurableProperties) {
		super(parentShell);
		this.configurableProperties = configurableProperties;
		this.propertyConfiguration = new HashMap<ModelProperty, DistributionConfig>();

		if (configurableProperties != null && configurableProperties.size() > 0) {
			for (ModelProperty property : configurableProperties) {
				DistributionConfig distributionConfig = new DistributionConfig();

				if (property.getMaxValue() != Double.POSITIVE_INFINITY) {
					distributionConfig.setMaximum(property.getMaxValue());
					distributionConfig.setConsiderMaximum(true);
				}

				if (property.getMinValue() != Double.NEGATIVE_INFINITY) {
					distributionConfig.setMinimum(property.getMinValue());
					distributionConfig.setConsiderMinimum(true);
				}

				if (currentProperty == null && property.getCanBeDistributed()) {
					currentProperty = property;
				}

				propertyConfiguration.put(property, distributionConfig);
			}
		}
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		Composite area = (Composite) super.createDialogArea(parent);
		container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		GridLayout layout = new GridLayout(6, true);
		container.setLayout(layout);

		Group grpPropertySelection = new Group(container, SWT.NONE);
		grpPropertySelection.setText("Generation options");
		grpPropertySelection.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 6, 1));
		grpPropertySelection.setLayout(new GridLayout(6, false));

		Label lblProperty = new Label(grpPropertySelection, SWT.NONE);
		lblProperty.setText("Model property");

		comboProperty = new Combo(grpPropertySelection, SWT.READ_ONLY);
		comboProperty.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, true, 1, 1));
		comboProperty.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
				switchProperty(true);
			}

		});

		if (configurableProperties == null || configurableProperties.size() == 0) {
			comboProperty.setEnabled(false);
		} else {
			Collections.sort(configurableProperties, new Comparator<ModelProperty>() {
				@Override
				public int compare(ModelProperty o1, ModelProperty o2) {
					return o1.getName().compareTo(o2.getName());
				}
			});

			for (ModelProperty property : configurableProperties) {
				if (property.getCanBeDistributed()) {
					comboProperty.add(property.getName());
				}
			}

			comboProperty.select(0);
		}

		new Label(grpPropertySelection, SWT.NONE);

		Label lblNumModels = new Label(grpPropertySelection, SWT.NONE);
		lblNumModels.setText("Number of models to be created");

		spinnerNumModels = new Spinner(grpPropertySelection, SWT.BORDER);
		spinnerNumModels.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				numModels = spinnerNumModels.getSelection();
				updatePreview(false);
			}
		});

		spinnerNumModels.setPageIncrement(10);
		spinnerNumModels.setIncrement(1);
		spinnerNumModels.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerNumModels.setMinimum(1);
		spinnerNumModels.setMaximum(1000);
		spinnerNumModels.setSelection(10);
		numModels = 10;

		Group grpDistributionSelection = new Group(container, SWT.NONE);
		grpDistributionSelection.setText("Distribution Selection");
		grpDistributionSelection.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 3, 1));
		grpDistributionSelection.setLayout(new GridLayout(2, false));

		Label lblDistribution = new Label(grpDistributionSelection, SWT.NONE);
		lblDistribution.setText("Distribution");

		comboDistribution = new Combo(grpDistributionSelection, SWT.READ_ONLY);
		comboDistribution.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		comboDistribution.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (prevDistribution != comboDistribution.getSelectionIndex()) {
					updatePreview(true);
				}

				prevDistribution = comboDistribution.getSelectionIndex();
			}
		});

		// Add available distributions
		comboDistribution.add(DISTRIBUTION_NONE);
		comboDistribution.add(DISTRIBUTION_BETA);
		comboDistribution.add(DISTRIBUTION_EXPONENTIAL);
		comboDistribution.add(DISTRIBUTION_GAMMA);
		comboDistribution.add(DISTRIBUTION_LOG_NORMAL);
		comboDistribution.add(DISTRIBUTION_NORMAL);
		comboDistribution.add(DISTRIBUTION_PARETO);
		comboDistribution.add(DISTRIBUTION_UNIFORM);
		comboDistribution.add(DISTRIBUTION_WEIBULL);
		comboDistribution.select(0);

		Group grpGraphStyle = new Group(container, SWT.NONE);
		grpGraphStyle.setText("Visualization");
		grpGraphStyle.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 3, 1));
		grpGraphStyle.setLayout(new GridLayout(2, false));

		Label lblGraphStyle = new Label(grpGraphStyle, SWT.NONE);
		lblGraphStyle.setText("Graph Style");

		comboGraphStyle = new Combo(grpGraphStyle, SWT.READ_ONLY);
		comboGraphStyle.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		comboGraphStyle.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (prevGraphStyle != comboGraphStyle.getSelectionIndex()) {
					updatePreview(false);
				}

				prevGraphStyle = comboGraphStyle.getSelectionIndex();
			}
		});

		Label lblResolution = new Label(grpGraphStyle, SWT.NONE);
		lblResolution.setText("Resolution");

		spinnerResolution = new Spinner(grpGraphStyle, SWT.BORDER);
		spinnerResolution.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
			}
		});

		spinnerResolution.setPageIncrement(10);
		spinnerResolution.setIncrement(1);
		spinnerResolution.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerResolution.setMinimum(20);
		spinnerResolution.setMaximum(300);
		spinnerResolution.setSelection(100);

		// Add available graph styles
		comboGraphStyle.add("Bar");
		comboGraphStyle.add("Line");
		comboGraphStyle.add("Area");
		comboGraphStyle.select(0);

		// Parameter Configuration
		Group grpParameterConfiguration = new Group(container, SWT.NONE);
		grpParameterConfiguration.setText("Parameter configuration");
		grpParameterConfiguration.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 2, 1));
		GridLayout parameterGridLayout = new GridLayout(3, false);
		parameterGridLayout.horizontalSpacing = 10;
		grpParameterConfiguration.setLayout(parameterGridLayout);

		lblMean = new Label(grpParameterConfiguration, SWT.NONE);
		lblMean.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblMean.setText("Mean");

		spinnerMean = new Spinner(grpParameterConfiguration, SWT.BORDER);
		spinnerMean.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
			}
		});

		spinnerMean.setPageIncrement(50);
		spinnerMean.setIncrement(1);
		spinnerMean.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerMean.setMinimum(-(int) Math.pow(10, 6));
		spinnerMean.setMaximum((int) Math.pow(10, 6));
		spinnerMean.setSelection(0);
		spinnerMean.setDigits(2);

		lblStd = new Label(grpParameterConfiguration, SWT.NONE);
		lblStd.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblStd.setText("Standard deviation");

		spinnerStd = new Spinner(grpParameterConfiguration, SWT.NONE);
		spinnerStd.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
			}
		});

		spinnerStd.setPageIncrement(10);
		spinnerStd.setIncrement(1);
		spinnerStd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerStd.setMinimum(1);
		spinnerStd.setMaximum((int) Math.pow(10, 5));
		spinnerStd.setSelection(50);
		spinnerStd.setDigits(2);

		btnLowerTruncation = new Button(grpParameterConfiguration, SWT.CHECK);
		btnLowerTruncation.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
			}
		});

		lblLowerBound = new Label(grpParameterConfiguration, SWT.NONE);
		lblLowerBound.setText("Lower Bound");
		spinnerLowerTruncationBound = new Spinner(grpParameterConfiguration, SWT.BORDER);
		spinnerLowerTruncationBound.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
			}
		});

		spinnerLowerTruncationBound.setPageIncrement(10);
		spinnerLowerTruncationBound.setIncrement(1);
		spinnerLowerTruncationBound.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerLowerTruncationBound.setMinimum(-(int) Math.pow(10, 6));
		spinnerLowerTruncationBound.setMaximum((int) Math.pow(10, 6));
		spinnerLowerTruncationBound.setSelection(-100);
		spinnerLowerTruncationBound.setDigits(2);

		btnUpperTruncation = new Button(grpParameterConfiguration, SWT.CHECK);
		btnUpperTruncation.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
			}
		});

		lblUpperBound = new Label(grpParameterConfiguration, SWT.NONE);
		lblUpperBound.setText("Upper bound");
		spinnerUpperTruncationBound = new Spinner(grpParameterConfiguration, SWT.BORDER);
		spinnerUpperTruncationBound.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				updatePreview(false);
			}
		});

		spinnerUpperTruncationBound.setPageIncrement(10);
		spinnerUpperTruncationBound.setIncrement(1);
		spinnerUpperTruncationBound.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		spinnerUpperTruncationBound.setMinimum(-(int) Math.pow(10, 6));
		spinnerUpperTruncationBound.setMaximum((int) Math.pow(10, 6));
		spinnerUpperTruncationBound.setSelection(100);
		spinnerUpperTruncationBound.setDigits(2);

		// Graph Visualization
		Group grpVisualization = new Group(container, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		grpVisualization.setText("Preview");
		grpVisualization.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 4, 2));
		grpVisualization.setLayout(new GridLayout(1, false));

		Canvas graphCanvas = new Canvas(grpVisualization, SWT.FILL);
		final LightweightSystem lws = new LightweightSystem(graphCanvas);

		xyGraph = new XYGraph();
		xyGraph.primaryYAxis.setRange(0.0, 1.0);
		xyGraph.primaryXAxis.setTitle("X");
		xyGraph.primaryYAxis.setTitle("P(X)");
		lws.setContents(xyGraph);

		graphCanvas.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		// Distribution properties
		Group grpDistributionProperties = new Group(container, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		grpDistributionProperties.setText("Moments");
		grpDistributionProperties.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		GridLayout propertiesGridLayout = new GridLayout(3, true);
		propertiesGridLayout.horizontalSpacing = 10;
		grpDistributionProperties.setLayout(propertiesGridLayout);

		lblResultMean = new Label(grpDistributionProperties, SWT.NONE);
		lblResultMean.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblResultMean.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		lblResultMean.setText("-");
		lblResultStd = new Label(grpDistributionProperties, SWT.NONE);
		lblResultStd.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblResultStd.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		lblResultStd.setText("-");
		lblResultVar = new Label(grpDistributionProperties, SWT.NONE);
		lblResultVar.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblResultVar.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		lblResultVar.setText("-");

		Label resultMean = new Label(grpDistributionProperties, SWT.NONE);
		resultMean.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		resultMean.setText("\u00B5 = E(X)");
		Label resultStd = new Label(grpDistributionProperties, SWT.NONE);
		resultStd.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		resultStd.setText("\u03C3 = STD(X)");
		Label resultVar = new Label(grpDistributionProperties, SWT.NONE);
		resultVar.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		resultVar.setText("\u03C3� = VAR(X)");

		display = Display.getCurrent();
		switchProperty(false);

		return container;
	}

	private void switchProperty(boolean updateCurrentProperty) {

		// Update the current property configuration
		if (updateCurrentProperty) {
			DistributionConfig updatableConfig = propertyConfiguration.get(currentProperty);
			updatableConfig.setDistribution(currentDistribution);
			updatableConfig.setFirstParam((spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits())));
			updatableConfig.setSecondParam((spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits())));
			updatableConfig.setMinimum((spinnerLowerTruncationBound.getSelection()
					/ Math.pow(10, spinnerLowerTruncationBound.getDigits())));
			updatableConfig.setMaximum((spinnerUpperTruncationBound.getSelection()
					/ Math.pow(10, spinnerUpperTruncationBound.getDigits())));
		}

		for (ModelProperty property : propertyConfiguration.keySet()) {
			if (property.getName().compareTo(comboProperty.getText()) == 0) {
				currentProperty = property;
				break;
			}
		}

		DistributionConfig config = propertyConfiguration.get(currentProperty);

		// Update other selections
		spinnerLowerTruncationBound.setMinimum(
				(int) (currentProperty.getMinValue() * Math.pow(10, spinnerLowerTruncationBound.getDigits())));
		spinnerLowerTruncationBound
				.setSelection((int) (config.getMinimum() * Math.pow(10, spinnerLowerTruncationBound.getDigits())));

		spinnerUpperTruncationBound.setMaximum(
				(int) (currentProperty.getMaxValue() * Math.pow(10, spinnerLowerTruncationBound.getDigits())));
		spinnerUpperTruncationBound
				.setSelection((int) (config.getMaximum() * Math.pow(10, spinnerUpperTruncationBound.getDigits())));

		// Get the distribution selected so far
		AbstractRealDistribution distribution = config.getDistribution();

		// No distribution was selected so far for this particular property
		if (distribution == null) {
			comboDistribution.select(DISTRIBUTION_NONE_IDX);
		} else {
			spinnerMean.setSelection((int) (config.getFirstParam() * Math.pow(10, spinnerMean.getDigits())));
			spinnerStd.setSelection((int) (config.getSecondParam() * Math.pow(10, spinnerStd.getDigits())));

			if (distribution instanceof BetaDistribution) {
				comboDistribution.select(DISTRIBUTION_BETA_IDX);
			} else if (distribution instanceof ExponentialDistribution) {
				comboDistribution.select(DISTRIBUTION_EXPONENTIAL_IDX);
			} else if (distribution instanceof GammaDistribution) {
				comboDistribution.select(DISTRIBUTION_GAMMA_IDX);
			} else if (distribution instanceof LogNormalDistribution) {
				comboDistribution.select(DISTRIBUTION_LOG_NORMAL_IDX);
			} else if (distribution instanceof NormalDistribution) {
				comboDistribution.select(DISTRIBUTION_NORMAL_IDX);
			} else if (distribution instanceof ParetoDistribution) {
				comboDistribution.select(DISTRIBUTION_PARETO_IDX);
			} else if (distribution instanceof UniformRealDistribution) {
				comboDistribution.select(DISTRIBUTION_UNIFORM_IDX);
			} else if (distribution instanceof WeibullDistribution) {
				comboDistribution.select(DISTRIBUTION_WEIBULL_IDX);
			}
		}

		prevDistribution = comboDistribution.getSelectionIndex();
		updatePreview(false);
	}

	private void updatePreview(boolean initDistributionConfiguration) {

		pdf = new CircularBufferDataProvider(false);

		if (comboDistribution.getText().compareTo(DISTRIBUTION_NONE) == 0) {
			comboGraphStyle.setEnabled(false);
			spinnerResolution.setEnabled(false);
			spinnerMean.setEnabled(false);
			spinnerStd.setEnabled(false);
			btnLowerTruncation.setEnabled(false);
			btnUpperTruncation.setEnabled(false);
			spinnerLowerTruncationBound.setEnabled(false);
			spinnerUpperTruncationBound.setEnabled(false);

			lblResultMean.setText("-");
			lblResultStd.setText("-");
			lblResultVar.setText("-");
			currentDistribution = null;
		} else {
			comboGraphStyle.setEnabled(true);
			spinnerResolution.setEnabled(true);
			spinnerMean.setEnabled(true);
			spinnerStd.setEnabled(true);
			btnLowerTruncation.setSelection(propertyConfiguration.get(currentProperty).getConsiderMinimum());
			btnUpperTruncation.setSelection(propertyConfiguration.get(currentProperty).getConsiderMinimum());
			btnLowerTruncation.setEnabled(!propertyConfiguration.get(currentProperty).getConsiderMinimum());
			btnUpperTruncation.setEnabled(!propertyConfiguration.get(currentProperty).getConsiderMinimum());
			spinnerLowerTruncationBound.setEnabled(true);
			spinnerUpperTruncationBound.setEnabled(true);

			// Get graph resolution
			int resolution = spinnerResolution.getSelection();

			// Get truncation bounds
			double truncationLowerBound = spinnerLowerTruncationBound.getSelection()
					/ Math.pow(10, spinnerLowerTruncationBound.getDigits());
			double truncationUpperBound = spinnerUpperTruncationBound.getSelection()
					/ Math.pow(10, spinnerUpperTruncationBound.getDigits());

			// Check if truncation is desired
			boolean truncateLowerBound = btnLowerTruncation.getSelection();
			boolean truncateUpperBound = btnUpperTruncation.getSelection();

			// Check if truncation bounds are valid
			if (truncationLowerBound >= truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				setErrorMessage("Upper bound cannot be below or equal to the lower bound.");
			} else {
				setErrorMessage(null);
			}

			if (comboDistribution.getText().compareTo(DISTRIBUTION_NORMAL) == 0) {
				lblMean.setText("Mean \u00B5");
				lblStd.setText("Standard deviation \u03C3");

				spinnerStd.setMinimum(1);
				spinnerMean.setMinimum(-(int) Math.pow(10, 6));

				lblMean.setVisible(true);
				spinnerMean.setVisible(true);
				lblStd.setVisible(true);
				spinnerStd.setVisible(true);
				btnLowerTruncation.setVisible(true);
				btnUpperTruncation.setVisible(true);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				if (initDistributionConfiguration) {
					spinnerMean.setSelection(0);
					spinnerStd.setSelection((int) (1 * Math.pow(10, spinnerStd.getDigits())));
				}

				currentDistribution = updateNormalDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			} else if (comboDistribution.getText().compareTo(DISTRIBUTION_LOG_NORMAL) == 0) {
				lblMean.setText("Normal mean \u00B5");
				lblStd.setText("Normal standard deviation \u03C3");

				spinnerStd.setMinimum(1);
				spinnerMean.setMinimum(-(int) Math.pow(10, 6));

				lblMean.setVisible(true);
				spinnerMean.setVisible(true);
				lblStd.setVisible(true);
				spinnerStd.setVisible(true);
				btnLowerTruncation.setVisible(true);
				btnUpperTruncation.setVisible(true);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				if (initDistributionConfiguration) {
					spinnerMean.setSelection(0);
					spinnerStd.setSelection((int) (0.5 * Math.pow(10, spinnerStd.getDigits())));
				}

				currentDistribution = updateLogNormalDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			} else if (comboDistribution.getText().compareTo(DISTRIBUTION_WEIBULL) == 0) {
				lblMean.setText("Shape \u03B1");
				lblStd.setText("Scale \u03B2");

				spinnerStd.setMinimum(1);
				spinnerMean.setMinimum(1);

				lblMean.setVisible(true);
				spinnerMean.setVisible(true);
				lblStd.setVisible(true);
				spinnerStd.setVisible(true);
				btnLowerTruncation.setVisible(true);
				btnUpperTruncation.setVisible(true);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				if (initDistributionConfiguration) {
					spinnerMean.setSelection((int) (1.5 * Math.pow(10, spinnerMean.getDigits())));
					spinnerStd.setSelection((int) (1 * Math.pow(10, spinnerStd.getDigits())));
				}

				currentDistribution = updateWeibullDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			} else if (comboDistribution.getText().compareTo(DISTRIBUTION_EXPONENTIAL) == 0) {
				lblMean.setText("Rate \u03BB");

				spinnerStd.setMinimum(1);
				spinnerMean.setMinimum(1);

				lblMean.setVisible(true);
				spinnerMean.setVisible(true);
				lblStd.setVisible(false);
				spinnerStd.setVisible(false);
				btnLowerTruncation.setVisible(true);
				btnUpperTruncation.setVisible(true);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				if (initDistributionConfiguration) {
					spinnerMean.setSelection((int) (2 * Math.pow(10, spinnerMean.getDigits())));
				}

				currentDistribution = updateExponentialDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			} else if (comboDistribution.getText().compareTo(DISTRIBUTION_BETA) == 0) {
				lblMean.setText("Shape \u03B1");
				lblStd.setText("Shape \u03B2");

				spinnerStd.setMinimum(1);
				spinnerMean.setMinimum(1);

				lblMean.setVisible(true);
				spinnerMean.setVisible(true);
				lblStd.setVisible(true);
				spinnerStd.setVisible(true);
				btnLowerTruncation.setVisible(true);
				btnUpperTruncation.setVisible(true);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				if (initDistributionConfiguration) {
					spinnerMean.setSelection((int) (2 * Math.pow(10, spinnerMean.getDigits())));
					spinnerStd.setSelection((int) (2 * Math.pow(10, spinnerStd.getDigits())));
				}

				currentDistribution = updateBetaDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			} else if (comboDistribution.getText().compareTo(DISTRIBUTION_PARETO) == 0) {
				lblMean.setText("Min. value k");
				lblStd.setText("Shape \u03B1");

				spinnerStd.setMinimum(1);
				spinnerMean.setMinimum(1);

				lblMean.setVisible(true);
				spinnerMean.setVisible(true);
				lblStd.setVisible(true);
				spinnerStd.setVisible(true);
				btnLowerTruncation.setVisible(true);
				btnUpperTruncation.setVisible(true);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				if (initDistributionConfiguration) {
					spinnerMean.setSelection((int) (2 * Math.pow(10, spinnerMean.getDigits())));
					spinnerStd.setSelection((int) (3 * Math.pow(10, spinnerStd.getDigits())));
				}

				currentDistribution = updateParetoDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			} else if (comboDistribution.getText().compareTo(DISTRIBUTION_UNIFORM) == 0) {

				lblMean.setVisible(false);
				lblStd.setVisible(false);
				spinnerStd.setVisible(false);
				spinnerMean.setVisible(false);
				btnLowerTruncation.setVisible(false);
				btnUpperTruncation.setVisible(false);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				currentDistribution = updateUniformDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			} else if (comboDistribution.getText().compareTo(DISTRIBUTION_GAMMA) == 0) {
				lblMean.setText("Shape \u03B1");
				lblStd.setText("Scale \u03B2");

				spinnerStd.setMinimum(1);
				spinnerMean.setMinimum(1);

				lblMean.setVisible(true);
				spinnerMean.setVisible(true);
				lblStd.setVisible(true);
				spinnerStd.setVisible(true);
				btnLowerTruncation.setVisible(true);
				btnUpperTruncation.setVisible(true);
				lblLowerBound.setVisible(true);
				lblUpperBound.setVisible(true);
				spinnerLowerTruncationBound.setVisible(true);
				spinnerUpperTruncationBound.setVisible(true);

				if (initDistributionConfiguration) {
					spinnerMean.setSelection((int) (0.5 * Math.pow(10, spinnerMean.getDigits())));
					spinnerStd.setSelection((int) (1 * Math.pow(10, spinnerStd.getDigits())));
				}

				currentDistribution = updateGammaDistribution(truncationLowerBound, truncationUpperBound,
						truncateLowerBound, truncateUpperBound, resolution);
			}

			DecimalFormat formatter = new DecimalFormat("0.000E0");

			// Update moments
			if (!Double.isNaN(mean)) {
				lblResultMean.setText(formatter.format(mean));
			} else {
				lblResultMean.setText("Indeterminate");
			}

			if (!Double.isNaN(std)) {
				lblResultStd.setText(formatter.format(std));
			} else {
				lblResultStd.setText("Indeterminate");
			}

			if (!Double.isNaN(var)) {
				lblResultVar.setText(formatter.format(var));
			} else {
				lblResultVar.setText("Indeterminate");
			}
		}

		// Remove old trace
		if (pdfTrace != null) {
			xyGraph.removeTrace(pdfTrace);
		}

		pdfTrace = new Trace("Probability density function", xyGraph.primaryXAxis, xyGraph.primaryYAxis, pdf);
		pdfTrace.setAreaAlpha(500);
		pdfTrace.setTraceColor(display.getSystemColor(SWT.COLOR_DARK_BLUE));

		if (comboGraphStyle.getSelectionIndex() == 0) {
			pdfTrace.setTraceType(TraceType.BAR);
			pdfTrace.setLineWidth(8);
		} else if (comboGraphStyle.getSelectionIndex() == 1) {
			pdfTrace.setTraceType(TraceType.SOLID_LINE);
			pdfTrace.setLineWidth(2);
		} else if (comboGraphStyle.getSelectionIndex() == 2) {
			pdfTrace.setTraceType(TraceType.AREA);
			pdfTrace.setLineWidth(8);
		}

		xyGraph.addTrace(pdfTrace);

		DistributionConfig updatableConfig = propertyConfiguration.get(currentProperty);
		updatableConfig.setDistribution(currentDistribution);
		updatableConfig.setFirstParam((spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits())));
		updatableConfig.setSecondParam((spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits())));
		updatableConfig.setMinimum(
				(spinnerLowerTruncationBound.getSelection() / Math.pow(10, spinnerLowerTruncationBound.getDigits())));
		updatableConfig.setMaximum(
				(spinnerUpperTruncationBound.getSelection() / Math.pow(10, spinnerUpperTruncationBound.getDigits())));
	}

	private AbstractRealDistribution updateNormalDistribution(double truncationLowerBound, double truncationUpperBound,
			boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		NormalDistribution distribution = new NormalDistribution(
				spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits()),
				spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits()));

		mean = distribution.getMean();
		std = distribution.getStandardDeviation();
		var = std * std;
		double lowerBound = distribution.getMean() - 5 * distribution.getStandardDeviation();
		double upperBound = distribution.getMean() + 5 * distribution.getStandardDeviation();

		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		for (int i = 0; i < spinnerResolution.getSelection(); i++) {
			double val = lowerBound + (upperBound - lowerBound) * i / resolution;

			if (truncationLowerBound > truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				xValues[i] = val;
				yValues[i] = 0;
				maxProb = 0;
			} else {
				double prob = distribution.density(val);

				// Check if the value is out of bounds or not
				if ((val < truncationLowerBound && truncateLowerBound)
						|| (val > truncationUpperBound && truncateUpperBound)) {
					prob = 0;
				}

				if (prob > maxProb) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);

		if (maxProb == 0) {
			xyGraph.primaryYAxis.setRange(0.0, 1);
		} else {
			xyGraph.primaryYAxis.setRange(0.0, maxProb * 1.1);
		}

		return distribution;
	}

	private AbstractRealDistribution updateLogNormalDistribution(double truncationLowerBound,
			double truncationUpperBound, boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		double mu = spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits());
		double sigma = spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits());
		LogNormalDistribution distribution = new LogNormalDistribution(mu, sigma);

		mean = distribution.getNumericalMean();
		var = distribution.getNumericalVariance();
		std = Math.sqrt(var);
		double lowerBound = Math.max(0, mean - 4 * std);
		double upperBound = mean + 4 * std;

		if (Double.isNaN(lowerBound)) {
			lowerBound = 0;
		}

		if (Double.isInfinite(upperBound)) {
			upperBound = Double.MAX_VALUE;
		}

		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		for (int i = 0; i < spinnerResolution.getSelection(); i++) {
			double val = lowerBound + (upperBound - lowerBound) * i / resolution;

			if (truncationLowerBound > truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				xValues[i] = val;
				yValues[i] = 0;
				maxProb = 0;
			} else {
				double prob = distribution.density(val);

				// Check if the value is out of bounds or not
				if ((val < truncationLowerBound && truncateLowerBound)
						|| (val > truncationUpperBound && truncateUpperBound)) {
					prob = 0;
				}

				if (prob > maxProb) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);

		if (maxProb == 0) {
			xyGraph.primaryYAxis.setRange(0.0, 1);
		} else {
			xyGraph.primaryYAxis.setRange(0.0, maxProb * 1.1);
		}

		return distribution;
	}

	private AbstractRealDistribution updateWeibullDistribution(double truncationLowerBound, double truncationUpperBound,
			boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		double alpha = spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits());
		double beta = spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits());
		WeibullDistribution distribution = new WeibullDistribution(alpha, beta);

		mean = distribution.getNumericalMean();
		var = distribution.getNumericalVariance();
		std = Math.sqrt(var);
		double lowerBound = 0;
		double upperBound = 5;

		if (!Double.isNaN(std)) {
			lowerBound = Math.max(0, mean - 4 * std);
			upperBound = mean + 4 * std;
		}

		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		for (int i = 0; i < spinnerResolution.getSelection(); i++) {
			double val = lowerBound + (upperBound - lowerBound) * i / resolution;

			if (truncationLowerBound > truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				xValues[i] = val;
				yValues[i] = 0;
				maxProb = 0;
			} else {
				double prob = distribution.density(val);

				// Check if the value is out of bounds or not
				if ((val < truncationLowerBound && truncateLowerBound)
						|| (val > truncationUpperBound && truncateUpperBound)) {
					prob = 0;
				}

				if (prob > maxProb) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);

		if (maxProb == 0) {
			xyGraph.primaryYAxis.setRange(0.0, 1);
		} else {
			xyGraph.primaryYAxis.setRange(0.0, maxProb * 1.1);
		}

		return distribution;
	}

	private AbstractRealDistribution updateExponentialDistribution(double truncationLowerBound,
			double truncationUpperBound, boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		double lambda = spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits());
		ExponentialDistribution distribution = new ExponentialDistribution(1 / lambda);

		mean = distribution.getNumericalMean();
		var = distribution.getNumericalVariance();
		std = Math.sqrt(var);
		double lowerBound = 0;
		double upperBound = -Math.log(1 - 0.999) / lambda;

		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		for (int i = 0; i < spinnerResolution.getSelection(); i++) {
			double val = lowerBound + (upperBound - lowerBound) * i / resolution;

			if (truncationLowerBound > truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				xValues[i] = val;
				yValues[i] = 0;
				maxProb = 0;
			} else {
				double prob = distribution.density(val);

				// Check if the value is out of bounds or not
				if ((val < truncationLowerBound && truncateLowerBound)
						|| (val > truncationUpperBound && truncateUpperBound)) {
					prob = 0;
				}

				if (prob > maxProb) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);

		if (maxProb == 0) {
			xyGraph.primaryYAxis.setRange(0.0, 1);
		} else {
			xyGraph.primaryYAxis.setRange(0.0, maxProb * 1.1);
		}

		return distribution;
	}

	private AbstractRealDistribution updateBetaDistribution(double truncationLowerBound, double truncationUpperBound,
			boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		double alpha = spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits());
		double beta = spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits());
		BetaDistribution distribution = new BetaDistribution(alpha, beta);

		mean = distribution.getNumericalMean();
		var = distribution.getNumericalVariance();
		std = Math.sqrt(var);
		double lowerBound = 0.000001;
		double upperBound = 0.999999;

		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		for (int i = 0; i < spinnerResolution.getSelection(); i++) {
			double val = lowerBound + (upperBound - lowerBound) * i / resolution;

			if (truncationLowerBound > truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				xValues[i] = val;
				yValues[i] = 0;
				maxProb = 0;
			} else {
				double prob = distribution.density(val);

				// Check if the value is out of bounds or not
				if ((val < truncationLowerBound && truncateLowerBound)
						|| (val > truncationUpperBound && truncateUpperBound)) {
					prob = 0;
				}

				if (prob > maxProb) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);
		xyGraph.primaryYAxis.setRange(0.0, 3);

		return distribution;
	}

	private AbstractRealDistribution updateParetoDistribution(double truncationLowerBound, double truncationUpperBound,
			boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		double scale = spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits());
		double shape = spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits());
		ParetoDistribution distribution = new ParetoDistribution(scale, shape);

		mean = Double.NaN;
		var = Double.NaN;
		std = Double.NaN;

		if (shape > 1) {
			mean = scale * shape / (shape - 1);
		}

		if (shape > 2) {
			std = Math.sqrt(shape / (shape - 2)) * scale / (shape - 1);
			var = shape * scale * scale / ((shape - 2) * (shape - 1) * (shape - 1));
		}

		double lowerBound = Math.max(0, scale - 1);
		double upperBound = Math.pow(4, 1 / shape) + scale * 2;

		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		for (int i = 0; i < spinnerResolution.getSelection(); i++) {
			double val = lowerBound + (upperBound - lowerBound) * i / resolution;

			if (truncationLowerBound > truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				xValues[i] = val;
				yValues[i] = 0;
				maxProb = 0;
			} else {
				double prob = distribution.density(val);

				// Check if the value is out of bounds or not
				if ((val < truncationLowerBound && truncateLowerBound)
						|| (val > truncationUpperBound && truncateUpperBound)) {
					prob = 0;
				}

				if (prob > maxProb) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);

		if (maxProb == 0) {
			xyGraph.primaryYAxis.setRange(0.0, 1);
		} else {
			xyGraph.primaryYAxis.setRange(0.0, maxProb * 1.1);
		}

		return distribution;
	}

	private AbstractRealDistribution updateUniformDistribution(double truncationLowerBound, double truncationUpperBound,
			boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		double min = spinnerLowerTruncationBound.getSelection() / Math.pow(10, spinnerLowerTruncationBound.getDigits());
		double max = spinnerUpperTruncationBound.getSelection() / Math.pow(10, spinnerUpperTruncationBound.getDigits());

		mean = Double.NaN;
		std = Double.NaN;
		var = Double.NaN;
		double lowerBound = min - 1;
		double upperBound = max + 1;
		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		UniformRealDistribution distribution = null;

		if (min >= max) {
			setErrorMessage("Upper bound cannot be below or equal to the lower bound.");
			lowerBound = 0;
			upperBound = 1;
			maxProb = 0;

			for (int i = 0; i < spinnerResolution.getSelection(); i++) {
				double val = lowerBound + (upperBound - lowerBound) * i / resolution;

				xValues[i] = val;
				yValues[i] = 0;
			}

			distribution = new UniformRealDistribution();
		} else {
			setErrorMessage(null);
			distribution = new UniformRealDistribution(min, max);

			mean = distribution.getNumericalMean();
			var = distribution.getNumericalVariance();
			std = Math.sqrt(var);

			for (int i = 0; i < spinnerResolution.getSelection(); i++) {
				double val = lowerBound + (upperBound - lowerBound) * i / resolution;

				double prob = distribution.density(val);

				if (prob > maxProb) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);

		if (maxProb == 0) {
			xyGraph.primaryYAxis.setRange(0.0, 1);
		} else {
			xyGraph.primaryYAxis.setRange(0.0, maxProb * 1.1);
		}

		return distribution;
	}

	private AbstractRealDistribution updateGammaDistribution(double truncationLowerBound, double truncationUpperBound,
			boolean truncateLowerBound, boolean truncateUpperBound, int resolution) {
		double alpha = spinnerMean.getSelection() / Math.pow(10, spinnerMean.getDigits());
		double beta = spinnerStd.getSelection() / Math.pow(10, spinnerStd.getDigits());
		GammaDistribution distribution = new GammaDistribution(alpha, (1 / beta));

		mean = alpha * beta;
		var = alpha * beta * beta;
		std = Math.sqrt(alpha) * beta;
		double lowerBound = Math.max(0, mean - 4 * std);
		double upperBound = mean + 4 * std;

		double maxProb = Double.NEGATIVE_INFINITY;
		double[] xValues = new double[resolution];
		double[] yValues = new double[resolution];

		for (int i = 0; i < spinnerResolution.getSelection(); i++) {
			double val = lowerBound + (upperBound - lowerBound) * i / resolution;

			if (truncationLowerBound > truncationUpperBound && truncateLowerBound && truncateUpperBound) {
				xValues[i] = val;
				yValues[i] = 0;
				maxProb = 0;
			} else {
				double prob = distribution.density(val);

				// Check if the value is out of bounds or not
				if ((val < truncationLowerBound && truncateLowerBound)
						|| (val > truncationUpperBound && truncateUpperBound)) {
					prob = 0;
				}

				if (prob > maxProb && Double.isFinite(prob)) {
					maxProb = prob;
				}

				xValues[i] = val;
				yValues[i] = prob;
			}
		}

		pdf.setBufferSize(resolution);
		pdf.setCurrentXDataArray(xValues);
		pdf.setCurrentYDataArray(yValues);
		xyGraph.primaryXAxis.setRange(lowerBound, upperBound);

		if (maxProb == 0) {
			xyGraph.primaryYAxis.setRange(0.0, 1);
		} else {
			xyGraph.primaryYAxis.setRange(0.0, maxProb * 1.1);
		}

		return distribution;
	}

	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Parameter distribution configuration");
		newShell.pack();
		newShell.setMinimumSize(800, 600);
	}

	@Override
	protected boolean isResizable() {
		return true;
	}

	@Override
	protected void okPressed() {
		MessageDialog messageDialog = new MessageDialog(getShell(), "Automated model generation", null,
				"Are you sure you want to create " + numModels
						+ " models automatically? Properties without a configured distribution will be assigned according to the current selection.",
				MessageDialog.QUESTION, new String[] { "Yes", "No" }, 0);

		if (messageDialog.open() == Window.OK) {
			super.okPressed();
		}
	}

	public HashMap<ModelProperty, DistributionConfig> getPropertyConfiguration() {
		return propertyConfiguration;
	}

	public int getNumModels() {
		return numModels;
	}
}

package at.fhhagenberg.mc.traffsim.communication.messaging;

import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;

public class VehicleDataPayload extends PositionPayload {

	private double speed;
	private double frontPosition;

	public VehicleDataPayload(Location pos, double speed, double frontPos, VehiclesLane lane) {
		super(pos, lane);
		this.speed = speed;
		this.frontPosition = frontPos;
	}

	public double getSpeed() {
		return speed;
	}

	@Override
	public int getSize() {
		return super.getSize() + Double.BYTES;
	}

	public double getFrontPosition() {
		return frontPosition;
	}

}

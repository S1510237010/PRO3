package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ContainerControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;

public abstract class ContainerControlConfigurationPage extends LongitudinalControlConfigurationPage {

	protected Combo comboControls;
	protected boolean areContainerControlsValid;
	protected Label lblControlWarning;

	protected Button btnAddChildControl;
	protected Button btnRemoveChildControl;

	protected ContainerControlConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		Label lblChildControls = new Label(grpGeneral, SWT.NONE);
		lblChildControls.setText("Child Controls");

		comboControls = new Combo(grpGeneral, SWT.READ_ONLY);
		comboControls.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));

		lblControlWarning = new Label(grpGeneral, SWT.NONE);
		lblControlWarning.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		lblControlWarning.setText("A longitudinal control is required.");
		lblControlWarning.setForeground(new Color(Display.getCurrent(), 255, 0, 0));
		lblControlWarning.setVisible(false);

		btnAddChildControl = new Button(grpGeneral, SWT.NONE);
		btnAddChildControl.setText("Add to container");
		btnAddChildControl.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, true, false, 2, 1));
		btnAddChildControl.setToolTipText("Adds the selected longitudinal control to the selected container");
		btnAddChildControl.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				addChildControlToContainer();
				viewer.refresh();
				validatePage();
				getWizard().getContainer().updateButtons();
			}
		});

		btnRemoveChildControl = new Button(grpGeneral, SWT.NONE);
		btnRemoveChildControl.setText("Remove to container");
		btnRemoveChildControl.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, true, false, 2, 1));
		btnRemoveChildControl.setToolTipText("Removes the longitudinal added the latest from the selected container");
		btnRemoveChildControl.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				removeChildControlFromContainer();
				viewer.refresh();
				validatePage();
				getWizard().getContainer().updateButtons();
			}
		});

		comboLongitudinalModel.setEnabled(false);
		lblModelWarning.setVisible(false);
	}

	@Override
	protected boolean isAddPossible() {
		if (comboControls == null) {
			return false;
		}

		return comboControls.getItemCount() > 0;
	}

	@Override
	protected boolean isStochasticAddPossible() {
		return false;
	}

	protected Class<? extends AbstractBean> getModelClass() {
		return LongitudinalControlBean.class;
	}

	@Override
	protected void validatePage() {
		super.validatePage();

		if (modelSet != null) {
			int numInvalidControls = 0;

			for (AbstractBean bean : modelSet) {
				if (bean instanceof ContainerControlBean) {
					if (((ContainerControlBean) bean).getNumChildControls() < 1) {
						numInvalidControls++;
					}
				}
			}

			if (numInvalidControls == 0) {
				areContainerControlsValid = true;
			} else {
				StringBuilder sb = new StringBuilder();
				sb.append("Some of your controls do not have child controls. Make sure each container control has at least one child. \n");

				if (getErrorMessage() != null) {
					sb.append(getErrorMessage());
				}
				
				setErrorMessage(sb.toString());
				areContainerControlsValid = false;
			}
		} else {
			areContainerControlsValid = true;
		}
	}

	@Override
	public boolean isPageComplete() {
		return modelSet != null && !modelSet.isEmpty() && areContainerControlsValid;
	}

	@Override
	protected void onTableViewerSelectionChanged() {
		super.onTableViewerSelectionChanged();

		if (((IStructuredSelection) viewer.getSelection()).getFirstElement() != null) {
			btnAddChildControl.setEnabled(true);

			int index = modelSet.indexOf(((IStructuredSelection) viewer.getSelection()).getFirstElement());

			if (((ContainerControlBean) modelSet.get(index)).getNumChildControls() > 0) {
				btnRemoveChildControl.setEnabled(true);
			} else {
				btnRemoveChildControl.setEnabled(false);
			}
		} else {
			btnAddChildControl.setEnabled(false);
			btnRemoveChildControl.setEnabled(false);
		}
	}

	protected void addChildControlToContainer() {
		if (modelSet != null && !modelSet.isEmpty()) {
			int index = modelSet.indexOf(((IStructuredSelection) viewer.getSelection()).getFirstElement());
			((ContainerControlBean) modelSet.get(index)).addControlIdentifier(comboControls.getText());

			if (((ContainerControlBean) modelSet.get(index)).getNumChildControls() > 0) {
				btnRemoveChildControl.setEnabled(true);
			}
		}
	}

	protected void removeChildControlFromContainer() {
		if (modelSet != null && !modelSet.isEmpty()) {
			int index = modelSet.indexOf(((IStructuredSelection) viewer.getSelection()).getFirstElement());
			((ContainerControlBean) modelSet.get(index)).removeLastControlIdentifier();

			if (((ContainerControlBean) modelSet.get(index)).getNumChildControls() == 0) {
				btnRemoveChildControl.setEnabled(false);
			}
		}
	}
}

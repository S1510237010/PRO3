package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.Iterables;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightControllerBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.statistics.IStatisticsProvider;

/**
 * Base class for all traffic light controller instances. Traffic light controllers are resposible for maintaining and operating all traffic
 * lights at an intersection by making use of the control logics which are associated to the individual traffic lights.
 *
 * @author Manuel Lindorfer
 *
 * @param <T>
 *            type of control logic the controller is operating on
 */
@SuppressWarnings("unchecked")
public abstract class TrafficLightController<T extends ControlLogic> implements ISimulationTimeUpdatable, IStatisticsProvider {

	public static long NEXT_ID = 0;
	protected long id;
	protected AbstractJunction junction;
	protected Iterable<T> controlLogics;

	protected boolean areLanesOperatedIndividually;

	/**
	 * Creates a new traffic light controller using the given identifier for the provided junction.
	 *
	 * @param id
	 *            unique identifier
	 * @param junction
	 *            the junction operated by the traffic light controller
	 */
	public TrafficLightController(long id, AbstractJunction junction) {
		this.id = id;
		this.junction = junction;
		this.areLanesOperatedIndividually = true;

		updateControlLogics();
	}

	/**
	 * Get's the traffic light controller's unique identifier.
	 *
	 * @return unique identifier
	 */
	public long getId() {
		return id;
	}

	/**
	 * Get's the junction operated by the traffic light controller.
	 *
	 * @return the junction under control
	 */
	public AbstractJunction getJunction() {
		return junction;
	}

	/**
	 * Get's a collection of control logics of all traffic lights mounted in approaches to the target junction.
	 *
	 * @return an iterable collection of control logics
	 */
	public Iterable<T> getControlLogics() {
		return controlLogics;
	}

	/**
	 * Determines whether all lanes of an approach are operated individually or not. This is relevant e.g. in case of a cyclic control
	 * scheme, where each traffic light is served after the other.
	 *
	 * @return true if all lanes are operated individually, false else
	 */
	public boolean getAreLanesOperatedIndividually() {
		return areLanesOperatedIndividually;
	}

	/**
	 * Specifies whether all lanes of an approach are operated individually or not. This is relevant e.g. in case of a cyclic control
	 * scheme, where each traffic light is served after the other.
	 *
	 * @param areLanesOperatedIndividually
	 *            true if all lanes should be operated individually, false else
	 */
	public void setAreLanesOperatedIndividually(boolean areLanesOperatedIndividually) {
		this.areLanesOperatedIndividually = areLanesOperatedIndividually;
	}

	/**
	 * Re-generates the set of control logics by iterating over all approaches of the target junction.
	 */
	public void updateControlLogics() {
		Iterable<T> logics = Collections.emptyList();

		for (JunctionApproach approach : junction.getApproaches()) {
			logics = (Iterable<T>) Iterables.concat(logics, approach.getControlLogics());
		}

		controlLogics = logics;
		onControlLogicsChanged();
	}

	@Override
	public void timeStep(double dt, Date simulationTime, double simulationRuntime) {
		long delayMillis = Math.round(dt * 1000);
		long runtimeMillis = Math.round(simulationRuntime * 1000);
		update(delayMillis, runtimeMillis);
	}

	/**
	 * Callback invoked when the control logics managed by the controller have been updated.
	 */
	protected void onControlLogicsChanged() {

	}

	/**
	 * Converts the traffic light controller to the corresponding data entity.
	 *
	 * @return a serializable traffic light controller entity
	 */
	public abstract TrafficLightControllerBean toBean();

	/**
	 * Get's the traffic light controllers control scheme.
	 *
	 * @return the control scheme
	 */
	public abstract TrafficLightControllers getControlMode();

	/**
	 * Update method triggered in every simulation time step.
	 *
	 * @param dt
	 *            the simulation update interval in milliseconds
	 * @param simulationRuntime
	 *            the simulation runtime in milliseconds
	 */
	protected abstract void update(long dt, long simulationRuntime);

	@Override
	public Map<String, Number> obtainStatistics() {
		Map<String, Number> statistics = new HashMap<>();
		return statistics;
	}
}

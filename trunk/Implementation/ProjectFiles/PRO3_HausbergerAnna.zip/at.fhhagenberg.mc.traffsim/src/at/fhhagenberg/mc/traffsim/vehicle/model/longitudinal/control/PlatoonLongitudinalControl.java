package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.TrafficUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IPlatoonLongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.PlatoonLongitudinalControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon.ManeuverType;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon.State;

public class PlatoonLongitudinalControl extends LongitudinalControl<ILongitudinalModel> {

	/**
	 * XML config data of control
	 */
	private PlatoonLongitudinalControlData data;

	/**
	 * Platoon of vehicle
	 */
	private Platoon platoon;

	/**
	 * Longitudinal model of leader vehicle
	 */
	private ILongitudinalModel leaderModel;

	/**
	 * Longitudinal model of following vehicle
	 */
	private IPlatoonLongitudinalModel followerModel;

	/**
	 * Longitudinal model of following vehicle
	 */
	private ILongitudinalModel maneuverModel;

	/**
	 * Longitudinal model of human vehicle
	 */
	private ILongitudinalModel humanModel;

	/**
	 * Empty CTor for Kryo
	 */
	public PlatoonLongitudinalControl() {

	}

	/**
	 * CTor
	 *
	 * @param data
	 *            Data with params from XML
	 */
	public PlatoonLongitudinalControl(PlatoonLongitudinalControlData data) {
		super(data.getIdentifier());
		this.data = data;
		this.leaderModel = this.data.getLeaderLongitudinalModel().createCopyFor(data.getLeaderLongitudinalModel().getModelData().getvTarget());
		this.followerModel = (IPlatoonLongitudinalModel) this.data.getFollowerLongitudinalModel()
				.createCopyFor(data.getFollowerLongitudinalModel().getModelData().getvTarget());
		this.maneuverModel = this.data.getManeuverLongitudinalModel().createCopyFor(data.getManeuverLongitudinalModel().getModelData().getvTarget());
		this.humanModel = this.data.getHumanLongitudinalModel().createCopyFor(data.getHumanLongitudinalModel().getModelData().getvTarget());
		this.setCllxtEnabled(false);
	}

	/**
	 * Platoon of vehicle
	 *
	 * @return platoon
	 */
	public Platoon getPlatoon() {
		return platoon;
	}

	/**
	 * Platoon of vehicle
	 *
	 * @param platoon
	 *            Platoon
	 */
	public void setPlatoon(Platoon platoon) {
		this.platoon = platoon;
		this.followerModel.setPlatoon(platoon);
		if (platoon != null) {
			this.leaderModel.getModelData().setvTarget(platoon.getDesiredSpeed());
		}
	}

	/**
	 * Get leader model
	 *
	 * @return model
	 */
	public ILongitudinalModel getLeaderModel() {
		return leaderModel;
	}

	/**
	 * Set leader model
	 *
	 * @param leaderModel
	 */
	public void setLeaderModel(ILongitudinalModel leaderModel) {
		this.leaderModel = leaderModel;
	}

	/**
	 * Get follower model
	 *
	 * @return model
	 */
	public IPlatoonLongitudinalModel getFollowerModel() {
		return followerModel;
	}

	/**
	 * Set follower model
	 *
	 * @param followerModel
	 *            model
	 */
	public void setFollowerModel(IPlatoonLongitudinalModel followerModel) {
		this.followerModel = followerModel;
	}

	/**
	 * Get maneuver model
	 *
	 * @return model
	 */
	public ILongitudinalModel getManeuverModel() {
		return maneuverModel;
	}

	/**
	 * Set maneuver model
	 *
	 * @param maneuverModel
	 *            model
	 */
	public void setManeuverModel(ILongitudinalModel maneuverModel) {
		this.maneuverModel = maneuverModel;
	}

	/**
	 * Get human model
	 *
	 * @return model
	 */
	public ILongitudinalModel getHumanModel() {
		return humanModel;
	}

	/**
	 * Set human model
	 *
	 * @param humanModel
	 *            model
	 */
	public void setHumanModel(ILongitudinalModel humanModel) {
		this.humanModel = humanModel;
	}

	@Override
	public LongitudinalControl<ILongitudinalModel> copy(double vTarget) {
		PlatoonLongitudinalControl copy = new Kryo().copy(this);
		copy.setPlatoon(null);
		copy.getFollowerModel().getModelData().setvTarget(vTarget);
		copy.getManeuverModel().getModelData().setvTarget(vTarget);
		copy.getHumanModel().getModelData().setvTarget(vTarget);
		return copy;
	}

	@Override
	public void setLongitudinalModel(ILongitudinalModel longitudinalModel) {
		if (platoon == null) {
			this.humanModel = longitudinalModel;
		}
		this.leaderModel = longitudinalModel;
	}

	@Override
	public ILongitudinalModel getLongitudinalModel() {
		if (platoon == null) {
			return humanModel;
		}
		return leaderModel;
	}

	@Override
	public double calcAccSolitary(Vehicle me, VehiclesLane seg, int lookForward, Vehicle virtualFront, double virtualFrontDistance) {
		AccUpdateData accData = getAccUpdateData(me, seg, virtualFront, virtualFrontDistance, lookForward);
		return calcAcc(false, me, accData, 1, 1, 1);
	}

	@Override
	protected double calcAccCustom(Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA) {
		return calcAcc(true, me, accData, alphaT, alphaV0, alphaA);
	}

	// ##########################
	// # STATE MACHINE #
	// ##########################

	/**
	 *
	 * @param comprehensive
	 *            is the calculation comprehensive for state
	 * @param me
	 *            current vehicle
	 * @param accData
	 *            acc data update for current vehicle
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @return
	 */
	private double calcAcc(boolean comprehensive, Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA) {
		// not in a platoon -> human model
		if (platoon == null) {
			return humanModel.calcAcc(me, me.getCurrentSpeed(), accData.distance, accData.speedDiff, accData.accLead, alphaT, alphaV0, alphaA,
					getSpeedLimitMps(me));
		}

		// workaround for MOBIL
		if (!platoon.getAllVehicles().contains(me)) {
			return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.distance, accData.speedDiff, accData.accLead, alphaT, alphaV0, alphaA,
					getSpeedLimitMps(me));
		}

		State state = platoon.getVehicleState(me);

		switch (state) {
		case IDLE:
			return calcAccIdle(comprehensive, me, accData, alphaT, alphaV0, alphaA, getSpeedLimitMps(me));
		case LANE_CHANGE:
			return calcAccLaneChange(comprehensive, me, accData, alphaT, alphaV0, alphaA, getSpeedLimitMps(me));
		case JOIN_REQUEST:
			return calcAccJoinRequest(comprehensive, me, accData, alphaT, alphaV0, alphaA, getSpeedLimitMps(me));
		case JOIN:
			return calcAccJoin(comprehensive, me, accData, alphaT, alphaV0, alphaA, getSpeedLimitMps(me));
		case LEAVE:
		case DISSOLVE:
			return calcAccLeave(comprehensive, me, accData, alphaT, alphaV0, alphaA, getSpeedLimitMps(me));
		}

		// should never be applied
		return 0;
	}

	/**
	 * Helper for calculation of acceleration for IDLE state
	 *
	 * @param comprehensive
	 *            is the calculation comprehensive for state
	 * @param me
	 *            current vehicle
	 * @param accData
	 *            acc data update for current vehicle
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @param speedLimit
	 *            speed limit for calculation
	 * @return desired acceleration for vehicle
	 */
	private double calcAccIdle(boolean comprehensive, Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		State platoonState = platoon.getPlatoonState();
		Vehicle leader = platoon.getLeader();
		switch (platoonState) {
		case IDLE:
		case LANE_CHANGE:
			return calcAccIdleNormal(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);
		case JOIN_REQUEST:
			// special case front join
			if (leader.equals(me) && platoon.getManeuverType() == ManeuverType.FRONT) {
				double spltd = (platoon.getDesiredSpeed() < speedLimit) ? platoon.getDesiredSpeed() : speedLimit;
				AccUpdateData accDataIgnorePreceding = getAccUpdateData(me, accData.getLaneSegment(), null, 0, 2);
				double accDesLeaderIgnorePreceding = maneuverModel.calcAcc(me, me.getCurrentSpeed(), accDataIgnorePreceding.getDistance(),
						accDataIgnorePreceding.getSpeedDiff(), accDataIgnorePreceding.getAccLead(), alphaT, alphaV0, alphaA, spltd);
				// double accDesLeaderIgnorePreceding = maneuverModel.calcAcc(me, me.getCurrentSpeed(),
				// LongitudinalControl.FREE_FLOW_DISTANCE, 0, 0, alphaT, alphaV0, alphaA, spltd);
				double accDesLeader = maneuverModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(),
						accData.getAccLead(), alphaT, alphaV0, alphaA, spltd);

				// Ignore the preceding vehicle in acc calculation if it is the joining vehicle
				Vehicle preceding = platoon.getManeuverVehicle();
				if (accData.getFrontVehicle() != null && accData.getFrontVehicle().equals(preceding)
						&& accData.getFrontVehicle().getCurrentSpeed() >= leader.getCurrentSpeed() - platoon.getManeuverSpeedTOffset() - 1) {
					return accDesLeaderIgnorePreceding;
				}
				return accDesLeader;
			}
			return calcAccIdleNormal(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);
		case JOIN:
			// special case front join
			if (leader.equals(me) && platoon.getManeuverType() == ManeuverType.FRONT) {
				Vehicle newLeader = platoon.getManeuverVehicle();
				// platoon follow acc for join
				AccUpdateData accDataPlatoon = getAccUpdateData(me, accData.getLaneSegment(), newLeader);
				double acc = followerModel.calcAcc(me, me.getCurrentSpeed(), accDataPlatoon.getDistance(), accDataPlatoon.getSpeedDiff(),
						accDataPlatoon.getAccLead(), newLeader.getCurrentSpeed(), alphaT, alphaV0, alphaA, speedLimit);
				return acc;
			}
			return calcAccIdleNormal(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);
		case LEAVE:
		case DISSOLVE:
			// special case front leave
			if (leader.equals(me) && platoon.getManeuverType() == ManeuverType.FRONT) {
				Vehicle oldLeader = platoon.getManeuverVehicle();

				// leader acc ignoring the new leader for join and leave if maneuver vehicle does not decelerate
				double accDesLeaderIgnorePreceding = leaderModel.calcAcc(me, me.getCurrentSpeed(), 10000, 0, 0, alphaT, alphaV0, alphaA, speedLimit);
				// leader acc for leave if maneuver vehicle decelerates
				double accDesLeader = leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(),
						accData.getAccLead(), alphaT, alphaV0, alphaA, speedLimit);

				double accDes = 0;

				if (oldLeader.getCurrentAcc() >= 0) {
					accDes = accDesLeaderIgnorePreceding;
				} else {
					accDes = accDesLeader;
				}

				return accDes;
			}
			return calcAccIdleNormal(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);
		}
		return 0;

	}

	/**
	 * Helper with extracted normal idle behavior of vehicle
	 *
	 * @param comprehensive
	 *            is the calculation comprehensive for state
	 * @param me
	 *            current vehicle
	 * @param accData
	 *            acc data update for current vehicle
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @param speedLimit
	 *            speed limit for calculation
	 * @return desired acceleration for vehicle in normal idle state
	 */
	private double calcAccIdleNormal(boolean comprehensive, Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		if (platoon.getLeader().equals(me)) {
			// lane count check -> if lane count less than 2 -> dissolve platoon
			if (TrafficUtil.getTrafficLaneCountForVehicle(me) < platoon.getMinimumLaneCount()) {
				platoon.dissolve(me, false);
			}
			return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT, alphaV0,
					alphaA, speedLimit);
		}
		double accLeader = leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
				alphaV0, alphaA, speedLimit);
		AccUpdateData accDataPlatoon = getAccUpdateData(me, accData.getLaneSegment(), platoon.getPreceding(me));
		double accFollow = followerModel.calcAcc(me, me.getCurrentSpeed(), accDataPlatoon.getDistance(), accDataPlatoon.getSpeedDiff(),
				accDataPlatoon.getAccLead(), platoon.getLeader().getCurrentSpeed(), alphaT, alphaV0, alphaA, speedLimit);
		// if front vehicle is not inside this platoon and leader model is less than follow model return leader model
		if (accData.getFrontVehicle() != null && !platoon.getAllVehicles().contains(accData.getFrontVehicle()) && accLeader < accFollow
				&& accLeader < 0) {
			if (comprehensive) {
				platoon.onVehicleStateError(me);
			}

			return accLeader;
		}

		return accFollow;
	}

	/**
	 * Helper for calculation of acceleration for LANE_CHANGE state
	 *
	 * @param comprehensive
	 *            is the calculation comprehensive for state
	 * @param me
	 *            current vehicle
	 * @param accData
	 *            acc data update for current vehicle
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @param speedLimit
	 *            speed limit for calculation
	 * @return desired acceleration for vehicle
	 */
	private double calcAccLaneChange(boolean comprehensive, Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		// TODO error states
		platoon.onVehicleStateReadyLong(me);
		return calcAccIdleNormal(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);

	}

	/**
	 * Helper for calculation of acceleration for JOIN REQUEST state
	 *
	 * @param comprehensive
	 *            is the calculation comprehensive for state
	 * @param me
	 *            current vehicle
	 * @param accData
	 *            acc data update for current vehicle
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @param speedLimit
	 *            speed limit for calculation
	 * @return desired acceleration for vehicle
	 */
	private double calcAccJoinRequest(boolean comprehensive, Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		ManeuverType maneuverType = platoon.getManeuverType();
		switch (maneuverType) {
		case FRONT:
			Vehicle leader = platoon.getLeader();
			if (leader == null) {
				// first/last vehicle in platoon
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}
			VehicleWithDistance rear = accData.getLaneSegment().rearVehicle(me);
			VehicleWithDistance distanceToLeader = SpatialUtil.getDistanceBetween(leader, me);

			double leaderGap = calcMinimumHumanGap(leader.getCurrentSpeed());

			// wrong lane or behind platoon
			if (leader.getLaneIndex() != accData.getLaneSegment().getLaneIndex() || distanceToLeader.getDistance() < 0) {
				double accHuman = humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(),
						alphaT, alphaV0, alphaA, speedLimit);
				// vfront to move to desired join position
				AccUpdateData accDataVfront = new AccUpdateData(-distanceToLeader.getDistance() + me.getLength() + 2 * leaderGap,
						me.getCurrentSpeed() - leader.getCurrentSpeed(), leader.getCurrentAcc(), leader.getType(), leader, accData.getLaneSegment());
				double accPlatoon = maneuverModel.calcAcc(me, me.getCurrentSpeed(), accDataVfront.getDistance(), accDataVfront.getSpeedDiff(),
						accDataVfront.getAccLead(), alphaT, alphaV0, alphaA, speedLimit);
				double acc = 0;
				// if gap between tail and me is less than human security distance change to side join from back
				if (accDataVfront.getDistance() <= leaderGap + platoon.getManeuverHumanDistanceThresholdOffset()) {
					acc = accHuman;
				} else if (accHuman < 0) {
					acc = accHuman;
				} else {
					acc = accPlatoon;
				}

				// distance to platoon exceeds max join distance -> error
				if (distanceToLeader.getDistance() >= platoon.getMaxDistanceForJoin() && comprehensive) {
					platoon.onVehicleStateError(me);
				}
				return acc;
			} else if (!rear.getVehicle().equals(leader)) {
				// vehicle in between -> return leader model to wait until vehicle in between overtakes
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			} else {
				// no vehicle in between
				// if minimum human security gap reached and speed of me is not too big
				if (rear.getDistance() <= leaderGap && me.getCurrentSpeed() <= leader.getCurrentSpeed()) {
					if (comprehensive) {
						platoon.onVehicleStateReadyLong(me);
						return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(),
								alphaT, alphaV0, alphaA, speedLimit);
					}
				}
				// cap speed of joining vehicle to 10 kph slower than the leader to get closer to platoon
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, leader.getCurrentSpeed() - platoon.getManeuverSpeedTOffset());
			}
		case TAIL:
			Vehicle tail = platoon.getTail();

			if (tail == null) {
				// first/last vehicle in platoon
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}

			if (tail.getLaneIndex() != accData.getLaneSegment().getLaneIndex()) {
				// wrong lane
				double accHuman = humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(),
						alphaT, alphaV0, alphaA, speedLimit);

				AccUpdateData accDataPlatoon = getAccUpdateData(me, accData.getLaneSegment(), tail);
				double tailGap = calcMinimumHumanGap(tail.getCurrentSpeed());
				double accPlatoon = maneuverModel.calcAcc(me, me.getCurrentSpeed(), accDataPlatoon.getDistance(), accDataPlatoon.getSpeedDiff(),
						accDataPlatoon.getAccLead(), alphaT, alphaV0, alphaA, speedLimit);

				// if gap between tail and me is less than human security distance change to side join from back
				if (accDataPlatoon.getDistance() <= tailGap + platoon.getManeuverHumanDistanceThresholdOffset()) {
					platoon.setManeuverType(ManeuverType.SIDE);
				}
				if (accHuman < 0) {
					return accHuman;
				} else {
					return accPlatoon;
				}
			} else if (!accData.getFrontVehicle().equals(tail)) {
				// vehicle in between -> return human model to wait until vehicle in between overtakes
				return humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			} else {
				// ready, no vehicle in between, return idle acc
				if (accData.getDistance() <= calcMinimumHumanGap(me.getCurrentSpeed()) + platoon.getManeuverHumanDistanceThresholdOffset()) {
					if (comprehensive) {
						platoon.onVehicleStateReadyLong(me);
					}
				}
				return maneuverModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}
		case SIDE:
			double acc = 0;
			// human acc on current lane
			double accHuman = humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(),
					alphaT, alphaV0, alphaA, speedLimit);

			// acc for v front vehicle which is positioned at preceding position + human security gap
			Vehicle preceding = platoon.getPreceding(me);
			AccUpdateData accDataPlatoon = getAccUpdateData(me, accData.getLaneSegment(), preceding);
			double gap = calcMinimumHumanGap(preceding.getCurrentSpeed());
			AccUpdateData accDataVFront = new AccUpdateData(accDataPlatoon.getDistance() + (gap), accDataPlatoon.getSpeedDiff(),
					accDataPlatoon.getAccLead(), accDataPlatoon.getFrontVehicleType(), accDataPlatoon.getFrontVehicle(),
					accDataPlatoon.getLaneSegment());
			double accVFront = maneuverModel.calcAcc(me, me.getCurrentSpeed(), accDataVFront.getDistance(), accDataVFront.getSpeedDiff(),
					accDataVFront.getAccLead(), alphaT, alphaV0, alphaA, speedLimit);

			// select smaller acc (e.g if human would because of real front vehicles human model is selected)
			if (accHuman < 0) {
				acc = accHuman;
			} else {
				acc = accVFront;
			}

			// ready if gap to v front vehicle is less or equal to human security gap
			if (accDataVFront.getDistance() <= gap + platoon.getManeuverHumanDistanceThresholdOffset()) {
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
			}
			return acc;
		}
		// should not happen
		return 0;

	}

	/**
	 * Helper for calculation of acceleration for JOIN state
	 *
	 * @param comprehensive
	 *            is the calculation comprehensive for state
	 * @param me
	 *            current vehicle
	 * @param accData
	 *            acc data update for current vehicle
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @param speedLimit
	 *            speed limit for calculation
	 * @return desired acceleration for vehicle
	 */
	private double calcAccJoin(boolean comprehensive, Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		ManeuverType maneuverType = platoon.getManeuverType();
		switch (maneuverType) {
		case FRONT:
			Vehicle follower = platoon.getLeader();
			if (follower == null) {
				// first vehicle in platoon
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}
			VehicleWithDistance rear = accData.getLaneSegment().rearVehicle(me);

			// vehicle between leader and me -> error -> back to join request
			if (rear == null || !follower.equals(rear.getVehicle())) {
				if (comprehensive) {
					platoon.onVehicleStateError(me);
				}
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}

			if (rear.getDistance() <= (platoon.getDesiredGap(me) + platoon.getManeuverPlatoonDistanceThresholdOffset())) {
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
			}
			return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT, alphaV0,
					alphaA, speedLimit);

		case TAIL:
			Vehicle tail = platoon.getPreceding(me); // don't use getTail because of JOIN after SIE leave
			if (tail == null) {
				// first/last vehicle in platoon
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}

			// vehicle between me and tail -> error -> back to join request
			if (!tail.equals(accData.getFrontVehicle())) {
				if (comprehensive) {
					platoon.onVehicleStateError(me);
				}
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}
			if (accData.getDistance() <= (platoon.getDesiredGap(me) + platoon.getManeuverPlatoonDistanceThresholdOffset())) {
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
			}
			return calcAccIdle(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);
		case SIDE:
			Vehicle leader = platoon.getLeader();
			if (leader == null) {
				// first/last vehicle in platoon
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
				return leaderModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}
			LaneSegment newLaneSegment = me.getRoadSegment().getLaneSegments().get(leader.getLaneIndex());

			Vehicle preceding = platoon.getPreceding(me);
			Vehicle following = platoon.getFollowing(me);
			VehicleWithDistance newFront = newLaneSegment.frontVehicle(me);
			VehicleWithDistance newRear = newLaneSegment.rearVehicle(me);
			boolean frontReady = false;
			boolean backReady = false;

			// not accData because only ready if really on right lane, no acc calculation inside this if statement
			if (me.getLaneIndex() == leader.getLaneIndex() && !me.isInProcessOfLaneChange()) {
				// if no preceding exist or preceding is new front and gap is closed
				if (preceding == null || (newFront != null && newFront.getVehicle().equals(preceding)
						&& newFront.getDistance() < platoon.getDesiredGap(me) + platoon.getManeuverPlatoonDistanceThresholdOffset())) {
					frontReady = true;
				}

				// if no following exist or following is new rear and gap is closed
				if (following == null || (newRear != null && newRear.getVehicle().equals(following)
						&& newRear.getDistance() < platoon.getDesiredGap(me) + platoon.getManeuverPlatoonDistanceThresholdOffset())) {
					backReady = true;
				}

				if (comprehensive && frontReady && backReady) {
					platoon.onVehicleStateReadyLong(me);
				}
			}

			// consider preceding vehicles if joining vehicle is not on same lane as platoon
			double humanAcc = humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(),
					alphaT, alphaV0, alphaA, speedLimit);
			if (humanAcc < 0 && leader.getLaneIndex() != accData.getLaneSegment().getLaneIndex() && !me.isInProcessOfLaneChange()) {
				return humanAcc;
			} else {
				return calcAccIdle(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);
			}
		}
		// should not happen
		return 0;
	}

	/**
	 * Helper for calculation of acceleration for LEAVE state
	 *
	 * @param comprehensive
	 *            is the calculation comprehensive for state
	 * @param me
	 *            current vehicle
	 * @param accData
	 *            acc data update for current vehicle
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @param speedLimit
	 *            speed limit for calculation
	 * @return desired acceleration for vehicle
	 */
	private double calcAccLeave(boolean comprehensive, Vehicle me, AccUpdateData accData, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		ManeuverType maneuverType = platoon.getManeuverType();
		switch (maneuverType) {
		case FRONT:
			Vehicle leader = platoon.getLeader();
			if (leader == null) {
				// last vehicle in platoon
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
				return humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}
			double humanGapLeader = calcMinimumHumanGap(leader.getCurrentSpeed());
			double accDesMeFront = humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(),
					alphaT, alphaV0, alphaA, speedLimit);
			VehicleWithDistance leaderWithDistance = accData.getLaneSegment().rearVehicle(me);
			// different lane than leader or rear vehicle is not leader or human gap reached
			if (leader.getLaneIndex() != accData.getLaneSegment().getLaneIndex() || leaderWithDistance == null
					|| !leaderWithDistance.getVehicle().equals(leader) || leaderWithDistance.getDistance() > humanGapLeader) {
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
			}
			return accDesMeFront;
		case TAIL:
			Vehicle tail = platoon.getTail();
			if (tail == null) {
				// last vehicle in platoon
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
				return humanModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(), alphaT,
						alphaV0, alphaA, speedLimit);
			}
			double humanGapMe = calcMinimumHumanGap(me.getCurrentSpeed());

			double accDesIgnorePreceding = maneuverModel.calcAcc(me, me.getCurrentSpeed(), LongitudinalControl.FREE_FLOW_DISTANCE, 0, 0, alphaT,
					alphaV0, alphaA, tail.getCurrentSpeed() - platoon.getManeuverSpeedTOffset());

			double accDesNormal = maneuverModel.calcAcc(me, me.getCurrentSpeed(), accData.getDistance(), accData.getSpeedDiff(), accData.getAccLead(),
					alphaT, alphaV0, alphaA, speedLimit);

			VehicleWithDistance tailWithDistance = accData.getLaneSegment().frontVehicle(me);
			// different lane than leader or human gap reached
			if (tail.getLaneIndex() != accData.getLaneSegment().getLaneIndex() || tailWithDistance == null
					|| !tailWithDistance.getVehicle().equals(tail)
					|| tailWithDistance.getDistance() >= humanGapMe - platoon.getManeuverHumanDistanceThresholdOffset()) {
				if (comprehensive) {
					platoon.onVehicleStateReadyLong(me);
				}
			}
			// if tail decelerates or front is not tail don't ignore preceding vehicles
			if (tail.getCurrentSpeed() < me.getCurrentSpeed() - 1 || !tail.equals(tailWithDistance.getVehicle())) {
				return accDesNormal;
			} else {
				return accDesIgnorePreceding;
			}
		case SIDE:
			// Idle because if simulation reaches end of road me can be a possible leader
			double acc = calcAccIdle(comprehensive, me, accData, alphaT, alphaV0, alphaA, speedLimit);
			if (comprehensive) {
				platoon.onVehicleStateReadyLong(me);
			}
			return acc;
		}
		// should not happen
		return 0;
	}

	// ##########################
	// # ACC HELPERS #
	// ##########################

	/**
	 * Helper to calculate minimum human gap based on speed
	 *
	 * @param v
	 *            current speed of vehicle
	 * @return minimum human gap
	 */
	private double calcMinimumHumanGap(double v) {
		return TrafficUtil.getMinimumSafetyDistance(v, humanModel.getModelData().gettMin(), humanModel.getModelData().getsMin());
	}

	/**
	 * Helper to get acc update for follower in platoon
	 *
	 * @param me
	 *            current vehicle
	 * @param seg
	 *            Lane segment of current vehicle
	 * @param preceding
	 *            preceding of current vehicle
	 * @return
	 */
	private AccUpdateData getAccUpdateData(Vehicle me, VehiclesLane seg, Vehicle preceding) {
		double s = 0;
		double dv = me.getCurrentSpeed() - preceding.getCurrentSpeed();

		double aLead = preceding.getCurrentAcc();
		VehicleType frontVehicleType = preceding.getType();
		Vehicle vehicle = preceding;

		VehicleWithDistance vd = SpatialUtil.getDistanceBetween(me, preceding);
		if (vd == null) {
			s = LongitudinalControl.FREE_FLOW_DISTANCE;
		} else {
			s = SpatialUtil.getDistanceBetween(me, preceding).getDistance();
		}

		return new AccUpdateData(s, dv, aLead, frontVehicleType, vehicle, seg);
	}

}

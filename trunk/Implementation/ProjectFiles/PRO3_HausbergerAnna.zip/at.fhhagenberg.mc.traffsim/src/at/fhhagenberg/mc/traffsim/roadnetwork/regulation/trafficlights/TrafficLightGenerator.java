package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.QueueMonitor;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.CyclicController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.FixedTimeController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightControllers;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.CyclicControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.FixedTimeControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.SelfOrganizingControlLogic;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.CyclicTrafficLightConfigurationParameters;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.FixedTimeTrafficLightConfigurationParameters;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.SelfOrganizingTrafficLightConfigurationParameters;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.TrafficLightConfigurationParameters;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.junction.TrafficLightGeneratorParameterPage.TrafficLightGenerationParameters;

public class TrafficLightGenerator {

	private SimulationModel model;

	public TrafficLightGenerator(SimulationModel activeModel) {
		this.model = activeModel;
	}

	public Pair<Integer, Integer> generateTrafficLights(TrafficLightGenerationParameters generalParameters,
			TrafficLightConfigurationParameters regulationParameters) {

		if (model == null) {
			return new ImmutablePair<Integer, Integer>(0, 0);
		}

		List<AbstractJunction> junctions = getRelevantJunctions(generalParameters);

		if (junctions.isEmpty()) {
			return new ImmutablePair<Integer, Integer>(0, 0);
		}

		int trafficLightsGenerated = 0;

		for (AbstractJunction junction : junctions) {
			if (regulationParameters.mergeApproaches) {
				trafficLightsGenerated += addTrafficLightsPerApproach(junction, regulationParameters);
			} else {
				trafficLightsGenerated += addTrafficLightsPerLane(junction, regulationParameters);
			}

			TrafficLightController<?> controller;

			// Create traffic controller
			if (regulationParameters.controlMode == TrafficLightControllers.CYCLIC) {
				CyclicTrafficLightConfigurationParameters params = (CyclicTrafficLightConfigurationParameters) regulationParameters;
				controller = new CyclicController(TrafficLightController.NEXT_ID, junction, params.startWithGreenPhase);
			} else if (regulationParameters.controlMode == TrafficLightControllers.FIXED_TIMED) {
				controller = new FixedTimeController(TrafficLightController.NEXT_ID, junction);
			} else {
				SelfOrganizingTrafficLightConfigurationParameters params = (SelfOrganizingTrafficLightConfigurationParameters) regulationParameters;
				controller = new SelfOrganizingController(TrafficLightController.NEXT_ID, junction, params.mode, params.maxCycle, params.targetCycle,
						params.updateInterval);

				for (JunctionApproach approach : junction.getApproaches()) {
					QueueMonitor queueMonitor = approach.getQueueMonitor();
					model.getNetwork().addDetector(queueMonitor.getStopLineDetector());
					model.getNetwork().addDetector(queueMonitor.getUpstreamDetector());
				}
			}

			controller.setAreLanesOperatedIndividually(!regulationParameters.mergeApproaches);
			junction.setTrafficLightController(controller);
			junction.setType(NodeType.TRAFFIC_LIGHT);
		}

		return new ImmutablePair<Integer, Integer>(trafficLightsGenerated, junctions.size());
	}

	private int addTrafficLightsPerApproach(AbstractJunction junction, TrafficLightConfigurationParameters parameters) {

		int numTrafficLights = 0;

		for (JunctionApproach approach : junction.getApproaches()) {
			List<JunctionConnector> approachConnectors = approach.getConnectors();
			addTrafficLightToConnectors(approach, approachConnectors, parameters);
			numTrafficLights++;
		}

		return numTrafficLights;
	}

	private int addTrafficLightsPerLane(AbstractJunction junction, TrafficLightConfigurationParameters parameters) {

		int numTrafficLights = 0;

		for (JunctionApproach approach : junction.getApproaches()) {
			Map<Integer, List<JunctionConnector>> approachConnectors = approach.getConnectors().stream()
					.collect(Collectors.groupingBy(JunctionConnector::getLane));

			List<Integer> keys = new ArrayList<>();
			keys.addAll(approachConnectors.keySet());
			Collections.sort(keys);

			for (int lane : keys) {
				List<JunctionConnector> connectors = approachConnectors.get(lane);
				addTrafficLightToConnectors(approach, connectors, parameters);
				numTrafficLights++;
			}
		}

		return numTrafficLights;
	}

	private void addTrafficLightToConnectors(JunctionApproach approach, List<JunctionConnector> connectors,
			TrafficLightConfigurationParameters parameters) {
		long id = TrafficLight.NEXT_ID++;
		TrafficLight tl = new TrafficLight(id, connectors.stream().map(c -> c.getId()).collect(Collectors.toList()));
		tl.setTimeIntergreen(parameters.interGreenTime);
		tl.setTimeYellow(parameters.yellowTime);
		tl.setTimeRedYellow(parameters.redYellowTime);

		for (JunctionConnector c : connectors) {
			c.setTrafficLight(tl);
		}

		approach.addTrafficLight(tl);

		ControlLogic controlLogic;

		// Add corresponding control logic
		if (parameters.controlMode == TrafficLightControllers.CYCLIC) {
			CyclicTrafficLightConfigurationParameters params = (CyclicTrafficLightConfigurationParameters) parameters;
			controlLogic = new CyclicControlLogic(tl, params.phaseLength, params.phaseDelay);
		} else if (parameters.controlMode == TrafficLightControllers.FIXED_TIMED) {
			FixedTimeTrafficLightConfigurationParameters params = (FixedTimeTrafficLightConfigurationParameters) parameters;
			controlLogic = new FixedTimeControlLogic(tl, params.startWithGreenPhase, params.phaseDelay, params.greenPhase, params.redPhase,
					params.offset);
		} else {
			SelfOrganizingTrafficLightConfigurationParameters params = (SelfOrganizingTrafficLightConfigurationParameters) parameters;
			controlLogic = new SelfOrganizingControlLogic(tl, approach.getQueueMonitor(), params.timeHorizon, params.passOverTime,
					params.startUpLossTime);
		}

		approach.addControlLogicFor(tl, controlLogic);
		model.getNetwork().addTrafficLight(tl);
	}

	private List<AbstractJunction> getRelevantJunctions(TrafficLightGenerationParameters parameters) {
		List<AbstractJunction> junctions = new ArrayList<>();

		RoadNetwork network = model.getNetwork();

		for (AbstractJunction junction : network.getJunctions()) {

			if (junction.getType() != parameters.nodeType) {
				continue;
			}

			if (junction.getSpeedLimitKmh() < parameters.lowerSpeedLimit || junction.getSpeedLimitKmh() > parameters.upperSpeedLimit) {
				continue;
			}

			if (junction.getApproaches().size() != parameters.numInflowingSegments) {
				continue;
			}

			if (!parameters.includeSingleLane && junction.isSingleLane()) {
				continue;
			}

			if (!parameters.includeMultiLane && !junction.isSingleLane()) {
				continue;
			}

			junctions.add(junction);
		}

		return junctions;
	}
}

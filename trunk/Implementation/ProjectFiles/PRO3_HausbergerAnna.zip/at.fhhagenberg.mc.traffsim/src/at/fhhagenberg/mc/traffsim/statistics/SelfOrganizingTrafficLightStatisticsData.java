package at.fhhagenberg.mc.traffsim.statistics;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;

public class SelfOrganizingTrafficLightStatisticsData extends TrafficLightStatisticsData {

	private static final long serialVersionUID = 7620408927145231445L;

	protected List<Double> priorityIndex = new ArrayList<>();
	protected List<Double> clearingTime = new ArrayList<>();
	protected List<Double> tauSwitchingPenalty = new ArrayList<>();
	protected List<Double> switchingPenalty = new ArrayList<>();
	protected List<Double> releasePeriod = new ArrayList<>();
	protected List<Double> waitingTimeExp = new ArrayList<>();
	protected List<Double> tau = new ArrayList<>();
	protected List<Double> queueLengthCritical = new ArrayList<>();
	protected List<Double> queueLengthCriticalTimeDependent = new ArrayList<>();
	protected List<Double> queueLengthExp = new ArrayList<>();
	protected List<Double> efficiency = new ArrayList<>();
	protected List<Double> efficiencyExp = new ArrayList<>();
	protected List<Double> efficiencyLastService = new ArrayList<>();
	protected List<Double> adaptivity = new ArrayList<>();
	protected List<Double> releaseState = new ArrayList<>();

	public SelfOrganizingTrafficLightStatisticsData() {
		super();
	}

	public SelfOrganizingTrafficLightStatisticsData(long controllerId, long approachId, long junctionId) {
		super(controllerId, approachId, junctionId);
	}

	public List<Double> getPriorityIndex() {
		return priorityIndex;
	}

	public List<Double> getClearingTime() {
		return clearingTime;
	}

	public List<Double> getTauSwitchingPenalty() {
		return tauSwitchingPenalty;
	}

	public List<Double> getSwitchingPenalty() {
		return switchingPenalty;
	}

	public List<Double> getReleasePeriod() {
		return releasePeriod;
	}

	public List<Double> getWaitingTimeExp() {
		return waitingTimeExp;
	}

	public List<Double> getTau() {
		return tau;
	}

	public List<Double> getQueueLengthCritical() {
		return queueLengthCritical;
	}

	public List<Double> getQueueLengthCriticalTimeDependent() {
		return queueLengthCriticalTimeDependent;
	}

	public List<Double> getQueueLengthExp() {
		return queueLengthExp;
	}

	public List<Double> getEfficiency() {
		return efficiency;
	}

	public List<Double> getEfficiencyExp() {
		return efficiencyExp;
	}

	public List<Double> getEfficiencyLastService() {
		return efficiencyLastService;
	}

	public List<Double> getAdaptivity() {
		return adaptivity;
	}

	public List<Double> getReleaseState() {
		return releaseState;
	}

	@Override
	public synchronized void addData(double time, ControlLogic controlLogic) {
		Map<String, Number> data = controlLogic.obtainStatistics();
		this.priorityIndex.add((double) data.get(IStatsConstants.CONTROL_LOGIC_PRIORITY_INDEX));
		this.clearingTime.add((double) data.get(IStatsConstants.CONTROL_LOGIC_CLEARING_TIME));
		this.tauSwitchingPenalty.add((double) data.get(IStatsConstants.CONTROL_LOGIC_TAU_SWITCHING_PENALTY));
		this.switchingPenalty.add((double) data.get(IStatsConstants.CONTROL_LOGIC_SWITCHING_PENALTY));
		this.releasePeriod.add((double) data.get(IStatsConstants.CONTROL_LOGIC_RELEASE_PERIOD));
		this.waitingTimeExp.add((double) data.get(IStatsConstants.CONTROL_LOGIC_WAITING_TIME_EXP));
		this.tau.add((double) data.get(IStatsConstants.CONTROL_LOGIC_TAU));
		this.queueLengthCritical.add((double) data.get(IStatsConstants.CONTROL_LOGIC_QUEUE_LENGTH_CRITICAL));
		this.queueLengthCriticalTimeDependent.add((double) data.get(IStatsConstants.CONTROL_LOGIC_QUEUE_LENGTH_CRITICAL_TIME_DEPENDENT));
		this.queueLengthExp.add((double) data.get(IStatsConstants.CONTROL_LOGIC_QUEUE_LENGTH_EXP));
		this.efficiency.add((double) data.get(IStatsConstants.CONTROL_LOGIC_EFFICIENCY));
		this.efficiencyExp.add((double) data.get(IStatsConstants.CONTROL_LOGIC_EFFICIENCY_EXP));
		this.efficiencyLastService.add((double) data.get(IStatsConstants.CONTROL_LOGIC_EFFICIENCY_LAST_SERVICE));
		this.adaptivity.add((double) data.get(IStatsConstants.CONTROL_LOGIC_ADAPTIVITY));
		this.releaseState.add((double) data.get(IStatsConstants.CONTROL_LOGIC_RELEASE_STATE));
		super.addData(time, controlLogic);
	}

	@Override
	public TrafficLightStatisticsData collectData(int numItemsToKeep) {
		SelfOrganizingTrafficLightStatisticsData data = new SelfOrganizingTrafficLightStatisticsData(trafficLightId, approachId, junctionId);
		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.time.addAll(time.subList(0, numItems));
				data.serviceLength.addAll(serviceLength.subList(0, numItems));
				data.serviceState.addAll(serviceState.subList(0, numItems));
				data.priorityIndex.addAll(priorityIndex.subList(0, numItems));
				data.clearingTime.addAll(clearingTime.subList(0, numItems));
				data.tauSwitchingPenalty.addAll(tauSwitchingPenalty.subList(0, numItems));
				data.switchingPenalty.addAll(switchingPenalty.subList(0, numItems));
				data.releasePeriod.addAll(releasePeriod.subList(0, numItems));
				data.waitingTimeExp.addAll(waitingTimeExp.subList(0, numItems));
				data.tau.addAll(tau.subList(0, numItems));
				data.queueLengthCritical.addAll(queueLengthCritical.subList(0, numItems));
				data.queueLengthCriticalTimeDependent.addAll(queueLengthCriticalTimeDependent.subList(0, numItems));
				data.queueLengthExp.addAll(queueLengthExp.subList(0, numItems));
				data.efficiency.addAll(efficiency.subList(0, numItems));
				data.efficiencyExp.addAll(efficiencyExp.subList(0, numItems));
				data.efficiencyLastService.addAll(efficiencyLastService.subList(0, numItems));
				data.adaptivity.addAll(adaptivity.subList(0, numItems));
				data.releaseState.addAll(releaseState.subList(0, numItems));

				// remove the collected sublist from statistics data
				time = new ArrayList<>(time.subList(numItems, lastIndex));
				serviceLength = new ArrayList<>(serviceLength.subList(numItems, lastIndex));
				serviceState = new ArrayList<>(serviceState.subList(numItems, lastIndex));
				priorityIndex = new ArrayList<>(priorityIndex.subList(numItems, lastIndex));
				clearingTime = new ArrayList<>(clearingTime.subList(numItems, lastIndex));
				tauSwitchingPenalty = new ArrayList<>(tauSwitchingPenalty.subList(numItems, lastIndex));
				switchingPenalty = new ArrayList<>(switchingPenalty.subList(numItems, lastIndex));
				releasePeriod = new ArrayList<>(releasePeriod.subList(numItems, lastIndex));
				waitingTimeExp = new ArrayList<>(waitingTimeExp.subList(numItems, lastIndex));
				tau = new ArrayList<>(tau.subList(numItems, lastIndex));
				queueLengthCritical = new ArrayList<>(queueLengthCritical.subList(numItems, lastIndex));
				queueLengthCriticalTimeDependent = new ArrayList<>(queueLengthCriticalTimeDependent.subList(numItems, lastIndex));
				queueLengthExp = new ArrayList<>(queueLengthExp.subList(numItems, lastIndex));
				efficiency = new ArrayList<>(efficiency.subList(numItems, lastIndex));
				efficiencyExp = new ArrayList<>(efficiencyExp.subList(numItems, lastIndex));
				efficiencyLastService = new ArrayList<>(efficiencyLastService.subList(numItems, lastIndex));
				adaptivity = new ArrayList<>(adaptivity.subList(numItems, lastIndex));
				releaseState = new ArrayList<>(releaseState.subList(numItems, lastIndex));

				data.recordedItems = recordedItems;
			}
		}

		return data;
	}
}

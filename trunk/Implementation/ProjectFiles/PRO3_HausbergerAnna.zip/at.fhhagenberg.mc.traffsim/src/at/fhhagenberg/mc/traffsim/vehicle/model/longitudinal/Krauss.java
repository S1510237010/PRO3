package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.KraussData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;

/**
 *
 * @author Manuel Lindorfer
 *
 */
public class Krauss extends LongitudinalModel implements IUpdateTimeDependableLongitudinalModel {

	private KraussData data;

	private double dt;

	public Krauss(){
		
	}
	
	public Krauss(double simulationTimestep, KraussData data) {
		super(data.getIdentifier());
		fullname = data.getFullname();
		this.data = data;
		this.dt = simulationTimestep;
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {

		final double localT = alphaT * dt;
		final double localV0 = Math.min(alphaV0 * data.getvTarget(), speedLimit);

		/**
		 * Safe speed
		 */
		final double vp = v - dv;
		final double b = -data.getSafeDec();
		final double vSafe = -b * localT + Math.sqrt(b * b * localT * localT + vp * vp + 2 * b * Math.max(s - data.getsMin(), 0.));

		/**
		 * Upper limit of new speed; corresponds with vNew of the Gipps model
		 */
		final double vUpper = Math.min(vSafe, Math.min(v + data.getComfortableAcc() * localT, localV0));

		/**
		 * Lower limit of new speed
		 */
		final double vLower = (1 - data.getEpsilon()) * vUpper + data.getEpsilon() * Math.max(0, v - b * localT);
		final double r = MathUtil.nextDouble();
		final double vNew = vLower + r * (vUpper - vLower);
		final double aWanted = (vNew - v) / localT;

		return aWanted;
	}

	@Override
	public LongitudinalModel createCopyFor(double speed) {
		KraussData copy = new Kryo().copy(data);
		data.setvTarget(speed);
		return new Krauss(dt, copy);
	}

	@Override
	public LongitudinalModelData getModelData() {
		return data;
	}

	@Override
	public boolean isSafeAcceleration(double acceleration) {
		return acceleration < data.getMaxAcc() && acceleration > data.getMaxDec();
	}

	@Override
	public void setSimulationTimestep(double simulationTimestep) {
		dt = simulationTimestep;
	}
}

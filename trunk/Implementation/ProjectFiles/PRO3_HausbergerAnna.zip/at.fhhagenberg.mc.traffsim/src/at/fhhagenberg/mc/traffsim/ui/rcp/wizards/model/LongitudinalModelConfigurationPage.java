package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.ACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.GippsDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IIDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.KraussDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.LongitudinalModelInputDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.OVMDataBean;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.LongitudinalModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class LongitudinalModelConfigurationPage extends ModelConfigurationPage {

	private Spinner spinnerTmin;
	private Spinner spinnerSMin;
	private Spinner spinnerDelta;
	private Spinner spinnerComfortableAcc;
	private Spinner spinnerMaxAcc;
	private Spinner spinnerSafeDec;
	private Spinner spinnerMaxDec;
	private Spinner spinnerVTarget;

	private Spinner spinnerCoolness;
	private Spinner spinnerEpsilon;
	private Spinner spinnerBeta;
	private Spinner spinnerGamma;
	private Spinner spinnerTau;
	private Spinner spinnerTransitionWidth;

	private Combo comboOVMFunction;

	private LongitudinalModels currentModel;

	protected LongitudinalModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		Label lblBasicParameters = new Label(grpModelParameters, SWT.NONE);
		lblBasicParameters.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblBasicParameters.setText("Basic parameters");
		lblBasicParameters.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 8, 1));

		Label lblTMin = new Label(grpModelParameters, SWT.NONE);
		lblTMin.setText("Time headway [s]");

		spinnerTmin = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerTmin.setPageIncrement(5);
		spinnerTmin.setIncrement(1);
		spinnerTmin.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerTmin.setMaximum(60);
		spinnerTmin.setMinimum(5);
		spinnerTmin.setSelection(18);
		spinnerTmin.setDigits(1);

		Label lblSMin = new Label(grpModelParameters, SWT.NONE);
		lblSMin.setText("Space headway [m]");

		spinnerSMin = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerSMin.setPageIncrement(5);
		spinnerSMin.setIncrement(1);
		spinnerSMin.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerSMin.setMaximum(100);
		spinnerSMin.setMinimum(5);
		spinnerSMin.setSelection(20);
		spinnerSMin.setDigits(1);

		Label lblDelta = new Label(grpModelParameters, SWT.NONE);
		lblDelta.setText("Delta");

		spinnerDelta = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerDelta.setPageIncrement(5);
		spinnerDelta.setIncrement(1);
		spinnerDelta.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerDelta.setMaximum(80);
		spinnerDelta.setMinimum(0);
		spinnerDelta.setSelection(40);
		spinnerDelta.setDigits(1);

		Label lblComfortableAcc = new Label(grpModelParameters, SWT.NONE);
		lblComfortableAcc.setText("Comfortable acceleration [m/s�]");

		spinnerComfortableAcc = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerComfortableAcc.setPageIncrement(5);
		spinnerComfortableAcc.setIncrement(1);
		spinnerComfortableAcc.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerComfortableAcc.setMaximum(60);
		spinnerComfortableAcc.setMinimum(5);
		spinnerComfortableAcc.setSelection(15);
		spinnerComfortableAcc.setDigits(1);

		Label lblMaxAcc = new Label(grpModelParameters, SWT.NONE);
		lblMaxAcc.setText("Max. acceleration [m/s�]");

		spinnerMaxAcc = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMaxAcc.setPageIncrement(5);
		spinnerMaxAcc.setIncrement(1);
		spinnerMaxAcc.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMaxAcc.setMaximum(100);
		spinnerMaxAcc.setMinimum(5);
		spinnerMaxAcc.setSelection(50);
		spinnerMaxAcc.setDigits(1);

		Label lblSafeDec = new Label(grpModelParameters, SWT.NONE);
		lblSafeDec.setText("Safe deceleration [m/s�]");

		spinnerSafeDec = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerSafeDec.setPageIncrement(5);
		spinnerSafeDec.setIncrement(1);
		spinnerSafeDec.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerSafeDec.setMaximum(0);
		spinnerSafeDec.setMinimum(-60);
		spinnerSafeDec.setSelection(-20);
		spinnerSafeDec.setDigits(1);

		Label lblMaxDec = new Label(grpModelParameters, SWT.NONE);
		lblMaxDec.setText("Max. deceleration [m/s�]");

		spinnerMaxDec = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMaxDec.setPageIncrement(5);
		spinnerMaxDec.setIncrement(1);
		spinnerMaxDec.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMaxDec.setMaximum(0);
		spinnerMaxDec.setMinimum(-100);
		spinnerMaxDec.setSelection(-70);
		spinnerMaxDec.setDigits(1);

		Label lblVTarget = new Label(grpModelParameters, SWT.NONE);
		lblVTarget.setText("Target speed [m/s]");

		spinnerVTarget = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerVTarget.setPageIncrement(5);
		spinnerVTarget.setIncrement(1);
		spinnerVTarget.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerVTarget.setMaximum(500);
		spinnerVTarget.setMinimum(10);
		spinnerVTarget.setSelection(140);
		spinnerVTarget.setDigits(1);

		new Label(grpModelParameters, SWT.NONE);
		new Label(grpModelParameters, SWT.NONE);

		Label lblSpecificParameters = new Label(grpModelParameters, SWT.NONE);
		lblSpecificParameters.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblSpecificParameters.setText("Specific parameters");
		lblSpecificParameters.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 8, 1));

		Label lblCoolness = new Label(grpModelParameters, SWT.NONE);
		lblCoolness.setText("Coolness [%]");

		spinnerCoolness = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerCoolness.setPageIncrement(5);
		spinnerCoolness.setIncrement(1);
		spinnerCoolness.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerCoolness.setMaximum(100);
		spinnerCoolness.setMinimum(0);
		spinnerCoolness.setSelection(99);
		spinnerCoolness.setDigits(2);

		Label lblBeta = new Label(grpModelParameters, SWT.NONE);
		lblBeta.setText("Beta");

		spinnerBeta = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerBeta.setPageIncrement(5);
		spinnerBeta.setIncrement(1);
		spinnerBeta.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerBeta.setMaximum(100);
		spinnerBeta.setMinimum(0);
		spinnerBeta.setSelection(15);
		spinnerBeta.setDigits(1);

		Label lblGamma = new Label(grpModelParameters, SWT.NONE);
		lblGamma.setText("Gamma (0: OVM, >0: FVDM)");

		spinnerGamma = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerGamma.setPageIncrement(5);
		spinnerGamma.setIncrement(1);
		spinnerGamma.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerGamma.setMaximum(100);
		spinnerGamma.setMinimum(0);
		spinnerGamma.setSelection(0);
		spinnerGamma.setDigits(1);

		Label lblEpsilon = new Label(grpModelParameters, SWT.NONE);
		lblEpsilon.setText("Epsilon");

		spinnerEpsilon = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerEpsilon.setPageIncrement(5);
		spinnerEpsilon.setIncrement(1);
		spinnerEpsilon.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerEpsilon.setMaximum(100);
		spinnerEpsilon.setMinimum(0);
		spinnerEpsilon.setSelection(50);
		spinnerEpsilon.setDigits(2);

		Label lblTau = new Label(grpModelParameters, SWT.NONE);
		lblTau.setText("Tau");

		spinnerTau = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerTau.setPageIncrement(5);
		spinnerTau.setIncrement(1);
		spinnerTau.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerTau.setMaximum(100);
		spinnerTau.setMinimum(0);
		spinnerTau.setSelection(65);
		spinnerTau.setDigits(2);

		Label lblTransitionWidth = new Label(grpModelParameters, SWT.NONE);
		lblTransitionWidth.setText("Transition width [m]");

		spinnerTransitionWidth = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerTransitionWidth.setPageIncrement(5);
		spinnerTransitionWidth.setIncrement(1);
		spinnerTransitionWidth.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerTransitionWidth.setMaximum(250);
		spinnerTransitionWidth.setMinimum(40);
		spinnerTransitionWidth.setSelection(80);
		spinnerTransitionWidth.setDigits(1);

		Label lblOVMFunction = new Label(grpModelParameters, SWT.NONE);
		lblOVMFunction.setText("OVM function");

		comboOVMFunction = new Combo(grpModelParameters, SWT.READ_ONLY);
		comboOVMFunction.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		comboOVMFunction.add("BANDO");
		comboOVMFunction.add("TRIANGULAR");
		comboOVMFunction.add("THREEPHASE");
		comboOVMFunction.select(0);
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			currentModel = LongitudinalModels.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setupUIFor(currentModel);
		}
	}

	private void setupUIFor(LongitudinalModels model) {

		controlMapping.clear();
		modelProperties.clear();

		switch (model) {
		case ACC:
			spinnerTmin.setEnabled(true);
			spinnerSMin.setEnabled(true);
			spinnerDelta.setEnabled(true);
			spinnerComfortableAcc.setEnabled(true);
			spinnerMaxAcc.setEnabled(true);
			spinnerSafeDec.setEnabled(true);
			spinnerMaxDec.setEnabled(true);
			spinnerVTarget.setEnabled(true);

			spinnerCoolness.setEnabled(true);
			spinnerEpsilon.setEnabled(false);
			spinnerBeta.setEnabled(false);
			spinnerGamma.setEnabled(false);
			spinnerTau.setEnabled(false);
			spinnerTransitionWidth.setEnabled(false);

			comboOVMFunction.setEnabled(false);

			ModelProperty timeHeadway = new ModelProperty("Time headway [s]", "settMin", Double.TYPE, 0.5, 6);
			ModelProperty spaceHeadway = new ModelProperty("Space headway [m]", "setsMin", Double.TYPE, 0.5, 10);
			ModelProperty delta = new ModelProperty("Delta", "setDelta", Double.TYPE, 0, 8);
			ModelProperty comfortableAcc = new ModelProperty("Comfortable acceleration [m/s�]", "setComfortableAcc", Double.TYPE, 0.5, 6);
			ModelProperty maxAcc = new ModelProperty("Max. acceleration [m/s�]", "setMaxAcc", Double.TYPE, 0.5, 10);
			ModelProperty safeDec = new ModelProperty("Safe deceleration [m/s�]", "setSafeDec", Double.TYPE, -6, 0);
			ModelProperty maxDec = new ModelProperty("Max. deceleration [m/s�]", "setMaxDec", Double.TYPE, -10, 0);
			ModelProperty targetSpeed = new ModelProperty("Target speed [m/s]", "setvTarget", Double.TYPE, 1, 50);
			ModelProperty coolness = new ModelProperty("Coolness [%]", "setCoolness", Double.TYPE, 0, 1);

			modelProperties.add(timeHeadway);
			modelProperties.add(spaceHeadway);
			modelProperties.add(delta);
			modelProperties.add(comfortableAcc);
			modelProperties.add(maxAcc);
			modelProperties.add(safeDec);
			modelProperties.add(maxDec);
			modelProperties.add(targetSpeed);
			modelProperties.add(coolness);

			controlMapping.put(timeHeadway, spinnerTmin);
			controlMapping.put(spaceHeadway, spinnerSMin);
			controlMapping.put(delta, spinnerDelta);
			controlMapping.put(comfortableAcc, spinnerComfortableAcc);
			controlMapping.put(maxAcc, spinnerMaxAcc);
			controlMapping.put(safeDec, spinnerSafeDec);
			controlMapping.put(maxDec, spinnerMaxDec);
			controlMapping.put(targetSpeed, spinnerVTarget);
			controlMapping.put(coolness, spinnerCoolness);

			break;
		case GIPPS:
			spinnerTmin.setEnabled(false);
			spinnerSMin.setEnabled(true);
			spinnerDelta.setEnabled(false);
			spinnerComfortableAcc.setEnabled(true);
			spinnerMaxAcc.setEnabled(false);
			spinnerSafeDec.setEnabled(true);
			spinnerMaxDec.setEnabled(false);
			spinnerVTarget.setEnabled(true);

			spinnerCoolness.setEnabled(false);
			spinnerEpsilon.setEnabled(false);
			spinnerBeta.setEnabled(false);
			spinnerGamma.setEnabled(false);
			spinnerTau.setEnabled(false);
			spinnerTransitionWidth.setEnabled(false);

			comboOVMFunction.setEnabled(false);

			ModelProperty spaceHeadway1 = new ModelProperty("Space headway [m]", "setsMin", Double.TYPE, 0.5, 10);
			ModelProperty comfortableAcc1 = new ModelProperty("Comfortable acceleration [m/s�]", "setComfortableAcc", Double.TYPE, 0.5, 6);
			ModelProperty safeDec1 = new ModelProperty("Safe deceleration [m/s�]", "setSafeDec", Double.TYPE, -6, 0);
			ModelProperty targetSpeed1 = new ModelProperty("Target speed [m/s]", "setvTarget", Double.TYPE, 1, 50);

			modelProperties.add(spaceHeadway1);
			modelProperties.add(comfortableAcc1);
			modelProperties.add(safeDec1);
			modelProperties.add(targetSpeed1);

			controlMapping.put(spaceHeadway1, spinnerSMin);
			controlMapping.put(comfortableAcc1, spinnerComfortableAcc);
			controlMapping.put(safeDec1, spinnerSafeDec);
			controlMapping.put(targetSpeed1, spinnerVTarget);

			break;
		case IDM:
		case IIDM:
			spinnerTmin.setEnabled(true);
			spinnerSMin.setEnabled(true);
			spinnerDelta.setEnabled(true);
			spinnerComfortableAcc.setEnabled(true);
			spinnerMaxAcc.setEnabled(true);
			spinnerSafeDec.setEnabled(true);
			spinnerMaxDec.setEnabled(true);
			spinnerVTarget.setEnabled(true);

			spinnerCoolness.setEnabled(false);
			spinnerEpsilon.setEnabled(false);
			spinnerBeta.setEnabled(false);
			spinnerGamma.setEnabled(false);
			spinnerTau.setEnabled(false);
			spinnerTransitionWidth.setEnabled(false);

			comboOVMFunction.setEnabled(false);

			ModelProperty timeHeadway2 = new ModelProperty("Time headway [s]", "settMin", Double.TYPE, 0.5, 6);
			ModelProperty spaceHeadway2 = new ModelProperty("Space headway [m]", "setsMin", Double.TYPE, 0.5, 10);
			ModelProperty delta2 = new ModelProperty("Delta", "setDelta", Double.TYPE, 0, 8);
			ModelProperty comfortableAcc2 = new ModelProperty("Comfortable acceleration [m/s�]", "setComfortableAcc", Double.TYPE, 0.5, 6);
			ModelProperty maxAcc2 = new ModelProperty("Max. acceleration [m/s�]", "setMaxAcc", Double.TYPE, 0.5, 10);
			ModelProperty safeDec2 = new ModelProperty("Safe deceleration [m/s�]", "setSafeDec", Double.TYPE, -6, 0);
			ModelProperty maxDec2 = new ModelProperty("Max. deceleration [m/s�]", "setMaxDec", Double.TYPE, -10, 0);
			ModelProperty targetSpeed2 = new ModelProperty("Target speed [m/s]", "setvTarget", Double.TYPE, 1, 50);

			modelProperties.add(timeHeadway2);
			modelProperties.add(spaceHeadway2);
			modelProperties.add(delta2);
			modelProperties.add(comfortableAcc2);
			modelProperties.add(maxAcc2);
			modelProperties.add(safeDec2);
			modelProperties.add(maxDec2);
			modelProperties.add(targetSpeed2);

			controlMapping.put(timeHeadway2, spinnerTmin);
			controlMapping.put(spaceHeadway2, spinnerSMin);
			controlMapping.put(delta2, spinnerDelta);
			controlMapping.put(comfortableAcc2, spinnerComfortableAcc);
			controlMapping.put(maxAcc2, spinnerMaxAcc);
			controlMapping.put(safeDec2, spinnerSafeDec);
			controlMapping.put(maxDec2, spinnerMaxDec);
			controlMapping.put(targetSpeed2, spinnerVTarget);
			break;
		case KRAUSS:
			spinnerTmin.setEnabled(false);
			spinnerSMin.setEnabled(true);
			spinnerDelta.setEnabled(false);
			spinnerComfortableAcc.setEnabled(true);
			spinnerMaxAcc.setEnabled(false);
			spinnerSafeDec.setEnabled(true);
			spinnerMaxDec.setEnabled(false);
			spinnerVTarget.setEnabled(true);

			spinnerCoolness.setEnabled(false);
			spinnerEpsilon.setEnabled(true);
			spinnerBeta.setEnabled(false);
			spinnerGamma.setEnabled(false);
			spinnerTau.setEnabled(false);
			spinnerTransitionWidth.setEnabled(false);

			comboOVMFunction.setEnabled(false);

			ModelProperty spaceHeadway3 = new ModelProperty("Space headway [m]", "setsMin", Double.TYPE, 0.5, 10);
			ModelProperty comfortableAcc3 = new ModelProperty("Comfortable acceleration [m/s�]", "setComfortableAcc", Double.TYPE, 0.5, 6);
			ModelProperty safeDec3 = new ModelProperty("Safe deceleration [m/s�]", "setSafeDec", Double.TYPE, -6, 0);
			ModelProperty targetSpeed3 = new ModelProperty("Target speed [m/s]", "setvTarget", Double.TYPE, 1, 50);
			ModelProperty epsilon = new ModelProperty("Epsilon", "setEpsilon", Double.TYPE, 0, 1);

			modelProperties.add(spaceHeadway3);
			modelProperties.add(comfortableAcc3);
			modelProperties.add(safeDec3);
			modelProperties.add(targetSpeed3);
			modelProperties.add(epsilon);

			controlMapping.put(spaceHeadway3, spinnerSMin);
			controlMapping.put(comfortableAcc3, spinnerComfortableAcc);
			controlMapping.put(safeDec3, spinnerSafeDec);
			controlMapping.put(targetSpeed3, spinnerVTarget);
			controlMapping.put(epsilon, spinnerEpsilon);

			break;
		case OVM:
			spinnerTmin.setEnabled(false);
			spinnerSMin.setEnabled(true);
			spinnerDelta.setEnabled(false);
			spinnerComfortableAcc.setEnabled(false);
			spinnerMaxAcc.setEnabled(false);
			spinnerSafeDec.setEnabled(false);
			spinnerMaxDec.setEnabled(false);
			spinnerVTarget.setEnabled(true);

			spinnerCoolness.setEnabled(false);
			spinnerEpsilon.setEnabled(false);
			spinnerBeta.setEnabled(true);
			spinnerGamma.setEnabled(true);
			spinnerTau.setEnabled(true);
			spinnerTransitionWidth.setEnabled(true);

			comboOVMFunction.setEnabled(true);

			ModelProperty spaceHeadway4 = new ModelProperty("Space headway [m]", "setsMin", Double.TYPE, 0.5, 10);
			ModelProperty targetSpeed4 = new ModelProperty("Target speed [m/s]", "setvTarget", Double.TYPE, 1, 50);
			ModelProperty beta = new ModelProperty("Beta", "setBeta", Double.TYPE, 0, 10);
			ModelProperty gamma = new ModelProperty("Gamma (0: OVM, >0: FVDM)", "setGamma", Double.TYPE, 0, 10);
			ModelProperty tau = new ModelProperty("Tau", "setTau", Double.TYPE, 0, 1);
			ModelProperty transitionWidth = new ModelProperty("Transition width [m]", "setTransitionWidth", Double.TYPE, 4, 25);

			modelProperties.add(spaceHeadway4);
			modelProperties.add(targetSpeed4);
			modelProperties.add(beta);
			modelProperties.add(gamma);
			modelProperties.add(tau);
			modelProperties.add(transitionWidth);

			controlMapping.put(spaceHeadway4, spinnerSMin);
			controlMapping.put(targetSpeed4, spinnerVTarget);
			controlMapping.put(beta, spinnerBeta);
			controlMapping.put(gamma, spinnerGamma);
			controlMapping.put(tau, spinnerTau);
			controlMapping.put(transitionWidth, spinnerTransitionWidth);

			break;
		default:
			spinnerTmin.setEnabled(false);
			spinnerSMin.setEnabled(false);
			spinnerDelta.setEnabled(false);
			spinnerComfortableAcc.setEnabled(false);
			spinnerMaxAcc.setEnabled(false);
			spinnerSafeDec.setEnabled(false);
			spinnerMaxDec.setEnabled(false);
			spinnerVTarget.setEnabled(false);

			spinnerCoolness.setEnabled(false);
			spinnerEpsilon.setEnabled(false);
			spinnerBeta.setEnabled(false);
			spinnerGamma.setEnabled(false);
			spinnerTau.setEnabled(false);
			spinnerTransitionWidth.setEnabled(false);

			comboOVMFunction.setEnabled(false);

			break;
		}

		setDescription(String.format("Configure '%s' model parameters", model.toString()));
	}

	protected void addModelToList() {
		if (currentModel == LongitudinalModels.IDM) {
			IDMDataBean longitudinalModel = new IDMDataBean();
			longitudinalModel.setModelIdentifier(txtIdentifier.getText());
			longitudinalModel.setFullName(txtFullName.getText());
			longitudinalModel.settMin(spinnerTmin.getSelection() / Math.pow(10, spinnerTmin.getDigits()));
			longitudinalModel.setsMin(spinnerSMin.getSelection() / Math.pow(10, spinnerSMin.getDigits()));
			longitudinalModel.setDelta(spinnerDelta.getSelection() / Math.pow(10, spinnerDelta.getDigits()));
			longitudinalModel.setComfortableAcc(spinnerComfortableAcc.getSelection() / Math.pow(10, spinnerComfortableAcc.getDigits()));
			longitudinalModel.setSafeDec(spinnerSafeDec.getSelection() / Math.pow(10, spinnerSafeDec.getDigits()));
			longitudinalModel.setMaxDec(spinnerMaxDec.getSelection() / Math.pow(10, spinnerMaxDec.getDigits()));
			longitudinalModel.setvTarget(spinnerVTarget.getSelection() / Math.pow(10, spinnerVTarget.getDigits()));
			longitudinalModel.setMaxAcc(spinnerMaxAcc.getSelection() / Math.pow(10, spinnerMaxAcc.getDigits()));
			modelSet.add(longitudinalModel);
		} else if (currentModel == LongitudinalModels.IIDM) {
			IIDMDataBean longitudinalModel = new IIDMDataBean();
			longitudinalModel.setModelIdentifier(txtIdentifier.getText());
			longitudinalModel.setFullName(txtFullName.getText());
			longitudinalModel.settMin(spinnerTmin.getSelection() / Math.pow(10, spinnerTmin.getDigits()));
			longitudinalModel.setsMin(spinnerSMin.getSelection() / Math.pow(10, spinnerSMin.getDigits()));
			longitudinalModel.setDelta(spinnerDelta.getSelection() / Math.pow(10, spinnerDelta.getDigits()));
			longitudinalModel.setComfortableAcc(spinnerComfortableAcc.getSelection() / Math.pow(10, spinnerComfortableAcc.getDigits()));
			longitudinalModel.setSafeDec(spinnerSafeDec.getSelection() / Math.pow(10, spinnerSafeDec.getDigits()));
			longitudinalModel.setMaxDec(spinnerMaxDec.getSelection() / Math.pow(10, spinnerMaxDec.getDigits()));
			longitudinalModel.setvTarget(spinnerVTarget.getSelection() / Math.pow(10, spinnerVTarget.getDigits()));
			longitudinalModel.setMaxAcc(spinnerMaxAcc.getSelection() / Math.pow(10, spinnerMaxAcc.getDigits()));
			modelSet.add(longitudinalModel);
		} else if (currentModel == LongitudinalModels.ACC) {
			ACCDataBean longitudinalModel = new ACCDataBean();
			longitudinalModel.setModelIdentifier(txtIdentifier.getText());
			longitudinalModel.setFullName(txtFullName.getText());
			longitudinalModel.settMin(spinnerTmin.getSelection() / Math.pow(10, spinnerTmin.getDigits()));
			longitudinalModel.setsMin(spinnerSMin.getSelection() / Math.pow(10, spinnerSMin.getDigits()));
			longitudinalModel.setDelta(spinnerDelta.getSelection() / Math.pow(10, spinnerDelta.getDigits()));
			longitudinalModel.setComfortableAcc(spinnerComfortableAcc.getSelection() / Math.pow(10, spinnerComfortableAcc.getDigits()));
			longitudinalModel.setSafeDec(spinnerSafeDec.getSelection() / Math.pow(10, spinnerSafeDec.getDigits()));
			longitudinalModel.setMaxDec(spinnerMaxDec.getSelection() / Math.pow(10, spinnerMaxDec.getDigits()));
			longitudinalModel.setvTarget(spinnerVTarget.getSelection() / Math.pow(10, spinnerVTarget.getDigits()));
			longitudinalModel.setMaxAcc(spinnerMaxAcc.getSelection() / Math.pow(10, spinnerMaxAcc.getDigits()));
			longitudinalModel.setCoolness(spinnerCoolness.getSelection() / Math.pow(10, spinnerCoolness.getDigits()));
			modelSet.add(longitudinalModel);
		} else if (currentModel == LongitudinalModels.GIPPS) {
			GippsDataBean longitudinalModel = new GippsDataBean();
			longitudinalModel.setModelIdentifier(txtIdentifier.getText());
			longitudinalModel.setFullName(txtFullName.getText());
			longitudinalModel.setsMin(spinnerSMin.getSelection() / Math.pow(10, spinnerSMin.getDigits()));
			longitudinalModel.setComfortableAcc(spinnerComfortableAcc.getSelection() / Math.pow(10, spinnerComfortableAcc.getDigits()));
			longitudinalModel.setSafeDec(spinnerSafeDec.getSelection() / Math.pow(10, spinnerSafeDec.getDigits()));
			longitudinalModel.setvTarget(spinnerVTarget.getSelection() / Math.pow(10, spinnerVTarget.getDigits()));
			modelSet.add(longitudinalModel);
		} else if (currentModel == LongitudinalModels.KRAUSS) {
			KraussDataBean longitudinalModel = new KraussDataBean();
			longitudinalModel.setModelIdentifier(txtIdentifier.getText());
			longitudinalModel.setFullName(txtFullName.getText());
			longitudinalModel.setsMin(spinnerSMin.getSelection() / Math.pow(10, spinnerSMin.getDigits()));
			longitudinalModel.setComfortableAcc(spinnerComfortableAcc.getSelection() / Math.pow(10, spinnerComfortableAcc.getDigits()));
			longitudinalModel.setSafeDec(spinnerSafeDec.getSelection() / Math.pow(10, spinnerSafeDec.getDigits()));
			longitudinalModel.setvTarget(spinnerVTarget.getSelection() / Math.pow(10, spinnerVTarget.getDigits()));
			longitudinalModel.setEpsilon(spinnerEpsilon.getSelection() / Math.pow(10, spinnerEpsilon.getDigits()));
			modelSet.add(longitudinalModel);
		} else if (currentModel == LongitudinalModels.OVM) {
			OVMDataBean longitudinalModel = new OVMDataBean();
			longitudinalModel.setModelIdentifier(txtIdentifier.getText());
			longitudinalModel.setFullName(txtFullName.getText());
			longitudinalModel.setsMin(spinnerSMin.getSelection() / Math.pow(10, spinnerSMin.getDigits()));
			longitudinalModel.setvTarget(spinnerVTarget.getSelection() / Math.pow(10, spinnerVTarget.getDigits()));
			longitudinalModel.setBeta(spinnerBeta.getSelection() / Math.pow(10, spinnerBeta.getDigits()));
			longitudinalModel.setGamma(spinnerGamma.getSelection() / Math.pow(10, spinnerGamma.getDigits()));
			longitudinalModel.setTau(spinnerTau.getSelection() / Math.pow(10, spinnerTau.getDigits()));
			longitudinalModel.setTransitionWidth(spinnerTransitionWidth.getSelection() / Math.pow(10, spinnerTransitionWidth.getDigits()));
			longitudinalModel.setOVMFunction(comboOVMFunction.getText());
			modelSet.add(longitudinalModel);
		}
	}

	protected void createColumns(TableViewer tv, String modelIdentifier) {

		LongitudinalModels model = LongitudinalModels.valueOfLabel(modelIdentifier);

		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((LongitudinalModelInputDataBean) element).getModelIdentifier() + "";
			}
		});

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.ACC) {
			TableViewerColumn colTMin = createTableViewerColumn("Time headway [s]", 120);
			colTMin.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((IDMDataBean) element).gettMin() + "";
				}
			});
		}

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.GIPPS
				|| model == LongitudinalModels.ACC || model == LongitudinalModels.KRAUSS || model == LongitudinalModels.OVM) {
			TableViewerColumn colSMin = createTableViewerColumn("Space headway [m]", 120);
			colSMin.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((LongitudinalModelInputDataBean) element).getsMin() + "";
				}
			});
		}

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.ACC) {
			TableViewerColumn colDelta = createTableViewerColumn("Delta", 60);
			colDelta.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((IDMDataBean) element).getDelta() + "";
				}
			});
		}

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.GIPPS
				|| model == LongitudinalModels.ACC || model == LongitudinalModels.KRAUSS) {
			TableViewerColumn colComfortableAcc = createTableViewerColumn("Comfortable acceleration [m/s�]", 200);
			colComfortableAcc.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((LongitudinalModelInputDataBean) element).getComfortableAcc() + "";
				}
			});
		}

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.ACC) {
			TableViewerColumn colMaxAcc = createTableViewerColumn("Max. acceleration [m/s�]", 160);
			colMaxAcc.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((IDMDataBean) element).getMaxAcc() + "";
				}
			});
		}

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.GIPPS
				|| model == LongitudinalModels.ACC || model == LongitudinalModels.KRAUSS) {
			TableViewerColumn colSafeDec = createTableViewerColumn("Safe deceleration [m/s�]", 160);
			colSafeDec.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((GippsDataBean) element).getSafeDec() + "";
				}
			});
		}

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.ACC) {
			TableViewerColumn colMaxDec = createTableViewerColumn("Max. deceleration [m/s�]", 160);
			colMaxDec.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((IDMDataBean) element).getMaxDec() + "";
				}
			});
		}

		if (model == LongitudinalModels.IDM || model == LongitudinalModels.IIDM || model == LongitudinalModels.GIPPS
				|| model == LongitudinalModels.ACC || model == LongitudinalModels.KRAUSS || model == LongitudinalModels.OVM) {
			TableViewerColumn colVTarget = createTableViewerColumn("Target speed [m/s]", 120);
			colVTarget.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((LongitudinalModelInputDataBean) element).getvTarget() + "";
				}
			});
		}
		// Specific parameters
		if (model == LongitudinalModels.ACC) {
			TableViewerColumn colCoolness = createTableViewerColumn("Coolness [%]", 120);
			colCoolness.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((ACCDataBean) element).getCoolness() + "";
				}
			});
		}

		if (model == LongitudinalModels.OVM) {
			TableViewerColumn colBeta = createTableViewerColumn("Beta", 80);
			colBeta.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((OVMDataBean) element).getBeta() + "";
				}
			});
		}

		if (model == LongitudinalModels.OVM) {
			TableViewerColumn colGamma = createTableViewerColumn("Gamma", 80);
			colGamma.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((OVMDataBean) element).getGamma() + "";
				}
			});
		}

		if (model == LongitudinalModels.KRAUSS) {
			TableViewerColumn colEpsilon = createTableViewerColumn("Epsilon", 100);
			colEpsilon.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((KraussDataBean) element).getEpsilon() + "";
				}
			});
		}

		if (model == LongitudinalModels.OVM) {
			TableViewerColumn colTau = createTableViewerColumn("Tau", 60);
			colTau.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((OVMDataBean) element).getTau() + "";
				}
			});
		}

		if (model == LongitudinalModels.OVM) {
			TableViewerColumn colTransitionWidth = createTableViewerColumn("Transition width [m]", 120);
			colTransitionWidth.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((OVMDataBean) element).getTransitionWidth() + "";
				}
			});
		}

		if (model == LongitudinalModels.OVM) {
			TableViewerColumn colOVMFunction = createTableViewerColumn("OVM function", 120);
			colOVMFunction.setLabelProvider(new ColumnLabelProvider() {
				@Override
				public String getText(Object element) {
					return ((OVMDataBean) element).getOVMFunction() + "";
				}
			});
		}
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {
		try {
			Class<?> cls = null;

			if (currentModel == LongitudinalModels.IDM) {
				cls = IDMDataBean.class;
			} else if (currentModel == LongitudinalModels.IIDM) {
				cls = IIDMDataBean.class;
			} else if (currentModel == LongitudinalModels.ACC) {
				cls = ACCDataBean.class;
			} else if (currentModel == LongitudinalModels.GIPPS) {
				cls = GippsDataBean.class;
			} else if (currentModel == LongitudinalModels.KRAUSS) {
				cls = KraussDataBean.class;
			} else if (currentModel == LongitudinalModels.OVM) {
				cls = OVMDataBean.class;
			}

			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();
				cls.getMethod("setModelIdentifier", String.class).invoke(obj,
						currentModel.getShortName() + "_gen_" + generationTime + "-" + (i + 1));
				cls.getMethod("setFullName", String.class).invoke(obj, "Auto. generated memory model");

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Method setter = cls.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);

						if (property.getType() == Integer.TYPE) {
							setter.invoke(obj, (int) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(obj, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(obj, (int) (spinner.getSelection() / Math.pow(10, spinner.getDigits())
										* property.getConversionFactor()));
							} else {
								setter.invoke(obj,
										(spinner.getSelection() / Math.pow(10, spinner.getDigits()) * property.getConversionFactor()));
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(obj, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(obj, text.getText());
						}
					}
				}

				if (currentModel == LongitudinalModels.IDM) {
					modelSet.add((IDMDataBean) obj);
				} else if (currentModel == LongitudinalModels.IIDM) {
					modelSet.add((IIDMDataBean) obj);
				} else if (currentModel == LongitudinalModels.ACC) {
					modelSet.add((ACCDataBean) obj);
				} else if (currentModel == LongitudinalModels.GIPPS) {
					modelSet.add((GippsDataBean) obj);
				} else if (currentModel == LongitudinalModels.KRAUSS) {
					modelSet.add((KraussDataBean) obj);
				} else if (currentModel == LongitudinalModels.OVM) {
					cls.getMethod("setOVMFunction", String.class).invoke(obj, comboOVMFunction.getText());
					modelSet.add((OVMDataBean) obj);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}

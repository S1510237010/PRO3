package at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSign.Type;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight.TrafficLightState;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.TrafficUtil;
import at.fhhagenberg.mc.traffsim.vehicle.BlinkerState;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleRouteListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleInJunction;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleListenerAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * This class provides an implementation of a one-lane unregulated junction, considering the
 *
 * @author Christian Backfrieder
 *
 */
public class DefaultJunction extends AbstractJunction {
	/** seconds */
	private static final double MAX_TIME_DISTANCE_FOR_UNREGULATED_ENTRY_GRANT = 5;
	private static final double MAX_TIME_DISTANCE_FOR_REGULATED_ENTRY_GRANT = 10;
	private static final double MAX_DISTANCE_FOR_RIGHTLAW_GRANT = 90;

	/** cache object for caching {@link VehiclesLane}s intersections (of course never change within one simulation) */
	private SpatialCache spatialCache;

	private IVehicleRouteListener vehicleListener = new VehicleListenerAdapter() {

		@Override
		public void vehicleLeftSimulation(Vehicle v) {
			v.removeVehicleListener(vehicleListener);
			vehiclesApproaching.remove(v.getUniqueId());
			driveThroughNotPossible.remove(v);
			entryGrants.remove(v.getUniqueId());
		}

		@Override
		public void vehicleChangedLaneSegment(Vehicle v, VehiclesLane oldLane, VehiclesLane newLane) {
			if (newLane instanceof JunctionConnector && oldLane instanceof LaneSegment && getVehicles().contains(v)) {
				// vehicle entered this junction
				addDebugLogLine(getLogMessage(PREFIX_ENTERED, v,
						String.format("entered from RS %d / rt. id %d", oldLane.getRoadSegment().getId(), oldLane.getRoadSegment().getRoutingId())),
						true);
			} else if (newLane instanceof LaneSegment && oldLane instanceof JunctionConnector && getConnectors().contains(oldLane)) {
				vehiclesApproaching.remove(v.getUniqueId());
				driveThroughNotPossible.remove(v);
				entryGrants.remove(v.getUniqueId());
				v.removeVehicleListener(vehicleListener);
				addDebugLogLine(getLogMessage(PREFIX_LEFT, v,
						String.format("left to RS %d / rt. id %d", newLane.getRoadSegment().getId(), newLane.getRoadSegment().getRoutingId())), true);
				v.setBlinkerState(BlinkerState.OFF);
				onVehicleLeftJunction(v.getUniqueId());
			} else if (newLane instanceof LaneSegment && oldLane instanceof LaneSegment
					&& oldLane.getRoadSegment().getId() == newLane.getRoadSegment().getId()) {
				// vehicle changed lane before junction -> also remove from lists, relevant for multilane junctions
				if (entryGrants.contains(v.getUniqueId())) {
					addDebugLogLine(getLogMessage(PREFIX_GRANT_REMOVED, v,
							String.format("changed lane from LS %d index %d (RS %d) to LS %d index %d (RS %d)", oldLane.getId(),
									oldLane.getLaneIndex(), oldLane.getRoadSegment().getId(), newLane.getId(), newLane.getLaneIndex(),
									newLane.getRoadSegment().getId())),
							true);
				}
				vehiclesApproaching.remove(v.getUniqueId());
				driveThroughNotPossible.remove(v);
				entryGrants.remove(v.getUniqueId());
			}
		}

		@Override
		public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute) {
			if (currentSegment.getJunction() != null && !currentSegment.getJunction().equals(DefaultJunction.this)
					&& !RoutingUtil.routesPassSameConnector(oldRoute, newRoute, DefaultJunction.this)) {
				vehiclesApproaching.remove(v.getUniqueId());
				driveThroughNotPossible.remove(v);
				addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, v, "removed grant because route updated"), true);
				entryGrants.remove(v.getUniqueId());
				v.removeVehicleListener(vehicleListener);
			}
		};

	};

	public DefaultJunction(long id, SpatialCache spatialCache) {
		super(id);
		this.spatialCache = spatialCache;
	}

	/**
	 * calculate the front vehicle of the given Vehicle in the junction
	 *
	 * @param connWithVehicle
	 * @param me
	 */
	@Override
	public VehicleWithDistance frontVehicle(Vehicle me, JunctionConnector connWithVehicle) {
		for (JunctionConnector conn : connectors) {
			if (!conn.equals(connWithVehicle) && !conn.getVehicles().isEmpty() && spatialCache.intersects(conn, connWithVehicle)
					&& !conn.getSourceLaneSegment().equals(connWithVehicle.getSourceLaneSegment())) {
				if (conn.getVehicles().stream().filter(v -> v.getUniqueId() != me.getUniqueId())
						.allMatch(v -> NumberUtil.doubleEquals(v.getCurrentSpeed(), 0))) {
					return connWithVehicle.getSinkLaneSegment().frontVehicle(me, 0, me.getLaneSegment().getRoadLength() - me.getFrontPosition());
				}
				double distance = SpatialUtil.nearestIntersection(conn.getBounds(), connWithVehicle.getBounds(), me.getAbsolutePosition())
						.minus(me.getAbsolutePosition()).magnitude();
				// ensure stop one vehicle length before critical intersection point -> see documentation image 000 junction front vehicle
				distance = Math.max(0, distance - me.getLength());
				return new VehicleWithDistance(VehicleFactory.createObstacle(distance), distance);
			}
		}
		for (RoadSegment rs : segmentsOut) {
			for (LaneSegment ls : rs.getLaneSegments()) {
				if (!ls.getVehicles().isEmpty() && !connWithVehicle.getSinkLaneSegment().equals(ls) && ls.frontVehicle().getRearPosition() < 0
						&& SpatialUtil.intersects(connWithVehicle.getBounds(), ls.frontVehicle().getBoundsPolygon())) {
					double distance = SpatialUtil.getShortestDistance(ls.frontVehicle().getBoundsPolygon(), me.getBoundsPolygon());
					return new VehicleWithDistance(VehicleFactory.createObstacle(distance), distance);
				}
			}
		}
		Stream<Vehicle> potentialIntersectingVehicles = connectors.stream().filter(c -> c.getVehicles().size() > 0).map(c -> c.getVehicles())
				.flatMap(v -> v.stream()).collect(Collectors.toList()).stream().filter(v -> TrafficUtil.vehicleIsLikelyStanding(v, getExtent()))
				.filter(v -> v.getUniqueId() != me.getUniqueId()).filter(v -> SpatialUtil.intersects(v.getLaneSegment(), connWithVehicle));
		for (Object o : potentialIntersectingVehicles.toArray()) {
			Vehicle v = (Vehicle) o;
			if (SpatialUtil.intersects(v.getBoundsPolygon(), connWithVehicle.getBounds())
					&& SpatialUtil.areaInSight(me.getAbsolutePosition(), me.getDrivingDirectionVector(), v.getBoundsPolygon(), getExtent())) {
				return new VehicleWithDistance(v, SpatialUtil.getShortestDistance(v.getBoundsPolygon(), me.getBoundsPolygon()));
			}

		}
		return null;
	}

	@Override
	public boolean canEnter(Vehicle vehWantToEnter, VehiclesLane source, VehiclesLane dest, double distanceToJunction) {
		// add vehicle to approaching vehicles and update distance
		if (!vehiclesApproaching.containsKey(vehWantToEnter.getUniqueId())) {
			vehiclesApproaching.put(vehWantToEnter.getUniqueId(),
					new VehicleInJunction(vehWantToEnter, source, dest, getConnector(source, dest), distanceToJunction));
			vehWantToEnter.addVehicleListener(vehicleListener);
		} else {
			VehicleInJunction tempVeh = vehiclesApproaching.get(vehWantToEnter.getUniqueId());
			tempVeh.setDistanceToJunction(distanceToJunction);
			if (tempVeh.getSourceLane().getId() != source.getId() || tempVeh.getDestinationLane().getId() != dest.getId()) {
				tempVeh.setSourceLane(source);
				tempVeh.setDestinationLane(dest);
				tempVeh.setJunctionConnector(getConnector(source, dest));
			}
		}

		// blinker
		updateBlinkerState(vehWantToEnter, source, dest, distanceToJunction);
		return entryGrants.contains(vehWantToEnter.getUniqueId());
	}

	/**
	 * Check if driving through the junction is possible without the risk of a standstill of traffic flow.
	 *
	 * @param vehWantToEnter
	 *            the vehicle for which to check entry
	 * @param dest
	 *            destination {@link LaneSegment}
	 * @param distance
	 *            the distance to the entry point of the junction
	 * @return true if driving through is possible, false otherwise
	 */
	private boolean isDriveThroughPossible(Vehicle vehWantToEnter, VehiclesLane dest, double distance) {
		Vehicle front = vehiclesApproaching.get(vehWantToEnter.getUniqueId()).getJunctionConnector().frontVehicle();
		if (front == null) {
			front = dest.frontVehicle();
		}
		if (getType() == NodeType.ROUNDABOUT) {
			VehicleInJunction vehWantToEnterExt = vehiclesApproaching.get(vehWantToEnter.getUniqueId());
			if (hasHighestPriority(vehWantToEnterExt.getJunctionConnector()) && dest.getRoadSegment().getJunction() != null
					&& dest.getRoadSegment().getJunction().getType() == NodeType.ROUNDABOUT) {
				return true;
			}
		}
		if (front != null) {
			VehicleWithDistance frontfront = dest.frontVehicle(front);
			double minGap = vehWantToEnter.getLongitudinalControl().getMinGap();
			if (frontfront != null && frontfront.getDistance() > front.getLength() + vehWantToEnter.getLength() + 2 * minGap
					&& (frontfront.getVehicle().getLaneSegment() == null
							|| frontfront.getVehicle().getLaneSegment().equals(front.getLaneSegment()))) {
				return true;
			}
			double minSpaceInTargetLane = front.getLength() + vehWantToEnter.getLength() + vehWantToEnter.getLongitudinalControl().getMinGap();
			if (front.getLaneSegment() instanceof JunctionConnector) {
				double withinDist = front.getLaneSegment().getRoadLength() - front.getFrontPosition() + front.getLength()
						+ vehWantToEnter.getLength();
				if (frontfront != null && frontfront.getDistance() > front.getLength() + vehWantToEnter.getLength() + 2 * minGap
						&& front.getLaneSegment().getSinkLaneSegment().equals(dest)) {
					return true;
				}
				if (TrafficUtil.vehicleIsLikelyStanding(front, withinDist + minGap) || TrafficUtil.isSafeBreakPossible(front, withinDist)) {
					return false;
				}
				if (front.getLaneSegment().getSinkLaneSegment().getRoadLength() < minSpaceInTargetLane) {
					return false;
				}
			}
			if (front.getLaneSegment() instanceof LaneSegment) {
				if (front.getRearPosition() > vehWantToEnter.getLength() + minGap) {
					return true;
				}
				if (front.getFrontPosition() <= front.getLength() * 1.9 || TrafficUtil.vehicleIsLikelyStanding(front,
						vehWantToEnter.getLength() + front.getLength() + minGap - front.getFrontPosition())) {
					return false;
				}
				if (front.getLaneSegment().getRoadLength() < minSpaceInTargetLane) {
					return false;
				}
			}
		}
		return true;
	}

	private boolean hasHighestPriority(JunctionConnector conn) {
		int highestPrio = Integer.MIN_VALUE;
		JunctionConnector withHighestPrio = null;
		for (JunctionConnector c : connectors) {
			if (c.getPriority() > highestPrio) {
				withHighestPrio = c;
				highestPrio = c.getPriority();
			} else if (c.getPriority() == highestPrio && c.equals(conn)) {
				withHighestPrio = c;
			}
		}
		return conn.equals(withHighestPrio);
	}

	/**
	 * Checks if the provided vehicle is allowed to enter the junction. This method does not check traffic lights, but it checks if (in
	 * order):
	 * <ul>
	 * <li>used connector is blocked by front vehicle</li>
	 * <li>priority is available: {@link #checkEntryAllowedWithPriority(Vehicle, VehiclesLane, VehiclesLane, double)}</li>
	 * <li>maximum distance for entry grant is exceeded</li>
	 * <li>vehicle has the right law grant</li>
	 * <li>vehicle is the nearest of all approaching vehicles</li>
	 * </ul>
	 *
	 * Independent of the entry criteria, possible intersections with already granted vehicles are checked
	 *
	 * @param vehWantToEnter
	 * @param source
	 * @param dest
	 * @param distance
	 * @param ignoreRegulation
	 * @return
	 */
	private synchronized boolean checkEntryAllowed(Vehicle vehWantToEnter, VehiclesLane source, VehiclesLane dest, double distance,
			boolean ignoreRegulation) {

		JunctionConnector usedConnector = getConnector(source, dest);
		/*
		 * multilane junctions: check if vehWantToEnter is NOT on intended target lane already or if it is, and NOT first vehicle on this
		 * lane -> disallow entry to avoid deadlocks
		 */
		if (!vehWantToEnter.getLaneSegment().equals(source)
				|| vehWantToEnter.getLaneSegment().equals(source) && !vehWantToEnter.equals(source.rearVehicle())) {
			return false;
		}
		// ////////////////////////////////////////
		// check if vehicle which front is already outside junction is blocking
		// anything
		for (RoadSegment rsOut : segmentsOut) {
			for (LaneSegment lsOut : rsOut.getLaneSegments()) {
				Vehicle front = lsOut.frontVehicle();
				if (front != null && front.getRearPosition() < 0 && !usedConnector.getSinkLaneSegment().equals(front.getLaneSegment())
				// && TrafficUtil.vehicleIsLikelyStanding(front,
				// Math.abs(front.getRearPosition()))
						&& SpatialUtil.intersects(front.getBoundsPolygon(), usedConnector.getBounds())) {
					addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "vehicle " + front.getLabel() + " is blocking connector"),
							false);
					driveThroughNotPossible.put(vehWantToEnter, usedConnector);
					return false;
				}
			}
		}
		// ////////////////////////////////////////////////////////////
		// process priority information
		if (isRegulated() && !ignoreRegulation) {
			return checkEntryAllowedWithPriority(vehWantToEnter, source, dest, distance);
		}
		// ////////////////////////////////////////////////////////////
		// unregulated junction from here
		if (distance / getSpeedLimitMps() > MAX_TIME_DISTANCE_FOR_UNREGULATED_ENTRY_GRANT) {
			addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "too far away"), false);
			return false;
		}
		Vehicle vehicleRightLawGrant = getVehicleRightLaw(vehiclesApproaching.values());
		// MULTIPLE VEHICLES IN JUNCTION / DECIDED TO ENTER
		if (vehicleRightLawGrant != null) {
			if (vehicleRightLawGrant.getUniqueId() == vehWantToEnter.getUniqueId()) {
				if (checkIntersectionWithGranted(vehWantToEnter, source, dest, "right law, but ")) {
					addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter, "right law, no intersection"), false);
					return true;
				} else {
					return false;
				}
			} else {
				VehicleInJunction vRightLaw = vehiclesApproaching.get(vehicleRightLawGrant.getUniqueId());
				if (vRightLaw != null && !spatialCache.intersects(usedConnector, vRightLaw.getJunctionConnector())
						&& checkIntersectionWithGranted(vehWantToEnter, source, dest, null)
						&& (distance < 3 && vehWantToEnter.getCurrentSpeed() < 1 || distance / vehWantToEnter.getCurrentSpeed() < 1.5)
				/*
				 * closer than 1.5 seconds to junction in case of entering additionally to right law vehicle
				 */) {
					addDebugLogLine(
							getLogMessage(PREFIX_ALLOWED, vehWantToEnter, "no intersection with right law (" + vehicleRightLawGrant.getLabel() + ")"),
							false);
					return true;
				} else if (driveThroughNotPossible.containsKey(vehicleRightLawGrant)
						&& checkIntersectionWithGranted(vehWantToEnter, source, dest, null)) {
					addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter,
							"right law grant (" + vehicleRightLawGrant.getLabel() + ") cannot drive through"), false);
					return true;
				} else {
					addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "intersects with granted " + vehicleRightLawGrant.getLabel()),
							false);
					return false;
				}
			}
		} else {
			Vehicle nearest = getNearestVehicle(vehiclesApproaching.values(), true);
			if (nearest != null) {
				if (nearest.getUniqueId() == vehWantToEnter.getUniqueId()) {
					if (checkIntersectionWithGranted(vehWantToEnter, source, dest, "nearest, but")) {
						addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter, String.format("nearest, no intersection (RS %d -> %d)",
								source.getRoadSegment().getId(), dest.getRoadSegment().getId())), false);
						return true;
					} else {
						return false;
					}
				} else {
					VehicleInJunction vNearest = vehiclesApproaching.get(nearest.getUniqueId());
					if ((driveThroughNotPossible.containsKey(nearest)
							|| vNearest != null && !spatialCache.intersects(usedConnector, vNearest.getJunctionConnector()))
							&& checkIntersectionWithGranted(vehWantToEnter, source, dest, null)) {
						addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter, "no intersection with nearest (" + nearest.getLabel() + ")"),
								false);
						return true;
					} else {
						addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "intersects with nearest " + nearest.getLabel()), false);
						return false;
					}
				}
			} else {
				if (checkIntersectionWithGranted(vehWantToEnter, source, dest, "nearest cannot be found, but ")) {
					addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter,
							"no intersection with granted (" + CollectionUtil.toString(entryGrants, ",") + ")"), false);
					return true;
				} else {
					return false;
				}
			}
		}

	}

	/**
	 * check if vehicle which would have right of way cannot enter due to congestion in target segment. in this case - let enter the vehicle
	 * if route is free
	 */
	private boolean canEnterBecauseHighestPrioBlocked(Vehicle vehWantToEnter, Vehicle vehicleWithHighestPriority, List<Vehicle> vehiclesInJunction,
			VehiclesLane dest, double distance) {
		return distance < vehWantToEnter.getLength() && entryGrants.isEmpty() && vehiclesInJunction.isEmpty()
				&& !vehWantToEnter.equals(vehicleWithHighestPriority) && isDriveThroughPossible(vehWantToEnter, dest, distance)
				&& driveThroughNotPossible.containsKey(vehicleWithHighestPriority)
				&& !dest.equals(driveThroughNotPossible.get(vehicleWithHighestPriority))/**
																						 * they do not have the same blocked destination, in
																						 * this case also the right law has to be applied
																						 */
				&& vehicleWithHighestPriority.getCurrentSpeed() < 0.1/**
																		 * the other vehicle must not already have stared driving
																		 */
		;
	}

	/**
	 * check if crossing is possible even if other vehicle will enter
	 *
	 * @param vehWantToEnter
	 * @param source
	 * @param dest
	 * @param vehiclesInJunction
	 * @param logPrefix
	 *            the prefix to add before the reason why intersection is granted. if null, no log is created at all.
	 * @return
	 */
	private boolean checkIntersectionWithGranted(Vehicle vehWantToEnter, VehiclesLane source, VehiclesLane dest, String logPrefix) {
		// check intersections with vehicles already decided to enter
		for (Long vid : entryGrants) {
			VehicleInJunction potentialIntersectingVeh = vehiclesApproaching.get(vid);
			JunctionConnector connOfVehicleWantToEnter = vehiclesApproaching.get(vehWantToEnter.getUniqueId()).getJunctionConnector();
			if (!potentialIntersectingVeh.getJunctionConnector().getSourceLaneSegment().equals(connOfVehicleWantToEnter.getSourceLaneSegment())
					&& spatialCache.intersects(connOfVehicleWantToEnter, potentialIntersectingVeh.getJunctionConnector())) {
				if (logPrefix != null) {
					addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter,
							logPrefix + " intersects with " + potentialIntersectingVeh.getVehicle().getLabel() + ", entry granted"), false);
				}
				return false;
			}
		}
		return true;

	}

	/**
	 * Checks if vehicle can enter by consideration of vehicles in junction.
	 *
	 * @param vehWantToEnter
	 * @param source
	 * @param dest
	 * @param vehiclesInJunction
	 * @return true if entry is possible, false if intersection would happen and vehicle cannot enter
	 */
	private boolean checkIntersectionWithVehiclesInJunction(Vehicle vehWantToEnter, VehiclesLane source, VehiclesLane dest,
			List<Vehicle> vehiclesInJunction) {
		for (Vehicle v : vehiclesInJunction) {
			JunctionConnector connOfVehicleWantToEnter = getConnector(source, dest);
			if (!connOfVehicleWantToEnter.equals(v.getLaneSegment())/*
																	 * they do not come from the same direction
																	 */
					&& spatialCache.intersects(connOfVehicleWantToEnter, v.getLaneSegment()) /* intersection */
			) {
				addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "would intersect with " + v.getLabel()), false);
				return false;
			}
		}
		return true;
	}

	private boolean checkEntryAllowedWithPriority(Vehicle vehWantToEnter, VehiclesLane source, VehiclesLane dest, double distance) {
		if (distance / getSpeedLimitMps() > MAX_TIME_DISTANCE_FOR_REGULATED_ENTRY_GRANT) {
			addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "too far away"), false);
			return false;
		}
		JunctionConnector activeConnector = getConnector(source, dest);
		if (activeConnector.isPriorityAvailable()) {
			Map<Long, VehicleInJunction> vApproach = new HashMap<>();
			Map<Integer, ArrayList<Long>> priorities = new HashMap<>();
			Map<Long, Double> distances = new HashMap<>();
			int highestPrio = Integer.MIN_VALUE;
			for (VehicleInJunction vij : vehiclesApproaching.values()) {
				Vehicle vOtherApproaching = vij.getVehicle();
				JunctionConnector curConn = RoadUtil.findConnector(vOtherApproaching, this);
				double dist = RoadUtil.getDistance(vOtherApproaching, this);
				if (curConn != null && dist < 100
						&& (vOtherApproaching == vehWantToEnter || vOtherApproaching.getLaneSegment() != vehWantToEnter.getLaneSegment())) {
					vApproach.put(vOtherApproaching.getUniqueId(), new VehicleInJunction(vOtherApproaching, curConn.getSourceLaneSegment(),
							curConn.getSinkLaneSegment(), curConn, distance));
					distances.put(vOtherApproaching.getUniqueId(), dist);
					ArrayList<Long> vs;
					if (priorities.containsKey(curConn.getPriority())) {
						vs = priorities.get(curConn.getPriority());
					} else {
						vs = new ArrayList<>();
					}
					vs.add(vOtherApproaching.getUniqueId());
					priorities.put(curConn.getPriority(), vs);
					if (curConn.getPriority() > highestPrio) {
						highestPrio = curConn.getPriority();
					}
				}

			}

			if (activeConnector.getPriority() == highestPrio && priorities.containsKey(activeConnector.getPriority())) {
				boolean onlyLeftTurners = true;
				boolean intersects = false;
				/** build list with vehicles that have the highest priority */
				ArrayList<Vehicle> vehiclesWithHighestPrio = new ArrayList<>();
				for (long vid : priorities.get(activeConnector.getPriority())) {
					vehiclesWithHighestPrio.add(vApproach.get(vid).getVehicle());
					if (!RoadUtil.turnsLeft(vApproach.get(vid).getJunctionConnector().getRoadGeometry())) {
						onlyLeftTurners = false;
					}
					VehicleInJunction vAppr = vehiclesApproaching.get(vid);
					if (vid != vehWantToEnter.getUniqueId() && spatialCache.intersects(activeConnector, vApproach.get(vid).getJunctionConnector())
							&& (vAppr.getVehicle().getCurrentSpeed() < 0.1
									/* standing still already */ || vAppr.getDistanceToJunction() / vAppr.getVehicle().getCurrentSpeed()
									/*
									 * estimated time to junction arrival of approaching vehicle
									 */
									< Math.sqrt((distance + activeConnector.getRoadLength() + vehWantToEnter.getLength()) / (vehWantToEnter.getLongitudinalControl().getComfortableAcc())))) {
						intersects = true;
					}
				}
				if (!onlyLeftTurners && intersects && RoadUtil.turnsLeft(activeConnector.getRoadGeometry())) {
					addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "is left turner and would disturb others"), false);
					return false;
				}
				if (distance < 70) {
					// check stop sign rule
					if (activeConnector.getRoadSign() != null && activeConnector.getRoadSign().getType() == Type.STOP
							&& (distance > 3 || vehWantToEnter.getCurrentSpeed() > 0.01)) {
						addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "must stop due to road sign"), false);
						return false;
					}
					if (checkIntersectionWithGranted(vehWantToEnter, source, dest, "highest prio, but ")) {
						addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter, "highest priority, no intersection"), false);
						return true;
					} else {
						return false;
					}
				} else {
					addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "too far away"), false);
					return false;
				}

				// return checkEntryAllowed(vehWantToEnter, source, dest,
				// distance, true);
			}
			// check if entry is still possible, even if not highest priority
			// (e.g. would not intersect with vehicles inside junction)
			if (distance < 8 && !entryGrants.isEmpty() && checkIntersectionWithGranted(vehWantToEnter, source, dest, null)) {
				for (VehicleInJunction v : vApproach.values()) {
					if (segmentsIn.contains(v.getVehicle().getLaneSegment().getRoadSegment())
							&& v.getVehicle().getLaneSegment().getRoadLength() - v.getVehicle().getFrontPosition() < 5
							&& v.getJunctionConnector().getPriority() > activeConnector.getPriority() && v.getVehicle() != vehWantToEnter
							&& SpatialUtil.intersects(v.getJunctionConnector(), activeConnector)) {
						/**
						 * only disallow drivethrough if other vehicle is not blocked
						 */
						if (!driveThroughNotPossible.containsKey(v.getVehicle())) {
							addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter,
									"approaching # " + v.getVehicle().getLabel() + " has higher prio"), false);
							return false;
						}
					}
				}
				// check stop sign rule
				if (activeConnector.getRoadSign().getType() == Type.STOP && (distance > 3 || vehWantToEnter.getCurrentSpeed() > 0.01)) {
					addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "must stop due to road sign"), false);
					return false;
				}
				addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter, "not highest prio, but no intersection"), false);
				return true;
			} else {
				ArrayList<Vehicle> vehiclesWithHighestPrio = new ArrayList<>();
				// if very few vehicles are in simulation priorities may not contain anything
				if (priorities.containsKey(highestPrio)) {
					for (long vid : priorities.get(highestPrio)) {
						vehiclesWithHighestPrio.add(vApproach.get(vid).getVehicle());
					}
					boolean intersectsWithAnyHighestPrio = false;
					for (Vehicle vHighestPrio : vehiclesWithHighestPrio) {
						if (SpatialUtil.intersects(vehiclesApproaching.get(vHighestPrio.getUniqueId()).getJunctionConnector(),
								vehiclesApproaching.get(vehWantToEnter.getUniqueId()).getJunctionConnector())) {
							intersectsWithAnyHighestPrio = true;
							if (!driveThroughNotPossible.containsKey(vHighestPrio)) {
								addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "too low priority"), false);
								return false;
							}
						}
					}
					if (!intersectsWithAnyHighestPrio && isDriveThroughPossible(vehWantToEnter, dest, distance)
							&& checkIntersectionWithGranted(vehWantToEnter, source, dest, "")) {
						addDebugLogLine(
								getLogMessage(PREFIX_ALLOWED, vehWantToEnter, "overrule priority law, because no intersectino with highest prio "
										+ vehiclesWithHighestPrio.stream().map(Vehicle::getLabel).collect(Collectors.joining(","))),
								false);
						return true;
					}
					// all vehicles with highest priority cannot drive through
					Vehicle vHighestPrio = CollectionUtil.getFirstObject(vehiclesWithHighestPrio);
					if (canEnterBecauseHighestPrioBlocked(vehWantToEnter, vHighestPrio, getVehicles(), dest, distance)) {
						addDebugLogLine(getLogMessage(PREFIX_ALLOWED, vehWantToEnter,
								"overrule priority law, because " + vHighestPrio.getLabel() + " cannot drive through"), false);
						return true;
					}
				}

			}
		}
		addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, vehWantToEnter, "no priority available"), false);
		return false;
	}

	/**
	 * Returns the vehicle to which right law applies
	 *
	 * @param vehiclesApproaching
	 * @return the preferred vehicle, or null if no preference can be found
	 */
	private Vehicle getVehicleRightLaw(Collection<VehicleInJunction> vehiclesApproaching) {
		/**
		 * vehicles considered contains all vehicles which are close enough to be considered for right law
		 */
		Map<Vehicle, Integer> vehiclesConsidered = new HashMap<>();
		for (RoadSegment roadSegIn : segmentsIn) {
			for (LaneSegment laneSegIn : roadSegIn.getLaneSegments()) {
				Vehicle potentialV = laneSegIn.rearVehicle();
				if (potentialV != null && laneSegIn.getRoadLength() - potentialV.getFrontPosition() < MAX_DISTANCE_FOR_RIGHTLAW_GRANT) {
					vehiclesConsidered.put(potentialV, 0);
				}
			}
		}
		if (vehiclesConsidered.isEmpty()) {// || vehiclesConsidered.size() == segmentsIn.size()) {
			return null;
		} else if (vehiclesConsidered.size() == 1) {
			return null;
		}
		boolean hasNonRightAngledConnectors = false;
		for (Iterator<Vehicle> vit = vehiclesConsidered.keySet().iterator(); vit.hasNext();) {
			Vehicle v = vit.next();
			if (v.getRoadSegment() == null) {
				// if vehicle was just created and has not yet assigned any roadsegment
				continue;
			}
			RoadSegment rightSeg = segmentsIn.elementRightTo(v.getRoadSegment());
			boolean isRightAngle = SpatialUtil.isRightAngle(rightSeg.getRoadGeometry(), true, v.getRoadSegment().getRoadGeometry(), true);
			if (isRightAngle) {
				rightSeg.getLaneSegments().stream().map(LaneSegment::rearVehicle).filter(veh -> veh != null && vehiclesConsidered.containsKey(veh))
						.forEach(vInRightSeg -> {
							vehiclesConsidered.put(vInRightSeg, vehiclesConsidered.get(vInRightSeg) + 1);
						});
			} else {
				vehiclesConsidered.put(v, vehiclesConsidered.get(v) + 1);
				hasNonRightAngledConnectors = true;
			}
		}
		if (!hasNonRightAngledConnectors && vehiclesConsidered.size() == segmentsIn.stream().flatMap(rs -> rs.getLaneSegments().stream()).count()) {
			/** all connectors angles are right angled, and each connector has a vehicle approaching */
			return null;
		}
		int max = Integer.MIN_VALUE;
		Vehicle preferredVehicle = null;
		boolean equalPrio = false;
		for (Vehicle v : vehiclesConsidered.keySet()) {
			if (vehiclesConsidered.get(v) > max) {
				preferredVehicle = v;
				max = vehiclesConsidered.get(v);
				equalPrio = false;
			} else if (vehiclesConsidered.get(v) == max) {
				equalPrio = true;
			}
		}
		if (equalPrio) {
			return null;
		}
		// }
		return preferredVehicle;
	}

	private Vehicle getNearestVehicle(Collection<VehicleInJunction> vehiclesApproaching, boolean ignoreLeftTurners) {
		Vehicle nearestVehicle = null;
		double nearestTimeToJunction = Double.POSITIVE_INFINITY;
		double nearestDistanceToJunction = Double.POSITIVE_INFINITY;
		List<VehicleInJunction> relevantVehicles = new ArrayList<>();
		/*
		 * remember the nearest vehicle which does not turn left. if this distance is too high, also left turner can enter because it will
		 * leave early enough in order not to violate priority rules
		 */
		double minDistanceOfNonLeftTurning = Double.POSITIVE_INFINITY;
		// filter vehicles which do not turn left for nearest calculation

		for (RoadSegment roadSegIn : segmentsIn) {
			for (LaneSegment laneSegIn : roadSegIn.getLaneSegments()) {
				Vehicle potentialV = laneSegIn.rearVehicle();
				if (potentialV != null && this.vehiclesApproaching.containsKey(potentialV.getUniqueId())) {
					VehicleInJunction vij = this.vehiclesApproaching.get(potentialV.getUniqueId());
					if (!RoadUtil.turnsLeft(vij.getJunctionConnector().getRoadGeometry()) || !ignoreLeftTurners) {
						relevantVehicles.add(vij);
						minDistanceOfNonLeftTurning = Math.min(minDistanceOfNonLeftTurning, vij.getDistanceToJunction());
					}
				}
			}
		}

		// do not filter vehicles which turn left in case the non-left turners are far enough away to leave before blocking prioritized
		// vehicles
		if (!relevantVehicles.isEmpty() && minDistanceOfNonLeftTurning > getSpeedLimitMps() * MAX_TIME_DISTANCE_FOR_UNREGULATED_ENTRY_GRANT) {
			relevantVehicles.clear();
		}
		for (VehicleInJunction vij : (relevantVehicles.isEmpty() ? vehiclesApproaching : relevantVehicles)) {
			Vehicle v = vij.getVehicle();
			VehiclesLane curLane = v.getLaneSegment();
			double distanceToJunction = curLane.getRoadLength() - v.getFrontPosition();
			while (curLane instanceof JunctionConnector || !this.equals(curLane.getRoadSegment().getJunction())) {
				curLane = curLane.getSinkLaneSegment();
				if (curLane == null) {
					/*
					 * this junction is not the next in the vehicles route -> we ignore this vehicle for planning and continue with the
					 * other vehicles approaching. Simply said: a vehicle cannot look past the next junction for now, even if its close to
					 * the current one.
					 */
					distanceToJunction = Double.POSITIVE_INFINITY;
					break;
				}
				distanceToJunction += curLane.getRoadLength();
			}
			if (v.getCurrentSpeed() < 1.5 && distanceToJunction <= nearestDistanceToJunction) {
				nearestDistanceToJunction = distanceToJunction;
				nearestTimeToJunction = distanceToJunction / v.getTargetSpeed();
				nearestVehicle = v;
			} else if (distanceToJunction / v.getCurrentSpeed() < nearestTimeToJunction) {
				// driving vehicle: take the one closer to the junction (in
				// terms of time)
				nearestDistanceToJunction = distanceToJunction;
				nearestTimeToJunction = distanceToJunction / v.getCurrentSpeed();
				nearestVehicle = v;
			}
		}
		return nearestVehicle;
	}

	@Override
	public Map<Long, VehicleInJunction> getVehiclesApproaching() {
		return Collections.unmodifiableMap(vehiclesApproaching);
	}

	@Override
	public Set<Long> getEntryGrants() {
		return Collections.unmodifiableSet(entryGrants);
	}

	@Override
	public boolean removeEntryGrant(Vehicle v, IRoute newRoute) {
		if (!entryGrants.contains(v.getUniqueId())) {
			/**
			 * also remove from vehiclesApproaching, because it may happen that this map contains wrong assigned junctionconnector and leads
			 * to accidents due to wrong intersection calculation
			 */
			if (vehiclesApproaching.containsKey(v.getUniqueId())) {
				vehiclesApproaching.remove(v.getUniqueId());
			}
			addDebugLogLine(
					getLogMessage(v,
							"removed from approaching vehicles due to route change (" + v.getRoute().toString() + " -> " + newRoute.toString() + ")"),
					true);
			return true;
		}
		/** check if granted vehicle is able to brake if entry is prohibited */
		boolean isOnlyVehicleWithGrant = vehiclesApproaching.isEmpty() && getVehicles().isEmpty() && decidedToEnterContainsOnly(v);
		if (isOnlyVehicleWithGrant || TrafficUtil.isSafeBreakPossible(v,
				v.getLaneSegment().getRoadLength() - v.getFrontPosition() - v.getLongitudinalControl().getMinGap() * 2)) {
			addDebugLogLine(getLogMessage(PREFIX_GRANT_REMOVED, v,
					"removed grant due to route change (" + v.getRoute().toString() + " -> " + newRoute.toString() + ")"), true);
			vehiclesApproaching.remove(v.getUniqueId());
			entryGrants.remove(v.getUniqueId());
			return true;
		}
		return false;
	}

	private boolean decidedToEnterContainsOnly(Vehicle v) {
		return entryGrants.size() == 1 && entryGrants.contains(v.getUniqueId());
	}

	@Override
	public void updateEntryGrants(double dt, Date time, double runTime) {
		// remove entry grants which are not in approaching list (possibly added too early)
		for (Iterator<Long> it = entryGrants.iterator(); it.hasNext();) {
			Long vid = it.next();
			if (!vehiclesApproaching.containsKey(vid)) {
				it.remove();
			} else {
				VehicleInJunction vij = vehiclesApproaching.get(vid);
				// vehicle is not the first in this lane segment - added too early - remove it
				VehiclesLane ls = vij.getVehicle().getLaneSegment();
				if (ls instanceof LaneSegment && !vid.equals(ls.rearVehicle().getUniqueId())) {
					it.remove();
				}
			}

		}

		// update vehicle grants
		for (Long vid : vehiclesApproaching.keySet()) {
			if (!entryGrants.contains(vid)) {
				VehicleInJunction vApproaching = vehiclesApproaching.get(vid);
				if (isEntryGranted(vApproaching)) {
					entryGrants.add(vid);
					addDebugLogLine(getLogMessage(PREFIX_GRANTED, vehiclesApproaching.get(vid).getVehicle(),
							"entry granted!  (New grants: " + CollectionUtil.toString(entryGrants, ",") + ")"), true);
				}
			}
		}
		// if (vehiclesApproaching.size()>1 && entryGrants.size()==0) {
		// System.out.println("deadlock junction #"+getId());
		// }
		// remove if traffic light is red in the meantime
		for (Iterator<Long> it = entryGrants.iterator(); it.hasNext();) {
			Long vid = it.next();
			VehicleInJunction vij = vehiclesApproaching.get(vid);
			TrafficLight tl = vij.getJunctionConnector().getTrafficLight();
			if (tl != null && (tl.getCurrentState() == TrafficLightState.RED || tl.getCurrentState() == TrafficLightState.YELLOW)
					&& TrafficUtil.isSafeBreakPossible(vij.getVehicle(), vij.getDistanceToJunction())) {
				if (logProvider != null) {
					logProvider.addLogLine(getLogMessage(PREFIX_DISALLOWED, vij.getVehicle(), "traffic light turned red"));
				}
				it.remove();
			}
		}
		// check standstill
		if (entryGrants.isEmpty() && (!driveThroughNotPossible.isEmpty() || !vehiclesApproaching.isEmpty())) {
			Map<Long, VehicleInJunction> frontVehicles = new HashMap<>();
			boolean standstill = true;
			for (RoadSegment rs : segmentsIn) {
				for (LaneSegment ls : rs.getLaneSegments()) {
					if (ls.rearVehicle() != null) {
						VehicleInJunction vAppr = vehiclesApproaching.get(ls.rearVehicle().getUniqueId());
						if (vAppr != null && vAppr.getDistanceToJunction() < vAppr.getVehicle().getLongitudinalControl().getMinGap() * 1.5
								&& vAppr.getVehicle().getCurrentSpeed() < 0.1) {
							frontVehicles.put(vAppr.getVehicle().getUniqueId(), vAppr);
						} else {
							standstill = false;
						}
					}
				}
			}
			if (standstill && !driveThroughNotPossible.isEmpty()) {
				for (Vehicle v : driveThroughNotPossible.keySet()) {
					frontVehicles.remove(v.getUniqueId());
				}
				Vehicle bestVehicle = getVehicleRightLaw(frontVehicles.values());
				if (bestVehicle == null) {
					bestVehicle = getNearestVehicle(frontVehicles.values(), true);
				}
				if (bestVehicle == null) {
					bestVehicle = getNearestVehicle(frontVehicles.values(), false);
				}
				if (bestVehicle != null) {
					VehicleInJunction bestVehicleInJunction = vehiclesApproaching.get(bestVehicle.getUniqueId());
					if (checkIntersectionWithVehiclesInJunction(bestVehicle, bestVehicleInJunction.getSourceLane(),
							bestVehicleInJunction.getDestinationLane(), getVehicles())) {
						if (isDriveThroughPossible(bestVehicle, bestVehicleInJunction.getDestinationLane(),
								bestVehicleInJunction.getDistanceToJunction())) {
							addDebugLogLine(
									getLogMessage(PREFIX_ALLOWED, bestVehicle, "standstill detected. not highest priority, but others are blocked"),
									false);
							entryGrants.add(bestVehicle.getUniqueId());
							addDebugLogLine(getLogMessage(PREFIX_GRANTED, bestVehicle,
									"entry granted!  (New grants: " + CollectionUtil.toString(entryGrants, ",") + ")"), true);
						} else {
							driveThroughNotPossible.put(bestVehicle, bestVehicleInJunction.getDestinationLane());
						}
					}
				}
			}
		}
		assert entryGrants
				.containsAll(getVehicles().stream().map(Vehicle::getUniqueId).collect(Collectors.toList())) : "Not all vehicles in junction #"
						+ getId() + " are contained in entry grants! Missing: "
						+ CollectionUtil.toString(
								getVehicles().stream().map(Vehicle::getUniqueId).filter(e -> !entryGrants.contains(e)).collect(Collectors.toList()),
								",");
	}

	/**
	 * This method checks if the entry can be granted to the given vehicle, but it just CHECKS. This means the list of
	 * {@link #vehiclesApproaching} and {@link #entryGrants} are not updated!
	 *
	 * @param v
	 *            the {@link VehicleInJunction} object which contains the vehicle for which entry should be checked (for the included
	 *            {@link JunctionConnector})
	 * @return true if the entry can be granted to vehicle v, false otherwise
	 */
	private boolean isEntryGranted(VehicleInJunction v) {
		if (isSimpleThrough()) {
			return true;
		}
		if (v == null) {
			return false;
		}
		// //////////////////////// traffic lights?
		JunctionConnector conn = v.getJunctionConnector();
		if (conn.getTrafficLight() != null) {
			TrafficLightState tlState = conn.getTrafficLight().getCurrentState();
			if (tlState == TrafficLightState.RED || tlState == TrafficLightState.RED_YELLOW) {
				return false;
			}
			if (tlState == TrafficLightState.GREEN) {
				if (RoadUtil.turnsLeft(conn.getRoadGeometry())) {
					// we are the left turner
					return isOkLeftTurner(v, conn)
							&& checkIntersectionWithGranted(v.getVehicle(), v.getSourceLane(), v.getDestinationLane(), "left turner, but ")
							&& isDriveThroughPossible(v.getVehicle(), v.getDestinationLane(), v.getDistanceToJunction());
				}
				return checkIntersectionWithGranted(v.getVehicle(), v.getSourceLane(), v.getDestinationLane(), "") && isNearestInRoutingSegment(v)
						&& isDriveThroughPossible(v.getVehicle(), v.getDestinationLane(), v.getDistanceToJunction());
			}
			return false;
		}
		// /////////////////////// end of traffic lights

		if (v.getVehicle().getRoadSegment() != null
				&& v.getDistanceToJunction() > MAX_TIME_DISTANCE_FOR_UNREGULATED_ENTRY_GRANT * v.getVehicle().getRoadSegment().getSpeedLimitMps()) {
			return false;
		}
		boolean entryAllowed = checkEntryAllowed(v.getVehicle(), v.getSourceLane(), v.getDestinationLane(), v.getDistanceToJunction(), false);
		// check if vehicle is able to drive through junction (if a jam occurs,
		// no entry is granted, because entered vehicles may not be
		// able to drive through and create deadlocks this way
		if (entryAllowed || driveThroughNotPossible.containsKey(v.getVehicle())) {
			if (!isDriveThroughPossible(v.getVehicle(), v.getDestinationLane(), v.getDistanceToJunction())) {
				driveThroughNotPossible.put(v.getVehicle(), v.getDestinationLane());
				addDebugLogLine(getLogMessage(PREFIX_DISALLOWED, v.getVehicle(), "cannot drive through"), false);
				return false;
			} else {
				driveThroughNotPossible.remove(v.getVehicle());
			}
		}
		return entryAllowed;

	}

	/**
	 * Check if it is ok that vehicle v enters the junction using connector conn
	 *
	 * @param v
	 * @param conn
	 * @return true if ok, false otherwise
	 */
	private boolean isOkLeftTurner(VehicleInJunction v, JunctionConnector conn) {
		for (VehicleInJunction vAppr : vehiclesApproaching.values()) {
			if (vAppr.equals(v) || vAppr.getSourceLane().equals(v.getSourceLane())) {
				continue;
			}

			TrafficLightState otherState = TrafficLightState.GREEN;

			if (vAppr.getJunctionConnector().getTrafficLight() != null) {
				otherState = vAppr.getJunctionConnector().getTrafficLight().getCurrentState();
			}

			if ((otherState == TrafficLightState.GREEN || otherState == TrafficLightState.YELLOW)
					&& SpatialUtil.intersects(vAppr.getJunctionConnector(), v.getJunctionConnector())
					&& (!TrafficUtil.isSafeBreakPossible(vAppr.getVehicle(), vAppr.getDistanceToJunction())
							|| vAppr.getDistanceToJunction() / vAppr.getVehicle().getCurrentSpeed()
							/*
							 * estimated time to junction arrival of approaching vehicle
							 */
							< Math.sqrt((v.getDistanceToJunction() + v.getJunctionConnector().getRoadLength() + v.getVehicle().getLength()) / (v.getVehicle().getLongitudinalControl().getComfortableAcc())))
			/*
			 * estimated pass time of waiting vehicle through junction -> t_pass = sqrt(s/a)
			 */) {
				if (RoadUtil.turnsLeft(vAppr.getJunctionConnector().getRoadGeometry())) {
					// other is also left turner
					return getArrivalTimeDiff(v, vAppr) < 0;
				}
				return false;
			}
		}
		return true;
	}
}

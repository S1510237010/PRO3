package at.fhhagenberg.mc.traffsim.routing.rerouter.congestion;

import java.util.Set;
import java.util.stream.Collectors;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.routing.AbstractRouteService;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.statistics.events.IEventLog;
import at.fhhagenberg.mc.traffsim.util.ThreadingUtil;
import at.fhhagenberg.mc.traffsim.util.types.PositiveMovingAverage;

public class SpeedAverageCostEvaluatorAndCongestionProvider extends AbstractCostAndCongestionEvaluator {

	private int movingAverageSize;

	public SpeedAverageCostEvaluatorAndCongestionProvider(String name, long updateIntervalMillis, long congestionDetectionUpdateMs,
			RoadNetwork network, AbstractRouteService router, int movingAverageSize, float congestionThresholdFactor, int congestionLevel,
			int minVehiclesForCongestion, IEventLog log) {
		super(name, updateIntervalMillis, congestionDetectionUpdateMs, network, router, congestionThresholdFactor, congestionLevel,
				minVehiclesForCongestion, log);
		this.movingAverageSize = movingAverageSize;
	}

	@Override
	protected void updateSpeedMapsAndCongestion() {
		ThreadingUtil.executeAction(network.getRoadSegments(), seg -> {
			Set<Long> vehicles = observationCenter.getVehicleIds(seg.getId()).stream().filter(v -> observationCenter.getVehicleSpeed(v) >= 0)
					.collect(Collectors.toSet());
			double overallSpeed = 0;
			for (Long v : vehicles) {
				overallSpeed += observationCenter.getVehicleSpeed(v);
			}
			// calculate average and save in cache
			double newValue;
			if (vehicles.size() > 0) {
				newValue = overallSpeed / vehicles.size();
			} else {
				newValue = seg.getSpeedLimitMps();
			}
			speedCurrentMap.put(seg.getId(), newValue);
			if (!speedAverageMap.containsKey(seg.getId())) {
				speedAverageMap.put(seg.getId(), new PositiveMovingAverage(movingAverageSize));
				speedMaxMap.put(seg.getId(), seg.getSpeedLimitMps());
			}
			speedAverageMap.get(seg.getId()).addValue(newValue);
			// check congestion threshold
			if (vehicles.size() >= numVehiclesForCongestion) {
				double thres = speedAverageMap.get(seg.getId()).currentAverage() / seg.getSpeedLimitMps();
				if (thres < congestionThreshold && !isMultiNotification(seg.getId())) {
					if (congestedSegments.add(seg)) {
						lastCongestedNotifications.put(seg.getId(), getCurrentSimTime().getTime());
						eventLog.logCongestion(EventType.CONGESTION_DETECTED, "SpeedAverage",
								"Segment ID #" + seg.getId() + " (" + seg.getName() + ") congested", seg.getEndNode().getId(), seg.getId(), thres);
					}
				}
			}
		}, "updating speed average maps");
		overrideSegmentCost();
	}

}

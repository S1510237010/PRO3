package at.fhhagenberg.mc.traffsim.vehicle;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;

public interface IVehicleRouteListener extends IVehicleListener {
	public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute);
}

package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.FixedTimeController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.FixedTimeControlLogic;

public class FixedTimeRegulationConfigurationControl
		extends TrafficRegulationConfigurationControl<FixedTimeController, FixedTimeControlLogic, FixedTimeTrafficLightConfigurationParameters> {

	private Spinner spinnerDelay;
	private Spinner spinnerTimeGreen;
	private Spinner spinnerTimeRed;
	private Spinner spinnerOffset;
	private Button btnStartWithGreen;

	public FixedTimeRegulationConfigurationControl(Composite parent, int style) {
		super(parent, style);
	}

	@Override
	protected void intialize() {

		Label lblTrafficLightHeader = new Label(container, SWT.CHECK);
		lblTrafficLightHeader.setText("Traffic Light Properties");
		lblTrafficLightHeader.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		FontDescriptor boldDescriptor = FontDescriptor.createFrom(lblTrafficLightHeader.getFont()).setStyle(SWT.BOLD);
		Font boldFont = boldDescriptor.createFont(lblTrafficLightHeader.getDisplay());
		lblTrafficLightHeader.setFont(boldFont);

		Label trafficLightDelayLabel = new Label(container, SWT.NONE);
		trafficLightDelayLabel.setText("Phase delay [s]");
		trafficLightDelayLabel.setToolTipText("Delay introduced before a traffic light changes its phase");
		spinnerDelay = new Spinner(container, SWT.BORDER);
		spinnerDelay.setDigits(3);
		spinnerDelay.setMaximum(120000);
		spinnerDelay.setMinimum(0);
		spinnerDelay.setPageIncrement(1000);
		spinnerDelay.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label trafficLightGreenPhaseLabel = new Label(container, SWT.NONE);
		trafficLightGreenPhaseLabel.setText("Green phase [s]");
		trafficLightGreenPhaseLabel.setToolTipText("Duration of the traffic light's green phase");
		spinnerTimeGreen = new Spinner(container, SWT.BORDER);
		spinnerTimeGreen.setDigits(3);
		spinnerTimeGreen.setMaximum(120000);
		spinnerTimeGreen.setMinimum(5000);
		spinnerTimeGreen.setPageIncrement(1000);
		spinnerTimeGreen.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label trafficLightRedPhaseLabel = new Label(container, SWT.NONE);
		trafficLightRedPhaseLabel.setText("Red phase [s]");
		trafficLightRedPhaseLabel.setToolTipText("Duration of the traffic light's red phase");
		spinnerTimeRed = new Spinner(container, SWT.BORDER);
		spinnerTimeRed.setDigits(3);
		spinnerTimeRed.setMaximum(120000);
		spinnerTimeRed.setMinimum(5000);
		spinnerTimeRed.setPageIncrement(1000);
		spinnerTimeRed.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		Label offsetLabel = new Label(container, SWT.NONE);
		offsetLabel.setText("Offset [s]");
		offsetLabel.setToolTipText("Timespan by which this traffic light is set off the others");
		spinnerOffset = new Spinner(container, SWT.BORDER);
		spinnerOffset.setDigits(3);
		spinnerOffset.setMaximum(120000);
		spinnerOffset.setMinimum(0);
		spinnerOffset.setPageIncrement(1000);
		spinnerOffset.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});

		btnStartWithGreen = new Button(container, SWT.CHECK);
		btnStartWithGreen.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		btnStartWithGreen.setText("Start with green phase");
		btnStartWithGreen.setToolTipText("Determines if the signal starts with a green phase or not");
		btnStartWithGreen.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateProperties();
			}
		});
	}

	@Override
	protected void updateControls() {
		if (selectedControlLogic != null) {
			spinnerDelay.setSelection((int) selectedControlLogic.getDelay());
			spinnerTimeGreen.setSelection((int) selectedControlLogic.getTimeGreen());
			spinnerTimeRed.setSelection((int) selectedControlLogic.getTimeRed());
			spinnerOffset.setSelection((int) selectedControlLogic.getOffset());
			btnStartWithGreen.setSelection(selectedControlLogic.isGreenInitially());
			spinnerDelay.setEnabled(true);
			spinnerTimeGreen.setEnabled(true);
			spinnerTimeRed.setEnabled(true);
			spinnerOffset.setEnabled(true);
			btnStartWithGreen.setEnabled(true);
		} else {
			spinnerDelay.setSelection(0);
			spinnerTimeGreen.setSelection(0);
			spinnerTimeRed.setSelection(0);
			spinnerOffset.setSelection(0);
			btnStartWithGreen.setSelection(false);
			spinnerDelay.setEnabled(false);
			spinnerTimeGreen.setEnabled(false);
			spinnerTimeRed.setEnabled(false);
			spinnerOffset.setEnabled(false);
			btnStartWithGreen.setEnabled(false);
		}
	}

	private void updateProperties() {
		if (selectedControlLogic != null) {
			selectedControlLogic.setDelay(spinnerDelay.getSelection());
			selectedControlLogic.setTimeGreen(spinnerTimeGreen.getSelection());
			selectedControlLogic.setTimeRed(spinnerTimeRed.getSelection());
			selectedControlLogic.setOffset(spinnerOffset.getSelection());
			selectedControlLogic.setGreenInitially(btnStartWithGreen.getSelection());
		}
	}

	@Override
	public void activate(boolean activate) {
		btnStartWithGreen.setEnabled(activate);
		spinnerDelay.setEnabled(activate);
		spinnerOffset.setEnabled(activate);
		spinnerTimeGreen.setEnabled(activate);
		spinnerTimeRed.setEnabled(activate);
	}

	@Override
	public FixedTimeTrafficLightConfigurationParameters getConfigurationParameters() {
		FixedTimeTrafficLightConfigurationParameters params = new FixedTimeTrafficLightConfigurationParameters();
		params.startWithGreenPhase = btnStartWithGreen.getSelection();
		params.phaseDelay = spinnerDelay.getSelection();
		params.greenPhase = spinnerTimeGreen.getSelection();
		params.redPhase = spinnerTimeRed.getSelection();
		params.offset = spinnerOffset.getSelection();
		return params;
	}
}

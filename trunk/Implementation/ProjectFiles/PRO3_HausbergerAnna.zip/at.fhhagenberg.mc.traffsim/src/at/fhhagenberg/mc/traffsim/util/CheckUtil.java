package at.fhhagenberg.mc.traffsim.util;

import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Utility class providing numerous validation methods (e.g. for acceleration, distances).
 *
 * @author Christian Backfrieder
 */
public class CheckUtil {

	/**
	 * Checks if the provided acceleration can be considered as safe.
	 *
	 * @param acc
	 *            the acceleration to be validated
	 * @return true if the acceleration is greater than or equal to @see TrafficDefaults.DEFAULT_SAFE_DECELERATION - false else
	 */
	public static boolean isSafeAcceleration(double acc) {
		return acc >= TrafficDefaults.DEFAULT_SAFE_DECELERATION;
	}

	/**
	 * Checks if the provided distance between two vehicles can be considered as safe taking the velocity difference between the vehicles
	 * into account.
	 *
	 * @param v1
	 *            the first vehicle
	 * @param v2
	 *            the second vehicle
	 * @param dist
	 *            the distance to be validated
	 * @return true if the distance cannot be covered in less than the minimum time headway of both vehicles considering the current
	 *         velocities - false else
	 */
	public static boolean isSafeDistance(Vehicle v1, Vehicle v2, double dist) {
		double v1tmin = v1.isObstacle() ? Double.MAX_VALUE : v1.getLongitudinalControl().getLongitudinalModel().getModelData().gettMin();
		double v2tmin = v2.isObstacle() ? Double.MAX_VALUE : v2.getLongitudinalControl().getLongitudinalModel().getModelData().gettMin();
		double dv = Math.abs(v1.getCurrentSpeed() - v2.getCurrentSpeed());
		return dist / dv >= Math.min(v1tmin, v2tmin);
	}

	/**
	 * Checks if the provided acceleration can be considered as tolerable.
	 *
	 * @param acc
	 *            the acceleration to be validated
	 * @return true if the acceleration is greater than or equal to @see TrafficDefaults.DEFAULT_TOLERABLE_DECELERATION - false else
	 */
	public static boolean isTolerableAcceleration(double acc) {
		return acc >= TrafficDefaults.DEFAULT_TOLERABLE_DECELERATION;
	}
}
package at.fhhagenberg.mc.traffsim.vehicle.model.consumption;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Class providing various constants required for determining a {@link Vehicle}
 * 's fuel consumption.
 *
 * @author Christian Backfrieder
 */
public abstract class FuelConstants {

	/** The caloric density of fuel (e.g. gasoline: 44 MJ/kg = 0.76 * 44 MJ/l) */
	public static final double CALORIC_DENS = 44e6;

	/** Conversion factor for Bar to Pascal */
	public static final double CONVERSION_BAR_TO_PASCAL = 1e5;

	/** Density of air in kg/m� */
	public static final double RHO_AIR = 1.29;

	/** Density of gasoline in kg/m� */
	public static final double RHO_FUEL = 760;

	/** Density of gasoline in kg/l */
	public static final double RHO_FUEL_PER_LITER = RHO_FUEL / 1000.;

	/**
	 * Conversion factor for g/kWh to m�/Ws (0.001 kg/1000W/3600s = 1 / 3.6e9)
	 */
	public static final double CONVERSION_GRAMM_PER_KWH_TO_SI = 1. / (RHO_FUEL * 3.6e9);

	/** Gravitational constant */
	public static final double GRAVITATION = 9.81;
	
	/** Conversion factors to translate fuel consumption to CO2 emissions **/
	public static final double LITERS_TO_CARBON_DIOXIDE_GASOLINE = 2.39;
	public static final double LITERS_TO_CARBON_DIOXIDE_DIESEL = 2.69;
	public static final double LITERS_TO_CARBON_DIOXIDE_PETROLEUM_GAS = 17.8;
	public static final double LITERS_TO_CARBON_DIOXIDE_NATURAL_GAS = 2.74;
}
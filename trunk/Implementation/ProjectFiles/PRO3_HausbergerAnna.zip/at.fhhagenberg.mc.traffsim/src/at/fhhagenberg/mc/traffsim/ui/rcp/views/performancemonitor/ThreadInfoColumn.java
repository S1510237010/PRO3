package at.fhhagenberg.mc.traffsim.ui.rcp.views.performancemonitor;

public enum ThreadInfoColumn {
	ID("ID"), NAME("Name"), STATE("State"), CPU_TIME("CPU Time");
	private String label;

	ThreadInfoColumn(String label) {
		this.label = label;
	}
	
	public String toString() {
		return label;
	}
}

package at.fhhagenberg.mc.traffsim.changes;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.thoughtworks.xstream.converters.ConversionException;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.converters.basic.DateConverter;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

public class ChangeSetDateConverter implements Converter {
	private DateConverter defaultConverter = new DateConverter();
	private SimpleDateFormat utcFormatter;

	public ChangeSetDateConverter() {
		utcFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());
		utcFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
	}

	@SuppressWarnings("rawtypes") //must implement interface!
	@Override
	public boolean canConvert(Class clazz) {
		// This converter is only for Calendar fields.
		return clazz == Date.class;
	}

	@Override
	public void marshal(Object value, HierarchicalStreamWriter writer, MarshallingContext context) {
		Date date = (Date) value;
		writer.setValue(utcFormatter.format(date));
	}

	@Override
	public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
		Date date;
		try {
			date = (Date) defaultConverter.fromString(reader.getValue());
		} catch (ConversionException e1) {
			try {
				date = utcFormatter.parse(reader.getValue());
			} catch (ParseException e) {
				throw new ConversionException(e.getMessage(), e);
			}
		}
		return date;
	}
}

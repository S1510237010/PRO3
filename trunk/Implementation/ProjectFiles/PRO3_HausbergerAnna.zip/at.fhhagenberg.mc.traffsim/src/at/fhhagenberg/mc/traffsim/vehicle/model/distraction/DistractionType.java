package at.fhhagenberg.mc.traffsim.vehicle.model.distraction;

import java.util.Random;

import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.distribution.LogNormalDistribution;
import org.apache.commons.math3.distribution.RealDistribution;
import org.apache.commons.math3.random.JDKRandomGenerator;
import org.apache.commons.math3.random.RandomGenerator;

import at.fhhagenberg.mc.traffsim.util.math.MathUtil;

public class DistractionType {

	public enum DurationDistribution {
		LOG_NORMAL, GAMMA
	}

	private long id;
	private String description;

	// Number of distractive events occurring per hour
	private double frequency;

	// Percent of all drivers engaging in the type of distraction
	private double exposure;

	// Mean, minimum and maximum duration
	private double meanDuration;
	private double stdDuration;
	private double minDuration;
	private double maxDuration;

	// Determines the bounds by which factor the driver's response time is affected
	private double minDelay;
	private double maxDelay;

	// Determines whether the distraction is severe or not
	private boolean isSevere;

	private boolean isStochastic;

	private Random random;
	private LogNormalDistribution logn;
	private GammaDistribution gamma;

	public DistractionType(long id, String description, boolean isStochastic) {
		this.id = id;
		this.description = description;
		this.isStochastic = isStochastic;
		this.random = new Random(id);
	}

	public void initialize() {
		if (isStochastic) {
			logn = MathUtil.getLogNormalDistribution(meanDuration, stdDuration);
			gamma = MathUtil.getGammaDistribution(meanDuration, stdDuration);
		} else {
			RandomGenerator gen = new JDKRandomGenerator();
			gen.setSeed(id);
			logn = MathUtil.getLogNormalDistribution(meanDuration, stdDuration, gen);
			gamma = MathUtil.getGammaDistribution(meanDuration, stdDuration, gen);
		}
	}

	public long getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getFrequency() {
		return frequency;
	}

	public void setFrequency(double frequency) {
		this.frequency = frequency;
	}

	public double getExposure() {
		return exposure;
	}

	public void setExposure(double exposure) {
		this.exposure = exposure;
	}

	public double getMeanDuration() {
		return meanDuration;
	}

	public void setMeanDuration(double meanDuration) {
		this.meanDuration = meanDuration;
	}

	public double getStdDuration() {
		return stdDuration;
	}

	public void setStdDuration(double stdDuration) {
		this.stdDuration = stdDuration;
	}

	public double getMinDuration() {
		return minDuration;
	}

	public void setMinDuration(double minDuration) {
		this.minDuration = minDuration;
	}

	public double getMaxDuration() {
		return maxDuration;
	}

	public void setMaxDuration(double maxDuration) {
		this.maxDuration = maxDuration;
	}

	public double getMinDelay() {
		return minDelay;
	}

	public void setMinDelay(double minDelay) {
		this.minDelay = minDelay;
	}

	public double getMaxDelay() {
		return maxDelay;
	}

	public void setMaxDelay(double maxDelay) {
		this.maxDelay = maxDelay;
	}

	public boolean isSevere() {
		return isSevere;
	}

	public void setIsSevere(boolean isSevere) {
		this.isSevere = isSevere;
	}

	public double getAverageInterArrivalTime() {
		return 3600.0 / frequency;
	}

	public double getResponseTimeIncrease() {
		return random.nextDouble() * (maxDelay - minDelay) + minDelay;
	}

	public double getDuration(DurationDistribution distribution, boolean useBounds) {

		RealDistribution dist;

		switch (distribution) {
		case LOG_NORMAL:
			dist = logn;
			break;
		case GAMMA:
			dist = gamma;
			break;
		default:
			return 0.0;
		}

		double sample = dist.sample();

		if (useBounds) {
			while (sample < minDuration || sample > maxDuration) {
				sample = dist.sample();
			}
		}

		return sample;
	}
}

package at.fhhagenberg.mc.traffsim.roadnetwork.route;

import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.ui.IRouteTraversalListener;

public interface IRoute {
	public RoadSegment getInitialSegment();

	public long getNextRoutingId();

	public long getRoutingIdAfter(long id);

	public long removeNextSegmentIdIfMatches(long id);

	public long getId();

	public List<Long> getRouteIds();

	public RoadSegment getTargetSegment();

	public List<Boolean> getIsReverse();
	
	public void setInitialRoadSegment(RoadSegment seg);

	public void setTargetSegment(RoadSegment lastObject);

	public void setIsReverse(List<Boolean> segmentReverse);
	
	public void addRouteTraversalListener(IRouteTraversalListener listener);
	
	public void removeRouteTraversalListener(IRouteTraversalListener listener);
}
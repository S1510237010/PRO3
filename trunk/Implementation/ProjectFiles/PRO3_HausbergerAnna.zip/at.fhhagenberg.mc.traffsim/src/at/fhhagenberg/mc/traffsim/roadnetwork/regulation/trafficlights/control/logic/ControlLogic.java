package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.DelayQueue;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.DelayedTask;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.statistics.IStatisticsProvider;
import at.fhhagenberg.mc.traffsim.statistics.IStatsConstants;

/**
 * Base class for all control logics used to configure a traffic light. A control logic serves as a container for specific parameters which
 * are utilized by a junction's traffic light controller to carry out a certain control strategy.
 *
 * @author Manuel Lindorfer
 *
 */
public abstract class ControlLogic implements IStatisticsProvider {
	protected DelayQueue<DelayedTask> scheduledTasks = new DelayQueue<>();

	protected double simulationTime;
	protected TrafficLight trafficLight;

	/**
	 * Creates a new control logic for the given traffic light
	 *
	 * @param trafficLight
	 *            the target traffic light
	 */
	public ControlLogic(TrafficLight trafficLight) {
		this.trafficLight = trafficLight;
	}

	/**
	 * Get's the current simulation runtime in seconds
	 *
	 * @return duration in seconds
	 */
	public double getSimulationTime() {
		return simulationTime;
	}

	/**
	 * Get's the current simulation runtime in milliseconds
	 *
	 * @return duration in milliseconds
	 */
	public long getSimualtionTimeInMilliseconds() {
		return Math.round(simulationTime * 1000);
	}

	/**
	 * Get's the traffic light configured by the control logic.
	 *
	 * @return the associated traffic light
	 */
	public TrafficLight getTrafficLight() {
		return trafficLight;
	}

	/**
	 * Initiates and immediate switch of the referenced traffic light to either the green or the red phase.
	 *
	 * @param toGreen
	 *            true if switching to the green phase, false else
	 */
	public void requestChange(boolean toGreen) {
		requestChange(toGreen, 0);
	}

	/**
	 * Initiates a switch of the referenced traffic light to either the green or the red phase after the given delay has elapsed.
	 *
	 * @param toGreen
	 *            true if switching to the green phase, false else
	 * @param delay
	 *            delay in millisconds
	 */
	public void requestChange(boolean toGreen, long delay) {
		trafficLight.toggleService(toGreen, delay);
	}

	/**
	 * Update method invoked in every simulation update time step. Verifies whether any of the scheduled tasks (e.g. phase switches) have to
	 * be executed or not.
	 *
	 * @param dt
	 *            the simulation update interval in seconds
	 * @param simulationTime
	 *            the simulation runtime in seconds
	 */
	public void update(double dt, double simulationTime) {
		this.simulationTime = simulationTime;

		long delayMillis = Math.round(dt * 1000);

		for (DelayedTask task : scheduledTasks) {
			task.updateDelay(delayMillis);
		}

		onStrategyUpdate(delayMillis);

		DelayedTask task;

		while ((task = scheduledTasks.poll()) != null) {
			task.run();
		}
	}

	/**
	 * Callback invoked in every update time step. Used for updating control logic specific properties.
	 *
	 * @param dt
	 *            the simulation update interval in milliseconds
	 */
	protected void onStrategyUpdate(long dt) {

	}

	@Override
	protected void finalize() throws Throwable {
		scheduledTasks.clear();
		super.finalize();
	}

	/**
	 * Converts the control logic to the corresponding data entity.
	 *
	 * @return a serializable control logic entity
	 */
	public abstract ControlLogicBean toBean();

	@Override
	public Map<String, Number> obtainStatistics() {
		Map<String, Number> statistics = new HashMap<>();
		statistics.put(IStatsConstants.CONTROL_LOGIC_SERVICE_LENGTH, trafficLight.getServiceLength());
		statistics.put(IStatsConstants.CONTROL_LOGIC_SERVICE_STATE, trafficLight.isServiced() ? 1d : 0d);
		return statistics;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

public enum FuelType {
	GASOLINE("Gasoline"), DIESEL("Diesel"), PETROLEUM_GAS("Petroleum gas"), NATURAL_GAS("Natural gas"), ELECTRIC("Electric"), MICROHYBRID("Micro Hybrid"), MILDHYBRID("Mild Hybrid"), FULLHYBRID("Full Hybrid");

	private String type;

	private FuelType(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type;
	}

	public static FuelType valueOfLabel(String label) {
		for (FuelType t : FuelType.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}
		return null;
	}
}

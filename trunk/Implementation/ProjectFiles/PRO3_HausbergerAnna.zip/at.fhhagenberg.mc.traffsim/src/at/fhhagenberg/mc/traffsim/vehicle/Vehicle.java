package at.fhhagenberg.mc.traffsim.vehicle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicReference;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.statistics.events.IEventLog;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConsumptionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeDecision;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeFactory;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.Memory;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControl;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.PlatoonLongitudinalControl;

public class Vehicle implements Comparable<Vehicle> {
	public enum VehicleProperties {
		LANE_CHANGE_URGENCY, NO_LEFT_LANE_CHANGE_FOR_EXIT, NO_RIGHT_LANE_CHANGE, PENDING_MANDATORY_LANE_CHANGE,
		/**
		 * must change lane before segment end
		 */
		SLOW_DOWN_PERCENTAGE_DUE_TO_LANE_CHANGE
	}

	private static final long BLINKER_UPDATE_FREQUENCY_MS = 400;

	private static final int DETAILS_LINE_LENGTH = 20;

	private static long NEXT_ID = 0;

	public static boolean isObstacle(VehicleType type) {
		return type == VehicleType.OBSTACLE || type == VehicleType.OBSTRUCTION;
	}

	private Vector absolutePosition;

	private List<Behavior> behaviors;
	private BlinkerState blinkerState = BlinkerState.OFF;
	private FuelConsumptionModel consumptionModel;
	private double currentAcc;
	private List<Vector> currentBounds = CollectionUtil.createArrayList(new Vector(), new Vector(), new Vector(), new Vector());

	/** index 0: liter/s; index 1: liter/100km */
	private double[] currentFuelConsumption = new double[2];
	private double[] currentCarbonFootprint = new double[2];
	private double currentSpeed;
	private double drivingAngle;
	private double frontPosition;
	private double frontPositionOld;
	private double fuelConsumed;
	private double carbonFootprint;
	private double imposedAcc;
	private double inProcessOfLaneChange;
	private boolean isVehicleBehaviorControlled;
	private long timeInSimulation;

	/** Leader capability for platooning (special trained driver **/
	private boolean leaderCapability = false;

	/** Speed required to be reached in order to execute a control-trace behavior properly **/
	private double requiredTargetSpeed;

	/** vehicle controlling **/
	private boolean isVehicleControlledManually = false;

	private AtomicReference<AbstractJunction> junction = new AtomicReference<>();

	private String label;

	private LaneChangeModel laneChangeModel;

	private AtomicReference<VehiclesLane> laneSegment = new AtomicReference<>();

	private long lastBlinkerUpdate;

	private double length;

	private LongitudinalControl<?> longitudinalControl;

	private Memory memory;

	private AtomicReference<Behavior> nextBehavior = new AtomicReference<>();

	private AtomicReference<VehiclesLane> previousLaneSegment = new AtomicReference<>();

	private VehicleState prevState;

	private AtomicReference<RoadSegment> roadSegment = new AtomicReference<>();

	private IRoute route;

	private Date startTime;

	private VehicleState state;
	private double travelDistance;

	private VehicleType type;
	private final long uniqueId;
	private Set<IVehicleListener> vehicleListeners = new CopyOnWriteArraySet<>();
	private Properties vehicleProperties = new Properties();
	private boolean wasInvolvedInCollision;

	private double width;

	private long entryTime;

	boolean recordFuel = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_FUEL_CONSUMPTION);
	boolean recordCo2 = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_CARBON_EMISSIONS);

	private Date lastPositionUpdate;

	private long simulationInterval;

	protected IEventLog eventLog;

	public Vehicle(double position) {
		this(position, TrafficDefaults.DEFAULT_VEHICLE_LENGTH, TrafficDefaults.DEFAULT_VEHICLE_WIDTH, NEXT_ID++, VehicleType.CAR);
	}

	public Vehicle(double position, long id) {
		this(position, TrafficDefaults.DEFAULT_VEHICLE_LENGTH, TrafficDefaults.DEFAULT_VEHICLE_WIDTH, id, VehicleType.CAR);
	}

	public Vehicle(double position, double length, double width, long id, VehicleType type) {
		this.frontPosition = position;
		this.setType(type);
		this.setState(VehicleState.STOP);
		this.width = width;
		this.length = length;
		this.uniqueId = id;
		if (NEXT_ID <= id) {
			NEXT_ID = id + 1;
		}

		behaviors = new ArrayList<>();
	}

	public void setEventLog(IEventLog eventLog) {
		this.eventLog = eventLog;
	}

	public void addVehicleListener(IVehicleListener listener) {
		vehicleListeners.add(listener);
	}

	public void clearProperty(String key) {
		vehicleProperties.remove(key);
	}

	@Override
	public int compareTo(Vehicle o) {
		long otherId = o.getUniqueId();
		return uniqueId < otherId ? -1 : uniqueId == otherId ? 0 : 1;
	}

	public LaneChangeDecision considerLaneChange() {
		if (isObstacle()) {
			return LaneChangeFactory.decisionStayInLane();
		}

		return laneChangeModel.makeDecision();
	}

	public void setIsVehicleControlledManually(boolean control) {
		isVehicleControlledManually = control;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		Vehicle other = (Vehicle) obj;

		if (uniqueId != other.uniqueId) {
			return false;
		}

		return true;
	}

	public Vector getAbsolutePosition() {
		return absolutePosition;
	}

	public List<Behavior> getBehaviors() {
		return behaviors;
	}

	public BlinkerState getBlinkerState() {
		return blinkerState;
	}

	public List<Vector> getBoundsPolygon() {
		if (currentBounds != null) {
			return currentBounds;
		}

		return null;
	}

	public FuelConsumptionModel getConsumptionModel() {
		return consumptionModel;
	}

	public double getCurrentAcc() {
		return currentAcc;
	}

	/**
	 *
	 * @return the current fuel consumption, index 0: liter/s, index 1: liter/100km
	 */
	public double[] getCurrentFuelConsumption() {
		return currentFuelConsumption;
	}

	public double[] getCurrentCarbonFootprint() {
		return currentCarbonFootprint;
	}

	/**
	 *
	 * @return the current speed in meters per second (mps)
	 */
	public double getCurrentSpeed() {
		return currentSpeed;
	}

	public String getDetails() {
		StringBuffer details = new StringBuffer();
		details.append(String.format("ID %d\n", getUniqueId()));
		details.append(String.format("label: %s\n", getLabel()));
		details.append(String.format("routable: %s\n", isRoutable()));
		details.append(String.format("spd: %.2f (%.2f m/s)\n", getCurrentSpeed() * 3.6, getCurrentSpeed()));
		details.append(String.format("acc: %.3f\n", getCurrentAcc()));
		details.append(String.format("frontpos: %.3f\n", getFrontPosition()));
		details.append(String.format("lanechange: %.3f\n", getInProcessOfLaneChange()));
		details.append(String.format("spd target: %.3f\n", getTargetSpeed()));
		details.append(String.format("fuel: %.3f\n", fuelConsumed));
		details.append(String.format("co2: %.3f\n", carbonFootprint));
		double slope = roadSegment.get() != null ? roadSegment.get().getSlope() : 0;
		if (consumptionModel != null) {
			details.append(String.format("fuel/100km: %.3f\n", consumptionModel.getInstConsumption100km(currentSpeed, currentAcc, slope, true)));
		}
		StringBuffer route = new StringBuffer();
		int beforeCr = 0;
		if (this.route != null && this.route.getRouteIds().size() > 0) {
			for (Long i : this.route.getRouteIds()) {
				final int lenBef = route.length();
				route.append(i);
				route.append(",");
				beforeCr += route.length() - lenBef;
				if (beforeCr > DETAILS_LINE_LENGTH) {
					route.append("\n   ");
					beforeCr = 0;
				}
				if (route.length() > DETAILS_LINE_LENGTH * 5) {
					route.append(" ... ");
					break;
				}
			}
		} else {
			route.append("none ");
		}
		details.append("route: " + route.substring(0, route.length() - 1));
		return details.toString();
	}

	public double getDistanceToRoadSegmentEnd() {
		return laneSegment.get().getRoadLength() - getFrontPosition();
	}

	public double getDrivingAngle() {
		return drivingAngle;
	}

	public double getFrontPosition() {
		return frontPosition;
	}

	public double getFrontPositionOld() {
		return frontPositionOld;
	}

	public VehicleWithDistance getFrontVehicle() {
		if (getLaneSegment() != null) {
			return getLaneSegment().frontVehicle(this);
		}

		return null;
	}

	public double getFuelConsumed() {
		return fuelConsumed;
	}

	public double getCarbonFootprint() {
		return carbonFootprint;
	}

	public double getImposedAcc() {
		return imposedAcc;
	}

	public double getInProcessOfLaneChange() {
		return inProcessOfLaneChange;
	}

	public long getTimeInSimulation() {
		return timeInSimulation;
	}

	public AbstractJunction getJunction() {
		return junction.get();
	}

	public String getLabel() {
		return label == null ? "<empty>" : label;
	}

	private double getLaneChangeAngleCorrection(double inProcessOfLaneChange, double laneChangeTime, double currentSpeed) {
		double correction = 1;
		// determine factor of angle
		if (Math.abs(inProcessOfLaneChange) > TrafficDefaults.LANE_CHANGE_TIME / 2) {
			// we are in first half of lange change -> angle must increase
			// steady
			correction = Math.signum(inProcessOfLaneChange) * (Math.abs(inProcessOfLaneChange) - TrafficDefaults.LANE_CHANGE_TIME);
		} else {
			// second half of change -> angle decreases steadily
			correction = -(inProcessOfLaneChange / (TrafficDefaults.LANE_CHANGE_TIME / 2));
		}
		// multiply with angle, which is the reciprocal of the current speed in
		// m/s
		correction *= Math.min(Math.PI / 6, 1 / currentSpeed);
		return correction;
	}

	public LaneChangeModel getLaneChangeModel() {
		return laneChangeModel;
	}

	public int getLaneIndex() {
		return laneSegment.get().getLaneIndex();
	}

	public VehiclesLane getLaneSegment() {
		return laneSegment.get();
	}

	public double getLength() {
		return length;
	}

	public LongitudinalControl<?> getLongitudinalControl() {
		return longitudinalControl;
	}

	public Memory getMemory() {
		return memory;
	}

	public double getMidPosition() {
		return frontPosition - length / 2;
	}

	public double getMidPositionOld() {
		return frontPositionOld - length / 2;
	}

	public void setRequiredTargetSpeed(double requiredTargetSpeed) {
		this.requiredTargetSpeed = requiredTargetSpeed;
	}

	public VehicleState getPreviousState() {
		return prevState;
	}

	public String getProperty(String key) {
		return vehicleProperties.getProperty(key);
	}

	public double getRearPosition() {
		return frontPosition - length;
	}

	public double getRearPositionOld() {
		return frontPositionOld - length;
	}

	public RoadSegment getRoadSegment() {
		return roadSegment.get();
	}

	public IRoute getRoute() {
		return route;
	}

	public Date getStartTime() {
		return startTime;
	}

	public VehicleState getState() {
		return state;
	}

	public double getTargetSpeed() {
		return longitudinalControl.getLongitudinalModel().getModelData().getvTarget();
	}

	public double getTravelDistance() {
		return travelDistance;
	}

	public VehicleType getType() {
		return type;
	}

	public long getUniqueId() {
		return uniqueId;
	}

	public Properties getVehicleProperties() {
		return vehicleProperties;
	}

	public boolean getWasInvolvedInCollision() {
		return wasInvolvedInCollision;
	}

	public double getWidth() {
		return width;
	}

	public boolean hasBoundsPolygon() {
		return currentBounds != null && absolutePosition != null;
	}

	@Override
	public int hashCode() {
		final long prime = 31;
		long result = 1;
		result = prime * result + uniqueId;
		return (int) result;
	}

	public boolean hasRoute() {
		return route != null && route.getNextRoutingId() != -1;
	}

	public boolean isVehicleBehaviorControlled() {
		return isVehicleBehaviorControlled;
	}

	public boolean isVehicleControlledManually() {
		return isVehicleControlledManually;
	}

	public boolean isVehiclePlatoonControlled() {
		return getLongitudinalControl() instanceof PlatoonLongitudinalControl
				&& ((PlatoonLongitudinalControl) getLongitudinalControl()).getPlatoon() != null;
	}

	public boolean hasLeaderCapability() {
		return leaderCapability;
	}

	public void setLeaderCapability(boolean leaderCapability) {
		this.leaderCapability = leaderCapability;
	}

	public boolean isInJunction() {
		return getLaneSegment() instanceof JunctionConnector;
	}

	public boolean isInProcessOfLaneChange() {
		return inProcessOfLaneChange != 0;
	}

	public boolean isObstacle() {
		return Vehicle.isObstacle(type);
	}

	/**
	 * Determines whether or not a vehicle is enabled for V2X communication
	 *
	 * @return <code>true</code> if the vehicle has routing capabilitiess
	 */
	public boolean isRoutable() {
		return false;
	}

	private void notifyChangedLane(VehiclesLane oldLane, VehiclesLane newLane) {
		if (oldLane != null && !oldLane.equals(newLane)) {
			for (IVehicleListener listener : vehicleListeners) {
				listener.vehicleChangedLaneSegment(this, oldLane, newLane);
			}
		}
	}

	public void onVehicleDistracted(double duration, boolean isSevere) {
		for (IVehicleListener listener : vehicleListeners) {
			listener.onDriverDistracted(uniqueId, isSevere, duration);
		}
	}

	public void notifyListenersVehicleLeft() {
		notifyListenersVehicleLeft(null);
	}

	public void notifyListenersVehicleLeft(Date timeLeft) {
		/**
		 * correct already added values by subtracting the percentage of progress that was not really driven by this vehicle. <br>
		 * Example: The simulation time step is 50 ms, so the time of 50 ms and the distance travelled within these 50 ms was already added
		 * to the corresponding variables. When an outflow is detected, the frontposition is larger than the current road length, what means
		 * that the vehicle was not on the road any more for a part of the added distance and time. Thus, a correction is needed here.
		 */
		double distanceAfterSegmentEnd = frontPosition - laneSegment.get().getRoadLength();
		/* vehicle left by exceeding last lane segment's length */
		double percentageAfterEnd = 0;
		if (distanceAfterSegmentEnd > 0) {
			double lastTravelDist = frontPosition - frontPositionOld;
			travelDistance -= distanceAfterSegmentEnd;
			timeInSimulation -= (distanceAfterSegmentEnd / currentSpeed) * 1000;
			percentageAfterEnd = distanceAfterSegmentEnd / lastTravelDist;
		}
		/* vehicle left simulation manually - correct time */
		if (timeLeft != null) {
			long diff = timeLeft.getTime() - lastPositionUpdate.getTime();
			percentageAfterEnd = diff / simulationInterval;
		}
		fuelConsumed -= currentFuelConsumption[0] * percentageAfterEnd;
		carbonFootprint -= currentCarbonFootprint[0] * percentageAfterEnd;

		// listener notifications
		for (IVehicleListener listener : vehicleListeners) {
			listener.vehicleLeftSimulation(this);
		}
		for (IVehicleListener listener : vehicleListeners) {
			listener.postLeftSimulation(this);
		}
	}

	public void notifyListenersVehicleEntered() {
		for (IVehicleListener listener : vehicleListeners) {
			listener.vehicleEntered(this);
		}
	}

	public void removeVehicleListener(IVehicleListener listener) {
		vehicleListeners.remove(listener);
	}

	public void resetProcessOfLaneChange() {
		inProcessOfLaneChange = 0;
	}

	public void setBehaviors(List<Behavior> behaviors) {
		Collections.sort(behaviors);
		this.behaviors = behaviors;

		if (this.behaviors.isEmpty()) {
			nextBehavior.set(null);
		} else {
			nextBehavior.set(this.behaviors.remove(0));
		}
	}

	public Behavior getNextBehavior() {
		return nextBehavior.get();
	}

	public void switchToNextBehavior() {
		Behavior next = behaviors.size() > 0 ? behaviors.remove(0) : null;
		nextBehavior.set(next);
	}

	public void setBlinkerState(BlinkerState blinkerState) {
		if (!this.blinkerState.name().startsWith(blinkerState.name())) {
			this.blinkerState = blinkerState;
		}
	}

	public void setConsumptionModel(FuelConsumptionModel consumptionModel) {
		this.consumptionModel = consumptionModel;
	}

	public void setCurrentSpeed(double currentSpeed) {
		this.currentSpeed = currentSpeed;
	}

	public void setFrontPosition(double position) {
		this.frontPosition = position;
	}

	public void setImposedAcc(double imposedAcc) {
		this.imposedAcc = imposedAcc;
	}

	public void setInProcessOfLaneChange(double inProcessOfLaneChange) {
		this.inProcessOfLaneChange = inProcessOfLaneChange;
	}

	public void setIsVehicleBehaviorControlled(boolean isBehaviorControlled) {
		this.isVehicleBehaviorControlled = isBehaviorControlled;
	}

	public void setJunction(AbstractJunction junction) {
		this.junction.set(junction);
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public void setLane(int index) {
		VehiclesLane oldLane = laneSegment.get();
		laneSegment.set(roadSegment.get().getLaneSegments().get(index));
		notifyChangedLane(oldLane, laneSegment.get());
	}

	public void setLaneChangeModel(LaneChangeModel laneChangeModel) {
		if (laneChangeModel != null) {
			this.laneChangeModel = laneChangeModel.copyForVehicle(this);
		}
	}

	public void setLaneSegment(VehiclesLane laneSegment) {
		previousLaneSegment.set(this.laneSegment.getAndSet(laneSegment));
		notifyChangedLane(previousLaneSegment.get(), laneSegment);
	}

	public void setLength(double length) {
		this.length = length;
	}

	public void setLongitudinalControl(LongitudinalControl<?> longControl) {
		this.longitudinalControl = longControl;
	}

	public void setMemory(Memory memory) {
		this.memory = memory;
	}

	public void setProperty(String key, String value) {
		vehicleProperties.setProperty(key, value);
	}

	public void setRoadSegment(RoadSegment roadSegment) {
		this.roadSegment.set(roadSegment);
	}

	public boolean setRoute(IRoute route) {
		for (IVehicleListener listener : vehicleListeners) {
			if (listener instanceof IVehicleRouteListener) {
				((IVehicleRouteListener) listener).routeUpdated(this, RoadUtil.getNextRoadSegment(laneSegment.get()), this.route, route);
			}
		}
		if (this.route != null && route != null && this.route.getNextRoutingId() != route.getNextRoutingId()) {
			blinkerState = BlinkerState.OFF;
		}
		this.route = route;
		return true;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
		lastPositionUpdate = startTime;
	}

	public void setEntryTime(long entryTime) {
		this.entryTime = entryTime;
	}

	public long getEntryTime() {
		return entryTime;
	}

	public void setState(VehicleState state) {
		if (!isObstacle()) {
			this.prevState = this.state;
			this.state = state;
		}
	}

	public void setType(VehicleType type) {
		this.type = type;
	}

	public void setVehicleProperties(Properties vehicleProperties) {
		this.vehicleProperties = vehicleProperties;
	}

	public void setWasInvolvedInCollision(boolean wasInvolvedInCollision) {
		this.wasInvolvedInCollision = wasInvolvedInCollision;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	@Override
	public String toString() {
		return getUniqueId() + " acc: " + getCurrentAcc() + " spd: " + getCurrentSpeed() + " lbl:" + label + " pos: " + frontPosition + "\n";
	}

	public void updateAcceleration(double dt, double simulationTime) {
		if (isObstacle()) {
			return;
		}

		double alphaTLocal = 1;
		double alphaV0Local = 1;
		double alphaALocal = 1;

		/** Update the memory **/
		if (memory != null) {
			final double v0 = longitudinalControl.getLongitudinalModel().getModelData().getvTarget();
			memory.update(dt, currentSpeed, v0);
			alphaTLocal *= memory.alphaT();
			alphaV0Local *= memory.alphaV0();
			alphaALocal *= memory.alphaA();
		}

		longitudinalControl.update(dt, simulationTime);

		currentAcc = isVehicleControlledManually ? imposedAcc
				: longitudinalControl.calcAccComprehensive(this, alphaTLocal, alphaV0Local, alphaALocal);

		assert currentAcc <= longitudinalControl.getLongitudinalModel().getModelData().getMaxAcc() : "Acceleration of vehicle " + getLabel()
				+ " too high (a = " + currentAcc + ")";
		assert currentAcc >= longitudinalControl.getLongitudinalModel().getModelData().getMaxDec() : "Acceleration of vehicle " + getLabel()
				+ " too low (a = " + currentAcc + ")";
	}

	public void updateGeometry() {
		VehiclesLane sourceLane = null;
		Vector newAbsolutePosition = null;
		VehiclesLane laneSeg = laneSegment.get();
		if (laneSeg == null) {
			/*
			 * could happen because addVehicle in LaneSegment first adds the vehicle to its collection of vehicles, and then sets the
			 * lanesegment of the vehicle. If VehicleProcessor calls updateGeometry between these calls, the laneSegment may still be null
			 * here.
			 */
			return;
		}
		sourceLane = previousLaneSegment.get() != null && previousLaneSegment.get().getRoadSegment() != laneSeg.getRoadSegment()
				? previousLaneSegment.get() : laneSeg.getSourceLaneSegment();
		RoadGeometry geom = laneSeg.getRoadGeometry();
		double midPosition = getMidPosition();
		if (midPosition < 0 && sourceLane != null) {
			geom = sourceLane.getRoadGeometry();
			midPosition = geom.getRoadLength() + getMidPosition();
		}

		newAbsolutePosition = geom.mapPosition(midPosition, laneSeg.getLaneWidth() * getInProcessOfLaneChange() / TrafficDefaults.LANE_CHANGE_TIME,
				laneSeg, this);
		if (newAbsolutePosition == null) {
			// ignore position errors if vehicle is about to leave simulation
			if (!getRoute().getRouteIds().isEmpty()) {
				Logger.logWarn(String.format("Vehicle %d: Could not map position %.3f not current segment %d (RS %d)", uniqueId, midPosition,
						laneSeg.getId(), laneSeg.getRoadSegment().getId()));
				return;
			}
		} else {
			absolutePosition = newAbsolutePosition;
		}

		double[] angles = new double[5];
		for (int k = 1; k <= angles.length; k++) {
			angles[k - 1] = SpatialUtil.angleAtPosition(this, this.getFrontPosition() - this.getLength() / (angles.length + 1) * k, sourceLane);
		}

		drivingAngle = NumberUtil.averageAngle(angles)
				+ getLaneChangeAngleCorrection(this.getInProcessOfLaneChange(), TrafficDefaults.LANE_CHANGE_TIME, this.getCurrentSpeed());

		currentBounds = VehicleFactory.updateCarBounds(absolutePosition, drivingAngle, length, width, currentBounds);
	}

	public void updateSpeedAndPosition(double dt, Date time) {
		// The postition of an obstacle does not change
		if (isObstacle()) {
			return;
		}
		simulationInterval = (long) (dt * 1000);
		timeInSimulation += simulationInterval;
		if (inProcessOfLaneChange > 0) {
			inProcessOfLaneChange = Math.max(0, inProcessOfLaneChange - dt);
		} else if (inProcessOfLaneChange < 0) {
			inProcessOfLaneChange = Math.min(0, inProcessOfLaneChange + dt);
		}

		long now = new Date().getTime();

		// Update blinker state
		if (now - lastBlinkerUpdate > BLINKER_UPDATE_FREQUENCY_MS || lastBlinkerUpdate == 0) {
			switch (blinkerState) {
			case LEFT:
				blinkerState = BlinkerState.LEFT_OFF;
				break;
			case LEFT_OFF:
				blinkerState = BlinkerState.LEFT;
				break;
			case RIGHT:
				blinkerState = BlinkerState.RIGHT_OFF;
				break;
			case RIGHT_OFF:
				blinkerState = BlinkerState.RIGHT;
				break;
			case WARN:
				blinkerState = BlinkerState.WARN_OFF;
				break;
			case WARN_OFF:
				blinkerState = BlinkerState.WARN;
				break;
			default:
				blinkerState = BlinkerState.OFF;
				break;
			}

			lastBlinkerUpdate = now;
		}

		// Update speed
		if (requiredTargetSpeed > 0 && !isVehicleBehaviorControlled) {
			/** If a trace behavior is going to be executed the required target speed is maintained until the behavior starts to execute **/
			currentSpeed = requiredTargetSpeed;
		} else {
			currentSpeed = Math.max(0, currentSpeed + currentAcc * dt);
		}

		VehicleState st = VehicleState.STEADY;

		// Update the vehicle's state
		if (currentAcc > 0.01 && !NumberUtil.doubleEquals(currentSpeed, 0, 0.02)) {
			st = VehicleState.ACCELERATION;
		} else if (currentAcc < -0.01 && !NumberUtil.doubleEquals(currentSpeed, 0, 0.02)) {
			st = VehicleState.DECELERATION;
		} else if (NumberUtil.doubleEquals(currentSpeed, 0, 0.02) && (NumberUtil.doubleEquals(currentAcc, 0, 0.01) || currentAcc < 0)) {
			st = VehicleState.STOP;
		}

		setState(st);

		// Update position
		double propagation = currentSpeed * dt;
		frontPositionOld = frontPosition;
		frontPosition += propagation;
		travelDistance += propagation;
		lastPositionUpdate = time;
		// Update connsumed fuel
		if (consumptionModel != null && (recordFuel || recordCo2)) {
			double slope = roadSegment.get() == null ? 0 : roadSegment.get().getSlope(); // road segment may be null initially
			if (recordFuel) {
				currentFuelConsumption = consumptionModel.getMultipleFuelFlow(currentSpeed, currentAcc, slope);
				fuelConsumed += currentFuelConsumption[0] * dt;
			}
			if (recordCo2) {
				currentCarbonFootprint = consumptionModel.getMultipleCo2Emissions(currentSpeed, currentFuelConsumption[0]);
				carbonFootprint += currentCarbonFootprint[0] * dt;
			}
		}
		updateGeometry();
	}

	public Vector getDrivingDirectionVector() {
		return currentBounds != null ? currentBounds.get(0).minus(currentBounds.get(1)) : new Vector();
	}
}
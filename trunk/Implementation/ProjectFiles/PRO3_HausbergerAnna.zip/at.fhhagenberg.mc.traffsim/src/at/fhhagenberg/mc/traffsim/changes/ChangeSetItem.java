package at.fhhagenberg.mc.traffsim.changes;

import java.util.Date;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import at.fhhagenberg.mc.util.DateUtil;

@XStreamAlias("item")
public class ChangeSetItem {
	public static String AFFECTED_PATH_BULLET = "\u2192";

	Date date;
	String msg;
	private String authorEmail;
	private String id;
	private ChangeAuthor author;
	@XStreamImplicit
	private List<String> affectedPath;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		String trimmedMsg = msg.replace('\n', ' ').replace('\r', ' ').replaceAll("\\s+", " ");
		String commitId = id!=null?" (commit " + id + ")":"";
		StringBuffer str = new StringBuffer(
				DateUtil.format(date) + "   " + trimmedMsg + " by " + author.getFullName() + commitId);
		for (String ap : this.affectedPath) {
			int start = ap.lastIndexOf('/') + 1;
			int end = ap.lastIndexOf('.');
			if (start < end) {
				str.append("\n          ");
				str.append(AFFECTED_PATH_BULLET);
				str.append(" ");
				str.append(ap.substring(ap.lastIndexOf('/') + 1, ap.lastIndexOf('.')));
			}
		}
		return str.toString();
	}

	public List<String> getAffectedPath() {
		return affectedPath;
	}

	public void setAffectedPath(List<String> affectedPath) {
		this.affectedPath = affectedPath;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAuthorEmail() {
		return authorEmail;
	}

	public void setAuthorEmail(String authorEmail) {
		this.authorEmail = authorEmail;
	}

	public ChangeAuthor getAuthor() {
		return author;
	}

	public void setAuthor(ChangeAuthor author) {
		this.author = author;
	}

}

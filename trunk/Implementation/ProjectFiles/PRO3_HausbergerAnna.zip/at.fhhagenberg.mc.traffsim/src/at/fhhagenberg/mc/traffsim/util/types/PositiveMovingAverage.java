package at.fhhagenberg.mc.traffsim.util.types;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Utility class implementing a (positive) moving average
 *
 * @author Christian Backfrieder
 */
public class PositiveMovingAverage {

	/** The current moving average */
	private double average = 0;

	/** The number of values to consider for the moving average */
	private int length;

	/** The sum of values considered for the moving average */
	private double sum = 0;

	/** The list of values considered for the moving average */
	private Queue<Double> values = new ConcurrentLinkedQueue<Double>();

	/**
	 * Creates a new moving average of the given length.
	 *
	 * @param length
	 *            the max. number of values to consider for the moving average
	 */
	public PositiveMovingAverage(int length) {
		if (length <= 0) {
			throw new IllegalArgumentException("length must be greater than zero");
		}

		this.length = length;
	}

	/**
	 * Adds a new value to the list and computes the moving average. Synchronized so that no changes in the underlying data are made during
	 * calculation.
	 *
	 * @param value
	 *            the new value to be added to the list
	 * @return the resulting moving average
	 */
	public synchronized double addValue(double value) {
		while (values.size() >= length && length > 0) {
			sum -= values.poll();
		}

		sum = Math.max(sum + value, 0);
		values.offer(new Double(value));
		average = sum / values.size();
		return average;
	}

	/**
	 * The current moving average.
	 *
	 * @return the moving average
	 */
	public double currentAverage() {
		return average;
	}
}
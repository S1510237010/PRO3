package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

public class ACCData extends IDMData {
	private static final String IDENTIFIER = "ACC";

	/** The coolness of the driver, in a range from */
	private double coolness;

	public ACCData() {
		setIdentifier(IDENTIFIER);
	}

	public ACCData(double vTarget, double sMin, double tMin, double comfortableAcc, double safeDec, double maxAcc, double maxDec,
			double delta, double coolness) {
		super(vTarget, sMin, tMin, comfortableAcc, safeDec, maxAcc, maxDec, delta);
		setCoolness(coolness);
		setIdentifier(IDENTIFIER);
	}

	public double getCoolness() {
		return coolness;
	}

	public void setCoolness(double coolness) {
		this.coolness = coolness;
	}
}
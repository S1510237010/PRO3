package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.roadsign;

import org.eclipse.jface.wizard.Wizard;

import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.roadsign.RoadSignParameterPage.GenerationParameters;

public class RoadSignGeneratorWizard extends Wizard {

	private RoadSignParameterPage roadSignParameterPage;
	private GenerationParameters generationParameters;

	public RoadSignGeneratorWizard() {
		setWindowTitle("Road Sign Generation");
		roadSignParameterPage = new RoadSignParameterPage("Road Sign Generation");
	}

	@Override
	public void addPages() {
		addPage(roadSignParameterPage);
	}

	@Override
	public boolean canFinish() {
		return roadSignParameterPage.isPageComplete();
	}

	@Override
	public boolean performFinish() {
		generationParameters = roadSignParameterPage.getResult();
		return true;
	}

	public GenerationParameters getGenerationParameters() {
		return generationParameters;
	}

}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers;

import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;

/**
 * Dynamic reaction time model enabling smooth transitions between different
 * reaction times when switching between driving regimes.
 *
 * @author Manuel Lindorfer
 *
 */
public class DynamicReactionTimeModel {

	/**
	 * Enumeration describing in which way transitions between two reaction
	 * times are modeled. HARSH: jump from one to another. INCREMENTAL:
	 * step-wise transition by moving the history buffer back and forth. SMOOTH:
	 * the transition is modeled using a smooth step function
	 */
	public enum ReactionTimeTransition {
		/**
		 * Approach the new target response time by immediately switching to it
		 */
		HARSH, /**
		 * Approach the new target response time in a step-wise fashion
		 */
		INCREMENTAL, /**
		 * Approach the new target response time using a smoothed
		 * step function
		 */
		SMOOTH
	}

	/** Flag indicating whether the reaction time model is initialized or not */
	private boolean isInitialized;

	/** The current reaction time */
	private double rtCurrent;

	/**
	 * The initial reaction time; corresponds to rtCurrent at the time a new
	 * target response time is set
	 */
	private double rtInitial;

	/**
	 * The intermediate reaction time originating from applying a smooth step
	 * function
	 */
	private double rtSmoothStep;

	/** The target reaction time to be approached */
	private double rtTarget;

	/**
	 * A transition factor for regulating the "smoothness" of the performed
	 * transition
	 */
	private double transitionFactor;

	/** The transition type used by the model */
	private ReactionTimeTransition transitionType;

	/**
	 * Instantiates a new dynamic reaction time model with default values.
	 */
	public DynamicReactionTimeModel() {
		this.rtCurrent = 0;
		this.rtTarget = 0;
		this.transitionFactor = 1.0;
		this.transitionType = ReactionTimeTransition.HARSH;
		this.isInitialized = false;
	}

	/**
	 * Instantiates a new dynamic reaction time model with the given transition
	 * type and factor.
	 *
	 * @param transitionType
	 *            the transition type to be used by the model
	 * @param transitionFactor
	 *            the transition factor to regulate the transitions' smoothness
	 */
	public DynamicReactionTimeModel(ReactionTimeTransition transitionType, double transitionFactor) {
		this.rtCurrent = 0;
		this.rtTarget = 0;
		this.transitionType = transitionType;
		this.transitionFactor = transitionFactor;
		this.isInitialized = false;
	}

	/**
	 * Gets the current reaction time.
	 *
	 * @return the current reaction time
	 */
	public double getCurrentReactionTime() {
		return rtCurrent;
	}

	/**
	 * Gets whether the reaction time model is initialized or not.
	 *
	 * @return true if setCurrentReactionTime or setTargetReactionTime have been
	 *         called once - false else
	 */
	public boolean getIsInitialized() {
		return isInitialized;
	}

	/**
	 * Gets the target reaction time.
	 *
	 * @return the target reaction time
	 */
	public double getTargetReactionTime() {
		return rtTarget;
	}

	/**
	 * Gets the transition type.
	 *
	 * @return the transition type
	 */
	public ReactionTimeTransition getTransitionType() {
		return transitionType;
	}

	/**
	 * Sets the current reaction time.
	 *
	 * @param rtCurrent
	 *            the new current reaction time
	 */
	public void setCurrentReactionTime(double rtCurrent) {
		this.rtCurrent = rtCurrent;
		this.isInitialized = true;
	}

	/**
	 * Sets the target reaction time.
	 *
	 * @param rtTarget
	 *            the new target reaction time
	 */
	public void setTargetReactionTime(double rtTarget) {
		this.rtTarget = rtTarget;
		this.rtInitial = rtCurrent;
		this.rtSmoothStep = Double.MAX_VALUE;
		this.isInitialized = true;
	}

	public void setTransitionType(ReactionTimeTransition transitionType) {
		this.transitionType = transitionType;
	}

	/**
	 * Updates the distraction based on the given time-interval. In every
	 * simulation time step the target reaction time is approached from the
	 * current one using the underlying transition type and factor.
	 *
	 * @param dt
	 *            the simulation time step [s]
	 */
	public void update(double dt) {
		if (!NumberUtil.doubleEquals(rtTarget, rtCurrent)) {
			switch (transitionType) {
			case HARSH:
				rtCurrent = rtTarget;
				break;
			case INCREMENTAL:
				if (rtCurrent > rtTarget) {
					// Reaction time decreases
					if (rtCurrent - transitionFactor * dt <= rtTarget) {
						rtCurrent = rtTarget;
					} else {
						rtCurrent -= transitionFactor * dt;
					}
				} else {
					// Reaction time increases
					if (rtCurrent + transitionFactor * dt >= rtTarget) {
						rtCurrent = rtTarget;
					} else {
						rtCurrent += transitionFactor * dt;
					}
				}
				break;
			case SMOOTH:
				double leftEdge = Math.min(rtInitial, rtTarget);
				double rightEdge = Math.max(rtInitial, rtTarget);

				if (rtSmoothStep == Double.MAX_VALUE) {
					rtSmoothStep = leftEdge;
					double rtDiff = Math.abs(rightEdge - leftEdge) * transitionFactor;
					rightEdge = leftEdge + rtDiff;
				}

				rtSmoothStep += dt / transitionFactor;

				double smoothStep = MathUtil.getSmoothStep(leftEdge, rightEdge, rtSmoothStep);

				if (rtCurrent > rtTarget) {
					// Reaction time decreases
					if (rtInitial - smoothStep * Math.abs(rtInitial - rtTarget) <= rtTarget) {
						rtCurrent = rtTarget;
					} else {
						rtCurrent = rtInitial - smoothStep * Math.abs(rtInitial - rtTarget);
					}
				} else {
					// Reaction time increases
					if (rtInitial + smoothStep * Math.abs(rtInitial - rtTarget) >= rtTarget) {
						rtCurrent = rtTarget;
					} else {
						rtCurrent = rtInitial + smoothStep * Math.abs(rtInitial - rtTarget);
					}
				}
				break;
			default:
				break;
			}
		}
	}
}

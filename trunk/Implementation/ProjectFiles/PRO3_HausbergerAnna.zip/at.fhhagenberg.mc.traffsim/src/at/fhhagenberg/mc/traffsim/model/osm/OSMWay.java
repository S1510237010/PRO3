package at.fhhagenberg.mc.traffsim.model.osm;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

/**
 * Implementation of an {@link OSMWay}. A way consists of an unique identifier,
 * a specific set of OSM nodes and may contain a certain number of additional
 * parameter tags.
 *
 * @author Manuel Lindorfer
 *
 */
public class OSMWay {

	/** The way's unique identifier */
	private long id;

	/** The set of nodes describing the way's geometry */
	private ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();

	/** The tags for this way as key-value-pairs */
	private Map<String, String> tags = new Hashtable<String, String>();

	/** The way's (OSM) version */
	private String version;

	/**
	 * Creates a new {@link OSMWay} with the given unique identifier.
	 *
	 * @param id
	 *            the way's unique identifier
	 */
	public OSMWay(long id) {
		this.id = id;
	}

	/**
	 * Adds a new {@link OSMNode} to the way.
	 *
	 * @param n
	 *            the new node to be added
	 */
	public void addNode(OSMNode n) {
		if (n != null) {
			nodes.add(n);
		}
	}

	/**
	 * Get's the way's unique identifier.
	 *
	 * @return the way's unique identifier
	 */
	public long getId() {
		return id;
	}

	/**
	 * Get's the value of the way's <i>lanes:backward</i> tag.
	 *
	 * @return the way's <i>lanes:backward</i> tag
	 */
	public String getLanesBackward() {
		return getTags().get("lanes:backward");
	}

	/**
	 * Get's the value of the way's <i>lanes:forward</i> tag.
	 *
	 * @return the way's <i>lanes:forward</i> tag
	 */
	public String getLanesForward() {
		return getTags().get("lanes:forward");
	}

	/**
	 * Get's the value of the way's <i>name</i> tag.
	 *
	 * @return the way's <i>name</i> tag
	 */
	public String getName() {
		return getTags().get("name");
	}

	/**
	 * Get's a list of all {@link OSMNode}s associated with this way.
	 *
	 * @return a list of all {@link OSMNode}s being part of the way
	 */
	public ArrayList<OSMNode> getNodes() {
		return nodes;
	}

	/**
	 * Get's the value of the way's <i>maxspeed</i> tag.
	 *
	 * @return the way's <i>maxspeed</i> tag
	 */
	public String getSpeedLimit() {
		return getTags().get("maxspeed");
	}

	/**
	 * Get's the set of additional tags of this way.
	 *
	 * @return the set of tags
	 */
	public Map<String, String> getTags() {
		return tags;
	}

	/**
	 * Get's the value of the way's <i>highway</i> tag.
	 *
	 * @return the way's <i>highway</i> tag
	 */
	public String getTypeName() {
		return getTags().get("highway");
	}

	/**
	 * Get's the way's (OSM) version.
	 *
	 * @return the way's (OSM) version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Determines whether the way is a highway or not.
	 *
	 * @return true if the way is a highway - false else
	 */
	public boolean isHighway() {
		String str = getTags().get("highway");

		if (str == null) {
			return false;
		}

		return str.compareTo("primary") == 0 || str.compareTo("secondary") == 0 || str.compareTo("residential") == 0
				|| str.compareTo("tertiary") == 0 || str.compareTo("unclassified") == 0;
	}

	/**
	 * Determines whether the way is one-way or not.
	 *
	 * @return true if the way is one-way - false else
	 */
	public boolean isOneWay() {
		String str = getTags().get("oneway");

		if (str == null) {
			return false;
		}

		return str.compareTo("yes") == 0;
	}

	/**
	 * Returns a string representation of the way.
	 *
	 * @return a string representation of the way
	 */
	public String key() {
		return "way_" + id;
	}

	/**
	 * Updates the way tag identified by the given key with the given value.
	 *
	 * @param key
	 *            the key identifying the tag to be updated
	 * @param value
	 *            the new tag value
	 */
	public void putTag(String key, String value) {
		tags.put(key, value);
	}

	/**
	 * Set's the set of additional tags of this way.
	 *
	 * @param _tags
	 *            the new tags for this way
	 */
	public void setTags(Map<String, String> _tags) {
		tags = _tags;
	}

	/**
	 * Set's the way's (OSM) version.
	 *
	 * @param _version
	 *            the new (OSM) version
	 */
	public void setVersion(String _version) {
		version = _version;
	}

	@Override
	public String toString() {
		return "[Way " + id + "]";
	}
}
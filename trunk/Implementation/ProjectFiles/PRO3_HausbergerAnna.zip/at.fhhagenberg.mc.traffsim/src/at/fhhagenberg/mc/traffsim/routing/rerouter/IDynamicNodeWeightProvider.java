package at.fhhagenberg.mc.traffsim.routing.rerouter;

public interface IDynamicNodeWeightProvider {
	public double getNodeWeight(long nodeId, double delaySeconds);
}

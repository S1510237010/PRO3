package at.fhhagenberg.mc.traffsim.util.exceptions;

/**
 * This exception type can be used to handle exceptions originating from merging multiple junctions into a single one containing all
 * relevant connectors.
 *
 * @author Christian Backfrieder
 */
public class MergeException extends Exception {

	/** Unique identifier for serialization */
	private static final long serialVersionUID = 246581881602359312L;

	/**
	 * Creates a new MergeException with the given message and exception.
	 *
	 * @param message
	 *            the exception message
	 * @param e
	 *            the exception causing this MergeException
	 */
	public MergeException(String message, Exception e) {
		super(message, e);
	}
}

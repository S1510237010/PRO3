package at.fhhagenberg.mc.traffsim.vehicle;

public enum VehicleState {
	ACCELERATION, DECELERATION, STEADY, STOP
}

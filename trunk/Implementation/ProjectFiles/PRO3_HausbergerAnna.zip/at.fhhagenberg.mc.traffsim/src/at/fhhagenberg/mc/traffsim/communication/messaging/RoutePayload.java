package at.fhhagenberg.mc.traffsim.communication.messaging;

import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;

public class RoutePayload extends PositionPayload {
	IRoute route;

	public RoutePayload(Location position, IRoute newRoute, VehiclesLane lane) {
		super(position, lane);
		super.lane = lane;
		this.route = newRoute;
	}

	@Override
	public int getSize() {
		// length of route + route id
		return Long.BYTES * (route.getRouteIds().size() + 1) + super.getSize();
	}

	public IRoute getRoute() {
		return route;
	}
}

package at.fhhagenberg.mc.traffsim.statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;

public abstract class TrafficControllerStatisticsData implements Serializable {

	private static final long serialVersionUID = 7630408927145231445L;

	protected final long controllerId;
	protected final long junctionId;

	protected List<Double> time = new ArrayList<>();

	protected long recordedItems;

	public TrafficControllerStatisticsData() {
		controllerId = -1;
		junctionId = -1;
	}

	public TrafficControllerStatisticsData(long controllerId, long junctionId) {
		this.controllerId = controllerId;
		this.junctionId = junctionId;
	}

	public long getControllerId() {
		return controllerId;
	}

	public long getJunctionId() {
		return junctionId;
	}

	public List<Double> getTime() {
		return time;
	}

	public abstract void addData(double time, TrafficLightController<?> controller);

	public abstract TrafficControllerStatisticsData collectData(int numItemsToKeep);
}

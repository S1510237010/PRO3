package at.fhhagenberg.mc.traffsim.routing;

import java.io.File;
import java.util.Set;

import at.fhhagenberg.mc.traffsim.roadnetwork.Node;

public class DefaultRouteService extends AbstractMultithreadedRouteService {

	public DefaultRouteService(File graphFile, Set<Long> removedRoutingIds) {
		super(graphFile, removedRoutingIds);
	}

	@Override
	public SimpleRouteResult findRoute(Node sourceNode, Node targetNode) {
		return findSingleRoute(sourceNode, targetNode);
	}
}

package at.fhhagenberg.mc.traffsim.ui;

import java.awt.Dimension;

public abstract class Constants {

	public static final String EMPTY_STRING = "";
	public static final String NEW_LINE = System.getProperty("line.separator");

	public static int MIN_ZOOMRECT_SIZE = 10;
	public static int MATRIX_SIZE = 3;

	// /////////////////////////////////
	/** general constants for the GisClient application */
	public static final int SCROLL_DELTA = 20;
	public static final double ZOOM_FACTOR = 1.3;

	/** constants for identifying the gui components for listener notifications */
	public static final String ACTION_LOAD_DATA = "ACTION_LOAD_DATA";
	public static final String ACTION_SCROLL_UP = "ACTION_SCROLL_UP";
	public static final String ACTION_SCROLL_DOWN = "ACTION_SCROLL_DOWN";
	public static final String ACTION_SCROLL_LEFT = "ACTION_SCROLL_LEFT";
	public static final String ACTION_SCROLL_RIGHT = "ACTION_SCROLL_RIGHT";
	public static final String ACTION_ZOOM_IN = "ACTION_ZOOM_IN";
	public static final String ACTION_ZOOM_OUT = "ACTION_ZOOM_OUT";
	public static final String ACTION_ZOOM_TO_FIT = "ACTION_ZOOM_TO_FIT";
	public static final String BUTTON_NAME_SELECT = "BUTTON_NAME_SELECT";
	public static final String BUTTON_NAME_DRAG = "BUTTON_NAME_DRAG";
	public static final String BUTTON_NAME_ZOOM = "BUTTON_NAME_ZOOM";
	public static final String FIELD_SCALE = "FIELD_SCALE";
	public static final String ACTION_SHOW_SDE_POIS = "ACTION_SHOW_SDE_POIS";
	public static final String ACTION_SHOW_POIS = "ACTION_SHOW_POIS";
	public static final String ACTION_STORE_IMAGE = "ACTION_STORE_IMAGE";
	public static final String ACTION_IMAGE_TYPE = "ACTION_IMAGE_TYPE";
	public static final String ACTION_STICKY = "ACTION_STICKY";

	/** constants for mouse state */
	public static final int MOUSE_STATE_SELECT = 0;
	public static final int MOUSE_STATE_DRAG = 1;
	public static final int MOUSE_STATE_ZOOM = 2;
	public static final int INITIAL_MOUSE_STATE = MOUSE_STATE_DRAG;

	public static final String SCALE_PREFIX = "1 : ";
	public static final String SCALE_UNKNOWN = SCALE_PREFIX + "unknown";
	public static final char ENTER_KEY = '\n';
	public static final int POI_TYPE = 99999;

	/** log messages */
	public static final String LOG_ERROR = "ERROR: ";
	public static final String LOG_WARNING = "WARNING: ";
	public static final String LOG_INFO = "INFO: ";

	/** map */
	public static final double WGS84_CORRECTURE_FACTOR = 1000;

	/** file structure */
	public static final String IMG_FOLDER = "img";

	public static final String FILE_SERIALIZED_GEO_OBJECTS = "geoobjects.ser";
	public static final String FILE_SERIALIZED_POIS = "pois.ser";

	public static final String FILE_GIS_RULES = "xml/GISRules.xml";

	public static final Dimension INITIAL_SIZE = new Dimension(800, 600);
	public static final String COMPONENT_COMPOSITION_FILE = "xml/ComponentComposition.xml";
	public static final String XML_MODULE_CLASS_TAG = "moduleClass";
	public static final String XML_MODULE_UI = "moduleUi";
	public static final String XML_METHOD_DEFINITION = "method";
	public static final String XML_PARAM_DEFINITION = "stringParam";
	public static final Object XML_MODULE_DEFINITION = "moduleDefinition";
	public static final String FILE_POI_RULES = "xml/POIRules.xml";

	public static final String FILE_FILTER_TRAFFSIM_XML = "*.xml";
	public static final String FILE_FILTER_OSM = "*.osm; *.pbf";
	public static final String FILTER_NAME_TRAFFSIM = "TraffSim Configuration";
	public static final String FILTER_NAME_OSM = "OSM File";
	public static final String FILE_FILTER_CSV = "*.csv";
	public static final String FILTER_NAME_CSV = "CSV File";

	/** Model constants **/
	public static final double SAFE_DECELERATION = -2.0;
	public static final double MAX_ACCELERATION = 5.0;
	public static final double MAX_DECELERATION = -9.0;
	public static final double DESIRED_TIME_HEADWAY = 1.5;
}

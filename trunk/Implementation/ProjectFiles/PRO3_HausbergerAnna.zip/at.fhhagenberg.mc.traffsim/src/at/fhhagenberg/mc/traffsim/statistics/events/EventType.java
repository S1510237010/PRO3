package at.fhhagenberg.mc.traffsim.statistics.events;

import org.eclipse.swt.graphics.Image;

import at.fhhagenberg.mc.traffsim.ui.IImageKeys;
import at.fhhagenberg.mc.traffsim.util.ImageUtil;

public enum EventType {
	VEHICLE_CREATED(0), VEHICLE_LEFT(1), VEHICLE_ENTERED(2), ROUTE_UPDATED(10), ROUTE_UPDATED_PREDICTIVE(11), ROUTE_UDPATED_REACTIVE(12), CRASH(
			20), DEADLOCK(21), CONGESTION_DETECTED(30), CONGESTION_PREDICTED(31), DRIVING_MODE_SWITCHED(32), DEBUGSESSION_STARTED(
					97), DEBUGSESSION_COMPLETED(98), VARIABLE_CHANGED(99), FIRST_VEHICLE_FINISHED(100), LAST_VEHICLE_GENERATED(101);

	private int index;

	EventType(int index) {
		this.index = index;
	}

	public int getIndex() {
		return index;
	}

	public static Image getImage(EventType type) {
		switch (type) {
		case ROUTE_UPDATED:
		case ROUTE_UPDATED_PREDICTIVE:
		case ROUTE_UDPATED_REACTIVE:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_UPDATE);
		case VEHICLE_CREATED:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_PLUS_WHITE);
		case VEHICLE_ENTERED:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_ENTER);
		case VEHICLE_LEFT:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_MINUS_WHITE);
		case CRASH:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_CRASH);
		case CONGESTION_DETECTED:
		case CONGESTION_PREDICTED:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_CONGESTION);
		case DEBUGSESSION_STARTED:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_DEBUG_SESSION_STARTED);
		case DEBUGSESSION_COMPLETED:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_DEBUG_SESSION_COMPLETED);
		case VARIABLE_CHANGED:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_VARIABLE_CHANGED);
		case DRIVING_MODE_SWITCHED:
			return ImageUtil.getSWTImage(IImageKeys.ACTION_DRIVING_MODE_SWITCHED);
		default:
			return null;
		}
	}

	public static String getAbbreviation(EventType type) {
		String str = type.toString();
		StringBuffer abbr = new StringBuffer();
		int _ind = -1;
		do {
			abbr.append(str.substring(_ind + 1, _ind + 2));
			_ind++;
		} while ((_ind = str.indexOf('_', _ind)) != -1);

		if (abbr.length() == 1) {
			// use first two characters as abbr. if no underscore found
			abbr.append(str.charAt(1));
		}
		return abbr.toString();
	}

	public boolean isCongestion() {
		return index >= CONGESTION_DETECTED.getIndex() && index <= CONGESTION_PREDICTED.getIndex();
	}
}

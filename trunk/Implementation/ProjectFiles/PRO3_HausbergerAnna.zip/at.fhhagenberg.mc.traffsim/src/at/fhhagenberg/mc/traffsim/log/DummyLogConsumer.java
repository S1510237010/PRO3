package at.fhhagenberg.mc.traffsim.log;

import at.fhhagenberg.mc.traffsim.model.ILogConsumer;

/**
 * A dummy implementation of {@link ILogConsumer} which effectively does nothing.
 *
 * @author Christian Backfrieder
 *
 */
public class DummyLogConsumer implements ILogConsumer {

	@Override
	public void addLogLine(LogMessage message) {

	}
}
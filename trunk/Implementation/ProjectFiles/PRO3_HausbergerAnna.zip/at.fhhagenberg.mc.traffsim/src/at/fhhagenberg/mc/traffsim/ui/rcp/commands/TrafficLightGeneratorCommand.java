package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import org.apache.commons.lang3.tuple.Pair;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLightGenerator;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.junction.TrafficLightGeneratorWizard;

public class TrafficLightGeneratorCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
	}

	@Override
	public void dispose() {
		// Unused
	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final TrafficLightGeneratorWizard wizard = new TrafficLightGeneratorWizard();
		WizardDialog dialog = new WizardDialog(Display.getCurrent().getActiveShell(), wizard);
		dialog.setPageSize(700, 630);
		int result = dialog.open();

		if (result == Dialog.CANCEL) {
			return null;
		}

		Job job = new Job("Traffic Light Generation") {

			@Override
			protected IStatus run(IProgressMonitor monitor) {

				if (wizard.performRemove()) {
					SimulationModel model = SimulationKernel.getInstance().getActiveModel();
					RoadNetwork network = model.getNetwork();

					for (AbstractJunction junction : network.getJunctions()) {
						if (junction.getType() == NodeType.TRAFFIC_LIGHT) {
							junction.setType(NodeType.SIMPLE);
							network.removeTrafficLightsForJunction(junction);
							junction.removeTrafficLightController();
						}
					}

					Display.getDefault().asyncExec(new Runnable() {
						@Override
						public void run() {
							MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Traffic Lights Removed Successfully",
									"All traffic lights have been removed from the active simulation model. Click on 'Export Infrastructure' to persist all changes.");
						}
					});

					return Status.OK_STATUS;
				}

				TrafficLightGenerator generator = new TrafficLightGenerator(SimulationKernel.getInstance().getActiveModel());
				Pair<Integer, Integer> generatedTrafficLights = generator.generateTrafficLights(wizard.getGenerationParameters(),
						wizard.getTrafficLightConfigurationParameters());

				Display.getDefault().asyncExec(new Runnable() {
					@Override
					public void run() {
						MessageDialog.openInformation(Display.getDefault().getActiveShell(), "Traffic Light Generation Finished",
								generatedTrafficLights.getLeft() == 0
										? "Nothing to generate. Make sure to provide meaningful generation parameters and ensure that a simulation model is loaded."
										: generatedTrafficLights.getLeft() + " traffic lights have been generated for "
												+ generatedTrafficLights.getRight()
												+ " junctions. Click on 'Export Infrastructure' to persist all changes.");
					}
				});

				return Status.OK_STATUS;
			}
		};

		job.setUser(true);
		job.schedule();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// Unused
	}
}
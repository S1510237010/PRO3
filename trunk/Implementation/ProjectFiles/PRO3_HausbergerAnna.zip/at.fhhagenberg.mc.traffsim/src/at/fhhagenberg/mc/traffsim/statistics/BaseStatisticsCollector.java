package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jmatio.types.MLArray;
import com.jmatio.types.MLCell;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;
import com.jmatio.types.MLInt16;
import com.jmatio.types.MLInt64;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.IntervalUpdateThread;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.statistics.events.CongestionEvent;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.EnumUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.CollectionUtil;

public abstract class BaseStatisticsCollector extends IntervalUpdateThread {

	protected static final String EVENTS_VAR = "events";
	protected static final String SIMPLE_MAT_FILE_SUFFIX = ".mat";
	protected static final String TRAFFSIM_VERSION_VARNAME = "traffsim_version";
	protected static final String HOST_VARNAME = "host_dns_name";
	protected static final String REROUTER_CPU_TIME = "rerouter_cpu_time";
	protected static final String DISTRACTIONS = "driver_distractions";
	protected static final String CPU_INFO = "cpu_info";
	protected static final String CRASH_TAG = "CRASH";
	protected static final String DEADLOCK_TAG = "DEADLOCK";

	private static final String COLUMN_NAMES_EVENTS_VAR = "column_names_events";
	protected static final String VEHICLE_STATISTICS_PREFIX = "vehicle_statistics_";
	protected static final String VEHICLE_NUMBER_ROUTABLE = "vehicle_num_routable";
	protected static final String VEHICLE_NUMBER_UNROUTABLE = "vehicle_num_unroutable";
	protected static final String VEHICLE_NUMBER_TOTAL = "vehicle_num_total";

	protected static final String CACHE_FILE_SUFFIX = ".cache";

	protected SimulationModel model;

	protected enum EventFieldId {
		ID, NUMBER, DATE, TYPE, TYPE_ID, VEHICLE_ID, DETAILS, CONGESTED_NODE, CONGESTED_SEGMENT, SEVERITY, PREDICTED_TIME, LOGDATE;
	}

	public BaseStatisticsCollector(String name, long delayInMillis, boolean startThread) {
		super(name, delayInMillis, startThread);
	}

	protected MLCell getEventData(List<Event> events) {
		// event data
		MLCell eventData = new MLCell(EVENTS_VAR, new int[] { events.size(), EventFieldId.values().length });
		for (int i = 0; i < events.size(); i++) {
			Event evt = events.get(i);
			eventData.set(new MLDouble("", new double[] { evt.getId() }, 1), i, EventFieldId.ID.ordinal());
			eventData.set(new MLDouble("", new double[] { evt.getContinuousNumber() }, 1), i, EventFieldId.NUMBER.ordinal());
			eventData.set(new MLInt64("", new long[] { evt.getTimestamp().getTime() }, 1), i, EventFieldId.DATE.ordinal());
			eventData.set(new MLChar("", evt.getType().toString()), i, EventFieldId.TYPE.ordinal());
			eventData.set(new MLInt16("", new short[] { (short) evt.getType().ordinal() }, 1), i, EventFieldId.TYPE_ID.ordinal());

			Matcher matcher = Pattern.compile(".*#(\\d+).*").matcher(evt.getDetails());
			long vehicleId = matcher.find() ? Long.parseLong(matcher.group(1)) : -1;
			eventData.set(new MLInt64("", new long[] { vehicleId }, 1), i, EventFieldId.VEHICLE_ID.ordinal());
			eventData.set(new MLChar("", evt.getDetails()), i, EventFieldId.DETAILS.ordinal());
			if (evt instanceof CongestionEvent) {
				CongestionEvent cevt = (CongestionEvent) evt;
				eventData.set(new MLInt64("", new long[] { cevt.getNodeId() }, 1), i, EventFieldId.CONGESTED_NODE.ordinal());
				eventData.set(new MLInt64("", new long[] { cevt.getSegmentId() }, 1), i, EventFieldId.CONGESTED_SEGMENT.ordinal());
				eventData.set(new MLDouble("", new double[] { cevt.getSeverity() }, 1), i, EventFieldId.SEVERITY.ordinal());
				eventData.set(new MLInt64("", new long[] { cevt.getPrediction() != null ? cevt.getPrediction().getTime() : 0 }, 1), i,
						EventFieldId.PREDICTED_TIME.ordinal());
			} else {
				eventData.set(new MLInt64("", new long[] { 0 }, 1), i, EventFieldId.CONGESTED_NODE.ordinal());
				eventData.set(new MLInt64("", new long[] { 0 }, 1), i, EventFieldId.CONGESTED_SEGMENT.ordinal());
				eventData.set(new MLDouble("", new double[] { 0 }, 1), i, EventFieldId.SEVERITY.ordinal());
				eventData.set(new MLInt64("", new long[] { 0 }, 1), i, EventFieldId.PREDICTED_TIME.ordinal());
			}
			eventData.set(new MLInt64("", new long[] { evt.getLogDate().getTime() }, 1), i, EventFieldId.LOGDATE.ordinal());
		}

		return eventData;
	}

	protected MLChar getEventColumnNames() {
		// column names for events
		String[] colNames = EnumUtil.enumNameToStringArray(EventFieldId.values());
		return new MLChar(COLUMN_NAMES_EVENTS_VAR, colNames);
	}

	protected File getStandardMatFile(File outputFolder, String date, String prefix, String suffix) {
		String matFilename = String.format("%s%s%s", prefix, date, suffix);
		File matFile = new File(outputFolder, matFilename);
		return matFile;
	}

	protected File getStandardMatFile(File outputFolder, String date, String suffix) {
		return getStandardMatFile(outputFolder, date, getStatisticsFilePrefix(), suffix);
	}

	protected Collection<MLArray> addStandardStatistics(Collection<MLArray> matFileData) {
		// cpu statistics
		if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_CPU_STATISTICS)) {
			CpuInfo cpuInfo = SimulationKernel.getCpuInfo();

			if (cpuInfo != null) {
				matFileData.add(new MLChar(CPU_INFO, SimulationKernel.getCpuInfo().getSummary()));
				double[][] arr = new double[1][1];
				arr[0][0] = model.getCpuTime();
				matFileData.add(new MLDouble(REROUTER_CPU_TIME, arr));
			}
		}

		// traffsim version
		matFileData.add(new MLChar(TRAFFSIM_VERSION_VARNAME, SimulationKernel.getTraffSimVersionInfo()));

		String hostname = "<unresolved>";
		try {
			InetAddress addr;
			addr = InetAddress.getLocalHost();
			hostname = addr.getHostName();
		} catch (UnknownHostException ex) {
			Logger.logWarn("Hostname cannot be resolved");
		}
		matFileData.add(new MLChar(HOST_VARNAME, hostname));

		// vehicle number
		double[][] arr = new double[1][1];
		arr[0][0] = (int) model.getSimObserver().getTotalNumRoutableVehicles();
		matFileData.add(new MLDouble(VEHICLE_NUMBER_ROUTABLE, arr));
		arr[0][0] = (int) model.getSimObserver().getTotalNumUnroutableVehicles();
		matFileData.add(new MLDouble(VEHICLE_NUMBER_UNROUTABLE, arr));
		arr[0][0] = (int) model.getSimObserver().getTotalNumRoutableVehicles() + (int) model.getSimObserver().getTotalNumUnroutableVehicles();
		matFileData.add(new MLDouble(VEHICLE_NUMBER_TOTAL, arr));

		// aux labels, if exist
		if (CollectionUtil.isNotNullOrEmpty(model.getAuxLabels())) {
			int ind = 0;
			String val;
			for (String lbl : model.getAuxLabels()) {
				StringBuffer key = new StringBuffer("aux");
				key.append(ind++);
				if (lbl.contains("=")) {
					key.append("_");
					key.append(lbl.substring(0, lbl.indexOf('=')));
					val = lbl.substring(lbl.indexOf('=') + 1);
				} else {
					val = lbl;
				}
				matFileData.add(new MLChar(key.toString(), val));
			}
		}

		return matFileData;
	}

	@Override
	public void doWorkWaitForFinish() {
		// for potential usage of inherited classes
	}

	protected abstract String getStatisticsFilePrefix();
}
package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.batch.BatchExecutor;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class ExecuteOpenModelsCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

	@Override
	public void dispose() {
		// unused
	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		List<SimulationModel> models = new ArrayList<>(SimulationKernel.getInstance().getOpenModels());
		BatchExecutor executor = new BatchExecutor(models, PreferenceUtil.getBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_BATCH),
				PreferenceUtil.getBoolean(IPreferenceConstants.MATLAB_DELETE_FILES_AFTER_MERGE));
		SimulationKernel.getInstance().setActiveBatchExecutor(executor);
		executor.start();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

}

package at.fhhagenberg.mc.traffsim.roadnetwork;

import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Geometry information holding a point list and geometry methods
 *
 * @author Christian B.
 *
 */
public class RoadGeometry {
	private List<Vector> points = new ArrayList<Vector>();
	private List<Vector> originalPoints = new ArrayList<Vector>();
	private boolean copyDone = false;
	private double length = Double.NaN;

	/**
	 * cache for distances. only to be used together with anglesbeforedistance. contains the distance steps before which the angles are
	 * valid for a specific index. This field must only be changed by {@link #updateAnglesCache()} method
	 */
	private double[] distances;
	/**
	 * cache for road direction angles which are valid before a specific distance. index corresponds to the field above. This field must
	 * only be changed by {@link #updateAnglesCache()} method
	 */
	private double[] anglesBeforeDistance;

	/**
	 * Copy Constructor
	 *
	 * @param roadGeometry
	 *            a <code>RoadGeometry</code> object
	 */
	public RoadGeometry(RoadGeometry roadGeometry) {
		this.points = new ArrayList<>();
		for (Vector point : roadGeometry.getPoints()) {
			points.add(new Vector(point));
		}
		this.originalPoints = new ArrayList<>();
		for (Vector point : roadGeometry.getOriginalPoints()) {
			points.add(new Vector(point));
		}
	}

	public RoadGeometry() {
	}

	public RoadGeometry(List<Vector> points) {
		this.points = points;
		geometryChanged();
	}

	public void addPoint(Vector point) {
		this.getModifiablePoints().add(point);
		updateRoadLength();
		geometryChanged();
	}

	public boolean removePoint(int index) {
		if (index > 0 && index < points.size()) {
			points.remove(index);
			updateRoadLength();
			geometryChanged();
			return true;
		}
		return false;
	}

	public void addPoint(double x, double y) {
		points.add(new Vector(x, y));
		geometryChanged();
	}

	public void resetPoints() {
		points = new ArrayList<Vector>();
		geometryChanged();
	}

	public Vector mapPosition(double roadPosition) {
		return mapPosition(roadPosition, 0, null, null);
	}

	/**
	 * Maps a position on the polylane this road geometry represents, using the given offset.
	 *
	 * @param roadPosition
	 *            the position from the beginning as distance on the polyline
	 * @param offset
	 *            the offset right or left (positive or negative)
	 * @param laneSegment
	 *            the lane segment for which to perform the mapping
	 * @param vehicle
	 *            the vehicle for which the mapping is done, because if the roadPosition is longer than the current lane, the route of the
	 *            vehicle is considered to determine the subsequent segment
	 * @return the absolutely mapped position
	 */
	public Vector mapPosition(double roadPosition, double offset, VehiclesLane laneSegment, Vehicle vehicle) {
		List<Vector> geomPoints = getPoints();
		double curRoadLength = 0;
		Vector dirVecFromLastSamplingPoint = null;
		Vector lastSamplingPoint;
		double magn = 0;
		if (getPoints().size() < 2) {
			return null;
		}
		// find succeeding lane segment, if road pos slightly out of current road length (can happen because #updateSpeedAndPositions is
		// called before #outFlow of VehicleLane s
		if (roadPosition > getRoadLength()) {
			VehiclesLane currentLane = null;
			if (laneSegment == null) {
				return null;
			}
			if (laneSegment.getSinkLaneSegment() != null) {
				currentLane = laneSegment.getSinkLaneSegment();
			} else if (laneSegment.getRoadSegment().getJunction() != null && vehicle != null) {
				currentLane = laneSegment.getRoadSegment().getJunction().getConnector(laneSegment.getRoadSegment().getRoutingId(),
						vehicle.getRoute().getNextRoutingId());
			}
			if (currentLane == null) {
				return null;
			}
			geomPoints = currentLane.getRoadGeometry().getPoints();
			roadPosition -= laneSegment.getRoadLength();

			Iterator<Vector> it = geomPoints.iterator();
			lastSamplingPoint = it.next();
			while (it.hasNext()) {
				Vector loc2 = it.next();
				dirVecFromLastSamplingPoint = loc2.minus(lastSamplingPoint);
				magn = dirVecFromLastSamplingPoint.magnitude();
				curRoadLength = curRoadLength + magn;
				if (roadPosition > magn) {
					roadPosition -= magn;
				}
				lastSamplingPoint = loc2;
			}
		} else {
			/*
			 * road position is in current segment - find absolute by looking up last sampling point of geometry and moving on from there
			 * (performance optimization)
			 */
			double positionSum = roadPosition;
			lastSamplingPoint = points.get(0);
			int i;
			for (i = 0; i < points.size(); i++) {
				if (positionSum < distances[i]) {
					lastSamplingPoint = points.get(i);
					break;
				} else {
					roadPosition -= distances[i] - (i > 0 ? distances[i - 1] : 0);
				}
			}
			dirVecFromLastSamplingPoint = points.get(i + 1).minus(points.get(i));
			magn = dirVecFromLastSamplingPoint.magnitude();
		}
		Vector mapped = lastSamplingPoint.plus(dirVecFromLastSamplingPoint.multiplyBy(roadPosition / magn));
		if (offset != 0) {
			mapped = mapped.plus(dirVecFromLastSamplingPoint.normal(offset < 0).unify().multiplyBy(Math.abs(offset)));
		}
		return mapped;

	}

	public double mapPoint(Vector point) {
		Iterator<Vector> it = getPoints().iterator();
		double roadPosition = 0;
		if (getPoints().size() < 2) {
			return 1;
		}
		Vector loc = it.next();
		while (it.hasNext()) {
			Vector loc2 = it.next();
			if (NumberUtil.doubleEquals(Line2D.ptLineDist(loc.x, loc.y, loc2.x, loc2.y, point.x, point.y), 0, 10E-3)) {
				roadPosition += point.minus(loc).magnitude();
				return roadPosition;
			} else {
				Vector vec = loc2.minus(loc);
				roadPosition = roadPosition + vec.magnitude();
			}
			loc = loc2;
		}
		return -1;
	}

	public double getRoadLength() {
		if (Double.isNaN(length)) {
			updateRoadLength();
		}
		return length;
	}

	private void updateRoadLength() {
		length = SpatialUtil.getLength(points);
	}

	/**
	 *
	 * @return the current points as unmodifiable List
	 */
	public List<Vector> getPoints() {
		return Collections.unmodifiableList(getModifiablePoints());
	}

	/**
	 *
	 * IMPORTANT: due to caching, {@link #geometryChanged()} must be called after anything is changed in this collection!
	 *
	 * @return the list of points as a modifiable list (in contrast to {@link #getPoints()}
	 */
	public List<Vector> getModifiablePoints() {
		return points.isEmpty() ? originalPoints : points;
	}

	/**
	 * This method must be called after points are modified!
	 */
	public void geometryChanged() {
		updateRoadLength();
		updateAnglesCache();
	}

	/**
	 * Update the cached direction angles for this geometry. Must be called each time the geometry is changed anyhow
	 */
	private void updateAnglesCache() {
		distances = new double[points.size() - 1];
		anglesBeforeDistance = new double[points.size() - 1];
		double distance = 0;
		double roadLength = 0;
		Vector loc = getPoints().get(0);
		for (int i = 1; i < points.size(); i++) {
			Vector loc2 = getPoints().get(i);
			Vector vec = loc2.minus(loc);
			roadLength = roadLength + vec.magnitude();
			distances[i - 1] = roadLength;
			anglesBeforeDistance[i - 1] = vec.getAngle();
			distance = distance + vec.magnitude();
			loc = loc2;
		}
	}

	public void setPoints(List<Vector> points) {
		this.points = points;
		geometryChanged();
	}

	/**
	 * Returns the angle at a specific position.
	 *
	 * This method uses cached positions because it is called very often for each vehicle during
	 * {@link Vehicle#updateSpeedAndPosition(double, Date)}
	 *
	 * @param roadPosition
	 * @return the direction angle at the specific position
	 */
	public double angleAt(double roadPosition) {
		for (int i = 0; i < distances.length; i++) {
			if (roadPosition < distances[i]) {
				return anglesBeforeDistance[i];
			}
		}
		return 0;
	}

	public double angleAfter(Vector point) {
		int i = points.indexOf(point);
		if (i == -1 || i + 1 >= points.size()) {
			return -1;
		}
		Vector vec = points.get(i + 1).minus(point);
		return vec.getAngle();
	}

	public Vector getPoint(int index) {
		if (index >= 0 && index < points.size()) {
			return points.get(index);
		}
		return null;
	}

	public Vector getLastPoint() {
		if (points != null && points.size() > 0) {
			return points.get(points.size() - 1);
		}
		return null;
	}

	public Vector getFirstPoint() {
		if (points != null && points.size() > 0) {
			return points.get(0);
		}
		return null;
	}

	public void copyOriginalPoints() {
		if (!copyDone) {
			this.originalPoints = new ArrayList<>();
			originalPoints.addAll(points);
			copyDone = true;
		}
	}

	public void resetToOriginalPoints() {
		this.points = new ArrayList<>();
		points.addAll(originalPoints);
		updateRoadLength();
	}

	public List<Vector> getOriginalPoints() {
		return originalPoints;
	}

	public void addOriginalPoint(double x, double y) {
		originalPoints.add(new Vector(x, y));
	}
}

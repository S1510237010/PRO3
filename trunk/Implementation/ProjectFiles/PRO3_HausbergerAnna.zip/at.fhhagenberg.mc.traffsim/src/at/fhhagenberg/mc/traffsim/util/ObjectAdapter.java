package at.fhhagenberg.mc.traffsim.util;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.data.beans.CoordinateBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.CyclicControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.CyclicControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.FixedTimeControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.FixedTimeControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.SelfOrganizingControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.SelfOrganizingControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.distraction.DistractionModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.distraction.DistractionTypeBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.CACCLaneChangeDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.MOBILDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.ACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.CACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.GippsDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IIDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.KraussDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.MemoryDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.OVMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation.DrivingRegimeBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation.SpeedRangeBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.DefaultLongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ExtendedHumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.HumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.PlatoonLongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.VehicleAutomationControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.RTDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.platoon.PlatoonActionDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.platoon.PlatoonDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.platoon.PlatoonManagerDataBean;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.QueueMonitor;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.CyclicController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.FixedTimeController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController.Mode;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.CyclicControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.FixedTimeControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.SelfOrganizingControlLogic;
import at.fhhagenberg.mc.traffsim.vehicle.DrivingRegime;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.AutomationLevel;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionType;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data.CACCLaneChangeData;
import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data.MOBILData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.IPlatoonLongitudinalModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.VehicleAutomationControl;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.ExtendedHumanDriverControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.HumanDriverControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data.PlatoonLongitudinalControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.ACCData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.CACCData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.GippsData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.IDMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.IIDMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.KraussData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.MemoryInputData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.OVMData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.Noise;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.Regime;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.SpeedRange;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonActionData;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonActionType;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonData;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data.PlatoonManagerData;

/**
 * Utility class providing functionality to convert bean classes obtained from the data serialization into other entities.
 *
 *
 * @author Christian Backfrieder
 */
public class ObjectAdapter {

	public static TrafficLight toTrafficLight(TrafficLightBean bean) {
		TrafficLight trafficLight = new TrafficLight(bean.getId(), bean.getConnectors());
		trafficLight.setTimeIntergreen(bean.getTimeIntergreen());
		trafficLight.setTimeYellow(bean.getTimeYellow());
		trafficLight.setTimeRedYellow(bean.getTimeRedYellow());
		return trafficLight;
	}

	public static ControlLogic toControlLogic(ControlLogicBean bean, TrafficLight trafficLight, QueueMonitor queueMonitor) {
		if (bean instanceof CyclicControlLogicBean) {
			CyclicControlLogicBean cb = (CyclicControlLogicBean) bean;
			CyclicControlLogic logic = new CyclicControlLogic(trafficLight, cb.getPhaseLength(), cb.getDelay());
			return logic;
		} else if (bean instanceof FixedTimeControlLogicBean) {
			FixedTimeControlLogicBean ftb = (FixedTimeControlLogicBean) bean;
			FixedTimeControlLogic logic = new FixedTimeControlLogic(trafficLight, ftb.getIsGreenInitially(), ftb.getDelay(), ftb.getTimeGreen(),
					ftb.getTimeRed(), ftb.getOffset());
			return logic;
		} else if (bean instanceof SelfOrganizingControlLogicBean) {
			SelfOrganizingControlLogicBean sob = (SelfOrganizingControlLogicBean) bean;
			SelfOrganizingControlLogic logic = new SelfOrganizingControlLogic(trafficLight, queueMonitor, sob.getTimeHorizon());
			logic.setPassOverTime(sob.getPassOverTime());
			logic.setStartUpLossTime(sob.getStartUpLossTime());
			return logic;
		}

		return null;
	}

	public static TrafficLightController<?> toTrafficLightController(TrafficLightControllerBean bean, AbstractJunction junction) {
		if (bean instanceof CyclicControllerBean) {
			CyclicControllerBean cb = (CyclicControllerBean) bean;
			CyclicController controller = new CyclicController(bean.getId(), junction, cb.getStartWithGreen());
			controller.setAreLanesOperatedIndividually(bean.getAreLanesOperatedIndividually());
			return controller;
		} else if (bean instanceof FixedTimeControllerBean) {
			FixedTimeController controller = new FixedTimeController(bean.getId(), junction);
			controller.setAreLanesOperatedIndividually(bean.getAreLanesOperatedIndividually());
			return controller;
		} else if (bean instanceof SelfOrganizingControllerBean) {
			SelfOrganizingControllerBean sob = (SelfOrganizingControllerBean) bean;
			SelfOrganizingController controller = new SelfOrganizingController(bean.getId(), junction);
			controller.setMode(Mode.getModeById(sob.getMode()));
			controller.setTargetCycleLength(sob.getTargetCycleLength());
			controller.setMaxCycleLength(sob.getMaxCycleLength());
			controller.setUseHeuristics(sob.getUseHeuristics());
			controller.setUpdateInterval(sob.getUpdateInterval());
			controller.setAreLanesOperatedIndividually(bean.getAreLanesOperatedIndividually());
			return controller;
		}

		return null;
	}

	/**
	 * Converts the given adaptive cruise control data bean into an adaptive cruise control data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static ACCData toACCData(ACCDataBean bean) {
		ACCData result = new ACCData();
		result.setComfortableAcc(bean.getComfortableAcc());
		result.setDelta(bean.getDelta());
		result.setMaxDec(bean.getMaxDec());
		result.setMaxAcc(bean.getMaxAcc());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		result.settMin(bean.gettMin());
		result.setvTarget(bean.getvTarget());
		result.setCoolness(bean.getCoolness());

		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	/**
	 * Converts the given cooperative adaptive cruise control data bean into an cooperative adaptive cruise control data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static CACCData toCACCData(CACCDataBean bean) {
		CACCData result = new CACCData();
		result.setComfortableAcc(bean.getComfortableAcc());
		result.setMaxDec(bean.getMaxDec());
		result.setMaxAcc(bean.getMaxAcc());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		result.settMin(bean.gettMin());
		result.setvTarget(bean.getvTarget());
		result.setC1(bean.getC1());
		result.setDamping(bean.getDamping());
		result.setBandwidth(bean.getBandwidth());
		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	/**
	 * Converts the given cooperative adaptive cruise control lane change data bean into a cooperative adaptive cruise control lane change
	 * data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @param model
	 *            simulation model
	 * @return the converted data entity
	 */
	public static CACCLaneChangeData toCACCLaneChangeData(CACCLaneChangeDataBean bean, SimulationModel model) {
		CACCLaneChangeData result = new CACCLaneChangeData();
		result.setFullname(bean.getFullName());
		result.setIdentifier(bean.getModelIdentifier());
		result.setHumanModel(model.getModelRegistry().getModel(bean.getHumanLaneChangeModelIdentifier(), LaneChangeModel.class));
		result.setLeaderModel(model.getModelRegistry().getModel(bean.getLeaderLaneChangeModelIdentifier(), LaneChangeModel.class));
		result.setPlatoonLaneChangeEnabled(bean.isPlatoonLaneChangeEnabled());
		result.setMaxDec(bean.getMaxDec());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		if (result.getHumanModel() == null) {
			Logger.logError("Invalid lane change model identifier '" + bean.getHumanLaneChangeModelIdentifier() + "' for human model.");
		}
		if (result.getLeaderModel() == null) {
			Logger.logError("Invalid lane change model identifier '" + bean.getLeaderLaneChangeModelIdentifier() + "' for leader mode.");
		}
		return result;
	}

	/**
	 * Converts the given list of vectors into a list of coordinate data beans.
	 *
	 * @param vectors
	 *            the list of vectors to be converted
	 * @return the list of converted coordinate beans
	 */
	public static List<CoordinateBean> toCoordinateBeanList(List<Vector> vectors) {
		List<CoordinateBean> result = new ArrayList<>();
		for (Vector v : vectors) {
			result.add(new CoordinateBean(v.x, v.y));
		}
		return result;
	}

	public static LongitudinalControl<ILongitudinalModel> toDefaultLongitudinalControl(DefaultLongitudinalControlBean bean) {
		LongitudinalControl<ILongitudinalModel> defaultControl = new LongitudinalControl<>(bean.getIdentifier());
		defaultControl.setCllxtEnabled(bean.getCllxtEnabled());
		return defaultControl;
	}

	public static VehicleAutomationControl toVehicleAutomationControl(VehicleAutomationControlBean bean) {
		VehicleAutomationControl control = new VehicleAutomationControl(bean.getIdentifier(), AutomationLevel.valueOfLabel(bean.getAutomationLevel()),
				bean.getTransitionSecondsAutomated(), bean.getTransitionSecondsHuman(), bean.getEvaluationRate(), bean.getTimeHeadway(),
				bean.getSpaceHeadway());

		control.setCllxtEnabled(bean.getCllxtEnabled());
		List<Regime> drivingRegimes = new ArrayList<>();
		List<SpeedRange> speedRanges = new ArrayList<>();

		if (bean.getDrivingRegimes() != null) {
			for (DrivingRegimeBean drivingRegime : bean.getDrivingRegimes()) {
				Regime regime = new Regime(DrivingRegime.valueOfLabel(drivingRegime.getRegime()), drivingRegime.getFallbackProbability());
				drivingRegimes.add(regime);
			}
		}

		if (bean.getSpeedRanges() != null) {
			for (SpeedRangeBean speedRange : bean.getSpeedRanges()) {
				SpeedRange range = new SpeedRange(speedRange.getFromSpeed(), speedRange.getToSpeed(), speedRange.getFallbackProbability());
				speedRanges.add(range);
			}
		}

		control.setDrivingRegimes(drivingRegimes);
		control.setSpeedRanges(speedRanges);
		return control;
	}

	public static PlatoonLongitudinalControlData toPlatoonLogitudinalControlData(PlatoonLongitudinalControlBean bean, SimulationModel model) {
		PlatoonLongitudinalControlData result = new PlatoonLongitudinalControlData();
		result.setLeaderLongitudinalModel(model.getModelRegistry().getModel(bean.getLeaderLongitudinalModelIdentifier(), ILongitudinalModel.class));
		result.setFollowerLongitudinalModel(
				model.getModelRegistry().getModel(bean.getFollowerLongitudinalModelIdentifier(), IPlatoonLongitudinalModel.class));
		result.setManeuverLongitudinalModel(
				model.getModelRegistry().getModel(bean.getManeuverLongitudinalModelIdentifier(), ILongitudinalModel.class));
		result.setHumanLongitudinalModel(model.getModelRegistry().getModel(bean.getHumanLongitudinalModelIdentifier(), ILongitudinalModel.class));
		result.setIdentifier(bean.getIdentifier());
		if (result.getLeaderLongitudinalModel() == null) {
			Logger.logError("Invalid longitudinal model identifier '" + bean.getLeaderLongitudinalModelIdentifier() + "'.");
		}
		if (result.getFollowerLongitudinalModel() == null) {
			Logger.logError("Invalid longitudinal model identifier '" + bean.getFollowerLongitudinalModelIdentifier() + "'.");
		}
		if (result.getManeuverLongitudinalModel() == null) {
			Logger.logError("Invalid longitudinal model identifier '" + bean.getManeuverLongitudinalModelIdentifier() + "'.");
		}
		if (result.getHumanLongitudinalModel() == null) {
			Logger.logError("Invalid longitudinal model identifier '" + bean.getHumanLongitudinalModelIdentifier() + "'.");
		}
		return result;
	}

	public static ExtendedHumanDriverControlData toEHDMxData(ExtendedHumanDriverControlBean bean) {
		RTDataBean rtBean = bean.getResponseTimes();

		ExtendedHumanDriverControlData result = new ExtendedHumanDriverControlData(bean.getDistanceNoiseIdentifier(),
				bean.getVelocityDifferenceNoiseIdentifier(), bean.getAccelerationNoiseIdentifier(), rtBean, bean.getNumConsideredVehicles(),
				bean.getSightDistance(), bean.getSpaceHeadwayThreshold());

		result.setIdentifier(bean.getIdentifier());
		return result;
	}

	/**
	 * Converts the given gipps data bean into a gipps data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static GippsData toGippsData(GippsDataBean bean) {
		GippsData result = new GippsData();
		result.setComfortableAcc(bean.getComfortableAcc());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		result.setvTarget(bean.getvTarget());

		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	public static HumanDriverControlData toHDMxData(HumanDriverControlBean bean) {
		HumanDriverControlData result = new HumanDriverControlData(bean.getDistanceNoiseIdentifier(), bean.getVelocityDifferenceNoiseIdentifier(),
				bean.getReactionTime(), bean.getIsReactive(), bean.getIsAnticipative(), bean.getNumConsideredVehicles());

		result.setIdentifier(bean.getIdentifier());
		return result;
	}

	/**
	 * Converts the given intelligent driver model data bean into an intelligent driver model data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static IDMData toIDMData(IDMDataBean bean) {
		IDMData result = new IDMData();
		result.setComfortableAcc(bean.getComfortableAcc());
		result.setDelta(bean.getDelta());
		result.setMaxDec(bean.getMaxDec());
		result.setMaxAcc(bean.getMaxAcc());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		result.settMin(bean.gettMin());
		result.setvTarget(bean.getvTarget());

		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	public static IIDMData toIIDMData(IIDMDataBean bean) {
		IIDMData result = new IIDMData();
		result.setComfortableAcc(bean.getComfortableAcc());
		result.setDelta(bean.getDelta());
		result.setMaxDec(bean.getMaxDec());
		result.setMaxAcc(bean.getMaxAcc());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		result.settMin(bean.gettMin());
		result.setvTarget(bean.getvTarget());

		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	/**
	 * Converts the given krauss data bean into a krauss data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static KraussData toKraussData(KraussDataBean bean) {
		KraussData result = new KraussData();
		result.setComfortableAcc(bean.getComfortableAcc());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		result.setvTarget(bean.getvTarget());
		result.setEpsilon(bean.getEpsilon());

		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	/**
	 * Converts the given memory data bean into a memory data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static MemoryInputData toMemoryInputData(MemoryDataBean bean) {
		MemoryInputData result = new MemoryInputData(bean.getTau(), bean.getResignationMaxAlphaT(), bean.getResignationMinAlphaV0(),
				bean.getResignationMinAlphaA());
		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	/**
	 * Converts the given mobil data bean into a mobil data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static MOBILData toMOBILData(MOBILDataBean bean) {
		MOBILData result = new MOBILData();
		result.setBiasRight(bean.getBiasRight());
		result.setMaxDec(bean.getMaxDec());
		result.setPoliteness(bean.getPoliteness());
		result.setSafeDec(bean.getSafeDec());
		result.setsMin(bean.getsMin());
		result.setThreshold(bean.getThreshold());

		result.setFullname(bean.getFullName());
		result.setIdentifier(bean.getModelIdentifier());
		return result;
	}

	/**
	 * Converts the given noise data bean into a noise data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static Noise toNoise(NoiseDataBean bean) {
		Noise noise = new Noise(bean);

		noise.setFluctStrength(noise.getFluctStrength());
		noise.setTau(noise.getTau());
		noise.setAmplifier(noise.getAmplifier());
		return noise;
	}

	public static DistractionModel toDistractionModel(DistractionModelBean bean) {
		DistractionModel model = new DistractionModel();
		model.setUpdateInterval(bean.getUpdateInterval());
		model.setExposureStochastic(bean.getIsExposureStochastic());
		model.setArrivalStochastic(bean.getIsArrivalStochastic());

		for (DistractionTypeBean d : bean.getDistractionTypes()) {
			DistractionType distractionType = new DistractionType(d.getId(), d.getDescription(), d.getIsStochastic());
			distractionType.setExposure(d.getExposure());
			distractionType.setFrequency(d.getFrequency());
			distractionType.setIsSevere(d.isSevere());
			distractionType.setMaxDelay(d.getMaxDelay());
			distractionType.setMaxDuration(d.getMaxDuration());
			distractionType.setMeanDuration(d.getMeanDuration());
			distractionType.setMinDelay(d.getMinDelay());
			distractionType.setMinDuration(d.getMinDuration());
			distractionType.setStdDuration(d.getStdDuration());
			model.addDistractionType(distractionType);
		}

		return model;
	}

	/**
	 * Converts the given ovm data bean into an ovm data entity.
	 *
	 * @param bean
	 *            the bean to be converted
	 * @return the converted data entity
	 */
	public static OVMData toOVMData(OVMDataBean bean) {
		OVMData result = new OVMData();
		result.setComfortableAcc(bean.getComfortableAcc());
		result.setsMin(bean.getsMin());
		result.setvTarget(bean.getvTarget());
		result.setBeta(bean.getBeta());
		result.setTau(bean.getTau());
		result.setTransitionWidth(bean.getTransitionWidth());
		result.setGamma(bean.getGamma());
		result.setOVMFunction(bean.getOVMFunction());

		result.setIdentifier(bean.getModelIdentifier());
		result.setFullname(bean.getFullName());
		return result;
	}

	/**
	 * Converts the given list of coordinate data beans into a list of vectors.
	 *
	 * @param coordinates
	 *            the list of coordinate data beans to be converted
	 * @return the converted list of vectors
	 */
	public static List<Vector> toVectorList(List<CoordinateBean> coordinates) {
		List<Vector> result = new ArrayList<>();

		for (CoordinateBean coordinateBean : coordinates) {
			result.add(new Vector(coordinateBean.getX(), coordinateBean.getY()));
		}

		return result;
	}

	/***
	 * Converts platoon manager data bean into a platoon manager data entity
	 *
	 * @param bean
	 *            The bean holds the data from xml
	 * @param model
	 *            The Simulation mode of the current simulation
	 * @param allVehicles
	 *            All vehicles are predeifend in the simulation
	 * @return platoon manager data entity
	 */
	public static PlatoonManagerData toPlatoonManagerData(PlatoonManagerDataBean bean, SimulationModel model, List<Vehicle> allVehicles) {
		PlatoonManagerData result = new PlatoonManagerData();
		result.setPlatoonData(toPlatoonData(bean.getPlatoonData()));
		result.setActionTimeout(bean.getActionTimeout());
		List<PlatoonActionData> predefinedPlatoons = new ArrayList<>();
		for (PlatoonActionDataBean pdb : bean.getPlatoonActions()) {
			predefinedPlatoons.add(toPlatoonActionData(pdb, allVehicles));
		}
		result.setPlatoonActions(predefinedPlatoons);

		return result;
	}

	public static PlatoonData toPlatoonData(PlatoonDataBean bean) {
		return new PlatoonData(bean.getDesiredSpeed(), bean.getDesiredGap(), bean.getManeuverGap(), bean.getMinimumLaneCount(),
				bean.getMaxVehiclesPerPlatoon(), bean.getMaxDistanceForJoin(), bean.getMaxTargetSpeedDifferenceForJoin(), bean.getManeuverTimeout(),
				bean.getDissolveTimeout(), bean.getManeuverSpeedTOffset(), bean.getManeuverHumanDistanceThresholdOffset(),
				bean.getManeuverPlatoonDistanceThresholdOffset());
	}

	/***
	 * Converts a platoon action data bean into a platoon action data entity
	 *
	 * @param bean
	 *            The bean which holds the data from xml
	 * @param allVehicles
	 *            A list of all predefined vehicles in the simulation
	 * @return platoon action data entity
	 */
	public static PlatoonActionData toPlatoonActionData(PlatoonActionDataBean bean, List<Vehicle> allVehicles) {
		Vehicle vehicle = null;
		for (Vehicle v : allVehicles) {
			if (v.getUniqueId() == bean.getVehicleId()) {
				vehicle = v;
				break;
			}
		}

		PlatoonActionType type = PlatoonActionType.valueOfLabel(bean.getAction());
		if (type != null) {
			return new PlatoonActionData(bean.getPlatoonId(), bean.getVehicleId(), vehicle, bean.getPosition(), type, bean.getTime(), bean.isForce());
		} else {
			Logger.logWarn("Type of platoon action is not defiend (" + bean.getAction() + ")!");
		}

		return null;
	}
}
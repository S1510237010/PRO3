package at.fhhagenberg.mc.traffsim.roadnetwork.junction;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import com.google.common.collect.BoundType;
import com.google.common.collect.SortedMultiset;
import com.google.common.collect.TreeMultiset;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.IDetectorDataListener;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector.DetectionMode;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.statistics.IStatisticsProvider;
import at.fhhagenberg.mc.traffsim.statistics.IStatsConstants;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleListenerAdapter;

public class QueueMonitor implements IDetectorDataListener, IStatisticsProvider {

	public static double QMAX_PER_LANE = 1800d / TimeUnit.SECONDS.convert(1, TimeUnit.HOURS); // vehicles/h
	private static final double STOP_LINE_OFFSET = 3;

	private static double getNumVehiclesPassed(SortedMultiset<Long> set, long t0, long t1) {
		return set.subMultiset(t0, BoundType.CLOSED, t1, BoundType.CLOSED).size();
	}

	private AbstractJunction junction;
	private RoadSegment roadSegment;
	private double timeHorizon; // [s]
	private double updateInterval; // [s]

	/** Actual time horizon in ms **/
	private long actualTimeHorizon;

	/** Detection facilities **/
	private LoopDetector stopLineDetector;
	private LoopDetector upstreamDetector;

	/** Memory for already detected vehicles */
	private Set<Long> bufferStopline;
	private Set<Long> vehiclesStopline;
	private TreeMultiset<Long> setStopline;
	private Set<Long> bufferUpstream;
	private Set<Long> vehiclesUpstream;
	private TreeMultiset<Long> setUpstream;
	private long lastClearance;

	/** All quantities per lane **/
	private long countedStopline;
	private long countedUpstream;

	private double waitingTimeSinceQueueEmptied;
	private double waitingTimeTotal;
	private boolean areVehiclesQueued;
	private long queueLength;
	private DescriptiveStatistics trafficFlowTenMinuteAvg;
	private DescriptiveStatistics trafficFlowThirtySecondAvg;

	private long simulationTime;

	private VehicleListenerAdapter listener = new VehicleListenerAdapter() {
		@Override
		public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {

			long vehicleId = vehicle.getUniqueId();

			if (newLane instanceof JunctionConnector) {
				if (!vehiclesStopline.contains(vehicleId)) {
					vehiclesStopline.add(vehicleId);
					bufferStopline.add(vehicleId);

					if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_INDIVIDUAL_WAITING_TIMES)
							&& PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS)) {
						junction.notifyVehicleDequeued(vehicleId);
					}
				}
			}
		};

		@Override
		public void vehicleLeftSimulation(Vehicle v) {
			v.removeVehicleListener(listener);
		};
	};

	public QueueMonitor(AbstractJunction junction, RoadSegment segment) {
		this(junction, segment, PreferenceUtil.getInt(IPreferenceConstants.QUEUE_MONITORING_TIME_HORIZON_S));
	}

	public QueueMonitor(AbstractJunction junction, RoadSegment segment, double horizon) {
		this.junction = junction;
		roadSegment = segment;
		timeHorizon = horizon;

		vehiclesUpstream = new HashSet<>();
		bufferUpstream = new HashSet<>();
		vehiclesStopline = new HashSet<>();
		bufferStopline = new HashSet<>();
		setStopline = TreeMultiset.create();
		setUpstream = TreeMultiset.create();

		stopLineDetector = new LoopDetector(LoopDetector.NEXT_DETECTOR_ID++, roadSegment, roadSegment.getRoadLength() - STOP_LINE_OFFSET,
				PreferenceUtil.getInt(IPreferenceConstants.LOOP_DETECTOR_SAMPLE_INTERVAL), DetectionMode.REAR);
		stopLineDetector.setIsAssociatedToQueueMonitor(true);

		upstreamDetector = new LoopDetector(LoopDetector.NEXT_DETECTOR_ID++, roadSegment,
				PreferenceUtil.getInt(IPreferenceConstants.LOOP_DETECTOR_SAMPLE_INTERVAL), timeHorizon, DetectionMode.DUAL);
		upstreamDetector.setIsAssociatedToQueueMonitor(true);

		stopLineDetector.addDataListener(this);
		upstreamDetector.addDataListener(this);
		upstreamDetector.setExternalVehicleListener(listener);
	}

	public AbstractJunction getJunction() {
		return junction;
	}

	public RoadSegment getRoadSegment() {
		return roadSegment;
	}

	public double getTimeHorizon() {
		return timeHorizon;
	}

	public void setTimeHorizon(double timeHorizon) {
		this.timeHorizon = timeHorizon;
		actualTimeHorizon = upstreamDetector.moveToUpstreamPosition(timeHorizon);
	}

	public LoopDetector getStopLineDetector() {
		return stopLineDetector;
	}

	public LoopDetector getUpstreamDetector() {
		return upstreamDetector;
	}

	public double getTotalWaitingTime() {
		return waitingTimeTotal;
	}

	public double getWaitingTimeSincQueueEmptied() {
		return waitingTimeSinceQueueEmptied;
	}

	public boolean areVehiclesQueued() {
		return areVehiclesQueued;
	}

	public double getCountExpected() {
		return getCountExpected(simulationTime);
	}

	public double getCountExpected(long time) {
		return countedUpstream + getNumVehiclesPassed(setUpstream, lastClearance - actualTimeHorizon, time - actualTimeHorizon);
	}

	public double getCountOutflow() {
		return getCountOutflow(simulationTime);
	}

	public double getCountOutflow(long time) {
		return countedStopline + getNumVehiclesPassed(setStopline, lastClearance, time);
	}

	public double getCountUpstream() {
		return getCountUpstream(simulationTime);
	}

	public double getCountUpstream(long time) {
		return getCountExpected(time) + getNumVehiclesPassed(setUpstream, time - actualTimeHorizon + Math.round(updateInterval * 1000), time);
	}

	public double getQueueLength() {
		return queueLength;
	}

	public double getAverageLoad() {
		return getTrafficFlowTenMinuteAverage() / getMaxTrafficFlow();
	}

	public double getMaxTrafficFlow() {
		return QMAX_PER_LANE / stopLineDetector.getRoadSegment().getLaneCount();
	}

	public double getTrafficFlowTenMinuteAverage() {
		return trafficFlowTenMinuteAvg.getMean() / updateInterval;
	}

	public double getTrafficFlowThirtySecondAverage() {
		return trafficFlowThirtySecondAvg.getMean() / updateInterval;
	}

	public void update(double dt, double simulationTime) {
		long delayMillis = Math.round(dt * 1000);
		long timeMillis = Math.round(simulationTime * 1000);

		// Update detected vehicles
		setUpstream.add(timeMillis, bufferUpstream.size());
		bufferUpstream.clear();

		setStopline.add(timeMillis, bufferStopline.size());
		bufferStopline.clear();

		initTrafficFlowStatistics(dt);
		updateQueueLength(timeMillis);
		updateWaitingTimes(dt);
		updateTrafficFlowStatistics(timeMillis, delayMillis);

		if (!areVehiclesQueued && queueLength == 0) {
			waitingTimeSinceQueueEmptied = 0;
			clear(timeMillis);
		}

		this.simulationTime = timeMillis;
	}

	@Override
	public void onVehiclePassed(long detectorId, Vehicle vehicle, int laneIndex) {

		long vehicleId = vehicle.getUniqueId();

		if (detectorId == stopLineDetector.getIdentifier()) {
			if (!vehiclesStopline.contains(vehicleId)) {
				vehiclesStopline.add(vehicleId);
				bufferStopline.add(vehicleId);

				if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_INDIVIDUAL_WAITING_TIMES)
						&& PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS)) {
					junction.notifyVehicleDequeued(vehicleId);
				}
			}
		} else {
			if (!vehiclesUpstream.contains(vehicleId)) {
				vehiclesUpstream.add(vehicleId);
				bufferUpstream.add(vehicleId);

				if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_INDIVIDUAL_WAITING_TIMES)
						&& PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS)) {
					junction.notifyVehicleEnqueued(vehicleId, -actualTimeHorizon / 1000.0);
				}
			}
		}
	}

	@Override
	public void onPresenceChanged(long detectorId, boolean isVehiclePresent, int laneIndex) {
		if (detectorId == stopLineDetector.getIdentifier()) {
			areVehiclesQueued = isVehiclePresent;
		}
	}

	private void clear(long simulationTime) {
		SortedMultiset<Long> upstreamSet = setUpstream.headMultiset(simulationTime - actualTimeHorizon, BoundType.CLOSED);
		countedUpstream += upstreamSet.size();

		SortedMultiset<Long> stoplineSet = setStopline.headMultiset(simulationTime, BoundType.CLOSED);
		countedStopline += stoplineSet.size();

		lastClearance = simulationTime;
		upstreamSet.clear();
		stoplineSet.clear();
	}

	private void initTrafficFlowStatistics(double dt) {
		if (trafficFlowTenMinuteAvg == null && trafficFlowThirtySecondAvg == null) {
			trafficFlowTenMinuteAvg = new DescriptiveStatistics((int) (600 / dt));
			trafficFlowThirtySecondAvg = new DescriptiveStatistics((int) (30 / dt));
			updateInterval = dt;
		}
	}

	private void updateQueueLength(long time) {
		double countExpected = getCountExpected(time);
		double countOutflow = getCountOutflow(time);
		queueLength = (long) Math.max(0, countExpected - countOutflow);
	}

	private void updateWaitingTimes(double dt) {
		double increment = queueLength * dt;
		waitingTimeSinceQueueEmptied += increment;
		waitingTimeTotal += increment;
	}

	private void updateTrafficFlowStatistics(long time, long dt) {
		double countUpstream = getCountUpstream(time);
		countUpstream -= getCountUpstream(time - dt);
		trafficFlowTenMinuteAvg.addValue(countUpstream);
		trafficFlowThirtySecondAvg.addValue(countUpstream);
	}

	@Override
	public Map<String, Number> obtainStatistics() {
		Map<String, Number> statistics = new HashMap<>();
		statistics.put(IStatsConstants.QUEUE_MONITOR_AVERAGE_LOAD, getAverageLoad());
		statistics.put(IStatsConstants.QUEUE_MONITOR_COUNT_OUTFLOW, getCountOutflow());
		statistics.put(IStatsConstants.QUEUE_MONITOR_COUNT_EXPECTED, getCountExpected());
		statistics.put(IStatsConstants.QUEUE_MONITOR_COUNT_UPSTREAM, getCountUpstream());
		statistics.put(IStatsConstants.QUEUE_MONITOR_QUEUE_LENGTH, getQueueLength());
		statistics.put(IStatsConstants.QUEUE_MONITOR_FLOW_AVG_30_SEC, getTrafficFlowThirtySecondAverage() * 3600);
		statistics.put(IStatsConstants.QUEUE_MONITOR_FLOW_AVG_10_MIN, getTrafficFlowThirtySecondAverage() * 3600);
		statistics.put(IStatsConstants.QUEUE_MONITOR_WAITING_TIME_TOTAL, getTotalWaitingTime());
		statistics.put(IStatsConstants.QUEUE_MONITOR_WAITING_TIME_SINCE_QUEUE_EMPTY, getWaitingTimeSincQueueEmptied());
		return statistics;
	}
}

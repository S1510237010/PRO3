package at.fhhagenberg.mc.traffsim.vehicle.model;

public enum ChannelModels {

	UNIFORM("Uniformly Distributed Channel Model", "UniChannel"), GEOMETRIC("Geometric Distributed Channel Model",
			"GeomChannel"), GILBERT_ELLIOT("Gilbert Elliot Model", "GEChannel");

	public static ChannelModels valueOfLabel(String label) {
		for (ChannelModels c : ChannelModels.values()) {
			if (c.toString().equals(label)) {
				return c;
			}
		}

		return null;
	}

	private String shortName;

	private String type;

	private ChannelModels(final String type, final String shortName) {
		this.type = type;
		this.shortName = shortName;
	}

	public String getShortName() {
		return shortName;
	}

	@Override
	public String toString() {
		return type;
	}
}

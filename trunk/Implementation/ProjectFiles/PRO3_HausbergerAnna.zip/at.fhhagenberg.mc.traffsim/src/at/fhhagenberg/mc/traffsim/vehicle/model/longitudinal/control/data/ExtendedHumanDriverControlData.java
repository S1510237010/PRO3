package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.data;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.RTDataBean;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalControlData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.ResponseTimeSet;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers.SpatialAnticipation;

public class ExtendedHumanDriverControlData extends LongitudinalControlData {

	/** Unique model identifier */
	private static final String IDENTIFIER = "EHDMx";

	// Noise and distraction models
	private String accelerationNoiseIdentifier;
	private String distanceNoiseIdentifier;
	private String velocityDifferenceNoiseIdentifier;

	// Spatial anticipation
	private SpatialAnticipation spatialAnticipation;

	// Finite reaction times and timely anticipation
	private ResponseTimeSet responseTimes;

	// Driving regimes
	private double spaceHeadwayThreshold;

	public ExtendedHumanDriverControlData() {
		setIdentifier(IDENTIFIER);
	}

	public ExtendedHumanDriverControlData(String distanceNoise, String velocityDifferenceNoise, String accelerationNoise, RTDataBean rtSet,
			int numConsideredVehicles, double sightDistance, double spaceHeadwayThreshold) {

		setIdentifier(IDENTIFIER);

		// Noises
		setDistanceNoiseIdentifier(distanceNoise);
		setVelocityDifferenceNoiseIdentifier(velocityDifferenceNoise);
		setAccelerationNoiseIdentifier(accelerationNoise);

		// Spatial Anticipation
		setSpatialAnticipation(new SpatialAnticipation(numConsideredVehicles, sightDistance));

		// Headway threshold
		setSpaceHeadwayThreshold(spaceHeadwayThreshold);

		// Delays
		double expected = rtSet.getExpected();
		double unexpected = rtSet.getUnexpected();
		double driveAway = rtSet.getDriveAway();
		double timeHeadway = rtSet.getTimeHeadway();
		boolean isReactive = rtSet.getIsReactive();
		boolean isAnticipative = rtSet.getIsAnticipative();
		setResponseTimes(new ResponseTimeSet(expected, unexpected, driveAway, timeHeadway, isReactive, isAnticipative));
	}

	public String getAccelerationNoiseIdentifier() {
		return accelerationNoiseIdentifier;
	}

	public void setAccelerationNoiseIdentifier(String accelerationNoiseIdentifier) {
		this.accelerationNoiseIdentifier = accelerationNoiseIdentifier;
	}

	public String getDistanceNoiseIdentifier() {
		return distanceNoiseIdentifier;
	}

	public void setDistanceNoiseIdentifier(String distanceNoiseIdentifier) {
		this.distanceNoiseIdentifier = distanceNoiseIdentifier;
	}

	public String getVelocityDifferenceNoiseIdentifier() {
		return velocityDifferenceNoiseIdentifier;
	}

	public void setVelocityDifferenceNoiseIdentifier(String velocityDifferenceNoiseIdentifier) {
		this.velocityDifferenceNoiseIdentifier = velocityDifferenceNoiseIdentifier;
	}

	public SpatialAnticipation getSpatialAnticipation() {
		return spatialAnticipation;
	}

	public void setSpatialAnticipation(SpatialAnticipation spatialAnticipation) {
		this.spatialAnticipation = spatialAnticipation;
	}

	public ResponseTimeSet getResponseTimes() {
		return responseTimes;
	}

	public void setResponseTimes(ResponseTimeSet responseTimes) {
		this.responseTimes = responseTimes;
	}

	public double getSpaceHeadwayThreshold() {
		return spaceHeadwayThreshold;
	}

	public void setSpaceHeadwayThreshold(double spaceHeadwayThreshold) {
		this.spaceHeadwayThreshold = spaceHeadwayThreshold;
	}
}

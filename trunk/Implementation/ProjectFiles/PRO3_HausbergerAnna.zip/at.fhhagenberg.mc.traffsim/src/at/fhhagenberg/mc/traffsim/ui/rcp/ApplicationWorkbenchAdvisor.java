package at.fhhagenberg.mc.traffsim.ui.rcp;

import org.eclipse.ui.IViewReference;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.IWorkbenchConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchAdvisor;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.Logger;

public class ApplicationWorkbenchAdvisor extends WorkbenchAdvisor {

	private static final String PERSPECTIVE_ID = "at.fhhagenberg.mc.traffsim.ui.rcp.perspective";

	@Override
	public WorkbenchWindowAdvisor createWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		return new ApplicationWorkbenchWindowAdvisor(configurer);
	}

	@Override
	public String getInitialWindowPerspectiveId() {
		return PERSPECTIVE_ID;
	}

	@Override
	public void initialize(IWorkbenchConfigurer configurer) {
		super.initialize(configurer);
		configurer.setSaveAndRestore(true);
	}

	@Override
	public void postStartup() {
		PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().addPartListener(SimulationKernel.getInstance());
		PlatformUI.getWorkbench().addWorkbenchListener(SimulationKernel.getInstance());
		SimulationKernel.getInstance().startup();
	}

	@Override
	public boolean preShutdown() {
		// close all views
		try {
			IViewReference[] refs = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getViewReferences();
			for (int i = 0; i < refs.length; ++i) {
				PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().hideView(refs[i]);
			}
		} catch (NullPointerException ex) {
			Logger.logWarn("Could not close views ", ex);
		}
		PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().closeAllPerspectives(false, true);
		return super.preShutdown();
	}
}

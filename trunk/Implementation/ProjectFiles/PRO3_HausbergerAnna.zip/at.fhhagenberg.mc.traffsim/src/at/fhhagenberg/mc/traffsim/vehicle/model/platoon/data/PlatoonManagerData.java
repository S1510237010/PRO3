package at.fhhagenberg.mc.traffsim.vehicle.model.platoon.data;

import java.util.List;

/**
 * Data entity for the platoon manager, also holds predefined platoon action
 *
 * @author Sebastian Huber
 *
 */
public class PlatoonManagerData {

	/**
	 * Parameters for platoon creation
	 */
	private PlatoonData platoonData;

	/**
	 * Timeout for retrying an action in the action queue if not succeed
	 */
	private long actionTimeout;

	/**
	 * List of predefined platoon actions
	 */
	private List<PlatoonActionData> platoonActions;

	/**
	 * Empty CTor
	 */
	public PlatoonManagerData() {
		super();
	}

	/**
	 * CTor
	 *
	 * @param platoonData
	 *            Configuration for platoon creations
	 * @param actionTimeout
	 *            timeout for platoon action
	 * @param platoonActions
	 *            predefined platoon actions
	 */
	public PlatoonManagerData(PlatoonData platoonData, long actionTimeout, List<PlatoonActionData> platoonActions) {
		super();
		this.platoonData = platoonData;
		this.actionTimeout = actionTimeout;
		this.platoonActions = platoonActions;
	}

	/**
	 * Get parameters for platoon creation
	 *
	 * @return platoon data
	 */
	public PlatoonData getPlatoonData() {
		return platoonData;
	}

	/**
	 * Set parameters for platoon creation
	 *
	 * @param platoonData
	 *            platoon data
	 */
	public void setPlatoonData(PlatoonData platoonData) {
		this.platoonData = platoonData;
	}

	/**
	 * Get timeout for retrying a platoon action before it is removed from queue
	 *
	 * @return timeout
	 */
	public long getActionTimeout() {
		return actionTimeout;
	}

	/**
	 * Set timeout for retrying a platoon action before it is removed from queue
	 *
	 * @param actionTimeout
	 *            timeout
	 */
	public void setActionTimeout(long actionTimeout) {
		this.actionTimeout = actionTimeout;
	}

	/**
	 * Predefined platoon actions
	 *
	 * @return platoon actions
	 */
	public List<PlatoonActionData> getPlatoonActions() {
		return platoonActions;
	}

	/**
	 * Predefined platoon action
	 *
	 * @param platoonActions
	 *            platoon actions
	 */
	public void setPlatoonActions(List<PlatoonActionData> platoonActions) {
		this.platoonActions = platoonActions;
	}
}

package at.fhhagenberg.mc.traffsim.roadnetwork.junction;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSign;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;

@XStreamAlias("JunctionConnector")
public class JunctionConnector extends VehiclesLane {

	private AbstractJunction junction;
	private TrafficLight trafficLight;
	private RoadSign roadSign;
	private int priority = PriorityState.NOT_AVAILABLE;

	/** smoothing and width factor for storage of info */
	private double shrinkFactor = -1;
	private int smoothing = -1;

	public JunctionConnector(long id, AbstractJunction abstractJunction, List<Vector> path, LaneSegment source, LaneSegment destination) {
		if (id > 0) {
			setId(id);
		} else {
			setId(NEXT_ID++);
		}

		roadGeometry = new RoadGeometry();
		roadGeometry.setPoints(path);
		this.sourceLaneSegment = source;
		this.sinkLaneSegment = destination;
		this.junction = abstractJunction;
		speedLimit = junction.getSpeedLimitMps();
	}

	@Override
	public void addVehicle(Vehicle vehicle) {
		this.vehicles.add(vehicle);
		vehicle.setLaneSegment(this);
		ensureVehiclesSorted();
	}

	@Override
	public VehicleWithDistance frontVehicle(Vehicle me) {
		double position = me.getFrontPosition();
		double distance = 0;
		int index = positionBinarySearch(position);
		final int insertionPoint = -index - 1;
		Vehicle result = null;
		if (index >= 0) {
			// exact match found
			if (index + 1 < vehicles.size()) {
				result = vehicles.get(index + 1);
			}
		} else if (insertionPoint >= 0 && insertionPoint < vehicles.size()) {
			result = vehicles.get(insertionPoint);
		}
		if (result != null) {
			return new VehicleWithDistance(result, distance + result.getRearPosition() - position);
		}
		// check crossing vehicles through implementatino of junction
		VehicleWithDistance junctionResult = junction.frontVehicle(me, this);
		if (junctionResult != null) {
			return junctionResult;
		}
		if (sinkLaneSegment != null) {
			distance = distance + roadGeometry.getRoadLength() - position;
			return sinkLaneSegment.frontVehicle(me, 0, distance);
		}
		return null;
	}

	public AbstractJunction getJunction() {
		return junction;
	}

	@Override
	public String toString() {
		return "#" + getId() + " prio " + PriorityState.toString(priority) + " |  Source: RS-" + sourceLaneSegment.getRoadSegment().getId() + " ("
				+ sourceLaneSegment.getRoadSegment().getRoutingId() + "), lane " + sourceLaneSegment.getLaneIndex() + " | Sink: RS-"
				+ sinkLaneSegment.getRoadSegment().getId() + " (" + sinkLaneSegment.getRoadSegment().getRoutingId() + "), lane "
				+ sinkLaneSegment.getLaneIndex();
	}

	public RoadSign getRoadSign() {
		return roadSign;
	}

	public int getLane() {
		if (sourceLaneSegment == null) {
			return -1;
		}

		return sourceLaneSegment.getLaneIndex();
	}

	public void setRoadSign(RoadSign roadSign) {
		this.roadSign = roadSign;
	}

	/**
	 * Convenience method, combination of {@link #setRoadSign(RoadSign)} and {@link #setPriority(int)}
	 *
	 * @param type
	 */
	public void setRoadSignAndPriority(RoadSign.Type type) {
		this.roadSign = new RoadSign(type);
		this.priority = RoadSign.getPriority(type);
	}

	public int getPriority() {
		return priority;
	}

	public boolean isPriorityAvailable() {
		return getTrafficLight() != null || roadSign != null || getPriority() != PriorityState.NOT_AVAILABLE;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * Resets the priority to not available state and clears road sign
	 */
	public void resetPriority() {
		setPriority(PriorityState.NOT_AVAILABLE);
		setRoadSign(null);
	}

	public double getShrinkFactor() {
		return shrinkFactor;
	}

	public void setShrinkFactor(double shrinkFactor) {
		this.shrinkFactor = shrinkFactor;
	}

	public int getSmoothing() {
		return smoothing;
	}

	public void setSmoothing(int smoothing) {
		this.smoothing = smoothing;
	}

	public TrafficLight getTrafficLight() {
		return trafficLight;
	}

	public void setTrafficLight(TrafficLight trafficLight) {
		this.trafficLight = trafficLight;
	}

	public static String createIdentifier(final JunctionConnector conn) {
		return String.format("J%d_S%d_D%d", conn.getJunction().getId(), conn.getSourceLaneSegment().getLaneIndex(),
				conn.getSinkLaneSegment().getLaneIndex());
	}

	@Override
	public double getSpeedLimitMps() {
		return getJunction().getSpeedLimitMps();
	}

}

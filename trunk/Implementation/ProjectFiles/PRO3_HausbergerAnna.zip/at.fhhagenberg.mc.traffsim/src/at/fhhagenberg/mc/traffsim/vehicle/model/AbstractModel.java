package at.fhhagenberg.mc.traffsim.vehicle.model;

public abstract class AbstractModel {

	/**
	 * Gets a human readable name of this model, which describes it shortly.
	 * 
	 * @return human readable name
	 */
	public abstract String getName();
}

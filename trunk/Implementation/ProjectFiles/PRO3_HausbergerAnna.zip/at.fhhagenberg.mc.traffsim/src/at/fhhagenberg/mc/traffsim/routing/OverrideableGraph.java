package at.fhhagenberg.mc.traffsim.routing;

import java.io.File;

import de.cm.osm2po.routing.Graph;
import de.cm.osm2po.routing.GraphCostsOverrider;

/**
 * Overriden {@link Graph}, which is able to change the costs for specific segment ids and therefore influence routing behavior
 * 
 * @author Christian Backfrieder
 * 
 */
public class OverrideableGraph extends Graph {

	GraphCostsOverrider hOverrider, kmOverrider;
	int[] edgeIdxs;

	public OverrideableGraph(File graphFile) {
		super(graphFile);
	}

	/**
	 * Sets a {@link GraphCostsOverrider} which is used to override the edge time costs
	 * 
	 * @param overrider
	 */
	public void setHOverrider(GraphCostsOverrider overrider) {
		this.hOverrider = overrider;
	}

	/**
	 * Sets a {@link GraphCostsOverrider} which is used to override the edge kilometer costs
	 * 
	 * @param overrider
	 */
	public void setKmOverrider(GraphCostsOverrider overrider) {
		this.kmOverrider = overrider;
	}

	@Override
	public float[] getEdgeCostsH() {
		if (hOverrider != null) {
			return hOverrider.getCurrentCosts();
		}
		return super.getEdgeCostsH();
	}

	@Override
	public float[] getEdgeCostsKm() {
		if (kmOverrider != null) {
			return kmOverrider.getCurrentCosts();
		}
		return super.getEdgeCostsKm();
	}

	public static int toEdgeId(long segId, boolean reverse) {
		return (int) (segId - 1 << 1) + (reverse ? 1 : 0);
	}

	/**
	 * Returns the time costs for a road segment, identified by its routing id and a direction
	 * 
	 * @param segId
	 * @param reverse
	 * @return time cost in hours
	 */
	public float getHCostsForSegment(long segId, boolean reverse) {
		int edgeId = toEdgeId(segId, reverse);
		return getHCostsForEdge(edgeId);
	}

	/**
	 * Returns the distance costs for a road segment, identified by its routing id and a direction
	 * 
	 * @param segId
	 * @param reverse
	 * @return distance cost in kilometers
	 */
	public float getKmCostsForSegment(long segId, boolean reverse) {
		int edgeId = toEdgeId(segId, reverse);
		return getKmCostsForEdge(edgeId);
	}

	public float getHCostsForEdge(int edgeId) {
		int edgeIdx = getEdgeIdxs()[edgeId];
		return hOverrider.getCurrentCosts()[edgeIdx];
	}

	public float getKmCostsForEdge(int edgeId) {
		int edgeIdx = getEdgeIdxs()[edgeId];
		return kmOverrider.getCurrentCosts()[edgeIdx];

	}

	public int[] getEdgeIdxs() {
		if (edgeIdxs == null) {
			edgeIdxs = createTransformedEdgeIndex();
		}
		return edgeIdxs;
	}

}

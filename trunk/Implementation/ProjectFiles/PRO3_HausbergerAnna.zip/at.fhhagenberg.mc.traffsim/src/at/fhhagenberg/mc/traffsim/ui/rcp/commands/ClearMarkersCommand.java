package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;

public class ClearMarkersCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

	@Override
	public void dispose() {
		// unused
	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		SimulationKernel.getInstance().getActiveModel().getUiModel().clearPoints();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return SimulationKernel.getInstance().isModelActive();
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

}

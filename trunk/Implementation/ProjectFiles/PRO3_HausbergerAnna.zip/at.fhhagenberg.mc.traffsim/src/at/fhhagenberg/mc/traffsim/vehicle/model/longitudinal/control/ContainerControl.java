package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control;

import java.util.ArrayList;
import java.util.List;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.ILongitudinalModel;

/**
 * This class provides the functionalities to manage multiple longitudinal controls and switch between those. The container behaves like an
 * ordinary LongitudinalControl by simply invoking the respective function calls on the currently active longitudinal control. Classes
 * inherting from this one need to take care of deciding which of its child controls has to be used at a certain point in time.
 *
 * @author Manuel Lindorfer
 *
 */
public abstract class ContainerControl extends LongitudinalControl<ILongitudinalModel> {

	protected List<LongitudinalControl<ILongitudinalModel>> childControls;
	protected LongitudinalControl<ILongitudinalModel> activeControl;

	public ContainerControl() {
		childControls = new ArrayList<>();
	}

	public ContainerControl(String identifier) {
		super(identifier);
		childControls = new ArrayList<>();
	}

	@Override
	public ContainerControl copy(double vTarget) {
		ContainerControl copy = new Kryo().copy(this);

		for (LongitudinalControl<ILongitudinalModel> childControl : childControls) {
			childControl.getLongitudinalModel().getModelData().setvTarget(vTarget);
		}

		return copy;
	}

	public List<LongitudinalControl<ILongitudinalModel>> getChildControls() {
		return childControls;
	}

	@Override
	protected AccUpdateData getAccUpdateData(Vehicle me) {
		return activeControl.getAccUpdateData(me);
	}

	public void setChildControls(List<LongitudinalControl<ILongitudinalModel>> childControls) {
		assert childControls != null && !childControls.isEmpty() : "Child controls cannot be null or empty.";
		this.childControls = childControls;

		// Set first child control active per default
		activeControl = childControls.get(0);

		// Verify whether the given set of child contols is valid
		validate();
	}

	public void addChildControl(LongitudinalControl<ILongitudinalModel> childControl) {
		if (childControl != null && !childControls.contains(childControl)) {
			childControls.add(childControl);
		}
	}

	public void removeChildControl(LongitudinalControl<ILongitudinalModel> childControl) {
		if (childControl != null && childControls.contains(childControl)) {
			childControls.remove(childControl);
		}
	}

	public LongitudinalControl<ILongitudinalModel> getActiveControl() {
		return activeControl;
	}

	public void setActiveControl(LongitudinalControl<ILongitudinalModel> activeControl) {
		assert activeControl != null : "The active control cannot be null.";
		this.activeControl = activeControl;
	}

	/**
	 * Overwritten methods
	 */
	@Override
	public void update(double dt, double simulationTime) {
		super.update(dt, simulationTime);

		for (LongitudinalControl<ILongitudinalModel> childControl : childControls) {
			childControl.update(dt, simulationTime);
		}
	}

	@Override
	public ILongitudinalModel getLongitudinalModel() {
		return activeControl.getLongitudinalModel();
	}

	@Override
	public double calcAccSolitary(Vehicle me, VehiclesLane lane) {
		return activeControl.calcAccSolitary(me, lane);
	}

	@Override
	public double calcAccSolitary(Vehicle me, VehiclesLane seg, int lookForward, Vehicle virtualFront, double virtualFrontDistance) {
		return activeControl.calcAccSolitary(me, seg, lookForward, virtualFront, virtualFrontDistance);
	}

	@Override
	public double calcAccComprehensive(Vehicle me, double alphaT, double alphaV0, double alphaA) {
		return activeControl.calcAccComprehensive(me, alphaT, alphaV0, alphaA);
	}

	public abstract void validate();
}

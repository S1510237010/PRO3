package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSignGenerator;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.roadsign.RoadSignGeneratorWizard;

public class RoadSignGeneratorCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final RoadSignGeneratorWizard wizard = new RoadSignGeneratorWizard();
		WizardDialog dialog = new WizardDialog(Display.getCurrent().getActiveShell(), wizard);
		int result = dialog.open();
		if (result == Dialog.CANCEL) {
			return null;
		}
		Job job = new Job("Road sign generation") {

			@Override
			protected IStatus run(IProgressMonitor monitor) {
				RoadSignGenerator gen = new RoadSignGenerator(SimulationKernel.getInstance().getActiveModel());
				gen.generateSigns(wizard.getGenerationParameters().stopSignFactor, wizard.getGenerationParameters().givewayThresholdFactor,
						wizard.getGenerationParameters().roundaboutOnly, wizard.getGenerationParameters().tJunctions,
						wizard.getGenerationParameters().spdRangeMin, wizard.getGenerationParameters().spdRangeMax);
				return Status.OK_STATUS;
			}
		};
		job.setUser(true);
		job.schedule();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
	}

}

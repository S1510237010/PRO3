package at.fhhagenberg.mc.traffsim.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.generator.AbstractVehicleGenerator;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.types.IDisposable;

/**
 * This class is the main driver for the simulation and holds the thread responsible for all updates.
 *
 * @author Christian B.
 *
 */
public class SimulationRun implements IDisposable {
	private List<ISimulationTimeUpdatable> simulationDrivers = new CopyOnWriteArrayList<>();

	private ISimulationFinishedListener simulationFinishedListener;
	private double runtime = 0;
	private Date currentSimTime;
	private final Date startSimTime;
	private long startRealTime;
	private long lastPauseStart;
	private long pausedMillis;

	public double getRunningSimtimeSeconds() {
		return runtime;
	}

	private class SimulationRunnable extends PauseableThread implements IPropertyChangeListener {
		private boolean boundSimRuntime = PreferenceUtil.getBoolean(IPreferenceConstants.BOUND_SIMULATION_RUNTIME);
		private int maxSimRuntime = PreferenceUtil.getInt(IPreferenceConstants.MAX_SIMULATION_RUNTIME);

		public SimulationRunnable(String name, long delayInMillis) {
			super(name, delayInMillis);
			PreferenceUtil.addPropertyChangeListener(this);
		}

		@Override
		public void doWork() {
			currentSimTime = new Date(currentSimTime.getTime() + resolution);
			runtime += resolution / 1000.0;

			for (ISimulationTimeUpdatable s : simulationDrivers) {
				s.timeStep(resolution / 1000.0, getCurrentSimTime(), runtime);
			}

			if (boundSimRuntime && runtime >= maxSimRuntime && simulationFinishedListener != null) {
				simulationFinishedListener.simulationFinished();
			}
		}

		@Override
		public void propertyChange(PropertyChangeEvent event) {
			if (event.getProperty().equals(IPreferenceConstants.BOUND_SIMULATION_RUNTIME)) {
				boundSimRuntime = (boolean) event.getNewValue();
			} else if (event.getProperty().equals(IPreferenceConstants.MAX_SIMULATION_RUNTIME)) {
				maxSimRuntime = (int) event.getNewValue();
			}
		}

		@Override
		protected void preStop() {
			PreferenceUtil.removePropertyChangeListener(this);
		}
	}

	final SimulationRunnable simulationThread;
	private int resolution;

	private IPropertyChangeListener propListener;

	public SimulationRun(String threadName, Date startTime, int simulationResolution, int simulationDelay) {
		this.startSimTime = startTime;
		currentSimTime = startTime;
		this.resolution = simulationResolution;
		propListener = new IPropertyChangeListener() {

			@Override
			public void propertyChange(PropertyChangeEvent event) {
				if (event.getProperty().equals(IPreferenceConstants.SIMULATION_DELAY_MS)) {
					simulationThread.setDelayInMillis((int) event.getNewValue());
				} else if (event.getProperty().equals(IPreferenceConstants.SIMULATION_RESOLUTION_MS)) {
					resolution = (int) event.getNewValue();
				}
			}
		};

		simulationThread = new SimulationRunnable(threadName, simulationDelay);

		PreferenceUtil.addPropertyChangeListener(propListener);
	}

	public ISimulationFinishedListener getSimulationFinishedListener() {
		return simulationFinishedListener;
	}

	public void setSimulationFinishedListener(ISimulationFinishedListener simulationFinishedListener) {
		this.simulationFinishedListener = simulationFinishedListener;
	}

	public void addSimulationTimeUpdatable(ISimulationTimeUpdatable step) {
		simulationDrivers.add(step);
	}

	public void removeSimulationTimeUpdatable(ISimulationTimeUpdatable step) {
		if (simulationDrivers.contains(step)) {
			simulationDrivers.remove(step);
		}
	}

	public boolean isSimulationRunning() {
		return simulationThread != null && simulationThread.isAlive() && !simulationThread.isPaused();
	}

	public void setSimulationRunning(boolean setRunning) {
		if (setRunning) {
			if (simulationThread.isAlive()) {
				if (simulationThread.isPaused()) {
					simulationThread.proceed();
					pausedMillis += System.currentTimeMillis() - lastPauseStart;
				}
			} else {
				simulationThread.start();
				startRealTime = System.currentTimeMillis();
			}
		} else {
			simulationThread.pause();
			lastPauseStart = System.currentTimeMillis();
		}
	}

	public void setDelay(long value) {
		simulationThread.setDelayInMillis(value);
	}

	public long getDelay() {
		return simulationThread.getDelayInMillis();
	}

	public void setResolution(int newMiliSeconds) {
		this.resolution = newMiliSeconds;
	}

	public int getResolution() {
		return resolution;
	}

	public AbstractVehicleGenerator getTrafficGenerator(int id) {
		for (ISimulationTimeUpdatable ts : simulationDrivers) {
			if (ts instanceof AbstractVehicleGenerator && (((AbstractVehicleGenerator) ts).getId() == id)) {
				return (AbstractVehicleGenerator) ts;
			}
		}
		return null;
	}

	public List<Long> getTrafficGeneratorIds() {
		List<Long> ids = new ArrayList<Long>();
		for (ISimulationTimeUpdatable ts : simulationDrivers) {
			if (ts instanceof AbstractVehicleGenerator) {
				ids.add(((AbstractVehicleGenerator) ts).getId());
			}
		}
		return ids;
	}

	@Override
	public void dispose() {
		if (simulationThread != null) {
			simulationThread.stopAndDestroy();
		}
		simulationDrivers.clear();
		PreferenceUtil.removePropertyChangeListener(propListener);
	}

	public Date getCurrentSimTime() {
		return currentSimTime;
	}

	public Date getStartSimTime() {
		return startSimTime;
	}

	public long getRunningRealtimeMillis() {
		return System.currentTimeMillis() - startRealTime - pausedMillis;
	}

	public long getRunningSimtimeMilliseconds() {
		return Math.round(runtime * 1000);
	}
}

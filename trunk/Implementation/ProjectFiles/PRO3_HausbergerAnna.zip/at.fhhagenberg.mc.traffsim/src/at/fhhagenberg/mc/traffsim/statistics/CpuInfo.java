package at.fhhagenberg.mc.traffsim.statistics;

/**
 * Container for CPU information, containing speed and cores
 * @author lokal
 *
 */
public class CpuInfo {
	private String label;
	private int cores;
	private String vendor;
	private int clockFrequency;

	/**
	 * 
	 * @param label
	 *            model name of cpu
	 * @param cores
	 *            number of total cores
	 * @param vendor
	 *            vendor
	 * @param clockFrequency the clock frequency in MHz
	 */
	public CpuInfo(String label, int cores, String vendor, int clockFrequency) {
		super();
		this.label = label;
		this.cores = cores;
		this.vendor = vendor;
		this.clockFrequency = clockFrequency;
	}

	public String getLabel() {
		return label;
	}

	public int getCores() {
		return cores;
	}

	public String getVendor() {
		return vendor;
	}

	public int getClockFrequency() {
		return clockFrequency;
	}

	public String getSummary() {
		return String.format("%s (Vendor: %s, Cores: %d, Clock: %d MHz)", label, vendor, cores, clockFrequency);
	}
}

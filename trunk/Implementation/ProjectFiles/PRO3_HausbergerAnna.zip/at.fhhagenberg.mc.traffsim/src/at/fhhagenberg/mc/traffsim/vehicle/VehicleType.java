package at.fhhagenberg.mc.traffsim.vehicle;

public enum VehicleType {
	CAR("Car"), OBSTACLE("Obstacle"), TRUCK("Truck"), OBSTRUCTION("Obstruction"), NONE("None");

	private String type;

	private VehicleType(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type;
	}

	public static VehicleType valueOfLabel(String label) {
		for (VehicleType t : VehicleType.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}
		return null;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.data;

import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeModel;

/**
 * Data entity for pltooning lane change model
 *
 * @author Sebastian Huber
 *
 */
public class CACCLaneChangeData extends AbstractLaneChangeModelData {

	/**
	 * Human lane change model
	 */
	LaneChangeModel humanModel;

	/**
	 * Leader lane change model
	 */
	LaneChangeModel leaderModel;

	/**
	 * Flag to enable leader model for lane changes of platoon
	 */
	private boolean platoonLaneChangeEnabled;

	/**
	 * Minimum distance between vehicles
	 */
	private double sMin;

	/**
	 * Max deceleration of vehicle
	 */
	private double maxDec;

	/**
	 * Safe deceleration of vehicle
	 */
	private double safeDec;

	/**
	 * Empty CTor
	 */
	public CACCLaneChangeData() {

	}

	/**
	 * Get human lane change model
	 *
	 * @return lane change model
	 */
	public LaneChangeModel getHumanModel() {
		return humanModel;
	}

	/**
	 * Set human lane chane model
	 *
	 * @param humanModel
	 *            lane change model
	 */
	public void setHumanModel(LaneChangeModel humanModel) {
		this.humanModel = humanModel;
	}

	/**
	 * Get leader lane model
	 *
	 * @return model
	 */
	public LaneChangeModel getLeaderModel() {
		return leaderModel;
	}

	/**
	 * Set leader lane model
	 * 
	 * @param leaderModel
	 *            model
	 */
	public void setLeaderModel(LaneChangeModel leaderModel) {
		this.leaderModel = leaderModel;
	}

	/**
	 * Get flag for enabling lane changes for platoon
	 *
	 * @return enabled
	 */
	public boolean isPlatoonLaneChangeEnabled() {
		return platoonLaneChangeEnabled;
	}

	/**
	 * Set flag for enabling lane changes for platoon
	 *
	 * @param platoonLaneChangeEnabled
	 *            enabled
	 */
	public void setPlatoonLaneChangeEnabled(boolean platoonLaneChangeEnabled) {
		this.platoonLaneChangeEnabled = platoonLaneChangeEnabled;
	}

	/**
	 * Minimum distance between human controlled vehicles
	 *
	 * @return sMin
	 */
	public double getsMin() {
		return sMin;
	}

	/**
	 * Minimum distance between human controlled vehicles
	 *
	 * @param sMin
	 *            sMin
	 */
	public void setsMin(double sMin) {
		this.sMin = sMin;
	}

	/**
	 * Max deceleration of vehicle
	 *
	 * @return MaxDec
	 */
	public double getMaxDec() {
		return maxDec;
	}

	/**
	 * Max deceleration of vehicle
	 *
	 * @param maxDec
	 *            macDec
	 */
	public void setMaxDec(double maxDec) {
		this.maxDec = maxDec;
	}

	/**
	 * Safe deceleration of vehicle
	 *
	 * @return safeDec
	 */
	public double getSafeDec() {
		return safeDec;
	}

	/**
	 * Safe deceleration of vehicle
	 *
	 * @param safeDec
	 *            safeDec
	 */
	public void setSafeDec(double safeDec) {
		this.safeDec = safeDec;
	}

}

package at.fhhagenberg.mc.traffsim.ui.dialogs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;

import at.fhhagenberg.mc.traffsim.model.init.ParameterKeyComparator;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.BitUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class ParameterSetSelectionDialog extends Dialog {
	private Table table;
	private List<String> setNames = new ArrayList<>();
	protected List<String> selectedElements = new ArrayList<>();

	public ParameterSetSelectionDialog(Shell parent, Set<String> names) {
		super(parent);
		setNames.addAll(names);
		Collections.sort(setNames, new ParameterKeyComparator());
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		GridData gd = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd.heightHint = 300;
		container.setLayoutData(gd);
		container.setLayout(new GridLayout(1, false));

		final CheckboxTableViewer checkboxTableViewer = CheckboxTableViewer.newCheckList(container, SWT.BORDER | SWT.V_SCROLL | SWT.FULL_SELECTION);
		table = checkboxTableViewer.getTable();
		table.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (BitUtil.checkMask(e.detail, SWT.CHECK)) {
					selectedElements = new ArrayList<>();
					for (TableItem ti : table.getItems()) {
						if (ti.getChecked()) {
							selectedElements.add(ti.getText());
						}
					}
				}
			}
		});
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		checkboxTableViewer.setLabelProvider(new LabelProvider());
		checkboxTableViewer.setContentProvider(new IStructuredContentProvider() {

			@Override
			public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
				// nothing
			}

			@Override
			public void dispose() {
				// nothing
			}

			@Override
			public Object[] getElements(Object inputElement) {
				return ((List<?>) inputElement).toArray();
			}
		});
		checkboxTableViewer.setInput(setNames);

		String lastChecked = PreferenceUtil.getString(IPreferenceConstants.LAST_SELECTED_PARAMETER_SETS, "");
		if (StringUtil.isNotNullOrEmpty(lastChecked) && StringUtil.isNotNullOrEmpty(lastChecked.substring(1, lastChecked.length() - 1))
				&& PreferenceUtil.getInt(IPreferenceConstants.LAST_SELECTED_PARAMETER_COUNT) == table.getItemCount()) {
			int[] arr = Arrays.stream(lastChecked.substring(1, lastChecked.length() - 1).split(",")).map(String::trim).mapToInt(Integer::parseInt)
					.toArray();
			for (Integer checkedIndex : arr) {
				checkboxTableViewer.setChecked(checkboxTableViewer.getElementAt(checkedIndex), true);
				selectedElements.add(checkboxTableViewer.getElementAt(checkedIndex).toString());
			}
		}
		if (setNames.size() == 1) {
			checkboxTableViewer.setChecked(checkboxTableViewer.getElementAt(0), true);
			selectedElements.add(checkboxTableViewer.getElementAt(0).toString());
		}

		return container;
	}

	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Property set selection");
	}

	public List<String> getSelectedElements() {
		return selectedElements;
	}

	@Override
	protected void okPressed() {
		List<Integer> checked = new ArrayList<>();
		for (TableItem it : table.getItems()) {
			if (it.getChecked()) {
				checked.add(table.indexOf(it));
			}
		}
		PreferenceUtil.set(IPreferenceConstants.LAST_SELECTED_PARAMETER_SETS, checked.toString());
		PreferenceUtil.setInt(IPreferenceConstants.LAST_SELECTED_PARAMETER_COUNT, table.getItemCount());
		super.okPressed();
	}
}

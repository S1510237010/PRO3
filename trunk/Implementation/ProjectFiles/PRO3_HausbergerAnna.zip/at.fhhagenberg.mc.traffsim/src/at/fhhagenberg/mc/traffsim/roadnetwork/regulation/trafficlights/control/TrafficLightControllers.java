package at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control;

/**
 * Enumeration for indicating the control scheme used by traffic light controllers.
 *
 * @author Manuel Lindorfer
 *
 */
public enum TrafficLightControllers {
	CYCLIC("Cyclic"), FIXED_TIMED("Fixed Time"), SELF_ORGANIZING("Self-organizing");

	public static TrafficLightControllers valueOfLabel(String label) {
		for (TrafficLightControllers t : TrafficLightControllers.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}

		return null;
	}

	private String type;

	private TrafficLightControllers(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type;
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.views.filter;

/**
 * Element which enables filtering by providing a {@link String} representation of the whole object
 * 
 * @author Christian Backfrieder
 * 
 */
public interface IFilterEnabledElement {
	/**
	 * 
	 * @return The string representation of this object, containing all information which is applicable for filtering
	 */
	public String getInfoAsString();
}

package at.fhhagenberg.mc.traffsim.vehicle;

public interface IVehicleGeneratorListener {
	/**
	 * This method is called as soon as the implementor of the interface creates a vehicle.
	 * 
	 * @param vehicle
	 */
	public void vehicleGenerated(Vehicle vehicle);
}

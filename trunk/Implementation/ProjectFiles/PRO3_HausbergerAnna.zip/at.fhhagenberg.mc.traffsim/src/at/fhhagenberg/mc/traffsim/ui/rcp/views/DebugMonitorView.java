package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.statistics.events.DebugEvent;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.statistics.events.IEventListener;
import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.filter.DefaultViewerFilter;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.DateUtil;

/**
 *
 * @author Manuel Lindorfer
 *
 */
public class DebugMonitorView extends BaseTableViewerView implements IEventListener {

	protected List<Event> events;
	protected Text textFind;
	protected Text textFilter;
	protected Button btnFilter;
	protected Button btnExportCsv;
	protected SimulationModel currentModel;

	private class DebugMonitorComparator extends BaseViewerComparator {
		@Override
		public int compare(Viewer viewer, Object e1, Object e2) {
			Event evt1 = (Event) e1;
			Event evt2 = (Event) e2;
			int rc = 0;

			switch (propertyIndex) {
			case 0:
				rc = new Long(evt1.getId()).compareTo(evt2.getId());
				break;
			case 1:
				rc = new Long(evt1.getContinuousNumber()).compareTo(evt2.getContinuousNumber());
				break;
			case 2:
				rc = evt1.getType().toString().compareTo(evt2.getType().toString());
				break;
			case 3:
				rc = DateUtil.formatWithMiliseconds(evt1.getTimestamp()).compareTo(DateUtil.formatWithMiliseconds(evt2.getTimestamp()));
				break;
			case 4:
				rc = evt1.getTypeInfo().compareTo(evt2.getTypeInfo());
				break;
			case 5:
				rc = evt1.getDetails().toString().compareTo(evt2.getDetails().toString());
				break;
			default:
				rc = 0;
			}

			// If descending order, flip the direction
			if (direction == DESCENDING) {
				rc = -rc;
			}

			return rc;
		}
	}

	@Override
	public void dispose() {
		removeEventListener();
		super.dispose();
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout(SWT.HORIZONTAL));

		// Set the sorter for the table
		comparator = new DebugMonitorComparator();

		Composite composite_1 = new Composite(parent, SWT.NONE);
		composite_1.setLayout(new GridLayout(1, false));

		Composite compositeTop = new Composite(composite_1, SWT.NONE);
		compositeTop.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));
		compositeTop.setLayout(new GridLayout(6, false));

		textFind = new Text(compositeTop, SWT.BORDER);
		textFind.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		textFind.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.keyCode == SWT.CR || e.keyCode == SWT.KEYPAD_CR) {
					doFind();
				}
			}
		});
		Button btnFind = new Button(compositeTop, SWT.NONE);
		btnFind.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				doFind();
			}
		});
		btnFind.setText("Find");

		textFilter = new Text(compositeTop, SWT.BORDER);
		textFilter.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btnFilter = new Button(compositeTop, SWT.TOGGLE);
		btnFilter.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnFilter.getSelection()) {
					btnFilter.setText("Filter ON");
					refreshFilter(textFilter.getText());
				} else {
					btnFilter.setText("Filter OFF");
					refreshFilter("");
				}
			}
		});
		btnFilter.setText("Filter OFF");

		btnExportCsv = new Button(compositeTop, SWT.NONE);
		btnExportCsv.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				doExportCsv();
			}
		});
		btnExportCsv.setText("Export CSV");

		textFilter.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (btnFilter.getSelection()) {
					refreshFilter(textFilter.getText());
				}
			}
		});

		Composite composite = new Composite(composite_1, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		composite.setLayout(new FillLayout());

		viewer = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI);
		table = createTable(viewer);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		filter = new DefaultViewerFilter("");
		viewer.addFilter(filter);

		createColumns(viewer);
		viewer.setContentProvider(new ArrayContentProvider());
		viewer.setInput(events);
		viewer.setComparator(comparator);

	}

	protected Table createTable(TableViewer viewer) {
		Table table = viewer.getTable();
		return table;
	}

	protected void doExportCsv() {
		FileDialog dialog = new FileDialog(getSite().getShell(), SWT.SAVE);
		dialog.setFilterNames(new String[] { "CSV files", "All files" });
		dialog.setFilterExtensions(new String[] { "*.csv", "*.*" });
		dialog.setFileName(getCsvFileName());

		String filename = dialog.open();
		File file = new File(filename);

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			CSVPrinter printer = new CSVPrinter(bw, CSVFormat.EXCEL.withDelimiter(';'));

			printer.printRecord(getCsvHeaders());

			for (Event event : events) {
				List<String> line = CollectionUtil.toArrayList("" + event.getId(), event.getTypeAbbreviation(), DateUtil.format(event.getTimestamp()),
						event.getDetails());
				processCustomEvents(line, event);
				printer.printRecord(line);
			}

			printer.flush();
			printer.close();
		} catch (IOException e) {
			MessageDialog.openError(getSite().getShell(), "Could not write to CSV", e.getMessage());
		}
	}

	protected List<String> getCsvHeaders() {
		return CollectionUtil.toArrayList("ID", "Type", "Time", "Details", "Variable Name", "Value");
	}

	protected String getCsvFileName() {
		return "debug_events_" + currentModel.getDescription() + ".csv";
	}

	protected void processCustomEvents(List<String> line, Event event) {
		if (event instanceof DebugEvent) {
			DebugEvent dev = (DebugEvent) event;
			line.add(dev.getVariableName() + "");
			line.add(dev.getVariableValue() + "");
		}
	}

	protected void addEventListener(SimulationModel model) {
		if (model != null && model.getEventLog() != null) {
			model.getEventLog().addDebugEventListener(this);
		}
	}

	protected void removeEventListener() {
		if (currentModel != null && currentModel.getEventLog() != null) {
			currentModel.getEventLog().removeDebugEventListener(this);
		}
	}

	protected List<Event> getEvents(SimulationModel model) {
		if (model == null || model.getEventLog() == null) {
			return new ArrayList<>();
		}

		return model.getEventLog().getDebugEvents();
	}

	protected void doFind() {
		String toFind = textFind.getText();
		int selIndex = (viewer.getTable().getSelectionIndex());

		if (selIndex < 0) {
			selIndex = 0;
		}

		boolean found = false;

		for (int i = selIndex + 1; i <= selIndex + events.size(); i++) {
			Event ev = (Event) viewer.getElementAt(i % events.size());

			if ((String.valueOf(ev.getId()).contains(toFind) || ev.getDetails().contains(toFind)
					|| String.valueOf(ev.getContinuousNumber()).contains(toFind))) {
				viewer.setSelection(new StructuredSelection(ev), true);
				found = true;
				break;
			}
		}

		if (!found) {
			MessageDialog.openInformation(textFind.getShell(), "Not found", "The entered string '" + toFind + "' was not found");
		}
	}

	protected void createSpecificColumns(int columnIndex) {
		TableViewerColumn colSegmentId = createTableViewerColumn(viewer, "Variable Name", 100, columnIndex++);
		colSegmentId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (element instanceof DebugEvent) {
					DebugEvent e = (DebugEvent) element;

					if (e.getType() == EventType.VARIABLE_CHANGED) {
						return e.getVariableName();
					}
				}

				return Constants.EMPTY_STRING;
			}
		});

		TableViewerColumn colNodeId = createTableViewerColumn(viewer, "Value", 80, columnIndex++);
		colNodeId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (element instanceof DebugEvent) {
					DebugEvent e = (DebugEvent) element;

					if (e.getType() == EventType.VARIABLE_CHANGED) {
						return String.valueOf(e.getVariableValue());
					}
				}

				return Constants.EMPTY_STRING;
			}
		});
	}

	private void createColumns(TableViewer viewer) {
		int columnIndex = 0;

		TableViewerColumn colId = createTableViewerColumn(viewer, "UID", 60, columnIndex++);
		colId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Event e = (Event) element;
				return e.getId() + "";
			}
		});

		TableViewerColumn colContId = createTableViewerColumn(viewer, "Number", 50, columnIndex++);
		colContId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Event e = (Event) element;
				return e.getContinuousNumber() + "";
			}
		});

		TableViewerColumn colTypeName = createTableViewerColumn(viewer, "Type", 55, columnIndex++);
		colTypeName.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Event e = (Event) element;
				return EventType.getAbbreviation(e.getType());
			}

			@Override
			public Image getImage(Object element) {
				Event e = (Event) element;
				return EventType.getImage(e.getType());
			}

			@Override
			public String getToolTipText(Object element) {
				Event e = (Event) element;
				return e.getType().toString();
			}
		});

		TableViewerColumn colDate = createTableViewerColumn(viewer, "Timestamp", 80, columnIndex++);
		colDate.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Event e = (Event) element;
				return DateUtil.formatWithMiliseconds(e.getTimestamp(), true);
			}
		});

		TableViewerColumn colLogDate = createTableViewerColumn(viewer, "Log-Date", 80, columnIndex++);
		colLogDate.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Event e = (Event) element;
				return DateUtil.formatWithMiliseconds(e.getLogDate(), true);
			}
		});

		TableViewerColumn colTypeDetails = createTableViewerColumn(viewer, "Type Info", 80, columnIndex++);
		colTypeDetails.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Event e = (Event) element;
				return e.getTypeInfo();
			}
		});

		TableViewerColumn colDetails = createTableViewerColumn(viewer, "Details", 250, columnIndex++);
		colDetails.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				Event e = (Event) element;
				return e.getDetails();
			}
		});

		createSpecificColumns(columnIndex);
	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		events = new ArrayList<>();

		if (newModel != null) {
			removeEventListener();
			addEventListener(newModel);
			events.addAll(getEvents(newModel));

			Display.getDefault().asyncExec(new Runnable() {

				@Override
				public void run() {
					if (viewer != null && !viewer.getTable().isDisposed()) {
						viewer.setInput(events);
						viewer.refresh();
					}
				}
			});

			currentModel = newModel;
		}
	}

	@Override
	public void newEvent(Event event) {
		events.add(event);
		getSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (viewer.getControl().isDisposed()) {
					return;
				}

				viewer.refresh(false);
				viewer.scrollDown(0, Integer.MAX_VALUE);
			}
		});
	}

	@Override
	protected BaseViewerComparator createComparator() {
		BaseViewerComparator comparator = new DebugMonitorComparator();
		return comparator;
	}
}
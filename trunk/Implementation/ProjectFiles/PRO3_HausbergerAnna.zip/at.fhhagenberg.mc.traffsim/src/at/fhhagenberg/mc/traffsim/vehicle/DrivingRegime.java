package at.fhhagenberg.mc.traffsim.vehicle;

public enum DrivingRegime {
	FREE_DRIVING("Free driving", "FREE"), FOLLOWING("Car following", "FOLLOWING");

	public static DrivingRegime valueOfLabel(String label) {
		for (DrivingRegime al : DrivingRegime.values()) {
			if (al.getLabel().equals(label)) {
				return al;
			}
		}

		return null;
	}

	private String name;
	private String label;

	private DrivingRegime(final String name, final String label) {
		this.name = name;
		this.label = label;
	}

	public String getName() {
		return name;
	}

	public String getLabel() {
		return label;
	}

	@Override
	public String toString() {
		return name;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle;

public class VehicleWithDistance {
	private Vehicle vehicle;
	private double distance;

	public VehicleWithDistance(Vehicle v, double distance) {
		this.vehicle = (v);
		this.distance = (distance);
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public double getDistance() {
		return distance;
	}

	public String toString() {
		return "veh id: " + vehicle.getUniqueId() + " dist: " + distance;
	}

}
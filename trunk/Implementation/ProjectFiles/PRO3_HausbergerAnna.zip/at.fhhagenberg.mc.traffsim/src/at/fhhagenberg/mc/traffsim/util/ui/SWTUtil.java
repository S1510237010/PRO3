package at.fhhagenberg.mc.traffsim.util.ui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.e4.ui.model.application.ui.basic.MPart;
import org.eclipse.e4.ui.model.application.ui.basic.MPartSashContainerElement;
import org.eclipse.e4.ui.workbench.modeling.EModelService;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.log.Logger;

/**
 * Utility class encapsulating the functionality to activate a new view on the active workbench window and to create a (fairly) evenly
 * spaced color table to be used in graphs.
 */
public class SWTUtil {

	/**
	 * Generates a series of colors such that the distribution of the colors is (fairly) evenly spaced throughout the color spectrum. This
	 * is especially useful for generating unique color codes to be used in a legend or on a graph.
	 *
	 * @param numColors
	 *            the number of colors to generate
	 * @param defaultColor
	 *            the default color
	 * @param hueMax
	 *            the max. gradiation of color
	 * @return a list of colors (@see Color) representing the colors in the table
	 */
	public static List<Color> createColorCodeTable(int numColors, Color defaultColor, float hueMax) {
		List<Color> table = new ArrayList<>(numColors);

		if (numColors == 1) {
			// Special case for only one color
			table.add(defaultColor);
		} else {
			float sat = (float) 0.8;

			for (int i = 0; i < numColors; i++) {
				float hue = hueMax * i / (numColors - 1);

				// Here we interleave light colors and dark colors
				// to get a wider distribution of colors.
				if (i % 2 == 0) {
					table.add(Color.getHSBColor(hue, sat, (float) 0.9));
				} else {
					table.add(Color.getHSBColor(hue, sat, (float) 0.7));
				}
			}
		}

		return table;
	}

	/**
	 * Check if view with given id is already open
	 * 
	 * @param viewId
	 * @return <code>true</code> if view is open, <code>false</code> otherwise
	 */
	public static boolean isViewOpen(String viewId) {
		return PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(viewId) != null;
	}

	/**
	 * Shows a new view in the active workbench window and optionally detaches that view.
	 *
	 * @param viewId
	 *            the view's primary identifier
	 * @param secondaryId
	 *            the view's secondary identifier
	 * @param detach
	 *            flag indicating whether the view should be detached or not
	 * @return the opened {@link ViewPart}, or <code>null</code> if not found
	 */
	public static IViewPart showView(String viewId, String secondaryId, boolean detach) {
		IViewPart viewPart;

		try {
			viewPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().showView(viewId, secondaryId,
					IWorkbenchPage.VIEW_ACTIVATE);

		} catch (PartInitException e) {
			Logger.logError("Cannot open view " + viewId + "!");
			return null;
		}

		if (detach) {
			EModelService s = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getService(EModelService.class);
			MPartSashContainerElement p = viewPart.getSite().getService(MPart.class);

			if (p != null) {
				if (p.getCurSharedRef() != null) {
					p = p.getCurSharedRef();
				}

				s.detach(p, 100, 100, 600, 600);
			}
		}
		return viewPart;
	}
}

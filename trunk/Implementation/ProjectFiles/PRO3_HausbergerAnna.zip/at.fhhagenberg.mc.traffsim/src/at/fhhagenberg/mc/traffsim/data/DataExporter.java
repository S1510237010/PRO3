package at.fhhagenberg.mc.traffsim.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;

import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficGeneratorBean;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficObstructionBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ConnectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.DetectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.IntersectionControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.LaneSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RemovedRoutingIdsBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightControllerBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.generator.AbstractVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.ContinuousVehicleGenerator;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane.Type;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.util.ObjectAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.Obstruction;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Utility class providing data exporting functionalities.
 *
 * @author Christian Backfrieder
 */
public class DataExporter {

	/**
	 * Exports the currently active {@link SimulationModel} into separate XML documents. The export comprises infrastructure entities (
	 * {@link RoadSegment}s, {@link AbstractJunction}s) and {@link IRoute}s.
	 *
	 * @param monitor
	 *            a {@link IProgressMonitor} for monitoring the export progress
	 */
	public static void exportNetwork(IProgressMonitor monitor) {
		SimulationModel activeModel = SimulationKernel.getInstance().getActiveModel();
		List<RoadSegment> roadSegments = activeModel.getNetwork().getRoadSegments();
		List<AbstractJunction> junctions = activeModel.getNetwork().getJunctions();
		List<TrafficLight> trafficLights = activeModel.getNetwork().getTrafficLights();
		List<LoopDetector> loopDetectors = activeModel.getNetwork().getLoopDetectors();
		List<Obstruction> obstructions = activeModel.getNetwork().getObstructions();
		List<AbstractVehicleGenerator> trafficGenerators = activeModel.getTrafficGenerators(false);

		List<IRoute> routes = new ArrayList<>(activeModel.getRouteRegistry().getRoutes().values());
		monitor.beginTask("Exporting network", roadSegments.size() + junctions.size() + routes.size() + loopDetectors.size() + 15);

		monitor.subTask("Sorting data");
		CollectionUtil.sortAfterField(roadSegments, "id");
		monitor.worked(1);
		CollectionUtil.sortAfterField(routes, "id");
		monitor.worked(1);
		CollectionUtil.sortAfterField(junctions, "id");
		monitor.worked(1);
		CollectionUtil.sortAfterField(trafficLights, "id");
		monitor.worked(1);
		CollectionUtil.sortAfterField(loopDetectors, "identifier");
		monitor.worked(1);
		CollectionUtil.sortAfterField(obstructions, "uniqueId");

		DataSerializer ser = new DataSerializer();

		monitor.subTask("Reading configuration");

		ser.readConfiguration(activeModel.getInputFile());
		TraffSimConfiguration config = ser.getConfiguration();
		List<InfrastructureBean> infrastructure = new ArrayList<>();
		List<IntersectionControlBean> intersectionControls = new ArrayList<>();

		// store removed routing ids
		infrastructure.add(new RemovedRoutingIdsBean(new ArrayList<>(activeModel.getRemovedRoutingIds())));

		// process junctions
		Map<Long, NodeBean> nodeBeans = new HashMap<>();

		if (!config.getBeanConfigurationsMapping().containsKey(IntersectionControlBean.class.getName())) {
			config.registerFilenameForClass(IntersectionControlBean.class, TraffsimDefaultData.INTERSECTION_CONTROLS_XML_NAME);
			ser.setConfiguration(config);
			ser.writeConfiguration(config.getConfigurationFile());
		}

		for (TrafficLight trafficLight : trafficLights) {
			TrafficLightBean bean = trafficLight.toBean();
			intersectionControls.add(bean);
		}

		for (AbstractJunction j : junctions) {
			NodeBean nb = new NodeBean(j.getId(), j.getAltitude());
			nb.setSecondaryIds(new ArrayList<Long>(j.getSecondaryIds()));

			if (j.isSimpleThrough()) {
				nb.setType(NodeType.DRIVE_THROUGH);
			} else if (j.hasTrafficLights()) {
				nb.setType(NodeType.TRAFFIC_LIGHT);
			} else {
				nb.setType(j.getType());
			}

			infrastructure.add(nb);
			nodeBeans.put(nb.getId(), nb);

			for (JunctionConnector c : j.getConnectors()) {
				monitor.subTask("Junction " + j.getId() + ", connector " + c.getId());
				LaneSegment src = c.getSourceLaneSegment();
				LaneSegment dst = c.getSinkLaneSegment();
				ConnectorBean cb = new ConnectorBean(c.getId(), src.getRoadSegment().getId(), src.getLaneIndex(), dst.getRoadSegment().getId(),
						dst.getLaneIndex(), c.getPriority(), j.getId(), c.getRoadSign() != null ? c.getRoadSign().toString() : null);
				cb.setSmoothing(c.getSmoothing());
				cb.setShrinkFactor(c.getShrinkFactor());
				infrastructure.add(cb);
			}

			if (j.getTrafficLightController() != null) {
				TrafficLightController<?> trafficLightController = j.getTrafficLightController();
				TrafficLightControllerBean bean = trafficLightController.toBean();
				intersectionControls.add(bean);
			}

			monitor.worked(1);
		}

		/**
		 * nodes which are no junctions, but simple start or end nodes of a segment
		 */
		monitor.subTask("Writing nodes which are not part of a junction...");
		HashMap<Long, NodeBean> additionalNodes = new HashMap<>();

		for (RoadSegment rs : roadSegments) {
			if (!nodeBeans.containsKey(rs.getStartNode().getId()) && !additionalNodes.containsKey(rs.getStartNode().getId())) {
				NodeBean start = new NodeBean(rs.getStartNode().getId(), rs.getStartNode().getAltitude());
				additionalNodes.put(start.getId(), start);
			}

			if (!nodeBeans.containsKey(rs.getEndNode().getId()) && !additionalNodes.containsKey(rs.getEndNode().getId())) {
				NodeBean end = new NodeBean(rs.getEndNode().getId(), rs.getEndNode().getAltitude());
				additionalNodes.put(end.getId(), end);
			}
		}

		infrastructure.addAll(additionalNodes.values());

		for (RoadSegment rs : roadSegments) {
			try {
				List<Vector> origPts = rs.getRoadGeometry().getOriginalPoints();

				if (origPts.isEmpty()) {
					rs.originalPointsSnapshot();
				}

				RoadSegmentBean rsBean = new RoadSegmentBean(ObjectAdapter.toCoordinateBeanList(rs.getRoadGeometry().getOriginalPoints()),
						rs.getStartNode().getId(), rs.getEndNode().getId(), rs.getLaneCount(), rs.getRoutingId(), rs.getId(), rs.getName(),
						rs.isOsmReverse());
				rsBean.setFittedPoints(ObjectAdapter.toCoordinateBeanList(rs.getRoadGeometry().getPoints()));
				rsBean.setOneWay(rs.isOneWay());

				long laneId = 0;
				List<LaneSegmentBean> lsBeans = new ArrayList<>();
				List<Integer> entryLanes = new ArrayList<>(), exitLanes = new ArrayList<>();

				for (LaneSegment ls : rs.getLaneSegments()) {
					monitor.subTask("RoadSegment " + rs.getId() + ", LaneSegment " + ls.getId());
					LaneSegmentBean lsBean = new LaneSegmentBean(laneId);
					lsBean.setPoints(ObjectAdapter.toCoordinateBeanList(ls.getRoadGeometry().getPoints()));
					lsBean.setLeftEdge(ObjectAdapter.toCoordinateBeanList(ls.getLeftEdge()));
					lsBean.setRightEdge(ObjectAdapter.toCoordinateBeanList(ls.getRightEdge()));
					lsBean.setLaneIndex(ls.getLaneIndex());
					lsBean.setLaneWidth(ls.getLaneWidth());
					lsBean.setId(ls.getId());
					lsBean.setType(ls.getLaneType().toString());

					if (ls.getSourceLaneSegment() != null) {
						lsBean.setSourceLane(ls.getSourceLaneSegment().getId());
					}

					if (ls.getSinkLaneSegment() != null) {
						lsBean.setSinkLane(ls.getSinkLaneSegment().getId());
					}

					if (ls.getLaneType() == Type.ENTRANCE) {
						entryLanes.add(ls.getLaneIndex());
					} else if (ls.getLaneType() == Type.EXIT) {
						exitLanes.add(ls.getLaneIndex());
					}

					lsBeans.add(lsBean);
				}

				monitor.worked(1);
				rsBean.setLaneSegments(lsBeans);
				rsBean.setEntryLanes(CollectionUtil.toPrimitiveIntArray(entryLanes));
				rsBean.setExitLanes(CollectionUtil.toPrimitiveIntArray(exitLanes));
				rsBean.setSpeedLimit(rs.getSpeedLimitKmph());
				infrastructure.add(rsBean);
			} catch (NullPointerException ex) {
				ex.printStackTrace();
			}
		}

		ser.writeData(infrastructure);

		if (intersectionControls.isEmpty()) {
			ser.clearData(IntersectionControlBean.class);
		} else {
			ser.writeData(intersectionControls);
		}

		// Export detectors
		List<DetectorBean> detectorBeans = new ArrayList<>();

		for (LoopDetector detector : loopDetectors) {
			if (!detector.getIsAssociatedToQueueMonitor()) {
				monitor.subTask("LoopDetector " + detector.getIdentifier() + ", RoadSegment " + detector.getRoadSegment().getId());

				DetectorBean bean = new DetectorBean();
				bean.setId(detector.getIdentifier());
				bean.setPosition(detector.getPosition());
				bean.setRoadSegmentId(detector.getRoadSegment().getId());
				bean.setSampleInterval(detector.getSampleInterval());
				detectorBeans.add(bean);
			}

			monitor.worked(1);
		}

		// Ensure detectors are included in the class mapping
		if (!ser.getConfiguration().getBeanConfigurationsMapping().containsKey(DetectorBean.class.getName())) {
			ser.getConfiguration().registerFilenameForClass(DetectorBean.class, TraffsimDefaultData.DETECTORS_XML_NAME);
			ser.setConfiguration(ser.getConfiguration());
			ser.writeConfiguration(ser.getConfiguration().getConfigurationFile());
		}

		if (detectorBeans.isEmpty()) {
			ser.clearData(DetectorBean.class);
		} else {
			ser.writeData(detectorBeans);
		}

		// Export obstructions
		List<TrafficObstructionBean> obstructionBeans = new ArrayList<>();

		for (Obstruction obstruction : obstructions) {
			TrafficObstructionBean bean = new TrafficObstructionBean(obstruction.getOffset(), obstruction.getDuration(), obstruction.isPermanent(),
					obstruction.getRoadSegment().getId(), obstruction.getLaneId(), obstruction.getFrontPosition());
			obstructionBeans.add(bean);
		}

		// Ensure obstructions are included in the class mapping
		if (!ser.getConfiguration().getBeanConfigurationsMapping().containsKey(TrafficObstructionBean.class.getName())) {
			ser.getConfiguration().registerFilenameForClass(TrafficObstructionBean.class, TraffsimDefaultData.OBSTRUCTIONS_XML_NAME);
			ser.setConfiguration(ser.getConfiguration());
			ser.writeConfiguration(ser.getConfiguration().getConfigurationFile());
		}

		if (obstructionBeans.isEmpty()) {
			ser.clearData(TrafficObstructionBean.class);
		} else {
			ser.writeData(obstructionBeans);
		}

		// Export routes
		List<RouteBean> rbs = new ArrayList<>();

		for (IRoute r : routes) {
			monitor.subTask("Route " + r.getId());
			RouteBean rb = new RouteBean(r.getId(), CollectionUtil.toPrimitiveLongArray(r.getRouteIds()));
			rbs.add(rb);
			monitor.worked(1);
		}

		ser.writeData(rbs);

		// Export traffic generators
		List<TrafficGeneratorBean> tgb = new ArrayList<>();

		for (AbstractVehicleGenerator generator : trafficGenerators) {
			if (generator instanceof ContinuousVehicleGenerator) {
				ContinuousVehicleGenerator continuousGenerator = (ContinuousVehicleGenerator) generator;
				tgb.add(continuousGenerator.toBean());
			}
		}

		// Ensure obstructions are included in the class mapping
		if (!ser.getConfiguration().getBeanConfigurationsMapping().containsKey(TrafficGeneratorBean.class.getName())) {
			ser.getConfiguration().registerFilenameForClass(TrafficGeneratorBean.class, TraffsimDefaultData.TRAFFIC_GENERATORS_XML_NAME);
			ser.setConfiguration(ser.getConfiguration());
			ser.writeConfiguration(ser.getConfiguration().getConfigurationFile());
		}

		if (tgb.isEmpty()) {
			ser.clearData(TrafficGeneratorBean.class);
		} else {
			ser.writeData(tgb);
		}

		monitor.subTask("Writing to XML");
		monitor.done();
	}
}
package at.fhhagenberg.mc.traffsim.roadnetwork.detector;

import com.google.common.base.Predicate;

import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector.DetectionMode;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class VehiclePassedPosition implements Predicate<Vehicle> {

	private double position;
	private DetectionMode detectionMode;

	public VehiclePassedPosition() {
		this.position = 0;
		detectionMode = DetectionMode.DUAL;
	}

	public VehiclePassedPosition(double position, DetectionMode detectionMode) {
		this.position = position;
		this.detectionMode = detectionMode;
	}

	@Override
	public boolean apply(Vehicle vehicle) {
		if (vehicle == null) {
			return false;
		}

		if (detectionMode == DetectionMode.FRONT) {
			return vehicle.getFrontPositionOld() <= position && vehicle.getFrontPosition() > position;
		} else if (detectionMode == DetectionMode.REAR) {
			return vehicle.getRearPositionOld() <= position && vehicle.getRearPosition() > position;
		} else {
			return vehicle.getFrontPositionOld() <= position && vehicle.getFrontPosition() > position
					|| vehicle.getRearPositionOld() <= position && vehicle.getRearPosition() > position;
		}
	}
}

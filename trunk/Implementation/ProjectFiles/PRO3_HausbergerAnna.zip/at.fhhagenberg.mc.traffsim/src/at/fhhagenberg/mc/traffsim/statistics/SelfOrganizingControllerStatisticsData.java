package at.fhhagenberg.mc.traffsim.statistics;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;

public class SelfOrganizingControllerStatisticsData extends TrafficControllerStatisticsData {

	private static final long serialVersionUID = 7620408927145231445L;

	protected List<Double> cycleTime = new ArrayList<>();
	protected List<Double> stabilizerState = new ArrayList<>();

	public SelfOrganizingControllerStatisticsData() {
		super();
	}

	public SelfOrganizingControllerStatisticsData(long controllerId, long junctionId) {
		super(controllerId, junctionId);
	}

	public List<Double> getCycleTime() {
		return cycleTime;
	}

	public List<Double> getStabilizerState() {
		return stabilizerState;
	}

	@Override
	public synchronized void addData(double time, TrafficLightController<?> controller) {
		Map<String, Number> data = controller.obtainStatistics();
		this.cycleTime.add((double) data.get(IStatsConstants.CONTROLLER_CYCLE_TIME));
		this.stabilizerState.add((double) data.get(IStatsConstants.CONTROLLER_STABILIZER_STATE));
		this.time.add(time);
		recordedItems++;
	}

	@Override
	public TrafficControllerStatisticsData collectData(int numItemsToKeep) {
		SelfOrganizingControllerStatisticsData data = new SelfOrganizingControllerStatisticsData(controllerId, junctionId);
		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.time.addAll(time.subList(0, numItems));
				data.cycleTime.addAll(cycleTime.subList(0, numItems));
				data.stabilizerState.addAll(stabilizerState.subList(0, numItems));

				// remove the collected sublist from statistics data
				time = new ArrayList<>(time.subList(numItems, lastIndex));
				cycleTime = new ArrayList<>(cycleTime.subList(numItems, lastIndex));
				stabilizerState = new ArrayList<>(stabilizerState.subList(numItems, lastIndex));

				data.recordedItems = recordedItems;
			}
		}

		return data;
	}
}

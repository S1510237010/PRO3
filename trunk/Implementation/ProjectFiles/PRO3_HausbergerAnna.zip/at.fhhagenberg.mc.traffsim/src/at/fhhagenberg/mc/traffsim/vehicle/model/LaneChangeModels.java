package at.fhhagenberg.mc.traffsim.vehicle.model;

public enum LaneChangeModels {

	MOBIL("Mobil", "MOBIL");

	private String type;
	private String shortName;

	private LaneChangeModels(final String type, final String shortName) {
		this.type = type;
		this.shortName = shortName;
	}

	@Override
	public String toString() {
		return type;
	}

	public String getShortName() {
		return shortName;
	}

	public static LaneChangeModels valueOfLabel(String label) {
		for (LaneChangeModels t : LaneChangeModels.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}

		return null;
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.osmimport;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.xml.sax.SAXException;

import at.fhhagenberg.mc.traffsim.data.TraffSimDataPlugin;
import at.fhhagenberg.mc.traffsim.data.TraffsimDefaultData;
import at.fhhagenberg.mc.traffsim.data.beans.ParameterBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.BaseRoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.osm.OSMLoader;
import at.fhhagenberg.mc.traffsim.data.osm.OSMWriter;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.FileUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class ConfigurationSelectionPage extends WizardPage implements IResultProvider {
	class InternalValidator extends KeyAdapter {
		@Override
		public void keyReleased(KeyEvent e) {
			validatePage();
		}
	}

	private Text txtFolderPath;
	private Text txtBaseNetworkFileName;
	private Text txtRoadNetworkFileName;
	private Text txtOsmFileName;
	private Text txtGraphFileName;

	private InternalValidator validator = new InternalValidator();

	/**
	 * Create the wizard.
	 */
	public ConfigurationSelectionPage() {
		super("wizardPage");
		setTitle("Configuration Selection");
		setDescription("Define TraffSim configuration where to attach the generated network");
	}

	/**
	 * Create contents of the wizard.
	 *
	 * @param parent
	 */
	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);

		setControl(container);
		container.setLayout(new GridLayout(3, false));

		Label lblConfigurationPath = new Label(container, SWT.NONE);
		lblConfigurationPath.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblConfigurationPath.setText("Configuration folder");

		txtFolderPath = new Text(container, SWT.BORDER);
		txtFolderPath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtFolderPath.addKeyListener(validator);
		txtFolderPath.setText(PreferenceUtil.getString(IPreferenceConstants.LAST_CONFIGURATION_FOLDER));

		Button btnBrowse = new Button(container, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DirectoryDialog dialog = new DirectoryDialog(getShell());
				String result = dialog.open();
				if (result != null) {
					txtFolderPath.setText(result);
				}
				validatePage();
			}
		});
		btnBrowse.setText("Browse");

		Label lblOsmFileName = new Label(container, SWT.NONE);
		lblOsmFileName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblOsmFileName.setText("OSM file name");

		txtOsmFileName = new Text(container, SWT.BORDER);
		txtOsmFileName.addKeyListener(validator);
		txtOsmFileName.setText("map.osm");
		txtOsmFileName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(container, SWT.NONE);

		Label lblGraphFileName = new Label(container, SWT.NONE);
		lblGraphFileName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblGraphFileName.setText("Graph file name");

		txtGraphFileName = new Text(container, SWT.BORDER);
		txtGraphFileName.setText("map.gph");
		txtGraphFileName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtGraphFileName.addKeyListener(validator);
		new Label(container, SWT.NONE);

		Label lblBaseNetworkFilename = new Label(container, SWT.NONE);
		lblBaseNetworkFilename.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblBaseNetworkFilename.setText("Base network file name");

		txtBaseNetworkFileName = new Text(container, SWT.BORDER);
		txtBaseNetworkFileName.setText("basenetwork.xml");
		txtBaseNetworkFileName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtBaseNetworkFileName.addKeyListener(validator);
		new Label(container, SWT.NONE);

		Label lblInfrastructureFilename = new Label(container, SWT.NONE);
		lblInfrastructureFilename.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblInfrastructureFilename.setText("Infrastructure file name");

		txtRoadNetworkFileName = new Text(container, SWT.BORDER);
		txtRoadNetworkFileName.setText("roadnetwork.xml");
		txtRoadNetworkFileName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		txtRoadNetworkFileName.addKeyListener(validator);
		new Label(container, SWT.NONE);
		validatePage();
	}

	@Override
	public boolean isPageComplete() {
		return StringUtil.isNullOrEmpty(getErrorMessage());
	}

	private void validatePage() {
		try {
			if (!new File(txtFolderPath.getText()).exists()) {
				setErrorMessage("Configuration folder does not exist");
			} else if (txtRoadNetworkFileName.getText().isEmpty() || txtBaseNetworkFileName.getText().isEmpty() || txtOsmFileName.getText().isEmpty()
					|| txtGraphFileName.getText().isEmpty()) {
				setErrorMessage("All fields are required");
			} else {
				setErrorMessage(null);
			}
		} finally {
			if (getWizard().getContainer().getCurrentPage() != null) {
				getWizard().getContainer().updateButtons();
			}
		}
	}

	@Override
	public TraffSimConfiguration getResult() {
		File confFile = new File(txtFolderPath.getText(), "configuration.xml");
		TraffSimConfiguration config;
		DataSerializer serializer = new DataSerializer();
		if (confFile.exists()) {
			serializer.readConfiguration(confFile);
			config = serializer.getConfiguration();
		} else {
			config = new TraffSimConfiguration();
			config.setConfigurationFile(confFile);
		}
		config.addOrUpdateBeanConfiguration(BaseRoadSegmentBean.class.getName(), txtBaseNetworkFileName.getText());
		config.addOrUpdateBeanConfiguration(InfrastructureBean.class.getName(), txtRoadNetworkFileName.getText());
		config.setGraphFile(txtGraphFileName.getText());
		config.setOsmNetworkFile(txtOsmFileName.getText());
		try {
			if (!config.getBeanConfigurationsMapping().containsKey(ModelBean.class.getName())) {
				FileUtil.copyFile(TraffSimDataPlugin.PLUGIN_ID,
						TraffsimDefaultData.DIRECTORY_NAME + TraffsimDefaultData.SEPARATOR + TraffsimDefaultData.MODELS_XML_NAME,
						config.getConfigurationFile().getParentFile());
				config.registerFilenameForClass(ModelBean.class, TraffsimDefaultData.MODELS_XML_NAME);
			}
			if (!config.getBeanConfigurationsMapping().containsKey(ParameterBean.class.getName())) {
				FileUtil.copyFile(TraffSimDataPlugin.PLUGIN_ID,
						TraffsimDefaultData.DIRECTORY_NAME + TraffsimDefaultData.SEPARATOR + TraffsimDefaultData.PARAMETERS_XML_NAME,
						config.getConfigurationFile().getParentFile());
				config.registerFilenameForClass(ParameterBean.class, TraffsimDefaultData.PARAMETERS_XML_NAME);
			}
			if (!config.getBeanConfigurationsMapping().containsKey(LongitudinalControlBean.class.getName())) {
				FileUtil.copyFile(TraffSimDataPlugin.PLUGIN_ID,
						TraffsimDefaultData.DIRECTORY_NAME + TraffsimDefaultData.SEPARATOR + TraffsimDefaultData.CONTROLS_XML_NAME,
						config.getConfigurationFile().getParentFile());
				config.registerFilenameForClass(LongitudinalControlBean.class, TraffsimDefaultData.CONTROLS_XML_NAME);
			}
		} catch (IOException e) {
			Logger.logError("Could not copy default files", e);
		}
		if (config.getStartTime() == null) {
			config.setStartTime(new Date());
		}
		serializer.setConfiguration(config);
		serializer.writeConfiguration(config.getConfigurationFile());
		prepareOsm();
		savePreferences();
		return config;
	}

	private void savePreferences() {
		PreferenceUtil.set(IPreferenceConstants.LAST_CONFIGURATION_FOLDER, txtFolderPath.getText());
	}

	private void prepareOsm() {
		final String strFolderPath = txtFolderPath.getText();
		final String strOsmFileName = txtOsmFileName.getText();

		ProgressMonitorDialog dialog = new ProgressMonitorDialog(getShell());
		try {
			dialog.run(true, true, new IRunnableWithProgress() {
				@Override
				public void run(IProgressMonitor monitor) {
					if (((SourceSelectionPage) getWizard().getPreviousPage(ConfigurationSelectionPage.this)).mustLoadFromOsmOnline()) {
						try {
							double[] bounds = new double[] { PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LAT_MIN),
									PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LON_MIN),
									PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LAT_MAX),
									PreferenceUtil.getDouble(IPreferenceConstants.SELECTION_COORD_LON_MAX) };
							OSMLoader loader = new OSMLoader();
							loader.processOSM(loader.getXMLOverpass(bounds[0], bounds[1], bounds[2], bounds[3], monitor), monitor);
							File osmFile = new File(strFolderPath, strOsmFileName);
							monitor.subTask("Writing to file " + osmFile.getName());
							BufferedWriter outWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(osmFile), "UTF-8"));
							OSMWriter.writeOSM(outWriter, bounds[0], bounds[1], bounds[2], bounds[3], loader.getNodes(), loader.getWays());
						} catch (IOException | ParserConfigurationException | SAXException e) {
							Logger.logError("Could not load OSM from web site", e);
						}
					} else {
						File osmFile = new File(
								((SourceSelectionPage) getWizard().getPreviousPage(ConfigurationSelectionPage.this)).getSelectedFilePath());
						osmFile.renameTo(new File(strFolderPath, strOsmFileName));
					}
				}
			});
		} catch (InvocationTargetException | InterruptedException e1) {
			Logger.logError("Could not load file ", e1);
		}
	}

	public void setFiles(final String osmFile, final String graphFile, final String folderName) {
		getWizard().getContainer().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (StringUtil.isNotNullOrEmpty(osmFile)) {
					txtOsmFileName.setText(osmFile);
				}
				if (StringUtil.isNotNullOrEmpty(graphFile)) {
					txtGraphFileName.setText(graphFile);
				}
				if (StringUtil.isNotNullOrEmpty(folderName)) {
					txtFolderPath.setText(folderName);
				}
			}
		});
	}

}

package at.fhhagenberg.mc.traffsim.ui.preferences;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class BatchPreferencePage extends PreferencePage implements IWorkbenchPreferencePage {

	private Button btnCleanupTempFolder;
	private Spinner spinnerSimultaneousSim;
	private Group grpExecutionAfterBatch;
	private Button btnExecuteThisTool;
	private Text textExecutable;
	private Button btnBrowse;
	private Group groupExecutionContinuous;
	private Button btnExecuteThisToolContinuous;
	private Text textExecutableContinuous;
	private Button btnBrowseContinuous;
	private Label lblIntervalevery;
	private Spinner spinnerExecutionInterval;
	private Group grpRestart;
	private Label lblSimulationsBeforeRestart;
	private Button btnRestart;
	private Spinner spinnerNumConfigurations;

	/** marker for buttons which should be ignored when disabling a group */
	private Object ignoreMarker = new Object();

	/**
	 * @wbp.parser.constructor
	 */
	public BatchPreferencePage() {
	}

	public BatchPreferencePage(String title, ImageDescriptor image) {
		super(title, image);
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(2, false));

		Label lblMaxSimultaneousSimulations = new Label(container, SWT.NONE);
		lblMaxSimultaneousSimulations.setText("Max. simultaneous simulations");

		spinnerSimultaneousSim = new Spinner(container, SWT.BORDER);
		spinnerSimultaneousSim.setPageIncrement(1);
		spinnerSimultaneousSim.setMaximum(100);
		spinnerSimultaneousSim.setMinimum(1);
		spinnerSimultaneousSim.setSelection(1);

		btnCleanupTempFolder = new Button(container, SWT.CHECK);
		btnCleanupTempFolder.setToolTipText("The temporary folders which were created by TraffSim are deleted before simulation start");
		btnCleanupTempFolder.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnCleanupTempFolder.setText("Cleanup temp folder before start");

		groupExecutionContinuous = new Group(container, SWT.NONE);
		groupExecutionContinuous.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		groupExecutionContinuous.setText("Execution after batch end");
		groupExecutionContinuous.setLayout(new GridLayout(3, false));

		btnExecuteThisToolContinuous = new Button(groupExecutionContinuous, SWT.CHECK);
		btnExecuteThisToolContinuous.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setControlsEnabled(groupExecutionContinuous, btnExecuteThisToolContinuous.getSelection());
			}
		});
		btnExecuteThisToolContinuous.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnExecuteThisToolContinuous.setText("Execute this tool during batch");
		btnExecuteThisToolContinuous.setSelection(false);
		btnExecuteThisToolContinuous.setData(ignoreMarker);

		lblIntervalevery = new Label(groupExecutionContinuous, SWT.NONE);
		lblIntervalevery
				.setToolTipText("The tool will be executed in the background, \neach time the specified amount of simulations is finished");
		lblIntervalevery.setText("Interval (every ... finished simulations):");

		spinnerExecutionInterval = new Spinner(groupExecutionContinuous, SWT.BORDER);
		new Label(groupExecutionContinuous, SWT.NONE);

		textExecutableContinuous = new Text(groupExecutionContinuous, SWT.BORDER);
		textExecutableContinuous.setText("");
		textExecutableContinuous.setEnabled(false);
		textExecutableContinuous.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		btnBrowseContinuous = new Button(groupExecutionContinuous, SWT.NONE);
		btnBrowseContinuous.setText("Browse");
		btnBrowseContinuous.setEnabled(false);
		btnBrowseContinuous.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog fd = new FileDialog(btnBrowse.getShell(), SWT.OPEN);
				fd.setText("Select executable tool for execution during batch");
				String txt = fd.open();
				textExecutableContinuous.setText(txt);
			}
		});

		grpExecutionAfterBatch = new Group(container, SWT.NONE);
		grpExecutionAfterBatch.setLayout(new GridLayout(2, false));
		grpExecutionAfterBatch.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpExecutionAfterBatch.setText("Execution after batch end");

		btnExecuteThisTool = new Button(grpExecutionAfterBatch, SWT.CHECK);
		btnExecuteThisTool.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setControlsEnabled(grpExecutionAfterBatch, btnExecuteThisTool.getSelection());
			}
		});
		btnExecuteThisTool.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnExecuteThisTool.setText("Execute this tool after batch finished");
		btnExecuteThisTool.setData(ignoreMarker);

		textExecutable = new Text(grpExecutionAfterBatch, SWT.BORDER);
		textExecutable.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btnBrowse = new Button(grpExecutionAfterBatch, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog fd = new FileDialog(btnBrowse.getShell(), SWT.OPEN);
				fd.setText("Select executable tool");
				String txt = fd.open();
				textExecutable.setText(txt);
			}
		});
		btnBrowse.setText("Browse");

		grpRestart = new Group(container, SWT.NONE);
		grpRestart.setLayout(new GridLayout(2, false));
		grpRestart.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpRestart.setText("Restart TraffSim and continue batch mode");

		btnRestart = new Button(grpRestart, SWT.CHECK);
		btnRestart.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRestart.setText("Restart TraffSim after ... configurations");
		btnRestart.setData(ignoreMarker);
		btnRestart.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setControlsEnabled(grpRestart, btnRestart.getSelection());
			}
		});

		lblSimulationsBeforeRestart = new Label(grpRestart, SWT.NONE);
		lblSimulationsBeforeRestart.setToolTipText(
				"TraffSim will be restarted after ... configurations \nhave been processed. Batch mode will continue afterwards.");
		lblSimulationsBeforeRestart.setText("Number of configurations:");
		spinnerNumConfigurations = new Spinner(grpRestart, SWT.BORDER);
		spinnerNumConfigurations.setIncrement(1);
		spinnerNumConfigurations.setPageIncrement(10);
		spinnerNumConfigurations.setMinimum(1);
		spinnerNumConfigurations.setMaximum(500);

		initializePreferences();
		return container;
	}

	private void setControlsEnabled(Group parent, boolean enabled) {
		for (Control c : parent.getChildren()) {
			if (!ignoreMarker.equals(c.getData())) {
				c.setEnabled(enabled);
			}
		}
	}

	@Override
	public void init(IWorkbench workbench) {

	}

	private void initializePreferences() {
		spinnerSimultaneousSim.setSelection(PreferenceUtil.getInt(IPreferenceConstants.NUM_SIMULTANEOUS_SIMULATIONS));
		btnCleanupTempFolder.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.CLEANUP_BATCH_TEMP));

		String toolPath = PreferenceUtil.getString(IPreferenceConstants.TOOL_PATH_AFTER_BATCH_FINISH);
		textExecutable.setText(toolPath);
		btnExecuteThisTool.setSelection(StringUtil.isNotNullOrEmpty(toolPath));
		setControlsEnabled(grpExecutionAfterBatch, StringUtil.isNotNullOrEmpty(toolPath));

		String toolPathContinuous = PreferenceUtil.getString(IPreferenceConstants.TOOL_PATH_DURING_BATCH);
		textExecutableContinuous.setText(toolPathContinuous);
		btnExecuteThisToolContinuous.setSelection(StringUtil.isNotNullOrEmpty(toolPathContinuous));
		spinnerExecutionInterval.setSelection(PreferenceUtil.getInt(IPreferenceConstants.TOOL_EXECUTION_INTERVAL));
		setControlsEnabled(groupExecutionContinuous, StringUtil.isNotNullOrEmpty(toolPathContinuous));

		boolean restartAfterNSimulations = PreferenceUtil.getBoolean(IPreferenceConstants.RESTART_AFTER_N_CONFIGURATIONS);
		spinnerNumConfigurations.setSelection(PreferenceUtil.getInt(IPreferenceConstants.CONFIGURATIONS_BEFORE_RESTART));
		btnRestart.setSelection(restartAfterNSimulations);
		setControlsEnabled(grpRestart, restartAfterNSimulations);
	}

	@Override
	protected void performApply() {
		PreferenceUtil.setInt(IPreferenceConstants.NUM_SIMULTANEOUS_SIMULATIONS, spinnerSimultaneousSim.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.CLEANUP_BATCH_TEMP, btnCleanupTempFolder.getSelection());
		if (!btnExecuteThisTool.getSelection()) {
			textExecutable.setText("");
		}
		if (!btnExecuteThisToolContinuous.getSelection()) {
			textExecutableContinuous.setText("");
		}

		PreferenceUtil.setBoolean(IPreferenceConstants.RESTART_AFTER_N_CONFIGURATIONS, btnRestart.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.CONFIGURATIONS_BEFORE_RESTART, spinnerNumConfigurations.getSelection());
		PreferenceUtil.set(IPreferenceConstants.TOOL_PATH_AFTER_BATCH_FINISH, textExecutable.getText());
		PreferenceUtil.setInt(IPreferenceConstants.TOOL_EXECUTION_INTERVAL, spinnerExecutionInterval.getSelection());
		PreferenceUtil.set(IPreferenceConstants.TOOL_PATH_DURING_BATCH, textExecutableContinuous.getText());
	}

	@Override
	public boolean performOk() {
		performApply();
		return super.performOk();
	}
}
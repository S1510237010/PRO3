package at.fhhagenberg.mc.traffsim.vehicle.model.platoon;

import at.fhhagenberg.mc.traffsim.vehicle.model.lanechange.LaneChangeModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControl;

/**
 * Configuration of a vehicle which holds a longitudinal and a lane change model
 * 
 * @author Sebastian Huber
 *
 */
public class VehicleConfig {
	/**
	 * Longitudinal model
	 */
	private LongitudinalControl<?> longControl;
	/**
	 * Lane change model
	 */
	private LaneChangeModel laneModel;
	
	/**
	 * CTor
	 * @param longControl Longitudinal model
	 * @param laneModel Lane change model
	 */
	public VehicleConfig(LongitudinalControl<?> longControl, LaneChangeModel laneModel) {
		super();
		this.longControl = longControl;
		this.laneModel = laneModel;
	}
	
	/**
	 * Longitudinal model
	 * @return long model
	 */
	public LongitudinalControl<?> getLongControl() {
		return longControl;
	}
	
	/**
	 * Lane change model
	 * @return lane model
	 */
	public LaneChangeModel getLaneModel() {
		return laneModel;
	}
}

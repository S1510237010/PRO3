package at.fhhagenberg.mc.traffsim.model;

public enum SimulationState {
	INITIAL, LOADING, LOADED, STARTED, CONTINUED, PAUSED,
	/**
	 * simulation has ended, but tasks to be done after simulation end (e.g. conversion of statistics etc. are still not done)
	 */
	ENDED,
	/** everything is done after simulation end */
	COMPLETED,
	/** simulation ended unusually, and tasks for cleanup are done */
	ABORTED;

	public static boolean isSimulationRunningAfter(SimulationState state) {
		return state == CONTINUED || state == STARTED;
	}
}

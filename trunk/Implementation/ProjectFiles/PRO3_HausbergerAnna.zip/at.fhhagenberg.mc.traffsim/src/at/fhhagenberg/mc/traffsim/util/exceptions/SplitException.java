package at.fhhagenberg.mc.traffsim.util.exceptions;

/**
 * This exception type can be used to handle exceptions originating from splitting a linestring into multiple parts.
 *
 * @author Christian Backfrieder
 */
public class SplitException extends Exception {

	/** Unique identifier for serialization */
	private static final long serialVersionUID = 9078254059093088343L;

	/** Flag indidicating whether the exception is fatal */
	boolean fatal = false;

	/**
	 * Creates a new SplitException with the given message
	 *
	 * @param message
	 *            the exception message
	 */
	public SplitException(String message) {
		super(message);
	}

	/**
	 * Creates a new SplitException with the given parameters.
	 *
	 * @param message
	 *            the exception message
	 * @param fatal
	 *            indicates whether the exception is fatal or not
	 */
	public SplitException(String message, boolean fatal) {
		this(message);
		this.fatal = fatal;
	}

	/**
	 * Gets whether the exception is fatal or not.
	 *
	 * @return true if fatal - false else
	 */
	public boolean isFatal() {
		return fatal;
	}
}

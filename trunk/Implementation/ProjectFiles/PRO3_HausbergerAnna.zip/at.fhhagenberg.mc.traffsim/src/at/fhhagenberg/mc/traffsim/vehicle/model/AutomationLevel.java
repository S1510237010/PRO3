package at.fhhagenberg.mc.traffsim.vehicle.model;

public enum AutomationLevel {
	NONE("No Automation", "NONE"), PARTIAL("Partial Automation", "PARTIAL"), HIGH("High Automation", "HIGH"), FULL("Full Automation",
			"FULL");

	public static AutomationLevel valueOfLabel(String label) {
		for (AutomationLevel al : AutomationLevel.values()) {
			if (al.getLabel().equals(label)) {
				return al;
			}
		}

		return null;
	}

	private String name;
	private String label;

	private AutomationLevel(final String name, final String label) {
		this.name = name;
		this.label = label;
	}

	public String getName() {
		return name;
	}

	public String getLabel() {
		return label;
	}

	@Override
	public String toString() {
		return name;
	}
}

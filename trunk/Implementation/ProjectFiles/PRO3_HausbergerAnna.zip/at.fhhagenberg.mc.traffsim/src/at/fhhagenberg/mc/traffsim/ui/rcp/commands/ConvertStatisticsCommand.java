package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.statistics.DetailedStatisticsCollector;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.util.DateUtil;

public class ConvertStatisticsCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		DirectoryDialog dialog = new DirectoryDialog(Display.getCurrent().getActiveShell());
		dialog.setText("Select cache folder");
		String selection = dialog.open();
		if (selection == null) {
			return null;
		}
		final File cacheFolder = new File(selection);
		SimulationModel model = new SimulationModel("temporary");
		final DetailedStatisticsCollector sc = new DetailedStatisticsCollector("Manual Statistics Converter", model, 100, false);
		final String startDate;
		if (cacheFolder.getName().startsWith(sc.getCacheFolderPrefix())) {
			startDate = cacheFolder.getName().replace(sc.getCacheFolderPrefix(), "");
		} else {
			startDate = "converted_" + DateUtil.formatForFile(new Date());
		}
		final Kryo serializer = new Kryo();
		serializer.setClassLoader(TraffSimCorePlugin.class.getClassLoader());
		Job job = new Job("Cache conversion") {

			@Override
			protected IStatus run(IProgressMonitor monitor) {
				try {
					sc.convertStatistics(cacheFolder, serializer, cacheFolder.getParentFile(), startDate, false, monitor);
				} catch (IOException e) {
					Logger.logError("Could not convert statistics");
					return new Status(IStatus.ERROR, TraffSimCorePlugin.PLUGIN_ID, "Could not convert statistics");
				}
				return Status.OK_STATUS;
			}
		};
		job.setUser(true);
		job.schedule();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

}

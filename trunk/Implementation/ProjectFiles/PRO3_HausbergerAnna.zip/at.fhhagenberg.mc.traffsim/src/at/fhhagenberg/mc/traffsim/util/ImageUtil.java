package at.fhhagenberg.mc.traffsim.util;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;

import javax.imageio.ImageIO;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import at.fhhagenberg.mc.traffsim.ui.rcp.views.SimulationView;

/**
 * Utility class providing image-related functionality.
 *
 * @author Christian Backfrieder
 */
public class ImageUtil {

	/** Cache for AWT images */
	private static HashMap<String, BufferedImage> awtImagesCache = new HashMap<>();

	/** Cache for SWT images */
	private static HashMap<String, Image> swtImagesCache = new HashMap<>();

	private static HashMap<Integer, Cursor> cursorCache = new HashMap<>();

	/**
	 * Gets a {@link BufferedImage} from a file specified by the given file name and adds it to the AWT cache.
	 *
	 * @param file
	 *            the name of the file containing the image data
	 * @return the loaded AWT image
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static java.awt.image.BufferedImage getAWTImage(String file) throws IOException {
		if (!awtImagesCache.containsKey(file)) {
			Bundle bundle = FrameworkUtil.getBundle(SimulationView.class);
			BufferedImage img = ImageIO.read(FileLocator.find(bundle, new Path(file), null).openStream());
			awtImagesCache.put(file, img);
		}

		return awtImagesCache.get(file);
	}

	public static Cursor getCursor(int type) {
		if (!cursorCache.containsKey(type)) {
			cursorCache.put(type, new Cursor(type));
		}
		return cursorCache.get(type);
	}

	/**
	 * Gets an {@link Image} from a file specified by the given file name and adds it to the SWT cache.
	 *
	 * @param file
	 *            the name of the file containing the image data
	 * @return the loaded SWT image
	 */
	public static Image getSWTImage(String file) {
		if (!swtImagesCache.containsKey(file)) {
			Bundle bundle = FrameworkUtil.getBundle(SimulationView.class);
			URL url = FileLocator.find(bundle, new Path(file), null);
			ImageDescriptor image = ImageDescriptor.createFromURL(url);
			swtImagesCache.put(file, image.createImage());
		}

		return swtImagesCache.get(file);
	}

	/**
	 * Rotate image the given {@link BufferedImage} by the provided angle in clockwise direction.
	 *
	 * @param src
	 *            the original image
	 * @param angle
	 *            the rotation angle
	 * @return the rotated image
	 */
	public static java.awt.image.BufferedImage rotateImage(BufferedImage src, double angle) {
		int w = src.getWidth();
		int h = src.getHeight();

		AffineTransform t = new AffineTransform();
		t.setToRotation(angle, w / 2d, h / 2d);

		// source image rectangle
		Point[] points = { new Point(0, 0), new Point(w, 0), new Point(w, h), new Point(0, h) };

		// transform to destination rectangle
		t.transform(points, 0, points, 0, 4);

		// get destination rectangle bounding box
		Point min = new Point(points[0]);
		Point max = new Point(points[0]);

		for (int i = 1, n = points.length; i < n; i++) {
			Point p = points[i];
			double pX = p.getX(), pY = p.getY();

			// update min/max x
			if (pX < min.getX()) {
				min.setLocation(pX, min.getY());
			}

			if (pX > max.getX()) {
				max.setLocation(pX, max.getY());
			}

			// update min/max y
			if (pY < min.getY()) {
				min.setLocation(min.getX(), pY);
			}

			if (pY > max.getY()) {
				max.setLocation(max.getX(), pY);
			}
		}

		// determine new width, height
		w = (int) (max.getX() - min.getX());
		h = (int) (max.getY() - min.getY());

		// determine required translation
		double tx = min.getX();
		double ty = min.getY();

		// append required translation
		AffineTransform translation = new AffineTransform();
		translation.translate(-tx, -ty);
		t.preConcatenate(translation);

		AffineTransformOp op = new AffineTransformOp(t, null);
		BufferedImage dst = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		op.filter(src, dst);
		return dst;
	}
}
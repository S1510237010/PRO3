package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.equinox.internal.p2.core.helpers.ServiceHelper;
import org.eclipse.equinox.p2.core.IProvisioningAgent;
import org.eclipse.equinox.p2.operations.UpdateOperation;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.PlatformUI;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.rcp.P2Util;

/**
 * This command executes the P2 update mechanism programmatically and performs an update operation and following restart automatically
 * without any user intervention.
 *
 * @author Christian Backfrieder
 *
 */
public class QuickUpdateCommand implements IHandler {

	public static final String COMMAND_ID = "at.fhhagenberg.mc.traffsim.commands.quickupdate";

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

	@Override
	public void dispose() {
		// unused
	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final IProvisioningAgent agent = (IProvisioningAgent) ServiceHelper.getService(TraffSimCorePlugin.getDefault().getBundle().getBundleContext(),
				IProvisioningAgent.SERVICE_NAME);
		if (agent == null) {
			Logger.logWarn("No provisioning agent found.  This application is not set up for updates.");
		}
		// If an update is performed, restart. Otherwise log
		// the status.
		final AtomicBoolean success = new AtomicBoolean(false);
		IRunnableWithProgress runnable = new IRunnableWithProgress() {
			@Override
			public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
				IStatus updateStatus = P2Util.checkForUpdates(agent, monitor);
				if (updateStatus.getCode() == UpdateOperation.STATUS_NOTHING_TO_UPDATE) {
					PlatformUI.getWorkbench().getDisplay().asyncExec(new Runnable() {
						@Override
						public void run() {
							MessageDialog.openInformation(null, "Updates", "No updates were found");
						}
					});
				} else if (updateStatus.getSeverity() != IStatus.ERROR) {
					success.set(true);
				} else {
					Logger.logWarn(updateStatus.getMessage());
				}
			}
		};
		try {
			new ProgressMonitorDialog(null).run(true, true, runnable);
			if (success.get()) {
				PlatformUI.getWorkbench().restart();
			}
		} catch (InvocationTargetException e) {
			Logger.logError(e.getMessage(), e);
		} catch (InterruptedException e) {
		}
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// unused
	}

}

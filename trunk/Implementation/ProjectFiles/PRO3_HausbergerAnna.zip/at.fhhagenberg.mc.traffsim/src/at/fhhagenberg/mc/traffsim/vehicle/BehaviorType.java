package at.fhhagenberg.mc.traffsim.vehicle;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public enum BehaviorType {

	/**
	 * A control behavior marks a vehicle that it is controlled not by it's used longitudinal model but by behaviors exclusively
	 */
	ACCELERATION("Acceleration"), DECELERATION("Deceleration"), CONTROL("Control"), DISTRACTION_EYES_OFF_ROAD(
			"Distraction (eyes-off road)"), DISTRACTION_MIND_OFF_ROAD("Distraction (mind-off road)"), TRACE("Trace-imposed");

	private String type;

	private BehaviorType(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return type;
	}

	public static BehaviorType valueOfLabel(String label) {
		for (BehaviorType t : BehaviorType.values()) {
			if (t.toString().equals(label)) {
				return t;
			}
		}

		return null;
	}
}

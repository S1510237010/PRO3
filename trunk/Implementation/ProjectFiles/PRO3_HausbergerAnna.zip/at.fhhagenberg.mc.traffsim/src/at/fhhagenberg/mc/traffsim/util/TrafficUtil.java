package at.fhhagenberg.mc.traffsim.util;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.lane.Lane.Type;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.LongitudinalModel;

/**
 * Utility class providing various vehicle-related functionalities.
 *
 * @author Christian Backfrieder
 */
public class TrafficUtil {

	/**
	 * Gets the brake distance until standstill for vehicle v.
	 *
	 * @param v
	 *            the vehicle of interest
	 * @return distance in meters which is needed by the vehicle to brake, without taking into account any reaction time
	 */
	public static double getBrakeDistance(Vehicle v) {
		double speed = v.getCurrentSpeed();
		double dec = v.getLongitudinalControl().getLongitudinalModel().getModelData().getSafeDec();
		return -speed * speed / (2 * dec);
	}

	/**
	 * Determine if a safe break is possible within the given distance by taking into account safe deceleration from the underlying
	 * {@link LongitudinalModel} .
	 *
	 * @param v
	 *            the vehicle which should be taken for calculation (using current speed)
	 * @param maximumDistance
	 *            the maximum break distance to allow
	 * @return true if vehicle is able to break within given distance, false otherwise
	 */
	public static boolean isSafeBreakPossible(Vehicle v, double maximumDistance) {
		if (v.getCurrentSpeed() == 0) {
			return true;
		}

		double brakeDist = getBrakeDistance(v);
		return brakeDist <= maximumDistance;
	}

	/**
	 * Determine if the given vehicle will stand still within the given distance, if moving constantly with current speed and acceleration.
	 *
	 * @param v
	 *            the vehicle which should be taken for calculation (using current speed and acceleration from it)
	 * @param withinDistance
	 *            the distance to compare with
	 * @return true if vehicle will stand still within the given distance, false otherwise
	 */
	public static boolean vehicleIsLikelyStanding(Vehicle v, double withinDistance) {
		double speed = v.getCurrentSpeed();
		double acc = v.getCurrentAcc();

		if (speed < 0.1) {
			return true;
		}

		return acc <= 0 && -speed * speed / acc < withinDistance;
	}

	/**
	 * Gets a list of vehicles situated within a given distance on the current lane segment.
	 *
	 * @param vehicles
	 *            the list of vehicles to be validated
	 * @param distance
	 *            the distance to be considered
	 * @param fromEnd
	 *            indicates whether the distance should be calculated from the segment's start or end
	 * @return a list of vehicles being in the range defined by the given distance
	 */
	public static List<Vehicle> vehiclesWithinDistance(List<Vehicle> vehicles, double distance, boolean fromEnd) {
		List<Vehicle> result = new ArrayList<>();

		if (fromEnd) {
			for (Vehicle v : vehicles) {
				if (v.getLaneSegment().getRoadLength() - v.getFrontPosition() < distance) {
					result.add(v);
				}
			}
		} else {
			for (Vehicle v : vehicles) {
				if (v.getFrontPosition() < distance) {
					result.add(v);
				}
			}
		}

		return result;
	}

	/**
	 * Gets a list of vehicles situated within a given time frame on the current lane segment. The time frame is based on the vehicle's
	 * current velocity.
	 *
	 * @param vehicles
	 *            the list of vehicles to be validated
	 * @param seconds
	 *            the time frame in seconds
	 * @param fromEnd
	 *            indicates whether the time frame should be calculated from the segment's start or end
	 * @return a list of vehicles being in the range defined by the given time frame
	 */
	public static List<Vehicle> vehiclesWithinTime(List<Vehicle> vehicles, double seconds, boolean fromEnd) {
		List<Vehicle> result = new ArrayList<>();

		for (Vehicle v : vehicles) {

			// Distance to road end
			double s = 0;

			if (fromEnd) {
				s = v.getLaneSegment().getRoadLength() - v.getFrontPosition();
			} else {
				s = v.getFrontPosition();
			}

			double t = s / v.getCurrentSpeed();

			if (t < seconds) {
				result.add(v);
			}
		}

		return result;
	}

	/**
	 * Calculates minimum human distance based on speed, time gap and minimum gap
	 *
	 * @param v
	 *            speed of vehicle
	 * @param tMin
	 *            time gap of vehicle
	 * @param sMin
	 *            minimum gap of vehicle
	 * @return minimum human distance
	 */
	public static double getMinimumSafetyDistance(double v, double tMin, double sMin) {
		return sMin + (tMin * v);
	}

	/**
	 * Calculates a intelligent (ACC/IDM) human distance based on speed, speed difference and comfortable accelerations and decelerations
	 *
	 * @param v
	 *            speed of vehicle
	 * @param dv
	 *            speed difference to preceding
	 * @param tMin
	 *            time gap of vehicle
	 * @param sMin
	 *            minimum gap of vehicle
	 * @param comfortAcc
	 *            comfortable acceleration of vehicle
	 * @param safeDec
	 *            safe deceleration of vehicle
	 * @return intelligent human gap
	 */
	public static double getIntelligentSaftyDistance(double v, double dv, double tMin, double sMin, double comfortAcc, double safeDec) {
		return sMin + Math.max(0.0, v * tMin + v * dv / (2 * Math.sqrt(comfortAcc * -safeDec)));
	}

	/**
	 * Get count of TRAFFIC lanes for vehicle
	 *
	 * @param v
	 *            vehicle to check (Road segment of vehicle)
	 * @return number of TRAFFIC lanes
	 */
	public static int getTrafficLaneCountForVehicle(Vehicle v) {
		int count = 0;

		for (LaneSegment ls : v.getRoadSegment().getLaneSegments()) {
			if (ls.getLaneType() == Type.TRAFFIC) {
				count++;
			}
		}
		return count;
	}

	/**
	 * Get true if lane is exit or entrance lane
	 *
	 * @param lane
	 *            lane to check
	 * @return true if lane is either exit or entrance
	 */
	public static boolean isLaneExitOrEntrance(LaneSegment lane) {
		boolean entrance = lane.getLaneType() == Type.ENTRANCE;
		boolean exit = lane.getLaneType() == Type.EXIT;
		return entrance || exit;
	}

	/**
	 * Helper to get the new lane segment based on a direction for a given vehicle
	 *
	 * @param me
	 *            current vehicle
	 * @param direction
	 *            direction for new lane segment
	 * @return new lane segment in the direction
	 */
	public static LaneSegment getNewLaneSegmentForVehicle(Vehicle me, int direction) {
		return me.getRoadSegment().getLaneSegments().get(me.getLaneIndex() + direction);
	}
}
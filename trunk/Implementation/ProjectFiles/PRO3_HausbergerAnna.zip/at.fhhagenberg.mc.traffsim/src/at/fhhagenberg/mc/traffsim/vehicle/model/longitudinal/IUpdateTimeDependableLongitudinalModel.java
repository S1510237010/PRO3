package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

public interface IUpdateTimeDependableLongitudinalModel {
	void setSimulationTimestep(double timeStep);
}

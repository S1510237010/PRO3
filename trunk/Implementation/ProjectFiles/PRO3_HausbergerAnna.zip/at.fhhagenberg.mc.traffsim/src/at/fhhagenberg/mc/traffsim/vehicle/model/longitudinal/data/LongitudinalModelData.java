package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

import at.fhhagenberg.mc.traffsim.vehicle.model.VehicleModelInputData;

public class LongitudinalModelData extends VehicleModelInputData {

	private double comfortableAcc;
	private double maxAcc;
	private double maxDec;
	private double safeDec;
	private double sMin;
	private double tMin;
	private double vTarget;

	public LongitudinalModelData() {

	}

	public LongitudinalModelData(double vTarget, double sMin, double tMin, double comfortableAcc, double safeDec, double maxAcc,
			double maxDec) {
		super();
		setvTarget(vTarget);
		setsMin(sMin);
		settMin(tMin);
		setComfortableAcc(comfortableAcc);
		setSafeDec(safeDec);
		setMaxAcc(maxAcc);
		setMaxDec(maxDec);
	}

	public double getComfortableAcc() {
		return comfortableAcc;
	}

	public double getMaxAcc() {
		return maxAcc;
	}

	public double getMaxDec() {
		return maxDec;
	}

	public double getSafeDec() {
		return safeDec;
	}

	public double getsMin() {
		return sMin;
	}

	public double gettMin() {
		return tMin;
	}

	public double getvTarget() {
		return vTarget;
	}

	public void setComfortableAcc(double comfortableAcc) {
		this.comfortableAcc = comfortableAcc;
	}

	public void setMaxAcc(double maxAcc) {
		this.maxAcc = maxAcc;
	}

	public void setMaxDec(double maxDec) {
		this.maxDec = maxDec;
	}

	public void setSafeDec(double safeDec) {
		this.safeDec = safeDec;
	}

	public void setsMin(double sMin) {
		this.sMin = sMin;
	}

	public void settMin(double tMin) {
		this.tMin = tMin;
	}

	public void setvTarget(double vTarget) {
		this.vTarget = vTarget;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.Platoon;

public interface IPlatoonLongitudinalModel extends ILongitudinalModel {
	/**
	 * Platoon of vehicle
	 *
	 * @return platoon
	 */
	Platoon getPlatoon();

	/**
	 * Platoon of vehicle
	 *
	 * @param platoon
	 *            Platoon
	 */
	void setPlatoon(Platoon platoon);

	/**
	 * Additional calculation for acceleration, including the speed of the leader of the platoon
	 *
	 * Values for the preceding and the leader vehicle (s, dv, aLead, vPlatoonLead) must be preceding and leader values of the platoon
	 * members!
	 *
	 * @param me
	 *            current vehicle
	 * @param v
	 *            speed
	 * @param s
	 *            distance to front vehicle
	 * @param dv
	 *            speed difference to front vehicle
	 * @param aLead
	 *            acceleration of front vehicle
	 * @param vPlatoonLead
	 *            speed of the platoon leader
	 * @param alphaT
	 *            human parameter 1
	 * @param alphaV0
	 *            human parameter 2
	 * @param alphaA
	 *            human parameter 3
	 * @param speedLimit
	 *            speed limit for calculation
	 * @return desired acceleration for vehicle
	 *
	 */
	double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double vPlatoonLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit);

}

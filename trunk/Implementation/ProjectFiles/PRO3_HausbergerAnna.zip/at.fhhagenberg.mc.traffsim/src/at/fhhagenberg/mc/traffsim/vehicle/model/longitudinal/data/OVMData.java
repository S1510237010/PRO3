package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.OVM.OVMFunction;

public class OVMData extends LongitudinalModelData {
	private static final String BANDO = "BANDO";

	private static final String IDENTIFIER = "OVM";
	private static final String THREEPHASE = "THREEPHASE";
	private static final String TRIANGULAR = "TRIANGULAR";

	private double beta = 0.0;
	private OVMFunction function;
	private double gamma = 0.0;

	private double tau = 0.0;

	private double transitionWidth = 0.0;

	public OVMData() {
		setIdentifier(IDENTIFIER);
	}

	public OVMData(double vTarget, double sMin, double comfortableAcc, double beta, double gamma, double tau, double transitionWidth,
			OVMFunction function) {

		super(vTarget, sMin, Constants.DESIRED_TIME_HEADWAY, comfortableAcc, Constants.SAFE_DECELERATION, Constants.MAX_ACCELERATION,
				Constants.MAX_DECELERATION);
		setBeta(beta);
		setGamma(gamma);
		setTau(tau);
		setTransitionWidth(transitionWidth);
		setOVMFunction(function);
		setIdentifier(IDENTIFIER);
	}

	public double getBeta() {
		return beta;
	}

	public double getGamma() {
		return gamma;
	}

	public OVMFunction getOVMFunction() {
		return function;
	}

	public double getTau() {
		return tau;
	}

	public double getTransitionWidth() {
		return transitionWidth;
	}

	public void setBeta(double beta) {
		this.beta = beta;
	}

	public void setGamma(double gamma) {
		this.gamma = gamma;
	}

	public void setOVMFunction(OVMFunction function) {
		this.function = function;
	}

	public void setOVMFunction(String function) {
		if (function.toUpperCase().compareTo(BANDO) == 0) {
			setOVMFunction(OVMFunction.BANDO);
		} else if (function.toUpperCase().compareTo(TRIANGULAR) == 0) {
			setOVMFunction(OVMFunction.TRIANGULAR);
		} else if (function.toUpperCase().compareTo(THREEPHASE) == 0) {
			setOVMFunction(OVMFunction.THREEPHASE);
		}
	}

	public void setTau(double tau) {
		this.tau = tau;
	}

	public void setTransitionWidth(double transitionWidth) {
		this.transitionWidth = transitionWidth;
	}
}

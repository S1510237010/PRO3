package at.fhhagenberg.mc.traffsim.util.jts;

import java.util.ArrayList;
import java.util.List;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Envelope;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.geom.Polygon;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * Conversion utility which acts as an interface for the conversion between local classes and JTS classes.
 *
 * @author Christian Backfrieder
 */
public class JTSAdapter {
	private static GeometryFactory geometryFactory = new GeometryFactory();

	/**
	 * Converts the given vector (@see Vector) into a coordinate (@see Coordinate).
	 *
	 * @param vector
	 *            the vector to be converted
	 * @return the resulting coordinate
	 */
	public static Coordinate toCoordinate(Vector vector) {
		return new Coordinate(vector.x, vector.y);
	}

	/**
	 * Converts the given list of vectors (@see Vector) into an array of coordinates (@see Coordinate).
	 *
	 * @param points
	 *            the list of vectors to be converted
	 * @return the resulting array of coordinates
	 */
	public static List<Coordinate> toCoordinatesList(List<Vector> points) {
		List<Coordinate> res = new ArrayList<>();

		for (Vector p : points) {
			if (p != null) {
				res.add(new Coordinate(p.x, p.y));
			}
		}

		return res;
	}

	/**
	 * Converts the given list of vectors (@see Vector) into an array of coordinates (@see Coordinate).
	 *
	 * @param points
	 *            the list of vectors to be converted
	 * @return the resulting array of coordinates
	 */
	public static Coordinate[] toCoordinates(List<Vector> points) {
		return toCoordinatesList(points).toArray(new Coordinate[] {});
	}

	/**
	 * Converts the given road geometry (@see RoadGeometry) into an array of coordinates (@see Coordinate).
	 *
	 * @param geom
	 *            the road geometry to be converted
	 * @return the resulting array of coordinates
	 */
	public static Coordinate[] toCoordinates(RoadGeometry geom) {
		return toCoordinates(geom.getPoints());
	}

	/**
	 * Converts the given list of vectors (@see Vector) into an envelope (@see Envelope).
	 *
	 * @param points
	 *            the list of vectors to be converted
	 * @return the resulting envelope
	 */
	public static Envelope toEnvelope(List<Vector> points) {
		if (points == null) {
			return null;
		}

		Envelope en = new Envelope();

		for (Vector vector : points) {
			en.expandToInclude(vector.x, vector.y);
		}

		return en;
	}

	/**
	 * Converts the given array of coordinates (@see Coordinate) into a line string (@see LineString).
	 *
	 * @param coordinates
	 *            the array of coordinates to be converted
	 * @return the resulting line string
	 */
	public static LineString toLineString(Coordinate[] coordinates) {
		return geometryFactory.createLineString(coordinates);
	}

	/**
	 * Converts the given list of vectors (@see Vector) into a line string (@see LineString).
	 *
	 * @param points
	 *            the list of vectors to be converted
	 * @return the resulting line string
	 */
	public static LineString toLineString(List<Vector> points) {
		return geometryFactory.createLineString(toCoordinates(points));
	}

	/**
	 * Converts the given road geometry (@see RoadGeometry) into a line string (@see LineString).
	 *
	 * @param geom
	 *            the road geometry to be converted
	 * @return the resulting line string
	 */
	public static LineString toLineString(RoadGeometry geom) {
		LineString linear = geometryFactory.createLineString(toCoordinates(geom));
		return linear;
	}

	/**
	 * Converts the given vector (@see Vector) into a point (@see Point).
	 *
	 * @param v
	 *            the vector to be converted
	 * @return the resulting point
	 */
	public static Point toPoint(Vector v) {
		return geometryFactory.createPoint(new Coordinate(v.x, v.y));
	}

	/**
	 * Converts the given list of vectors (@see Vector) into a polygon (@see Polygon).
	 *
	 * @param points
	 *            the list of vectors to be converted
	 * @return the resulting polygon
	 */
	public static Polygon toPolygon(List<Vector> points) {
		List<Coordinate> newPoints = toCoordinatesList(points);

		if (!CollectionUtil.getLastObject(newPoints).equals(CollectionUtil.getFirstObject(newPoints))) {
			newPoints.add(CollectionUtil.getFirstObject(newPoints));
		}
		try {
			return geometryFactory.createPolygon(newPoints.toArray(new Coordinate[] {}));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Converts the given coordinate (@see Coordinate) into a vector (@see Vector).
	 *
	 * @param c
	 *            the coordinate to be converted
	 * @return the resulting vector
	 */
	public static Vector toVector(Coordinate c) {
		return new Vector(c.x, c.y);
	}

	/**
	 * Converts the given point (@see Point) into a vector (@see Vector).
	 *
	 * @param pt
	 *            the point to be converted
	 * @return the resulting vector
	 */
	public static Vector toVector(Point pt) {
		return new Vector(pt.getX(), pt.getY());
	}

	/**
	 * Converts the given array of coordinates (@see Coordinate) into a list of vectors (@see Vector).
	 *
	 * @param coordinates
	 *            the array of coordinates to be converted
	 * @return the resulting list of vectors
	 */
	public static List<Vector> toVectorList(Coordinate[] coordinates) {
		ArrayList<Vector> vectorList = new ArrayList<>();

		for (Coordinate c : coordinates) {
			vectorList.add(toVector(c));
		}

		return vectorList;
	}
}
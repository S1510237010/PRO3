package at.fhhagenberg.mc.traffsim.statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.LongitudinalModelInputParameterSet;

public class ModelInputStatisticsData implements Serializable {

	private static final long serialVersionUID = 766040892714523144L;

	private final long vehicleId;
	private List<Double> time = new ArrayList<>();
	private List<Double> speed = new ArrayList<>();
	private List<Double> speedDifference = new ArrayList<>();
	private List<Double> spacing = new ArrayList<>();
	private List<Double> accLeader = new ArrayList<>();
	private List<Double> alphaA = new ArrayList<>();
	private List<Double> alphaT = new ArrayList<>();
	private List<Double> alphaV0 = new ArrayList<>();
	private List<Double> appliedAcc = new ArrayList<>();
	private List<Double> distanceEstimationError = new ArrayList<>();
	private List<Double> speedDifferenceEstimationError = new ArrayList<>();
	private List<Double> drivingError = new ArrayList<>();

	private long recordedItems;
	private long removedItems = 0;

	public ModelInputStatisticsData() {
		vehicleId = -1;
	}

	public ModelInputStatisticsData(long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public synchronized void addData(double runtime, LongitudinalModelInputParameterSet modelInput) {

		if (modelInput == null) {
			return;
		}

		time.add(runtime);
		speed.add(modelInput.getV());
		speedDifference.add(modelInput.getDv());
		spacing.add(modelInput.getS());
		accLeader.add(modelInput.getALead());
		alphaA.add(modelInput.getAlphaA());
		alphaT.add(modelInput.getAlphaT());
		alphaV0.add(modelInput.getAlphaV0());
		appliedAcc.add(modelInput.getAppliedAcc());
		distanceEstimationError.add(modelInput.getDistanceNoise());
		speedDifferenceEstimationError.add(modelInput.getSpeedDifferenceNoise());
		drivingError.add(modelInput.getAccelerationNoise());

		recordedItems++;
	}

	public ModelInputStatisticsData collectData(int numItemsToKeep) {
		ModelInputStatisticsData data = new ModelInputStatisticsData(vehicleId);

		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.time.addAll(time.subList(0, numItems));
				data.speed.addAll(speed.subList(0, numItems));
				data.speedDifference.addAll(speedDifference.subList(0, numItems));
				data.spacing.addAll(spacing.subList(0, numItems));
				data.accLeader.addAll(accLeader.subList(0, numItems));
				data.alphaA.addAll(alphaA.subList(0, numItems));
				data.alphaT.addAll(alphaT.subList(0, numItems));
				data.alphaV0.addAll(alphaV0.subList(0, numItems));
				data.appliedAcc.addAll(appliedAcc.subList(0, numItems));
				data.distanceEstimationError.addAll(distanceEstimationError.subList(0, numItems));
				data.speedDifferenceEstimationError.addAll(speedDifferenceEstimationError.subList(0, numItems));
				data.drivingError.addAll(drivingError.subList(0, numItems));

				// Remove the collected sublist from statistics data
				time = new ArrayList<>(time.subList(numItems, lastIndex));
				speed = new ArrayList<>(speed.subList(numItems, lastIndex));
				speedDifference = new ArrayList<>(speedDifference.subList(numItems, lastIndex));
				spacing = new ArrayList<>(spacing.subList(numItems, lastIndex));
				accLeader = new ArrayList<>(accLeader.subList(numItems, lastIndex));
				alphaA = new ArrayList<>(alphaA.subList(numItems, lastIndex));
				alphaT = new ArrayList<>(alphaT.subList(numItems, lastIndex));
				alphaV0 = new ArrayList<>(alphaV0.subList(numItems, lastIndex));
				appliedAcc = new ArrayList<>(appliedAcc.subList(numItems, lastIndex));
				distanceEstimationError = new ArrayList<>(distanceEstimationError.subList(numItems, lastIndex));
				speedDifferenceEstimationError = new ArrayList<>(
						speedDifferenceEstimationError.subList(numItems, lastIndex));
				drivingError = new ArrayList<>(drivingError.subList(numItems, lastIndex));

				removedItems += numItems;
				data.recordedItems = recordedItems;
			}
		}

		return data;
	}

	public long getVehicleId() {
		return vehicleId;
	}

	public List<Double> getTime() {
		return time;
	}

	public List<Double> getSpeed() {
		return speed;
	}

	public List<Double> getSpeedDifference() {
		return speedDifference;
	}

	public List<Double> getSpacing() {
		return spacing;
	}

	public List<Double> getAccLeader() {
		return accLeader;
	}

	public List<Double> getAlphaA() {
		return alphaA;
	}

	public List<Double> getAlphaT() {
		return alphaT;
	}

	public List<Double> getAlphaV0() {
		return alphaV0;
	}

	public List<Double> getAppliedAcc() {
		return appliedAcc;
	}

	public List<Double> getDistanceEstimationError() {
		return distanceEstimationError;
	}

	public List<Double> getSpeedDifferenceEstimationError() {
		return speedDifferenceEstimationError;
	}

	public List<Double> getDrivingError() {
		return drivingError;
	}

	public long getRecordedItems() {
		return recordedItems;
	}

	public long getRemovedItems() {
		return removedItems;
	}
}
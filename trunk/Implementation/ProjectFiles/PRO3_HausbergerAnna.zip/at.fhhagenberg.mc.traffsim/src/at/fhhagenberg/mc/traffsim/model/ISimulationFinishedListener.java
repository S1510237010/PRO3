package at.fhhagenberg.mc.traffsim.model;

public interface ISimulationFinishedListener {
	public void simulationFinished();
}

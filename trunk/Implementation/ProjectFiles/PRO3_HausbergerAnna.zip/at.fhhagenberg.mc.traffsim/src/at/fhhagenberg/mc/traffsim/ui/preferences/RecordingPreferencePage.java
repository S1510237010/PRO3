package at.fhhagenberg.mc.traffsim.ui.preferences;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.DateUtil;

public class RecordingPreferencePage extends PreferencePage implements IWorkbenchPreferencePage {

	private Button btnRecordVehicleStatistics;
	private Button btnRecordTime;
	private Button btnRecordDistance;
	private Button btnRecordPosition;
	private Button btnRecordSpeed;
	private Button btnRecordAcceleration;
	private Button btnRecordFuelConsumption;
	private Button btnRecordCarbonEmissions;
	private Button btnRecordDetailedJunctionStatistics;

	private Button btnRecordJunctionOutlineStatistics;
	private Button btnRecordDetectorStatistics;
	private Button btnRecordRoadStatistics;
	private Button btnRecordOutline;
	private Button btnRecordDebugEvents;
	private Button btnRecordCpuStatistics;
	private Button btnRecordModelInputStatistics;
	private Group grpOutlineStatistics;
	private Group grpMiscStatistics;
	private Group grpVehicleStatistics;
	private Group grpJunctionStatistics;
	private Button btnRecordQueueMonitorStatistics;
	private Button btnRecordTrafficLightStatistics;
	private Button btnRecordTrafficControllerStatistics;
	private Button btnRecordIndividualWaitingTimes;
	private Button btnEnableContinuousOutline;
	private Label lblRecordingInterval;
	private Spinner spinnerRecInterval;
	private Label lblMs;
	private Label lblSeconds;
	private Label lblTargetCachefileSize;
	private Spinner spinnerCacheSize;
	private Label lblMb;
	private Button btnRecordFuelOutline;
	private Button btnRecordCarbonOutline;
	private Button btnRecordEventsOutline;
	private Button btnRecordDistToFront;
	private Button btnRecordDistractionState;
	private Button btnRecordDistractionOutlineStatistics;

	/**
	 * @wbp.parser.constructor
	 */
	public RecordingPreferencePage() {
	}

	public RecordingPreferencePage(String title) {
		super(title);
	}

	public RecordingPreferencePage(String title, ImageDescriptor image) {
		super(title, image);
	}

	@Override
	public void init(IWorkbench workbench) {
		setPreferenceStore(TraffSimCorePlugin.getDefault().getPreferenceStore());
	}

	@Override
	protected Control createContents(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(2, false));

		grpVehicleStatistics = new Group(container, SWT.NONE);
		grpVehicleStatistics.setLayout(new GridLayout(3, false));
		grpVehicleStatistics.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpVehicleStatistics.setText("Vehicle Statistics");

		btnRecordVehicleStatistics = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordVehicleStatistics.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordVehicleStatistics.setText("Record detailed vehicle statistics");
		btnRecordVehicleStatistics.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateRecordingSection();
			}
		});

		// Detailed vehicle statistics
		btnRecordTime = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordTime.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordTime.setText("Record time");

		btnRecordDistance = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordDistance.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordDistance.setText("Record travel distance");

		btnRecordPosition = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordPosition.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordPosition.setText("Record position (x/y)");

		btnRecordSpeed = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordSpeed.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordSpeed.setText("Record velocity");

		btnRecordAcceleration = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordAcceleration.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordAcceleration.setText("Record acceleration");

		btnRecordFuelConsumption = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordFuelConsumption.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				btnRecordFuelOutline.setSelection(((Button) e.widget).getSelection());
				if (!btnRecordFuelConsumption.getSelection()) {
					btnRecordCarbonEmissions.setSelection(false);
					btnRecordCarbonOutline.setSelection(false);
				}
			}
		});
		btnRecordFuelConsumption.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordFuelConsumption.setText("Record fuel consumption");

		btnRecordCarbonEmissions = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordCarbonEmissions.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				btnRecordCarbonOutline.setSelection(((Button) e.widget).getSelection());
				if (btnRecordCarbonEmissions.getSelection()) {
					btnRecordFuelConsumption.setSelection(true);
					btnRecordFuelOutline.setSelection(true);
				}
			}
		});
		btnRecordCarbonEmissions.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordCarbonEmissions.setText("Record carbon emissions (CO2)");

		btnRecordDistToFront = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordDistToFront.setEnabled(false);
		btnRecordDistToFront.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordDistToFront.setText("Record distance to front vehicle");

		btnRecordDistractionState = new Button(grpVehicleStatistics, SWT.CHECK);
		btnRecordDistractionState.setEnabled(false);
		btnRecordDistractionState.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		btnRecordDistractionState.setText("Record distraction state");

		lblTargetCachefileSize = new Label(grpVehicleStatistics, SWT.NONE);
		lblTargetCachefileSize.setText("Target Cache-File Size");

		spinnerCacheSize = new Spinner(grpVehicleStatistics, SWT.BORDER);
		spinnerCacheSize.setMaximum(500);
		spinnerCacheSize.setMinimum(1);
		spinnerCacheSize.setSelection(50);

		lblMb = new Label(grpVehicleStatistics, SWT.NONE);
		lblMb.setText("MB");

		grpJunctionStatistics = new Group(container, SWT.NONE);
		grpJunctionStatistics.setLayout(new GridLayout(1, false));
		grpJunctionStatistics.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 1, 1));
		grpJunctionStatistics.setText("Junction Statistics");

		btnRecordDetailedJunctionStatistics = new Button(grpJunctionStatistics, SWT.CHECK);
		btnRecordDetailedJunctionStatistics.setText("Record detailed junction statistics");
		btnRecordDetailedJunctionStatistics.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateRecordingSection();
			}
		});

		btnRecordQueueMonitorStatistics = new Button(grpJunctionStatistics, SWT.CHECK);
		btnRecordQueueMonitorStatistics.setText("Record queue monitoring statistics");

		btnRecordTrafficControllerStatistics = new Button(grpJunctionStatistics, SWT.CHECK);
		btnRecordTrafficControllerStatistics.setText("Record traffic controller statistics");

		btnRecordTrafficLightStatistics = new Button(grpJunctionStatistics, SWT.CHECK);
		btnRecordTrafficLightStatistics.setText("Record traffic light statistics");

		btnRecordJunctionOutlineStatistics = new Button(grpJunctionStatistics, SWT.CHECK);
		btnRecordJunctionOutlineStatistics.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRecordJunctionOutlineStatistics.setText("Record outline junction statistics");
		btnRecordJunctionOutlineStatistics.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateRecordingSection();
			}
		});

		btnRecordIndividualWaitingTimes = new Button(grpJunctionStatistics, SWT.CHECK);
		btnRecordIndividualWaitingTimes.setText("Record detailed waiting times");
		btnRecordIndividualWaitingTimes.setToolTipText("Each junction tracks the waiting time experienced by every individual approaching vehicle.");

		grpOutlineStatistics = new Group(container, SWT.NONE);
		grpOutlineStatistics.setLayout(new GridLayout(4, false));
		grpOutlineStatistics.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpOutlineStatistics.setText("Outline Statistics");

		btnRecordOutline = new Button(grpOutlineStatistics, SWT.CHECK);
		btnRecordOutline.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateRecordingSection();
			}
		});

		btnRecordOutline.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 4, 1));
		btnRecordOutline.setText("Record outline vehicle statistics");

		btnRecordFuelOutline = new Button(grpOutlineStatistics, SWT.CHECK);
		btnRecordFuelOutline.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				btnRecordFuelConsumption.setSelection(((Button) e.widget).getSelection());
				if (!btnRecordFuelOutline.getSelection()) {
					btnRecordCarbonOutline.setSelection(false);
					btnRecordCarbonEmissions.setSelection(false);
				}
			}
		});
		btnRecordFuelOutline.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 4, 1));
		btnRecordFuelOutline.setText("Record fuel consumption");
		btnRecordFuelOutline.setSelection(false);
		btnRecordFuelOutline.setEnabled(false);

		btnRecordCarbonOutline = new Button(grpOutlineStatistics, SWT.CHECK);
		btnRecordCarbonOutline.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				btnRecordCarbonEmissions.setSelection(((Button) e.widget).getSelection());
				if (btnRecordCarbonEmissions.getSelection()) {
					btnRecordFuelOutline.setSelection(true);
					btnRecordFuelConsumption.setSelection(true);
				}
			}
		});
		btnRecordCarbonOutline.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 4, 1));
		btnRecordCarbonOutline.setText("Record carbon emissions (CO2)");
		btnRecordCarbonOutline.setSelection(false);
		btnRecordCarbonOutline.setEnabled(false);

		btnRecordEventsOutline = new Button(grpOutlineStatistics, SWT.CHECK);
		btnRecordEventsOutline.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 4, 1));
		btnRecordEventsOutline.setText("Record events");

		btnEnableContinuousOutline = new Button(grpOutlineStatistics, SWT.CHECK);
		btnEnableContinuousOutline.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateRecordingSection();
			}
		});
		btnEnableContinuousOutline.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 4, 1));
		btnEnableContinuousOutline.setText("Enable continuous outline recording");

		lblRecordingInterval = new Label(grpOutlineStatistics, SWT.NONE);
		lblRecordingInterval.setText("Recording interval");

		spinnerRecInterval = new Spinner(grpOutlineStatistics, SWT.BORDER);
		spinnerRecInterval.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateRecordingSection();
			}
		});
		spinnerRecInterval.setEnabled(false);
		spinnerRecInterval.setMaximum(3600000);
		spinnerRecInterval.setIncrement(1000);
		spinnerRecInterval.setPageIncrement(60000);

		lblMs = new Label(grpOutlineStatistics, SWT.NONE);
		lblMs.setText("ms");

		lblSeconds = new Label(grpOutlineStatistics, SWT.NONE);
		lblSeconds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		grpMiscStatistics = new Group(container, SWT.NONE);
		grpMiscStatistics.setLayout(new GridLayout(1, false));
		grpMiscStatistics.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpMiscStatistics.setText("Misc. Statistics");

		btnRecordRoadStatistics = new Button(grpMiscStatistics, SWT.CHECK);
		btnRecordRoadStatistics.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRecordRoadStatistics.setText("Record road statistics");

		btnRecordDetectorStatistics = new Button(grpMiscStatistics, SWT.CHECK);
		btnRecordDetectorStatistics.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRecordDetectorStatistics.setText("Record detector statistics");

		btnRecordCpuStatistics = new Button(grpMiscStatistics, SWT.CHECK);
		btnRecordCpuStatistics.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRecordCpuStatistics.setText("Record CPU statistics");

		btnRecordDebugEvents = new Button(grpMiscStatistics, SWT.CHECK);
		btnRecordDebugEvents.setToolTipText(
				"Various debug events are captured during a simulation run (e.g. variable changes). These events can be viewed in the Debug Monitor.");
		btnRecordDebugEvents.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRecordDebugEvents.setText("Record debug events");

		btnRecordModelInputStatistics = new Button(grpMiscStatistics, SWT.CHECK);
		btnRecordModelInputStatistics
				.setToolTipText("Records parameters passed to a vehicle's longitudinal model for acceleration for later reprodcibility");
		btnRecordModelInputStatistics.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRecordModelInputStatistics.setText("Record model input parameters");

		btnRecordDistractionOutlineStatistics = new Button(grpMiscStatistics, SWT.CHECK);
		btnRecordDistractionOutlineStatistics.setToolTipText(
				"Records various outline statistics, e.g. number of distractions, frequency, exposure, average duration etc. per distraction type");
		btnRecordDistractionOutlineStatistics.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		btnRecordDistractionOutlineStatistics.setText("Record distraction statistics");

		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		initializePreferences();
		updateRecordingSection();
		return container;
	}

	protected void updateRecordingSection() {
		btnEnableContinuousOutline.setEnabled(btnRecordOutline.getSelection());
		spinnerRecInterval.setEnabled(btnRecordOutline.getSelection() && btnEnableContinuousOutline.getSelection());
		lblSeconds.setText(DateUtil.getTimeSpan(((double) spinnerRecInterval.getSelection()) / 1000));

		btnRecordTime.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordDistance.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordPosition.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordSpeed.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordAcceleration.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordFuelConsumption.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordCarbonEmissions.setEnabled(btnRecordVehicleStatistics.getSelection());
		spinnerCacheSize.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordDistToFront.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordDistractionState.setEnabled(btnRecordVehicleStatistics.getSelection());

		boolean recordOutline = btnRecordOutline.getSelection();
		btnRecordCarbonOutline.setEnabled(recordOutline);
		btnRecordFuelOutline.setEnabled(recordOutline);
		btnRecordEventsOutline.setEnabled(recordOutline);

		boolean recordDetailedJunctionStatistics = btnRecordDetailedJunctionStatistics.getSelection();
		btnRecordTrafficControllerStatistics.setEnabled(recordDetailedJunctionStatistics);
		btnRecordTrafficLightStatistics.setEnabled(recordDetailedJunctionStatistics);
		btnRecordQueueMonitorStatistics.setEnabled(recordDetailedJunctionStatistics);

		boolean recordJunctionOutlineStatistics = btnRecordJunctionOutlineStatistics.getSelection();
		btnRecordIndividualWaitingTimes.setEnabled(recordJunctionOutlineStatistics);
	}

	private void initializePreferences() {
		btnRecordVehicleStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_STATISTICS));
		btnRecordTime.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordDistance.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordPosition.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordSpeed.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordAcceleration.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordFuelConsumption.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordCarbonEmissions.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordDistToFront.setEnabled(btnRecordVehicleStatistics.getSelection());
		btnRecordDistractionState.setEnabled(btnRecordVehicleStatistics.getSelection());

		btnRecordTime.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_TIME));
		btnRecordDistance.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_DISTANCE));
		btnRecordPosition.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_POSITION));
		btnRecordSpeed.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_SPEED));
		btnRecordAcceleration.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_ACCELERATION));
		btnRecordFuelConsumption.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_FUEL_CONSUMPTION));
		btnRecordFuelOutline.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_FUEL_CONSUMPTION));
		btnRecordCarbonEmissions.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_CARBON_EMISSIONS));
		btnRecordDistToFront.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_DIST_TO_FRONT));
		btnRecordDistractionState.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_DISTRACTION_STATE));
		btnRecordCarbonOutline.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_CARBON_EMISSIONS));
		btnRecordOutline.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS));
		btnRecordRoadStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_ROAD_STATISTICS));
		btnRecordJunctionOutlineStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS));
		btnRecordDetectorStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DETECTOR_STATISTICS));
		btnRecordCpuStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_CPU_STATISTICS));
		btnRecordDebugEvents.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DEBUG_EVENTS));
		btnRecordModelInputStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS));
		btnRecordDistractionOutlineStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DISTRACTION_STATISTICS));
		btnEnableContinuousOutline.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS_INTERVAL_ENABLED));
		spinnerRecInterval.setSelection(PreferenceUtil.getInt(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS_INTERVAL));
		spinnerCacheSize.setSelection(PreferenceUtil.getInt(IPreferenceConstants.CACHE_FILE_SIZE_TARGET));
		btnRecordEventsOutline.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_EVENTS));
		btnRecordDetailedJunctionStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DETAILED_JUNCTION_STATISTICS));
		btnRecordQueueMonitorStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_QUEUE_MONITORING_STATISTICS));
		btnRecordTrafficControllerStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_CONTROLLER_STATISTICS));
		btnRecordTrafficLightStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_TRAFFIC_LIGHT_STATISTICS));
		btnRecordIndividualWaitingTimes.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_INDIVIDUAL_WAITING_TIMES));
	}

	@Override
	protected void performApply() {
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_STATISTICS, btnRecordVehicleStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_TIME, btnRecordTime.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_DISTANCE, btnRecordDistance.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_POSITION, btnRecordPosition.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_SPEED, btnRecordSpeed.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_ACCELERATION, btnRecordAcceleration.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_CARBON_EMISSIONS, btnRecordCarbonEmissions.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_FUEL_CONSUMPTION, btnRecordFuelConsumption.getSelection());

		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS, btnRecordOutline.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_ROAD_STATISTICS, btnRecordRoadStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS, btnRecordJunctionOutlineStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_DETECTOR_STATISTICS, btnRecordDetectorStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_DEBUG_EVENTS, btnRecordDebugEvents.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_CPU_STATISTICS, btnRecordCpuStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS, btnRecordModelInputStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_DISTRACTION_STATISTICS, btnRecordDistractionOutlineStatistics.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS_INTERVAL, spinnerRecInterval.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS_INTERVAL_ENABLED, btnEnableContinuousOutline.getSelection());
		PreferenceUtil.setInt(IPreferenceConstants.CACHE_FILE_SIZE_TARGET, spinnerCacheSize.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_OUTLINE_EVENTS, btnRecordEventsOutline.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_DETAILED_JUNCTION_STATISTICS, btnRecordDetailedJunctionStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_QUEUE_MONITORING_STATISTICS, btnRecordQueueMonitorStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_TRAFFIC_CONTROLLER_STATISTICS, btnRecordTrafficControllerStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_TRAFFIC_LIGHT_STATISTICS, btnRecordTrafficLightStatistics.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_INDIVIDUAL_WAITING_TIMES, btnRecordIndividualWaitingTimes.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_DIST_TO_FRONT, btnRecordDistToFront.getSelection());
		PreferenceUtil.setBoolean(IPreferenceConstants.RECORD_VEHICLE_DISTRACTION_STATE, btnRecordDistractionState.getSelection());
	}

	@Override
	public boolean performOk() {
		performApply();
		return super.performOk();
	}
}
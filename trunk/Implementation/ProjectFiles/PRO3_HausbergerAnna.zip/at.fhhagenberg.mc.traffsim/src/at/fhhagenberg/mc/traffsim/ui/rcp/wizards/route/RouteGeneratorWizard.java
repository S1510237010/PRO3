package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.wizard.Wizard;

import at.fhhagenberg.mc.traffsim.routing.routegenerator.VehicleAttributes;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route.RouteParameterPage.RouteParameters;

public class RouteGeneratorWizard extends Wizard {
	public static final String PAGE_ROUTE_PAREMTERS = "route_parameters";
	public static final String PAGE_VEHICLE_SETS = "vehicle_sets";
	public static final String PAGE_CONFIGURATION_CREATION = "config_creation";

	private RouteParameterPage routeParameterPage;
	private VehicleParameterPage vehicleParameterPage;
	private RouteParameters routeParameters;
	private List<VehicleAttributes> vehicleParameters;
	private ConfigurationCreationPage configurationCopyPage;

	private String configFileName;
	private String vehiclesFileName;
	private String routesFileName;
	private String parametersFileName;
	private String outputFolder;
	private String commDataFileName;

	private boolean updateMappings;

	public RouteGeneratorWizard() {
		setWindowTitle("Route and Vehicle Generation");
		routeParameterPage = new RouteParameterPage(PAGE_ROUTE_PAREMTERS);
		vehicleParameterPage = new VehicleParameterPage(PAGE_VEHICLE_SETS);
		configurationCopyPage = new ConfigurationCreationPage(PAGE_CONFIGURATION_CREATION);
	}

	@Override
	public void addPages() {
		addPage(routeParameterPage);
		addPage(vehicleParameterPage);
		addPage(configurationCopyPage);
	}

	@Override
	public boolean canFinish() {
		if (getContainer().getCurrentPage() == null) {
			return false;
		}
		return (getContainer().getCurrentPage().equals(vehicleParameterPage) && vehicleParameterPage.isPageComplete())
				|| (getContainer().getCurrentPage().equals(configurationCopyPage) && configurationCopyPage.isPageComplete());
	}

	@Override
	public boolean performFinish() {
		routeParameters = routeParameterPage.getResult();
		vehicleParameters = new ArrayList<>(vehicleParameterPage.getResult());

		if (getContainer().getCurrentPage().equals(configurationCopyPage)) {
			configFileName = configurationCopyPage.getConfigurationFileName();
			vehiclesFileName = configurationCopyPage.getVehiclesFileName();
			commDataFileName = configurationCopyPage.getCommDataFileName();
			routesFileName = configurationCopyPage.getRoutesFileName();
			parametersFileName = configurationCopyPage.getParametersFileName();
			outputFolder = configurationCopyPage.getOutputFolder();
			updateMappings = configurationCopyPage.getUpdateMappings();
		} else {
			configFileName = null;
			vehiclesFileName = null;
			routesFileName = null;
			parametersFileName = null;
			outputFolder = null;
			updateMappings = false;
		}

		return true;
	}

	public RouteParameters getRouteParameters() {
		return routeParameters;
	}

	public boolean getAppendToExistingConfig() {
		return vehicleParameterPage.getAppendToExistingConfig();
	}

	public List<VehicleAttributes> getVehicleParameters() {
		return vehicleParameters;
	}

	public String getConfigFileName() {
		return configFileName;
	}

	public String getVehiclesFileName() {
		return vehiclesFileName;
	}

	public String getRoutesFileName() {
		return routesFileName;
	}

	public String getParametersFileName() {
		return parametersFileName;
	}

	public String getOutputFolder() {
		return outputFolder;
	}

	public String getCommDataFileName() {
		return commDataFileName;
	}

	public boolean getUpdateMappings() {
		return updateMappings;
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.helpers;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;

/**
 * Container class holding numerous model parameters of the Human Driver Model for later usage. Objects of this type are used to maintain a
 * list of historical values of various parameters in order to implement a delayed driver reaction.
 *
 * @author Manuel Lindorfer
 */
public class ModelParameterSet {

	/** The acceleration applied at the delayed time [m/s^2] */
	private double a;

	/** The velocity difference to the preceding vehicle at the delayed time [m/s] */
	private double dv;

	/** The net gaps to all spatially anticipated vehicles at the delayed time [m] */
	private List<Double> netGaps;

	/** The distance to the preceding vehicle at the delayed time [m] */
	private double s;

	/** The timely anticipated distance to the preceding vehicle at the delayed time [m] */
	private double sAnti;

	/** The velocity at the delayed time [m/s] */
	private double v;

	/** The timely anticipated velocity at the delayed time [m/s] */
	private double vAnti;

	/** The velocities of all spatially anticipated vehicles at the delayed time [m/s] */
	private List<Double> velocities;

	/**
	 * Instantiates a new parameter set.
	 *
	 * @param v
	 *            the vehicle's velocity at the delayed time [m/s]
	 * @param dv
	 *            the velocity difference to the preceding vehicle at the delayed time [m/s]
	 * @param s
	 *            the distance to the preceding vehicle at the delayed time [m]
	 * @param vehiclesToConsider
	 *            a list of vehicles to consider in the scope of spatial anticipation
	 * @param a
	 *            the currently applied acceleration
	 * @param rt
	 *            the currently active response time
	 */
	public ModelParameterSet(double v, double dv, double s, List<VehicleWithDistance> vehiclesToConsider, double a, double rt) {
		setV(v);
		setDv(dv);
		setS(s);
		setA(a);
		setVAnti(getV() + rt * a);
		setSAnti(getS() - rt * getDv());

		if (!vehiclesToConsider.isEmpty()) {
			netGaps = new ArrayList<Double>();
			velocities = new ArrayList<Double>();

			for (VehicleWithDistance vehicle : vehiclesToConsider) {
				netGaps.add(vehicle.getDistance());
				velocities.add(vehicle.getVehicle().getCurrentSpeed());
			}
		} else {
			netGaps = null;
			velocities = null;
		}
	}

	/**
	 * Gets the acceleration at the delayed time.
	 *
	 * @return the acceleration at the delayed time
	 */
	public double getA() {
		return a;
	}

	/**
	 * Gets the velocity difference to the preceding vehicle at the delayed time.
	 *
	 * @return the velocity difference to the preceding vehicle at the delayed time
	 */
	public double getDv() {
		return dv;
	}

	/**
	 * Gets the net gaps to all spatially anticipated preceding vehicles at the delayed time.
	 *
	 * @return the net gaps to all spatially anticipated preceding vehicles at the delayed time
	 */
	public List<Double> getNetGaps() {
		return netGaps;
	}

	/**
	 * Gets the distance to the preceding vehicle at the delayed time.
	 *
	 * @return the distance to the preceding vehicle at the delayed time
	 */
	public double getS() {
		return s;
	}

	/**
	 * Gets the temporally anticipated distance to the preceding vehicle at the delayed time.
	 *
	 * @return the temporally anticipated distance to the preceding vehicle at the delayed time
	 */
	public double getSAnti() {
		return sAnti;
	}

	/**
	 * Gets the vehicle's velocity at the delayed time.
	 *
	 * @return the velocity at the delayed time
	 */
	public double getV() {
		return v;
	}

	/**
	 * Gets the temporally anticipated velocity at the delayed time.
	 *
	 * @return the temporally anticipated velocity at the delayed time
	 */
	public double getVAnti() {
		return vAnti;
	}

	/**
	 * Gets the velocities to all spatially anticipated preceding vehicles at the delayed time.
	 *
	 * @return the velocities to all spatially anticipated preceding vehicles at the delayed time
	 */
	public List<Double> getVelocities() {
		return velocities;
	}

	/**
	 * Sets the acceleration at the delayed time.
	 *
	 * @param a
	 *            the new acceleration
	 */
	public void setA(double a) {
		this.a = a;
	}

	/**
	 * Sets the velocity difference to the preceding vehicle at the delayed time.
	 *
	 * @param dv
	 *            the new velocity difference
	 */
	public void setDv(double dv) {
		this.dv = dv;
	}

	/**
	 * Sets the net gaps to all spatially anticipated preceding vehicles at the delayed time.
	 *
	 * @param netGaps
	 *            the new net gaps
	 */
	public void setNetGaps(List<Double> netGaps) {
		this.netGaps = netGaps;
	}

	/**
	 * Sets the distance to the preceding vehicle at the delayed time.
	 *
	 * @param s
	 *            the new distance to the preceding vehicle
	 */
	public void setS(double s) {
		this.s = s;
	}

	/**
	 * Sets the temporally anticipated distance to the preceding vehicle at the delayed time.
	 *
	 * @param sAnti
	 *            the new temporally anticipated distance
	 */
	public void setSAnti(double sAnti) {
		this.sAnti = sAnti;
	}

	/**
	 * Sets the vehicle's velocity at the delayed time.
	 *
	 * @param v
	 *            the new velocity
	 */
	public void setV(double v) {
		this.v = v;
	}

	/**
	 * Sets the temporally anticipated velocity at the delayed time.
	 *
	 * @param vAnti
	 *            the new temporally anticipated velocity
	 */
	public void setVAnti(double vAnti) {
		this.vAnti = vAnti;
	}

	/**
	 * Sets the velocities of all spatially anticipated preceding vehicles at the delayed time.
	 *
	 * @param velocities
	 *            the new velocities
	 */
	public void setVelocities(List<Double> velocities) {
		this.velocities = velocities;
	}
}

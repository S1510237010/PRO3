package at.fhhagenberg.mc.traffsim.ui.rcp.views.performancemonitor;

import java.lang.management.ManagementFactory;

import org.apache.commons.lang3.ArrayUtils;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.statistics.CpuInfo;

public class PerformanceMonitorView extends ViewPart implements IThreadUpdateListener {
	private Table table;
	private TableViewer viewer;
	private MyViewerComparator comparator = new MyViewerComparator();
	private ThreadInfoCollector updater;
	private Text textOverallCpu;
	private Text textThreadCount;
	private Text textMonitorEffort;
	private Text textCores;
	private Text textMhz;
	private Text textCpuLabel;
	private Text textVendor;
	private CpuInfo cpuinfo;

	public PerformanceMonitorView() {
		updater = SimulationKernel.getInstance().getThreadInfoUpdater();
		updater.setThreadUpdateListener(this);
	}

	private class MyViewerComparator extends ViewerComparator {
		private int propertyIndex;
		private static final int DESCENDING = 0;
		private int direction = 1;

		public MyViewerComparator() {
			this.propertyIndex = 0;
			direction = DESCENDING;
		}

		public int getDirection() {
			return direction == 1 ? SWT.UP : SWT.DOWN;
		}

		public void setColumn(int column) {
			if (column == this.propertyIndex) {
				// Same column as last sort; toggle the direction
				direction = 1 - direction;
			} else {
				// New column; do an ascending sort
				this.propertyIndex = column;
				direction = DESCENDING;
			}
		}

		@Override
		public int compare(Viewer viewer, Object e1, Object e2) {
			Long l1 = (Long) e1;
			Long l2 = (Long) e2;
			int rc = 0;
			DetailThreadInfo info1 = updater.getInfo(l1);
			DetailThreadInfo info2 = updater.getInfo(l2);
			boolean isnull = info1 == null || info2 == null || info1.getInfo() == null || info2.getInfo() == null;
			switch (propertyIndex) {
			case 0:
				rc = l1.compareTo(l2);
				break;
			case 1:
				rc = isnull ? 0 : info1.getInfo().getThreadName().compareTo(info2.getInfo().getThreadName());
				break;
			case 2:
				rc = isnull ? 0 : Double.compare(info1.getCputime(), info2.getCputime());
				break;
			case 3:
				rc = isnull ? 0 : info1.getInfo().getThreadState().toString().compareTo(info2.getInfo().getThreadState().toString());
				break;
			default:
				rc = 0;
			}
			// If descending order, flip the direction
			if (direction == DESCENDING) {
				rc = -rc;
			}
			return rc;
		}
	}

	@Override
	public void dispose() {
		updater.resetThreadUpdateListener();
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		Composite composite_1 = new Composite(parent, SWT.NONE);
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		composite_1.setLayout(new GridLayout(2, false));

		Label lblCpu = new Label(composite_1, SWT.NONE);
		lblCpu.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblCpu.setText("CPU:");

		textCpuLabel = new Text(composite_1, SWT.BORDER);
		textCpuLabel.setEditable(false);
		textCpuLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		SashForm sashForm = new SashForm(parent, SWT.NONE);
		sashForm.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		viewer = new TableViewer(sashForm, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI);
		table = viewer.getTable();
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));
		composite.setLayout(new GridLayout(2, false));

		Group grpCpuInfo = new Group(composite, SWT.NONE);
		grpCpuInfo.setText("CPU Info");
		grpCpuInfo.setLayout(new GridLayout(2, false));
		grpCpuInfo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));

		Label lblVendor = new Label(grpCpuInfo, SWT.NONE);
		lblVendor.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblVendor.setText("Vendor");

		textVendor = new Text(grpCpuInfo, SWT.BORDER);
		textVendor.setEditable(false);
		textVendor.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblCores = new Label(grpCpuInfo, SWT.NONE);
		lblCores.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblCores.setText("Cores");

		textCores = new Text(grpCpuInfo, SWT.BORDER);
		textCores.setEditable(false);
		textCores.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblMhz = new Label(grpCpuInfo, SWT.NONE);
		lblMhz.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMhz.setText("MHz");

		textMhz = new Text(grpCpuInfo, SWT.BORDER);
		textMhz.setEditable(false);
		textMhz.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblOverallCpuTime = new Label(composite, SWT.NONE);
		lblOverallCpuTime.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblOverallCpuTime.setText("Overall CPU Time");

		textOverallCpu = new Text(composite, SWT.BORDER | SWT.READ_ONLY);
		textOverallCpu.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblThreadCount = new Label(composite, SWT.NONE);
		lblThreadCount.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblThreadCount.setText("Thread count");

		textThreadCount = new Text(composite, SWT.BORDER | SWT.READ_ONLY);
		textThreadCount.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblMonitorEffort = new Label(composite, SWT.NONE);
		lblMonitorEffort.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMonitorEffort.setText("Monitor effort");

		textMonitorEffort = new Text(composite, SWT.BORDER | SWT.READ_ONLY);
		textMonitorEffort.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		sashForm.setWeights(new int[] { 3, 1 });

		createColumns(viewer);
		viewer.setContentProvider(new ArrayContentProvider());
		viewer.setInput(ArrayUtils.toObject(ManagementFactory.getThreadMXBean().getAllThreadIds()));
		viewer.setComparator(comparator);

		// fill cpu info
		cpuinfo = updater.getCpuInfo();
		if (cpuinfo != null) {
			textCpuLabel.setText(cpuinfo.getLabel());
			textCores.setText(String.valueOf(cpuinfo.getCores()));
			textVendor.setText(cpuinfo.getVendor());
			textMhz.setText(String.valueOf(cpuinfo.getClockFrequency()));
		}
	}

	private void createColumns(TableViewer viewer) {
		int colindex = 0;

		TableViewerColumn colId = createTableViewerColumn(ThreadInfoColumn.ID, 50, colindex++);
		colId.setLabelProvider(new ThreadInfoLabelProvider(updater, ThreadInfoColumn.ID));

		TableViewerColumn colName = createTableViewerColumn(ThreadInfoColumn.NAME, 250, colindex++);
		colName.setLabelProvider(new ThreadInfoLabelProvider(updater, ThreadInfoColumn.NAME));

		TableViewerColumn colCpuTime = createTableViewerColumn(ThreadInfoColumn.CPU_TIME, 80, colindex++);
		colCpuTime.setLabelProvider(new ThreadInfoLabelProvider(updater, ThreadInfoColumn.CPU_TIME));

		TableViewerColumn colState = createTableViewerColumn(ThreadInfoColumn.STATE, 150, colindex++);
		colState.setLabelProvider(new ThreadInfoLabelProvider(updater, ThreadInfoColumn.STATE));

	}

	private TableViewerColumn createTableViewerColumn(ThreadInfoColumn col, int width, int colNumber) {
		final TableViewerColumn viewerColumn = new TableViewerColumn(viewer, SWT.NONE);
		final TableColumn column = viewerColumn.getColumn();
		column.setText(col.toString());
		column.setWidth(width);
		column.setResizable(true);
		column.setMoveable(true);
		column.addSelectionListener(getSelectionAdapter(column, colNumber));
		return viewerColumn;
	}

	private SelectionAdapter getSelectionAdapter(final TableColumn column, final int index) {
		SelectionAdapter selectionAdapter = new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				comparator.setColumn(index);
				int dir = comparator.getDirection();
				viewer.getTable().setSortDirection(dir);
				viewer.getTable().setSortColumn(column);
				viewer.refresh();
			}
		};
		return selectionAdapter;
	}

	@Override
	public void setFocus() {

	}

	@Override
	public void threadListUpdated(long[] newList) {
		getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				viewer.setInput(ArrayUtils.toObject(newList));
			}
		});
	}

	@Override
	public void dataUpdated() {
		getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (!viewer.getTable().isDisposed()) {
					viewer.refresh();
					textOverallCpu.setText(String.format("%.3f s", updater.getCpuSum()));
					textThreadCount.setText(String.valueOf(updater.getThreadCount()));
					textMonitorEffort.setText(String.format("%.3f s", updater.getOwnRuntime()));
				}
			}
		});
	}

	private Display getDisplay() {
		if (getSite() != null && getSite().getShell() != null && getSite().getShell().getDisplay() != null) {
			return getSite().getShell().getDisplay();
		}
		return Display.getCurrent() != null ? Display.getCurrent() : Display.getDefault();
	}

}

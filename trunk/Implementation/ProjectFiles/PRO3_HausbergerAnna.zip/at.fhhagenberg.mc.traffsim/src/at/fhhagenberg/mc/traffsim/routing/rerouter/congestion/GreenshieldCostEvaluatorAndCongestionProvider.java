package at.fhhagenberg.mc.traffsim.routing.rerouter.congestion;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.routing.AbstractRouteService;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICongestionProvider;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.statistics.events.IEventLog;
import at.fhhagenberg.mc.traffsim.util.ThreadingUtil;
import at.fhhagenberg.mc.traffsim.util.types.PositiveMovingAverage;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleFactory;

public class GreenshieldCostEvaluatorAndCongestionProvider extends AbstractCostAndCongestionEvaluator implements ICongestionProvider {

	private int movingAverageSize;

	public GreenshieldCostEvaluatorAndCongestionProvider(String name, long updateIntervalMillis, long congestionDetectionUpdateMs,
			RoadNetwork network, AbstractRouteService router, int movingAverageSize, float congestionThresholdDelta, int congestionLevel,
			int numVehiclesForCongestion, IEventLog log) {
		super(name, updateIntervalMillis, congestionDetectionUpdateMs, network, router, congestionThresholdDelta, congestionLevel,
				numVehiclesForCongestion, log);
		if (congestionThresholdDelta < 0 || congestionThresholdDelta > 1 || congestionLevel < 1) {
			throw new IllegalArgumentException(
					"Illegal value for congestion threshold delta (" + congestionThresholdDelta + ") or congestion level (" + congestionLevel + ")");
		}
		this.movingAverageSize = movingAverageSize;
	}

	@Override
	protected void updateSpeedMapsAndCongestion() {
		ThreadingUtil.executeAction(network.getRoadSegments(), seg -> {
			long numVeh = observationCenter.getNumVehicles(seg.getId());
			/** traffic density */
			double k_i = numVeh / seg.getRoadLength();
			/** maximum traffic density */
			double maxNumVehicles = Math
					.ceil(seg.getRoadLength() / (VehicleFactory.getAverageVehicleLength() + VehicleFactory.getMinLongitudinalGap()));
			double k_jam = maxNumVehicles / seg.getRoadLength();
			/** freeflow speed */
			double v_f = seg.getSpeedLimitMps();
			/** estimated road speed */
			double v_i = v_f * (1 - k_i / k_jam);

			speedCurrentMap.put(seg.getId(), v_i);
			if (!speedAverageMap.containsKey(seg.getId())) {
				speedAverageMap.put(seg.getId(), new PositiveMovingAverage(movingAverageSize));
				speedMaxMap.put(seg.getId(), seg.getSpeedLimitMps());
			}
			speedAverageMap.get(seg.getId()).addValue(v_i);
			if (k_i / k_jam >= congestionThreshold && numVeh > numVehiclesForCongestion && !isMultiNotification(seg.getId())) {
				lastCongestedNotifications.put(seg.getId(), getCurrentSimTime().getTime());
				congestedSegments.add(seg);
				eventLog.logCongestion(EventType.CONGESTION_DETECTED, "Greenshield",
						"Segment ID #" + seg.getId() + " (" + seg.getName() + ") congested", seg.getEndNode().getId(), seg.getId(), k_i / k_jam);
			}
		}, "updating greenshield speed maps");
		overrideSegmentCost();
	}

}

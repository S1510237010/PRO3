package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.LogMessage;
import at.fhhagenberg.mc.traffsim.model.ILogConsumer;
import at.fhhagenberg.mc.traffsim.model.batch.BatchExecutor;
import at.fhhagenberg.mc.traffsim.model.batch.IBatchListener;
import at.fhhagenberg.mc.traffsim.model.batch.ScheduledSimulation;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.util.CollectionUtil;

public class BatchMonitorView extends ViewPart implements IBatchListener, ILogConsumer {
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.batchmonitor";

	protected static final String TICK = "\u2714 ";

	private Text textBatchLog;
	private List<String> currentScheduledSimulations;
	private Label lblNumConfigurations;
	private org.eclipse.swt.widgets.List listConfigurations;
	private ProgressBar progressBarConfigurations;
	private Label lblNumSimulations;
	private org.eclipse.swt.widgets.List listSimulations;
	private ProgressBar progressBarSimulations;

	private BatchExecutor executor;
	private SashForm sashForm;
	private Composite composite_1;
	private Composite composite_2;

	private Composite composite;

	private Button btnPauseBatch;

	private Button btnStopBatch;
	private SashForm sashForm_1;
	/** remembers the last index of the configuration, in case multiple equal configurations are contained in this list */
	private Map<String, Integer> lastSelectionIndices = new HashMap<>();
	private Label lblCompleted;
	private Text textCompletedSimulations;

	public BatchMonitorView() {
		SimulationKernel.getInstance().registerBatchListener(this);
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		sashForm = new SashForm(parent, SWT.VERTICAL);
		sashForm.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new GridLayout(3, false));

		Label lblSimulationConfigurations = new Label(composite_1, SWT.NONE);
		lblSimulationConfigurations.setText("Configuration files");

		lblNumConfigurations = new Label(composite_1, SWT.NONE);
		GridData gd_lblNumConfigurations = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_lblNumConfigurations.widthHint = 80;
		lblNumConfigurations.setLayoutData(gd_lblNumConfigurations);
		lblNumConfigurations.setText("(?/?)");

		sashForm_1 = new SashForm(composite_1, SWT.VERTICAL);
		sashForm_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 5));

		listConfigurations = new org.eclipse.swt.widgets.List(sashForm_1, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);

		listSimulations = new org.eclipse.swt.widgets.List(sashForm_1, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI);
		sashForm_1.setWeights(new int[] { 1, 1 });

		progressBarConfigurations = new ProgressBar(composite_1, SWT.SMOOTH);
		progressBarConfigurations.setLayoutData(new GridData(SWT.FILL, SWT.TOP, false, false, 2, 1));

		Label lblSimulations = new Label(composite_1, SWT.NONE);
		lblSimulations.setText("Simulations");

		lblNumSimulations = new Label(composite_1, SWT.NONE);
		lblNumSimulations.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		lblNumSimulations.setText("(?/?)");

		progressBarSimulations = new ProgressBar(composite_1, SWT.NONE);
		progressBarSimulations.setLayoutData(new GridData(SWT.FILL, SWT.TOP, false, false, 2, 1));

		lblCompleted = new Label(composite_1, SWT.WRAP);
		lblCompleted.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, false, false, 1, 1));
		lblCompleted.setText("Completed\nsimulations:");

		textCompletedSimulations = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		textCompletedSimulations.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, false, false, 1, 1));
		textCompletedSimulations.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));

		composite_2 = new Composite(sashForm, SWT.NONE);
		composite_2.setLayout(new GridLayout(1, false));

		textBatchLog = new Text(composite_2, SWT.BORDER | SWT.READ_ONLY | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL);
		textBatchLog.setEditable(false);
		textBatchLog.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		textBatchLog.setText("No batch simulation running.\n");
		sashForm.setWeights(new int[] { 5, 4 });
		composite = new Composite(parent, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		GridLayout gl_composite = new GridLayout(2, true);
		gl_composite.marginWidth = 0;
		gl_composite.marginHeight = 0;
		composite.setLayout(gl_composite);

		btnPauseBatch = new Button(composite, SWT.TOGGLE);
		btnPauseBatch.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnPauseBatch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (executor != null) {
					executor.setPause(btnPauseBatch.getSelection());
				}
			}
		});
		btnPauseBatch.setText("Pause Batch");

		btnStopBatch = new Button(composite, SWT.NONE);
		btnStopBatch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (executor != null) {
					append("Batch stopped.");
					progressBarConfigurations.setSelection(0);
					progressBarSimulations.setSelection(0);
					listConfigurations.setItems(new String[0]);
					listSimulations.setItems(new String[0]);
					executor.stopBatch();
					lastSelectionIndices = new HashMap<>();
				}
			}
		});
		btnStopBatch.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnStopBatch.setText("Stop Batch");
	}

	@Override
	public void setFocus() {

	}

	public void append(String text) {
		textBatchLog.setText(textBatchLog.getText() + "\n" + text + "\n");
	}

	@Override
	public void batchStarted(List<File> originalConfigurations, List<ScheduledSimulation> currentScheduledSimulations, BatchExecutor executor) {
		executor.setLogConsumer(this);
		getViewSite().getShell().getDisplay().syncExec(new Runnable() {

			@Override
			public void run() {
				listConfigurations.removeAll();
				listSimulations.removeAll();
				btnPauseBatch.setEnabled(true);
				btnStopBatch.setEnabled(true);
				textBatchLog.append("\n---\n");
				textBatchLog.append(String.format("Simulation started: %d configurations\n", CollectionUtil.getSize(originalConfigurations)));
				refreshCurrentSimulations(toSimulationIdentifiers(currentScheduledSimulations), false);
				refreshCurrentConfigurations(originalConfigurations);
				progressBarConfigurations.setMaximum(originalConfigurations.size());
				lblNumConfigurations.setText("(0/" + originalConfigurations.size() + ")");
			}
		});
		this.executor = executor;
	}

	private List<String> toSimulationIdentifiers(Collection<ScheduledSimulation> simulations) {
		return simulations != null ? simulations.stream().map(s -> s.toString()).collect(Collectors.toList()) : null;
	}

	private String toConfFileString(File file) {
		File original = SimulationKernel.getInstance().getTempToOriginalFileMapping().get(file);
		return original.getName() + " - " + original.getAbsolutePath() + "  (" + file.getAbsolutePath() + ")";
	}

	private void refreshCurrentSimulations(List<String> sims, boolean clearOld) {
		if (clearOld) {
			listSimulations.removeAll();
			for (String sim : sims) {
				sim = sim.replaceAll(TICK, "");
			}
		}
		if (sims != null) {
			progressBarSimulations.setMaximum(Math.max(CollectionUtil.getSize(sims), listSimulations.getItemCount()));
			lblNumSimulations.setText("(0/" + progressBarSimulations.getMaximum() + ")");

			List<String> items = CollectionUtil.toArrayList(listSimulations.getItems());
			for (String scheduledSimulation : sims) {
				if (!items.contains(scheduledSimulation)) {
					listSimulations.add(scheduledSimulation);
				}
			}
		}
	}

	private void refreshCurrentConfigurations(List<File> originalConfigurations) {
		listConfigurations.removeAll();
		for (File file : originalConfigurations) {
			listConfigurations.add(toConfFileString(file));
		}
	}

	@Override
	public void currentSimulationsChanged(List<ScheduledSimulation> newScheduledSimulations, Collection<ScheduledSimulation> activeSims,
			boolean clearOld) {

		getViewSite().getShell().getDisplay().syncExec(new Runnable() {

			@Override
			public void run() {
				List<String> newScheduledSimStrings = toSimulationIdentifiers(newScheduledSimulations);
				if (currentScheduledSimulations == null || !currentScheduledSimulations.containsAll(newScheduledSimStrings) || clearOld) {
					refreshCurrentSimulations(CollectionUtil.union(newScheduledSimStrings, toSimulationIdentifiers(activeSims)), clearOld);
					currentScheduledSimulations = newScheduledSimStrings;
				}
				if (!listSimulations.isDisposed()) {
					List<Integer> indicesToSelect = new ArrayList<>();
					if (activeSims != null) {
						int[] curSel = listSimulations.getSelectionIndices();
						if (curSel.length > 0) {
							for (int i : curSel) {
								String curItem = listSimulations.getItem(i);
								if (!activeSims.stream().anyMatch(s -> s.toString().equals(curItem))) {
									listSimulations.setItem(i, TICK + curItem);
								}
							}
						}
						listSimulations.deselectAll();
						for (Iterator<ScheduledSimulation> simIt = activeSims.iterator(); simIt.hasNext();) {
							ScheduledSimulation active = simIt.next();
							int index = listSimulations.indexOf(active.toString());
							indicesToSelect.add(index);
							progressBarSimulations.setSelection(index);
						}
						lblNumSimulations.setText("(" + (NumberUtil.max(indicesToSelect, -1) + 1) + "/" + progressBarSimulations.getMaximum() + ")");
						listSimulations.select(CollectionUtil.toPrimitiveIntArray(indicesToSelect));
						listSimulations.showSelection();
					} else {
						listSimulations.deselectAll();
					}
				}
				textCompletedSimulations.setText(executor.getNumSimulationsDone() + "");
			}
		});
	}

	@Override
	public void currentConfigurationsChanged(List<File> newConfigurations, File active) {
		getViewSite().getShell().getDisplay().syncExec(new Runnable() {

			@Override
			public void run() {
				if (listConfigurations.isDisposed()) {
					return;
				}

				listConfigurations.deselectAll();
				if (active != null) {
					final String activeAsString = toConfFileString(active);
					if (!lastSelectionIndices.containsKey(activeAsString)) {
						lastSelectionIndices.put(activeAsString, 0);
					} else {
						lastSelectionIndices.put(activeAsString, lastSelectionIndices.get(activeAsString) + 1);
					}
					int index = listConfigurations.indexOf(activeAsString, lastSelectionIndices.get(activeAsString));
					listConfigurations.select(index);
					listConfigurations.showSelection();
					progressBarConfigurations.setSelection(index);
					lblNumConfigurations.setText(increaseNum(lblNumConfigurations.getText()));

				}
			}
		});
	}

	/**
	 * @param s
	 *            String in the form (1/2)
	 * @return increased value (2/2)
	 */
	private String increaseNum(String s) {
		int bracket = s.indexOf('(');
		int slash = s.indexOf('/');
		int num = Integer.valueOf(s.substring(bracket + 1, slash));
		num++;
		return "(" + num + s.substring(slash);
	}

	@Override
	public void addLogLine(LogMessage message) {
		getViewSite().getShell().getDisplay().syncExec(new Runnable() {

			@Override
			public void run() {
				textBatchLog.append(message.getFullMessage() + "\n");
			}
		});
	}

	@Override
	public void batchFinished() {
		getViewSite().getShell().getDisplay().syncExec(new Runnable() {

			@Override
			public void run() {
				progressBarConfigurations.setSelection(progressBarConfigurations.getMaximum());
				progressBarSimulations.setSelection(progressBarSimulations.getMaximum());
				btnPauseBatch.setEnabled(false);
				btnStopBatch.setEnabled(false);
			}
		});
		executor = null;
		lastSelectionIndices = new HashMap<>();
	}

	@Override
	public void dispose() {
		if (executor != null) {
			executor.setLogConsumer(null);
		}

		SimulationKernel.getInstance().unregisterBatchListener(this);
	}

	@Override
	public void logLine(final String line) {
		getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				if (!line.endsWith("\n")) {
					textBatchLog.append(line + "\n");
				} else {
					textBatchLog.append(line);
				}
			}
		});
	}

	@Override
	public void replaceLastLogCharacters(int numChar, String toAppend) {
		getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				String text = textBatchLog.getText();
				String newText = text.substring(0, text.length() - numChar) + toAppend;
				textBatchLog.setText(newText);
			}
		});
	}

	public void setViewTitle(String title) {
		setPartName(title);
	}
}

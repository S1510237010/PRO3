package at.fhhagenberg.mc.traffsim.ui.osm;

import org.jdesktop.swingx.VirtualEarthTileFactoryInfo;
import org.jdesktop.swingx.mapviewer.TileFactoryInfo;

/**
 * Overridden {@link TileFactoryInfo} in order to fix the minimum zoom level (down to 0 is available from virtualearth tile server)
 * 
 * @author Christian Backfrieder
 * 
 **/
public class CustomVirtualEarthTileFactoryInfo extends VirtualEarthTileFactoryInfo {

	private int minZoomLevel = 0;

	public CustomVirtualEarthTileFactoryInfo(MVEMode mode) {
		super(mode);
	}

	public CustomVirtualEarthTileFactoryInfo(MVEMode mode, int minZoomLevel) {
		super(mode);
		this.minZoomLevel = minZoomLevel;
	}

	@Override
	public int getMinimumZoomLevel() {
		return minZoomLevel;
	}

}

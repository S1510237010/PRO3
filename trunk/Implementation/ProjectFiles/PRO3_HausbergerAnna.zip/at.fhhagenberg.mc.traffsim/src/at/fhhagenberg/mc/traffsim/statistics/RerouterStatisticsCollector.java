package at.fhhagenberg.mc.traffsim.statistics;

import at.fhhagenberg.mc.traffsim.model.ThreadConstants;
import at.fhhagenberg.mc.util.StringUtil;

public class RerouterStatisticsCollector implements IThreadInfoListener {

	private double cpuTime;
	private String modelId;

	public RerouterStatisticsCollector(String modelId) {
		this.modelId = modelId;
	}

	@Override
	public String getPattern() {
		return ".*" + StringUtil.createThreadName(modelId, ThreadConstants.REROUTER_NAME + ".*");
	}

	@Override
	public void setCpuTime(double newTime) {
		this.cpuTime = newTime;
	}

	@Override
	public double getCpuTime() {
		return cpuTime;
	}

	@Override
	public void resetTime() {
		cpuTime = 0;
	}

}

package at.fhhagenberg.mc.traffsim.statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;

public class TrafficLightStatisticsData implements Serializable {

	private static final long serialVersionUID = 7610408927145231445L;

	protected final long junctionId;
	protected final long approachId;
	protected final long trafficLightId;
	protected List<Double> time = new ArrayList<>();
	protected List<Double> serviceLength = new ArrayList<>();
	protected List<Double> serviceState = new ArrayList<>();

	protected long recordedItems;

	public TrafficLightStatisticsData() {
		junctionId = -1;
		approachId = -1;
		trafficLightId = -1;
	}

	public TrafficLightStatisticsData(long trafficLightId, long approachId, long junctionId) {
		this.trafficLightId = trafficLightId;
		this.approachId = approachId;
		this.junctionId = junctionId;
	}

	public long getTrafficLightId() {
		return trafficLightId;
	}

	public long getApproachId() {
		return approachId;
	}

	public long getJunctionId() {
		return junctionId;
	}

	public List<Double> getTime() {
		return time;
	}

	public List<Double> getServiceLength() {
		return serviceLength;
	}

	public List<Double> getServiceState() {
		return serviceState;
	}

	public synchronized void addData(double time, ControlLogic controlLogic) {
		Map<String, Number> data = controlLogic.obtainStatistics();
		this.time.add(time);
		this.serviceLength.add((double) data.get(IStatsConstants.CONTROL_LOGIC_SERVICE_LENGTH));
		this.serviceState.add((double) data.get(IStatsConstants.CONTROL_LOGIC_SERVICE_STATE));
		recordedItems++;
	}

	public TrafficLightStatisticsData collectData(int numItemsToKeep) {
		TrafficLightStatisticsData data = new TrafficLightStatisticsData(trafficLightId, approachId, junctionId);
		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.time.addAll(time.subList(0, numItems));
				data.serviceLength.addAll(serviceLength.subList(0, numItems));
				data.serviceState.addAll(serviceState.subList(0, numItems));

				// remove the collected sublist from statistics data
				time = new ArrayList<>(time.subList(numItems, lastIndex));
				serviceLength = new ArrayList<>(serviceLength.subList(numItems, lastIndex));
				serviceState = new ArrayList<>(serviceState.subList(numItems, lastIndex));
				data.recordedItems = recordedItems;
			}
		}

		return data;
	}
}

package at.fhhagenberg.mc.traffsim.model;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

/**
 * Abstract base class for processes which must be updated in an time interval measured in simulation time (not real time). It allows
 * continuous, recurring tasks which need not to run each simulation time step, but where their successful execution must be ensured in a
 * defined interval. Thus, the interval of executions does not depend on the specified simulation delay, since complete execution is ensured
 * by blocking {@link #timeStep(double, Date, double)} before next call of {@link #doWorkWaitForFinish()}<br>
 * <br>
 * <b>Important:</b> Do not forget to register the implementation as {@link ISimulationTimeUpdatable}!<br>
 * <br>
 * <b>Example:</b> A task must be executed every 500 ms of simulation time and made sure that execution is completed before the next
 * execution of this same task. Therefore, this class is inherited, and constructed with <code>"name", 500</code> as parameters. Every 500
 * ms of simulation time, the {@link #doWorkWaitForFinish()} method is called, and {@link #timeStep(double, Date, double)} blocks, if and
 * only if the task within method {@link #doWorkWaitForFinish()}is not completed.
 *
 * @author Christian B.
 *
 */
public abstract class IntervalUpdateThread extends PauseableThread implements ISimulationTimeUpdatable, ISimulationTimeProvider {

	/** timestamp of last execution of {@link #doWork()} */
	private long lastUpdateMillis = 0;
	/** the update interval (measured in simulation time) */
	protected long updateIntervalMillis;
	/** the current simulation time */
	private Date curSimTime = new Date(0);
	private double runTime;

	private boolean singleThreadedExecution = PreferenceUtil.getBoolean(IPreferenceConstants.SINGLETHREADED_EXECUTION);
	private ExecutorService currentTaskExecutor;

	/**
	 * Default constructor.
	 *
	 * @param name
	 * @param updateIntervalMillis
	 *
	 * @see IntervalUpdateThread#IntervalUpdateThread(String, long, boolean)
	 */
	public IntervalUpdateThread(String name, long updateIntervalMillis) {
		this(name, updateIntervalMillis, true);
	}

	/**
	 *
	 * @param name
	 *            The name of this thread
	 * @param updateIntervalMillis
	 *            the update interval, with which this thread is called, measured in simulation time. If execution of
	 *            {@link #doWorkWaitForFinish()} is not complete until next request, {@link #timeStep(double, Date, double)} is blocked
	 *            until completion.
	 * @param startThread
	 *            switch to set whether the thread should be started by the constructor immediately, or needs to be started later manually
	 */
	public IntervalUpdateThread(String name, long updateIntervalMillis, boolean startThread) {
		this(name, 5, updateIntervalMillis, startThread);
	}

	/**
	 * Private constructor with all parameters, because delayInMillis is irrelevant here
	 *
	 * @param name
	 * @param delayInMillis
	 * @param updateIntervalMillis
	 * @param startThread
	 */
	private IntervalUpdateThread(String name, long delayInMillis, long updateIntervalMillis, boolean startThread) {
		super(name, delayInMillis);
		this.updateIntervalMillis = updateIntervalMillis;
		if (startThread) {
			startPaused();
		}
	}

	@Override
	public final void doWork() {
		if (!singleThreadedExecution) {
			doWorkWaitForFinish();
		}
		pause();
	}

	/**
	 * Work which must be done in the specified interval, measured in simulation time. Wait for finishing of this call if next call if it is
	 * not finished within period (if execution takes longer than interval with which {@link #timeStep(double, Date, double)} is called).
	 */
	public abstract void doWorkWaitForFinish();

	/**
	 * This method is fully synchronized and blocks {@link #timeStep(double, Date, double)} until finishing of execution - in constrast to
	 * {@link #doWorkWaitForFinish()} which does not immediately block execution flow, but only if execution takes longer than specified
	 * interval.
	 *
	 * In other words, this means that the code within this method is executed in the main simulation driver thread ({@link SimulationRun}),
	 * while {@link #doWorkWaitForFinish()} is executed in a separate thread, created by {@link IntervalUpdateThread}
	 */
	public void doSynchronizedWork() {

	}

	private final void doInitialSynchronizedWork() {
		if (singleThreadedExecution) {
			doWorkWaitForFinish();
		}
	}

	@Override
	public void timeStep(double dt, Date time, double runTime) {
		this.curSimTime = time;
		this.runTime = runTime;
		if (time.getTime() - lastUpdateMillis >= updateIntervalMillis) {
			/** wait for finish of task before next task is started -> ensure that specified interval is observed */
			while (!isPaused()) {
				try {
					Thread.sleep(3);
				} catch (InterruptedException e) {
					break;
				}
			}
			proceed();
			// System.out.println(getName() + " " + DateUtil.formatWithMiliseconds(time));
			lastUpdateMillis = time.getTime();
			/** additionally, */
			doInitialSynchronizedWork();
			doSynchronizedWork();
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see at.fhhagenberg.mc.traffsim.model.SimulationTimeProvider#getCurSimTime()
	 */
	@Override
	public Date getCurrentSimTime() {
		return curSimTime;
	}

	/**
	 *
	 * @return the update interval of this thread, in miliseconds measured in simulation time ({@link #doSynchronizedWork()} and
	 *         {@link #doWorkWaitForFinish()} are called in this interval)
	 */
	public long getUpdateIntervalMillis() {
		return updateIntervalMillis;
	}

	/**
	 *
	 * @return the current simulation runtime in seconds
	 */
	public double getRunTime() {
		return runTime;
	}

	@Override
	protected void stopInitiated() {
		if (currentTaskExecutor != null) {
			currentTaskExecutor.shutdownNow();
		}
	}

	/**
	 * Helper method which can trigger task execution, and passes exception only if this thread has not been stopped yet
	 *
	 * @param exec
	 *            the {@link ExecutorService} to use
	 * @param tasks
	 *            the tasks to execute
	 */
	public void executeTasks(ExecutorService exec, List<Callable<Object>> tasks) {
		List<Future<Object>> futures = Collections.emptyList();
		try {
			currentTaskExecutor = exec;
			futures = exec.invokeAll(tasks);
			currentTaskExecutor = null;
		} catch (Exception e1) {
			if (!isStopped() && !currentTaskExecutor.isShutdown()) {
				Logger.logWarn("Error in task execution processor of " + getName(), e1);
			}
		}

		for (Future<Object> future : futures) {
			try {
				future.get();
			} catch (Exception e) {
				if (!isStopped()) {
					Logger.logWarn("Error in " + getName(), e);
				}
			}
		}
	}
}

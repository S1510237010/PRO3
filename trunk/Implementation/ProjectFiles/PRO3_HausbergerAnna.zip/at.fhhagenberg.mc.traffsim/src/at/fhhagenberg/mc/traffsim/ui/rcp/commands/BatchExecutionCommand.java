package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.io.File;
import java.util.List;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.batch.BatchExecutor;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.BatchMonitorView;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.batch.BatchExecutionWizard;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.ui.SWTUtil;

public class BatchExecutionCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		BatchExecutionWizard wizard = new BatchExecutionWizard();
		WizardDialog dialog = new WizardDialog(Display.getCurrent().getActiveShell(), wizard);
		int result = dialog.open();
		if (result == Dialog.CANCEL) {
			return null;
		}

		List<File> files = wizard.getResult();

		SWTUtil.showView(BatchMonitorView.ID, "unused", true);

		BatchExecutor executor = new BatchExecutor(files, TraffSimCorePlugin.getDefault().getWorkbench().getActiveWorkbenchWindow(),
				PreferenceUtil.getBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_BATCH),
				PreferenceUtil.getBoolean(IPreferenceConstants.MATLAB_DELETE_FILES_AFTER_MERGE));
		SimulationKernel.getInstance().setActiveBatchExecutor(executor);
		executor.start();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

}

package at.fhhagenberg.mc.traffsim.ui;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.TimeUnit;

import com.xuggle.mediatool.IMediaWriter;
import com.xuggle.mediatool.ToolFactory;
import com.xuggle.xuggler.ICodec;

import at.fhhagenberg.mc.traffsim.log.Logger;

/**
 * Helper class which enables screen capturing. Takes {@link BufferedImage}s as input and generates mp4 video
 *
 * @author Christian
 *
 */
public class ScreenCapture {

	private IMediaWriter writer;
	boolean initialized = false;
	File outfile;

	public void init(File outputFolder, String outputFilename, int width, int height) {
		outputFolder.mkdirs();
		outfile = new File(outputFolder, outputFilename + ".m2v");
		writer = ToolFactory.makeWriter(outfile.toString());
		writer.addVideoStream(0, 0, ICodec.ID.CODEC_ID_MPEG2VIDEO, width, height);
		initialized = true;
	}

	/**
	 * Reset capture and delete created output file
	 */
	public void reset() {
		initialized = false;
		outfile.delete();
		writer = null;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void encode(BufferedImage image, long timeStamp) {
		if (!initialized) {
			Logger.logWarn("ScreenCapture not initialized.");
			return;
		}
		BufferedImage newImage = convertToType(image, BufferedImage.TYPE_3BYTE_BGR);
		writer.encodeVideo(0, newImage, timeStamp, TimeUnit.MILLISECONDS);
	}

	private BufferedImage convertToType(BufferedImage sourceImage, int targetType) {

		BufferedImage image;

		// if the source image is already the target type, return the source
		// image
		if (sourceImage.getType() == targetType) {
			image = sourceImage;
		}
		// otherwise create a new image of the target type and draw the new
		// image
		else {
			image = new BufferedImage(sourceImage.getWidth(), sourceImage.getHeight(), targetType);
			// image.getGraphics().setColor(Color.WHITE);
			// image.getGraphics().fillRect(0, 0, image.getWidth(), image.getHeight());
			image.getGraphics().drawImage(sourceImage, 0, 0, null);
		}

		return image;
	}

	public void close() {
		if (isInitialized()) {
			writer.flush();
			try {
				writer.close();
			} catch (Exception e) {
				if (!e.getMessage().startsWith("error Operation not permitted")) {
					Logger.logWarn("Could not close video file");
				}
			}
			initialized = false;
		}
	}

}

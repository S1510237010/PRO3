package at.fhhagenberg.mc.traffsim.util.types;

import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;

/**
 * Utility class holding all relevant parameters resulting from a merger of multiple junctions into a single one.
 *
 * @author Christian Backfrieder
 */
public class MergeResult {

	/** The resulting, merged junction */
	private AbstractJunction mergedJunction;

	/** The road segments removed in the course of the merging process */
	private List<RoadSegment> removedRoadSegments;

	/**
	 * Creates a new merge result with the given parameters.
	 *
	 * @param mergedJunction
	 *            the resulting, merged junction
	 * @param removedRoadSegments
	 *            a list of road segements removed in the course of the merging process
	 */
	public MergeResult(AbstractJunction mergedJunction, List<RoadSegment> removedRoadSegments) {
		super();
		this.mergedJunction = mergedJunction;
		this.removedRoadSegments = removedRoadSegments;
	}

	/**
	 * Gets the merged junction.
	 *
	 * @return the merged junction
	 */
	public AbstractJunction getMergedJunction() {
		return mergedJunction;
	}

	/**
	 * Gets the list of removed road segments.
	 *
	 * @return the list of removed road segments
	 */
	public List<RoadSegment> getRemovedRoadSegments() {
		return removedRoadSegments;
	}
}
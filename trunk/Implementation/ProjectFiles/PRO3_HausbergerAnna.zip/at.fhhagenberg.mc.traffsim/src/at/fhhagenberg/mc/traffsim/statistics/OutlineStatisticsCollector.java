package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.esotericsoftware.kryo.io.Input;
import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLCell;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleRouteListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

public class OutlineStatisticsCollector extends CachingStatisticsCollector implements IVehicleGeneratorListener, IVehicleRouteListener {
	private static final String VEHICLE_STATISTICS_OUTLINE_PREFIX = "statistics_outline_";
	private static final String OUTLINE_STATS_VARNAME = "outline_stats";
	private static final String OUTLINE_STAT_CONTINUOUS_VARNAME = "outline_stats_continuous";
	private static final String OUTLINE_STAT_CONTINUOUS_INTERVAL_VARNAME = "outline_stats_continuous_interval";
	private Map<Long, OutlineVehicleStatisticsData> outlineStats = new ConcurrentHashMap<>();
	private List<Pair<Double, OutlineVehicleStatisticsData>> continuousOutlineStats = new ArrayList<>();
	private List<Event> events = new ArrayList<>();

	/** contains data of finished vehicles */
	private OutlineVehicleStatisticsData dataSumFinishedVehicles = new OutlineVehicleStatisticsData(0, 0, 0, 0, 0);
	private boolean collectEvents;
	private boolean recordOutlineVStat = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS);

	/**
	 * Create new outline stat collector
	 *
	 * @param name
	 *            the thread name
	 *
	 * @param model
	 *            the model to grab data
	 * @param recordIntervalMillis
	 *            optional interval of recording, or 0 if continuous recording should be disabled
	 */
	public OutlineStatisticsCollector(String name, SimulationModel model, long recordIntervalMillis) {
		super(name, model, recordIntervalMillis, false, false);
		this.model = model;
		this.collectEvents = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_EVENTS);

		if (recordIntervalMillis == 0 && !collectEvents) {
			stopAndDestroy();
		} else {
			if (recordIntervalMillis == 0) {
				updateIntervalMillis = 5000;
			}
			startPaused();
		}

	}

	/**
	 * Sum up statistics collected so far and return as double array
	 *
	 * @return double array containing in order: time, fuel, carbonEmissions, distance, routeupdates, crashcount
	 */
	public double[] sumUpStatistics() {
		double time = 0, fuel = 0, carbonEmissions = 0, distance = 0, routeUpdates = 0;
		for (OutlineVehicleStatisticsData ovsd : outlineStats.values()) {
			time += ovsd.totalTime;
			fuel += ovsd.totalFuel;
			carbonEmissions += ovsd.totalCarbonEmissions;
			distance += ovsd.totalDistance;
			routeUpdates += ovsd.routeUpdateCount;
		}
		return new double[] { time, fuel, carbonEmissions, distance, routeUpdates, model.getCrashCount() };
	}

	/**
	 * Sum up statistics collected so far and return as double array
	 *
	 * @return double array containing in order: time, fuel, carbonEmissions, distance, routeupdates, crashcount
	 */
	public double[] getContinuousOutlineStatistics() {
		if (continuousOutlineStats.isEmpty()) {
			return new double[6];
		}
		OutlineVehicleStatisticsData stat = continuousOutlineStats.get(continuousOutlineStats.size() - 1).getRight();
		return new double[] { stat.totalTime, stat.totalFuel, stat.totalCarbonEmissions, stat.totalDistance, stat.routeUpdateCount,
				model.getCrashCount() };
	}

	private String getStandardSuffix(boolean crashDetected, boolean deadLockDetected) {
		return crashDetected ? String.format("-%s%s", CRASH_TAG, SIMPLE_MAT_FILE_SUFFIX)
				: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, SIMPLE_MAT_FILE_SUFFIX) : SIMPLE_MAT_FILE_SUFFIX;
	}

	@Override
	public void postLeftSimulation(Vehicle v) {
		updateOutlineStatisticsFor(v, outlineStats);
		if (!continuousOutlineStats.isEmpty()) {
			/**
			 * add data from finished vehicle to base data, since list of vehicles alive does not contain this vehicle any more, and then
			 * the recorded sum is not correct
			 */
			dataSumFinishedVehicles.update(dataSumFinishedVehicles.totalFuel + v.getFuelConsumed(),
					dataSumFinishedVehicles.totalCarbonEmissions + v.getCarbonFootprint(),
					dataSumFinishedVehicles.totalDistance + v.getTravelDistance(), dataSumFinishedVehicles.totalTime + getTimeAlive(v));
			dataSumFinishedVehicles.routeUpdateCount += outlineStats.get(v.getUniqueId()).routeUpdateCount;
		}
	}

	private synchronized void updateOutlineStatisticsFor(Vehicle v, Map<Long, OutlineVehicleStatisticsData> outlineStats) {
		long vehicleId = v.getUniqueId();
		if (recordOutlineVStat) {
			if (outlineStats.containsKey(vehicleId)) {
				outlineStats.get(vehicleId).update(v.getFuelConsumed(), v.getCarbonFootprint(), v.getTravelDistance(), getTimeAlive(v));
			} else {
				outlineStats.put(vehicleId, new OutlineVehicleStatisticsData(vehicleId, v.getFuelConsumed(), v.getCarbonFootprint(),
						v.getTravelDistance(), getTimeAlive(v)));
			}
		}
	}

	private double getTimeAlive(Vehicle v) {
		return v.getTimeInSimulation() / 1000.0;
	}

	@Override
	public void vehicleGenerated(Vehicle vehicle) {
		vehicle.addVehicleListener(this);
	}

	@Override
	public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute) {
		if (recordOutlineVStat && outlineStats.containsKey(v.getUniqueId())) {
			outlineStats.get(v.getUniqueId()).increaseRouteUpdates();
		} else {
			OutlineVehicleStatisticsData os = new OutlineVehicleStatisticsData(v.getUniqueId(), v.getFuelConsumed(), v.getCarbonFootprint(),
					v.getTravelDistance(),
					model.getSimRuntimeSeconds() - ((double) (v.getStartTime().getTime() - model.getStartSimTime().getTime())) / 1000);
			os.increaseRouteUpdates();
			outlineStats.put(v.getUniqueId(), os);
		}
	}

	@Override
	protected String getStatisticsFilePrefix() {
		return "vehicle_statistics_";
	}

	@Override
	public IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException {
		List<MLArray> matFileData = new ArrayList<>();

		monitor.subTask("Summing up vehicle's data");

		double[][] arr = new double[1][6];
		arr[0] = sumUpStatistics();
		matFileData.add(new MLDouble(OUTLINE_STATS_VARNAME, arr));

		if (!continuousOutlineStats.isEmpty()) {
			arr = new double[continuousOutlineStats.size() + 1][6];
			int i = 0;
			for (Pair<Double, OutlineVehicleStatisticsData> entry : continuousOutlineStats) {
				OutlineVehicleStatisticsData data = entry.getRight();
				arr[i++] = new double[] { entry.getLeft(), data.totalTime, data.totalFuel, data.totalCarbonEmissions, data.totalDistance,
						data.routeUpdateCount, data.cpuSeconds };
			}
			arr[i] = new double[] { model.getSimRuntimeSeconds(), dataSumFinishedVehicles.totalTime, dataSumFinishedVehicles.totalFuel,
					dataSumFinishedVehicles.totalCarbonEmissions, dataSumFinishedVehicles.totalDistance, dataSumFinishedVehicles.routeUpdateCount,
					model.getCpuTime() };
			matFileData.add(new MLDouble(OUTLINE_STAT_CONTINUOUS_VARNAME, arr));

			arr = new double[1][1];
			arr[0][0] = getUpdateIntervalMillis();
			matFileData.add(new MLDouble(OUTLINE_STAT_CONTINUOUS_INTERVAL_VARNAME, arr));
		}

		Collection<MLArray> finalData = addStandardStatistics(matFileData);

		String matFilename = String.format("%s%s%s", VEHICLE_STATISTICS_OUTLINE_PREFIX, date, getStandardSuffix(crashDetected, deadLockDetected));
		File matFile = new File(outputFolder, matFilename);

		// write everything to mat file
		try {
			monitor.subTask("Writing to outline MAT file");
			new MatFileWriter(matFile, finalData);
		} catch (IOException e) {
			String msg = "Cannot write to MAT file '" + matFilename + "'";
			Logger.logError(msg, e);
			return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, msg);
		}

		if (collectEvents) {
			File[] files = listCachedFiles();
			if (files != null) {
				monitor.beginTask("Converting " + files.length + " cached files", files.length + 2);
				for (File f : files) {
					Input input = new Input(new FileInputStream(f));
					List<?> objs = kryo.readObject(input, ArrayList.class);
					input.close();
					for (Object obj : objs) {
						if (obj instanceof Event) {
							events.add(0, (Event) obj);
						}
					}
				}
				monitor.worked(1);
			}
			this.events.addAll(model.getEventLog().collectEvents(0));

			MLCell data = super.getEventData(events);
			MLChar names = super.getEventColumnNames();
			ArrayList<MLArray> list = CollectionUtil.createArrayList(data, MLArray.class);
			list.add(names);
			try {
				monitor.subTask("Writing events to MAT file");
				new MatFileWriter(getStandardMatFile(outputFolder, date, getStandardSuffix(crashDetected, deadLockDetected)), list);
			} catch (IOException e) {
				String msg = "Cannot write to MAT file '" + matFilename + "'";
				Logger.logError(msg, e);
				return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, msg);
			}
		}
		if (clearCache && (collectEvents || recordOutlineVStat)) {
			clearCache(cacheFolder);
		}
		return Status.OK_STATUS;
	}

	@Override
	protected void collectStatistics(int itemsToKeep) {
		if (recordOutlineVStat) {
			double runtimeSeconds = model.getSimRuntimeSeconds();
			OutlineVehicleStatisticsData outlineStatTemp = dataSumFinishedVehicles.clone();
			for (Vehicle v : model.getVehiclesInSimulation(false)) {
				outlineStatTemp.update(outlineStatTemp.totalFuel + v.getFuelConsumed(), outlineStatTemp.totalCarbonEmissions + v.getCarbonFootprint(),
						outlineStatTemp.totalDistance + v.getTravelDistance(), outlineStatTemp.totalTime + getTimeAlive(v));
				if (outlineStats.containsKey(v.getUniqueId())) {
					outlineStatTemp.routeUpdateCount += outlineStats.get(v.getUniqueId()).routeUpdateCount;
				}
			}
			outlineStatTemp.setCpuSeconds(model.getCpuTime());
			continuousOutlineStats.add(new ImmutablePair<Double, OutlineVehicleStatisticsData>(runtimeSeconds, outlineStatTemp));
		}
		if (collectEvents)
			dataList.addAll(model.getEventLog().collectEvents(itemsToKeep));
	}

	@Override
	public String getCacheFolderPrefix() {
		return ".stat-outline-cache_";
	}

	@Override
	protected String getCacheFilePrefix() {
		return "traffsim_outline_stats";
	}

	@Override
	protected String getVariablePrefix() {
		return "outline_";
	}
}

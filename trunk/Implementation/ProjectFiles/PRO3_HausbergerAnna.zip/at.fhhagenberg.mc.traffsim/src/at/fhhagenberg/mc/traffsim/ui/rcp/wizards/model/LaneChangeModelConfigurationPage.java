package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.MOBILDataBean;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.LaneChangeModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class LaneChangeModelConfigurationPage extends ModelConfigurationPage {

	private Spinner spinnerMobilBiasRight;
	private Spinner spinnerMobilMaxDeceleration;
	private Spinner spinnerMobilPoliteness;
	private Spinner spinnerMobilSafeDeceleration;
	private Spinner spinnerMobilSMin;
	private Spinner spinnerMobilThreshold;

	private LaneChangeModels currentModel;

	protected LaneChangeModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		Label lblMobilBiasRight = new Label(grpModelParameters, SWT.NONE);
		lblMobilBiasRight.setText("Bias right");

		spinnerMobilBiasRight = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMobilBiasRight.setPageIncrement(10);
		spinnerMobilBiasRight.setIncrement(1);
		spinnerMobilBiasRight.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMobilBiasRight.setMaximum(100);
		spinnerMobilBiasRight.setMinimum(0);
		spinnerMobilBiasRight.setSelection(20);
		spinnerMobilBiasRight.setDigits(2);

		Label lblMobilMaxDec = new Label(grpModelParameters, SWT.NONE);
		lblMobilMaxDec.setText("Max. deceleration [m/s�]");

		spinnerMobilMaxDeceleration = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMobilMaxDeceleration.setPageIncrement(10);
		spinnerMobilMaxDeceleration.setIncrement(1);
		spinnerMobilMaxDeceleration.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMobilMaxDeceleration.setMaximum(0);
		spinnerMobilMaxDeceleration.setMinimum(-150);
		spinnerMobilMaxDeceleration.setSelection(-70);
		spinnerMobilMaxDeceleration.setDigits(1);

		Label lblMobilPoliteness = new Label(grpModelParameters, SWT.NONE);
		lblMobilPoliteness.setText("Politeness");

		spinnerMobilPoliteness = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMobilPoliteness.setPageIncrement(10);
		spinnerMobilPoliteness.setIncrement(1);
		spinnerMobilPoliteness.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMobilPoliteness.setMaximum(100);
		spinnerMobilPoliteness.setMinimum(0);
		spinnerMobilPoliteness.setSelection(99);
		spinnerMobilPoliteness.setDigits(2);

		Label lblMobilSafeDeceleration = new Label(grpModelParameters, SWT.NONE);
		lblMobilSafeDeceleration.setText("Safe deceleration [m/s�]");

		spinnerMobilSafeDeceleration = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMobilSafeDeceleration.setPageIncrement(10);
		spinnerMobilSafeDeceleration.setIncrement(1);
		spinnerMobilSafeDeceleration.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMobilSafeDeceleration.setMaximum(0);
		spinnerMobilSafeDeceleration.setMinimum(-100);
		spinnerMobilSafeDeceleration.setSelection(-20);
		spinnerMobilSafeDeceleration.setDigits(1);

		Label lblMobilSMin = new Label(grpModelParameters, SWT.NONE);
		lblMobilSMin.setText("Minimum gap [m]");

		spinnerMobilSMin = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMobilSMin.setPageIncrement(10);
		spinnerMobilSMin.setIncrement(1);
		spinnerMobilSMin.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMobilSMin.setMaximum(150);
		spinnerMobilSMin.setMinimum(5);
		spinnerMobilSMin.setSelection(20);
		spinnerMobilSMin.setDigits(1);

		Label lblMobilTreshold = new Label(grpModelParameters, SWT.NONE);
		lblMobilTreshold.setText("Threshold");

		spinnerMobilThreshold = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMobilThreshold.setPageIncrement(10);
		spinnerMobilThreshold.setIncrement(1);
		spinnerMobilThreshold.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMobilThreshold.setMaximum(100);
		spinnerMobilThreshold.setMinimum(0);
		spinnerMobilThreshold.setSelection(1);
		spinnerMobilThreshold.setDigits(1);

		// Model property initialization
		ModelProperty bias = new ModelProperty("Bias right", "setBiasRight", Double.TYPE, 0, 1);
		ModelProperty maxDeceleration = new ModelProperty("Max. deceleration [m/s�]", "setMaxDec", Double.TYPE, -15, 0);
		ModelProperty politeness = new ModelProperty("Politeness", "setPoliteness", Double.TYPE, 0, 1);
		ModelProperty safeDeceleration = new ModelProperty("Safe deceleration [m/s�]", "setSafeDec", Double.TYPE, -10,
				0);
		ModelProperty minimumGap = new ModelProperty("Minimum gap [m]", "setsMin", Double.TYPE, 0.5, 15);
		ModelProperty threshold = new ModelProperty("Threshold", "setThreshold", Double.TYPE, 0, 10);

		modelProperties.add(bias);
		modelProperties.add(maxDeceleration);
		modelProperties.add(politeness);
		modelProperties.add(safeDeceleration);
		modelProperties.add(minimumGap);
		modelProperties.add(threshold);

		controlMapping.put(bias, spinnerMobilBiasRight);
		controlMapping.put(maxDeceleration, spinnerMobilMaxDeceleration);
		controlMapping.put(politeness, spinnerMobilPoliteness);
		controlMapping.put(safeDeceleration, spinnerMobilSafeDeceleration);
		controlMapping.put(minimumGap, spinnerMobilSMin);
		controlMapping.put(threshold, spinnerMobilThreshold);
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			currentModel = LaneChangeModels
					.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' model parameters", currentModel.toString()));
		}
	}

	protected void addModelToList() {
		MOBILDataBean laneChangeModel = new MOBILDataBean();
		laneChangeModel.setModelIdentifier(txtIdentifier.getText());
		laneChangeModel.setFullName(txtFullName.getText());
		laneChangeModel
				.setBiasRight(spinnerMobilBiasRight.getSelection() / Math.pow(10, spinnerMobilBiasRight.getDigits()));
		laneChangeModel.setMaxDec(
				spinnerMobilMaxDeceleration.getSelection() / Math.pow(10, spinnerMobilMaxDeceleration.getDigits()));
		laneChangeModel.setSafeDec(
				spinnerMobilSafeDeceleration.getSelection() / Math.pow(10, spinnerMobilSafeDeceleration.getDigits()));
		laneChangeModel.setPoliteness(
				spinnerMobilPoliteness.getSelection() / Math.pow(10, spinnerMobilPoliteness.getDigits()));
		laneChangeModel.setsMin(spinnerMobilSMin.getSelection() / Math.pow(10, spinnerMobilSMin.getDigits()));
		laneChangeModel
				.setThreshold(spinnerMobilThreshold.getSelection() / Math.pow(10, spinnerMobilThreshold.getDigits()));

		modelSet.add(laneChangeModel);
	}

	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MOBILDataBean) element).getModelIdentifier() + "";
			}
		});

		TableViewerColumn colBiasRight = createTableViewerColumn("Bias right", 100);
		colBiasRight.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MOBILDataBean) element).getBiasRight() + "";
			}
		});

		TableViewerColumn colMaxDec = createTableViewerColumn("Max deceleration [m/s�]", 150);
		colMaxDec.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MOBILDataBean) element).getMaxDec() + "";
			}
		});

		TableViewerColumn colSafeDec = createTableViewerColumn("Safe deceleration [m/s�]", 150);
		colSafeDec.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MOBILDataBean) element).getSafeDec() + "";
			}
		});

		TableViewerColumn colPoliteness = createTableViewerColumn("Politeness", 100);
		colPoliteness.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MOBILDataBean) element).getPoliteness() + "";
			}
		});

		TableViewerColumn colSMin = createTableViewerColumn("Minimum gap [m]", 120);
		colSMin.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MOBILDataBean) element).getsMin() + "";
			}
		});

		TableViewerColumn colThreshold = createTableViewerColumn("Threshold", 100);
		colThreshold.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((MOBILDataBean) element).getThreshold() + "";
			}
		});
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {
		try {
			Class<?> cls = MOBILDataBean.class;
			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();
				cls.getMethod("setModelIdentifier", String.class).invoke(obj,
						currentModel.getShortName() + "_gen_" + generationTime + "-" + (i + 1));
				cls.getMethod("setFullName", String.class).invoke(obj, "Auto. generated lane change model");

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Method setter = cls.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);
						
						if (property.getType() == Integer.TYPE) {
							setter.invoke(obj, (int) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(obj, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(obj, (int) (spinner.getSelection()
										/ Math.pow(10, spinner.getDigits())  * property.getConversionFactor()));
							} else {
								setter.invoke(obj, (spinner.getSelection()
										/ Math.pow(10, spinner.getDigits()) * property.getConversionFactor()));
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(obj, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(obj, text.getText());
						}
					}
				}

				modelSet.add((MOBILDataBean) obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
package at.fhhagenberg.mc.traffsim.ui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

import org.jdesktop.swingx.JXMapViewer;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

/**
 * 
 * DrawingPanel extends a Panel and overrides paint-Method. On repaint, it simply paints the image that was set as a member variable in the
 * drawing area.
 * 
 * @author Christian
 */
public class DrawingPanel extends JXMapViewer {
	private static final long serialVersionUID = -1007896326611847781L;
	/** image to draw on paint-call */
	private Image image = null;
	private Rectangle zoomRect;
	private List<IResizeListener> resizeListeners = new ArrayList<>();
	private Dimension oldSize;
	private boolean showOsmMap;

	public void paintComponent(Graphics g) {
		try {
			Graphics2D g2d = (Graphics2D) g;
			if (showOsmMap) {
				paintMap(g2d);
			} else {
				g.setColor(PreferenceUtil.getColor(IPreferenceConstants.BACKGROUND_COLOR));
				g.fillRect(0, 0, getSize().width, getSize().height);
			}
			if (!getSize().equals(oldSize)) {
				notifyOnWindowSizeChanged();

				boolean initialized = oldSize == null;
				oldSize = getSize();

				if (initialized) {
					notifyOnWindowSizeInitialized();
				}
			}
			/** check if window size changed - if yes - notify listener */
			/** draw new border */
			g.setColor(Color.BLACK);
			g.drawRect(0, 0, getSize().width - 1, getSize().height - 1);
			if (image != null) {
				g.drawImage(image, 1, 1, this);
			}
			/** draw zoom rectangle */
			g2d.setXORMode(Color.CYAN);
			if (zoomRect != null) {
				Composite old = g2d.getComposite();
				g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.1f));
				g2d.setColor(Color.YELLOW);
				g2d.fillRect(zoomRect.x, zoomRect.y, zoomRect.width, zoomRect.height);
				g2d.setComposite(old);
				g2d.setColor(Color.RED);
				g2d.drawRect(zoomRect.x, zoomRect.y, zoomRect.width, zoomRect.height);
			}
		} catch (InternalError e) {
			if (!e.getMessage().equals("not implemented yet")) {
				// ignore console flooding message
				Logger.logDebug("Cought internal error on painting. Map drawing exception in OGLSurfaceData: " + e.getMessage());
			}
			repaint();
		}

	}

	private void notifyOnWindowSizeChanged() {
		for (IResizeListener listener : resizeListeners) {
			listener.windowSizeChanged();
		}
	}

	private void notifyOnWindowSizeInitialized() {
		for (IResizeListener listener : resizeListeners) {
			listener.windowSizeInitialized();
		}
	}

	public void paintMap(Graphics2D g2d) {
		Composite old = g2d.getComposite();
		g2d.clearRect(0, 0, getSize().width, getSize().height);
		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
				(float) PreferenceUtil.getDouble(IPreferenceConstants.BACKGROUND_ALPHA) / 100));
		super.paintComponent(g2d);
		g2d.setComposite(old);
	}

	public void paintMapRaw(Graphics2D g2d) {
		super.paintComponent(g2d);
	}

	public void removeResizeListener(IResizeListener listener) {
		if (listener != null && resizeListeners.contains(listener)) {
			resizeListeners.remove(listener);
		}
	}

	public void addResizeListener(IResizeListener listener) {
		if (listener != null && !resizeListeners.contains(listener)) {
			resizeListeners.add(listener);
		}
	}

	public void setImage(Image _image) {
		image = _image;
		repaint();
	}

	public Image getImage() {
		return image;
	}

	public void setZoomRectangle(Rectangle rect) {
		this.zoomRect = rect;
		this.repaint();
	}

	@Override
	public void setZoom(int zoom) {
		super.setZoom(zoom);
	}

	public void setShowOsmMap(boolean show) {
		this.showOsmMap = show;
	}

}

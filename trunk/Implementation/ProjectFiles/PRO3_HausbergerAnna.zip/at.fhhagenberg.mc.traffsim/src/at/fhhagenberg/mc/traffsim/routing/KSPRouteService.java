package at.fhhagenberg.mc.traffsim.routing;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import at.fhhagenberg.mc.traffsim.roadnetwork.Node;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.routing.rerouter.IDynamicNodeWeightProvider;
import at.fhhagenberg.mc.traffsim.routing.routegenerator.RouteResult;
import de.cm.osm2po.routing.Graph;

/**
 * Calculates the k best routes based on the {@link DefaultRouteService}, and selects the route with the least future predicted cost for
 * 
 * @author Christian Backfrieder
 * 
 */
public class KSPRouteService extends AbstractMultithreadedRouteService {

	private static final int NUM_THREADS = 3;
	private int k;
	private RoadNetwork network;
	private IDynamicNodeWeightProvider nodeweightProvider;

	public KSPRouteService(File graphFile, Set<Long> removedRoutingIds, int k, RoadNetwork network,
			IDynamicNodeWeightProvider footprintGen) {
		super(graphFile, removedRoutingIds);
		this.k = k;
		this.network = network;
		this.nodeweightProvider = footprintGen;
		setupDynamicGraphs(NUM_THREADS);
	}

	@Override
	public SimpleRouteResult findRoute(Node sourceNode, Node targetNode) {
		List<RouteResult> routeResults = findKsp(sourceNode, targetNode, k);
		double minRouteRating = Double.MAX_VALUE;
		RouteResult bestOfK = null;
		for (RouteResult r : routeResults) {
			double timeDelay = 0;
			double routeCost = 0;
			for (RoadSegment rs : r.getSegments()) {
				timeDelay += getSegmentUnfilteredHCost(rs.getRoutingId(), rs.isOsmReverse());
				routeCost += nodeweightProvider.getNodeWeight(rs.getEndNode().getId(), timeDelay);
			}
			if (routeCost < minRouteRating) {
				bestOfK = r;
				minRouteRating = routeCost;
			}
		}
		return bestOfK;
	}

	public List<RouteResult> findKsp(final Node source, final Node sink, int numPaths) {
		final List<RouteResult> A = new ArrayList<>();
		A.add(new RouteResult(super.findSingleRoute(source, sink), network));

		for (int k = 1; k < numPaths; k++) {
			final List<RouteResult> B = new ArrayList<>();
			for (int i = 0; i < A.get(k - 1).getNodeIds().size() - 2; i++) {
				TransientGraphCostsOverrider overrider = null;
				try {
					overrider = startDynamicOverride();

					Long spurNode = A.get(k - 1).getNodeIds().get(i);
					RouteResult rootPath = A.get(k - 1).subRoute(0, i);
					for (RouteResult r : A) {
						if (r.getNodeIds().size() > i && rootPath.getNodeIds().equals(r.getNodeIds().subList(0, i + 1))) {
							overrider.overrideCost((int) r.getRoutingSegment(spurNode).getRoutingId(), Float.POSITIVE_INFINITY,
									r.getRoutingSegment(spurNode).isOsmReverse());
						}
					}
					for (Long rootPathNode : rootPath.getNodeIds()) {
						if (!rootPathNode.equals(spurNode)) {
							// remove node from graph (set all
							int[] incoming = graph.findIncomingEdges(rootPathNode.intValue());
							int[] outgoing = graph.findOutgoingEdges(rootPathNode.intValue());
							int[] allEdges = new int[incoming.length + outgoing.length];
							System.arraycopy(incoming, 0, allEdges, 0, incoming.length);
							System.arraycopy(outgoing, 0, allEdges, incoming.length, outgoing.length);
							for (Integer edgeIdx : allEdges) {
								int edgeId = graph.getEdgeIds()[edgeIdx];
								int segId = Graph.toSegmentId(edgeId);
								overrider.overrideCost(segId, Float.POSITIVE_INFINITY, Graph.isReverse(edgeId));
							}
						}

					}
					SimpleRouteResult rt = findSingleRoute(new Node(spurNode), sink, overrider.getGraph());
					if (rt != null && !rt.getRoutingIds().isEmpty()) {
						RouteResult spurPath = new RouteResult(rt, network);
						RouteResult totalPath = rootPath.copyAndAppend(spurPath);
						B.add(totalPath);
					}
				} finally {
					finishDynamicOverrider(overrider);
				}
			}
			if (B.size() <= 1) {
				continue;
			}
			Collections.sort(B);
			A.add(B.get(1));
		}
		return A;
	}
}

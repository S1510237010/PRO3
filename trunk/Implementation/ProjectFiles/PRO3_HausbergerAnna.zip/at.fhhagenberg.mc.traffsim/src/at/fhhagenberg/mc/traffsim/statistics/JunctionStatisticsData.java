package at.fhhagenberg.mc.traffsim.statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;

public class JunctionStatisticsData implements Serializable {

	private static final long serialVersionUID = 7630408927145231445L;

	protected final long junctionId;
	protected List<Double> time = new ArrayList<>();
	protected List<Double> queueLength = new ArrayList<>();
	protected List<Double> throughput = new ArrayList<>();

	protected long recordedItems;

	public JunctionStatisticsData() {
		junctionId = -1;
	}

	public JunctionStatisticsData(long junctionId) {
		this.junctionId = junctionId;
	}

	public long getJunctionId() {
		return junctionId;
	}

	public List<Double> getTime() {
		return time;
	}

	public List<Double> getQueueLength() {
		return queueLength;
	}

	public List<Double> getThroughput() {
		return throughput;
	}

	public synchronized void addData(double time, AbstractJunction junction) {
		Map<String, Number> data = junction.obtainStatistics();
		this.queueLength.add((double) data.get(IStatsConstants.JUNCTION_QUEUE_LENGTH));
		this.throughput.add((double) data.get(IStatsConstants.JUNCTION_THROUGHPUT));
		this.time.add(time);
		recordedItems++;
	}

	public JunctionStatisticsData collectData(int numItemsToKeep) {
		JunctionStatisticsData data = new JunctionStatisticsData(junctionId);
		synchronized (this) {
			int lastIndex = time.size();
			int numItems = lastIndex - numItemsToKeep;

			if (numItems > 0) {
				data.time.addAll(time.subList(0, numItems));
				data.queueLength.addAll(queueLength.subList(0, numItems));
				data.throughput.addAll(throughput.subList(0, numItems));

				// remove the collected sublist from statistics data
				time = new ArrayList<>(time.subList(numItems, lastIndex));
				queueLength = new ArrayList<>(queueLength.subList(numItems, lastIndex));
				throughput = new ArrayList<>(throughput.subList(numItems, lastIndex));

				data.recordedItems = recordedItems;
			}
		}

		return data;
	}
}

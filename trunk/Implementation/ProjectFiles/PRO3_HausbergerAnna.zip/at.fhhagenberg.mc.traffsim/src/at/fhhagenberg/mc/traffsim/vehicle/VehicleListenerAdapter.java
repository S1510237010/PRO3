package at.fhhagenberg.mc.traffsim.vehicle;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;

/**
 * Adapter class which allows {@link IVehicleListener}s not to implement unused methods, they just override the required
 * 
 * @author Christian Backfrieder
 * 
 */
public class VehicleListenerAdapter implements IVehicleRouteListener {

	@Override
	public void vehicleLeftSimulation(Vehicle v) {

	}

	@Override
	public void postLeftSimulation(Vehicle v) {

	}

	@Override
	public void vehicleChangedLaneSegment(Vehicle vehicle, VehiclesLane oldLane, VehiclesLane newLane) {

	}

	@Override
	public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute) {

	}

}

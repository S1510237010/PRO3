package at.fhhagenberg.mc.traffsim.ui;

import at.fhhagenberg.mc.traffsim.util.BitUtil;

public class UiFlag {
	/** bit indexes */
	private static int index = 1;
	public static final int VEHICLE_INFO = index++;
	public static final int VEHICLE_DETAILS = index++;
	public static final int SCALE_LARGE = index++;
	public static final int SCALE_MEDIUM = index++;
	public static final int SCALE_SMALL = index++;
	public static final int VEHICLE_IDS = index++;
	public static final int LANE_DEBUG = index++;
	public static final int ROADSEGMENT_DEBUG = index++;
	public static final int JUNCTION_DEBUG = index++;
	public static final int SPEED_LIMITS = index++;
	public static final int TRANSPARENT_ROADS = index++;
	public static final int SELECTED = index++;
	public static final int SHOW_DETECTORS = index++;
	public static final int VEHICLE_DEBUG = BitUtil.set(0, VEHICLE_IDS);

}

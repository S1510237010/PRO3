package at.fhhagenberg.mc.traffsim.roadnetwork.detector;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

import org.apache.commons.lang3.tuple.Triple;

import at.fhhagenberg.mc.traffsim.model.TrafficDefaults;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneQuantity;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleListenerAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleType;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;

public class LoopDetector {

	public enum DetectionMode {
		FRONT, REAR, DUAL
	}

	public static long NEXT_DETECTOR_ID = 0;

	protected long identifier;
	protected double position;

	protected RoadSegment roadSegment;
	protected DetectionMode detectionMode;
	protected List<Vector> absolutePositions;
	private List<DetectorDataSample> currentSamplesPerLane;

	protected int sampleInterval;
	private double timeOffset;

	private double meanSpeedAllLanes;
	private double occupancyAllLanes;
	private int vehicleCountAllLanes;
	private double meanHarmonicSpeedAllLanes;
	private double meanHarmonicTimeGapAllLanes;

	private LaneQuantity[] laneQuantities;
	private boolean[] lanePresences;

	protected SignalPoint crossSectionSignalPoint;

	private Set<IDetectorDataListener> dataListeners = new CopyOnWriteArraySet<>();

	private VehicleListenerAdapter externalVehicleListener;

	private boolean isAssociatedToQueueMonitor;

	public LoopDetector() {
		this.identifier = 0;
		this.position = 0;
		this.sampleInterval = 0;
		this.roadSegment = null;
		this.laneQuantities = new LaneQuantity[1];
		this.lanePresences = new boolean[1];
		this.timeOffset = 0;
		this.currentSamplesPerLane = new ArrayList<>();
		this.detectionMode = DetectionMode.DUAL;
		this.crossSectionSignalPoint = new SignalPoint(this.position, detectionMode);
		resetLaneAverages();
		updatePositions();
	}

	public LoopDetector(long id, RoadSegment segment, double position, int sampleInterval, DetectionMode detectionMode) {
		this.identifier = id;
		this.roadSegment = segment;
		this.position = position;
		this.sampleInterval = sampleInterval;
		this.currentSamplesPerLane = new ArrayList<>();
		this.timeOffset = 0;
		this.detectionMode = detectionMode;
		this.crossSectionSignalPoint = new SignalPoint(this.position, detectionMode);

		initLaneQuantities();
		resetLaneAverages();
		updatePositions();
	}

	public LoopDetector(long id, RoadSegment segment, int sampleInterval, double timeHorizon, DetectionMode detectionMode) {
		this.identifier = id;
		this.roadSegment = segment;
		this.sampleInterval = sampleInterval;
		this.currentSamplesPerLane = new ArrayList<>();
		this.timeOffset = 0;
		this.detectionMode = detectionMode;

		moveToUpstreamPosition(timeHorizon);

		initLaneQuantities();
		resetLaneAverages();
		updatePositions();
	}

	public LoopDetector copy() {
		LoopDetector copy = new LoopDetector(identifier, roadSegment, position, sampleInterval, detectionMode);
		copy.setAbsolutePositions(absolutePositions);
		copy.setIsAssociatedToQueueMonitor(isAssociatedToQueueMonitor);
		return copy;
	}

	public boolean getIsAssociatedToQueueMonitor() {
		return isAssociatedToQueueMonitor;
	}

	public void setIsAssociatedToQueueMonitor(boolean isAssociatedToQueueMonitor) {
		this.isAssociatedToQueueMonitor = isAssociatedToQueueMonitor;
	}

	public long moveToUpstreamPosition(double timeHorizon) {
		Triple<RoadSegment, Double, Double> upstreamPosition = RoadUtil.getUpstreamPosition(roadSegment, timeHorizon);
		roadSegment = upstreamPosition.getLeft();
		long actualTimeHorizon = Math.round(upstreamPosition.getMiddle());
		position = upstreamPosition.getRight();

		double gap = 2 * roadSegment.getSpeedLimitMps();

		if (position < gap) {
			RoadSegment rs = roadSegment;
			double tempDist = 0;

			while (rs.getSourceRoadSegment() != null) {
				rs = rs.getSourceRoadSegment();
				tempDist += rs.getRoadLength();
			}

			if (tempDist + position < gap) {
				position = gap;
			}
		}

		this.crossSectionSignalPoint = new SignalPoint(this.position, detectionMode);
		updatePositions();
		return actualTimeHorizon;
	}

	public void setExternalVehicleListener(VehicleListenerAdapter externalListener) {
		this.externalVehicleListener = externalListener;
	}

	public void updatePosition(double position) {
		this.position = position;
		crossSectionSignalPoint = new SignalPoint(this.position, detectionMode);
	}

	public void addDataListener(IDetectorDataListener listener) {
		if (listener != null && !dataListeners.contains(listener)) {
			dataListeners.add(listener);
		}
	}

	public void removeDataListener(IDetectorDataListener listener) {
		if (listener != null && dataListeners.contains(listener)) {
			dataListeners.remove(listener);
		}
	}

	public List<Vector> getAbsolutePositions() {
		return absolutePositions;
	}

	public void setAbsolutePositions(List<Vector> absolutePosition) {
		this.absolutePositions = absolutePosition;
	}

	public long getIdentifier() {
		return identifier;
	}

	public void setIdentifier(long identifier) {
		this.identifier = identifier;
	}

	public double getPosition() {
		return position;
	}

	public RoadSegment getRoadSegment() {
		return roadSegment;
	}

	public void setRoadSegment(RoadSegment segment) {
		this.roadSegment = segment;
	}

	public double getDensityArithmetic(int i) {
		return NumberUtil.doubleEquals(laneQuantities[i].meanSpeed, 0d) ? 0 : getFlow(i) / laneQuantities[i].meanSpeed;
	}

	public double getDensityArithmeticAllLanes() {
		return NumberUtil.doubleEquals(meanSpeedAllLanes, 0) ? 0 : getFlowAllLanes() / meanSpeedAllLanes;
	}

	public int getSampleInterval() {
		return sampleInterval;
	}

	public void setSampleInterval(int sampleInterval) {
		this.sampleInterval = sampleInterval;
	}

	public double getFlow(int i) {
		return laneQuantities[i].vehicleCountOutput / (double) sampleInterval;
	}

	public double getMeanSpeed(int i) {
		return laneQuantities[i].meanSpeed;
	}

	public double getOccupancy(int i) {
		return laneQuantities[i].occupancy;
	}

	public int getVehicleCount(int i) {
		return laneQuantities[i].vehicleCountOutput;
	}

	public double getMeanSpeedHarmonic(int i) {
		return laneQuantities[i].meanSpeedHarmonic;
	}

	public double getMeanTimeGapHarmonic(int i) {
		return laneQuantities[i].meanTimeGapHarmonic;
	}

	public double getFlowAllLanes() {
		return vehicleCountAllLanes / ((double) sampleInterval * roadSegment.getLaneCount());
	}

	public double getMeanSpeedAllLanes() {
		return meanSpeedAllLanes;
	}

	public double getVehicleCountAllLanes() {
		return vehicleCountAllLanes;
	}

	public double getOccupancyAllLanes() {
		return occupancyAllLanes;
	}

	public double getMeanSpeedHarmonicAllLanes() {
		return meanHarmonicSpeedAllLanes;
	}

	public double getMeanTimeGapHarmonicAllLanes() {
		return meanHarmonicTimeGapAllLanes;
	}

	public void update(double dt, double simulationTime) {

		/** Detect vehicles passing by the loop detector **/
		for (Vehicle vehicle : crossSectionSignalPoint.getPassedVehicles()) {
			if (countVehiclesAndDataForLane(vehicle)) {

				if (externalVehicleListener != null) {
					vehicle.addVehicleListener(externalVehicleListener);
				}

				notifyVehiclePassed(vehicle, vehicle.getLaneIndex());
			}
		}

		/** Presence detection **/
		updatePresences();

		crossSectionSignalPoint.clear();

		/** Update figures of merit **/
		if ((simulationTime - timeOffset + 1e-7) >= sampleInterval) {
			for (LaneQuantity laneQuantity : laneQuantities) {
				laneQuantity.calcAverageForLane(sampleInterval);
			}

			calculateAveragesOverAllLanes();
			notifyDetectorDataSampled(simulationTime);
			timeOffset = simulationTime;
		}
	}

	public void updateSignalPoint(double runTime) {
		if (crossSectionSignalPoint != null && roadSegment.getAllVehicles().size() > 0) {
			crossSectionSignalPoint.registerVehicles(runTime, roadSegment.getAllVehicles());
		}
	}

	public String getDetails(int laneIndex) {
		StringBuffer details = new StringBuffer();
		details.append(String.format("%s: ID %d\n", this.getClass().getSimpleName(), getIdentifier()));
		details.append(String.format("road segment: %s\n", roadSegment.getId()));
		details.append(String.format("lane: %s\n", laneIndex));
		details.append(String.format("position: %.2fm\n", position));
		details.append(String.format("sample interval: %d s\n", getSampleInterval()));

		if (currentSamplesPerLane.isEmpty() || currentSamplesPerLane.size() < laneIndex + 1) {
			details.append("flow: - veh/h\n");
			details.append("density: - veh/km\n");
			details.append("mean speed: - km/h\n");
			details.append("occupancy: -\n");
		} else {
			DetectorDataSample sample = currentSamplesPerLane.get(laneIndex);
			details.append(String.format("flow: %.2f veh/h\n", sample.getFlow()));
			details.append(String.format("density: %.2f veh/km\n", sample.getDensity()));
			details.append(String.format("mean speed: %.2f km/h\n", sample.getSpeed()));
			details.append(String.format("occupancy: %.2f\n", sample.getOccupancy()));
		}

		return details.toString();
	}

	private void notifyDetectorDataSampled(double simulationTime) {
		List<DetectorDataSample> dataSamplesPerLane = new ArrayList<>();

		for (int i = 0; i < laneQuantities.length; i++) {
			DetectorDataSample sample = new DetectorDataSample();
			sample.setLaneIndex(i);
			sample.setTime(simulationTime);
			sample.setSpeed(getMeanSpeed(i) * 3.6);
			sample.setOccupancy(getOccupancy(i) * 100);
			sample.setFlow(getFlow(i) * 3600);
			sample.setDensity(getDensityArithmetic(i) * 1000);
			dataSamplesPerLane.add(sample);
		}

		currentSamplesPerLane = dataSamplesPerLane;

		for (IDetectorDataListener listener : dataListeners) {
			listener.onDetectorDataSampled(getIdentifier(), roadSegment.getId(), dataSamplesPerLane);
		}
	}

	private boolean countVehiclesAndDataForLane(Vehicle vehicle) {
		int laneIndex = vehicle.getLaneIndex();
		LaneQuantity laneQuantity = laneQuantities[laneIndex];

		// Ignore vehicles which have already been counted once
		if (laneQuantity.detectedVehicleIds.contains(vehicle.getUniqueId())) {
			return false;
		}

		laneQuantity.detectedVehicleIds.add(vehicle.getUniqueId());
		laneQuantity.vehicleCount++;
		double speedVehicle = vehicle.getCurrentSpeed();
		laneQuantity.speedSum += speedVehicle;
		laneQuantity.totalOccupationTime += (speedVehicle > 0) ? vehicle.getLength() / speedVehicle : 0;
		laneQuantity.sumInvV += (speedVehicle > 0) ? 1.0 / speedVehicle : 0;
		VehicleWithDistance vehicleFront = vehicle.getFrontVehicle();

		// Consider brutto gap (i.e. distance from front to front)
		double brutTimeGap = (vehicleFront == null || vehicleFront.getVehicle() == null
				|| (vehicleFront.getVehicle().getType() != VehicleType.CAR && vehicleFront.getVehicle().getType() != VehicleType.TRUCK)) ? 0
						: (vehicleFront.getDistance() + vehicleFront.getVehicle().getLength()) / vehicleFront.getVehicle().getCurrentSpeed();
		laneQuantity.sumInvQ += (brutTimeGap > 0) ? 1.0 / brutTimeGap : 0;
		return true;
	}

	private void calculateAveragesOverAllLanes() {
		resetLaneAverages();

		for (int i = 0; i < roadSegment.getLaneCount(); i++) {
			vehicleCountAllLanes += getVehicleCount(i);
			meanSpeedAllLanes += getVehicleCount(i) * getMeanSpeed(i);
			occupancyAllLanes += getOccupancy(i);
			meanHarmonicSpeedAllLanes += getVehicleCount(i) * getMeanSpeedHarmonic(i);
			meanHarmonicTimeGapAllLanes += getVehicleCount(i) * getMeanTimeGapHarmonic(i);
		}

		meanSpeedAllLanes = vehicleCountAllLanes == 0 ? 0 : meanSpeedAllLanes / vehicleCountAllLanes;
		meanHarmonicSpeedAllLanes = vehicleCountAllLanes == 0 ? 0 : meanHarmonicSpeedAllLanes / vehicleCountAllLanes;
		meanHarmonicTimeGapAllLanes = vehicleCountAllLanes == 0 ? 0 : meanHarmonicTimeGapAllLanes / vehicleCountAllLanes;
		occupancyAllLanes /= roadSegment.getLaneCount();
	}

	private void resetLaneAverages() {
		meanSpeedAllLanes = 0;
		vehicleCountAllLanes = 0;
		occupancyAllLanes = 0;
		meanHarmonicSpeedAllLanes = 0;
		meanHarmonicTimeGapAllLanes = 0;
	}

	private void initLaneQuantities() {
		int laneCount = roadSegment.getLaneCount();
		laneQuantities = new LaneQuantity[laneCount];

		for (int i = 0; i < laneCount; i++) {
			laneQuantities[i] = new LaneQuantity();
		}

		lanePresences = new boolean[laneCount];
	}

	private void updatePresences() {
		boolean[] updatedPresences = new boolean[lanePresences.length];

		for (Vehicle vehicle : crossSectionSignalPoint.getPresentVehicles()) {
			if (vehicle.getCurrentSpeed() < TrafficDefaults.DEFAULT_PRESENCE_DETECTION_SPEED_THRESHOLD)
				updatedPresences[vehicle.getLaneIndex()] = true;
		}

		for (int i = 0; i < lanePresences.length; i++) {
			if (updatedPresences[i] != lanePresences[i]) {
				notifyPresenceChanged(updatedPresences[i], i);
			}

			lanePresences[i] = updatedPresences[i];
		}
	}

	private void updatePositions() {
		List<Vector> absoluteDetectorPositions = new ArrayList<>();

		for (LaneSegment lane : roadSegment.getLaneSegments()) {
			Vector pos = lane.getRoadGeometry().mapPosition(position, 0, lane, null);

			if (pos != null) {
				absoluteDetectorPositions.add(pos);
			}
		}

		setAbsolutePositions(absoluteDetectorPositions);
	}

	private void notifyVehiclePassed(Vehicle vehicle, int laneIdx) {
		for (IDetectorDataListener listener : dataListeners) {
			listener.onVehiclePassed(identifier, vehicle, laneIdx);
		}
	}

	private void notifyPresenceChanged(boolean isVehiclePresent, int laneIdx) {
		for (IDetectorDataListener listener : dataListeners) {
			listener.onPresenceChanged(identifier, isVehiclePresent, laneIdx);
		}
	}
}

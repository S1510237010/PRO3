package at.fhhagenberg.mc.traffsim.roadnetwork.regulation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSign.Type;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.types.CyclicList;
import at.fhhagenberg.mc.util.CollectionUtil;

public class RoadSignGenerator {

	private SimulationModel model;

	public RoadSignGenerator(SimulationModel activeModel) {
		this.model = activeModel;
	}

	/**
	 *
	 * @param stopSignFactor
	 *            factor of speed difference to create stop sign (must be greater than 1, e.g. 2, which means a difference of 30 to 60 kmph
	 *            leads to creation of a stop sign
	 * @param giveWayFactor
	 * @param roundaboutsOnly
	 *            only generate signs in roundabouts, and nowhere else
	 * @param generateFortJuncWithSameSpeedLimit
	 * @param spdRangeMin
	 * @param spdRangeMax
	 */
	public void generateSigns(double stopSignFactor, double giveWayFactor, boolean roundaboutsOnly, boolean generateFortJuncWithSameSpeedLimit,
			double spdRangeMin, double spdRangeMax) {

		if (model == null) {
			return;
		}

		if (roundaboutsOnly) {
			initRoundabouts();
			return;
		}

		RoadNetwork network = model.getNetwork();

		for (AbstractJunction j : network.getJunctions()) {
			Map<Integer, List<RoadSegment>> spdMap = getSpeedLimitMap(j.getSegmentsIn());
			ArrayList<Integer> keys = new ArrayList<>(spdMap.keySet());
			Collections.sort(keys);
			if (CollectionUtil.getFirstObject(keys) <= spdRangeMin || CollectionUtil.getLastObject(keys) >= spdRangeMax) {
				// out of valid range
				continue;
			}

			if (keys.size() == 1) {
				// same speed limit - check t - junction
				if (generateFortJuncWithSameSpeedLimit && j.getSegmentsIn().size() == 3) {
					for (RoadSegment seg : j.getSegmentsIn()) {
						double angleLeft = SpatialUtil.getRelativeAngle(seg.getRoadGeometry(), true,
								((CyclicList<RoadSegment>) j.getSegmentsIn()).elementLeftTo(seg).getRoadGeometry(), true);
						double angleRight = SpatialUtil.getRelativeAngle(seg.getRoadGeometry(), true,
								((CyclicList<RoadSegment>) j.getSegmentsIn()).elementRightTo(seg).getRoadGeometry(), true);
						angleLeft = fixAngle(angleLeft);
						angleRight = fixAngle(angleRight);
						double angleDiff = (angleRight - angleLeft + 2 * Math.PI) % (2 * Math.PI);
						if (angleDiff < 0.125 * Math.PI || angleLeft < Math.PI * 2 / 3 && angleRight < Math.PI * 2 / 3) {
							addSign(seg, Type.GIVE_WAY);
							break;
						}
					}
				}
			} else {
				Integer spdMin = (keys.get(0));
				for (RoadSegment seg : spdMap.get(spdMin)) {
					if (seg.getJunction() != null && seg.getJunction().getType() != NodeType.ROUNDABOUT
							&& seg.getJunction().getSegmentsIn().size() > 2) {
						double factor = (double) NumberUtil.max(keys, 0) / spdMin;
						if (factor >= stopSignFactor) {
							addSign(seg, Type.STOP);
						} else if (factor >= giveWayFactor) {
							addSign(seg, RoadSign.Type.GIVE_WAY);
						}
					}
				}
			}

			for (JunctionConnector conn : j.getConnectors()) {
				if (conn.getRoadSign() == null) {
					conn.setRoadSignAndPriority(Type.NONE);
				}
			}
		}
	}

	private void initRoundabouts() {
		RoadNetwork network = model.getNetwork();
		for (RoadSegment s : network.getRoadSegments()) {
			if (s.getEndNode().getType() == NodeType.ROUNDABOUT && s.getStartNode().getType() != NodeType.ROUNDABOUT && s.getJunction() != null) {
				for (LaneSegment ls : s.getLaneSegments()) {
					boolean isEntryPoint = false;
					for (JunctionConnector jc : s.getJunction().getConnectors(ls)) {
						if (jc.getSinkLaneSegment().getRoadSegment() != null
								&& jc.getSinkLaneSegment().getRoadSegment().getEndNode().getType() == NodeType.ROUNDABOUT) {
							isEntryPoint = true;
							break;
						}
					}
					if (isEntryPoint) {
						for (JunctionConnector jc : s.getJunction().getConnectors(ls)) {
							jc.setRoadSign(new RoadSign(Type.GIVE_WAY));
						}
					}
				}
			}
		}
	}

	private double fixAngle(double angle) {
		if (angle > 0.625 * Math.PI) {
			angle = 2 * Math.PI - angle;
		}
		// angle = (Math.PI * 2 + angle) % (2 * Math.PI);
		if (angle < 0) {
			if (angle > -3 / 2 * Math.PI) {
				return Math.abs(angle);
			}
			return 2 * Math.PI + angle;
		}
		return angle;
	}

	private void addSign(RoadSegment seg, RoadSign.Type type) {
		for (LaneSegment ls : seg.getLaneSegments()) {
			for (JunctionConnector conn : seg.getJunction().getConnectors(ls)) {
				conn.setRoadSignAndPriority(type);
			}
		}
	}

	private Map<Integer, List<RoadSegment>> getSpeedLimitMap(List<RoadSegment> segments) {
		Map<Integer, List<RoadSegment>> speedMap = new HashMap<>();
		for (RoadSegment seg : segments) {
			int limit = (int) seg.getSpeedLimitKmph();
			if (!speedMap.containsKey(limit)) {
				speedMap.put(limit, new ArrayList<RoadSegment>());
			}
			speedMap.get(limit).add(seg);
		}
		return speedMap;
	}
}

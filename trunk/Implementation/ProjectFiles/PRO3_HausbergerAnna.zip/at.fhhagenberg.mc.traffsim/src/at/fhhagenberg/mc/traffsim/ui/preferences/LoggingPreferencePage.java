package at.fhhagenberg.mc.traffsim.ui.preferences;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.IntegerFieldEditor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;

public class LoggingPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {
	public LoggingPreferencePage() {
	}

	@Override
	public void init(IWorkbench workbench) {
		setPreferenceStore(TraffSimCorePlugin.getDefault().getPreferenceStore());
		setDescription("Preferences for logging and debug output");
	}

	@Override
	protected Control createContents(Composite parent) {
		return super.createContents(parent);
	}

	@Override
	protected void createFieldEditors() {
		{
			IntegerFieldEditor integerFieldEditor = new IntegerFieldEditor(IPreferenceConstants.JUNCTION_LOG_CACHE_SIZE,
					"Junction log cache size", getFieldEditorParent());
			integerFieldEditor.setValidRange(0, 1000);
			addField(integerFieldEditor);
		}
	}

}

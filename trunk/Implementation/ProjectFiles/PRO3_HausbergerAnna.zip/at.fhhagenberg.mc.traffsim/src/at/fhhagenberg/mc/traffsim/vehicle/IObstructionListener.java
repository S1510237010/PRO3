package at.fhhagenberg.mc.traffsim.vehicle;

/**
 * Listener interface which is notified if an obstruction enters or leaves the simulation.
 * 
 * @author Manuel Lindorfer
 *
 */
public interface IObstructionListener {

	default public void obstructionGenerated(Obstruction o) {};
	
	default public void obstructionDecomposed(Obstruction o) {};
}

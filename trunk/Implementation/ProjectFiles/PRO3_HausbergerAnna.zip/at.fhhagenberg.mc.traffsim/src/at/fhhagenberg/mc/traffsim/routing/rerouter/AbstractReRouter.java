package at.fhhagenberg.mc.traffsim.routing.rerouter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import at.fhhagenberg.mc.traffsim.communication.IChannelModel;
import at.fhhagenberg.mc.traffsim.communication.ICommunicationPartner;
import at.fhhagenberg.mc.traffsim.communication.IVehicleInformationReceiver;
import at.fhhagenberg.mc.traffsim.communication.MessageTransfer;
import at.fhhagenberg.mc.traffsim.communication.messaging.MessageFactory;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.IntervalUpdateThread;
import at.fhhagenberg.mc.traffsim.model.PropertyKeys;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.ThreadConstants;
import at.fhhagenberg.mc.traffsim.roadnetwork.Node;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.routing.AbstractRouteService;
import at.fhhagenberg.mc.traffsim.routing.Congestion;
import at.fhhagenberg.mc.traffsim.routing.RoutingException;
import at.fhhagenberg.mc.traffsim.routing.SimpleRouteResult;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.util.types.NamedThreadFactory;
import at.fhhagenberg.mc.traffsim.vehicle.CommVehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.StringUtil;
import at.fhhagenberg.mc.util.types.IDisposable;

public abstract class AbstractReRouter extends IntervalUpdateThread implements IVehicleInformationReceiver, ICommunicationPartner, IDisposable {
	public static final String REROUTER_NAME = "Standard";
	protected SimulationModel model;

	/**
	 * Perform rerouting
	 */
	@Override
	public abstract void doSynchronizedWork();

	protected ExecutorService exec;
	/**
	 * the threshold for time difference of old to new route (oldCost/newCost must be greater than this value to assign new route). Must
	 * meaningfully be greater than 1
	 */
	protected double timeCostThresholdFactor;
	/**
	 * the threshold for distance difference of new to old route (newCost/ oldCost must be lower than this value to assign new route). A
	 * factor of 2 means, new routes which have a length more than 2 times the old length are not assigned
	 */
	protected double distanceCostThresholdFactor;
	/** vehicles which are scheduled for rerouting in the next run */
	protected Map<Long, Vehicle> vehicles = new ConcurrentHashMap<>();
	/** remember the time when a vehicle should be updated the next time */
	protected Map<Long, Date> vehicleNextUpdate = new ConcurrentHashMap<>();

	/** Mapping of {@link Vehicle#getUniqueId()} to simulation timestamp in order to avoid double assignments */
	private Map<Long, Long> lastVehicleUpdates = new ConcurrentHashMap<>();
	private static final long MINIMAL_ROUTE_ASSIGNMENT_DELAY_MS = 5000;

	/** Perform only simulation of rerouting, and do NOT assign new routes */
	protected boolean simulateReRouting = false;

	public AbstractReRouter(String name, long updateIntervalMillis, SimulationModel model) {
		super(name, updateIntervalMillis);
		this.model = model;
		model.getObservationCenter().registerInformationReceiver(this);
		exec = Executors.newFixedThreadPool(PreferenceUtil.getBoolean(IPreferenceConstants.SINGLETHREADED_EXECUTION) ? 1 : 3,
				new NamedThreadFactory(StringUtil.createThreadName(model.getUniqueId(), ThreadConstants.REROUTER_NAME + getReRouterName())));
	}

	@Override
	public void vehicleLeftSimulation(Vehicle v) {
		vehicles.remove(v.getUniqueId());
		vehicleNextUpdate.remove(v.getUniqueId());
	}

	@Override
	public void dispose() {
		exec.shutdown();
		model.getObservationCenter().unregisterInformationReceiver(this);
	}

	protected double getTimeCost(IRoute route) {
		double cost = 0;
		for (int i = 0; i < route.getRouteIds().size(); i++) {
			long routeId = route.getRouteIds().get(i);
			if (route.getIsReverse().size() == route.getRouteIds().size()) {
				boolean reverse = route.getIsReverse().get(i);
				cost += model.getRouteService().getSegmentNormalizedTotalCost(routeId, reverse);
			} else {
				return Double.POSITIVE_INFINITY;
			}
		}
		return cost;
	}

	protected double getKmCost(IRoute route) {
		double cost = 0;
		for (int i = 0; i < route.getRouteIds().size(); i++) {
			long routeId = route.getRouteIds().get(i);
			if (route.getIsReverse().size() == route.getRouteIds().size()) {
				boolean reverse = route.getIsReverse().get(i);
				cost += model.getRouteService().getKmCosts(routeId, reverse);
			} else {
				return Double.POSITIVE_INFINITY;
			}
		}
		return cost;
	}

	/**
	 * the threshold for time difference of old to new route (oldCost/newCost must be greater than this value to assign new route). Must
	 * meaningfully be greater than 1
	 *
	 * @param timeCostThresholdFactor
	 *            the new factor (can be set dynamically during simulation)
	 */
	public void setTimeCostThresholdFactor(double timeCostThresholdFactor) {
		this.timeCostThresholdFactor = timeCostThresholdFactor;
	}

	/**
	 * the threshold for distance difference of old to new route (oldCost/newCost must be greater than this value to assign new route). Must
	 * meaningfully be greater than 1
	 *
	 * @param kmCostThresholdFactor
	 *            the new factor (can be set dynamically during simulation)
	 */
	public void setDistanceCostThresholdFactor(double kmCostThresholdFactor) {
		this.distanceCostThresholdFactor = kmCostThresholdFactor;
	}

	protected SimpleRouteResult findRoute(Vehicle v) {
		Node startNode;
		if (v.isInJunction()) {
			startNode = v.getLaneSegment().getSinkLaneSegment().getRoadSegment().getEndNode();
		} else {
			RoadSegment rs = v.getRoadSegment();
			if (rs != null) {
				startNode = rs.getEndNode();
			} else {
				return null;
			}
		}
		IRoute curRoute = model.getObservationCenter().getRoute(v.getUniqueId());
		if (curRoute != null) {
			return model.getRouteService().findRoute(startNode, curRoute.getTargetSegment().getEndNode());
		}
		return null;
	}

	protected boolean assignNewRoute(Vehicle vehicle, IRoute newRoute, String comment) {
		return assignNewRoute(vehicle, newRoute, timeCostThresholdFactor, distanceCostThresholdFactor, comment);
	}

	/**
	 * Calculates a new route by using the {@link AbstractRouteService} from the {@link SimulationModel} and assigns it to the vehicle, if
	 * this is possible
	 *
	 * Synchronized to avoid assigning a new route by multiple threads simultaneously
	 *
	 * @param vehicle
	 * @return <code>true</code> if route was assigned, <code>false</code> otherwise
	 */
	protected synchronized boolean assignNewRoute(Vehicle vehicle, IRoute newRoute, Double timeThreshold, Double distanceThreshold, String comment) {
		long curSimTime = model.getCurrentSimTime().getTime();
		if (lastVehicleUpdates.containsKey(vehicle.getUniqueId())) {
			Long lastUpdate = lastVehicleUpdates.get(vehicle.getUniqueId());
			if ((curSimTime - lastUpdate) < MINIMAL_ROUTE_ASSIGNMENT_DELAY_MS) {
				// updated within minimal delay -> return true to avoid multiple updates in a very short time period
				return false;
			}
		}
		if (newRoute != null && vehicle.getRoadSegment() != null) {
			if (timeThreshold == null) {
				timeThreshold = timeCostThresholdFactor;
			}
			if (distanceThreshold == null) {
				distanceThreshold = distanceCostThresholdFactor;
			}
			newRoute.removeNextSegmentIdIfMatches(vehicle.getRoadSegment().getRoutingId());
			IRoute currentRoute = model.getObservationCenter().getRoute(vehicle.getUniqueId());
			if (RoutingUtil.routeContains(newRoute, currentRoute)) {
				return false;
			}

			try {
				newRoute = RoutingUtil.updateInitialAndTargetRoadSegments(newRoute, model.getNetwork().getRoadSegmentsByRoutingId());
			} catch (RoutingException e) {
				Logger.logWarn("Re-Router problem: " + e.getMessage());
			}
			boolean intersectionOnly = PropertyUtil.getBooleanProperty(model.getSimulationParameters(),
					PropertyKeys.USE_NONOVERLAPPING_ROUTEPART_FOR_COMPARISON_ONLY, false);
			// compare time cost
			IRoute diffCurRoute = intersectionOnly ? RoutingUtil.subtractRoute(currentRoute, newRoute) : currentRoute;
			IRoute diffNewRoute = intersectionOnly ? RoutingUtil.subtractRoute(newRoute, currentRoute) : newRoute;
			double currentHCost = getTimeCost(diffCurRoute);
			double newHCost = getTimeCost(diffNewRoute);
			if (currentHCost / newHCost > timeThreshold) {
				// time cost ok, compare km cost threshold
				double currentKmCost = getKmCost(diffCurRoute);
				double newKmCost = getKmCost(diffNewRoute);
				if (newKmCost / currentKmCost < distanceThreshold) {
					if (newRoute != null) {
						EventType evType = EventType.ROUTE_UDPATED_REACTIVE;
						if (comment.equals(TimeDynamicReRouter.REROUTER_NAME)) {
							evType = EventType.ROUTE_UPDATED_PREDICTIVE;
						}
						Event ev = model.buildEvent(evType, vehicle, comment + " | " + currentRoute.toString() + " -> " + newRoute.toString()
								+ " | @RS-" + vehicle.getRoadSegment().getId() + " @pos " + vehicle.getFrontPosition());
						IChannelModel channelModel = vehicle instanceof CommVehicle ? ((CommVehicle) vehicle).getDemandChannelModel() : null;
						model.getCommunicator().sendMessage(this, vehicle.getUniqueId(),
								MessageFactory.createRouteMessage(null, newRoute, vehicle.getLaneSegment(), ev), channelModel);
						// Logger.logInfo("Set new route for vehicle " + vehicle.getLabel());
					} else {
						Logger.logWarn("Cannot set new route for vehicle " + vehicle.getLabel());
					}
				}
			}
		} else {
			return false;
		}
		lastVehicleUpdates.put(vehicle.getUniqueId(), curSimTime);
		return true;
	}

	protected abstract List<ICongestionProvider> getStandardCongestionProviders();

	/**
	 * Prepare vehicles which are scheduled for rerouting
	 */
	@Override
	public void doWorkWaitForFinish() {
		List<ICongestionProvider> provs = getStandardCongestionProviders();
		if (getStandardCongestionProviders() != null) {
			for (ICongestionProvider prov : provs) {
				for (Congestion c : prov.getCongestions()) {
					for (Vehicle vehicle : c.getVehicles()) {
						if (vehicle.isRoutable()) {
							long vid = vehicle.getUniqueId();
							if (!vehicles.containsKey(vid)) {
								vehicles.put(vid, vehicle);
							}
							if (!vehicleNextUpdate.containsKey(vid)) {
								vehicleNextUpdate.put(vid, model.getCurrentSimTime());
							}
						}
					}
				}
			}
		}
	}

	protected void performStandardReRoute() {
		performStandardReRoute(null);
	}

	protected void performStandardReRoute(Set<Long> vehiclesToSkip) {
		List<Callable<Object>> tasks = new ArrayList<>();
		Set<Long> vehicleIds = vehicles.keySet();
		if (vehiclesToSkip != null) {
			vehicleIds.removeAll(vehiclesToSkip);
		}
		for (final Long l : vehicleIds) {
			tasks.add(new Callable<Object>() {

				@Override
				public Object call() throws Exception {
					Date nextUpdateTime = vehicleNextUpdate.get(l);
					CommVehicle vehicle = (CommVehicle) vehicles.get(l); // vehicle must be commvehicle to be routable
					if (vehicle == null) {
						vehicles.remove(l);
						return null;
					}
					if (nextUpdateTime != null && nextUpdateTime.before(model.getCurrentSimTime()) && vehicle.getRoadSegment() != null) {
						SimpleRouteResult route = findRoute(vehicle);
						if (route != null) {
							boolean success = assignNewRoute(vehicle, new Route(route.getRoutingIds()), REROUTER_NAME);
							if (success) {
								vehicleNextUpdate.put(vehicle.getUniqueId(),
										new Date(model.getCurrentSimTime().getTime() + vehicle.getStaticRouteUpdateInterval()));
							}
						}
					}
					return null;
				}

			});
		}
		executeTasks(exec, tasks);
	}

	protected abstract String getReRouterName();

	public boolean isSimulateReRouting() {
		return simulateReRouting;
	}

	public void setSimulateReRouting(boolean simulateReRouting) {
		this.simulateReRouting = simulateReRouting;
	}

	@Override
	public void messageReceived(MessageTransfer msg) {
		// nothing
	}

	@Override
	public String getCommName() {
		return "ReRouter " + getReRouterName();
	}
}
package at.fhhagenberg.mc.traffsim.model;

import java.util.List;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public interface IItemSelectionListener {
	/**
	 * Notification for selection of specific items by user. Those lists are <b>never <code>null</code></b> by convention!
	 * 
	 * @param junctions
	 * @param connectors
	 * @param roadSegments
	 * @param laneSegments
	 * @param vehicles
	 */
	public void itemsSelected(List<AbstractJunction> junctions, List<JunctionConnector> connectors, List<RoadSegment> roadSegments,
			List<LaneSegment> laneSegments, List<Vehicle> vehicles);
}

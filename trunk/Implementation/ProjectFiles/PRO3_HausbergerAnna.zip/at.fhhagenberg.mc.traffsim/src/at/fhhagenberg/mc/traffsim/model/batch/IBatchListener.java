package at.fhhagenberg.mc.traffsim.model.batch;

import java.io.File;
import java.util.Collection;
import java.util.List;

public interface IBatchListener {
	/**
	 * Notification that batch has started
	 *
	 * @param originalConfigurations
	 *            the scheduled configurations, as file links to configurations. These should be the files already copied to the temporary
	 *            directory, if copying is enabled
	 * @param currentScheduledSimulations
	 *            the currently scheduled simulations
	 * @param executor
	 *            a batch executor to receive notifications
	 */
	public void batchStarted(List<File> originalConfigurations, List<ScheduledSimulation> currentScheduledSimulations,
			BatchExecutor executor);

	public void currentSimulationsChanged(List<ScheduledSimulation> newScheduledSimulations, Collection<ScheduledSimulation> active,
			boolean clearOld);

	/**
	 * Notification that current configurations have changed
	 *
	 * @param newConfigurations
	 *            a complete list of new configurations, as file links to temporary directory.
	 * @param active
	 *            the currently active configuration
	 */
	public void currentConfigurationsChanged(List<File> newConfigurations, File active);

	public void batchFinished();

	public void logLine(String line);

	default public void replaceLastLogCharacters(int numChar, String toAppend) {
	};

}

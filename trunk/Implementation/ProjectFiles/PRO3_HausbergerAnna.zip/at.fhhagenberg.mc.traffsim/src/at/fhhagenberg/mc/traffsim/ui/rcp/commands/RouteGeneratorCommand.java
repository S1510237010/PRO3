package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.util.List;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.routing.routegenerator.RouteGenerator;
import at.fhhagenberg.mc.traffsim.routing.routegenerator.VehicleAttributes;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route.RouteGeneratorWizard;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.route.RouteParameterPage.RouteParameters;

public class RouteGeneratorCommand implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {

	}

	@Override
	public void dispose() {

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		RouteGeneratorWizard routeWizard = new RouteGeneratorWizard();
		WizardDialog dialog = new WizardDialog(Display.getCurrent().getActiveShell(), routeWizard);
		int result = dialog.open();

		if (result == Dialog.CANCEL) {
			return null;
		}

		final RouteParameters routeParams = routeWizard.getRouteParameters();
		final boolean appendToExistingConfig = routeWizard.getAppendToExistingConfig();
		final List<VehicleAttributes> vehicleParams = routeWizard.getVehicleParameters();
		final String configFileName = routeWizard.getConfigFileName();
		final String vehiclesFileName = routeWizard.getVehiclesFileName();
		final String routesFileName = routeWizard.getRoutesFileName();
		final String parametersFileName = routeWizard.getParametersFileName();
		final String outputFolderName = routeWizard.getOutputFolder();
		final boolean updateMappings = routeWizard.getUpdateMappings();

		Job job = new Job("Route generation") {

			@Override
			protected IStatus run(IProgressMonitor monitor) {
				RouteGenerator gen = new RouteGenerator(routeParams.configFile, appendToExistingConfig, routeParams.useExistingRoutes,
						routeParams.nrRoutes, routeParams.maxRouteIndex, routeParams.startInterval, routeParams.startDate, vehicleParams,
						routeParams.startIds, routeParams.endIds, -1, configFileName, vehiclesFileName, routesFileName, parametersFileName,
						routeWizard.getCommDataFileName(), outputFolderName, monitor);
				gen.generateAndSave(updateMappings);
				return Status.OK_STATUS;
			}
		};

		job.setUser(true);
		job.schedule();
		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {

	}
}

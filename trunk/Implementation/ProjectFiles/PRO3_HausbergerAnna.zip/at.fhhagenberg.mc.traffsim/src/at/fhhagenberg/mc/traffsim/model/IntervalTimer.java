package at.fhhagenberg.mc.traffsim.model;

import at.fhhagenberg.mc.traffsim.log.Logger;

/**
 * Timer class, which notifies the subclass as soon as time is up by {@link #timeIsUp()} method. The subclass can decide whatever is
 * necessary after this time period. The subclass also can reset the timer by {@link #resetTimer()} method. This is useful for e.g. cache
 * classes which should not hold their cache forever, but for a limited period of time.
 * 
 * In order to avoid running this thread forever, it destroys itself each time the time interval is up and re-creates as soon as the
 * interval is reset.
 * 
 * @author Christian Backfrieder
 * 
 */
public abstract class IntervalTimer {
	private long interval;
	private volatile long lastAccess = 0;

	private Thread cleanThread;
	private String name;

	public IntervalTimer(String name, long intervalMillis) {
		this.interval = intervalMillis;
		this.name = name;
	}

	private void createAndStartThread() {
		cleanThread = new Thread(name) {
			public void run() {
				while (true) {
					long now = System.currentTimeMillis();
					long newSleeptime;
					if (now - lastAccess > interval) {
						timeIsUp();
						// stop threads execution
						break;
					}
					newSleeptime = interval - (now - lastAccess);
					try {
						Thread.sleep(newSleeptime);
					} catch (InterruptedException e) {
						Logger.logInfo("Cache cleaner terminated.");
						break;
					}
				}
			}
		};
		cleanThread.start();
	}

	/**
	 * Reset the timer, start counting. By this method, the {@link Thread} is created.
	 */
	public synchronized void resetTimer() {
		lastAccess = System.currentTimeMillis();
		if (cleanThread == null || !cleanThread.isAlive()) {
			createAndStartThread();
		}
	}

	/**
	 * Notification of a exceeded timer interval
	 */
	protected abstract void timeIsUp();

}

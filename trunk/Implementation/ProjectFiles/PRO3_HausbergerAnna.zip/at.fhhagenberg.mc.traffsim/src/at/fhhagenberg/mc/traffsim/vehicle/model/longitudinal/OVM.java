package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import com.esotericsoftware.kryo.Kryo;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.OVMData;

/**
 * Optimal Velocity
 *
 * @author Manuel Lindorfer
 *
 */
public class OVM extends LongitudinalModel {

	public enum OVMFunction {
		BANDO, THREEPHASE, TRIANGULAR,
	}

	private OVMData data;

	public OVM(){
		
	}
	
	public OVM(OVMData data) {
		super(data.getIdentifier());
		fullname = data.getFullname();
		this.data = data;
	}

	@Override
	public double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit) {
		/**
		 * Speed limit: OVM causes accidents due to immediate braking reaction
		 **/
		final double v0Local = Math.min(alphaV0 * data.getvTarget(), speedLimit);

		/** Actual acceleration calculation **/
		final double transitionWidthLoc = Math.max(1e-6, data.getTransitionWidth() * alphaT);

		final double betaLoc = data.getBeta();

		/** Optimal velocity **/
		double vOptimal = 0;

		final double s0 = data.getsMin();

		OVMFunction variant = data.getOVMFunction();

		if (variant == OVMFunction.BANDO) {
			/** Standard OVM function (Bando) **/
			final double v0Prev = v0Local / (1.0 + Math.tanh(betaLoc));
			vOptimal = Math.max(v0Prev * (Math.tanh((s - s0) / transitionWidthLoc - betaLoc) - Math.tanh(-betaLoc)), 0.);
		} else if (variant == OVMFunction.TRIANGULAR) {
			final double T = data.getBeta();
			vOptimal = Math.max(Math.min((s - s0) / T, v0Local), 0.0);
		} else if (variant == OVMFunction.THREEPHASE) {
			final double diffT = 0.0 * Math.pow(Math.max(1 - v / v0Local, 0.0001), 0.5);

			/** Minimum time headway **/
			final double Tmin = transitionWidthLoc + diffT;

			/** Maximum time headway **/
			final double Tmax = betaLoc + diffT;

			final double Tdyn = (s - s0) / Math.max(v, 1e-7);
			vOptimal = Tdyn > Tmax ? Math.min((s - s0) / Tmax, v0Local)
					: Tdyn > Tmin ? Math.min(v, v0Local) : Tdyn > 0 ? Math.min((s - s0) / Tmin, v0Local) : 0;
		}

		double aWanted = 0;
		final double tau = data.getTau();
		final double gamma = data.getGamma();

		if (variant == OVMFunction.BANDO) {
			/** Original VDIFF model, OVM: Gamma == 0 **/
			aWanted = (vOptimal - v) / tau - gamma * dv;
		} else if (variant == OVMFunction.TRIANGULAR) {
			aWanted = (vOptimal - v) / tau - gamma * v * dv / Math.max(s - 1.0 * s0, 1e-7);
		} else if (variant == OVMFunction.THREEPHASE) {
			aWanted = (vOptimal - v) / tau - gamma * (dv > 0 ? dv : 0);
		}

		return Math.min(aWanted, data.getComfortableAcc());
	}

	@Override
	public LongitudinalModel createCopyFor(double speed) {
		OVMData copy = new Kryo().copy(data);
		copy.setvTarget(speed);
		return new OVM(copy);
	}

	@Override
	public LongitudinalModelData getModelData() {
		return data;
	}

	@Override
	public boolean isSafeAcceleration(double acceleration) {
		return acceleration < data.getMaxAcc() && acceleration > data.getMaxDec();
	}
}

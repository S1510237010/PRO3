package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.SelfOrganizingController.Mode;

public class SelfOrganizingTrafficLightConfigurationParameters extends TrafficLightConfigurationParameters {
	public long targetCycle;
	public long maxCycle;
	public long updateInterval;
	public long timeHorizon;
	public long passOverTime;
	public long startUpLossTime;
	public boolean useHeuristics;
	public Mode mode;
}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data.LongitudinalModelData;

public interface ILongitudinalModel {

	double calcAcc(Vehicle me, double v, double s, double dv, double aLead, double alphaT, double alphaV0, double alphaA,
			double speedLimit);

	LongitudinalModelData getModelData();

	boolean isSafeAcceleration(double acceleration);
	
	LongitudinalModel createCopyFor(double targetSpeed);
}
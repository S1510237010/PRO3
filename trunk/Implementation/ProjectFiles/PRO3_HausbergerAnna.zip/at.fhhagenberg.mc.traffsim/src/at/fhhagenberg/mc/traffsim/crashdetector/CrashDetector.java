package at.fhhagenberg.mc.traffsim.crashdetector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.vividsolutions.jts.index.quadtree.Quadtree;

import at.fhhagenberg.mc.traffsim.model.IntervalUpdateThread;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.jts.JTSAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.IObstructionListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Obstruction;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * This class is responsible for the detection of collision between any of the vehicles and/or obstacles being part of a simulation run.
 * Once such a collision has been detected, all registered {@link ICrashListener} are notified. The detection mechanism is triggered at
 * every simulation update time step.
 */
public class CrashDetector extends IntervalUpdateThread implements IVehicleGeneratorListener, IVehicleListener, IObstructionListener {

	/** The unique identifiers of vehicles being involved in a collision */
	private HashSet<Long> crashingIds = new HashSet<>();

	/**
	 * A list of listeners being informed in case a collision has been detected
	 */
	private List<ICrashListener> crashListeners = new ArrayList<>();

	/** A set of vehicles which have to be considered for crash detection */
	private List<Vehicle> vehicles = new ArrayList<>();

	/**
	 * lock for access to vehicles
	 */
	private Lock vehiclesLock = new ReentrantLock();

	/**
	 * Instantiates a new crash detector.
	 *
	 * @param name
	 *            the name of the detector
	 * @param simulationTimeInterval
	 *            the simulation time update interval
	 */
	public CrashDetector(String name, long simulationTimeInterval) {
		super(name, simulationTimeInterval);
	}

	/**
	 * Adds the the given {@link ICrashListener} to the crash detector. It will be notified in case a collision has been detected.
	 *
	 * @param listener
	 *            the {@link ICrashListener} to be added.
	 */
	public void addCrashListener(ICrashListener listener) {
		crashListeners.add(listener);
	}

	/**
	 * removes the provided {@link ICrashListener} from those to be notified
	 *
	 * @param listener
	 */
	public void removeCrashListener(ICrashListener listener) {
		crashListeners.remove(listener);
	}

	@Override
	public void doWorkWaitForFinish() {
		// create copy to can remove vehicles which are checked
		List<Vehicle> vehiclescopy;
		try {
			vehiclesLock.lock();
			vehiclescopy = new ArrayList<>(vehicles);
		} finally {
			vehiclesLock.unlock();
		}
		Quadtree tree = new Quadtree();
		for (Iterator<Vehicle> it = vehiclescopy.iterator(); it.hasNext();) {
			Vehicle v = it.next();
			List<Vector> bounds = v.getBoundsPolygon();
			if (bounds != null) {
				tree.insert(JTSAdapter.toEnvelope(bounds), v);
			} else {
				it.remove();
			}
		}
		for (Iterator<Vehicle> it = vehiclescopy.iterator(); it.hasNext();) {
			Vehicle v1 = it.next();
			List<?> res = tree.query(JTSAdapter.toEnvelope(v1.getBoundsPolygon()));
			for (Object o : res) {
				Vehicle v2 = (Vehicle) o;
				if (isCrashing(v1, v2)) {
					if (!crashingIds.contains(v1.getUniqueId()) && !crashingIds.contains(v2.getUniqueId())) {
						// new warning, not already warned
						crashingIds = new HashSet<>();
						crashingIds.add(v1.getUniqueId());
						crashingIds.add(v2.getUniqueId());
						notifyCrash(v1, v2);
					}
				}
			}
		}

		pause();

	}

	private boolean isCrashing(Vehicle v1, Vehicle v2) {
		if (!v1.equals(v2) && v1.hasBoundsPolygon() && v2.hasBoundsPolygon()) {
			Vector pos1 = v1.getAbsolutePosition();
			Vector pos2 = v2.getAbsolutePosition();
			double maxLength = Math.max(SpatialUtil.getMaxExtent(v1.getBoundsPolygon()), SpatialUtil.getMaxExtent(v2.getBoundsPolygon()));

			if (Math.abs(pos1.x - pos2.x) < maxLength && Math.abs(pos1.y - pos2.y) < maxLength) {
				if (SpatialUtil.intersects(v1.getBoundsPolygon(), v2.getBoundsPolygon()) || SpatialUtil.contains(v1.getBoundsPolygon(), pos2)
						|| SpatialUtil.contains(v2.getBoundsPolygon(), pos1)) {
					VehiclesLane v1Lane = v1.getLaneSegment();
					VehiclesLane v2Lane = v2.getLaneSegment();
					// check if the road segments are crossing (bridge)
					if (!v1Lane.equals(v2Lane) && !SpatialUtil.areBordering(v1Lane, v2Lane)) {
						// crossing segments which are not part of junction
						// - must be bridge. ignore potential crash

					} else {
						if (v1Lane instanceof JunctionConnector && v2Lane instanceof JunctionConnector
								&& ((JunctionConnector) v1Lane).getJunction().getId() != ((JunctionConnector) v2Lane).getJunction().getId()) {
							// both segments are part of junction, but not of
							// same junction id - must be bridge. ignore
							// potential crash
						} else {
							// check if already warned about this crash
							return true;

						}
					}
				}
			}
		}
		return false;
	}

	/**
	 * Notifies all {@link ICrashListener} that a collision between {@link Vehicle} v1 and {@link Vehicle} v2 has been detected.
	 *
	 * @param v1
	 *            the first vehicle being involved in the collision
	 * @param v2
	 *            the second vehicle being involved in the collision
	 */
	private void notifyCrash(Vehicle v1, Vehicle v2) {
		for (ICrashListener l : crashListeners) {
			l.crashDetected(v1, v2);
		}
	}

	@Override
	public void obstructionDecomposed(Obstruction o) {
		try {
			vehiclesLock.lock();
			if (vehicles.contains(o)) {
				vehicles.remove(o);
			}
		} finally {
			vehiclesLock.unlock();
		}
	}

	@Override
	public void obstructionGenerated(Obstruction o) {
		try {
			vehiclesLock.lock();
			vehicles.add(o);
		} finally {
			vehiclesLock.unlock();
		}
	}

	@Override
	public void vehicleGenerated(Vehicle v) {
		v.addVehicleListener(this);
		try {
			vehiclesLock.lock();
			vehicles.add(v);
		} finally {
			vehiclesLock.unlock();
		}

	}

	@Override
	public void vehicleLeftSimulation(Vehicle v) {
		try {
			vehiclesLock.lock();
			vehicles.remove(v);
		} finally {
			vehiclesLock.unlock();
		}
	}
}
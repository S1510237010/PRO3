package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.BatteryDataBean;

/**
 * This class represents a battery.
 *
 * @author Anna
 *
 */
class Batterie {

	/**
	 * number of cells in the battery.
	 */
	private int mCells;
	/**
	 * type of battery.
	 */
	private BatteryType mType;
	/**
	 * Degree of discharge (1 == full, 0 == fully discharged).
	 */
	private double mDoD;
	/**
	 * maximum capacity of the battery in Ah.
	 */
	private double mCapacity;
	/**
	 * current charge of the battery.
	 */
	private double mCharge;
	/**
	 * maximum charge of battery.
	 */
	private final double mMAXCHARGE;
	/**
	 * Peukert coefficient.
	 */
	private double mK;

	public Batterie(BatteryDataBean _bean) {
		mMAXCHARGE = _bean.getMaxCharge();
		mCells = _bean.getCells();
		mCharge = mMAXCHARGE;
		mType = BatteryType.valueOf(_bean.getType());
		mDoD = 1;
		mCapacity = _bean.getCapacity();
		mK = _bean.getK();
	}

	/**
	 * @return the Amphour Capacity for a 10h rate.
	 */
	private double getAmphCapa() {
		return Math.pow((mCapacity / 10), mK) * 10;
	}

	/**
	 * @return the resistance of the battery.
	 */
	private double getResistance() {
		if (mType == BatteryType.LEADACID) {
			return mCells * 0.022f / getAmphCapa();
		} else if (mType == BatteryType.NICKELBASED) {
			return mCells * 0.06f / getAmphCapa();
		}
		return Double.MIN_VALUE;
	}

	/**
	 * @return calculated open circuit voltage from the battery, depending on DoD.
	 */
	private double getOpenCircuitV() {

		if (mType == BatteryType.LEADACID) {
			return mCells * (2.15f - mDoD * (2.15f - 2.0f));
		} else if (mType == BatteryType.NICKELBASED) {
			return mCells * (-8.2816f * Math.pow(mDoD, 7) + 23.5749f * Math.pow(mDoD, 6) - 30 * Math.pow(mDoD, 5) + 23.7053f * Math.pow(mDoD, 4)
					- 12.5877f * Math.pow(mDoD, 3) + 4.1315f * Math.pow(mDoD, 2) - 0.8658f * mDoD + 1.37f);
		}

		return Double.MIN_VALUE;
	}

	/**
	 * @param _power
	 *            power to be overcome by the car
	 * @return needed I from the battery
	 */
	public double getCurrentI(double _power) {
		double I = Integer.MIN_VALUE;
		double E = getOpenCircuitV();
		double R = getResistance();
		if (_power >= 0) {
			I = (E - Math.sqrt(Math.pow(E, 2) - 4 * R * _power)) / (2 * R);
		} else {
			I = (-E + Math.sqrt(Math.pow(E, 2) + 4 * R * _power)) / (2 * R);
		}
		return I;
	}

	/**
	 * @param _I
	 *            charge applied to the battery.
	 * @param _sec
	 *            for how long the battery is charged or discharged.
	 * @return the charge that was applied or subtracted from the battery
	 */
	public double changeCharge(double _I, double _sec) {

		if (isEmpty()) {
			return Double.MIN_VALUE;
		}

		// if _I < 0 -> charging, else if _I > 0 -> discharging
		mCharge = mCharge - (_sec * _I) / 3600;
		mDoD = mCharge / mMAXCHARGE;

		return _I;
	}

	/**
	 * @return controls if the battery is empty or not.
	 */
	public boolean isEmpty() {
		return mDoD <= 0;
	}

}

package at.fhhagenberg.mc.traffsim.communication.messaging;

public abstract class MessagePayload {
	/**
	 * 
	 * @return the size of the message payload data in bytes
	 */
	public abstract int getSize();
}

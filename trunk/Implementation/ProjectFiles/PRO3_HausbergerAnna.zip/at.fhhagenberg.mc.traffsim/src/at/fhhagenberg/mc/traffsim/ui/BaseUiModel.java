package at.fhhagenberg.mc.traffsim.ui;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.ui.AWTAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public abstract class BaseUiModel {
	protected Matrix transformMatrix;

	public class IntersectionResult {
		final List<Vehicle> vehicles;
		final List<RoadSegment> roadSegments;
		final List<LaneSegment> laneSegments;
		final List<AbstractJunction> junctions;
		final List<JunctionConnector> connectors;

		public IntersectionResult(List<Vehicle> vehicles, List<RoadSegment> roadSegments, List<LaneSegment> laneSegments,
				List<AbstractJunction> junctions, List<JunctionConnector> connectors) {
			super();
			this.vehicles = vehicles;
			this.roadSegments = roadSegments;
			this.laneSegments = laneSegments;
			this.junctions = junctions;
			this.connectors = connectors;
		}

		public List<Vehicle> getVehicles() {
			return vehicles;
		}

		public List<RoadSegment> getRoadSegments() {
			return roadSegments;
		}

		public List<LaneSegment> getLaneSegments() {
			return laneSegments;
		}

		public List<AbstractJunction> getJunctions() {
			return junctions;
		}

		public List<JunctionConnector> getConnectors() {
			return connectors;
		}

	}

	/**
	 * Check if the given geometry (interpreted as polygon) intersects with any of the provided {@link RoadSegment}s or
	 * {@link AbstractJunction}s. All coordinates have of course to be real coordinates, no screen coordinates!
	 * 
	 * @param roadSegments
	 * @param junctions
	 * @param geometry
	 * @return {@link IntersectionResult} containing all road segments and junctions which intersect with the given geometry
	 */
	public IntersectionResult checkIntersection(List<RoadSegment> roadSegments, List<AbstractJunction> junctions, List<Vector> geometry) {
		List<Vehicle> selectedVehicles = new ArrayList<>();
		List<RoadSegment> selectedRoadSegments = new ArrayList<>();
		List<AbstractJunction> selectedJunctions = new ArrayList<>();
		List<JunctionConnector> selectedConnectors = new ArrayList<>();
		List<LaneSegment> selectedLaneSegments = new ArrayList<>();

		if (roadSegments != null) {
			for (RoadSegment s : roadSegments) {

				if (s == null) {
					continue;
				}

				// initial check if intersection is there, fine check is performed in if clause
				if ((s.getBounds()).intersects(AWTAdapter.toRectangle2D(geometry))) {
					for (Vehicle v : s.getAllVehicles()) {
						if (SpatialUtil.intersectsArea(v.getBoundsPolygon(), geometry)) {
							selectedVehicles.add(v);
						}
					}
					for (LaneSegment ls : s.getLaneSegments()) {
						if (SpatialUtil.intersectsArea(ls.getBounds(), geometry)) {
							selectedLaneSegments.add(ls);
							if (!selectedRoadSegments.contains(s)) {
								selectedRoadSegments.add(s);
							}
						}
					}
				}
			}
		}

		if (junctions != null) {
			for (AbstractJunction junc : junctions) {

				if (junc == null) {
					continue;
				}

				if (SpatialUtil.intersectsArea(junc.getBounds(), geometry)) {
					selectedJunctions.add(junc);
					for (JunctionConnector conn : junc.getConnectors()) {
						if (SpatialUtil.intersectsArea(conn.getBounds(), geometry)) {
							selectedConnectors.add(conn);
						}
					}
				}
			}
		}

		return new IntersectionResult(selectedVehicles, selectedRoadSegments, selectedLaneSegments, selectedJunctions, selectedConnectors);
	}

	public IntersectionResult checkIntersection(List<RoadSegment> roadSegments, List<AbstractJunction> junctions, Vector point) {
		return checkIntersection(roadSegments, junctions, SpatialUtil.extendToSquare(point, 1));
	}

	/**
	 * Scroll vertically
	 * 
	 * @param _delta
	 *            to scroll in pixel, nevative values affect scrolling left, positive ones right
	 */
	public void scrollVertical(int _delta) {
		scrollDiagonal(0, -_delta);
		updateView(true);
	}

	/**
	 * Scroll horizontally
	 * 
	 * @param _delta
	 *            scroll value in pixel, negative values affect scrolling downwards, positive ones upwards
	 */
	public void scrollHorizontal(int _delta) {
		scrollDiagonal(_delta, 0);
		updateView(true);

	}

	/**
	 * Scroll in both directions
	 * 
	 * @param _xDelta
	 *            delta to scroll in x-direction
	 * @param _yDelta
	 *            delta to scroll in y-direction
	 */
	public void scrollDiagonal(int _xDelta, int _yDelta) {
		transformMatrix = (Matrix.translate(_xDelta, _yDelta).multiply(transformMatrix));
		updateView(true);
	}

	public void zoom(Point pt, double factor) {
		transformMatrix = Matrix.zoomPoint(transformMatrix, pt, factor);
		updateView(true);
	}

	public abstract void updateView(boolean forceRedraw);

	public abstract void clickedOn(Point screenCoords, int mouseOptionState);
}

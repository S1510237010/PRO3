package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

public class FixedTimeTrafficLightConfigurationParameters extends TrafficLightConfigurationParameters {
	public boolean startWithGreenPhase;
	public long phaseDelay;
	public long greenPhase;
	public long redPhase;
	public long offset;
}

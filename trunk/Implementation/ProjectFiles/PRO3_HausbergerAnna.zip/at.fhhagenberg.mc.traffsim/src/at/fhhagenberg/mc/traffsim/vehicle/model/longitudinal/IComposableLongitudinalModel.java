package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal;

public interface IComposableLongitudinalModel extends ILongitudinalModel {
	/**
	 * Calculate acceleration as if vehicle was on empty road
	 * 
	 * @param v
	 * @param speedLimit
	 * @param alphaT
	 * @param alphaV0
	 * @param alphaA
	 * @return the acceleration value in m/s^2
	 */
	public abstract double calcAccComponent(double v, double speedLimit, double alphaT, double alphaV0, double alphaA);

	/**
	 * Calc negative part of acceleration function, considering other vehicles
	 * 
	 * @param v
	 * @param speedLimit
	 * @param s
	 * @param dv
	 * @param aLead
	 * @param alphaT
	 * @param alphaV0
	 * @param alphaA
	 * @param renormalizationFactor
	 * @return negative acceleration representing breaking component
	 */
	public abstract double calcBrakeComponent(double v, double speedLimit, double s, double dv, double aLead, double alphaT, double alphaV0,
			double alphaA, double renormalizationFactor);

}

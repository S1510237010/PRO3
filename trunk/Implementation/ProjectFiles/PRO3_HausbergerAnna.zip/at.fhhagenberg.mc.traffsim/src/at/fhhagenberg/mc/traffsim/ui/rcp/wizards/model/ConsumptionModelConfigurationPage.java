package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionCarDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.EngineDataBean;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.ConsumptionModels;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class ConsumptionModelConfigurationPage extends ModelConfigurationPage {

	// Car data
	private Spinner spinnerVehicleMass;
	private Spinner spinnerCrossSectionSurface;
	private Spinner spinnerCDValue;
	private Spinner spinnerElectricPower;
	private Spinner spinnerFrictionCoefficient;
	private Spinner spinnerVFrictionCoefficient;
	private Spinner spinnerTyreRadius;

	// Engine data
	private Spinner spinnerMaxEnginePower;
	private Spinner spinnerCylinderVolume;
	private Spinner spinnerConsumptionRate;
	private Spinner spinnerMinSpecificConsumptionRate;
	private Spinner spinnerMinPressure;
	private Spinner spinnerMaxPressure;
	private Spinner spinnerIdleRotationRate;
	private Spinner spinnerMaxRotationRate;
	private Text txtGearRatios;

	private ConsumptionModels currentModel;

	protected ConsumptionModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		Label lblCarData = new Label(grpModelParameters, SWT.NONE);
		lblCarData.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblCarData.setText("Car data");
		lblCarData.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 8, 1));

		Label lblVehicleMass = new Label(grpModelParameters, SWT.NONE);
		lblVehicleMass.setText("Vehicle mass [kg]");

		spinnerVehicleMass = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerVehicleMass.setPageIncrement(50);
		spinnerVehicleMass.setIncrement(5);
		spinnerVehicleMass.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerVehicleMass.setMaximum(10000);
		spinnerVehicleMass.setMinimum(300);
		spinnerVehicleMass.setSelection(1500);
		spinnerVehicleMass.setDigits(0);

		Label lblCrossSectionSurface = new Label(grpModelParameters, SWT.NONE);
		lblCrossSectionSurface.setText("Cross section surface [m�]");

		spinnerCrossSectionSurface = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerCrossSectionSurface.setPageIncrement(5);
		spinnerCrossSectionSurface.setIncrement(1);
		spinnerCrossSectionSurface.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerCrossSectionSurface.setMaximum(100);
		spinnerCrossSectionSurface.setMinimum(0);
		spinnerCrossSectionSurface.setSelection(22);
		spinnerCrossSectionSurface.setDigits(1);

		Label lblCdValue = new Label(grpModelParameters, SWT.NONE);
		lblCdValue.setText("CD value");

		spinnerCDValue = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerCDValue.setPageIncrement(5);
		spinnerCDValue.setIncrement(1);
		spinnerCDValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerCDValue.setMaximum(100);
		spinnerCDValue.setMinimum(0);
		spinnerCDValue.setSelection(32);
		spinnerCDValue.setDigits(2);

		Label lblElectricPower = new Label(grpModelParameters, SWT.NONE);
		lblElectricPower.setText("Electric power [W]");

		spinnerElectricPower = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerElectricPower.setPageIncrement(50);
		spinnerElectricPower.setIncrement(5);
		spinnerElectricPower.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerElectricPower.setMaximum(10000);
		spinnerElectricPower.setMinimum(500);
		spinnerElectricPower.setSelection(3000);
		spinnerElectricPower.setDigits(0);

		Label lblFrictionCoefficient = new Label(grpModelParameters, SWT.NONE);
		lblFrictionCoefficient.setText("Cons. friction coefficient");

		spinnerFrictionCoefficient = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerFrictionCoefficient.setPageIncrement(10);
		spinnerFrictionCoefficient.setIncrement(1);
		spinnerFrictionCoefficient.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerFrictionCoefficient.setMaximum(1000);
		spinnerFrictionCoefficient.setMinimum(0);
		spinnerFrictionCoefficient.setSelection(15);
		spinnerFrictionCoefficient.setDigits(3);

		Label lblVFrictionCoefficient = new Label(grpModelParameters, SWT.NONE);
		lblVFrictionCoefficient.setText("V. friction coefficient");

		spinnerVFrictionCoefficient = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerVFrictionCoefficient.setPageIncrement(10);
		spinnerVFrictionCoefficient.setIncrement(1);
		spinnerVFrictionCoefficient.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerVFrictionCoefficient.setMaximum(1000);
		spinnerVFrictionCoefficient.setMinimum(0);
		spinnerVFrictionCoefficient.setSelection(0);
		spinnerVFrictionCoefficient.setDigits(3);

		Label lblDynamicTyreRadius = new Label(grpModelParameters, SWT.NONE);
		lblDynamicTyreRadius.setText("Dynamic tyre radius [m]");

		spinnerTyreRadius = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerTyreRadius.setPageIncrement(10);
		spinnerTyreRadius.setIncrement(1);
		spinnerTyreRadius.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerTyreRadius.setMaximum(200);
		spinnerTyreRadius.setMinimum(10);
		spinnerTyreRadius.setSelection(31);
		spinnerTyreRadius.setDigits(2);

		new Label(grpModelParameters, SWT.NONE);
		new Label(grpModelParameters, SWT.NONE);
		new Label(grpModelParameters, SWT.NONE);
		new Label(grpModelParameters, SWT.NONE);

		Label lblEngineData = new Label(grpModelParameters, SWT.NONE);
		lblEngineData.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblEngineData.setText("Engine data");
		lblEngineData.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 8, 1));

		Label lblMaxPower = new Label(grpModelParameters, SWT.NONE);
		lblMaxPower.setText("Max. engine power [W]");

		spinnerMaxEnginePower = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMaxEnginePower.setPageIncrement(10);
		spinnerMaxEnginePower.setIncrement(1);
		spinnerMaxEnginePower.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMaxEnginePower.setMaximum(300);
		spinnerMaxEnginePower.setMinimum(10);
		spinnerMaxEnginePower.setSelection(90);
		spinnerMaxEnginePower.setDigits(0);

		Label lblCylinderVolume = new Label(grpModelParameters, SWT.NONE);
		lblCylinderVolume.setText("Cylinder volume [l]");

		spinnerCylinderVolume = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerCylinderVolume.setPageIncrement(5);
		spinnerCylinderVolume.setIncrement(1);
		spinnerCylinderVolume.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerCylinderVolume.setMaximum(50);
		spinnerCylinderVolume.setMinimum(5);
		spinnerCylinderVolume.setSelection(14);
		spinnerCylinderVolume.setDigits(1);

		Label lblConsumptionRate = new Label(grpModelParameters, SWT.NONE);
		lblConsumptionRate.setText("Idle consumption rate [l/s]");

		spinnerConsumptionRate = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerConsumptionRate.setPageIncrement(10);
		spinnerConsumptionRate.setIncrement(1);
		spinnerConsumptionRate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerConsumptionRate.setMaximum(150);
		spinnerConsumptionRate.setMinimum(0);
		spinnerConsumptionRate.setSelection(8);
		spinnerConsumptionRate.setDigits(1);

		Label lblSpecificConsumption = new Label(grpModelParameters, SWT.NONE);
		lblSpecificConsumption.setText("Min. specific consumption [kg/Ws]");

		spinnerMinSpecificConsumptionRate = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMinSpecificConsumptionRate.setPageIncrement(50);
		spinnerMinSpecificConsumptionRate.setIncrement(5);
		spinnerMinSpecificConsumptionRate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMinSpecificConsumptionRate.setMaximum(5000);
		spinnerMinSpecificConsumptionRate.setMinimum(0);
		spinnerMinSpecificConsumptionRate.setSelection(1850);
		spinnerMinSpecificConsumptionRate.setDigits(1);

		Label lblPressureMinimum = new Label(grpModelParameters, SWT.NONE);
		lblPressureMinimum.setText("Min. eff. pressure [Pa]");

		spinnerMinPressure = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMinPressure.setPageIncrement(10);
		spinnerMinPressure.setIncrement(1);
		spinnerMinPressure.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMinPressure.setMaximum(1000);
		spinnerMinPressure.setMinimum(0);
		spinnerMinPressure.setSelection(10);
		spinnerMinPressure.setDigits(1);

		Label lblPressureMaximum = new Label(grpModelParameters, SWT.NONE);
		lblPressureMaximum.setText("Max. eff. pressure [Pa]");

		spinnerMaxPressure = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMaxPressure.setPageIncrement(10);
		spinnerMaxPressure.setIncrement(1);
		spinnerMaxPressure.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMaxPressure.setMaximum(1000);
		spinnerMaxPressure.setMinimum(0);
		spinnerMaxPressure.setSelection(220);
		spinnerMaxPressure.setDigits(1);

		Label lblIdleRotationRate = new Label(grpModelParameters, SWT.NONE);
		lblIdleRotationRate.setText("Idle rotation rate [1/s]");

		spinnerIdleRotationRate = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerIdleRotationRate.setPageIncrement(50);
		spinnerIdleRotationRate.setIncrement(10);
		spinnerIdleRotationRate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerIdleRotationRate.setMaximum(10000);
		spinnerIdleRotationRate.setMinimum(0);
		spinnerIdleRotationRate.setSelection(900);
		spinnerIdleRotationRate.setDigits(0);

		Label lblMaxRotationRate = new Label(grpModelParameters, SWT.NONE);
		lblMaxRotationRate.setText("Max. rotation rate [1/s]");

		spinnerMaxRotationRate = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerMaxRotationRate.setPageIncrement(50);
		spinnerMaxRotationRate.setIncrement(10);
		spinnerMaxRotationRate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerMaxRotationRate.setMaximum(10000);
		spinnerMaxRotationRate.setMinimum(0);
		spinnerMaxRotationRate.setSelection(4500);
		spinnerMaxRotationRate.setDigits(0);

		Label lblGrearRatios = new Label(grpModelParameters, SWT.NONE);
		lblGrearRatios.setText("Gear ratios");

		txtGearRatios = new Text(grpModelParameters, SWT.BORDER);
		txtGearRatios.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		txtGearRatios.setText("13.9,7.8,5.26,3.79,3.09");
		txtGearRatios.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validatePage();
			}
		});

		// Model property initialization
		ModelProperty vehicleMass = new ModelProperty("Vehicle mass [kg]", "setVehicleMass", Double.TYPE, 300, 10000);
		vehicleMass.setParentType(ConsumptionCarDataBean.class);

		ModelProperty sectionSurface = new ModelProperty("Cross section surface [m�]", "setCrossSectionSurface",
				Double.TYPE, 0, 10);
		sectionSurface.setParentType(ConsumptionCarDataBean.class);

		ModelProperty cdValue = new ModelProperty("CD value", "setCdValue", Double.TYPE, 0, 1);
		cdValue.setParentType(ConsumptionCarDataBean.class);

		ModelProperty electricPower = new ModelProperty("Electric power [W]", "setElectricPower", Double.TYPE, 500,
				1000);
		electricPower.setParentType(ConsumptionCarDataBean.class);

		ModelProperty consFriction = new ModelProperty("Cons. friction coefficient", "setConsFrictionCoefficient",
				Double.TYPE, 0, 1);
		consFriction.setParentType(ConsumptionCarDataBean.class);

		ModelProperty vFriction = new ModelProperty("V. friction coefficient", "setvFrictionCoefficient", Double.TYPE,
				0, 1);
		vFriction.setParentType(ConsumptionCarDataBean.class);

		ModelProperty tyreRadius = new ModelProperty("Dynamic tyre radius [m]", "setDynamicTyreRadius", Double.TYPE,
				0.1, 2);
		tyreRadius.setParentType(ConsumptionCarDataBean.class);

		ModelProperty maxEnginePower = new ModelProperty("Max. engine power [W]", "setMaxPower", Double.TYPE, 10, 300);
		maxEnginePower.setParentType(EngineDataBean.class);

		ModelProperty cylinderVolume = new ModelProperty("Cylinder volume [l]", "setCylinderVolume", Double.TYPE, 0.5,
				5);
		cylinderVolume.setParentType(EngineDataBean.class);

		ModelProperty idleConsumptionRate = new ModelProperty("Idle consumption rate [l/s]",
				"setIdleConsumptionRateLiterPerSecond", Double.TYPE, 0, 15);
		idleConsumptionRate.setParentType(EngineDataBean.class);

		ModelProperty minSpecificConsumption = new ModelProperty("Min. specific consumption [kg/Ws]",
				"setMinSpecificConsumption", Double.TYPE, 0, 500);
		minSpecificConsumption.setParentType(EngineDataBean.class);

		ModelProperty minEffPressure = new ModelProperty("Min. eff. pressure [Pa]", "setEffectivePressureMinimum",
				Double.TYPE, 0, 100);
		minEffPressure.setParentType(EngineDataBean.class);

		ModelProperty maxEffPressure = new ModelProperty("Max. eff. pressure [Pa]", "setEffectivePressureMaximum",
				Double.TYPE, 0, 100);
		maxEffPressure.setParentType(EngineDataBean.class);

		ModelProperty idleRotationRate = new ModelProperty("Idle rotation rate [1/s]", "setIdleRotationRate",
				Double.TYPE, 0, 1000);
		idleRotationRate.setParentType(EngineDataBean.class);

		ModelProperty maxRotationRate = new ModelProperty("Max. rotation rate [1/s]", "setMaxRotationRate", Double.TYPE,
				0, 1000);
		maxRotationRate.setParentType(EngineDataBean.class);

		modelProperties.add(vehicleMass);
		modelProperties.add(sectionSurface);
		modelProperties.add(cdValue);
		modelProperties.add(electricPower);
		modelProperties.add(consFriction);
		modelProperties.add(vFriction);
		modelProperties.add(tyreRadius);
		modelProperties.add(maxEnginePower);
		modelProperties.add(cylinderVolume);
		modelProperties.add(idleConsumptionRate);
		modelProperties.add(minSpecificConsumption);
		modelProperties.add(minEffPressure);
		modelProperties.add(maxEffPressure);
		modelProperties.add(idleRotationRate);
		modelProperties.add(maxRotationRate);

		controlMapping.put(vehicleMass, spinnerVehicleMass);
		controlMapping.put(sectionSurface, spinnerCrossSectionSurface);
		controlMapping.put(cdValue, spinnerCDValue);
		controlMapping.put(electricPower, spinnerElectricPower);
		controlMapping.put(consFriction, spinnerFrictionCoefficient);
		controlMapping.put(vFriction, spinnerVFrictionCoefficient);
		controlMapping.put(tyreRadius, spinnerTyreRadius);
		controlMapping.put(maxEnginePower, spinnerMaxEnginePower);
		controlMapping.put(cylinderVolume, spinnerCylinderVolume);
		controlMapping.put(idleConsumptionRate, spinnerConsumptionRate);
		controlMapping.put(minSpecificConsumption, spinnerMinSpecificConsumptionRate);
		controlMapping.put(minEffPressure, spinnerMinPressure);
		controlMapping.put(maxEffPressure, spinnerMaxPressure);
		controlMapping.put(idleRotationRate, spinnerIdleRotationRate);
		controlMapping.put(maxRotationRate, spinnerMaxRotationRate);
	}

	@Override
	protected void validatePage() {
		super.validatePage();

		if (txtGearRatios == null) {
			return;
		}

		StringBuilder sb;

		if (getErrorMessage() == null) {
			sb = new StringBuilder();
		} else {
			sb = new StringBuilder(getErrorMessage());
		}

		if (StringUtil.isNullOrEmpty(txtGearRatios.getText())) {
			sb.insert(0, "Gear ratios must not be empty.\n");
		} else {
			try {
				ArrayList<Double> gears = (ArrayList<Double>) CollectionUtil.toDoubleList(txtGearRatios.getText(), ",");

				if (gears != null) {
					if (!CollectionUtil.isDoubleListInDescendingOrder(gears) || gears.size() < 3) {
						sb.insert(0, 
								"Gear ratios must be a list of at least three numbers (e.g. '4.12') delimited by ',' and in descending order.\n");
					}
				}
			} catch (Exception exc) {
				sb.insert(0, 
						"Gear ratios must be a list of at least three numbers (e.g. '4.12') delimited by ',' and in descending order.\n");
			}
		}

		if (sb.length() == 0) {
			setErrorMessage(null);
			btnAdd.setEnabled(true);
			btnAddStochastically.setEnabled(true);
		} else {
			setErrorMessage(sb.toString());
			btnAdd.setEnabled(false);

			if (getErrorMessage().contains("Gear")) {
				btnAddStochastically.setEnabled(false);
			}else{
				btnAddStochastically.setEnabled(true);
			}
		}
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			currentModel = ConsumptionModels
					.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' model parameters", currentModel.toString()));
		}
	}

	protected void addModelToList() {
		ConsumptionBean consumptionModel = new ConsumptionBean();
		consumptionModel.setModelIdentifier(txtIdentifier.getText());
		consumptionModel.setFullName(txtFullName.getText());

		ConsumptionCarDataBean carData = new ConsumptionCarDataBean();
		carData.setVehicleMass(spinnerVehicleMass.getSelection() / Math.pow(10, spinnerVehicleMass.getDigits()));
		carData.setCrossSectionSurface(
				spinnerCrossSectionSurface.getSelection() / Math.pow(10, spinnerCrossSectionSurface.getDigits()));
		carData.setCdValue(spinnerCDValue.getSelection() / Math.pow(10, spinnerCDValue.getDigits()));
		carData.setElectricPower(spinnerElectricPower.getSelection() / Math.pow(10, spinnerElectricPower.getDigits()));
		carData.setConsFrictionCoefficient(
				spinnerFrictionCoefficient.getSelection() / Math.pow(10, spinnerFrictionCoefficient.getDigits()));
		carData.setvFrictionCoefficient(
				spinnerVFrictionCoefficient.getSelection() / Math.pow(10, spinnerVFrictionCoefficient.getDigits()));
		carData.setDynamicTyreRadius(spinnerTyreRadius.getSelection() / Math.pow(10, spinnerTyreRadius.getDigits()));

		EngineDataBean engineData = new EngineDataBean();
		engineData.setMaxPower(spinnerMaxEnginePower.getSelection() / Math.pow(10, spinnerMaxEnginePower.getDigits()));
		engineData.setCylinderVolume(
				spinnerCylinderVolume.getSelection() / Math.pow(10, spinnerCylinderVolume.getDigits()));
		engineData.setIdleConsumptionRateLiterPerSecond(
				spinnerConsumptionRate.getSelection() / Math.pow(10, spinnerConsumptionRate.getDigits()));
		engineData.setMinSpecificConsumption(spinnerMinSpecificConsumptionRate.getSelection()
				/ Math.pow(10, spinnerMinSpecificConsumptionRate.getDigits()));
		engineData.setEffectivePressureMinimum(
				spinnerMinPressure.getSelection() / Math.pow(10, spinnerMinPressure.getDigits()));
		engineData.setEffectivePressureMaximum(
				spinnerMaxPressure.getSelection() / Math.pow(10, spinnerMaxPressure.getDigits()));
		engineData.setIdleRotationRate(
				spinnerIdleRotationRate.getSelection() / Math.pow(10, spinnerIdleRotationRate.getDigits()));
		engineData.setMaxRotationRate(
				spinnerMaxRotationRate.getSelection() / Math.pow(10, spinnerMaxRotationRate.getDigits()));
		engineData.setGearRatios(CollectionUtil.toDoubleList(txtGearRatios.getText(), ","));

		consumptionModel.setCarData(carData);
		consumptionModel.setEngineData(engineData);

		modelSet.add(consumptionModel);
	}

	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getModelIdentifier() + "";
			}
		});

		TableViewerColumn colMass = createTableViewerColumn("Vehicle mass [kg]", 120);
		colMass.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getCarData().getVehicleMass() + "";
			}
		});

		TableViewerColumn colSurface = createTableViewerColumn("Cross section surface [m�]", 160);
		colSurface.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getCarData().getCrossSectionSurface() + "";
			}
		});

		TableViewerColumn colCdValue = createTableViewerColumn("CD value", 100);
		colCdValue.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getCarData().getCdValue() + "";
			}
		});

		TableViewerColumn colElectricPower = createTableViewerColumn("Electric power [W]", 120);
		colElectricPower.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getCarData().getElectricPower() + "";
			}
		});

		TableViewerColumn colConsFriction = createTableViewerColumn("Cons. friction coefficient", 150);
		colConsFriction.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getCarData().getConsFrictionCoefficient() + "";
			}
		});

		TableViewerColumn colVFriction = createTableViewerColumn("V. friction coefficient", 150);
		colVFriction.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getCarData().getvFrictionCoefficient() + "";
			}
		});

		TableViewerColumn colDynamicTyreRadius = createTableViewerColumn("Dynamic tyre radius [m]", 150);
		colDynamicTyreRadius.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getCarData().getDynamicTyreRadius() + "";
			}
		});

		TableViewerColumn colMaxPower = createTableViewerColumn("Max. engine power [W]", 150);
		colMaxPower.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getMaxPower() + "";
			}
		});

		TableViewerColumn colCylinderVolume = createTableViewerColumn("Cylinder volume [l]", 140);
		colCylinderVolume.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getCylinderVolume() + "";
			}
		});

		TableViewerColumn colIdleConsumptionRate = createTableViewerColumn("Idle consumption rate [l/s]", 160);
		colIdleConsumptionRate.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getIdleConsumptionRateLiterPerSecond() + "";
			}
		});

		TableViewerColumn coldMinSpecConsumption = createTableViewerColumn("Min. specific consumption [kg/Ws]", 200);
		coldMinSpecConsumption.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getMinSpecificConsumption() + "";
			}
		});

		TableViewerColumn colEffPressureMinimum = createTableViewerColumn("Min. eff. pressure [Pa]", 150);
		colEffPressureMinimum.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getEffectivePressureMinimum() + "";
			}
		});

		TableViewerColumn colEffPressureMaximum = createTableViewerColumn("Max. eff. pressure [Pa]", 150);
		colEffPressureMaximum.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getEffectivePressureMaximum() + "";
			}
		});

		TableViewerColumn colIdleRotationRate = createTableViewerColumn("Idle rotation rate [1/s]", 150);
		colIdleRotationRate.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getIdleRotationRate() + "";
			}
		});

		TableViewerColumn colMaxRotationRate = createTableViewerColumn("Max. rotation rate [1/s]", 150);
		colMaxRotationRate.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getMaxRotationRate() + "";
			}
		});

		TableViewerColumn colGearRatios = createTableViewerColumn("Gear ratios", 100);
		colGearRatios.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((ConsumptionBean) element).getEngineData().getGearRatios() + "";
			}
		});
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {
		try {
			Class<?> cls = ConsumptionBean.class;
			Class<?> carCls = ConsumptionCarDataBean.class;
			Class<?> engineCls = EngineDataBean.class;

			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();
				Object carObj = carCls.newInstance();
				Object engineObj = engineCls.newInstance();

				cls.getMethod("setModelIdentifier", String.class).invoke(obj,
						currentModel.getShortName() + "_gen_" + generationTime + "-" + (i + 1));
				cls.getMethod("setFullName", String.class).invoke(obj, "Auto. generated memory model");

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Object currentObject = null;
					Class<?> currentClass = null;

					if (property.getParentType() == null) {
						currentObject = obj;
						currentClass = cls;
					} else if (property.getParentType() == ConsumptionCarDataBean.class) {
						currentObject = carObj;
						currentClass = carCls;
					} else if (property.getParentType() == EngineDataBean.class) {
						currentObject = engineObj;
						currentClass = engineCls;
					}

					Method setter = currentClass.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);
						
						if (property.getType() == Integer.TYPE) {
							setter.invoke(currentObject, (int) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(currentObject, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(currentObject, (int) (spinner.getSelection()
										/ Math.pow(10, spinner.getDigits())  * property.getConversionFactor()));
							} else {
								setter.invoke(currentObject, (spinner.getSelection()
										/ Math.pow(10, spinner.getDigits()) * property.getConversionFactor()));
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(currentObject, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(currentObject, text.getText());
						}
					}
				}

				// Set list property manually since it requires special
				// conversion
				engineCls.getMethod("setGearRatios", List.class).invoke(engineObj,
						CollectionUtil.toDoubleList(txtGearRatios.getText(), ","));

				// Set child beans
				cls.getMethod("setCarData", ConsumptionCarDataBean.class).invoke(obj, carObj);
				cls.getMethod("setEngineData", EngineDataBean.class).invoke(obj, engineObj);

				modelSet.add((ConsumptionBean) obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
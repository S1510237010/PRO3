package at.fhhagenberg.mc.traffsim.roadnetwork.detector;

import com.google.common.base.Predicate;

import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public class VehiclePresenceDetection implements Predicate<Vehicle> {

	private double position;

	public VehiclePresenceDetection() {
		this.position = 0;
	}

	public VehiclePresenceDetection(double position) {
		this.position = position;
	}

	@Override
	public boolean apply(Vehicle vehicle) {
		if (vehicle == null) {
			return false;
		}

		return vehicle.getRearPosition() < position && vehicle.getFrontPosition() > position;
	}
}

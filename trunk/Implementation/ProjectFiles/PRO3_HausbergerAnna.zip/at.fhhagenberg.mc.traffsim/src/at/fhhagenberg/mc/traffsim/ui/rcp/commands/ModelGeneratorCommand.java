package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

import java.util.List;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import at.fhhagenberg.mc.traffsim.data.TraffsimDefaultData;
import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model.ModelGeneratorWizard;

/**
 * 
 * @author Manuel Lindorfer
 *
 */
public class ModelGeneratorCommand implements IHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		ModelGeneratorWizard modelWizard = new ModelGeneratorWizard();
		WizardDialog dialog = new WizardDialog(Display.getCurrent().getActiveShell(), modelWizard);
		int result = dialog.open();

		if (result == Dialog.CANCEL) {
			return null;
		}

		try {
			DataSerializer serializer = new DataSerializer();
			serializer.readConfiguration(modelWizard.getConfigFile());

			TraffSimConfiguration config = serializer.getConfiguration();
			
			List<AbstractBean> models = modelWizard.getModels();
			List<AbstractBean> controls = modelWizard.getControls();

			if (!config.getBeanConfigurationsMapping().containsKey(LongitudinalControlBean.class.getName())) {
				config.registerFilenameForClass(LongitudinalControlBean.class, TraffsimDefaultData.CONTROLS_XML_NAME);
				serializer.setConfiguration(config);
				serializer.writeConfiguration(config.getConfigurationFile());
			}
			
			if (models != null && !models.isEmpty()) {
				serializer.writeData(models);
			} else if (controls != null && !controls.isEmpty()) {
				serializer.writeData(controls);
			}
			MessageDialog messageDialog = new MessageDialog(Display.getCurrent().getActiveShell(), "Model generation completed", null,
					"The model configuration file has been updated successfully.", MessageDialog.INFORMATION, new String[] { "Ok" }, 0);
			messageDialog.open();
		} catch (Exception exc) {
			MessageDialog messageDialog = new MessageDialog(Display.getCurrent().getActiveShell(), "Model generation failed", null,
					"An error occurred while updating the model configuration file.", MessageDialog.ERROR, new String[] { "Ok" }, 0);
			messageDialog.open();
			Logger.logError("Something went wrong while serializing generated models.\n\n" + exc.getMessage());
		}

		return null;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isHandled() {
		return true;
	}

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// Not implemented
	}

	@Override
	public void dispose() {
		// Not implemented
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// Not implemented
	}
}
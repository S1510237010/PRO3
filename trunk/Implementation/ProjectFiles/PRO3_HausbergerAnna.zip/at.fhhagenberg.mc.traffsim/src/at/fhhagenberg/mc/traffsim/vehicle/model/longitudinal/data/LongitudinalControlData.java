package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

public class LongitudinalControlData {

	private String identifier;

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	@Override
	public String toString() {
		return identifier;
	}
}

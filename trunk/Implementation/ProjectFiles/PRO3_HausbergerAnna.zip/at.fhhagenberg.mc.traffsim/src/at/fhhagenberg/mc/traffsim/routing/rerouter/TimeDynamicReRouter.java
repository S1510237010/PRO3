package at.fhhagenberg.mc.traffsim.routing.rerouter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.Node;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.Route;
import at.fhhagenberg.mc.traffsim.routing.AbstractRouteService;
import at.fhhagenberg.mc.traffsim.routing.Congestion;
import at.fhhagenberg.mc.traffsim.routing.SimpleRouteResult;
import at.fhhagenberg.mc.traffsim.routing.TransientGraphCostsOverrider;
import at.fhhagenberg.mc.traffsim.routing.rerouter.footprint.TimeDynamicFootprintGenerator;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.vehicle.CommVehicle;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

public class TimeDynamicReRouter extends AbstractReRouter {
	public static final String REROUTER_NAME = "TimeDynamic";

	private class TimeDynamicCallable implements Callable<Object> {
		private static final long MAX_NODE_LOCK_LIFETIME_MS = 5 * 60 * 1000; // 5 minutes
		private List<Congestion> congestions = new ArrayList<>();
		private Map<Long, Pair<Congestion, Integer>> notHandled;
		private double timeThreshold;
		private double distanceThreshold;;
		private String sourceReRouter;

		public TimeDynamicCallable(Congestion con, Map<Long, Pair<Congestion, Integer>> notHandled, double timeThreshold, double distanceThreshold,
				String sourceReRouter) {
			this.congestions.add(con);
			this.notHandled = notHandled;
			this.timeThreshold = timeThreshold;
			this.distanceThreshold = distanceThreshold;
			this.sourceReRouter = sourceReRouter;
		}

		@Override
		public Object call() throws Exception {
			for (Congestion congestion : congestions) {
				// override graph
				TransientGraphCostsOverrider overrider = null;
				AbstractJunction congestedJunc = model.getNetwork().getJunctionByKey(congestion.getCongestedNode());
				if (congestedJunc == null) {
					Logger.logWarn("Could not find congested junction # " + congestion.getCongestionId());
					continue;
				}
				// find out farthest vehicles
				Map<Double, Vehicle> distanceToVehicleMap = new HashMap<>();
				for (Vehicle v : congestion.getVehicles()) {

					if (v == null) {
						continue;
					}

					long vid = v.getUniqueId();
					Date nextUpdateTime;
					nextUpdateTime = vehicleNextUpdate.get(vid);
					if (nextUpdateTime != null && nextUpdateTime.after(model.getCurrentSimTime())) {
						continue;
					}
					if (v == null || v.getRoadSegment() == null
							|| !RoutingUtil.routePasses(model.getObservationCenter().getRoute(v.getUniqueId()), congestedJunc, Integer.MAX_VALUE)) {
						continue;
					}
					double distance = model.getNetwork().getJunctionByKey(congestion.getCongestedNode()).getJunctionCenter()
							.distanceTo(v.getAbsolutePosition());
					distanceToVehicleMap.put(distance, v);
				}

				// sort distances descending (longest to shortest)
				ArrayList<Double> distances = new ArrayList<Double>(distanceToVehicleMap.keySet());
				Collections.sort(distances, new Comparator<Double>() {
					@Override
					public int compare(Double o1, Double o2) {
						return o2.compareTo(o1);
					}
				});

				// begin with longest distance to junction for rerouting
				long neededReroutings = congestion.getVehicles().size() - congestion.getNumAllowed();
				int successfulReroutings = 0;
				for (Double distance : distances) {
					if (successfulReroutings >= neededReroutings) {
						// enough reroutings
						break;
					}
					Vehicle v = distanceToVehicleMap.get(distance);

					try {
						// override nodes
						overrider = model.getRouteService().startDynamicOverride();
						List<AbstractJunction> unusableNodes = CollectionUtil.createArrayList(congestedJunc);
						if (forbiddenNodes.containsKey(v.getUniqueId())) {
							unusableNodes.addAll(forbiddenNodes.get(v.getUniqueId()).values());
						}
						for (AbstractJunction unusableNode : unusableNodes) {
							for (RoadSegment seg : unusableNode.getSegmentsIn()) {
								overrider.overrideCost((int) seg.getRoutingId(), Float.MAX_VALUE, seg.isOsmReverse());
							}
						}

						// calculate new route if commvehicle
						if (v.isRoutable()) {
							CommVehicle commV = (CommVehicle) v;
							SimpleRouteResult route = findRoute(commV, overrider);
							if (route != null && route.getRoutingIds().size() > 0) {
								IRoute newRoute = new Route(route.getRoutingIds());
								newRoute = RoutingUtil.updateInitialAndTargetRoadSegments(newRoute, model.getNetwork().getRoadSegmentsByRoutingId());

								if (assignNewRoute(commV, newRoute, timeThreshold, distanceThreshold, sourceReRouter)) {
									vehicleNextUpdate.put(commV.getUniqueId(),
											new Date(model.getCurrentSimTime().getTime() + commV.getDynamicRouteUpdateThreshold()));
									successfulReroutings++;
									congestion.getVehicles().remove(commV);
									if (avoidMultiReroutes) {
										addForbiddenNode(forbiddenNodes, commV.getUniqueId(), congestion.getPredictedDate(), congestedJunc);
									}
									dynamicallyRoutedVehicles.add(commV.getUniqueId());
								} else {
									// add small threshold of 5 seconds to avoid multiple tries to assign the same route, which does
									// obviously not work since assignNewRoute returned false
									vehicleNextUpdate.put(commV.getUniqueId(), new Date(model.getCurrentSimTime().getTime() + 5000));
								}
							}
						}
					} catch (Exception e) {
						Logger.logError(String.format("Could not handle congestion %d in node %d", congestion.getCongestionId(),
								congestion.getCongestedNode()), e);
						continue;
					} finally {
						// clear overridden graph
						model.getRouteService().finishDynamicOverrider(overrider);
					}
				}

				if (successfulReroutings < neededReroutings) {
					Pair<Congestion, Integer> cong;
					cong = notHandled.get(congestion.getCongestionId());
					if (cong == null) {
						cong = new MutablePair<Congestion, Integer>(congestion, 0);
					}
					cong.setValue(cong.getValue() + 1);
					notHandled.put(congestion.getCongestionId(), cong);
				}

			}
			return null;
		}

		private void addForbiddenNode(Map<Long, Map<Date, AbstractJunction>> forbiddenNodes, Long vehicleId, Date endTime,
				AbstractJunction congestedJunc) {
			if (!forbiddenNodes.containsKey(vehicleId)) {
				forbiddenNodes.put(vehicleId, new ConcurrentHashMap<>());
			}
			forbiddenNodes.get(vehicleId).put(endTime == null ? new Date(model.getCurrentSimTime().getTime() + MAX_NODE_LOCK_LIFETIME_MS) : endTime,
					congestedJunc);
		}

	}

	private TimeDynamicFootprintGenerator timedynamicFootprint;
	private List<ICongestionProvider> additionalCongestionProviders = new ArrayList<>();
	private double timeDynamicThreshold;
	private double distanceDynamicThreshold;
	private Map<Long, Pair<Congestion, Integer>> toRetry = new ConcurrentHashMap<>();

	/** List of nodes which are not to be used by the vehicle (vehicle unique id = key of this map, date is end date of lock) */
	protected Map<Long, Map<Date, AbstractJunction>> forbiddenNodes = new ConcurrentHashMap<>();
	protected Set<Long> dynamicallyRoutedVehicles = new HashSet<>();
	private LockedNodesCleaner lockedNodesCleaner;
	private boolean avoidMultiReroutes;

	public TimeDynamicReRouter(String name, long updateIntervalMillis, SimulationModel model, TimeDynamicFootprintGenerator generator,
			double timeDynamicThreshold, double distanceDynamicThreshold, boolean avoidMultiReroutes) {
		super(name, updateIntervalMillis, model);
		this.timedynamicFootprint = generator;
		model.getRouteService().setupDynamicGraphs(3);
		this.timeDynamicThreshold = timeDynamicThreshold;
		this.distanceDynamicThreshold = distanceDynamicThreshold;
		this.lockedNodesCleaner = new LockedNodesCleaner("TDyn Router Locked Nodes Cleaner " + model.getUniqueId(), 10000, forbiddenNodes, model);
		this.avoidMultiReroutes = avoidMultiReroutes;
	}

	/**
	 * This method must not be executed in parallel, since {@link AbstractRouteService#overrideDynamicSegmentHCost(long, float, boolean)}
	 * does not support multiple instance of a dynamic grpah
	 */
	@Override
	public void doSynchronizedWork() {
		if (!simulateReRouting) {
			List<Callable<Object>> tasks = new ArrayList<>();

			while (!timedynamicFootprint.getCongestions().isEmpty()) {
				Congestion congestion = timedynamicFootprint.getCongestions().poll();
				tasks.add(new TimeDynamicCallable(congestion, toRetry, timeDynamicThreshold, distanceDynamicThreshold, REROUTER_NAME));
			}
			executeTasks(exec, tasks);
			for (Pair<Congestion, Integer> cong : new ArrayList<>(toRetry.values())) {
				if (cong.getValue() > 3 || cong.getLeft().getPredictedDate().before(model.getCurrentSimTime())) {
					toRetry.remove(cong.getLeft().getCongestionId());
				} else {
					timedynamicFootprint.getCongestions().offer(cong.getLeft());
				}
			}
			// // additional rerouting for currently congested nodes
			performStandardReRoute(dynamicallyRoutedVehicles);
		}
	}

	private SimpleRouteResult findRoute(Vehicle v, TransientGraphCostsOverrider overrider) {
		Node startNode;
		if (v.isInJunction()) {
			startNode = v.getLaneSegment().getSinkLaneSegment().getRoadSegment().getEndNode();
		} else {
			RoadSegment rs = v.getRoadSegment();
			if (rs != null) {
				startNode = rs.getEndNode();
			} else {
				return null;
			}
		}
		return model.getRouteService().findRouteDynamic(startNode,
				model.getObservationCenter().getRoute(v.getUniqueId()).getTargetSegment().getEndNode(), overrider);
	}

	public void addCongestionProvider(ICongestionProvider prov) {
		this.additionalCongestionProviders.add(prov);
	}

	@Override
	protected List<ICongestionProvider> getStandardCongestionProviders() {
		return additionalCongestionProviders;
	}

	@Override
	protected String getReRouterName() {
		return REROUTER_NAME;
	}

	@Override
	public void dispose() {
		lockedNodesCleaner.stopAndDestroy();
		super.dispose();
	}

	@Override
	public String getCommReceiverName() {
		return REROUTER_NAME;
	}

}

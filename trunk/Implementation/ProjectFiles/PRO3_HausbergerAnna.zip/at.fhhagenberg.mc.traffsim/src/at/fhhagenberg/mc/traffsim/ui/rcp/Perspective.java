package at.fhhagenberg.mc.traffsim.ui.rcp;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.IPlaceholderFolderLayout;

import at.fhhagenberg.mc.traffsim.ui.rcp.views.DetailsView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.InfrastructureEditorView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.RoadStatisticsView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.SelectionStatisticsView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.SimulationView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.TrafficGeneratorEditorView;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.VehicleStatisticsView;

public class Perspective implements IPerspectiveFactory {
	private static final String TOP = "top";
	private static final String TOPRIGHT = TOP + "right";
	private static final String BOTTOM = "bottom";
	private static final String LOGFILEVIEW_ID = "de.anbos.eclipse.logviewer.plugin.LogViewer";

	public void createInitialLayout(IPageLayout layout) {
		layout.setEditorAreaVisible(false);
		layout.setFixed(false);
		IPlaceholderFolderLayout topHalf = layout.createPlaceholderFolder(TOP, IPageLayout.TOP, 0.35f, layout.getEditorArea());
		IPlaceholderFolderLayout topRight = layout.createPlaceholderFolder(TOPRIGHT, IPageLayout.RIGHT, 0.6f, TOP);
		IPlaceholderFolderLayout bottomHalf = layout.createPlaceholderFolder(BOTTOM, IPageLayout.BOTTOM, 0.65f, TOP);
		bottomHalf.addPlaceholder(VehicleStatisticsView.ID);
		bottomHalf.addPlaceholder(RoadStatisticsView.ID);
		bottomHalf.addPlaceholder(SelectionStatisticsView.ID);
		bottomHalf.addPlaceholder(LOGFILEVIEW_ID);
		topHalf.addPlaceholder(SimulationView.ID + ":*");
		topHalf.addPlaceholder(InfrastructureEditorView.ID);
		topRight.addPlaceholder(TrafficGeneratorEditorView.ID);
		topRight.addPlaceholder(DetailsView.ID + ":*");
	}
}

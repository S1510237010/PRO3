package at.fhhagenberg.mc.traffsim.util.types;

import java.util.concurrent.ThreadFactory;

/**
 * Custom implementation of @see ThreadFactory allowing for the instantiation of named threads.
 *
 * @author Christian Backfrieder
 */
public class NamedThreadFactory implements ThreadFactory {

	/** The name of the thread pool */
	private String baseName;

	/** The current number of threads created from the pool */
	private int num = 0;

	/**
	 * Creates new instance of thread factory with the given base name.<br>
	 * Each thread will have its unique number appended to the base name (e.g. "pool-baseName-2").
	 *
	 * @param baseName
	 *            the base name
	 */
	public NamedThreadFactory(String baseName) {
		this.baseName = baseName;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.util.concurrent.ThreadFactory#newThread(java.lang.Runnable)
	 */
	@Override
	public Thread newThread(Runnable r) {
		return new Thread(r, "pool-" + baseName + "-" + num++);
	}
}
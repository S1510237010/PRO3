package at.fhhagenberg.mc.traffsim.vehicle.model;

public class ModelProperty {
	private String name;
	private String propertySetterName;
	private Class<?> type;
	private double minValue;
	private double maxValue;

	// Flag to indicate whether this property can be configured using the
	// distribution configuration dialog
	private boolean canBeDistributed;

	// Defines the type of the parent object
	private Class<?> parentType;

	// Required for correct scaling of parameters
	private double conversionFactor;

	public ModelProperty(String name, String propertyName, Class<?> clazz) {
		this.name = name;
		this.propertySetterName = propertyName;
		this.type = clazz;
		this.minValue = Double.NEGATIVE_INFINITY;
		this.maxValue = Double.POSITIVE_INFINITY;
		this.canBeDistributed = true;
		this.parentType = null;
		this.conversionFactor = 1.;
	}

	public ModelProperty(String name, String setterName, Class<?> clazz, double minValue, double maxValue) {
		this.name = name;
		this.propertySetterName = setterName;
		this.type = clazz;
		this.minValue = minValue;
		this.maxValue = maxValue;
		this.canBeDistributed = true;
		this.parentType = null;
		this.conversionFactor = 1.0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSetter() {
		return propertySetterName;
	}

	public void setSetter(String setterName) {
		this.propertySetterName = setterName;
	}

	public Class<?> getType() {
		return type;
	}

	public void setType(Class<?> type) {
		this.type = type;
	}

	public double getMinValue() {
		return minValue;
	}

	public void setMinValue(double minValue) {
		this.minValue = minValue;
	}

	public double getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(double maxValue) {
		this.maxValue = maxValue;
	}

	public boolean getCanBeDistributed() {
		return canBeDistributed;
	}

	public void setCanBeDistributed(boolean canBeDistributed) {
		this.canBeDistributed = canBeDistributed;
	}

	public Class<?> getParentType() {
		return parentType;
	}

	public void setParentType(Class<?> parentClazz) {
		this.parentType = parentClazz;
	}

	public double getConversionFactor() {
		return conversionFactor;
	}

	public void setConversionFactor(double conversionFactor) {
		this.conversionFactor = conversionFactor;
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.views.performancemonitor;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.net.URI;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;
import org.hyperic.sigar.Sigar;

import at.fhhagenberg.mc.osm2po.libs.TraffSimLibsPlugin;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.statistics.CpuInfo;
import at.fhhagenberg.mc.traffsim.statistics.IThreadInfoListener;
import at.fhhagenberg.mc.util.OsUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class ThreadInfoCollector extends PauseableThread {

	private long[] allThreadIds;
	private Map<Long, DetailThreadInfo> infoCache = new ConcurrentHashMap<>();
	private IThreadUpdateListener listener;
	private double ownRuntime = 0;
	private List<IThreadInfoListener> patternListeners = new CopyOnWriteArrayList<>();
	private Sigar sigar;
	private double sum;
	private ThreadMXBean threadMXBean;

	public ThreadInfoCollector(String name, long delayInMillis) {
		super(name, delayInMillis);
	}

	public void addPatternListener(IThreadInfoListener listener) {
		this.patternListeners.add(listener);
	}

	@Override
	public void doWork() {
		long startTime = System.nanoTime();
		sum = 0;
		if (allThreadIds != null) {
			long[] oldThreadIds = new long[allThreadIds.length];
			System.arraycopy(allThreadIds, 0, oldThreadIds, 0, allThreadIds.length);
			allThreadIds = threadMXBean.getAllThreadIds();
			if (!Arrays.equals(oldThreadIds, allThreadIds) && listener != null) {
				listener.threadListUpdated(allThreadIds);
			}
		} else {
			allThreadIds = threadMXBean.getAllThreadIds();
		}

		for (Long id : allThreadIds) {
			DetailThreadInfo info;
			if (infoCache.containsKey(id)) {
				info = infoCache.get(id);
			} else {
				info = new DetailThreadInfo();
				infoCache.put(id, info);
			}
			info.setInfo(threadMXBean.getThreadInfo(id));
			double curCpuTime = threadMXBean.getThreadCpuTime(id) / 1E9;
			info.setCputime(curCpuTime);
			sum += curCpuTime;
		}
		for (IThreadInfoListener listener : patternListeners) {
			double patternSum = 0;
			for (DetailThreadInfo info : infoCache.values()) {
				if (info.getInfo() != null && info.getInfo().getThreadName().matches(listener.getPattern())) {
					patternSum += info.getCputime();
				}
			}
			listener.setCpuTime(patternSum);
		}

		if (listener != null) {
			listener.dataUpdated();
		}
		ownRuntime += (System.nanoTime() - startTime) / 1E9;
	}

	public CpuInfo getCpuInfo() {
		try {
			URL url = FileLocator.resolve(Platform.getBundle(TraffSimLibsPlugin.PLUGIN_ID).getResource("lib/io/hardware"));
			File ioPath = new File(new URI(StringUtil.ensureURICompatible(url.toString())));

			System.setProperty("java.library.path",
					System.getProperty("java.library.path") + OsUtil.getClassPathSeparator() + ioPath.getAbsolutePath());
			sigar = new Sigar();

			org.hyperic.sigar.CpuInfo info = sigar.getCpuInfoList()[0];
			return new CpuInfo(info.getModel(), info.getTotalCores(), info.getVendor(), info.getMhz());
		} catch (Exception e) {
			Logger.logError("unable to determine cpu info", e);
		}
		return null;
	}

	public double getCpuSum() {
		return sum;
	}

	public DetailThreadInfo getInfo(long id) {
		return infoCache.get(id);
	}

	/**
	 * @return time that is taken for determination of thread info
	 */
	public double getOwnRuntime() {
		return ownRuntime;
	}

	public int getThreadCount() {
		return allThreadIds.length;
	}

	@Override
	public void init() {
		threadMXBean = ManagementFactory.getThreadMXBean();
	}

	public void removePatternListener(IThreadInfoListener listener) {
		this.patternListeners.remove(listener);
	}

	public void resetThreadUpdateListener() {
		this.pause();
		this.listener = null;
	}

	public void setThreadUpdateListener(IThreadUpdateListener listener) {
		this.listener = listener;
		this.proceed();
	}

}
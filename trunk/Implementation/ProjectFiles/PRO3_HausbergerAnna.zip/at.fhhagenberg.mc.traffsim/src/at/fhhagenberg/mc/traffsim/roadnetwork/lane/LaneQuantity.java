package at.fhhagenberg.mc.traffsim.roadnetwork.lane;

import java.util.ArrayList;
import java.util.List;

import at.fhhagenberg.mc.traffsim.util.NumberUtil;

public class LaneQuantity {

	public List<Long> detectedVehicleIds = new ArrayList<>();
	public int vehicleCount;
	public int vehicleCountOutput;
	public double speedSum;
	public double meanSpeed;
	public double meanSpeedHarmonic;
	public double totalOccupationTime;
	public double occupancy;
	public double meanTimeGapHarmonic;
	public double sumInvV;
	public double sumInvQ;

	public LaneQuantity(){
		reset();
	}
	
	public void reset() {
		vehicleCount = 0;
		speedSum = 0;
		totalOccupationTime = 0;
		sumInvV = 0;
		sumInvQ = 0;
	}

	public void calcAverageForLane(double sampleInterval) {
		vehicleCountOutput = vehicleCount;
		meanSpeed = (vehicleCount == 0) ? 0 : speedSum / vehicleCount;
		occupancy = (NumberUtil.doubleEquals(totalOccupationTime, 0)) ? 0 : totalOccupationTime / sampleInterval;
		meanSpeedHarmonic = (vehicleCount == 0) ? 0 : 1.0 / (sumInvV / vehicleCount);
		meanTimeGapHarmonic = (vehicleCount == 0) ? 0 : sumInvQ / vehicleCount;
		reset();
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp;

import at.fhhagenberg.mc.traffsim.model.SimulationModel;

public interface IModelInputChangedListener {
	public void inputChanged(SimulationModel newModel);
}

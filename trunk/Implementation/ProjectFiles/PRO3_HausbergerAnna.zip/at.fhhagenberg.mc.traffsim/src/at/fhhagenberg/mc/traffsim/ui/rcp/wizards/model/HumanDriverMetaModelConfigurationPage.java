package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.model;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.LongitudinalModelInputDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.HumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.ui.dialogs.DistributionConfig;
import at.fhhagenberg.mc.traffsim.util.math.MathUtil;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelProperty;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.control.LongitudinalControls;
import at.fhhagenberg.mc.util.StringUtil;

public class HumanDriverMetaModelConfigurationPage extends LongitudinalControlConfigurationPage {

	private Combo comboDistanceNoise;
	private Combo comboVelocityDifferenceNoise;

	private Button btnIsAnticipative;
	private Button btnIsReactive;
	private Spinner spinnerNumAnticipatedVehicles;
	private Spinner spinnerReactionTime;

	private LongitudinalControls currentControl;

	protected HumanDriverMetaModelConfigurationPage(String pageName) {
		super(pageName);
	}

	@Override
	protected void addModelToList() {
		HumanDriverControlBean control = new HumanDriverControlBean();
		control.setIdentifier(txtIdentifier.getText());
		control.setLongitudinalModelIdentifier(comboLongitudinalModel.getText());

		if (comboDistanceNoise.getSelectionIndex() > 0) {
			control.setDistanceNoiseIdentifier(comboDistanceNoise.getText());
		}

		if (comboVelocityDifferenceNoise.getSelectionIndex() > 0) {
			control.setVelocityDifferenceNoiseIdentifier(comboVelocityDifferenceNoise.getText());
		}

		control.setNumConsideredVehicles(spinnerNumAnticipatedVehicles.getSelection());
		control.setIsReactive(btnIsReactive.getSelection());
		control.setIsAnticipative(btnIsAnticipative.getSelection());
		control.setReactionTime(spinnerReactionTime.getSelection() * 10);
		modelSet.add(control);
	}

	@Override
	protected void createColumns(TableViewer tv, String modelIdentifier) {
		TableViewerColumn colIdentifier = createTableViewerColumn("Identifier", 100);
		colIdentifier.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((HumanDriverControlBean) element).getIdentifier() + "";
			}
		});

		TableViewerColumn colLongitudinalModel = createTableViewerColumn("Underlying longitudinal model", 210);
		colLongitudinalModel.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((HumanDriverControlBean) element).getLongitudinalModelIdentifier() + "";
			}
		});

		TableViewerColumn colNumAnticipatedVehicles = createTableViewerColumn("Num. of anticipated vehicles", 180);
		colNumAnticipatedVehicles.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((HumanDriverControlBean) element).getNumConsideredVehicles() + "";
			}
		});

		TableViewerColumn colDelayExpected = createTableViewerColumn("Reaction time [s]", 130);
		colDelayExpected.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((HumanDriverControlBean) element).getReactionTime() / 1000.0 + "";
			}
		});

		TableViewerColumn colEnableDelays = createTableViewerColumn("Is reactive", 100);
		colEnableDelays.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((HumanDriverControlBean) element).getIsReactive() ? "\u2714" : "\u2718";
			}
		});

		TableViewerColumn colEnableTimelyAnticipation = createTableViewerColumn("Timely Anticipation", 120);
		colEnableTimelyAnticipation.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				return ((HumanDriverControlBean) element).getIsAnticipative() ? "\u2714" : "\u2718";
			}
		});

		TableViewerColumn colEnableEstimationErrorsS = createTableViewerColumn("Estimation error model [s]", 130);
		colEnableEstimationErrorsS.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				String identifier = ((HumanDriverControlBean) element).getDistanceNoiseIdentifier();
				return StringUtil.isNotNullOrEmpty(identifier) ? identifier : "\u2718";
			}
		});

		TableViewerColumn colEnableEstimationErrorsV = createTableViewerColumn("Estimation error model [dv]", 130);
		colEnableEstimationErrorsV.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				String identifier = ((HumanDriverControlBean) element).getVelocityDifferenceNoiseIdentifier();
				return StringUtil.isNotNullOrEmpty(identifier) ? identifier : "\u2718";
			}
		});
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);

		grpModelParameters.setVisible(true);

		Label lblNumAnticipatedVehicles = new Label(grpModelParameters, SWT.NONE);
		lblNumAnticipatedVehicles.setText("Num. of anticipated vehicles");
		lblNumAnticipatedVehicles.setToolTipText("Number of preceding vehicles the driver considers during his driving task.");

		spinnerNumAnticipatedVehicles = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerNumAnticipatedVehicles.setPageIncrement(1);
		spinnerNumAnticipatedVehicles.setIncrement(1);
		spinnerNumAnticipatedVehicles.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerNumAnticipatedVehicles.setMaximum(7);
		spinnerNumAnticipatedVehicles.setMinimum(1);
		spinnerNumAnticipatedVehicles.setSelection(3);
		spinnerNumAnticipatedVehicles.setDigits(0);

		Label lblDelayExpected = new Label(grpModelParameters, SWT.NONE);
		lblDelayExpected.setText("Reaction time T' [s]");
		lblDelayExpected.setToolTipText("Delay of driver actions in expected scenarios (car-following, approaching an intersection)");

		spinnerReactionTime = new Spinner(grpModelParameters, SWT.BORDER);
		spinnerReactionTime.setPageIncrement(10);
		spinnerReactionTime.setIncrement(1);
		spinnerReactionTime.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		spinnerReactionTime.setMaximum(400);
		spinnerReactionTime.setMinimum(0);
		spinnerReactionTime.setSelection(60);
		spinnerReactionTime.setDigits(2);

		btnIsReactive = new Button(grpModelParameters, SWT.CHECK);
		btnIsReactive.setText("Consider reaction time");
		btnIsReactive.setLayoutData(new GridData(SWT.LEFT, SWT.BOTTOM, false, false, 2, 1));

		btnIsAnticipative = new Button(grpModelParameters, SWT.CHECK);
		btnIsAnticipative.setText("Consider timely anticipation");
		btnIsAnticipative.setLayoutData(new GridData(SWT.LEFT, SWT.BOTTOM, false, false, 2, 1));

		Label lblDistanceNoise = new Label(grpModelParameters, SWT.NONE);
		lblDistanceNoise.setText("Distance estimation noise model");
		lblDistanceNoise.setToolTipText("Defines the noise model used for modeling estimation errors with respect to distances");

		comboDistanceNoise = new Combo(grpModelParameters, SWT.READ_ONLY);
		comboDistanceNoise.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblVelocityDifferenceNoise = new Label(grpModelParameters, SWT.NONE);
		lblVelocityDifferenceNoise.setText("Speed diff. estimation noise model");
		lblVelocityDifferenceNoise
				.setToolTipText("Defines the noise model used for modeling estimation errors with respect to speed differences");

		comboVelocityDifferenceNoise = new Combo(grpModelParameters, SWT.READ_ONLY);
		comboVelocityDifferenceNoise.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		// Model property initialization
		ModelProperty distanceNoise = new ModelProperty("Distance noise", "setDistanceNoiseIdentifier", String.class);
		distanceNoise.setCanBeDistributed(false);
		ModelProperty velocityDifferenceNoise = new ModelProperty("Velocity difference noise", "setVelocityDifferenceNoiseIdentifier",
				String.class);
		velocityDifferenceNoise.setCanBeDistributed(false);
		ModelProperty longitudinalModel = new ModelProperty("Underlying longitudinal model", "setLongitudinalModelIdentifier",
				String.class);
		longitudinalModel.setCanBeDistributed(false);

		ModelProperty numAnticipatedVehicles = new ModelProperty("Num. of anticipated vehicles", "setNumConsideredVehicles", Integer.TYPE,
				1, 10);
		ModelProperty reactionTime = new ModelProperty("Reaction time [s]", "setReactionTime", Double.TYPE, 0, 4);
		reactionTime.setConversionFactor(1000);

		modelProperties.add(numAnticipatedVehicles);
		modelProperties.add(reactionTime);
		modelProperties.add(distanceNoise);
		modelProperties.add(velocityDifferenceNoise);
		modelProperties.add(longitudinalModel);

		controlMapping.put(numAnticipatedVehicles, spinnerNumAnticipatedVehicles);
		controlMapping.put(reactionTime, spinnerReactionTime);
		controlMapping.put(distanceNoise, comboDistanceNoise);
		controlMapping.put(velocityDifferenceNoise, comboVelocityDifferenceNoise);
		controlMapping.put(longitudinalModel, comboLongitudinalModel);
	}

	@Override
	protected void generateModels(int numModels, HashMap<ModelProperty, DistributionConfig> propertyConfiguration) {
		try {
			Class<?> cls = HumanDriverControlBean.class;

			long generationTime = new Date().getTime();

			for (int i = 0; i < numModels; i++) {
				Object obj = cls.newInstance();

				cls.getMethod("setIdentifier", String.class).invoke(obj,
						currentControl.getShortName() + "_gen_" + generationTime + "-" + (i + 1));

				for (ModelProperty property : propertyConfiguration.keySet()) {
					Object currentObject = null;
					Class<?> currentClass = null;

					currentObject = obj;
					currentClass = cls;

					Method setter = currentClass.getMethod(property.getSetter(), property.getType());
					DistributionConfig config = propertyConfiguration.get(property);

					if (config.getDistribution() != null && property.getCanBeDistributed()) {
						double sampledValue = MathUtil.getSample(config.getDistribution(),
								config.getConsiderMinimum() ? config.getMinimum() : Double.NEGATIVE_INFINITY,
								config.getConsiderMaximum() ? config.getMaximum() : Double.POSITIVE_INFINITY);

						if (property.getType() == Integer.TYPE) {
							setter.invoke(currentObject, (int) (sampledValue * property.getConversionFactor()));
						} else {
							setter.invoke(currentObject, sampledValue * property.getConversionFactor());
						}
					} else {
						// Get the spinner used for parameterizing this property
						Control control = controlMapping.get(property);

						if (control instanceof Spinner) {
							Spinner spinner = (Spinner) control;

							if (property.getType() == Integer.TYPE) {
								setter.invoke(currentObject, (int) (spinner.getSelection() / Math.pow(10, spinner.getDigits())
										* property.getConversionFactor()));
							} else {
								setter.invoke(currentObject,
										spinner.getSelection() / Math.pow(10, spinner.getDigits()) * property.getConversionFactor());
							}
						} else if (control instanceof Button) {
							Button button = (Button) control;
							setter.invoke(currentObject, button.getSelection());
						} else if (control instanceof Text) {
							Text text = (Text) control;
							setter.invoke(currentObject, text.getText());
						} else if (control instanceof Combo) {
							Combo combo = (Combo) control;
							setter.invoke(currentObject, combo.getText());
						}
					}
				}

				// Set boolean properties manually
				cls.getMethod("setIsReactive", Boolean.TYPE).invoke(obj, btnIsReactive.getSelection());
				cls.getMethod("setIsAnticipative", Boolean.TYPE).invoke(obj, btnIsAnticipative.getSelection());
				modelSet.add((HumanDriverControlBean) obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void initializeModels() {
		try {
			comboLongitudinalModel.removeAll();
			comboDistanceNoise.removeAll();
			comboVelocityDifferenceNoise.removeAll();

			DataSerializer ser = new DataSerializer();
			File configFile = ((ModelSelectionPage) ((ModelGeneratorWizard) getWizard()).getPage(ModelGeneratorWizard.PAGE_MODEL_SELECTION))
					.getConfigFile();
			ser.readConfiguration(configFile);

			List<? extends AbstractBean> beans = ser.readData(ModelBean.class);

			for (AbstractBean abstractBean : beans) {
				if (abstractBean instanceof NoiseDataBean) {
					comboDistanceNoise.add(((NoiseDataBean) abstractBean).getModelIdentifier());
					comboVelocityDifferenceNoise.add(((NoiseDataBean) abstractBean).getModelIdentifier());
				} else if (abstractBean instanceof LongitudinalModelInputDataBean) {
					comboLongitudinalModel.add(((LongitudinalModelInputDataBean) abstractBean).getModelIdentifier());
				}
			}

			if (comboDistanceNoise.getItemCount() > 0) {
				comboDistanceNoise.add("NONE", 0);
				comboVelocityDifferenceNoise.add("NONE", 0);

				comboDistanceNoise.setEnabled(true);
				comboVelocityDifferenceNoise.setEnabled(true);

				comboDistanceNoise.select(0);
				comboVelocityDifferenceNoise.select(0);
			} else {
				comboDistanceNoise.setEnabled(false);
				comboVelocityDifferenceNoise.setEnabled(false);
			}

			if (comboLongitudinalModel.getItemCount() > 0) {
				comboLongitudinalModel.setEnabled(true);
				comboLongitudinalModel.select(0);
				lblModelWarning.setVisible(false);
			} else {
				comboLongitudinalModel.setEnabled(false);
				lblModelWarning.setVisible(true);
			}

			validatePage();
		} catch (Exception exc) {
			setErrorMessage("Controls couldn't be loaded. Ensure that the configuration file is not corrupt.");
			comboDistanceNoise.setEnabled(false);
			comboVelocityDifferenceNoise.setEnabled(false);
			comboLongitudinalModel.setEnabled(false);
			return;
		}
	}

	@Override
	protected boolean isAddPossible() {
		if (comboLongitudinalModel == null) {
			return false;
		}

		return comboLongitudinalModel.getItemCount() > 0;
	}

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);

		if (visible) {
			initializeModels();
			currentControl = LongitudinalControls.valueOfLabel(((ModelGeneratorWizard) getWizard()).getPreviousModelIdentifier());
			setDescription(String.format("Configure '%s' control parameters", currentControl.toString()));
		}
	}
}

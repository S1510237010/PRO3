package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.BatteryDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionCarDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ElectricEngineDataBean;

/**
 * This class manages a vehicle car and its consumption.
 *
 * @author Anna
 *
 */
public class ElectricConsumptionModel {

	/**
	 * Enigine model of the electric vehicle.
	 */
	private ElectricEngineModel mEngine;
	/**
	 * Car model of the electric vehicle.
	 */
	private CarModel mCar;
	/**
	 * FuelType == electric
	 */
	private FuelType mType;

	/**
	 * The model's unique identifier
	 */
	private String mIdentifier;

	public ElectricConsumptionModel(String _identifier, ConsumptionCarDataBean _carInput, ElectricEngineDataBean _engineInput,
			BatteryDataBean _batteryInput) {
		mIdentifier = _identifier;
		mCar = new CarModel(_carInput);
		mEngine = new ElectricEngineModel(_engineInput, _batteryInput);
		mType = FuelType.ELECTRIC;
	}

	/**
	 * This method calls all necessary methods in order to calculate the consumption of the vehicle with a certain speed, acceleration, on a
	 * certain ground with a slope.
	 *
	 * @param _v
	 *            speed of vehicle
	 * @param _acc
	 *            acceleration of vehicle
	 * @param _slope
	 *            angle of ground
	 * @param _factor
	 *            factor of how much percent of the needed power is going to be produced by the electric motor
	 * @return the needed amperage
	 */
	public double getCurrentConsumption(double _v, double _acc, double _slope, double _factor) {
		double force = mCar.getForceMech(_v, _acc, _slope) * _factor;
		double power = force * _v;

		double consumption = mEngine.getConsumption(power, _v, _acc <= 0);

		// System.out.println("Consumption: " + consumption);
		return consumption;
	}

	public FuelType getType() {
		return mType;
	}

	public String getIdentifier() {
		return mIdentifier;
	}

}

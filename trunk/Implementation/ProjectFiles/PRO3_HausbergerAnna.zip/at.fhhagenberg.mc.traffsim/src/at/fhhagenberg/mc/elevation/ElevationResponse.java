package at.fhhagenberg.mc.elevation;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

/**
 * Helping class required for correctly parsing data returned from the
 * MapQuest-API.
 *
 * @author Christian Backfrieder
 */
@XStreamAlias("elevationResponse")
public class ElevationResponse {

	/**
	 * Helper class containing copyright information
	 */
	@XStreamAlias("copyright")
	protected class Copyright {

		/** URL, image text and copyright text */
		String imageUrl, imageAltText, text;

		/**
		 * Gets the alternative image text.
		 *
		 * @return the alternative image text
		 */
		public String getImageAltText() {
			return imageAltText;
		}

		/**
		 * Gets the image URL.
		 *
		 * @return the image URL
		 */
		public String getImageUrl() {
			return imageUrl;
		}

		/**
		 * Gets the copyright text.
		 *
		 * @return the copyright text
		 */
		public String getText() {
			return text;
		}

		/**
		 * Sets the alternative image text
		 *
		 * @param imageAltText
		 *            the new alternative image text
		 */
		public void setImageAltText(String imageAltText) {
			this.imageAltText = imageAltText;
		}

		/**
		 * Sets the image URL.
		 *
		 * @param imageUrl
		 *            the new image URL
		 */
		public void setImageUrl(String imageUrl) {
			this.imageUrl = imageUrl;
		}

		/**
		 * Sets the copyright text.
		 *
		 * @param text
		 *            the new copyright text
		 */
		public void setText(String text) {
			this.text = text;
		}
	}

	/**
	 * Helper class containing distance and height information
	 */
	@XStreamAlias("distanceHeight")
	protected class DistanceHeight {

		/** Distance */
		private double distance;

		/** Height */
		private double height;

		/**
		 * Gets the distance in meters.
		 *
		 * @return the distance in meters
		 */
		public double getDistance() {
			return distance;
		}

		/**
		 * Gets the altitude in meters.
		 *
		 * @return the altitude in meters.
		 */
		public double getHeight() {
			return height;
		}

		/**
		 * Sets the distance.
		 *
		 * @param distance
		 *            the new distance in meters
		 */
		public void setDistance(double distance) {
			this.distance = distance;
		}

		/**
		 * Sets the altitude.
		 *
		 * @param height
		 *            the new altitude in meters
		 */
		public void setHeight(double height) {
			this.height = height;
		}
	}

	/**
	 * Helper class containing copyright information, additional response
	 * messages and a response status code
	 */
	protected class Info {

		/** Copyright information */
		private Copyright copyright;

		/** Response message */
		@XStreamOmitField
		private List<String> messages;

		/** The response status code */
		private int statusCode;

		/**
		 * Gets the copyright information.
		 *
		 * @return the copyright information
		 */
		public Copyright getCopyright() {
			return copyright;
		}

		/**
		 * Gets the additional response messages.
		 *
		 * @return additional response messages
		 */
		public List<String> getMessages() {
			return messages;
		}

		/**
		 * Gets the response status code.
		 *
		 * @return the response status code
		 */
		public int getStatusCode() {
			return statusCode;
		}

		/**
		 * Sets the copyright information.
		 *
		 * @param copyright
		 *            the new copyright information
		 */
		public void setCopyright(Copyright copyright) {
			this.copyright = copyright;
		}

		/**
		 * Sets the additional response messages.
		 *
		 * @param messages
		 *            the new response messages
		 */
		public void setMessages(List<String> messages) {
			this.messages = messages;
		}

		/**
		 * Sets the response status code.
		 *
		 * @param statusCode
		 *            the new response status code
		 */
		public void setStatusCode(int statusCode) {
			this.statusCode = statusCode;
		}
	}

	/**
	 * Helper class encapsulating the MapQuest response
	 */
	protected class InfoClass {

		/** The response information */
		private Info info;

		/**
		 * Gets the response information.
		 *
		 * @return the information
		 */
		public Info getInfo() {
			return info;
		}

		/**
		 * Sets the response information.
		 *
		 * @param info
		 *            the new information
		 */
		public void setInfo(Info info) {
			this.info = info;
		}
	}

	/**
	 * Helper class containing a latitude-longitude pair
	 */
	@XStreamAlias("LatLng")
	protected class LatLng {

		/** The latitude value */
		private double lat;

		/** The longitude value */
		private double lng;

		/**
		 * Gets the latitude's value.
		 *
		 * @return the latitude
		 */
		public double getLat() {
			return lat;
		}

		/**
		 * Gets the longitude's value.
		 *
		 * @return the longitude
		 */
		public double getLng() {
			return lng;
		}

		/**
		 * Sets the latitude's value.
		 *
		 * @param lat
		 *            the new latitude
		 */
		public void setLat(double lat) {
			this.lat = lat;
		}

		/**
		 * Sets the longitude's value.
		 *
		 * @param lng
		 *            the new longitude
		 */
		public void setLng(double lng) {
			this.lng = lng;
		}
	}

	/**
	 * List of distance and height information sets being part of the response
	 */
	@XStreamAlias("distanceHeightCollection")
	private List<DistanceHeight> distanceHeightCollection;

	/** The actual response information */
	@XStreamOmitField
	private Info info;

	/** List of latitude-longitude pairs being part of the response */
	private List<LatLng> shapePoints;

	/**
	 * Gets the current distance and height information returned by the
	 * response.
	 *
	 * @return the actual distance an height information
	 */
	public List<DistanceHeight> getDistanceHeightCollection() {
		return distanceHeightCollection;
	}

	/**
	 * Gets the current response information.
	 *
	 * @return the actual response information
	 */
	public Info getInfo() {
		return info;
	}

	/**
	 * Gets current list of latitude-longitude pairs for mapping the requested
	 * altitudes.
	 *
	 * @return the actual list of latitude-longitude pairs
	 */
	public List<LatLng> getShapePoints() {
		return shapePoints;
	}

	/**
	 * Sets the current distance and height information.
	 *
	 * @param distanceHeightCollection
	 *            the new distance and height information
	 */
	public void setDistanceHeightCollection(List<DistanceHeight> distanceHeightCollection) {
		this.distanceHeightCollection = distanceHeightCollection;
	}

	/**
	 * Sets the current response information.
	 *
	 * @param info
	 *            the new information
	 */
	public void setInfo(Info info) {
		this.info = info;
	}

	/**
	 * Sets the current list of latitude-longitude pairs
	 *
	 * @param shapePoints
	 *            the new list of latitude-longitude pairs
	 */
	public void setShapePoints(List<LatLng> shapePoints) {
		this.shapePoints = shapePoints;
	}
}
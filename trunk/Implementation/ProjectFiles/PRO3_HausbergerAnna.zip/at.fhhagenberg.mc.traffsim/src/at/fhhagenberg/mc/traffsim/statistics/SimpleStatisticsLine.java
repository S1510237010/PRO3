package at.fhhagenberg.mc.traffsim.statistics;

public class SimpleStatisticsLine {
	String file;
	double timeSum;
	double timeAvg;
	double fuelSum;
	double fuelAvg;
	double carbonEmissionsSum;
	double carbonEmissionsAvg;
	double distSum;
	double distAvg;
	int numVehicles;
	double speedAvg;
	
}

package at.fhhagenberg.mc.traffsim.model;

public interface IVehicleStatisticsChangedListener {
	public void vehicleAdded(long vehicleId);

	public void vehicleDataChanged(long vehicleId);

}

package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.junction;

import org.eclipse.jface.wizard.Wizard;

import at.fhhagenberg.mc.traffsim.ui.rcp.custom.TrafficLightConfigurationParameters;
import at.fhhagenberg.mc.traffsim.ui.rcp.wizards.junction.TrafficLightGeneratorParameterPage.TrafficLightGenerationParameters;

public class TrafficLightGeneratorWizard extends Wizard {

	private TrafficLightGeneratorParameterPage trafficLightGeneratorParameterPage;
	private TrafficLightGenerationParameters generationParameters;
	private TrafficLightConfigurationParameters trafficLightConfigurationParameters;
	private boolean performRemove;

	public TrafficLightGeneratorWizard() {
		setWindowTitle("Traffic Light Generation");
		trafficLightGeneratorParameterPage = new TrafficLightGeneratorParameterPage("Traffic Light Generation");
	}

	@Override
	public void addPages() {
		addPage(trafficLightGeneratorParameterPage);
	}

	@Override
	public boolean canFinish() {
		return trafficLightGeneratorParameterPage.isPageComplete();
	}

	@Override
	public boolean performFinish() {
		trafficLightGeneratorParameterPage.validatePage();
		generationParameters = trafficLightGeneratorParameterPage.getGenerationParameters();
		trafficLightConfigurationParameters = trafficLightGeneratorParameterPage.getTrafficLightConfigurationParameters();
		performRemove = trafficLightGeneratorParameterPage.performRemove();
		return true;
	}

	public TrafficLightGenerationParameters getGenerationParameters() {
		return generationParameters;
	}

	public TrafficLightConfigurationParameters getTrafficLightConfigurationParameters() {
		return trafficLightConfigurationParameters;
	}

	public boolean performRemove() {
		return performRemove;
	}
}
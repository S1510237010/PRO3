package at.fhhagenberg.mc.elevation;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.util.CoordinateUtil;
import at.fhhagenberg.mc.traffsim.util.NumberUtil;

/**
 * This class is provides the functionality to retrieve altitude information for
 * a specific location or a set of locations via the MapQuest-API
 * (http://open.mapquestapi.com/elevation/v1/).
 *
 * @author Christian Backfrieder
 */
public class AltitudeService {

	/**
	 * Helper class providing parsing functionality for altitude data retrieved
	 * from the MapQuest-API.
	 */
	private class ElevationContentHandler implements ContentHandler {

		/** Constants to distinguish between message and height data */
		private static final String HEIGHT_ELEMENT = "height";
		private static final String MESSAGE_ELEMENT = "message";

		/** The current response message being parsed */
		private String current;

		/** A list of parsed altitude values */
		private List<Double> heights = new ArrayList<>();

		/** A list of messages retrieved from the MapQuest-API */
		private List<String> messages = new ArrayList<>();

		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			current = new String(ch, start, length);
		}

		@Override
		public void endDocument() throws SAXException {
		}

		@Override
		public void endElement(String uri, String localName, String qName) throws SAXException {
			if (localName.equals(HEIGHT_ELEMENT)) {
				heights.add(Double.parseDouble(current));
			} else if (localName.equals(MESSAGE_ELEMENT)) {
				messages.add(current);
			}
		}

		@Override
		public void endPrefixMapping(String prefix) throws SAXException {
		}

		@Override
		public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
		}

		@Override
		public void processingInstruction(String target, String data) throws SAXException {
		}

		@Override
		public void setDocumentLocator(Locator locator) {
		}

		@Override
		public void skippedEntity(String name) throws SAXException {
		}

		@Override
		public void startDocument() throws SAXException {
		}

		@Override
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		}

		@Override
		public void startPrefixMapping(String prefix, String uri) throws SAXException {
		}
	}

	/** The MapQuest API key */
	private static final String MAPQUEST_KEY = "qaeWD1d1QfWGKXrbLE0KxGaD6dud5gFJ";

	/** The URL for retrieving altitude information */
	private static final String MAPQUEST_URL = "http://open.mapquestapi.com/elevation/v1/profile?key=" + MAPQUEST_KEY
			+ "&outFormat=xml&outShapeFormat=none&useFilter=true&&latLngCollection=";

	/**
	 * Constant identifying the max. number of altitude values per API request
	 */
	private static final int MAX_ITEMS_PER_REQUEST = 30;

	/**
	 * Map containing a mapping of locations and their corresponding altitude
	 * values
	 */
	private HashMap<Location, Double> heightCache = new HashMap<>();

	/**
	 * Gets the altitude (in meters) for the given {@link Location}.
	 *
	 * @param loc
	 *            the location of interest
	 * @return the altitude (in meters) for the given {@link Location}
	 */
	public double getAltitude(Location loc) {
		ArrayList<Location> locs = new ArrayList<>();
		locs.add(loc);
		return getAltitudes(locs, new NullProgressMonitor()).get(0);
	}

	/**
	 * Gets the altitude (in meters) for the given set of {@link Location}.
	 *
	 * @param locations
	 *            the list of relevant locations
	 * @param monitor
	 *            a monitor entity for progress monitoring
	 * @return a list of altitudes (in meters) for the given set of
	 *         {@link Location}
	 */
	public List<Double> getAltitudes(List<? extends Location> locations, IProgressMonitor monitor) {
		XStream xstream = new XStream(new DomDriver());
		xstream.processAnnotations(ElevationResponse.class);

		List<Location> processedLocations = new ArrayList<>();

		StringBuffer locStrBuf = new StringBuffer();
		int itemsInStrBuf = 0;

		for (int i = 0; i < locations.size(); i++) {
			monitor.subTask("Loading altitudes (" + i + "/" + locations.size() + ") ...");

			if (itemsInStrBuf >= MAX_ITEMS_PER_REQUEST || i == locations.size() - 1) {
				try {
					String locStr = locStrBuf.substring(0, locStrBuf.length() - 1);
					URL url = new URL(MAPQUEST_URL + locStr);
					XMLReader reader = XMLReaderFactory.createXMLReader();

					ElevationContentHandler ch = new ElevationContentHandler();
					reader.setContentHandler(ch);
					reader.parse(new InputSource(url.openStream()));

					for (int j = 0; j < ch.heights.size(); j++) {
						heightCache.put(processedLocations.get(j), ch.heights.get(j));
					}
				} catch (IOException e) {
					Logger.logError("Could not determine altitude for coordinates ", e);
				} catch (Exception e) {
					e.printStackTrace();
				}

				processedLocations = new ArrayList<>();
				itemsInStrBuf = 0;
				locStrBuf = new StringBuffer();
			}

			Location loc = locations.get(i);

			if (loc == null) {
				Logger.logWarn("Received null location at index " + i);
				continue;
			}

			if (!heightCache.containsKey(loc)) {
				Location wgs84 = CoordinateUtil.toWGS84Coordinate(loc);
				locStrBuf.append(NumberUtil.roundTo(wgs84.y, 6));
				locStrBuf.append(",");
				locStrBuf.append(NumberUtil.roundTo(wgs84.x, 6));
				locStrBuf.append(",");
				processedLocations.add(loc);
				itemsInStrBuf++;
			}
		}

		List<Double> result = new ArrayList<>();

		for (Location loc : locations) {
			if (loc != null && heightCache.containsKey(loc)) {
				result.add(heightCache.get(loc));
			} else {
				result.add(0d);
			}
		}

		if (result.size() != locations.size()) {
			Logger.logError("Could not find all altitudes!");
			return null;
		}

		return result;
	}
}
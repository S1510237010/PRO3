package at.fhhagenberg.mc.traffsim.ui.rcp.commands;

public class ShowAlwaysEnabledViewCommand extends ShowViewCommand {

	@Override
	public boolean isEnabled() {
		return true;
	}

}

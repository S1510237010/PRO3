package at.fhhagenberg.mc.traffsim.ui.osm;

public enum TileType {
	OSMDE("OSM Map"), BING_MAP("Bing Map"), BING_SAT("Satellite"), BING_HYBRID("Hybrid"), STAMEN_BLACKWHITE("Black/White");

	private final String text;

	private TileType(final String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}

	public static TileType fromString(String text) {
		if (text != null) {
			for (TileType b : TileType.values()) {
				if (text.equalsIgnoreCase(b.text)) {
					return b;
				}
			}
		}
		return null;
	}

	public long[] getScales() {
		switch (this) {
		case BING_HYBRID:
		case BING_SAT:
			return OSMZoom.SCALES_BING_SAT;
		case BING_MAP:
			return OSMZoom.SCALES_BING;
		case OSMDE:
		case STAMEN_BLACKWHITE:
			return OSMZoom.SCALES_OSM;
		}
		return new long[] { 0 };
	}
}

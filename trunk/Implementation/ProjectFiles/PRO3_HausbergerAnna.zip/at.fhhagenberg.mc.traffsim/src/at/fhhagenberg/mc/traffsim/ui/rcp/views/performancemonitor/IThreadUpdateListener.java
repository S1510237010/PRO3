package at.fhhagenberg.mc.traffsim.ui.rcp.views.performancemonitor;

public interface IThreadUpdateListener {
	public void threadListUpdated(long[] newList);

	public void dataUpdated();
}

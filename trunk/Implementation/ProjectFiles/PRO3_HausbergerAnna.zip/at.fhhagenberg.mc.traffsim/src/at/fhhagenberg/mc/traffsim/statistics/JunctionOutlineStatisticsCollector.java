package at.fhhagenberg.mc.traffsim.statistics;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLCell;
import com.jmatio.types.MLChar;
import com.jmatio.types.MLDouble;
import com.jmatio.types.MLInt64;

import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.StringUtil;

/**
 * Outline statistics collector used to obtain overall throughput (num. vehicles) and waiting time for each intersection on a per-approach
 * basis.
 *
 * @author Manuel Lindorfer
 *
 */
public class JunctionOutlineStatisticsCollector extends BaseStatisticsCollector implements IConvertableStatisticsCollector {

	private static final String JUNCTION_STATISTICS_SUFFIX = ".mat";
	private static final String JUNCTION_VAR_PREFIX = "junction_outline_";

	public JunctionOutlineStatisticsCollector(String name, SimulationModel model, long recordIntervalMillis) {
		super(name, recordIntervalMillis, false);
		this.model = model;
		if (recordIntervalMillis <= 0) {
			stopAndDestroy();
		} else {
			startPaused();
		}
	}

	@Override
	public IStatus convertStatistics(File outputFolder, String date, boolean clearCache, IProgressMonitor monitor, boolean crashDetected,
			boolean deadLockDetected) throws IOException {
		monitor.subTask("Writing junction statistics");

		List<AbstractJunction> junctions = model.getNetwork().getJunctions();
		List<MLArray> matFileData = new ArrayList<>();

		for (AbstractJunction junction : junctions) {
			String varname = getJunctionVarName(junction.getId(), null);
			String waitingTimesVarName = getJunctionVarName(junction.getId(), "_waiting_times");

			List<JunctionApproach> approaches = junction.getApproaches();

			if (monitor.isCanceled()) {
				return Status.CANCEL_STATUS;
			}

			MLCell jStats = new MLCell(varname, new int[] { approaches.size() + 1, 3 });
			int index = 0;
			jStats.set(new MLChar("", "Approach"), 0, index++);
			jStats.set(new MLChar("", "Throughput [veh]"), 0, index++);
			jStats.set(new MLChar("", "Total Waiting Time [s]"), 0, index++);

			int i = 1;

			for (JunctionApproach approach : approaches) {
				index = 0;
				jStats.set(new MLInt64("", new long[] { approach.getId() }, 1), i, index++);
				jStats.set(new MLDouble("", new double[] { approach.getQueueMonitor().getCountOutflow(model.getSimRuntimeMilliseconds()) }, 1), i,
						index++);
				jStats.set(new MLDouble("", new double[] { approach.getQueueMonitor().getTotalWaitingTime() }, 1), i, index++);
				i++;
			}

			// Only add if data has been recorded actually
			if (i > 1) {
				matFileData.add(jStats);
			}

			if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS)
					&& PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_INDIVIDUAL_WAITING_TIMES)) {
				Map<Long, Double> waitingTimes = junction.getIndividualWaitingTimes();

				if (waitingTimes.size() > 0) {
					MLCell wtStats = new MLCell(waitingTimesVarName, new int[] { waitingTimes.size() + 1, 2 });
					index = 0;
					wtStats.set(new MLChar("", "Vehicle"), 0, index++);
					wtStats.set(new MLChar("", "Waiting Time [s]"), 0, index++);

					i = 1;

					for (Long vehicleId : waitingTimes.keySet()) {
						index = 0;
						wtStats.set(new MLInt64("", new long[] { vehicleId }, 1), i, index++);
						wtStats.set(new MLDouble("", new double[] { waitingTimes.get(vehicleId) }, 1), i, index++);
						i++;
					}

					matFileData.add(wtStats);
				}
			}
		}

		File matFile = getStandardMatFile(outputFolder, date, crashDetected ? String.format("-%s%s", CRASH_TAG, JUNCTION_STATISTICS_SUFFIX)
				: deadLockDetected ? String.format("-%s%s", DEADLOCK_TAG, JUNCTION_STATISTICS_SUFFIX) : JUNCTION_STATISTICS_SUFFIX);

		try {
			monitor.subTask("Writing to Junction Outline Statistics MAT file");
			new MatFileWriter(matFile, matFileData);
		} catch (IOException e) {
			String msg = "Cannot write to Junction Outline Statistics MAT file '" + matFile.getName() + "'";
			Logger.logError(msg, e);
			return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, msg);
		}

		return Status.OK_STATUS;
	}

	private String getJunctionVarName(long junctionId, String postFix) {
		if (StringUtil.isNotNullOrEmpty(postFix)) {
			return String.format("%s%04d%s", JUNCTION_VAR_PREFIX, junctionId, postFix);
		}

		return String.format("%s%04d", JUNCTION_VAR_PREFIX, junctionId);
	}

	@Override
	protected String getStatisticsFilePrefix() {
		return "junction_outline_statistics_";
	}

}

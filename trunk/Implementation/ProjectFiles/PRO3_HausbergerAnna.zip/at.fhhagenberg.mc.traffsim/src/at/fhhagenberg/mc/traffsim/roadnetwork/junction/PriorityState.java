package at.fhhagenberg.mc.traffsim.roadnetwork.junction;

public class PriorityState {

	public static final int STOP_SIGN = -100;
	private static final int STOP_REQUIRED_THRESHOLD = -100;

	public static final int GIVE_WAY_SIGN = -98;
	public static final int NONE = 0;
	public static final int PRIORITY_ROAD = 99;

	public static final int NOT_AVAILABLE = Integer.MIN_VALUE;

	public static final int TRAFFIC_LIGHTS_GREEN = 100;
	public static final int TRAFFIC_LIGHTS_OOO = NONE;
	public static final int TRAFFIC_LIGHTS_RED = -100;
	public static final int TRAFFIC_LIGHTS_RED_YELLOW = -98;
	public static final int TRAFFIC_LIGHTS_YELLOW = -99;

	public static boolean isStopRequired(int priority) {
		return priority <= STOP_REQUIRED_THRESHOLD;
	}

	public static String toString(int state) {
		if (state == NOT_AVAILABLE) {
			return "N/A";
		}
		return "" + state;
	}
}

package at.fhhagenberg.mc.traffsim.util.math;

import java.util.Random;

public class RandomNumberGenerator {

	public static double getPoissonRandomNumber(double lambda) {
		Random r = new Random();
		double l = Math.exp(-lambda);
		int k = 0;
		double p = 1.0;

		do {
			k++;
			p = p * r.nextDouble();
		} while (p > l);

		return k - 1;
	}

	public static double getExponentialRandomNumber(double seed) {
		Random r = new Random();
		double p = 1.0 / (seed);
		return (int) (Math.ceil(Math.log(r.nextDouble()) / Math.log(1.0 - p)));
	}

	public static double getParetoRandomNumber(double alpha, double xM) {
		Random r = new Random();

		double v = r.nextDouble();
		while (v == 0) {
			v = r.nextDouble();
		}

		return xM / Math.pow(v, 1.0 / alpha);
	}

	public static double getBoundedParetorRandomNumber(double alpha, double l, double h) {
		Random r = new Random();
		double u = r.nextDouble();
		while (u == 0) {
			u = r.nextDouble();
		}

		double x = -(u * Math.pow(h, alpha) - u * Math.pow(l, alpha) - Math.pow(h, alpha)) / (Math.pow(h * l, alpha));
		return Math.pow(x, -1.0 / alpha);
	}
}

package at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.data;

public class KraussData extends GippsData {
	private static final String IDENTIFIER = "KRAUSS";

	private double epsilon = 0.0;

	public KraussData() {
		setIdentifier(IDENTIFIER);
	}

	public KraussData(double vTarget, double sMin, double comfortableAcc, double safeDec, double epsilon) {
		super(vTarget, sMin, comfortableAcc, safeDec);
		setEpsilon(epsilon);
		setIdentifier(IDENTIFIER);
	}

	public double getEpsilon() {
		return epsilon;
	}

	public void setEpsilon(double epsilon) {
		this.epsilon = epsilon;
	}
}
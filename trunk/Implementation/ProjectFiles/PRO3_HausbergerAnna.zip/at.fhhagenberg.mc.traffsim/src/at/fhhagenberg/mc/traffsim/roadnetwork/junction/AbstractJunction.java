package at.fhhagenberg.mc.traffsim.roadnetwork.junction;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ConnectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.log.LogMessage;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.ILogConsumer;
import at.fhhagenberg.mc.traffsim.model.ISimulationTimeProvider;
import at.fhhagenberg.mc.traffsim.model.geo.Line;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.geo.Vector;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl.JunctionApproach;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.RoadSign;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.TrafficLight;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightController;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.logic.ControlLogic;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.statistics.IStatisticsProvider;
import at.fhhagenberg.mc.traffsim.statistics.IStatsConstants;
import at.fhhagenberg.mc.traffsim.statistics.LaneStatisticsData;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;
import at.fhhagenberg.mc.traffsim.util.exceptions.SpatialException;
import at.fhhagenberg.mc.traffsim.util.exceptions.SplitException;
import at.fhhagenberg.mc.traffsim.util.types.CyclicList;
import at.fhhagenberg.mc.traffsim.util.ui.AWTAdapter;
import at.fhhagenberg.mc.traffsim.vehicle.BlinkerState;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleInJunction;
import at.fhhagenberg.mc.traffsim.vehicle.VehicleWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.model.longitudinal.LongitudinalModel;
import at.fhhagenberg.mc.util.CollectionUtil;

public abstract class AbstractJunction implements IStatisticsProvider {
	public static final double DIRECTION_INDICATOR_DISTANCE = 60;
	protected static final double DEFAULT_LANE_WIDTH_SHRINK_FACTOR = 0.97;
	protected static final double MAX_JUNCTION_RADIUS = 30;
	protected static final double DEFAULT_SMOOTHING_DISTANCE = 200;
	protected static final String PREFIX_ALLOWED = "\u2714";
	protected static final String PREFIX_GRANTED = "\u2795";
	protected static final String PREFIX_GRANT_REMOVED = "\u2796";
	protected static final String PREFIX_DISALLOWED = "\u26d4";
	protected static final String PREFIX_ENTERED = "\u2B00";
	protected static final String PREFIX_LEFT = "\u2B02";

	protected CyclicList<RoadSegment> segmentsOut = new CyclicList<>();
	protected CyclicList<RoadSegment> segmentsIn = new CyclicList<>();

	/** vehicles which are already on their way into the junction */
	protected Map<Long, VehicleInJunction> vehiclesApproaching = new ConcurrentHashMap<>();
	protected Set<Long> entryGrants = new ConcurrentSkipListSet<>();

	/**
	 * vehicles which would have highest priority but cannot enter because their exit is blocked, e.g. by a congestion and mapping to their
	 * destination (which is blocked)
	 */
	protected Map<Vehicle, VehiclesLane> driveThroughNotPossible = new ConcurrentHashMap<>();

	private long id;

	/**
	 * If junctions are merged, these are the ids of junctions which were deleted
	 */
	private Set<Long> secondaryIds = new HashSet<Long>();
	private List<Vector> bounds;
	protected List<JunctionConnector> connectors = new ArrayList<>();
	protected List<JunctionApproach> approaches = new ArrayList<>();
	protected TrafficLightController<?> trafficLightController;
	private Vector junctionCenter;
	private double altitude = Double.NaN;

	/**
	 * speed limit is automatically set to maximum of incoming and outgoing road segments
	 */
	private double speedLimitKmh = Double.NEGATIVE_INFINITY;
	private ArrayList<Line> openEdges;
	private Rectangle boundsRectangle;

	protected ILogConsumer logProvider;
	private ArrayList<RoadSegment> allSegments;
	private ArrayList<Vector> roundedBounds;
	private InternalLogProvider internalLogProvider = new InternalLogProvider();

	private static long nextId = 0;

	private LinkedBlockingQueue<LogMessage> internalLogCache = new LinkedBlockingQueue<>();
	private NodeType type = NodeType.SIMPLE;
	private Map<String, Double> relativeAnglesCache = new ConcurrentHashMap<>();
	private Set<Long> borderingRoutingIds = new HashSet<>();
	/** cached flag if this junction is regulated */
	private Boolean isRegulated = null;
	private ISimulationTimeProvider timeProvider;

	/** longest extent of the intersection */
	private double extent = Double.NaN;

	private Set<IJunctionListener> junctionListeners = new CopyOnWriteArraySet<>();
	/** difference between lanes leading out of and lanes in this junction */
	private int diffInOutLanes;

	/** Use to track individual waiting times for every approach vehicle **/
	private Map<Long, Double> individualWaitingTimes = new ConcurrentHashMap<>();

	private Set<Long> queuedVehicles = new HashSet<>();
	private LogMessage lastAdded;

	/**
	 * Internal class, which is used to cache log messages even if no details view is open
	 */
	private class InternalLogProvider implements ILogConsumer {
		@Override
		public void addLogLine(LogMessage msg) {
			internalLogCache.offer(msg);
		}
	}

	public void cleanInternalLogCache(final int numMessages) {
		while (internalLogCache.size() > numMessages) {
			internalLogCache.poll();
		}
	}

	public AbstractJunction() {
		id = nextId++;
	}

	public AbstractJunction(long id) {
		this.id = id;
	}

	/**
	 * Copy constructor for editing support
	 *
	 * @param other
	 */
	public AbstractJunction(AbstractJunction other) {
		super();
		this.segmentsOut = other.segmentsOut;
		this.segmentsIn = other.segmentsIn;
		this.id = other.id;
		this.secondaryIds = other.secondaryIds;
		this.bounds = other.bounds;
		this.connectors = other.connectors;
		this.approaches = other.approaches;
		this.junctionCenter = other.junctionCenter;
		this.altitude = other.altitude;
		this.speedLimitKmh = other.speedLimitKmh;
		this.openEdges = other.openEdges;
		this.boundsRectangle = other.boundsRectangle;
		this.allSegments = other.allSegments;
	}

	public void addJunctionListener(IJunctionListener listener) {
		if (listener != null && !junctionListeners.contains(listener)) {
			junctionListeners.add(listener);
		}
	}

	public void removeJunctionListener(IJunctionListener listener) {
		if (listener != null && junctionListeners.contains(listener)) {
			junctionListeners.remove(listener);
		}
	}

	public List<RoadSegment> getSegmentsOut() {
		return segmentsOut;
	}

	public void addConnectionIn(RoadSegment segment) {
		if (segment == null) {
			return;
		}

		segmentsIn.add(segment);
		this.speedLimitKmh = Math.max(segment.getSpeedLimitKmph(), speedLimitKmh);
		sortSegments();
	}

	public void addConnectionOut(RoadSegment segment) {
		if (segment == null) {
			return;
		}

		segmentsOut.add(segment);
		this.speedLimitKmh = Math.max(segment.getSpeedLimitKmph(), speedLimitKmh);
		sortSegments();
	}

	public void setSegmentsIn(CyclicList<RoadSegment> segmentsIn) {
		this.segmentsIn = segmentsIn;
		sortSegments();
	}

	public void setSegmentsOut(CyclicList<RoadSegment> segmentsOut) {
		this.segmentsOut = segmentsOut;
		sortSegments();
	}

	public void addVehicle(Vehicle v, VehiclesLane sourceLane) {
		JunctionConnector conn = null;
		IRoute r = v.getRoute();
		if (!v.hasRoute() || r.getRouteIds().isEmpty()) {
			v.setJunction(null);
			v.getLaneSegment().getVehicles().remove(v);
			v.setRoadSegment(null);
			v.notifyListenersVehicleLeft();
			Logger.logWarn("Route of " + v.getLabel() + " has ended. Removing although no road end reached!");
			return;
		}
		if (v.hasRoute()) {
			conn = getNextConnector(v.getRoute(), sourceLane);
		}

		if (conn == null) {
			// something wrong in route - check if route contains any of the
			// subsequent road segments
			conn = tryUpdateRoute(v, sourceLane);
			if (conn == null) {
				Logger.logError("Next connector for vehicle " + v.getLabel() + " not found. Using random direction!");

				int abortCounter = 0;
				do {
					if (abortCounter++ > connectors.size() * 10) {
						break;
					}
					int ind = (int) Math.floor(Math.random() * (connectors.size() - 1));
					conn = connectors.get(ind);
				} while (sourceLane.getRoadSegment().getRoutingId() == conn.getSinkLaneSegment().getRoadSegment().getRoutingId()
						|| !conn.getSourceLaneSegment().equals(sourceLane));
			}
		}
		v.setJunction(this);
		onVehicleEnteredJunction(v.getRoadSegment().getId(), v.getUniqueId());
		v.setRoadSegment(null);
		conn.addVehicle(v);
	}

	private JunctionConnector tryUpdateRoute(Vehicle v, VehiclesLane sourceLane) {
		int i = 0;
		JunctionConnector conn = null;
		IRoute curRoute = null;
		while (i < v.getRoute().getRouteIds().size() && conn == null) {
			curRoute = RoutingUtil.trimRoute(v.getRoute(), i, 0);
			conn = getNextConnector(curRoute, sourceLane);
			i++;
		}
		if (conn != null && curRoute != null) {
			Logger.logDebug(String.format("Junction successfully updated outdated route of vehicle #%d (label %s). New route: %s", v.getUniqueId(),
					v.getLabel(), CollectionUtil.toString(curRoute.getRouteIds(), ",")));
			v.setRoute(curRoute);
		}
		return conn;
	}

	public JunctionConnector getNextConnector(Vehicle vehicle) {
		if (!vehicle.hasRoute()) {
			return null;
		}

		return getNextConnector(vehicle.getRoute(), vehicle.getLaneSegment());
	}

	private JunctionConnector getNextConnector(IRoute r, VehiclesLane sourceLane) {
		JunctionConnector result = null;
		long routingId = r.getNextRoutingId();
		int laneIdDiff = Integer.MAX_VALUE;
		for (JunctionConnector jc : connectors) {
			if (jc.getSourceLaneSegment() == sourceLane && jc.getSinkLaneSegment().getRoadSegment().getRoutingId() == routingId) {
				int currentIdDiff = Math.abs(jc.getSinkLaneSegment().getLaneIndex() - sourceLane.getLaneIndex());
				if (currentIdDiff < laneIdDiff) {
					result = jc;
					laneIdDiff = currentIdDiff;
				}
			}
		}
		return result;
	}

	public void notifyVehicleEnqueued(long vehicleId, double timeHorizon) {
		if (!queuedVehicles.contains(vehicleId)) {
			queuedVehicles.add(vehicleId);
			individualWaitingTimes.put(vehicleId, timeHorizon);
		}
	}

	public void notifyVehicleDequeued(long vehicleId) {
		if (queuedVehicles.contains(vehicleId)) {
			queuedVehicles.remove(vehicleId);
		}
	}

	public abstract void updateEntryGrants(double dt, Date time, double runTime);

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
		AbstractJunction.nextId = id + 1;
	}

	@Override
	public String toString() {
		StringBuffer conn = new StringBuffer();
		if (segmentsOut != null) {
			conn.append("out ");
			for (RoadSegment s : segmentsOut) {
				conn.append(s.getId());
				conn.append(", ");
			}
		}
		if (segmentsIn != null) {
			conn.append("\n     in ");
			for (RoadSegment s : segmentsIn) {
				conn.append(s.getId());
				conn.append(", ");
			}
		}
		return String.format("AbstractJunction: ID %d\nconnected RS: %s\nAltitude: %.2f\nMax Spd: %.2f km/h\nType: %s", id, conn.toString(), altitude,
				speedLimitKmh, type.toString());
	}

	public List<RoadSegment> getSegmentsIn() {
		return segmentsIn;
	}

	/**
	 * Initialize junction and automatically generate the connectors inside by creating connections from each segment in to each segment out
	 *
	 * @throws SplitException
	 * @throws SpatialException
	 */
	public void initializeInterior() throws SplitException, SpatialException {
		initializeInterior(null, true);
	}

	/**
	 * Initialize the junction and create connectors according to parameter.
	 *
	 * @param connectors
	 *            the connectors to create when initializing this junction
	 * @param forceDefaultEnlargement
	 *            the enlargment to use for enlarging the bounds of this junction can be defined by the {@link RoadSegment}s inwards and
	 *            outwards. If the geometries of those are reset, this enlargement is not given any more and set to zero. Therefore, it is
	 *            possible to force the default enlargement value for initialization even if the connectors are already defined.
	 * @throws SplitException
	 * @throws SpatialException
	 */
	public void initializeInterior(List<ConnectorBean> connectors, boolean forceDefaultEnlargement) throws SplitException, SpatialException {
		if (forceDefaultEnlargement) {
			initializeInterior(connectors, getMaxLaneWidth() / 2);
		} else {
			initializeInterior(connectors, 0);
		}
	}

	public void initializeInterior(List<ConnectorBean> connectors, double enlargement) throws SplitException, SpatialException {
		if (junctionCenter == null && segmentsOut.size() > 0) {
			junctionCenter = segmentsOut.get(0).getRoadGeometry().getPoints().get(0);
		}
		updateBounds();

		cutRoadSegments(enlargement);
		sortSegments();
		updateBounds();
		createJunctionConnectors(connectors);
		updateLeftAndRightConnectorEdges();
		updateOpenEdges();
		updateRoundedBounds();
	}

	private void updateOpenEdges() {
		openEdges = new ArrayList<>();
		for (int i = 1; i < bounds.size(); i++) {
			openEdges.add(new Line(bounds.get(i - 1), bounds.get(i)));
		}
		openEdges.add(new Line(CollectionUtil.getLastObject(bounds), CollectionUtil.getFirstObject(bounds)));

		// remove lines of bounds which are no open edges
		for (RoadSegment rsIn : segmentsIn) {
			for (LaneSegment seg : rsIn.getLaneSegments()) {
				for (ListIterator<Line> lineIt = openEdges.listIterator(); lineIt.hasNext();) {
					Line line = lineIt.next();
					if (line.getPoints().size() < 2) {
						lineIt.remove();
						continue;
					}
					Line newLine = SpatialUtil.removePoints(line, CollectionUtil.getLastObject(seg.getRightEdge()),
							CollectionUtil.getLastObject(seg.getLeftEdge()));
					if (newLine.getPoints().size() < 2) {
						lineIt.remove();
					} else if (!newLine.equals(line)) {
						lineIt.set(newLine);
					}
				}
			}
		}
		for (RoadSegment rsOut : segmentsOut) {
			for (LaneSegment seg : rsOut.getLaneSegments()) {
				for (ListIterator<Line> lineIt = openEdges.listIterator(); lineIt.hasNext();) {
					Line line = lineIt.next();
					if (line.getPoints().size() < 2) {
						lineIt.remove();
						continue;
					}
					Line newLine = SpatialUtil.removePoints(line, CollectionUtil.getFirstObject(seg.getRightEdge()),
							CollectionUtil.getFirstObject(seg.getLeftEdge()));
					if (newLine.getPoints().size() < 2) {
						lineIt.remove();
					} else if (!newLine.equals(line)) {
						lineIt.set(newLine);
					}
					// if
					// (line.getP1().equals(CollectionUtil.getFirstObject(seg.getRightEdge()),
					// 10e-3)
					// &&
					// line.getP2().equals(CollectionUtil.getFirstObject(seg.getLeftEdge()),
					// 10e-3)
					// ||
					// line.getP2().equals(CollectionUtil.getFirstObject(seg.getRightEdge()),
					// 10e-3)
					// &&
					// line.getP1().equals(CollectionUtil.getFirstObject(seg.getLeftEdge()),
					// 10e-3)) {
					// lineIt.remove();
					// }

				}
			}
		}
		// all lines filtered - now make rest of lines smooth
		for (ListIterator<Line> lineIt = openEdges.listIterator(); lineIt.hasNext();) {
			Line line = lineIt.next();
			RoadSegment in = null, out = null;
			for (RoadSegment segIn : segmentsIn) {
				Location loc = CollectionUtil.getLastObject(segIn.getRightMostLane().getRightEdge());
				if (loc.equals(line.getP1()) || loc.equals(line.getP2())) {
					in = segIn;
					break;
				}
			}
			for (RoadSegment segOut : segmentsOut) {
				Location loc = CollectionUtil.getFirstObject(segOut.getRightMostLane().getRightEdge());
				if (loc.equals(line.getP1()) || loc.equals(line.getP2())) {
					out = segOut;
					break;
				}
			}
			if (in != null && out != null) {
				JunctionConnector conn = generateConnector(in.getRightMostLane(), out.getRightMostLane(), 1);
				try {
					updateConnectorEdges(conn);
				} catch (SpatialException e) {
					Logger.logWarn("Error on smoothing connector (" + e.getMessage() + "). Ignoring this and continuing");
				}
				if (conn != null) {
					ArrayList<Vector> list = new ArrayList<>(conn.getRightEdge());
					list.add(0, CollectionUtil.getLastObject(in.getRightMostLane().getRightEdge()));
					list.add(CollectionUtil.getFirstObject(out.getRightMostLane().getRightEdge()));
					lineIt.set(new Line(list));
				}
			}
		}
	}

	public void addConnector(JunctionConnector conn) {
		this.connectors.add(conn);

		try {
			updateLeftAndRightConnectorEdges();
		} catch (SpatialException e) {
			Logger.logError("Cannot update connector edges", e);
		}

		isRegulated = null;
	}

	public void removeConnector(JunctionConnector conn) {
		this.connectors.remove(conn);

		try {
			updateLeftAndRightConnectorEdges();
		} catch (SpatialException e) {
			Logger.logError("Cannot update connector edges", e);
		}

		isRegulated = null;
	}

	private void updateBounds() {
		// //////////////
		Set<Vector> newBounds = new HashSet<>();
		for (RoadSegment rsIn : segmentsIn) {
			for (RoadSegment rsOut : segmentsOut) {
				if (rsIn.getRoutingId() != rsOut.getRoutingId()) {
					Vector intersection = SpatialUtil.nearestIntersection(rsIn.getRightMostLane().getRightEdge(),
							rsOut.getRightMostLane().getRightEdge(), junctionCenter);
					// check if intersection is unrealistic (may be the case if
					// segment in and segment out do not intersect in this
					// junction, but in a neighbor junction, e.g. traffic island
					if (intersection == null || SpatialUtil.getDistance(intersection, junctionCenter) > MAX_JUNCTION_RADIUS) {
						List<Vector> lanepoints = rsIn.getRightMostLane().getRightEdge();
						newBounds.add(lanepoints.get(lanepoints.size() - 1));
						newBounds.add(rsOut.getRightMostLane().getRightEdge().get(0));
					} else {
						newBounds.add(intersection);
					}
				}
			}
		}
		// for one-way crossings: check intersections of in/in and out/out as
		// well
		for (RoadSegment rsIn1 : segmentsIn) {
			for (RoadSegment rsIn2 : segmentsIn) {
				Vector intersection = SpatialUtil.firstIntersection(rsIn1.getRightMostLane().getRightEdge(), rsIn2.laneSegment(0).getLeftEdge());
				if (intersection != null && SpatialUtil.getDistance(intersection, junctionCenter) <= MAX_JUNCTION_RADIUS) {
					newBounds.add(intersection);
				}
				Vector intersection2 = SpatialUtil.firstIntersection(rsIn2.getRightMostLane().getRightEdge(), rsIn1.laneSegment(0).getLeftEdge());
				if (intersection2 != null && SpatialUtil.getDistance(intersection2, junctionCenter) <= MAX_JUNCTION_RADIUS) {
					newBounds.add(intersection2);
				}
			}
		}
		for (RoadSegment rsOut1 : segmentsOut) {
			for (RoadSegment rsOut2 : segmentsOut) {
				Vector intersection = SpatialUtil.firstIntersection(rsOut1.getRightMostLane().getRightEdge(), rsOut2.laneSegment(0).getLeftEdge());
				if (intersection != null && SpatialUtil.getDistance(intersection, junctionCenter) <= MAX_JUNCTION_RADIUS) {
					newBounds.add(intersection);
				}
				Vector intersection2 = SpatialUtil.firstIntersection(rsOut2.getRightMostLane().getRightEdge(), rsOut1.laneSegment(0).getLeftEdge());
				if (intersection2 != null && SpatialUtil.getDistance(intersection2, junctionCenter) <= MAX_JUNCTION_RADIUS) {
					newBounds.add(intersection2);
				}
			}
		}
		for (RoadSegment segIn : segmentsIn) {
			for (LaneSegment seg : segIn.getLaneSegments()) {
				List<Vector> edge = seg.getRightEdge();
				if (edge.size() > 0) {
					newBounds.add(edge.get(edge.size() - 1));
				}
				edge = seg.getLeftEdge();
				if (edge.size() > 0) {
					newBounds.add(edge.get(edge.size() - 1));
				}
			}
		}
		for (RoadSegment segOut : segmentsOut) {
			for (LaneSegment seg : segOut.getLaneSegments()) {
				List<Vector> edge = seg.getRightEdge();
				if (edge.size() > 0) {
					newBounds.add(edge.get(0));
				}
				edge = seg.getLeftEdge();

				if (edge.size() > 0) {
					newBounds.add(edge.get(0));
				}
			}
		}
		bounds = SpatialUtil.convexHull(newBounds, 0);
		boundsRectangle = AWTAdapter.toRectangle(bounds);

		junctionCenter = SpatialUtil.getCenter(bounds);
	}

	protected boolean isOneWaySegment(RoadSegment seg) {
		List<RoadSegment> searchSegments = null;
		if (segmentsIn.contains(seg)) {
			searchSegments = segmentsOut;
		} else {
			searchSegments = segmentsIn;
		}
		for (RoadSegment rs : searchSegments) {
			if (rs.getRoutingId() == seg.getRoutingId()) {
				return false;
			}
		}
		return true;
	}

	public void createApproaches() {
		for (RoadSegment segment : segmentsIn) {
			List<TrafficLight> trafficLights = new ArrayList<>();
			List<JunctionConnector> relatedConnectors = new ArrayList<>();

			for (JunctionConnector connector : connectors) {
				if (segment.getLaneSegments().contains(connector.getSourceLaneSegment())) {
					if (connector.getTrafficLight() != null && !trafficLights.contains(connector.getTrafficLight())) {
						trafficLights.add(connector.getTrafficLight());
					}

					if (!relatedConnectors.contains(connector)) {
						relatedConnectors.add(connector);
					}
				}
			}

			JunctionApproach approach;

			if (!trafficLights.isEmpty()) {
				approach = new JunctionApproach(this, segment, relatedConnectors, trafficLights);
			} else {
				approach = new JunctionApproach(this, segment, relatedConnectors);
			}

			approaches.add(approach);
		}
	}

	private void createJunctionConnectors(List<ConnectorBean> definedConnectors) {
		connectors.clear();
		if (definedConnectors != null && !definedConnectors.isEmpty()) {
			isRegulated = false;
			for (ConnectorBean bean : definedConnectors) {
				RoadSegment fromSeg = CollectionUtil.getObjectWithId(segmentsIn, bean.getFromSegment());
				RoadSegment toSeg = CollectionUtil.getObjectWithId(segmentsOut, bean.getToSegment());

				if (fromSeg == null || toSeg == null) {
					Logger.logError("Could not find defined connector for junction " + bean.getNodeId() + " from " + bean.getFromSegment() + " (lane "
							+ bean.getFromLane() + ") to " + bean.getToSegment() + " (lane " + bean.getToLane() + ").");
					continue;
				}

				LaneSegment from = fromSeg.laneSegment(bean.getFromLane());
				LaneSegment to = toSeg.laneSegment(bean.getToLane());
				JunctionConnector conn = generateConnector(bean.getId(), from, to,
						bean.getShrinkFactor() <= 0 ? DEFAULT_LANE_WIDTH_SHRINK_FACTOR : bean.getShrinkFactor(),
						bean.getSmoothing() <= 0 ? DEFAULT_SMOOTHING_DISTANCE : bean.getSmoothing());

				if (bean.getRoadSign() != null) {
					conn.setRoadSign(new RoadSign(RoadSign.Type.valueOf(bean.getRoadSign().toString())));
					isRegulated = true;
				}

				conn.setPriority(bean.getPriority());
				connectors.add(conn);
			}
			if (isRegulated()) {
				for (JunctionConnector conn : connectors) {
					if (!conn.isPriorityAvailable()) {
						conn.setPriority(PriorityState.NONE);
					}
				}
			}
		} else {
			isRegulated = null;
			Set<Pair<LaneSegment, LaneSegment>> pairs = new HashSet<>();
			pairs.addAll(getConnectedPairs());
			for (Pair<LaneSegment, LaneSegment> pair : pairs) {
				LaneSegment lsIn = pair.getLeft();
				LaneSegment lsOut = pair.getRight();
				if (!PreferenceUtil.getBoolean(IPreferenceConstants.CREATE_REVERSE_CONNECTOR)
						&& lsIn.getRoadSegment().getRoutingId() == lsOut.getRoadSegment().getRoutingId()) {
					continue;
				}
				/*
				 * IGNORE LANE RESTRICTIONS, since they lead to problems. if (lsIn.getRestriction() != null) { double angleDiff =
				 * SpatialUtil.getAngleDifference(lsIn.getRoadGeometry(), lsOut.getRoadGeometry(), true); switch (lsIn.getRestriction()) {
				 * case STRAIGHT_RIGHT: if (!RoadUtil.turnsLeft(angleDiff)) { ok = true; } break; case TO_LEFT: if
				 * (RoadUtil.turnsLeft(angleDiff)) { ok = true; } break; case TO_RIGHT:
				 *
				 * if (!RoadUtil.turnsLeft(angleDiff) && !RoadUtil.goesStraight(angleDiff)) { ok = true; } break; case STRAIGHT: ok = true;
				 * break; } } else { ok = true; } if (ok) {
				 */
				connectors.add(generateConnector(lsIn, lsOut, DEFAULT_LANE_WIDTH_SHRINK_FACTOR));
				// }
			}
		}
	}

	private Set<Pair<LaneSegment, LaneSegment>> getConnectedPairs() {
		Set<Pair<LaneSegment, LaneSegment>> pairs = new HashSet<>();
		if (isSimpleThrough() || ((segmentsIn.size() == 1 || segmentsOut.size() == 1)
				&& RoadUtil.totalLaneCount(segmentsIn, -1) == RoadUtil.totalLaneCount(segmentsOut, -1))) {
			if (segmentsIn.size() == 1) {
				RoadSegment rsIn = CollectionUtil.getFirstObject(segmentsIn);

				// find out segment right to the current in segment
				RoadSegment firstOutSegment = null;
				double leastDiff = Double.MAX_VALUE;
				for (RoadSegment rsOut : segmentsOut) {
					double diff = SpatialUtil.getAngleDifference(rsIn.getRoadGeometry(), rsOut.getRoadGeometry(), true);
					if (diff < leastDiff && rsIn.getRoutingId() != rsOut.getRoutingId()) {
						leastDiff = diff;
						firstOutSegment = rsOut;
					}
				}

				// loop through all out segments and add lane segment one after
				// the other
				int lsInIndex = 0;
				RoadSegment cur = firstOutSegment;
				do {
					for (LaneSegment lsOut : cur.getLaneSegments()) {
						pairs.add(new ImmutablePair<LaneSegment, LaneSegment>(rsIn.laneSegment(lsInIndex), lsOut));
						lsInIndex++;
					}
					do {
						cur = segmentsOut.elementLeftTo(cur);
					} while (rsIn.getRoutingId() == cur.getRoutingId());
				} while (!cur.equals(firstOutSegment));
			}
			if (segmentsOut.size() == 1) {
				RoadSegment rsOut = segmentsOut.get(0);

				// find out segment right to the current in segment
				RoadSegment firstInSegment = null;
				double maxDiff = Double.MIN_VALUE;
				for (RoadSegment rsIn : segmentsIn) {
					double diff = SpatialUtil.getAngleDifference(rsIn.getRoadGeometry(), rsOut.getRoadGeometry(), true);
					if (diff > maxDiff && rsIn.getRoutingId() != rsOut.getRoutingId()) {
						maxDiff = diff;
						firstInSegment = rsIn;
					}
				}

				// loop through all out segments and add lane segment one after
				// the other
				int lsOutIndex = rsOut.getLaneCount() - 1;
				RoadSegment cur = firstInSegment;
				do {
					for (int i = cur.getLaneCount() - 1; i >= 0; i--) {
						LaneSegment lsIn = cur.laneSegment(i);
						pairs.add(new ImmutablePair<LaneSegment, LaneSegment>(lsIn, rsOut.laneSegment(lsOutIndex)));
						lsOutIndex--;
					}
					do {
						cur = segmentsIn.elementLeftTo(cur);
					} while (rsOut.getRoutingId() == cur.getRoutingId());
				} while (!cur.equals(firstInSegment));
			}
		} else {
			// no special handling - create combinations for junction connectors
			for (RoadSegment rsIn : segmentsIn) {

				Set<LaneSegment> unusedSegments = new HashSet<>(rsIn.getLaneSegments());
				for (RoadSegment rsOut : segmentsOut) {
					double diff = SpatialUtil.getAngleDifference(rsIn.getRoadGeometry(), rsOut.getRoadGeometry(), true);
					boolean straight = !RoadUtil.turnsLeft(diff) && !RoadUtil.turnsRight(diff);
					if (RoadUtil.turnsLeft(diff) || straight) {
						for (int laneIndex = 0; laneIndex < rsIn.getLaneCount() && laneIndex < rsOut.getLaneCount(); laneIndex++) {
							pairs.add(new ImmutablePair<>(rsIn.laneSegment(laneIndex), rsOut.laneSegment(laneIndex)));
							unusedSegments.remove(rsIn.laneSegment(laneIndex));
						}
					}
					if (RoadUtil.turnsRight(diff) || straight) {
						for (int inLaneIndex = rsIn.getLaneCount() - 1, outLaneIndex = rsOut.getLaneCount() - 1; inLaneIndex >= 0
								&& outLaneIndex >= 0; inLaneIndex--, outLaneIndex--) {
							pairs.add(new ImmutablePair<>(rsIn.laneSegment(inLaneIndex), rsOut.laneSegment(outLaneIndex)));
							unusedSegments.remove(rsIn.laneSegment(inLaneIndex));
						}
					}
					if (!unusedSegments.isEmpty()) {
						for (LaneSegment unused : unusedSegments) {
							System.out.println("unused: " + getId() + "  " + unused);
						}
					}
				}

			}

		}
		return pairs;
	}

	public JunctionConnector generateConnector(LaneSegment lsIn, LaneSegment lsOut, double shrinkFactor) {
		return generateConnector(-1, lsIn, lsOut, shrinkFactor, DEFAULT_SMOOTHING_DISTANCE);
	}

	/**
	 * Create a junction connector between given {@link LaneSegment}s
	 *
	 * @param id
	 *            the connector's id
	 * @param lsIn
	 *            the {@link LaneSegment} inwards
	 * @param lsOut
	 *            the {@link LaneSegment} outwards
	 * @param shrinkFactor
	 *            factor which is applied to shrink the width
	 * @param smoothingDistance
	 *            distance to move points outwards for smoothing (lower distance will create sharper edges
	 * @return the generated junction connector
	 */
	public JunctionConnector generateConnector(long id, LaneSegment lsIn, LaneSegment lsOut, double shrinkFactor, double smoothingDistance) {
		List<Vector> path = new ArrayList<>();
		List<Vector> geomIn = lsIn.getRoadGeometry().getPoints();
		List<Vector> geomOut = lsOut.getRoadGeometry().getPoints();
		if (geomIn.size() == 0 || geomOut.size() == 0) {
			return null;
		}
		// create a vector which contains one point before
		// pointIn, pointIn, pointOut and one point after
		// pointOut
		// the points before in and after out are moved to the
		// appropriate direction, so that smooth curves are the
		// result
		Vector pointIn = geomIn.get(geomIn.size() - 1);
		if (geomIn.size() > 1) {
			Vector next = geomIn.get(geomIn.size() - 2);
			Vector dir = next.minus(pointIn);
			path.add(next.plus(dir.unify().multiplyBy(smoothingDistance)));
		}
		path.add(pointIn);
		Vector pointOut = geomOut.get(0);
		path.add(pointOut);
		if (geomOut.size() > 1) {
			Vector next = geomOut.get(1);
			Vector dir = next.minus(pointOut);
			path.add(next.plus(dir.unify().multiplyBy(smoothingDistance)));
		}
		List<Vector> smoothed = SpatialUtil.smooth(path, 0f);
		smoothed = smoothed.subList(smoothed.indexOf(pointIn), smoothed.indexOf(pointOut) + 1);
		JunctionConnector conn = new JunctionConnector(id, this, smoothed, lsIn, lsOut);
		conn.setShrinkFactor(shrinkFactor);
		conn.setSmoothing((int) smoothingDistance);
		conn.setLaneWidth((lsIn.getLaneWidth() + lsOut.getLaneWidth()) / 2 * shrinkFactor);
		isRegulated = null;
		return conn;
	}

	private void updateLeftAndRightConnectorEdges() throws SpatialException {
		for (JunctionConnector conn : connectors) {
			updateConnectorEdges(conn);
		}
	}

	public void updateConnectorEdges(JunctionConnector conn) throws SpatialException {
		boolean addedFront = false;
		boolean addedBack = false;
		List<Vector> extendedPoints = new ArrayList<>(conn.getRoadGeometry().getPoints());
		if (conn.getSourceLaneSegment() != null) {
			List<Vector> sourcePoints = conn.getSourceLaneSegment().getRoadGeometry().getPoints();
			if (sourcePoints.get(sourcePoints.size() - 1).equals(extendedPoints.get(0))) {
				extendedPoints.add(0, sourcePoints.get(sourcePoints.size() - 2));
			} else {
				extendedPoints.add(0, sourcePoints.get(sourcePoints.size() - 1));
			}
			addedFront = true;
		}
		if (conn.getSinkLaneSegment() != null) {
			List<Vector> sinkPoints = conn.getSinkLaneSegment().getRoadGeometry().getPoints();
			if (sinkPoints.get(0).equals(extendedPoints.get(extendedPoints.size() - 1))) {
				extendedPoints.add(sinkPoints.get(1));
			} else {
				extendedPoints.add(0, sinkPoints.get(0));
			}
			addedBack = true;
		}
		List<Vector> leftEdge, rightEdge;
		leftEdge = SpatialUtil.createOffsetCurve(extendedPoints, conn.getLaneWidth() / 2, true);
		rightEdge = SpatialUtil.createOffsetCurve(extendedPoints, -conn.getLaneWidth() / 2, true);
		if (addedFront) {
			leftEdge.remove(0);
			rightEdge.remove(0);
		}
		if (addedBack) {
			leftEdge.remove(leftEdge.size() - 1);
			rightEdge.remove(rightEdge.size() - 1);

		}
		conn.setLeftEdge(leftEdge);
		conn.setRightEdge(rightEdge);
	}

	/**
	 *
	 * @param enlargement
	 *            specify whether the junction bounds should be enlarged by half the maximum lane width (useful if junction is generated the
	 *            first time)
	 * @throws SplitException
	 */
	private void cutRoadSegments(double enlargement) throws SplitException {

		List<Vector> boundsToCut = SpatialUtil.convexHull(new HashSet<>(bounds), enlargement);
		for (RoadSegment rsIn : segmentsIn) {
			rsIn.originalPointsSnapshot();
			rsIn.getRoadGeometry().setPoints(SpatialUtil.split(rsIn.getRoadGeometry().getPoints(), boundsToCut, true));
			for (LaneSegment ls : rsIn.getLaneSegments()) {
				ls.getRoadGeometry().setPoints(SpatialUtil.split(ls.getRoadGeometry().getPoints(), boundsToCut, true));
				ls.setRightEdge(SpatialUtil.split(ls.getRightEdge(), boundsToCut, true));
				ls.setLeftEdge(SpatialUtil.split(ls.getLeftEdge(), boundsToCut, true));
			}

		}
		for (RoadSegment rsOut : segmentsOut) {
			rsOut.originalPointsSnapshot();
			try {
				rsOut.getRoadGeometry().setPoints(SpatialUtil.split(rsOut.getRoadGeometry().getPoints(), boundsToCut, true));
			} catch (SplitException ex) {
				if (ex.isFatal()) {
					throw ex;
				} else {
					Logger.logWarn(ex.getMessage());
				}
			}
			for (LaneSegment ls : rsOut.getLaneSegments()) {
				ls.getRoadGeometry().setPoints(SpatialUtil.split(ls.getRoadGeometry().getPoints(), boundsToCut, true));
				ls.setRightEdge(SpatialUtil.split(ls.getRightEdge(), boundsToCut, true));
				ls.setLeftEdge(SpatialUtil.split(ls.getLeftEdge(), boundsToCut, true));
			}
		}
	}

	private double getMaxLaneWidth() {
		double maxLaneWidth = 0;

		for (RoadSegment rsIn1 : segmentsIn) {
			maxLaneWidth = Math.max(maxLaneWidth, rsIn1.getRightMostLane().getLaneWidth());
		}
		for (RoadSegment rsOut1 : segmentsOut) {
			maxLaneWidth = Math.max(maxLaneWidth, rsOut1.getRightMostLane().getLaneWidth());
		}
		return maxLaneWidth;
	}

	public List<Vector> getBounds() {
		return bounds;
	}

	public Rectangle getBoundsRectangle() {
		return boundsRectangle;
	}

	public ArrayList<Vector> getRoundedBounds() {
		return roundedBounds;
	}

	private void updateRoundedBounds() {
		roundedBounds = new ArrayList<>();
		for (int i = 0; i < bounds.size() - 1; i++) {
			Vector v = bounds.get(i);
			Vector next = bounds.get(i + 1);
			boolean found = false;
			for (Line line : openEdges) {
				if (CollectionUtil.getFirstObject(line.getPolyLine()).equals(next) && CollectionUtil.getLastObject(line.getPolyLine()).equals(v)) {
					ArrayList<Vector> reversed = new ArrayList<>(line.getPolyLine());
					Collections.reverse(reversed);
					roundedBounds.addAll(reversed);
					i++;
					found = true;
					break;
				}
			}
			if (!found) {
				roundedBounds.add(v);
			}

		}
	}

	public List<JunctionApproach> getApproaches() {
		return approaches;
	}

	public ControlLogic getControlLogicForTrafficLight(TrafficLight trafficLight) {
		if (trafficLight == null) {
			return null;
		}

		JunctionApproach approach = getApproachForTrafficLight(trafficLight);

		if (approach == null) {
			return null;
		}

		return approach.getControlLogicForTrafficLight(trafficLight);
	}

	public JunctionApproach getApproachForTrafficLight(TrafficLight trafficLight) {
		if (trafficLight == null) {
			return null;
		}

		try {
			JunctionApproach approach = approaches.stream().filter(app -> app.getTrafficLights().contains(trafficLight)).findAny().get();
			return approach;
		} catch (NoSuchElementException ne) {
			return null;
		}
	}

	public TrafficLightController<?> getTrafficLightController() {
		return trafficLightController;
	}

	public void setTrafficLightController(TrafficLightController<?> trafficLightController) {
		this.trafficLightController = trafficLightController;
	}

	public void removeTrafficLight(TrafficLight tl) {

		JunctionApproach approach = getApproachForTrafficLight(tl);

		if (approach != null) {
			approach.removeTrafficLight(tl);

			if (trafficLightController != null) {
				trafficLightController.updateControlLogics();
			}
		}

		if (getTrafficLights().size() == 0) {
			removeTrafficLightController();
		}
	}

	public void removeTrafficLightController() {
		trafficLightController = null;

		for (JunctionApproach approach : approaches) {
			approach.removeAllTrafficLights();
		}
	}

	public List<TrafficLight> getTrafficLights() {
		List<TrafficLight> trafficLights = new ArrayList<>();

		for (JunctionApproach approach : approaches) {
			trafficLights.addAll(approach.getTrafficLights());
		}

		return trafficLights;
	}

	public List<JunctionConnector> getConnectors() {
		return connectors;
	}

	public List<Vehicle> getVehicles() {
		List<Vehicle> vehicles = new ArrayList<>();
		for (JunctionConnector jc : connectors) {
			vehicles.addAll(jc.getVehicles());
		}
		return vehicles;
	}

	public List<JunctionConnector> getConnectors(long fromRoutingId, long toRoutingId) {
		List<JunctionConnector> connectors = new ArrayList<>();
		for (JunctionConnector jc : this.connectors) {
			if (jc.getSourceLaneSegment().getRoadSegment().getRoutingId() == fromRoutingId
					&& jc.getSinkLaneSegment().getRoadSegment().getRoutingId() == toRoutingId) {
				connectors.add(jc);
			}
		}
		return connectors;
	}

	public JunctionConnector getConnector(long fromRoutingId, long toRoutingId) {
		List<JunctionConnector> conn = getConnectors(fromRoutingId, toRoutingId);
		return conn.size() > 0 ? conn.get(0) : null;
	}

	/**
	 * Get the defined connector. If multiple connectors are available, take the one which needs the least lane changes in front of
	 * intersection
	 *
	 * @param fromRoutingId
	 *            the routing id of the source segment
	 * @param toRoutingId
	 *            routing id of the destination segment
	 * @param preferredLaneIndex
	 *            the index of the preferred entry lane
	 * @return the best fitting connector, or <code>null</code> if no such connector exists
	 */
	public JunctionConnector getConnector(long fromRoutingId, long toRoutingId, int preferredLaneIndex) {

		JunctionConnector fittingConn = null;
		int minLaneDiff = Integer.MAX_VALUE;
		List<JunctionConnector> conn = getConnectors(fromRoutingId, toRoutingId);
		for (JunctionConnector jc : conn) {
			if (fittingConn == null) {
				fittingConn = jc;
			}
			int newLaneDiff = Math.abs(jc.getSourceLaneSegment().getLaneIndex() - preferredLaneIndex);
			// check if less lane changes are necessary when using the current
			// connector to reach target
			if (minLaneDiff > newLaneDiff) {
				fittingConn = jc;
				minLaneDiff = newLaneDiff;
			}
		}
		return fittingConn;
	}

	public JunctionConnector getConnector(VehiclesLane fromLane, VehiclesLane toLane) {
		for (JunctionConnector jc : this.connectors) {
			if (jc.getSourceLaneSegment().getId() == fromLane.getId() && jc.getSinkLaneSegment().getId() == toLane.getId()) {
				return jc;
			}
		}
		return null;
	}

	/**
	 * Get all connectors which originate in the given {@link VehiclesLane}
	 *
	 * @param from
	 *            the originating {@link VehiclesLane}
	 * @return list of {@link JunctionConnector}s, which lead from source lane to any other lane
	 */
	public List<JunctionConnector> getConnectors(VehiclesLane from) {
		List<JunctionConnector> conn = new ArrayList<>();
		for (JunctionConnector jc : connectors) {
			if (jc.getSourceLaneSegment().equals(from)) {
				conn.add(jc);
			}
		}
		return conn;
	}

	public List<JunctionConnector> getConnectorsTo(VehiclesLane to) {
		List<JunctionConnector> conn = new ArrayList<>();
		for (JunctionConnector jc : connectors) {
			if (jc.getSinkLaneSegment().equals(to)) {
				conn.add(jc);
			}
		}
		return conn;
	}

	public void updateWaitingTimes(double dt) {
		for (Long vehicleId : queuedVehicles) {
			if (individualWaitingTimes.containsKey(vehicleId)) {
				double waitingTime = individualWaitingTimes.get(vehicleId) + dt;
				individualWaitingTimes.put(vehicleId, waitingTime);
			}
		}
	}

	public void updateAccelerations(double dt, double runTime) {
		for (JunctionConnector jc : getConnectors()) {
			for (Vehicle v : jc.getVehicles()) {
				v.updateAcceleration(dt, runTime);
			}
		}
	}

	public void updateSpeedsAndPositions(double dt, Date time) {
		for (JunctionConnector jc : getConnectors()) {
			for (Vehicle v : jc.getVehicles()) {
				v.updateSpeedAndPosition(dt, time);
			}
		}
	}

	private void sortSegments() {
		if (junctionCenter != null) {
			DirectionComparator compIn = new DirectionComparator(junctionCenter, DirectionComparator.GEOMETRY_TAKE_LAST);
			Collections.sort(segmentsIn, compIn);
			DirectionComparator compOut = new DirectionComparator(junctionCenter, DirectionComparator.GEOMETRY_TAKE_FIRST);
			Collections.sort(segmentsOut, compOut);
			allSegments = new ArrayList<>();
			allSegments.addAll(segmentsIn);
			allSegments.addAll(segmentsOut);
			for (RoadSegment rs : allSegments) {
				borderingRoutingIds.add(rs.getRoutingId());
			}
		}
		diffInOutLanes = segmentsOut.stream().mapToInt(RoadSegment::getLaneCount).sum()
				- segmentsIn.stream().mapToInt(RoadSegment::getLaneCount).sum();
	}

	/**
	 *
	 * @return the difference between the sum of {@link VehiclesLane}s out of this junction compared to the lanes leading in this junction
	 */
	public int getDiffInOut() {
		return diffInOutLanes;
	}

	public Set<Long> getBorderingRoutingIds() {
		return borderingRoutingIds;
	}

	public ArrayList<RoadSegment> getAllSegments() {
		return allSegments;
	}

	public Vector getJunctionCenter() {
		return junctionCenter;
	}

	public double getSpeedLimitKmh() {
		return speedLimitKmh;
	}

	public double getSpeedLimitMps() {
		return speedLimitKmh / 3.6;
	}

	public void setSpeedLimitKmh(double speedLimit) {
		this.speedLimitKmh = speedLimit;
	}

	public ArrayList<Line> getOpenEdges() {
		return openEdges;
	}

	public LaneStatisticsData getStatistics() {
		LaneStatisticsData data = new LaneStatisticsData();
		for (RoadSegment conn : segmentsIn) {
			data = data.merge(conn.getCompleteRoadStatistics());
		}
		return data;
	}

	/**
	 * Calculation of the front vehicle on the given {@link JunctionConnector}. This influences the behavior for the
	 * {@link LongitudinalModel}. If the lane is blocked or vehicle should break, an imaginary obstacle can be created to achieve this
	 * behavior.
	 *
	 * This method can be overridden by implementations of {@link AbstractJunction} in order to model the appropriate behavior.
	 *
	 * @param me
	 *            The vehicle for which to calculate successor
	 * @param connector
	 *            the {@link JunctionConnector} on which the vehicle is driving
	 * @return the front {@link Vehicle} and the distance between me and the front, or null in case no such vehicle exists or no
	 *         junction-specific implementation is needed
	 */
	public abstract VehicleWithDistance frontVehicle(Vehicle me, JunctionConnector connector);

	/**
	 * Logic for junction: is the vehicle from source to destination allowed to enter the junction?
	 *
	 * This method must be overridden by implementations of {@link AbstractJunction} in order to model the appropriate behavior
	 *
	 * @param v
	 *            the vehicle which wants to enter the intersection
	 * @param source
	 *            the lane where the vehicle is coming from
	 * @param dest
	 *            lane where the vehicle is going to
	 * @param distanceToJunction
	 * @return true, if the vehicle can enter, false otherwise
	 */
	public abstract boolean canEnter(Vehicle v, VehiclesLane source, VehiclesLane dest, double distanceToJunction);

	public abstract Map<Long, VehicleInJunction> getVehiclesApproaching();

	public abstract Set<Long> getEntryGrants();

	public Map<Vehicle, VehiclesLane> getDriveThroughNotPossible() {
		return driveThroughNotPossible;
	}

	public void removeLogProvider() {
		this.logProvider = null;
	}

	public void setLogProvider(ILogConsumer logProvider) {
		this.logProvider = logProvider;
		for (LogMessage s : internalLogCache) {
			logProvider.addLogLine(s);
		}
	}

	/**
	 * This method can be used to provider debug output for junctions. The output can be handled by any debug window, for example, or is
	 * simply ignored if not necessary.
	 *
	 * @param msg
	 * @param forceLog
	 *            force the line to be added to the log
	 */
	public void addDebugLogLine(final LogMessage msg, final boolean forceLog) {
		if (!msg.equals(lastAdded) && (forceLog || !internalLogCache.contains(msg))) {
			lastAdded = msg;
			if (logProvider != null) {
				logProvider.addLogLine(msg);
			}
			internalLogProvider.addLogLine(msg);
		}
	}

	/**
	 * Add id of junction which was merged with this one and disappeared from the network
	 *
	 * @param secId
	 */
	public void addSecondaryId(long secId) {
		this.secondaryIds.add(secId);
	}

	public double getAltitude() {
		return altitude;
	}

	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	public boolean isRegulated() {
		if (isRegulated == null) {
			isRegulated = false;
			for (JunctionConnector c : connectors) {
				if (c.isPriorityAvailable() && c.getRoadSign() != null && c.getRoadSign().getType() != RoadSign.Type.NONE) {
					isRegulated = true;
				}
			}
		}
		return isRegulated;
	}

	public Map<Long, Double> getIndividualWaitingTimes() {
		return individualWaitingTimes;
	}

	public Set<Long> getSecondaryIds() {
		return secondaryIds;
	}

	public abstract boolean removeEntryGrant(Vehicle v, IRoute newRoute);

	public boolean isSimpleThrough() {
		return type == NodeType.DRIVE_THROUGH;
	}

	public boolean hasTrafficLights() {
		for (JunctionConnector conn : connectors) {
			if (conn.getTrafficLight() != null) {
				return true;
			}
		}
		return false;
	}

	public boolean isSingleLane() {
		for (JunctionApproach approach : approaches) {
			if (!approach.IsSingleLane()) {
				return false;
			}
		}

		return true;
	}

	public double getCachedRelativeAngle(VehiclesLane source, VehiclesLane dest) {
		String key = source.getId() + "_" + dest.getId();
		if (!relativeAnglesCache.containsKey(key)) {
			relativeAnglesCache.put(key, SpatialUtil.getAngleDifference(source.getRoadGeometry(), dest.getRoadGeometry(), true));
		}
		return relativeAnglesCache.get(key);
	}

	protected LogMessage getLogMessage(Vehicle vehWantToEnter, String msg) {
		return getLogMessage("", vehWantToEnter, msg);
	}

	protected LogMessage getLogMessage(String prefix, Vehicle vehWantToEnter, String msg) {
		StringBuffer buf = new StringBuffer();
		buf.append(prefix);
		buf.append(" ");
		buf.append(vehWantToEnter.getLabel());
		buf.append(" ");
		buf.append(msg);
		if (timeProvider == null) {
			return new LogMessage(buf.toString());
		}
		return new LogMessage(timeProvider.getCurrentSimTime(), buf.toString());
	}

	public NodeType getType() {
		return type;
	}

	public void setType(NodeType type) {
		if (type != null) {
			this.type = type;
		}
	}

	public void setSimulationTimeProvider(ISimulationTimeProvider timeProvider) {
		this.timeProvider = timeProvider;
	}

	/**
	 *
	 * @return the longest extent of this intersection, i.e. the longest possible driving through distance of a {@link JunctionConnector}
	 */
	public double getExtent() {
		if (Double.isNaN(extent)) {
			extent = connectors.stream().map(JunctionConnector::getRoadLength).max(Comparator.comparingDouble(c -> c)).get();
		}
		return extent;
	}

	protected void onVehicleLeftJunction(long vehicleId) {
		for (IJunctionListener listener : junctionListeners) {
			listener.onVehicleLeftJunction(id, vehicleId);
		}
	}

	protected void onVehicleEnteredJunction(long roadSegmentId, long vehicleId) {
		for (IJunctionListener listener : junctionListeners) {
			listener.onVehicleEnteredJunction(id, roadSegmentId, vehicleId);
		}
	}

	protected void updateBlinkerState(Vehicle vehWantToEnter, VehiclesLane source, VehiclesLane dest, double distanceToJunction) {
		AbstractJunction nextJunc;
		if (distanceToJunction < DIRECTION_INDICATOR_DISTANCE && vehWantToEnter.getRoadSegment() != null
				&& (nextJunc = RoadUtil.getNextJunction(vehWantToEnter.getRoadSegment()).getJunction()) != null && nextJunc.equals(this)) {

			double angle = getCachedRelativeAngle(source, dest);
			if (RoadUtil.turnsLeft(angle)) {
				vehWantToEnter.setBlinkerState(BlinkerState.LEFT);
			} else if (RoadUtil.turnsRight(angle)) {
				vehWantToEnter.setBlinkerState(BlinkerState.RIGHT);
			}
		}
	}

	/**
	 * Checks if the given vehicle has the shortest distance to the junction on the current {@link RoadSegment}
	 *
	 * @param v
	 * @return true if the vehicle is the closest, false otherwise
	 */
	protected boolean isNearestInRoutingSegment(VehicleInJunction v) {
		for (VehicleInJunction vAppr : vehiclesApproaching.values()) {
			if (!vAppr.getVehicle().isInJunction() && vAppr.getDistanceToJunction() < v.getDistanceToJunction()
					&& (vAppr.getJunctionConnector().getSourceLaneSegment().equals(v.getJunctionConnector().getSourceLaneSegment())
							&& !vAppr.getJunctionConnector().getSinkLaneSegment().equals(v.getJunctionConnector().getSinkLaneSegment()))) {
				return false;
			}
		}

		return true;
	}

	/**
	 *
	 * @param veh1
	 * @param veh2
	 * @return positive: veh1 arrives later, negative: veh2 arrives later
	 */
	protected double getArrivalTimeDiff(VehicleInJunction veh1, VehicleInJunction veh2) {
		double s1 = veh1.getDistanceToJunction();
		double v1 = veh1.getVehicle().getCurrentSpeed();
		double a1 = veh1.getVehicle().getCurrentAcc();
		double s2 = veh2.getDistanceToJunction();
		double v2 = veh2.getVehicle().getCurrentSpeed();
		double a2 = veh2.getVehicle().getCurrentAcc();

		if (v1 == 0 && v2 == 0) {
			return a1 - a2;
		}

		if (v1 == 0) {
			return -v2;
		}

		if (v2 == 0) {
			return v1;
		}

		return (s1 / v1 - v1 / a1) - (s2 / v2 - v2 / a2);
	}

	@Override
	public Map<String, Number> obtainStatistics() {
		Map<String, Number> statistics = new HashMap<>();

		double totalQueue = 0;
		double totalThroughput = 0;

		for (JunctionApproach approach : approaches) {
			totalQueue += approach.getQueueMonitor().getQueueLength();
			totalThroughput += approach.getQueueMonitor().getCountOutflow();
		}

		statistics.put(IStatsConstants.JUNCTION_QUEUE_LENGTH, totalQueue);
		statistics.put(IStatsConstants.JUNCTION_THROUGHPUT, totalThroughput);
		return statistics;
	}
}

package at.fhhagenberg.mc.traffsim.communication;

public interface IChannelModel extends Cloneable {

	/**
	 * Find the next delay of the message
	 * 
	 * @return delay in miliseconds
	 */
	long getNextDelay();

	/**
	 * 
	 * @return whether or not the next message transfer is successful
	 */
	boolean isSuccessful();

	/**
	 * Creates a clone of this model, if necessary (e.g. stateful model with markov chain)
	 * 
	 * @return clone of this model if necessary, or the current instance if not necessary
	 * @throws CloneNotSupportedException
	 */
	IChannelModel clone() throws CloneNotSupportedException;

	/**
	 * 
	 * @return a human readable name of the model
	 */
	String getName();
}
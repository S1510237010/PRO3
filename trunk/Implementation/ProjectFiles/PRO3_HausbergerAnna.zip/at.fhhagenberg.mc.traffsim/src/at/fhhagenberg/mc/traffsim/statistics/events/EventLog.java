package at.fhhagenberg.mc.traffsim.statistics.events;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.collections4.queue.CircularFifoQueue;

import at.fhhagenberg.mc.traffsim.model.PauseableThread;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;

public class EventLog extends PauseableThread {
	private Lock eventsLock = new ReentrantLock();
	private Queue<Event> events = new CircularFifoQueue<Event>(PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_CACHE_SIZE) * 10);
	private ReentrantLock notificationsLock = new ReentrantLock();
	private List<Event> scheduledNotifications = new ArrayList<>();
	private Set<IEventListener> eventListeners = new HashSet<>();

	private Lock debugEventsLock = new ReentrantLock();
	private Queue<Event> debugEvents = new CircularFifoQueue<Event>(PreferenceUtil.getInt(IPreferenceConstants.STATISTICS_CACHE_SIZE) * 10);
	private Set<IEventListener> debugEventListeners = new HashSet<>();

	public EventLog(String name, long delay) {
		super(name, delay);
	}

	public void logEvent(Event event) {
		try {
			eventsLock.lock();
			events.add(event);
		} finally {
			eventsLock.unlock();
		}

		try {
			notificationsLock.lock();
			scheduledNotifications.add(event);
		} finally {
			notificationsLock.unlock();
		}

		proceed();
	}

	public void logDebugEvent(Event event) {

		if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DEBUG_EVENTS)) {
			try {
				debugEventsLock.lock();
				debugEvents.add(event);
			} finally {
				debugEventsLock.unlock();
			}

			try {
				notificationsLock.lock();
				scheduledNotifications.add(event);
			} finally {
				notificationsLock.unlock();
			}
		}

		proceed();
	}

	/**
	 * Remove the events from the internal list, while keeping the specified amount of elements in the list
	 *
	 * @param eventsToKeep
	 *            the number of elements to keep in the internal list (the rest is deleted)
	 * @return the removed events (as new {@link ArrayList}
	 */
	public List<Event> collectEvents(int eventsToKeep) {
		List<Event> collected = new ArrayList<>();
		try {
			eventsLock.lock();
			if (events.size() <= eventsToKeep) {
				return collected;
			}
			while (events.size() > eventsToKeep) {
				collected.add(events.poll());
			}
		} finally {
			eventsLock.unlock();
		}
		return collected;
	}

	public List<Event> getEvents() {
		try {
			eventsLock.lock();
			return new ArrayList<Event>(events);
		} finally {
			eventsLock.unlock();
		}
	}

	public List<Event> getDebugEvents() {
		try {
			debugEventsLock.lock();
			return new ArrayList<Event>(debugEvents);
		} finally {
			debugEventsLock.unlock();
		}
	}

	public void addEventListener(IEventListener listener) {
		this.eventListeners.add(listener);
	}

	public void addDebugEventListener(IEventListener listener) {
		this.debugEventListeners.add(listener);
	}

	@Override
	public void doWork() {
		List<Event> toSchedule;

		try {
			notificationsLock.lock();
			toSchedule = new ArrayList<>(scheduledNotifications);
			scheduledNotifications = new ArrayList<>();
		} finally {
			notificationsLock.unlock();
		}

		for (Event event : toSchedule) {
			if (event instanceof DebugEvent) {
				for (IEventListener listener : debugEventListeners) {
					listener.newEvent(event);
				}
			} else {
				for (IEventListener listener : eventListeners) {
					listener.newEvent(event);
				}
			}
		}

		pause();
	}

	public void removeEventListener(IEventListener listener) {
		this.eventListeners.remove(listener);
	}

	public void removeDebugEventListener(IEventListener listener) {
		this.debugEventListeners.remove(listener);
	}
}

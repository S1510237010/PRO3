package at.fhhagenberg.mc.traffsim.roadnetwork.junction.impl;

import java.util.HashMap;

import at.fhhagenberg.mc.traffsim.model.IntervalTimer;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.SpatialUtil;

/**
 * Caching utility, which caches the intersection calculation of {@link VehiclesLane}s, used in a junction.
 *
 * @author Christian Backfrieder
 *
 */
public class SpatialCache extends IntervalTimer {

	public SpatialCache(long intervalMillis) {
		super("Cache Timer (Lane intersection)", intervalMillis);
	}

	private HashMap<LanesCombination, Boolean> intersectingCache = new HashMap<>();

	/**
	 * A combination of two lanes. The equals method returns true if this combination consists of the very same lanes which are
	 * exchangeable! <br>
	 * <b>Example:</b><br>
	 * <code> new {@link LanesCombination}(lane1, lane2).equals(new {@link LanesCombination}(lane2, lane1)) == true</code>
	 *
	 * @author Christian Backfrieder
	 *
	 */
	private class LanesCombination {

		private VehiclesLane lane1;
		private VehiclesLane lane2;

		public LanesCombination(VehiclesLane lane1, VehiclesLane lane2) {
			this.lane1 = lane1;
			this.lane2 = lane2;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			if (lane1 != null && lane2 != null) {
				VehiclesLane first = lane1.getRoadLength() < lane2.getRoadLength() ? lane1 : lane2;
				VehiclesLane second = lane1.getRoadLength() < lane2.getRoadLength() ? lane2 : lane1;
				result = prime * result + first.hashCode();
				result = prime * result + second.hashCode();
			} else {
				if (lane1 == null) {
					result = prime * result + lane2.hashCode();
				}
				if (lane2 == null) {
					result = prime * result + lane1.hashCode();
				}
			}

			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			LanesCombination other = (LanesCombination) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (lane1 == null) {
				if (other.lane1 != null)
					return false;
			} else if (!lane1.equals(other.lane1) && !lane1.equals(other.lane2)) {
				return false;
			}
			if (lane2 == null) {
				if (other.lane2 != null)
					return false;
			} else if (!lane2.equals(other.lane2) && !lane2.equals(other.lane1)) {
				return false;
			}
			return true;
		}

		private SpatialCache getOuterType() {
			return SpatialCache.this;
		}

	}

	/**
	 * Calculate intersection between two {@link VehiclesLane}s and cache result.
	 *
	 * @param lane1
	 * @param lane2
	 * @return <code>true</code> if any of the lane bounds intersects, <code>false</code> otherwise
	 * @see SpatialUtil#intersect(VehiclesLane, VehiclesLane)
	 */
	public boolean intersects(VehiclesLane lane1, VehiclesLane lane2) {
		resetTimer();
		LanesCombination combination = new LanesCombination(lane1, lane2);
		synchronized (this) {
			if (!intersectingCache.containsKey(combination)) {
				intersectingCache.put(combination, SpatialUtil.intersects(lane1, lane2));
				// System.out.println(((JunctionConnector) lane1).getJunction().getId() + " new: " + lane1.getId() + "/" + lane2.getId());
			}
			return intersectingCache.get(combination);
		}
	}

	@Override
	protected void timeIsUp() {
		synchronized (this) {
			intersectingCache = new HashMap<>();
		}
	}
}

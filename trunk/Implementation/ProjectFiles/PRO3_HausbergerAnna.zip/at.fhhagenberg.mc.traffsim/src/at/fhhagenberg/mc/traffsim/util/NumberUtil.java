package at.fhhagenberg.mc.traffsim.util;

import java.util.List;

/**
 * Utility class providing number-related functionalities
 *
 * @author Christian Backfrieder
 */
public class NumberUtil {

	/**
	 * Calculates average (index 0) and standard deviation (index 1) of the given list of values.
	 *
	 * @param values
	 *            the values used for calculation
	 * @return double array of length 2 containing the values' average (index 0) and standard deviation (index 1)
	 */
	public static double[] average(List<Double> values) {
		if (values == null || values.isEmpty()) {
			return new double[2];
		}

		double var = 0;
		double avg = 0;

		for (Double d : values) {
			avg += d;
		}

		avg /= values.size();

		for (Double d : values) {
			var += Math.pow(d - avg, 2);
		}

		var /= values.size();
		return new double[] { avg, Math.sqrt(var) };
	}

	/**
	 * Calculates the average angle from the given array of values
	 *
	 * @param values
	 *            the array of values used for calculation
	 * @return the average angle obtained from the provided values
	 */
	public static double averageAngle(double[] values) {
		double x = 0, y = 0;

		for (double d : values) {
			x += Math.cos(d);
			y += Math.sin(d);
		}

		return Math.atan2(y, x);
	}

	/**
	 * Calculates the average angle from the given list of values
	 *
	 * @param values
	 *            the list of values used for calculation
	 * @return the average angle obtained from the provided values
	 */
	public static double averageAngle(List<Double> values) {
		double x = 0, y = 0;

		for (Double d : values) {
			x += Math.cos(d);
			y += Math.sin(d);
		}

		return Math.atan2(y, x);
	}

	/**
	 * Compare two double values using a tolerance of 10^-5.
	 *
	 * @param v1
	 *            the first double value
	 * @param v2
	 *            the second double value
	 * @return true if the difference of the provided doubles is less than the tolerance value - false else
	 * @see #doubleEquals(double, double, double)
	 */
	public static boolean doubleEquals(double v1, double v2) {
		return doubleEquals(v1, v2, 0.00001);
	}

	/**
	 * Compare two double values using the given tolerance.
	 *
	 * @param v1
	 *            the first double value
	 * @param v2
	 *            the second double value
	 * @param tolerance
	 *            the tolerance used for comparison
	 * @return true if the difference of the provided doubles is less than the tolerance value - false else
	 */
	public static boolean doubleEquals(double v1, double v2, double tolerance) {
		return Math.abs(v1 - v2) < tolerance;
	}

	/**
	 * Determines the min. value of the given array of values.
	 *
	 * @param array
	 *            the array of values used for calculation
	 * @return the minimum value in the given array
	 */
	public static double min(double... array) {
		double min = Double.POSITIVE_INFINITY;

		if (array == null) {
			return min;
		}

		for (double val : array) {
			if (val < min) {
				min = val;
			}
		}

		return min;
	}

	/**
	 * Determines the max. value of the given array of values.
	 *
	 * @param array
	 *            the array of values used for calculation
	 * @return the max. value in the given array
	 */
	public static double max(double... array) {
		double max = Double.NEGATIVE_INFINITY;

		if (array == null) {
			return max;
		}

		for (double val : array) {
			if (val > max) {
				max = val;
			}
		}

		return max;
	}

	/**
	 * Determines the max. value of type T in the given list of type T.
	 *
	 * @param <T>
	 *            the generic type
	 * @param list
	 *            the list of values used for calculation
	 * @param defaultValue
	 *            the default value to initialize the maximum with
	 * @return the maximum of a list, assuming generic type of list is an instance of {@link Comparable}, or <code>null</code> if not
	 */
	public static <T extends Comparable<T>> T max(List<T> list, T defaultValue) {
		T max = defaultValue;

		try {
			for (T obj : list) {
				if (max == null || ((Comparable<T>) max).compareTo(obj) < 0) {
					max = obj;
				}
			}
		} catch (Exception e) {
			return defaultValue;
		}

		return max;
	}

	/**
	 * Multiplies each value of the given array with the provided factor.
	 *
	 * @param array
	 *            the array whose values are to be multiplied
	 * @param factor
	 *            the multiplication factor
	 * @return an element-wise multiplied array
	 */
	public static double[] multiply(double[] array, double factor) {
		for (int i = 0; i < array.length; i++) {
			array[i] *= factor;
		}

		return array;
	}

	/**
	 * Rounds the given number to the provided number of decimals.
	 *
	 * @param number
	 *            the number to be rounded
	 * @param decimals
	 *            the number of decimals to be considered for rounding
	 * @return the rounded number
	 */
	public static double roundTo(double number, int decimals) {
		int fact = (int) Math.pow(10, decimals);
		return (double) Math.round(number * fact) / fact;
	}

	/**
	 * Limit the value to be within the given range
	 * 
	 * @param value
	 *            the value to limit
	 * @param minimum
	 *            the minimum not to undercut
	 * @param maximum
	 *            the maximum not to exceed
	 * @return the value if between minimum and maximum, or minimum if value < minimum, or maximum if value > maximum
	 */
	public static double limit(double value, double minimum, double maximum) {
		return value < minimum ? minimum : (value > maximum ? maximum : value);
	}
}
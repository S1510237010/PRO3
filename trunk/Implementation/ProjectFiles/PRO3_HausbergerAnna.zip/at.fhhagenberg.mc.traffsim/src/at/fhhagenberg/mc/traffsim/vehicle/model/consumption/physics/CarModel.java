package at.fhhagenberg.mc.traffsim.vehicle.model.consumption.physics;

import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionCarDataBean;
import at.fhhagenberg.mc.traffsim.vehicle.model.consumption.FuelConstants;

/**
 * Container class providing a number of car-related parameters and certain interfaces to access them in an abstracted manner.
 *
 * @author Christian Backfrieder
 */
public class CarModel {

	private ConsumptionCarDataBean data;

	// cache for values that are only dependent from data, and therefore constant
	private double mg;
	private double c;
	private double d;
	private double e;

	private double dynWheelCircumfence;

	/**
	 * Creates a new {@link CarModel} from the provided {@link ConsumptionCarDataBean}.
	 *
	 * @param carInput
	 *            a data entity containing all car-related parameters obtained from a configuration file
	 */
	public CarModel(ConsumptionCarDataBean carInput) {
		this.data = carInput;
		mg = data.getVehicleMass() * FuelConstants.GRAVITATION;
		c = mg * data.getConsFrictionCoefficient();
		d = mg * data.getvFrictionCoefficient();
		e = 0.5 * FuelConstants.RHO_AIR * data.getCdValue() * data.getCrossSectionSurface();

		dynWheelCircumfence = 2 * Math.PI * data.getDynamicTyreRadius();
	}

	/**
	 * Gets the vehicle's dynamic wheel circumference.
	 *
	 * @return the dynamic wheel circumference
	 */
	public double getDynamicWheelCircumfence() {
		return dynWheelCircumfence;
	}

	/**
	 * Gets the vehicle's electric power
	 *
	 * @return the electric power
	 */
	public double getElectricPower() {
		return data.getElectricPower();
	}

	/**
	 * Gets the vehicle's mechanical force based on the current velocity and acceleration.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @return the mechanical force
	 */
	public double getForceMech(double v, double acc) {
		return getForceMech(v, acc, 0);
	}

	/**
	 * Gets the vehicle's mechanical force based on the current velocity, the current acceleration and the current slope.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @param acc
	 *            the vehicle's current acceleration
	 * @param slope
	 *            the current slope
	 * @return the mechanical force
	 */
	public double getForceMech(double v, double acc, double slope) {

		final double f = mg * Math.sin(slope);
		return c /* rolling friction (contant) */
				+ d * v /*
						 * rolling friction (variable; speed proportional)
						 */
				+ f /* downhill force (slope) */
				+ e * v * v /* air resistance */
				+ data.getVehicleMass() * acc /* inertial force */;
	}

	/**
	 * Gets the vehicle's free wheeling deceleration based on the current velocity.
	 *
	 * @param v
	 *            the vehicle's current velocity
	 * @return the free wheeling deceleration
	 */
	public double getFreeWheelingDecel(double v) {
		return -(FuelConstants.GRAVITATION * data.getConsFrictionCoefficient()
				+ FuelConstants.GRAVITATION * data.getvFrictionCoefficient() * v
				+ data.getCdValue() * FuelConstants.RHO_AIR * data.getCrossSectionSurface() * v * v / (2 * data.getVehicleMass()));
	}
}
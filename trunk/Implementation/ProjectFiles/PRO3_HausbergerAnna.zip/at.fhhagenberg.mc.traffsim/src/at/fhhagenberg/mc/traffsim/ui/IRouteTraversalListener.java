package at.fhhagenberg.mc.traffsim.ui;

public interface IRouteTraversalListener {

	void onRoutingIdTraversed();
}

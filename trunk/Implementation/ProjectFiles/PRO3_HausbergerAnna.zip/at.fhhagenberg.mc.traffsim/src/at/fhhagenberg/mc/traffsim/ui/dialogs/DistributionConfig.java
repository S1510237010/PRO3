package at.fhhagenberg.mc.traffsim.ui.dialogs;

import org.apache.commons.math3.distribution.AbstractRealDistribution;

public class DistributionConfig {

	private AbstractRealDistribution distribution;
	
	// Possible lower and upper boundaries for the particular property
	private double minimum;
	private double maximum;
	
	// Fields to persist selection values of configuration controls
	private double firstParam;
	private double secondParam;
	
	// Flags to determine whether the lower/upper bounds should be considered
	private boolean considerMinimum;
	private boolean considerMaximum;

	public DistributionConfig() {
		this.distribution = null;
		this.considerMinimum = false;
		this.considerMaximum = false;
	}

	public DistributionConfig(AbstractRealDistribution distribution, double firstParam, double secondParam, double min,
			double max, boolean considerMin, boolean considerMax) {
		this.distribution = distribution;
		this.firstParam = firstParam;
		this.secondParam = secondParam;
		this.minimum = min;
		this.maximum = max;
		this.considerMinimum = considerMin;
		this.considerMaximum = considerMax;
	}

	public void setDistribution(AbstractRealDistribution distribution) {
		this.distribution = distribution;
	}

	public AbstractRealDistribution getDistribution() {
		return distribution;
	}

	public void setFirstParam(double firstParam) {
		this.firstParam = firstParam;
	}

	public double getFirstParam() {
		return firstParam;
	}

	public void setSecondParam(double secondParam) {
		this.secondParam = secondParam;
	}

	public double getSecondParam() {
		return secondParam;
	}

	public void setMinimum(double min) {
		this.minimum = min;
	}

	public double getMinimum() {
		return minimum;
	}

	public void setMaximum(double max) {
		this.maximum = max;
	}

	public double getMaximum() {
		return maximum;
	}

	public void setConsiderMinimum(boolean considerMin) {
		this.considerMinimum = considerMin;
	}

	public boolean getConsiderMinimum() {
		return considerMinimum;
	}

	public void setConsiderMaximum(boolean considerMax) {
		this.considerMaximum = considerMax;
	}

	public boolean getConsiderMaximum() {
		return considerMaximum;
	}
}

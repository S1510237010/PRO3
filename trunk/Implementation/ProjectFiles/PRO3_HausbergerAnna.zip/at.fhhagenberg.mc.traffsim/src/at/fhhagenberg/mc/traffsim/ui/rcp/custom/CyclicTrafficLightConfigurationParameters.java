package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

public class CyclicTrafficLightConfigurationParameters extends TrafficLightConfigurationParameters {
	public boolean startWithGreenPhase;
	public long phaseDelay;
	public long phaseLength;
}

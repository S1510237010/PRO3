package at.fhhagenberg.mc.traffsim.communication;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

public interface IVehicleInformationReceiver extends IVehicleListener {
	default public void vehicleGenerated(Long vId) {
	}

	default public void routeUpdated(Vehicle v, RoadSegment currentSegment, IRoute oldRoute, IRoute newRoute) {
	}

	/**
	 *
	 * @return a readable name of the communication receiver
	 */
	public String getCommReceiverName();

}

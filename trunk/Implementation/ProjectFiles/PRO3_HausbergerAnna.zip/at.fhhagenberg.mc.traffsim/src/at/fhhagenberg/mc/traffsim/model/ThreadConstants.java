package at.fhhagenberg.mc.traffsim.model;

public abstract class ThreadConstants {

	public static final String REROUTER_NAME = "ReRoutingThread";
	public static final String VEHICLEUPDATER_NAME = "VehicleUpdateThread";
	public static final String COMMUNICATOR_NAME = "CommunicatorThread";

}

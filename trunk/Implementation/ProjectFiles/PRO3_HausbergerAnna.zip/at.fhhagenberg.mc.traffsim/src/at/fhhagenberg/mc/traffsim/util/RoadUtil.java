package at.fhhagenberg.mc.traffsim.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.tuple.Triple;

import at.fhhagenberg.mc.traffsim.roadnetwork.RoadGeometry;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.VehiclesLane;
import at.fhhagenberg.mc.traffsim.util.types.CyclicList;
import at.fhhagenberg.mc.traffsim.util.types.JunctionWithDistance;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;

/**
 * Utility class providing various functionalities related to roads and infrastructure.
 *
 * @author Christian Backfrieder
 */
public class RoadUtil {

	/**
	 * Finds which connector of the given {@link AbstractJunction} the {@link Vehicle} v uses, or <code>null</code> if the vehicles route
	 * does not traverse this junction.
	 *
	 * @param vehicle
	 *            the vehicle of interest
	 * @param j
	 *            the junction to be validated
	 * @return the found connector, or <code>null</code> if not found
	 */
	public static JunctionConnector findConnector(Vehicle vehicle, AbstractJunction j) {
		VehiclesLane curLane = vehicle.getLaneSegment();
		long nextRoutingId = vehicle.getRoute().getNextRoutingId();

		while (true) {
			if (curLane.getSinkLaneSegment() != null) {
				curLane = curLane.getSinkLaneSegment();
			} else if (curLane.getRoadSegment().getJunction() != null) {
				AbstractJunction junc = curLane.getRoadSegment().getJunction();
				JunctionConnector conn = junc.getConnector(curLane.getRoadSegment().getRoutingId(), nextRoutingId);

				if (junc.equals(j)) {
					return conn;
				}

				if (conn == null) {
					return null;
				}

				curLane = conn.getSinkLaneSegment();
			} else {
				break;
			}

			nextRoutingId = vehicle.getRoute().getRoutingIdAfter(nextRoutingId);
		}

		return null;
	}

	/**
	 * @param origin
	 * @param travelTime
	 * @return Triple:</br>
	 *         Segment where position lands</br>
	 *         actual possible travel time from given segment to returned position</br>
	 *         position relative to given segment
	 */
	public static Triple<RoadSegment, Double, Double> getUpstreamPosition(final RoadSegment origin, double travelTime) {

		// Calculation in meter, seconds
		double totalTime = travelTime;
		double passed = 0;
		double inc = 0;
		RoadSegment segTemp = origin;
		double driveThroughTime = segTemp.getRoadLength() / segTemp.getSpeedLimitMps();

		while (true) {
			inc = passed + driveThroughTime >= totalTime ? totalTime - passed : driveThroughTime;

			if (segTemp.getSourceRoadSegment() == null) {
				totalTime = passed + inc;
				break;
			}

			if (passed + driveThroughTime >= totalTime) {
				passed += inc;
				break;
			}

			segTemp = segTemp.getSourceRoadSegment();
			driveThroughTime = segTemp.getRoadLength() / segTemp.getSpeedLimitMps();
			passed += inc;
		}

		RoadSegment monitoredSegment = segTemp;
		double distance = inc * monitoredSegment.getSpeedLimitMps();
		distance = monitoredSegment.getRoadLength() - distance;
		double actualTimerange = totalTime * 1000;
		return Triple.of(monitoredSegment, actualTimerange, distance);
	}

	/**
	 * Takes into account the route of the vehicle and calculates the distance (without lane changes) in meters how far the vehicle has to
	 * drive until reaching the given {@link AbstractJunction}.
	 *
	 * @param vehicle
	 *            the {@link Vehicle} of which the current position and route is taken for calculation )
	 * @param junc
	 *            the junction to measure distance to
	 * @return the distance in meters, or -1 if no connection found between the current vehicle position and the given {@link RoadSegment}
	 */
	public static double getDistance(Vehicle vehicle, AbstractJunction junc) {
		VehiclesLane curLane = vehicle.getLaneSegment();
		double distance = curLane.getRoadLength() - vehicle.getFrontPosition();
		long nextRoutingId = vehicle.getRoute().getNextRoutingId();

		while (true) {
			if (curLane.getSinkLaneSegment() != null) {
				curLane = curLane.getSinkLaneSegment();
			} else if (curLane.getRoadSegment().getJunction() != null) {
				AbstractJunction curJunc = curLane.getRoadSegment().getJunction();
				JunctionConnector conn = curJunc.getConnector(curLane.getRoadSegment().getRoutingId(), nextRoutingId);

				if (conn == null) {
					return Double.MIN_VALUE;
				}

				if (curJunc.equals(junc)) {
					return distance;
				}

				distance += conn.getRoadLength();
				curLane = conn.getSinkLaneSegment();
			} else {
				break;
			}

			distance += curLane.getRoadLength();
			nextRoutingId = vehicle.getRoute().getRoutingIdAfter(nextRoutingId);
		}

		return distance;
	}

	/**
	 * Gets a list of all lane segments from the given list of road segments.
	 *
	 * @param roadSegs
	 *            the list of road segments
	 * @return a list of lane segments obtained from the provided road segments
	 */
	public static List<LaneSegment> getLaneSegments(CyclicList<RoadSegment> roadSegs) {
		List<LaneSegment> laneSegs = new ArrayList<>();
		RoadSegment current = roadSegs.get(0);

		do {
			laneSegs.addAll(current.getLaneSegments());
			current = roadSegs.elementLeftTo(current);
		} while (current != roadSegs.get(0));

		return laneSegs;
	}

	/**
	 * Gets a {@link JunctionWithDistance} object comprising the next junction and the distance to it from the given road segment.
	 *
	 * @param seg
	 *            the segment of interest
	 * @return a {@link JunctionWithDistance} object encapsulating the next junction and it's distance from the road segment
	 */
	public static JunctionWithDistance getNextJunction(RoadSegment seg) {
		return getNextJunction(seg, 0);
	}

	/**
	 * Gets a {@link JunctionWithDistance} object comprising the next junction and the distance to it from the given road segment.
	 *
	 * @param seg
	 *            the segment of interest
	 * @return a {@link JunctionWithDistance} object encapsulating the next junction and it's distance from the road segment
	 */
	public static JunctionWithDistance getNextJunction(VehiclesLane seg) {
		return getNextJunction(getNextRoadSegment(seg), 0);
	}

	public static RoadSegment getNextRoadSegment(VehiclesLane seg) {
		while (seg != null && seg.getRoadSegment() == null) {
			seg = seg.getSinkLaneSegment();
		}
		return seg != null ? seg.getRoadSegment() : null;
	}

	/**
	 * Calculates the next junction after the road segment, and subtracts vehicle's position from the distance.
	 *
	 * @param seg
	 *            the segment of interest
	 * @param vehiclePosition
	 *            the vehicle front position on the given segment (is subtracted from the overall distance)
	 * @return next junction, including distance measured from the current front position to the entry point of the junction. If the
	 *         {@link RoadSegment} is a dangling segment (has no junction), the {@link AbstractJunction} field of
	 *         {@link JunctionWithDistance} is <code>null</code>
	 */
	public static JunctionWithDistance getNextJunction(RoadSegment seg, double vehiclePosition) {
		if (seg == null) {
			return null;
		}
		double distance = seg.getRoadLength();

		while (seg.getSinkRoadSegment() != null) {
			seg = seg.getSinkRoadSegment();
			distance += seg.getRoadLength();
		}

		return new JunctionWithDistance(seg.getJunction(), distance - vehiclePosition);
	}

	/**
	 * Gets a {@link JunctionWithDistance} object comprising the previous junction and the distance to it from the given road segment.
	 *
	 * @param seg
	 *            the segment of interest
	 * @return a {@link JunctionWithDistance} object encapsulating the previous junction and it's distance from the road segment
	 */
	public static JunctionWithDistance getPreviousJunction(RoadSegment seg) {
		return getPreviousJunction(seg, 0);
	}

	/**
	 * Calculates the previous junction before the road segment, and subtracts vehicle's position from the distance.
	 *
	 * @param seg
	 *            the segment of interest
	 * @param vehiclePosition
	 *            the vehicle front position on the given segment (is subtracted from the overall distance)
	 * @return previous junction, including distance measured from the current front position to the entry point of the junction. If the
	 *         {@link RoadSegment} is a dangling segment (has no junction), the {@link AbstractJunction} field of
	 *         {@link JunctionWithDistance} is <code>null</code>
	 */
	public static JunctionWithDistance getPreviousJunction(RoadSegment seg, double vehiclePosition) {
		if (seg == null) {
			return null;
		}
		double distance = vehiclePosition;

		while (seg.getSourceRoadSegment() != null) {
			seg = seg.getSourceRoadSegment();
			distance += seg.getRoadLength();
		}

		return new JunctionWithDistance(seg.getSourceJunction(), distance);
	}

	/**
	 * Gets the previous junction before the road segment.
	 *
	 * @param seg
	 *            the seggment of interest
	 * @return the previous junction before the given road segment
	 */
	public static AbstractJunction getPreviousJunctionOnly(RoadSegment seg) {
		while (seg.getSourceRoadSegment() != null) {
			seg = seg.getSourceRoadSegment();
		}

		return seg.getSourceJunction();
	}

	/**
	 * Gets the next junction after the road segment.
	 *
	 * @param seg
	 *            the seggment of interest
	 * @return the next junction after the given road segment
	 */
	public static AbstractJunction getNextJunctionOnly(RoadSegment seg) {
		while (seg.getSinkRoadSegment() != null) {
			seg = seg.getSinkRoadSegment();
		}

		return seg.getJunction();
	}

	public static RoadSegment getConnectingSegmentForward(RoadSegment seg, AbstractJunction junction) {
		while (seg.getSinkRoadSegment() != null) {
			seg = seg.getSinkRoadSegment();
		}

		if (seg.getJunction() != null && seg.getJunction().getId() == junction.getId()) {
			return seg;
		}

		return null;
	}

	public static RoadSegment getConnectingSegmentBackward(RoadSegment seg, AbstractJunction junction) {
		while (seg.getSourceRoadSegment() != null) {
			seg = seg.getSourceRoadSegment();
		}

		if (seg.getSourceJunction() != null && seg.getSourceJunction().getId() == junction.getId()) {
			return seg;
		}

		return null;
	}

	/**
	 * Determine whether or not any other vehicle is located between a given vehicle and a given junction, using the vehicle's route for
	 * determination
	 *
	 * @param vehicle
	 *            the vehicle to check for
	 * @param j
	 *            the junction which should be checked
	 * @param baseLane
	 *            the basis lane to start looking (and its direct followers)
	 * @return <true> if any other vehicle is between the current vehicle location and the provided junction, <false> if no vehicle is
	 *         inbetween or if the route of the vehicle does not pass the junction
	 */
	public static boolean isOtherVehicleBeforeJunction(Vehicle vehicle, AbstractJunction j, VehiclesLane baseLane) {
		VehiclesLane curLane = baseLane;
		long nextRoutingId = vehicle.getRoute().getNextRoutingId();

		while (true) {
			if (curLane.getVehicles().indexOf(vehicle) != -1 && curLane.getVehicles().indexOf(vehicle) < curLane.getVehicles().size() - 1) {
				return true;
			}

			if (curLane.getVehicles().indexOf(vehicle) == -1 && !curLane.getVehicles().isEmpty()) {
				return true;
			}

			if (curLane.getSinkLaneSegment() != null) {
				curLane = curLane.getSinkLaneSegment();
			} else if (curLane.getRoadSegment().getJunction() != null) {
				AbstractJunction junc = curLane.getRoadSegment().getJunction();
				JunctionConnector conn = junc.getConnector(curLane.getRoadSegment().getRoutingId(), nextRoutingId);

				if (junc.equals(j) || conn == null) {
					return false;
				}

				curLane = conn.getSinkLaneSegment();
			} else {
				break;
			}

			nextRoutingId = vehicle.getRoute().getRoutingIdAfter(nextRoutingId);
		}

		return true;
	}

	/**
	 * @see #isOtherVehicleBeforeJunction(Vehicle, AbstractJunction, VehiclesLane) with the current vehicle's lane as base lane
	 * @param vehicle
	 * @param j
	 * @return <true> if any other vehicle is between the current vehicle location and the provided junction, <false> if no vehicle is
	 *         inbetween or if the route of the vehicle does not pass the junction
	 */
	public static boolean isOtherVehicleBeforeJunction(Vehicle vehicle, AbstractJunction j) {
		return isOtherVehicleBeforeJunction(vehicle, j, vehicle.getLaneSegment());
	}

	/**
	 * Helper method, determines next junction automatically based on provided baseLane parameter
	 *
	 * @param vehicle
	 *            the base vehicle for analysis
	 * @param baseLane
	 *            the lane to look on
	 * @see #isOtherVehicleBeforeJunction(Vehicle, AbstractJunction, VehiclesLane)
	 * @return <code>true</code> if any vehicle is in front of the current vehicle, <code>false</code> otherwise
	 */
	public static boolean isOtherVehicleBeforeJunction(Vehicle vehicle, VehiclesLane baseLane) {
		JunctionWithDistance nextJunction = RoadUtil.getNextJunction(baseLane.getRoadSegment());
		if (nextJunction != null && nextJunction.getJunction() != null) {
			return isOtherVehicleBeforeJunction(vehicle, nextJunction.getJunction(), baseLane);
		}
		return false;
	}

	/**
	 * Gets the total number of lanes for the given list of road segments, expect for the segment identified by the given id.
	 *
	 * @param roadSegments
	 *            the list of road segments to obtain the lane count from
	 * @param exceptRoutingId
	 *            the identifier of the road segment to be left out when adding up the number of lanes
	 * @return the total lane count of all provided road segments
	 */
	public static int totalLaneCount(Collection<RoadSegment> roadSegments, long exceptRoutingId) {
		int sum = 0;

		for (RoadSegment roadSegment : roadSegments) {
			if (roadSegment.getRoutingId() != exceptRoutingId) {
				sum += roadSegment.getLaneCount();
			}
		}

		return sum;
	}

	/**
	 * Determines whether the given angle difference constitutes to a turn to the left.
	 *
	 * @param angleDifference
	 *            the angle difference in radians
	 * @return true if the angle difference constitutes to a turn to the left - false else
	 */
	public static boolean turnsLeft(double angleDifference) {
		return angleDifference > Math.PI * 1 / 5 && angleDifference < Math.PI * 4 / 5;
	}

	/**
	 * Determines whether the given road geometry turns to the left.
	 *
	 * @param geom
	 *            the geometry to be validated
	 * @return true if the geometry turns to the left - false else
	 */
	public static boolean turnsLeft(RoadGeometry geom) {
		double diff = SpatialUtil.getAngleDifference(geom, true);
		return turnsLeft(diff);
	}

	/**
	 * Determines whether the given angle difference constitutes to a turn to the right.
	 *
	 * @param angleDifference
	 *            the angle difference in radians
	 * @return true if the angle difference constitutes to a turn to the right - false else
	 */
	public static boolean turnsRight(double angleDifference) {
		return angleDifference > Math.PI * 6 / 5 && angleDifference < Math.PI * 9 / 5;
	}

	/**
	 * Returns the current road segment or junction id of the as string with RS# or J# prefix.
	 *
	 * @param v
	 *            the vehicle
	 * @return the number of the {@link RoadSegment} or {@link AbstractJunction}, or "?" string if not found
	 */
	public static String getRoadSegOrJunctionId(Vehicle v) {
		return v.getRoadSegment() != null ? "RS#" + v.getRoadSegment().getId() : v.getJunction() != null ? "J#" + v.getJunction().getId() : "?";
	}
}
package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.batch;

import java.io.File;
import java.util.ArrayList;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;

import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.util.StringUtil;

public class BatchFileSelectionPage extends WizardPage {

	protected BatchFileSelectionPage() {
		super("Batch file selection");
		setTitle("Batch file selection");
		setDescription("Select configurations which should be loaded and simulated one after the other");
	}

	private java.util.List<File> selectedFiles = new ArrayList<>();

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(2, false));

		final List list = new List(container, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI);
		list.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 4));

		Button btnAdd = new Button(container, SWT.NONE);
		btnAdd.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(Display.getCurrent().getActiveShell(), SWT.MULTI);
				dialog.setText("Open configuration files");
				dialog.setFilterExtensions(new String[] { Constants.FILE_FILTER_TRAFFSIM_XML });
				dialog.setFilterNames(new String[] { Constants.FILTER_NAME_TRAFFSIM });
				dialog.open();
				for (String selected : dialog.getFileNames()) {
					if (StringUtil.isNotNullOrEmpty(selected)) {
						File f = new File(dialog.getFilterPath(), selected);
						selectedFiles.add(f);
						list.add(f.getAbsolutePath());
						list.select(list.getItemCount() - 1);
					}
				}
				getWizard().getContainer().updateButtons();
			}
		});
		btnAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnAdd.setText("Add");

		Button btnDuplicate = new Button(container, SWT.NONE);
		btnDuplicate.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				for (String s : list.getSelection()) {
					selectedFiles.add(new File(s));
					list.add(s);
					getWizard().getContainer().updateButtons();
				}
			}
		});
		btnDuplicate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btnDuplicate.setText("Duplicate");

		Button btnRemove = new Button(container, SWT.NONE);
		btnRemove.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				for (String s : list.getSelection()) {
					selectedFiles.remove(new File(s));
					list.deselect(list.indexOf(s));
					list.remove(s);
					getWizard().getContainer().updateButtons();
				}
			}
		});
		btnRemove.setLayoutData(new GridData(SWT.FILL, SWT.TOP, false, false, 1, 1));
		btnRemove.setText("Remove");
		setControl(container);

		Button btnRemoveAll = new Button(container, SWT.NONE);
		btnRemoveAll.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				list.removeAll();
				selectedFiles.clear();
				getWizard().getContainer().updateButtons();
			}
		});
		btnRemoveAll.setLayoutData(new GridData(SWT.FILL, SWT.TOP, false, false, 1, 1));
		btnRemoveAll.setText("Remove all");

		final Button btnMergeGeneratedStatistics = new Button(container, SWT.CHECK);
		btnMergeGeneratedStatistics.setSelection(PreferenceUtil.getBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_BATCH));
		btnMergeGeneratedStatistics.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				PreferenceUtil.setBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_BATCH, btnMergeGeneratedStatistics.getSelection());
				PreferenceUtil.setBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_EACH_SIMULATION,
						!btnMergeGeneratedStatistics.getSelection());
			}
		});
		btnMergeGeneratedStatistics.setText("Merge generated statistics after batch execution by MATLAB");
		new Label(container, SWT.NONE);
	}

	public java.util.List<File> getSelectedFiles() {
		return selectedFiles;
	}

	@Override
	public boolean isPageComplete() {
		return !selectedFiles.isEmpty();
	}

}

package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Table;

import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.IRoute;
import at.fhhagenberg.mc.traffsim.statistics.events.CongestionEvent;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.ui.Constants;
import at.fhhagenberg.mc.traffsim.ui.IRouteProvider;
import at.fhhagenberg.mc.traffsim.ui.IRouteUpdateListener;
import at.fhhagenberg.mc.traffsim.util.RoutingUtil;
import at.fhhagenberg.mc.util.CollectionUtil;
import at.fhhagenberg.mc.util.DateUtil;

public class EventLogView extends DebugMonitorView implements IRouteProvider {

	protected List<IRoute> selectedRoutes;
	private IRouteUpdateListener routeUpdateListener;

	@Override
	protected Table createTable(TableViewer viewer) {
		Table table = viewer.getTable();

		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectedRoutes = new ArrayList<>();
				for (Object o : viewer.getStructuredSelection().toList()) {
					if (o instanceof Event) {
						Event ev = (Event) o;
						if (ev.getType() == EventType.ROUTE_UPDATED || ev.getType() == EventType.ROUTE_UDPATED_REACTIVE
								|| ev.getType() == EventType.ROUTE_UPDATED_PREDICTIVE) {
							selectedRoutes.addAll(RoutingUtil.parseRoutesFromEvent(ev.getDetails()));
						}
					}
				}
				notifySelectionUpdated();
			}
		});

		return table;
	}

	protected void notifySelectionUpdated() {
		if (routeUpdateListener != null) {
			routeUpdateListener.routesUpdated(selectedRoutes);
		}
	}

	@Override
	protected List<String> getCsvHeaders() {
		return CollectionUtil.toArrayList("ID", "Type", "Time", "Details", "Cong. Node", "Cong. Seg.", "Severity", "Predicted Time");
	}

	@Override
	protected String getCsvFileName() {
		return "events_" + currentModel.getDescription() + ".csv";
	}

	@Override
	protected void processCustomEvents(List<String> line, Event event) {
		if (event instanceof CongestionEvent) {
			CongestionEvent cev = (CongestionEvent) event;
			line.add(cev.getNodeId() + "");
			line.add(cev.getSegmentId() + "");
			line.add(cev.getSeverity() + "");
			line.add(DateUtil.format(cev.getPrediction()));
		}
	}

	@Override
	protected void createSpecificColumns(int columnIndex) {
		TableViewerColumn colSegmentId = createTableViewerColumn(viewer, "Congested Segment", 80, columnIndex++);
		colSegmentId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (element instanceof CongestionEvent) {
					CongestionEvent e = (CongestionEvent) element;
					return String.valueOf(e.getSegmentId());
				}
				return Constants.EMPTY_STRING;
			}
		});

		TableViewerColumn colNodeId = createTableViewerColumn(viewer, "Congested Node", 80, columnIndex++);
		colNodeId.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (element instanceof CongestionEvent) {
					CongestionEvent e = (CongestionEvent) element;
					return String.valueOf(e.getNodeId());
				}
				return Constants.EMPTY_STRING;
			}
		});

		TableViewerColumn colSeverity = createTableViewerColumn(viewer, "Severity", 80, columnIndex++);
		colSeverity.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				if (element instanceof CongestionEvent) {
					CongestionEvent e = (CongestionEvent) element;
					return String.valueOf(e.getSeverity());
				}
				return Constants.EMPTY_STRING;
			}
		});
	}

	@Override
	protected void addEventListener(SimulationModel model) {
		if (model != null && model.getEventLog() != null) {
			model.getEventLog().addEventListener(this);
		}
	}

	@Override
	protected void removeEventListener() {
		if (currentModel != null && currentModel.getEventLog() != null) {
			currentModel.getEventLog().removeEventListener(this);
		}
	}

	@Override
	protected List<Event> getEvents(SimulationModel model) {
		if (model == null || model.getEventLog() == null) {
			return new ArrayList<>();
		}

		return model.getEventLog().getEvents();
	}

	@Override
	public List<IRoute> getAvailableRoutes() {
		return selectedRoutes;
	}

	@Override
	public List<IRoute> getAllRoutes() {
		return selectedRoutes;
	}

	@Override
	public String getName() {
		return "Eventlog";
	}

	@Override
	public void setUpdateListener(IRouteUpdateListener listener) {
		this.routeUpdateListener = listener;
	}

	@Override
	public boolean isInitialized() {
		return true;
	}
}
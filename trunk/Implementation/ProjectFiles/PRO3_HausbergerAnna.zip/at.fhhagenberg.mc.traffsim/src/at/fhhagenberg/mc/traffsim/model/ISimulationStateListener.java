package at.fhhagenberg.mc.traffsim.model;

public interface ISimulationStateListener {

	/**
	 * Called after simulation state changed, immediately before
	 * {@link #simulationStateChanged(SimulationModel, SimulationState, SimulationState)}
	 * 
	 * @param model
	 *            the model for which the state has changed
	 * @param oldState
	 * @param newState
	 */
	public default void preSimulationStateChanged(final SimulationModel model, final SimulationState oldState,
			final SimulationState newState) {
	};

	/**
	 * Called as soon as simulation state changes
	 * 
	 * @param model
	 *            the model for which the state has changed
	 * @param oldState
	 * @param newState
	 */
	public void simulationStateChanged(final SimulationModel model, final SimulationState oldState, final SimulationState newState);

	/**
	 * Called after simulation state changed, immediately after
	 * {@link #simulationStateChanged(SimulationModel, SimulationState, SimulationState)}
	 * 
	 * @param model
	 *            the model for which the state has changed
	 * @param oldState
	 * @param newState
	 */
	public default void postSimulationStateChanged(final SimulationModel model, final SimulationState oldState,
			final SimulationState newState) {
	};

}

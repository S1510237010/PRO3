package at.fhhagenberg.mc.traffsim.ui.rcp.views;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.model.IItemSelectionListener;
import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.traffsim.model.SimulationObserver;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.ui.rcp.IModelInputChangedListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.util.CollectionUtil;

public class SelectionDetailsView extends ViewPart implements IModelInputChangedListener, IItemSelectionListener {
	/** view id as defined in manifest */
	public static final String ID = "at.fhhagenberg.mc.traffsim.views.statistics.selectiondetails";
	private SimulationModel currentModel;
	private Text textStartIds;
	private Text textEndIds;
	private Text textRoutingIds;
	private Text textSegmentIds;
	private Text textVehIds;
	private Text textAvgSpeed;
	private Text textVehLabels;
	private Group grpCurrentData;
	private Label lblTotal;
	private Text textCurTotal;
	private Label lblRoutable;
	private Text textCurRoutable;
	private Label lblUnroutable;
	private Text textCurUnroutable;
	private Group grpOverallVehiclesAmount;
	private Label label;
	private Text textOverallTotal;
	private Label label_1;
	private Text textOverallRoutable;
	private Label label_2;
	private Text textOverallUnroutable;
	private Group grpEnteredVehicles;
	private Label lblAmount;
	private Text textEnteredAmount;
	private Label lblVehicles_1;
	private Text textEnteredVehicles;
	private Group grpSelection;

	public SelectionDetailsView() {
		SimulationKernel.getInstance().addInputChangedListener(this);
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		grpCurrentData = new Group(parent, SWT.NONE);
		grpCurrentData.setLayout(new GridLayout(6, false));
		grpCurrentData.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpCurrentData.setText("Current Vehicles Amount (including generated, excluding left vehicles)");

		lblTotal = new Label(grpCurrentData, SWT.NONE);
		lblTotal.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblTotal.setText("Total");

		textCurTotal = new Text(grpCurrentData, SWT.BORDER);
		textCurTotal.setEditable(false);
		textCurTotal.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		lblRoutable = new Label(grpCurrentData, SWT.NONE);
		lblRoutable.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRoutable.setText("Routable");

		textCurRoutable = new Text(grpCurrentData, SWT.BORDER);
		textCurRoutable.setEditable(false);
		textCurRoutable.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		lblUnroutable = new Label(grpCurrentData, SWT.NONE);
		lblUnroutable.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblUnroutable.setText("Unroutable");

		textCurUnroutable = new Text(grpCurrentData, SWT.BORDER);
		textCurUnroutable.setEditable(false);
		textCurUnroutable.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		grpOverallVehiclesAmount = new Group(parent, SWT.NONE);
		grpOverallVehiclesAmount.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		grpOverallVehiclesAmount.setText("Overall Vehicles Amount (including generated and already left vehicles)");
		grpOverallVehiclesAmount.setLayout(new GridLayout(6, false));

		label = new Label(grpOverallVehiclesAmount, SWT.NONE);
		label.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		label.setText("Total");

		textOverallTotal = new Text(grpOverallVehiclesAmount, SWT.BORDER);
		textOverallTotal.setEditable(false);
		textOverallTotal.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		label_1 = new Label(grpOverallVehiclesAmount, SWT.NONE);
		label_1.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		label_1.setText("Routable");

		textOverallRoutable = new Text(grpOverallVehiclesAmount, SWT.BORDER);
		textOverallRoutable.setEditable(false);
		textOverallRoutable.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		label_2 = new Label(grpOverallVehiclesAmount, SWT.NONE);
		label_2.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		label_2.setText("Unroutable");
		textOverallUnroutable = new Text(grpOverallVehiclesAmount, SWT.BORDER);
		textOverallUnroutable.setEditable(false);
		textOverallUnroutable.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		grpEnteredVehicles = new Group(parent, SWT.NONE);
		grpEnteredVehicles.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		grpEnteredVehicles.setText("Entered Vehicles (all visible vehicles, excluding generated but not yet entered and already left)");
		grpEnteredVehicles.setLayout(new GridLayout(2, false));

		lblAmount = new Label(grpEnteredVehicles, SWT.NONE);
		lblAmount.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblAmount.setText("Amount");

		textEnteredAmount = new Text(grpEnteredVehicles, SWT.BORDER);
		textEnteredAmount.setEditable(false);
		textEnteredAmount.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		lblVehicles_1 = new Label(grpEnteredVehicles, SWT.NONE);
		lblVehicles_1.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblVehicles_1.setText("Vehicles");

		textEnteredVehicles = new Text(grpEnteredVehicles, SWT.BORDER);
		textEnteredVehicles.setEditable(false);
		textEnteredVehicles.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		// currentModel.getSimObserver().get

		grpSelection = new Group(parent, SWT.NONE);
		grpSelection.setLayout(new GridLayout(2, false));
		grpSelection.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		grpSelection.setText("Selection");

		Label lblRoadsegmentIds = new Label(grpSelection, SWT.NONE);
		lblRoadsegmentIds.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRoadsegmentIds.setText("RoadSegment IDs");

		textSegmentIds = new Text(grpSelection, SWT.BORDER);
		textSegmentIds.setEditable(false);
		textSegmentIds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblStartRoadSegment = new Label(grpSelection, SWT.NONE);
		lblStartRoadSegment.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblStartRoadSegment.setText("Start RoadSegment IDs");

		textStartIds = new Text(grpSelection, SWT.BORDER);
		textStartIds.setEditable(false);
		textStartIds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblEndRoadsegmentIds = new Label(grpSelection, SWT.NONE);
		lblEndRoadsegmentIds.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblEndRoadsegmentIds.setText("End RoadSegment IDs");

		textEndIds = new Text(grpSelection, SWT.BORDER);
		textEndIds.setEditable(false);
		textEndIds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblRoutingIds = new Label(grpSelection, SWT.NONE);
		lblRoutingIds.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRoutingIds.setText("Routing IDs");

		textRoutingIds = new Text(grpSelection, SWT.BORDER);
		textRoutingIds.setEditable(false);
		textRoutingIds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblVehicles = new Label(grpSelection, SWT.NONE);
		lblVehicles.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblVehicles.setText("Vehicle IDs");

		textVehIds = new Text(grpSelection, SWT.BORDER);
		textVehIds.setEditable(false);
		textVehIds.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblVehicleLabels = new Label(grpSelection, SWT.NONE);
		lblVehicleLabels.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblVehicleLabels.setText("Vehicle Labels");

		textVehLabels = new Text(grpSelection, SWT.BORDER);
		textVehLabels.setEditable(false);
		textVehLabels.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblAvgVehicleSpeed = new Label(grpSelection, SWT.NONE);
		lblAvgVehicleSpeed.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblAvgVehicleSpeed.setText("Avg. Vehicle Speed");

		textAvgSpeed = new Text(grpSelection, SWT.BORDER);
		textAvgSpeed.setEditable(false);
		textAvgSpeed.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

	}

	public void setFocus() {
		// unused

	}

	@Override
	public void inputChanged(SimulationModel newModel) {
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
		}
		if (newModel != null) {
			newModel.addItemSelectionListener(this);
		}
		currentModel = newModel;
	}

	@Override
	public void dispose() {
		SimulationKernel.getInstance().removeInputChangedListener(this);
		if (currentModel != null) {
			currentModel.removeItemSelectionListener(this);
			currentModel = null;
		}
		super.dispose();
	}

	@Override
	public void itemsSelected(List<AbstractJunction> junctions, List<JunctionConnector> connectors, List<RoadSegment> roadSegments,
			List<LaneSegment> laneSegments, List<Vehicle> vehicles) {
		if (!roadSegments.isEmpty()) {
			updateView(roadSegments, vehicles);
		}
	}

	private void updateView(List<RoadSegment> roadSegments, List<Vehicle> vehicles) {
		final List<Long> routingIds = new ArrayList<>();
		final List<Long> startIds = new ArrayList<>();
		final List<Long> endIds = new ArrayList<>();
		final List<Long> segmentIds = new ArrayList<>();
		for (RoadSegment rs : roadSegments) {
			if (rs.getStartNode().isSourceDeadEnd()) {
				startIds.add(rs.getId());
			}
			if (rs.getEndNode().isSinkDeadEnd()) {
				endIds.add(rs.getId());
			}
			if (!routingIds.contains(rs.getRoutingId())) {
				routingIds.add(rs.getRoutingId());
			}
			if (!segmentIds.contains(rs.getRoutingId())) {
				segmentIds.add(rs.getId());
			}
		}
		final List<Long> vehIds = new ArrayList<>();
		final List<String> vehLbls = new ArrayList<>();
		double speedSum = 0;
		for (Vehicle v : vehicles) {
			vehIds.add(v.getUniqueId());
			vehLbls.add(v.getLabel());
			speedSum += v.getCurrentSpeed();
		}
		SimulationObserver simObs = currentModel.getSimObserver();
		final List<Long> enteredVehIds = new ArrayList<>(simObs.getEnteredVehicles().size());
		for (Vehicle v : simObs.getEnteredVehicles()) {
			enteredVehIds.add(v.getUniqueId());
		}
		final double speedAvg = vehicles.size() == 0 ? 0 : speedSum / vehicles.size();
		final String SEPARATOR = ",";
		getSite().getShell().getDisplay().asyncExec(new Runnable() {

			@Override
			public void run() {
				textStartIds.setText(CollectionUtil.toString(startIds, SEPARATOR));
				textEndIds.setText(CollectionUtil.toString(endIds, SEPARATOR));
				textRoutingIds.setText(CollectionUtil.toString(routingIds, SEPARATOR));
				textSegmentIds.setText(CollectionUtil.toString(segmentIds, SEPARATOR));
				textVehIds.setText(CollectionUtil.toString(vehIds, SEPARATOR));
				textVehLabels.setText(CollectionUtil.toString(vehLbls, SEPARATOR));
				textAvgSpeed.setText(String.format("%.6f m/s  (%.6f km/h)", speedAvg, speedAvg * 3.6));
				textCurRoutable.setText(simObs.getCurNumRoutableVehicles() + "");
				textCurUnroutable.setText(simObs.getCurNumUnroutableVehicles() + "");
				textCurTotal.setText(simObs.getCurNumVehicles() + "");
				textOverallTotal.setText(simObs.getTotalNumRoutableVehicles() + simObs.getTotalNumUnroutableVehicles() + "");
				textOverallRoutable.setText(simObs.getTotalNumRoutableVehicles() + "");
				textOverallUnroutable.setText(simObs.getTotalNumUnroutableVehicles() + "");
				textEnteredAmount.setText(simObs.getEnteredVehicles().size() + "");
				textEnteredVehicles.setText(CollectionUtil.toString(enteredVehIds, SEPARATOR));
			}
		});
	}
}

package at.fhhagenberg.mc.traffsim.routing.rerouter;

import java.util.List;

import at.fhhagenberg.mc.traffsim.model.SimulationModel;
import at.fhhagenberg.mc.util.CollectionUtil;

/**
 * 
 * @author Christian Backfrieder
 * 
 */
public class ReRouter extends AbstractReRouter {

	private static final String REROUTER_NAME = "Std";
	private ICongestionProvider congestionProvider;

	/**
	 * 
	 * @param name
	 *            The name of the thread
	 * @param updateIntervalMillis
	 *            the update interval, in simulation time
	 * @param model
	 *            the model to use
	 * @param provider
	 *            a congestion provider to be used
	 */
	public ReRouter(String name, long updateIntervalMillis, SimulationModel model, ICongestionProvider provider) {
		super(name, updateIntervalMillis, model);
		this.congestionProvider = provider;
	}

	@Override
	public void doSynchronizedWork() {
		if (!simulateReRouting) {
			performStandardReRoute();
		}
	}

	@Override
	protected List<ICongestionProvider> getStandardCongestionProviders() {
		return CollectionUtil.createArrayList(congestionProvider);
	}

	@Override
	protected String getReRouterName() {
		return REROUTER_NAME;
	}

	@Override
	public String getCommReceiverName() {
		return "Std Rerouter";
	}
}

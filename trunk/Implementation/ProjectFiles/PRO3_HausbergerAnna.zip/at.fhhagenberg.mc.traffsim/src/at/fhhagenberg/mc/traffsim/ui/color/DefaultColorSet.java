package at.fhhagenberg.mc.traffsim.ui.color;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Stroke;

import at.fhhagenberg.mc.traffsim.ui.Matrix;

/**
 * A default color set, which can be extended for modifications
 * 
 * @author Christian
 * 
 */
public class DefaultColorSet extends ColorSet {
	protected final Color background = new Color(210, 255, 210);
	protected Color streetBackground = new Color(195, 195, 195);
	protected Color streetMiddle = new Color(0, 0, 128);

	public Color getColor(IElement element) {
		switch (element) {
		case STREET_BACKGROUND:
			return streetBackground;
		case STANDSTILL:
			return Color.WHITE;
		case ACCELERATE:
			return Color.GREEN;
		case BACKGROUND:
			return background;
		case BREAK:
			return Color.RED;
		case CAR:
			return Color.BLUE;
		case CAR_EDGE:
			return Color.BLACK;
		case CAR_EDGE_PLATOON:
			return Color.MAGENTA;
		case CROSSING_FONT_PRIMARY:
			return Color.BLACK;
		case CROSSING_FONT_SECONDARY:
			return Color.GRAY;
		case INSERT_BACKGROUND:
			return Color.WHITE;
		case INSERT_FONT:
			return Color.BLACK;
		case ROAD_MIDDLE:
			return streetMiddle;
		case STREET_EDGE:
			return Color.BLACK;
		case STREET_GROUND_MARKINGS:
			return Color.WHITE;
		case CROSSING_BORDER:
			return Color.BLACK;
		case CRITICAL_ACC:
			return Color.YELLOW;
		case ROAD_SIGN_STAND:
			return Color.BLACK;
		case MARKER:
			return Color.RED;
		case DETECTOR:
			return Color.DARK_GRAY;
		default:
			return Color.BLACK;

		}
	}

	@Override
	public Stroke getStroke(IElement stroke, Matrix matrix) {
		switch (stroke) {
		case STANDSTILL:
			break;
		case ACCELERATE:
			break;
		case BACKGROUND:
			break;
		case BREAK:
			break;
		case CAR:
			break;
		case CAR_EDGE:
			break;
		case CRITICAL_ACC:
			break;
		case CROSSING_BORDER:
			break;
		case CROSSING_FONT_PRIMARY:
			break;
		case CROSSING_FONT_SECONDARY:
			break;
		case INSERT_BACKGROUND:
			break;
		case INSERT_FONT:
			break;
		case ROAD_MIDDLE:
			break;
		case STREET_BACKGROUND:
			break;
		case STREET_EDGE:
			return new BasicStroke((float) matrix.getScaleFactor() / 3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
		case STREET_GROUND_MARKINGS:
			float scaleFactor = (float) matrix.getScaleFactor();
			return new BasicStroke(0.5f * scaleFactor, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, new float[] { 3 * scaleFactor },
					0f);
		case ROAD_SIGN_STAND:
			return new BasicStroke((float) matrix.getScaleFactor() / 5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
		default:
			break;

		}
		return new BasicStroke();
	}
}

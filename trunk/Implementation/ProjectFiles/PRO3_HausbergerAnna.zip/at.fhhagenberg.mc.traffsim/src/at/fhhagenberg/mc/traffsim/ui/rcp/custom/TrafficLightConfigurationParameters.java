package at.fhhagenberg.mc.traffsim.ui.rcp.custom;

import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightControllers;

public class TrafficLightConfigurationParameters {
	public TrafficLightControllers controlMode;
	public boolean mergeApproaches;
	public long interGreenTime;
	public long yellowTime;
	public long redYellowTime;
}

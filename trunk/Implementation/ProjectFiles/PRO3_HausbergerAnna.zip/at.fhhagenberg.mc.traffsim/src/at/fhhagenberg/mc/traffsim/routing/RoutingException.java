package at.fhhagenberg.mc.traffsim.routing;

public class RoutingException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6012144809380319144L;

	public RoutingException(String message) {
		super(message);
	}

}

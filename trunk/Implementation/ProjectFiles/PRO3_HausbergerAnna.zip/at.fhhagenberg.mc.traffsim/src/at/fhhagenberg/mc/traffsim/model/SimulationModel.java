package at.fhhagenberg.mc.traffsim.model;

import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;

import at.fhhagenberg.mc.traffsim.ISimulationTimeUpdatable;
import at.fhhagenberg.mc.traffsim.communication.Communicator;
import at.fhhagenberg.mc.traffsim.communication.ObservationCenter;
import at.fhhagenberg.mc.traffsim.crashdetector.ActionOnCrash;
import at.fhhagenberg.mc.traffsim.crashdetector.CrashDetector;
import at.fhhagenberg.mc.traffsim.crashdetector.ICrashListener;
import at.fhhagenberg.mc.traffsim.data.DataLoader;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.traffsim.deadlock.ActionOnDeadlock;
import at.fhhagenberg.mc.traffsim.deadlock.DeadlockDetector;
import at.fhhagenberg.mc.traffsim.deadlock.IDeadlockListener;
import at.fhhagenberg.mc.traffsim.generator.AbstractVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.PredefinedVehicleGenerator;
import at.fhhagenberg.mc.traffsim.generator.TrafficObstructionGenerator;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.log.Logger;
import at.fhhagenberg.mc.traffsim.model.geo.Location;
import at.fhhagenberg.mc.traffsim.model.init.ParameterParser;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadNetwork;
import at.fhhagenberg.mc.traffsim.roadnetwork.RoadSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.VehicleProcessor;
import at.fhhagenberg.mc.traffsim.roadnetwork.detector.LoopDetector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.AbstractJunction;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionConnector;
import at.fhhagenberg.mc.traffsim.roadnetwork.junction.JunctionLogCacheCleaner;
import at.fhhagenberg.mc.traffsim.roadnetwork.lane.LaneSegment;
import at.fhhagenberg.mc.traffsim.roadnetwork.route.RouteRegistry;
import at.fhhagenberg.mc.traffsim.routing.AbstractMultithreadedRouteService;
import at.fhhagenberg.mc.traffsim.routing.DefaultRouteService;
import at.fhhagenberg.mc.traffsim.routing.KSPRouteService;
import at.fhhagenberg.mc.traffsim.routing.rerouter.AbstractCostEvaluator;
import at.fhhagenberg.mc.traffsim.routing.rerouter.AbstractReRouter;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ICongestionProvider;
import at.fhhagenberg.mc.traffsim.routing.rerouter.ReRouter;
import at.fhhagenberg.mc.traffsim.routing.rerouter.TimeDynamicReRouter;
import at.fhhagenberg.mc.traffsim.routing.rerouter.footprint.RoadFootprintGenerator;
import at.fhhagenberg.mc.traffsim.routing.rerouter.footprint.TimeDynamicFootprintGenerator;
import at.fhhagenberg.mc.traffsim.statistics.DetailedStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.DetectorStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.DistractionOutlineStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.IConvertableStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.IThreadInfoListener;
import at.fhhagenberg.mc.traffsim.statistics.JunctionDetailsStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.JunctionOutlineStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.ModelInputStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.OutlineStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.RerouterStatisticsCollector;
import at.fhhagenberg.mc.traffsim.statistics.Statistics;
import at.fhhagenberg.mc.traffsim.statistics.events.CongestionEvent;
import at.fhhagenberg.mc.traffsim.statistics.events.Event;
import at.fhhagenberg.mc.traffsim.statistics.events.EventLog;
import at.fhhagenberg.mc.traffsim.statistics.events.EventType;
import at.fhhagenberg.mc.traffsim.statistics.events.IEventLog;
import at.fhhagenberg.mc.traffsim.ui.UiModel;
import at.fhhagenberg.mc.traffsim.ui.controller.TraffSimController;
import at.fhhagenberg.mc.traffsim.ui.preferences.IPreferenceConstants;
import at.fhhagenberg.mc.traffsim.ui.rcp.TraffSimCorePlugin;
import at.fhhagenberg.mc.traffsim.ui.rcp.views.SimulationView;
import at.fhhagenberg.mc.traffsim.util.ConfigDirFileFilter;
import at.fhhagenberg.mc.traffsim.util.CoordinateUtil;
import at.fhhagenberg.mc.traffsim.util.PreferenceUtil;
import at.fhhagenberg.mc.traffsim.util.PropertyUtil;
import at.fhhagenberg.mc.traffsim.util.RoadUtil;
import at.fhhagenberg.mc.traffsim.util.types.GeneralFilesFilter;
import at.fhhagenberg.mc.traffsim.vehicle.BlinkerUpdater;
import at.fhhagenberg.mc.traffsim.vehicle.IVehicleGeneratorListener;
import at.fhhagenberg.mc.traffsim.vehicle.Vehicle;
import at.fhhagenberg.mc.traffsim.vehicle.model.ModelRegistry;
import at.fhhagenberg.mc.traffsim.vehicle.model.distraction.DistractionModel;
import at.fhhagenberg.mc.traffsim.vehicle.model.platoon.PlatoonManager;
import at.fhhagenberg.mc.util.DateUtil;
import at.fhhagenberg.mc.util.FileUtil;
import at.fhhagenberg.mc.util.StringUtil;
import at.fhhagenberg.mc.util.types.IDisposable;
import matlabcontrol.MatlabConnectionException;
import matlabcontrol.MatlabInvocationException;

public class SimulationModel implements ICrashListener, ISimulationFinishedListener, IEventLog, ISimulationTimeProvider, IDeadlockListener {
	private List<String> auxLabels;

	/** in batch mode, no user interactions are performed, just run through */
	private boolean batchMode = false;
	private IThreadInfoListener cpuStatsCollector;
	private CrashDetector crashDetector;
	private DeadlockDetector deadlockDetector;
	private boolean crashFlag;
	private boolean deadLockFlag;
	private SimulationState currentState = SimulationState.INITIAL;
	private String description;
	private TimeDynamicFootprintGenerator dynamicFootprintGenerator;
	private EventLog eventLog;
	private RoadFootprintGenerator footprintGenerator;

	private File graphFile;

	/**
	 * file which is created in output folder to mark incomplete simulations. It is deleted after successful finished sims
	 */
	private File incompleteIdentifierFile;

	/** The loaded configuration of this simulation, for later use */
	private File inputFile;

	private String longDescription;

	private ModelRegistry modelRegistry = new ModelRegistry();

	private RoadNetwork network;

	private int crashCount;

	private OutlineStatisticsCollector outlineStatisticsCollector;
	private File outputFolder;

	private String parameterSetLabel;

	private Set<Long> removedRoutingIds;

	private AbstractReRouter reRouter;

	private boolean restartFlag;

	private RouteRegistry routeRegistry = new RouteRegistry();
	private AbstractMultithreadedRouteService routeService;

	private List<Vehicle> selectedVehicles;
	private Set<IItemSelectionListener> selectionListeners = new HashSet<>();

	private SimulationObserver simObserver;

	private Properties simParameters;

	private SimulationRun simulationRun;

	private Set<ISimulationStateListener> simulationStateListeners = new HashSet<>();

	private boolean simulationStopped = false;

	private Date startDate;

	private Statistics statistics = new Statistics(this);

	private List<AbstractVehicleGenerator> trafficGenerators;

	private UiModel uiModel;

	private String uniqueId;

	private VehicleProcessor vehicleProcessor;

	private DistractionModel distractionModel;

	private VehicleUpdater vehicleUpdater;

	private PlatoonManager platoonManager;

	private SimulationView view;

	/**
	 * all background worker threads, which are paused on simulation pause and stopped when simulation is finished
	 */
	private List<PauseableThread> workerThreads = new CopyOnWriteArrayList<>();

	private TraffSimController controller;

	private Communicator communicator;

	private ObservationCenter observationCenter = new ObservationCenter(this);

	private String restartReason = "";

	private List<IDisposable> disposables = new ArrayList<>();

	private List<IConvertableStatisticsCollector> statisticsCollectors = new ArrayList<>();

	/**
	 * Standard constructor
	 *
	 * @param uniqueId
	 *            a string id, which must not be null and must be unique within all {@link SimulationModel} ids
	 */
	public SimulationModel(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	/**
	 * @param simParameters
	 *            the simulation properties assigned with this simulation
	 */
	public void setSimParameters(Properties simParameters) {
		this.simParameters = simParameters;
	}

	public void setDistractionModel(DistractionModel model) {
		distractionModel = model;
	}

	public DistractionModel getDistractionModel() {
		return distractionModel;
	}

	public void addItemSelectionListener(IItemSelectionListener listener) {
		this.selectionListeners.add(listener);
	}

	public void addRemovedRoutingId(long id) {
		removedRoutingIds.add(id);
		routeService.removedRoutingIdsChanged(removedRoutingIds);
	}

	public void addSimulationStateListener(ISimulationStateListener listener) {
		this.simulationStateListeners.add(listener);
	}

	public void addSimulationTimeUpdatable(ISimulationTimeUpdatable updateable) {
		this.simulationRun.addSimulationTimeUpdatable(updateable);
	}

	public void removeSimulationTimeUpdatable(ISimulationTimeUpdatable updateable) {
		this.simulationRun.removeSimulationTimeUpdatable(updateable);
	}

	@Override
	public void crashDetected(final Vehicle v1, final Vehicle v2) {
		final Location wgs84 = CoordinateUtil.toWGS84Coordinate(v1.getAbsolutePosition());
		final String message = String.format(
				"Vehicle %s (located at %s, lane %d) crashed into %s (located at %s, lane %d) at position %.2f/%.2f (%.3f/%.3f)", v1.getLabel(),
				RoadUtil.getRoadSegOrJunctionId(v1), v1.getLaneIndex(), v2.getLabel(), RoadUtil.getRoadSegOrJunctionId(v2), v2.getLaneIndex(),
				v1.getAbsolutePosition().x, v1.getAbsolutePosition().y, wgs84.y, wgs84.x);
		Logger.logWarn(message);
		logEvent(EventType.CRASH, message);

		int action = PreferenceUtil.getInt(IPreferenceConstants.ACTION_ON_CRASH);

		if (action == ActionOnCrash.OPEN_POPUP.ordinal()) {
			setSimulationRunning(false);
			Display.getDefault().asyncExec(new Runnable() {

				@Override
				public void run() {

					boolean result = MessageDialog.openQuestion(Display.getDefault().getActiveShell(), "Crash detected",
							message + "\n\nZoom to crash location");

					if (result) {
						uiModel.zoomTo(v1.getAbsolutePosition());
					}
				}
			});
		} else if (action == ActionOnCrash.STOP_SIMULATION.ordinal() || action == ActionOnCrash.RESTART.ordinal()
				|| action == ActionOnCrash.TAG_AND_CONTINUE.ordinal()) {
			// start new thread to avoid blocking of CrashDetector
			if (action == ActionOnCrash.RESTART.ordinal()) {
				restartFlag = true;
				restartReason = "Crash";
				Logger.logInfo("Trying to restart simulation after crash");
			}

			if (action == ActionOnCrash.TAG_AND_CONTINUE.ordinal()) {
				crashFlag = true;
				Logger.logInfo("Crash detected. Create statistics and continue with batch execution (if required)");
			}

			new Thread("Simulation Stopper") {

				@Override
				public void run() {
					stopSimulation(batchMode, action == ActionOnCrash.TAG_AND_CONTINUE.ordinal());
				}

			}.start();
		} else if (action == ActionOnCrash.REMOVE_PARTICIPANTS.ordinal()) {
			Logger.logInfo("Crash detected. Remove involved vehicles from simulation");

			// Remove involved vehicles from the simulation
			v1.setJunction(null);
			v1.getLaneSegment().getVehicles().remove(v1);
			v1.setRoadSegment(null);
			v1.setWasInvolvedInCollision(true);

			v2.setJunction(null);
			v2.getLaneSegment().getVehicles().remove(v2);
			v2.setRoadSegment(null);
			v2.setWasInvolvedInCollision(true);

			v1.notifyListenersVehicleLeft();
			v2.notifyListenersVehicleLeft();

			crashCount++;
		}
	}

	public int getCrashCount() {
		return crashCount;
	}

	public List<String> getAuxLabels() {
		return auxLabels;
	}

	public double getCpuTime() {
		return cpuStatsCollector != null ? cpuStatsCollector.getCpuTime() : 0;
	}

	@Override
	public Date getCurrentSimTime() {
		return simulationRun != null ? simulationRun.getCurrentSimTime() : null;
	}

	public SimulationState getCurrentState() {
		return currentState;
	}

	public String getDescription() {
		return description;
	}

	public TimeDynamicFootprintGenerator getDynamicFootprintGenerator() {
		return dynamicFootprintGenerator;
	}

	public EventLog getEventLog() {
		return eventLog;
	}

	public double getFootprint(long roadSegmentId) {
		return footprintGenerator != null ? footprintGenerator.getCost(roadSegmentId) : Double.NaN;
	}

	/**
	 * Returns the configuration file with which this simulation was initialized
	 *
	 * @return the input configuration {@link File}
	 */
	public File getInputFile() {
		return inputFile;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public ModelRegistry getModelRegistry() {
		return modelRegistry;
	}

	public RoadNetwork getNetwork() {
		return network;
	}

	public int getNumRoutesPassingSeg(long roadSegmentId) {
		return footprintGenerator != null ? (int) footprintGenerator.getVehicleCount(roadSegmentId) : 0;
	}

	public File getOutputFolder() {
		return outputFolder;
	}

	public PredefinedVehicleGenerator getPredefinedVehicleGenerator() {
		if (trafficGenerators == null || trafficGenerators.isEmpty()) {
			return null;
		}

		for (AbstractVehicleGenerator trafficGenerator : trafficGenerators) {
			if (trafficGenerator instanceof PredefinedVehicleGenerator) {
				return (PredefinedVehicleGenerator) trafficGenerator;
			}
		}

		return null;
	}

	public Set<Long> getRemovedRoutingIds() {
		return removedRoutingIds;
	}

	public int getSimulationResolution() {
		if (simulationRun == null) {
			return 0;
		}

		return simulationRun.getResolution();
	}

	public RouteRegistry getRouteRegistry() {
		return routeRegistry;
	}

	public AbstractMultithreadedRouteService getRouteService() {
		return routeService;
	}

	public long getRunningRealtimeMillis() {
		return simulationRun.getRunningRealtimeMillis();
	}

	public List<Vehicle> getSelectedVehicles() {
		return selectedVehicles;
	}

	public Properties getSimulationParameters() {
		return simParameters;
	}

	public SimulationObserver getSimObserver() {
		return simObserver;
	}

	public double getSimRuntimeSeconds() {
		return simulationRun.getRunningSimtimeSeconds();
	}

	public long getSimRuntimeMilliseconds() {
		return simulationRun.getRunningSimtimeMilliseconds();
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getStartSimTime() {
		return simulationRun.getStartSimTime();
	}

	public Statistics getStatistics() {
		return statistics;
	}

	public void addTrafficGenerator(AbstractVehicleGenerator generator) {
		if (generator != null && !trafficGenerators.contains(generator)) {
			trafficGenerators.add(generator);
		}
	}

	public void removeTrafficGenerator(AbstractVehicleGenerator generator) {
		if (generator != null && trafficGenerators.contains(generator)) {
			trafficGenerators.remove(generator);
		}
	}

	public List<AbstractVehicleGenerator> getTrafficGenerators(boolean includeObstructionGenerators) {

		if (includeObstructionGenerators) {
			return trafficGenerators;
		}

		List<AbstractVehicleGenerator> generators = new ArrayList<>();

		for (AbstractVehicleGenerator generator : trafficGenerators) {
			if (generator instanceof TrafficObstructionGenerator) {
				continue;
			}

			generators.add(generator);
		}

		return generators;
	}

	public UiModel getUiModel() {
		return uiModel;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public File getGraphFile() {
		return graphFile;
	}

	public VehicleProcessor getVehicleProcessor() {
		return vehicleProcessor;
	}

	public PlatoonManager getPlatoonManager() {
		return this.platoonManager;
	}

	public Collection<Vehicle> getVehiclesInSimulation(boolean onlyRoutable) {
		return Collections.unmodifiableCollection(simObserver.getVehiclesInSimulation(onlyRoutable));
	}

	public SimulationView getView() {
		return view;
	}

	/**
	 *
	 * @param view
	 *            the one {@link SimulationView} which is connected with this model
	 */
	public void initView(SimulationView view) {
		this.view = view;
		uiModel = new UiModel(view, this);
		controller = new TraffSimController(uiModel);
		view.init(uiModel, this, controller);
	}

	public boolean isRestartFlag() {
		return restartFlag;
	}

	public String resetRestartReason() {
		String temp = restartReason;
		restartReason = "";
		return temp;
	}

	public boolean isSimulationRunning() {
		return simulationRun != null && simulationRun.isSimulationRunning();
	}

	/**
	 * Load the data beans and process them using the provided {@link DataLoader}. Sets also descriptions and input file of
	 * {@link SimulationModel}
	 *
	 * @param loader
	 * @param monitor
	 * @param loadingOptions
	 * @throws LoadingException
	 */
	public void loadData(DataLoader loader, IProgressMonitor monitor, final Properties loadingOptions) throws LoadingException {
		notifyNewState(SimulationState.LOADING);
		File f = loader.getConfigurationFile();
		this.inputFile = f;

		longDescription = f.getAbsolutePath() + ", parameters: " + parameterSetLabel;

		description = StringUtil.shorten(FileUtil.removeTempFileExtension(f.getAbsolutePath()), 10, 40) + ", parameters: " + parameterSetLabel;

		// init communicator here, because it is already used e.g. when creating vehicles
		communicator = new Communicator(getUniqueId(), "Communicator " + uniqueId, 250);

		loader.loadBeans(f, monitor);
		loader.loadConfiguration(this, monitor, loadingOptions);
	}

	public void initData(DataLoader loader, IProgressMonitor monitor, final Properties loadingOptions, int simulationIdentifier) {
		view.setDescriptionString(uniqueId + " | " + description);
		view.setNameString(
				"Sim #" + uniqueId + " [Set " + PropertyUtil.getStringProperty(simParameters, PropertyKeys.PARAMETERSET_ID, "<unknown>") + "]");

		if (simulationIdentifier < 0) {
			outputFolder = new File(loader.getOutputFolder(),
					PropertyUtil.getStringProperty(simParameters, PropertyKeys.SIMULATION_SET_SUBFOLDER, ""));
		} else {
			outputFolder = new File(loader.getOutputFolder(),
					PropertyUtil.getStringProperty(simParameters, PropertyKeys.SIMULATION_SET_SUBFOLDER, "") + "_no" + simulationIdentifier);
		}

		network = loader.getRoadNetwork();
		vehicleUpdater = new VehicleUpdater(network);

		simObserver = new SimulationObserver(this);
		simObserver.setFinishedListener(this);
		uiModel.setSimulationObserver(simObserver);

		graphFile = loader.getGraphFile();
		removedRoutingIds = loader.getOldRoutingIds();

		auxLabels = loader.getAuxLabels();

		crashDetector = new CrashDetector("CrashDetector " + uniqueId, 457);
		crashDetector.addCrashListener(this);
		workerThreads.add(crashDetector);

		deadlockDetector = new DeadlockDetector("DeadlockDetector " + uniqueId, TimeUnit.MINUTES.toMillis(1), simObserver);
		deadlockDetector.addDeadlockListener(this);
		workerThreads.add(deadlockDetector);

		JunctionLogCacheCleaner junctionLogCacheCleaner = new JunctionLogCacheCleaner("Junction LogCache Cleaner " + uniqueId, 5000, network);
		workerThreads.add(junctionLogCacheCleaner);

		boolean collectJunctionOutlineStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS);
		boolean collectDetectorStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DETECTOR_STATISTICS);

		vehicleProcessor = new VehicleProcessor(this);

		communicator.registerCommunicationReceiver(observationCenter);
		boolean commDelayEnabled = PropertyUtil.getBooleanProperty(simParameters, PropertyKeys.COMM_DELAY_ENABLED,
				PropertyValues.DEFAULT_COMM_DELAY_ENABLED);
		communicator.setDelayEnabled(commDelayEnabled);
		if (commDelayEnabled) {
			workerThreads.add(communicator);
		}

		int resolution = PropertyUtil.getIntProperty(simParameters, PropertyKeys.SIMULATION_RESOLUTION_MS,
				PreferenceUtil.getInt(IPreferenceConstants.SIMULATION_RESOLUTION_MS));
		int delay = PropertyUtil.getIntProperty(simParameters, PropertyKeys.SIMULATION_DELAY_MS,
				PreferenceUtil.getInt(IPreferenceConstants.SIMULATION_DELAY_MS));

		view.updateResolutionAndDelay(resolution, delay);
		simulationRun = new SimulationRun("SimulationRunnable " + uniqueId, loader.getStartTime(), resolution, delay);

		boolean distractionsEnabled = PreferenceUtil.getBoolean(IPreferenceConstants.DISTRACTION_MODEL_ACTIVE);

		if (distractionsEnabled && distractionModel != null) {
			simulationRun.addSimulationTimeUpdatable(distractionModel);
		}

		if (PreferenceUtil.getBoolean(IPreferenceConstants.BOUND_SIMULATION_RUNTIME)) {
			simulationRun.setSimulationFinishedListener(this);
		}

		simulationRun.addSimulationTimeUpdatable(vehicleProcessor);
		simulationRun.addSimulationTimeUpdatable(vehicleUpdater);

		boolean collectStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_STATISTICS);
		boolean collectOutlineStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS);
		boolean collectModelInputStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS);
		boolean collectJunctionDetailStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DETAILED_JUNCTION_STATISTICS);
		boolean collectDistractionOutlineStatistics = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DISTRACTION_STATISTICS);

		if (collectStatistics) {
			DetailedStatisticsCollector detailedStatisticsCollector = new DetailedStatisticsCollector("Detailed Statistics Collector " + uniqueId,
					this, 5000, PropertyUtil.getBooleanProperty(loadingOptions, PropertyKeys.BATCH_EXECUTION, Boolean.TRUE));
			workerThreads.add(detailedStatisticsCollector);
			simulationRun.addSimulationTimeUpdatable(detailedStatisticsCollector);
			statisticsCollectors.add(detailedStatisticsCollector);
		}

		if (collectOutlineStatistics) {
			boolean recIntervalEnabled = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS_INTERVAL_ENABLED);
			outlineStatisticsCollector = new OutlineStatisticsCollector("OutlineStatisticsCollector " + uniqueId, this,
					recIntervalEnabled ? PreferenceUtil.getInt(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS_INTERVAL) : 0);
			if (!outlineStatisticsCollector.isStopped()) {
				workerThreads.add(outlineStatisticsCollector);
				simulationRun.addSimulationTimeUpdatable(outlineStatisticsCollector);
			}
			statisticsCollectors.add(outlineStatisticsCollector);
		}

		if (collectModelInputStatistics) {
			ModelInputStatisticsCollector modelInputStatisticsCollector = new ModelInputStatisticsCollector("Model Statistics Writer " + uniqueId,
					this, 5000, PropertyUtil.getBooleanProperty(loadingOptions, PropertyKeys.BATCH_EXECUTION, Boolean.TRUE));
			workerThreads.add(modelInputStatisticsCollector);
			simulationRun.addSimulationTimeUpdatable(modelInputStatisticsCollector);
			statisticsCollectors.add(modelInputStatisticsCollector);
		}

		if (collectJunctionOutlineStatistics) {
			JunctionOutlineStatisticsCollector junctionOutlineStatisticsCollector = new JunctionOutlineStatisticsCollector(
					"Junction Statistics Collector " + uniqueId, this, 5000);
			workerThreads.add(junctionOutlineStatisticsCollector);
			simulationRun.addSimulationTimeUpdatable(junctionOutlineStatisticsCollector);
			statisticsCollectors.add(junctionOutlineStatisticsCollector);
		}

		if (collectDistractionOutlineStatistics) {
			DistractionOutlineStatisticsCollector distractionStatisticsCollector = new DistractionOutlineStatisticsCollector(
					"Distraction Statistics Collector " + uniqueId, this, 5000);
			workerThreads.add(distractionStatisticsCollector);
			simulationRun.addSimulationTimeUpdatable(distractionStatisticsCollector);
			statisticsCollectors.add(distractionStatisticsCollector);
		}

		if (collectDetectorStatistics) {
			DetectorStatisticsCollector detectorStatisticsCollector = new DetectorStatisticsCollector("Detector Statistics Collector " + uniqueId,
					this, 5000, PropertyUtil.getBooleanProperty(loadingOptions, PropertyKeys.BATCH_EXECUTION, Boolean.TRUE));
			workerThreads.add(detectorStatisticsCollector);
			simulationRun.addSimulationTimeUpdatable(detectorStatisticsCollector);
			statisticsCollectors.add(detectorStatisticsCollector);
			if (network != null) {
				List<LoopDetector> detectors = network.getLoopDetectors();

				if (detectors != null && !detectors.isEmpty()) {
					for (LoopDetector detector : detectors) {
						if (!detector.getIsAssociatedToQueueMonitor()) {
							detector.addDataListener(detectorStatisticsCollector);
						}
					}
				}
			}
		}

		if (collectJunctionDetailStatistics) {
			JunctionDetailsStatisticsCollector junctionDetailsStatisticsCollector = new JunctionDetailsStatisticsCollector(
					"Junction Details Statistics Collector " + uniqueId, this, 5000,
					PropertyUtil.getBooleanProperty(loadingOptions, PropertyKeys.BATCH_EXECUTION, Boolean.TRUE));
			workerThreads.add(junctionDetailsStatisticsCollector);
			simulationRun.addSimulationTimeUpdatable(junctionDetailsStatisticsCollector);
			statisticsCollectors.add(junctionDetailsStatisticsCollector);
		}

		if (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_CPU_STATISTICS)) {
			cpuStatsCollector = new RerouterStatisticsCollector(uniqueId);
			SimulationKernel.getInstance().getThreadInfoUpdater().addPatternListener(cpuStatsCollector);
		}

		eventLog = new EventLog("Event Log " + uniqueId, 200);
		workerThreads.add(eventLog);

		BlinkerUpdater blinkerUpdater = new BlinkerUpdater("Direction Indicator Updater " + uniqueId, 400);
		workerThreads.add(blinkerUpdater);

		trafficGenerators = loader.getTrafficGenerators();

		if (trafficGenerators != null) {
			for (AbstractVehicleGenerator trafficGenerator : trafficGenerators) {
				trafficGenerator.addVehicleObserver(crashDetector);
				trafficGenerator.addVehicleObserver(simObserver);
				trafficGenerator.addVehicleObserver(blinkerUpdater);

				if (trafficGenerator instanceof TrafficObstructionGenerator) {
					((TrafficObstructionGenerator) trafficGenerator).addObstructionObserver(crashDetector);
				} else {
					if (distractionsEnabled && distractionModel != null) {
						trafficGenerator.addVehicleObserver(distractionModel);

						if (trafficGenerator instanceof PredefinedVehicleGenerator) {
							distractionModel.initialize(((PredefinedVehicleGenerator) trafficGenerator).getInitialVehicles());
						}
					}
				}

				if (collectOutlineStatistics) {
					trafficGenerator.addVehicleObserver(outlineStatisticsCollector);
				}

				for (IConvertableStatisticsCollector coll : statisticsCollectors) {
					if (coll instanceof IVehicleGeneratorListener) {
						trafficGenerator.addVehicleObserver((IVehicleGeneratorListener) coll);
					}
				}
				trafficGenerator.setSimulationModel(this);
				simulationRun.addSimulationTimeUpdatable(trafficGenerator);
			}
		}

		String reroutingMode = PropertyUtil.getStringProperty(simParameters, PropertyKeys.REROUTING_MODE, PropertyValues.REROUTING_MODE_SINGLE);

		if (!reroutingMode.equals(PropertyValues.DISABLED)) {
			String footprintHeuristicMode = PropertyUtil.getStringProperty(simParameters, PropertyKeys.REROUTING_FOOTPRINT_HEURISTICS,
					PropertyValues.UNDEFINED);
			if (footprintHeuristicMode.equals(PropertyValues.REROUTING_HEURISTICS_ROUTE_FOOTPRINT)) {
				int weight = PropertyUtil.getIntProperty(simParameters, PropertyKeys.REROUTING_FOOTPRINT_HEURISTICS_ROUTE_WEIGHT,
						PropertyValues.DEFAULT_REROUTING_HEURISTICS_ROUTE_FOOTPRINT_WEIGHT);
				footprintGenerator = new RoadFootprintGenerator(this, weight);
			}
			if (!footprintHeuristicMode.equals(PropertyValues.DISABLED)) {
				dynamicFootprintGenerator = new TimeDynamicFootprintGenerator(this, 5,
						PropertyUtil.getIntProperty(simParameters, PropertyKeys.REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_TIME_RESOLUTION,
								PropertyValues.DEFAULT_REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_TIME_RESOLUTION),
						PropertyUtil.getIntProperty(simParameters, PropertyKeys.REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_MAX_FORECAST,
								PropertyValues.DEFAULT_REROUTING_HEURISTICS_FOOTPRINT_PREDICTION_MAX_FORECAST),
						PropertyUtil.getDoubleProperty(simParameters, PropertyKeys.CONGESTION_THRESHOLD_VEHICLES_PER_SECOND,
								PropertyValues.DEFAULT_CONGESTION_THRESHOLD_VEHICLES_PER_SECOND));
			}

			if (reroutingMode.equals(PropertyValues.REROUTING_MODE_SINGLE) || reroutingMode.equals(PropertyValues.REROUTING_MODE_TIME_DYNAMIC)) {
				routeService = new DefaultRouteService(graphFile, removedRoutingIds);
			} else if (reroutingMode.equals(PropertyValues.REROUTING_MODE_KSP)) {
				routeService = new KSPRouteService(graphFile, removedRoutingIds,
						PropertyUtil.getIntProperty(simParameters, PropertyKeys.KSP_VALUE_K, PropertyValues.DEFAULT_KSP_VALUE_K), network,
						dynamicFootprintGenerator);
			}

			ParameterParser parser = new ParameterParser(this, simParameters);
			ICongestionProvider congProv = null;
			AbstractCostEvaluator costEval = null;
			try {
				congProv = parser.getCongProv();
				costEval = parser.getCostEval();
			} catch (LoadingException e) {
				Logger.logError(e.getMessage());
				return;
			}

			if (costEval != null) {
				if (footprintGenerator != null) {
					costEval.addCostProvider(footprintGenerator);
				}

				if (PropertyUtil.getStringProperty(simParameters, PropertyKeys.REROUTING_MODE, PropertyValues.DISABLED)
						.equals(PropertyValues.REROUTING_MODE_TIME_DYNAMIC)) {
					double timeThresholdDynamic = PropertyUtil.getDoubleProperty(simParameters, PropertyKeys.REROUTING_THRESHOLD_TIME_DYNAMIC,
							PropertyValues.DEFAULT_REROUTING_THRESHOLD_TIME_DYNAMIC);
					double distanceThresholdDynamic = PropertyUtil.getDoubleProperty(simParameters, PropertyKeys.REROUTING_THRESHOLD_DISTANCE_DYNAMIC,
							PropertyValues.DEFAULT_REROUTING_THRESHOLD_DISTANCE_DYNAMIC);
					reRouter = new TimeDynamicReRouter("TimeDynamic ReRouter " + uniqueId,
							PropertyUtil.getIntProperty(simParameters, PropertyKeys.REROUTING_UPDATE_TIME,
									PropertyValues.DEFAULT_REROUTING_UPDATE_TIME),
							this, getDynamicFootprintGenerator(), timeThresholdDynamic, distanceThresholdDynamic, PropertyUtil.getBooleanProperty(
									simParameters, PropertyKeys.AVOID_MULTI_REROUTES, PropertyValues.DEFAULT_AVOID_MULTI_REROUTES));
					if (PropertyUtil.getStringProperty(simParameters, PropertyKeys.USE_TIME_DYNAMIC_CONGESTION_EXTENSION, PropertyValues.DISABLED)
							.equals(PropertyValues.ENABLED)) {
						((TimeDynamicReRouter) reRouter).addCongestionProvider(congProv);
					}

				} else {
					reRouter = new ReRouter("ReRouter " + uniqueId, PropertyUtil.getIntProperty(simParameters, PropertyKeys.REROUTING_UPDATE_TIME,
							PropertyValues.DEFAULT_REROUTING_UPDATE_TIME), this, congProv);
				}

				reRouter.setTimeCostThresholdFactor(PropertyUtil.getDoubleProperty(simParameters, PropertyKeys.REROUTING_THRESHOLD_TIME,
						TrafficDefaults.DEFAULT_REROUTING_THRESHOLD_TIME));
				reRouter.setDistanceCostThresholdFactor(PropertyUtil.getDoubleProperty(simParameters, PropertyKeys.REROUTING_THRESHOLD_DISTANCE,
						TrafficDefaults.DEFAULT_REROUTING_THRESHOLD_DISTANCE));

				if (PropertyUtil.getBooleanProperty(simParameters, PropertyKeys.REROUTING_SIMULATION_ONLY, Boolean.FALSE)) {
					reRouter.setSimulateReRouting(true);
				}

				workerThreads.add(reRouter);
				simulationRun.addSimulationTimeUpdatable(reRouter);

				workerThreads.add(costEval);
				simulationRun.addSimulationTimeUpdatable(costEval);
			}
		} else {
			Logger.logInfo("Rerouting disabled");
		}

		// TODO add parameter for enabling platooning

		this.platoonManager = loader.getPlatoonManager();

		// add to disposables, which are disposed in order!
		disposables.add(simulationRun);

		if (reRouter != null) {
			disposables.add(reRouter);
		}

		if (routeService != null) {
			disposables.add(routeService);
		}

		disposables.add(communicator);
		disposables.addAll(trafficGenerators);

		simulationRun.addSimulationTimeUpdatable(uiModel);
		simulationRun.addSimulationTimeUpdatable(crashDetector);
		simulationRun.addSimulationTimeUpdatable(deadlockDetector);
		simulationRun.addSimulationTimeUpdatable(statistics);

		if (commDelayEnabled) {
			simulationRun.addSimulationTimeUpdatable(communicator);
		}

		if (this.platoonManager != null) {
			platoonManager.setSimulationObserver(simObserver);
			simulationRun.addSimulationTimeUpdatable(platoonManager);
		}

		uiModel.zoomToFit();
		notifyNewState(SimulationState.LOADED);
		monitor.done();
	}

	public DataLoader loadDataWithProgressMonitorDialog(DataLoader loader, final Properties loadingOptions, int simulationIdentifier) {
		Job job = new Job("Loading model " + uniqueId) {
			@Override
			protected IStatus run(IProgressMonitor monitor) {
				try {
					loadData(loader, monitor, loadingOptions);
				} catch (final LoadingException e) {
					Logger.logError(e.getMessage(), e);
					stopSimulation(true, false);
					SimulationKernel.getInstance().doClose(uniqueId, true);
					return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, "Could not load file " + loader.getConfigurationFile(), e);
				}
				initData(loader, monitor, loadingOptions, simulationIdentifier);
				return Status.OK_STATUS;
			}
		};
		job.setUser(true);
		job.schedule();
		try {
			job.join();
		} catch (InterruptedException e1) {
			Logger.logError("Waiting for loading of simulation #" + simulationIdentifier + " failed", e1);
		}
		return loader;
	}

	@Override
	public void logCongestion(EventType type, String typeInfo, String message, long nodeId, long segId, double severity) {
		logCongestion(type, typeInfo, message, nodeId, segId, severity, null);
	}

	public void logCongestion(EventType type, String typeInfo, String message, long nodeId, long segId, double severity, Date prediction) {
		logEvent(new CongestionEvent(uniqueId, getCurrentSimTime(), type, typeInfo, message, nodeId, segId, severity, prediction));
	}

	@Override
	public void logEvent(Event event) {
		event.setLogDate(getCurrentSimTime());
		eventLog.logEvent(event);
	}

	@Override
	public void logEvent(EventType type, String typeInfo, String details) {
		logEvent(new Event(uniqueId, getCurrentSimTime(), type, typeInfo, details, true));
	}

	/**
	 * Log event and append vehicle id and label to details
	 *
	 * @param type
	 * @param v
	 * @param details
	 */
	public void logEvent(EventType type, Vehicle v, String details) {
		logEvent(buildEvent(type, v, details));
	}

	public Event buildEvent(EventType type, Vehicle v, String details) {
		details = String.format("#%05d (%s) %s", v.getUniqueId(), v.getLabel(), details);
		return new Event(uniqueId, getCurrentSimTime(), type, v.getLabel(), details, true);
	}

	private void notifyNewState(final SimulationState newState) {
		List<ISimulationStateListener> listenersCopy = new ArrayList<>(simulationStateListeners);
		for (final ISimulationStateListener l : listenersCopy) {
			l.preSimulationStateChanged(this, currentState, newState);
		}

		for (final ISimulationStateListener l : listenersCopy) {
			l.simulationStateChanged(this, currentState, newState);
		}

		for (final ISimulationStateListener l : listenersCopy) {
			l.postSimulationStateChanged(this, currentState, newState);
		}

		currentState = newState;
	}

	public void registerVehicleObserver(IVehicleGeneratorListener generatorListener) {
		if (trafficGenerators != null) {
			for (AbstractVehicleGenerator trafficGenerator : trafficGenerators) {
				trafficGenerator.addVehicleObserver(generatorListener);
			}
		} else {
			Logger.logWarn("No traffic generators found");
		}
	}

	public void removeItemSelectionListener(IItemSelectionListener listener) {
		this.selectionListeners.remove(listener);
	}

	public void removeSimulationStateListener(ISimulationStateListener listener) {
		this.simulationStateListeners.remove(listener);
	}

	public void selectedItems(List<Vehicle> selectedVehicles, List<RoadSegment> selectedRoadSegments, List<LaneSegment> selectedLaneSegments,
			List<AbstractJunction> selectedJunctions, List<JunctionConnector> selectedJunctionConnectors) {
		this.selectedVehicles = selectedVehicles;
		for (IItemSelectionListener isl : selectionListeners) {
			isl.itemsSelected(selectedJunctions, selectedJunctionConnectors, selectedRoadSegments, selectedLaneSegments, selectedVehicles);
		}
	}

	public void setBatchMode(boolean batchMode) {
		this.batchMode = batchMode;
	}

	public void setDelay(int value) {
		simulationRun.setDelay(value);
	}

	public void setParameterSetLabel(String label) {
		this.parameterSetLabel = label;
	}

	public String getParameterSetLabel() {
		return parameterSetLabel;
	}

	public void setResolution(int value) {
		simulationRun.setResolution(value);
	}

	public void setSimulationRunning(boolean setRunning) {
		setSimulationRunning(setRunning, true);
	}

	public void setSimulationRunning(boolean setRunning, boolean avoidPausedEvent) {
		// bring view to front if simulation is starting and not already in
		// front
		if (setRunning) {
			IWorkbenchPart activePart = view.getViewSite().getWorkbenchWindow().getActivePage().getActivePart();
			if (activePart != null && !activePart.equals(view)) {
				view.getViewSite().getShell().getDisplay().asyncExec(new Runnable() {

					@Override
					public void run() {
						try {
							view.getViewSite().getWorkbenchWindow().getActivePage().showView(SimulationView.ID, uniqueId,
									IWorkbenchPage.VIEW_ACTIVATE);
						} catch (PartInitException e) {
							Logger.logWarn("Could not bring view " + uniqueId + " to foreground");
						}
					}
				});
			}
		}
		if (simulationRun == null) {
			return;
		}
		simulationRun.setSimulationRunning(setRunning);
		if (setRunning) {
			if (currentState == SimulationState.LOADED) {
				startDate = new Date();
				outputFolder.mkdirs();
				try {
					FileUtils.writeStringToFile(new File(outputFolder, "TraffSim_version_" + DateUtil.formatForFile(startDate) + ".txt"),
							SimulationKernel.getTraffSimVersionInfo());
				} catch (IOException e1) {
					Logger.logError("unable to create traffsim-version file", e1);
				}
				incompleteIdentifierFile = new File(outputFolder, "INCOMPLETE_" + DateUtil.formatForFile(startDate));
				try {
					incompleteIdentifierFile.createNewFile();
				} catch (IOException e) {
					Logger.logWarn("Could not create incomplete identifier file");
				}
				notifyNewState(SimulationState.STARTED);
				for (PauseableThread t : workerThreads) {
					t.start();
				}
			} else {
				notifyNewState(SimulationState.CONTINUED);
			}
			for (PauseableThread t : workerThreads) {
				t.proceed();
			}
		} else {
			if (!avoidPausedEvent) {
				notifyNewState(SimulationState.PAUSED);
			}
			for (PauseableThread t : workerThreads) {
				t.pause();
			}
		}
	}

	@Override
	public void simulationFinished() {
		stopSimulation(false, true);
	}

	/**
	 * Stops the simulation
	 *
	 * @param terminateUiThread
	 *            also terminate the UI thread, which means that no interactions (Scrolling etc.) are possible any more. <br>
	 *            if set to false, just the ui thread is kept alive
	 * @param successfullyFinished
	 *            set to <code>true</code> if the simulation was finished successfully and has not been canceled by the user
	 */
	public void stopSimulation(boolean terminateUiThread, boolean successfullyFinished) {
		if (successfullyFinished && !incompleteIdentifierFile.delete()) {
			Logger.logWarn("Failed to delete incomplete file " + incompleteIdentifierFile.getAbsolutePath());
		}

		if (!simulationStopped) {
			setSimulationRunning(false, true);
			notifyNewState(SimulationState.ENDED);

			for (IDisposable d : disposables) {
				d.dispose();
			}
			disposables.clear();

			for (PauseableThread pt : workerThreads) {
				pt.stopAndDestroy(false);
			}
			workerThreads.clear();

			if (crashDetector != null) {
				crashDetector.removeCrashListener(this);
			}

			if (deadlockDetector != null) {
				deadlockDetector.removeDeadlockListener(this);
			}

			if (uiModel != null) {
				uiModel.setSimulationObserver(null);
			}

			view = null;

			// delete results if canceled manually
			if (!successfullyFinished) {
				if (PreferenceUtil.getBoolean(IPreferenceConstants.DELETE_CANCELED_SIMULATION_RESULTS) && outputFolder != null
						&& outputFolder.exists()) {
					try {
						Logger.logInfo("Deleting output files of canceled simulation in " + outputFolder.getAbsolutePath());
						GeneralFilesFilter filter = new GeneralFilesFilter(DateUtil.formatForFile(startDate));
						Collection<File> simFiles = FileUtils.listFilesAndDirs(outputFolder, filter, filter);
						simFiles.remove(outputFolder);
						for (File f : simFiles) {
							if (f.isDirectory()) {
								FileUtils.deleteDirectory(f);
							} else {
								f.delete();
							}
						}
					} catch (IOException e) {
						Logger.logWarn("Could not delete output folder ", e);

					}
				}

				simulationStopped = true;
			} else {
				final String date = DateUtil.formatForFile(startDate);

				if (PreferenceUtil.getBoolean(IPreferenceConstants.COPY_CONFIG_TO_OUTPUT)) {
					final DataSerializer ser = new DataSerializer();
					ser.readConfiguration(inputFile);
					String configIdentifier = "config_" + date;
					FileFilter filter = new ConfigDirFileFilter(ser);
					File configOutputDir = new File(outputFolder, configIdentifier);
					if (configOutputDir.exists() || configOutputDir.mkdirs()) {
						try {
							if (PreferenceUtil.getBoolean(IPreferenceConstants.COMPRESS_CONFIG_IN_OUTPUT)) {
								File zipFile = new File(configOutputDir, configIdentifier + ".zip");
								FileUtil.zipFile(inputFile.getParentFile().listFiles(filter), zipFile);

							} else {
								FileUtils.copyDirectory(inputFile.getParentFile(), configOutputDir, filter);
							}

							// add additional information
							simParameters.setProperty(IPreferenceConstants.SIMULATION_RESOLUTION_MS.toLowerCase(), "" + getSimulationResolution());
							simParameters.setProperty(IPreferenceConstants.SIMULATION_DELAY_MS.toLowerCase(), "" + simulationRun.getDelay());

							String origPath = SimulationKernel.getInstance().getTempToOriginalFileMapping().get(inputFile) != null
									? SimulationKernel.getInstance().getTempToOriginalFileMapping().get(inputFile).getAbsolutePath()
									: inputFile.getAbsolutePath();

							FileOutputStream fos = new FileOutputStream(new File(configOutputDir, "usedParameters.properties"));
							simParameters.store(fos, "Simulation parameters for " + origPath);
							fos.close();
						} catch (IOException e) {
							Logger.logError("Error during copying of simulation info to " + outputFolder.getAbsolutePath());
						}
					} else {
						Logger.logError("Could not create output directory");
					}
				}

				// convert statistics
				if (simulationRun != null && simulationRun.getRunningSimtimeSeconds() > 0
						&& (PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_ROAD_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DETECTOR_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_JUNCTION_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DETAILED_JUNCTION_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_DISTRACTION_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_MODEL_INPUT_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_OUTLINE_VEHICLE_STATISTICS)
								|| PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_CPU_STATISTICS))) {

					Job job = Job.create("Conversion of statistics to MAT file (model #" + uniqueId + ")", monitor -> {
						try {
							IStatus status = Status.OK_STATUS;
							for (IConvertableStatisticsCollector coll : statisticsCollectors) {
								if (!monitor.isCanceled() && status.isOK()) {
									coll.convertStatistics(outputFolder, date, true, monitor, crashFlag, deadLockFlag);
								}
							}
							monitor.done();
							return status;
						} catch (IOException e) {
							String msg = "File I/O error. Cannot convert cache to MAT-file";
							Logger.logError(msg, e);
							return new Status(Status.ERROR, TraffSimCorePlugin.PLUGIN_ID, msg);
						}
					});

					job.setUser(true);
					job.schedule();
					// wait for job to be finished
					try {
						job.join();
					} catch (InterruptedException e) {
						Logger.logError("Could not finish conversion of statistics caches", e);
					}

					AtomicBoolean userAnswer = new AtomicBoolean(true);
					final boolean matlabConversion = PreferenceUtil.getBoolean(IPreferenceConstants.MERGE_MATLAB_FILES_AFTER_EACH_SIMULATION);
					boolean recordVStat = PreferenceUtil.getBoolean(IPreferenceConstants.RECORD_VEHICLE_STATISTICS);
					if (!batchMode) {
						userAnswer.set(false);
						Display.getDefault().syncExec(new Runnable() {

							@Override
							public void run() {
								boolean answer = MessageDialog.openQuestion(Display.getDefault().getActiveShell(), "Simulation finished",
										"The current simulation has finished!\n\nSimulation time: "
												+ DateUtil.getTimeSpan(simulationRun.getRunningSimtimeSeconds())
												+ "\n\nDo you want to convert the statistics now?\nHint: Automatic Batch-conversion to matlab is "
												+ (matlabConversion ? "ENABLED" : "DISABLED") + " in preferences");
								userAnswer.set(answer);
							}
						});
					}
					String matlabPath = PreferenceUtil.getString(IPreferenceConstants.MATLAB_PATH);
					if (recordVStat && StringUtil.isNotNullOrEmpty(matlabPath) && userAnswer.get() && matlabConversion) {
						Job matConvertJob = new Job("Conversion of statistics to MAT-file") {
							@Override
							protected IStatus run(IProgressMonitor monitor) {
								try {
									SimulationKernel.getInstance().mergeFilesInMatlab(matlabPath, getOutputFolder(),
											PreferenceUtil.getBoolean(IPreferenceConstants.MATLAB_DELETE_FILES_AFTER_MERGE));
								} catch (MatlabInvocationException | MatlabConnectionException | IOException e) {
									return new Status(IStatus.ERROR, TraffSimCorePlugin.PLUGIN_ID,
											"Matlab files could not be merged: " + e.getMessage());
								}
								return Status.OK_STATUS;
							}
						};

						matConvertJob.setUser(true);
						matConvertJob.schedule();
						try {
							matConvertJob.join();
						} catch (InterruptedException e) {
							Logger.logWarn("Waiting for matlab conversion failed: " + e.getMessage());
						}
					}

					simulationStopped = true;
				}
			}

			if (PreferenceUtil.getBoolean(IPreferenceConstants.CLEAR_OUTPUT_FOLDER_AFTER_SIMULATION_FINISH)) {
				String date = DateUtil.formatForFile(startDate);
				IOFileFilter filter = new WildcardFileFilter("*" + date + "*");
				Collection<File> files = FileUtils.listFilesAndDirs(outputFolder, filter, filter);
				files.remove(outputFolder); // bizarrely, the output folder is contained in the returned list
				files.forEach(f -> {
					if (f.exists())
						FileUtils.deleteQuietly(f);
				});
			}

			notifyNewState(successfullyFinished ? SimulationState.COMPLETED : SimulationState.ABORTED);

			statisticsCollectors.clear();
			outlineStatisticsCollector = null;

			statistics.reset();
			SimulationKernel.getInstance().getThreadInfoUpdater().removePatternListener(cpuStatsCollector);
		}

		if (terminateUiThread && uiModel != null) {
			uiModel.stop();
			// remove assignment to ui related classes to avoid memory leak by dangling SimulationModel reference
			controller = null;
			uiModel = null;
		}
	}

	public void unregisterVehicleGeneratorListener(IVehicleGeneratorListener generatorListener) {
		for (AbstractVehicleGenerator trafficGenerator : trafficGenerators) {
			trafficGenerator.removeVehicleObserver(generatorListener);
		}
	}

	public Communicator getCommunicator() {
		return communicator;
	}

	public ObservationCenter getObservationCenter() {
		return observationCenter;
	}

	public OutlineStatisticsCollector getOutlineStatisticsCollector() {
		return outlineStatisticsCollector;
	}

	@Override
	public void deadlockDetected() {
		String message = "Deadlock detected";
		Logger.logWarn(message);
		logEvent(EventType.DEADLOCK, message);

		int action = PreferenceUtil.getInt(IPreferenceConstants.ACTION_ON_DEADLOCK);

		if (action == ActionOnDeadlock.OPEN_POPUP.ordinal()) {
			setSimulationRunning(false);
			Display.getDefault().asyncExec(new Runnable() {

				@Override
				public void run() {
					MessageDialog.openWarning(Display.getDefault().getActiveShell(), "Deadlock detected", message);
				}
			});
		} else if (action == ActionOnDeadlock.STOP_SIMULATION.ordinal() || action == ActionOnDeadlock.RESTART.ordinal()
				|| action == ActionOnDeadlock.TAG_AND_CONTINUE.ordinal()) {
			// start new thread to avoid blocking of CrashDetector
			if (action == ActionOnDeadlock.RESTART.ordinal()) {
				restartFlag = true;
				restartReason = "Deadlock";
				Logger.logInfo("Trying to restart simulation after deadlock");
			}

			if (action == ActionOnDeadlock.TAG_AND_CONTINUE.ordinal()) {
				deadLockFlag = true;
				Logger.logInfo("Deadlock detected. Create statistics and continue with batch execution (if required)");
			}

			new Thread("Simulation Stopper (Deadlock)") {

				@Override
				public void run() {
					stopSimulation(batchMode, action == ActionOnDeadlock.TAG_AND_CONTINUE.ordinal());
				}

			}.start();
		}

	}

	public Set<ISimulationStateListener> getSimulationStateListeners() {
		return simulationStateListeners;
	}

	public long getSimulationDelay() {
		return simulationRun.getDelay();
	}

	public boolean isLoaded() {
		return network != null;
	}
}

package at.fhhagenberg.mc.traffsim.ui.rcp.wizards.junction;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeType;
import at.fhhagenberg.mc.traffsim.kernel.SimulationKernel;
import at.fhhagenberg.mc.traffsim.roadnetwork.regulation.trafficlights.control.TrafficLightControllers;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.CyclicRegulationConfigurationControl;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.FixedTimeRegulationConfigurationControl;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.SelfOrganizingRegulationConfigurationControl;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.TrafficLightConfigurationParameters;
import at.fhhagenberg.mc.traffsim.ui.rcp.custom.TrafficRegulationConfigurationControl;
import at.fhhagenberg.mc.util.StringUtil;

@SuppressWarnings("rawtypes")
public class TrafficLightGeneratorParameterPage extends WizardPage {

	public class TrafficLightGenerationParameters {
		public boolean includeSingleLane;
		public boolean includeMultiLane;
		public int numInflowingSegments;
		public double lowerSpeedLimit;
		public double upperSpeedLimit;
		public NodeType nodeType;
	}

	/** Generation parameters **/
	private Button btnSingleLane;
	private Button btnMultiLane;
	private Spinner spinnerNumSegments;
	private Spinner spinnerLowerSpeedLimit;
	private Spinner spinnerUpperSpeedLimit;
	private Combo comboNodeType;
	private Button btnRemoveAllTrafficLights;

	/** Traffic light configuration */
	private Group grpRegulation;
	private Button btnMergeTrafficLightsPerApproach;
	private Combo comboController;
	private Spinner spinnerIntergreenTime;
	private Spinner spinnerYellowTime;
	private Spinner spinnerRedYellowTime;

	private TrafficLightControllers prevControlMode;
	private TrafficLightControllers currentControlMode;
	private Map<TrafficLightControllers, TrafficRegulationConfigurationControl> configurationControlMapping = new HashMap<>();
	private TrafficRegulationConfigurationControl currentConfigurationControl;

	protected TrafficLightGeneratorParameterPage(String pageName) {
		super("Traffic Light Generation Parameters");
		setTitle("Traffic Light Generation Parameters");
		setDescription("Set up details for automated traffic light generation");
	}

	private TrafficLightGenerationParameters generationParameters = new TrafficLightGenerationParameters();
	private TrafficLightConfigurationParameters trafficLightConfigurationParameters;

	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);
		validatePage();
		getWizard().getContainer().updateButtons();
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		setControl(container);
		container.setLayout(new GridLayout(2, false));

		btnRemoveAllTrafficLights = new Button(container, SWT.CHECK);
		btnRemoveAllTrafficLights.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, true, false, 2, 1));
		btnRemoveAllTrafficLights.setText("Remove all traffic lights");
		btnRemoveAllTrafficLights.setToolTipText("All traffic lights from the currently active simulation model will be removed.");
		btnRemoveAllTrafficLights.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				enableControls(!btnRemoveAllTrafficLights.getSelection());
			}
		});

		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		Group grpParameters = new Group(container, SWT.NONE);
		grpParameters.setLayout(new GridLayout(2, false));
		grpParameters.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1));
		grpParameters.setText("Generation Parameters");

		btnSingleLane = new Button(grpParameters, SWT.CHECK);
		btnSingleLane.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		btnSingleLane.setText("Consider single-lane intersections");
		btnSingleLane.setToolTipText("Create traffic lights for intersections composed of single-lane segments only.");

		btnMultiLane = new Button(grpParameters, SWT.CHECK);
		btnMultiLane.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		btnMultiLane.setText("Consider multi-lane intersections");
		btnMultiLane.setToolTipText("Create traffic lights for intersections composed of at least on multi-lane segment.");

		Label lblNumSegments = new Label(grpParameters, SWT.NONE);
		lblNumSegments.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblNumSegments.setText("Num. approaches");
		lblNumSegments.setToolTipText("Only intersections composed of the specified number of approaches are equipped with traffic lights.");

		spinnerNumSegments = new Spinner(grpParameters, SWT.BORDER);
		spinnerNumSegments.setToolTipText("Only intersections composed of the specified number of approaches are equipped with traffic lights.");
		spinnerNumSegments.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));
		spinnerNumSegments.setMinimum(3);
		spinnerNumSegments.setMaximum(7);

		Label lblLowerSpeedLimit = new Label(grpParameters, SWT.NONE);
		lblLowerSpeedLimit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblLowerSpeedLimit.setText("Lower speed limit [km/h]");
		lblLowerSpeedLimit.setToolTipText("Only intersections with a speed limit greater than specified are equipped with traffic lights.");

		spinnerLowerSpeedLimit = new Spinner(grpParameters, SWT.BORDER);
		spinnerLowerSpeedLimit.setToolTipText("Only intersections with a speed limit greater than specified are equipped with traffic lights.");
		spinnerLowerSpeedLimit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));
		spinnerLowerSpeedLimit.setMinimum(0);
		spinnerLowerSpeedLimit.setMaximum(200);
		spinnerLowerSpeedLimit.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				validatePage();
			}
		});

		Label lblUpperSpeedLimit = new Label(grpParameters, SWT.NONE);
		lblUpperSpeedLimit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblUpperSpeedLimit.setText("Upper speed limit [km/h]");
		lblUpperSpeedLimit.setToolTipText("Only intersections with a speed limit smaller than specified are equipped with traffic lights.");

		spinnerUpperSpeedLimit = new Spinner(grpParameters, SWT.BORDER);
		spinnerUpperSpeedLimit.setToolTipText("Only intersections with a speed limit smaller than specified are equipped with traffic lights.");
		spinnerUpperSpeedLimit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));
		spinnerUpperSpeedLimit.setMinimum(0);
		spinnerUpperSpeedLimit.setMaximum(200);
		spinnerUpperSpeedLimit.setSelection(100);
		spinnerUpperSpeedLimit.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				validatePage();
			}
		});

		Label lblNodeType = new Label(grpParameters, SWT.NONE);
		lblNodeType.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblNodeType.setText("Node type");
		lblNodeType.setToolTipText("Only intersections of the given node type are equipped with traffic lights.");

		comboNodeType = new Combo(grpParameters, SWT.READ_ONLY);
		comboNodeType.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));

		for (NodeType t : NodeType.values()) {
			if (t != NodeType.TRAFFIC_LIGHT) {
				comboNodeType.add(t.toString());
			}
		}

		comboNodeType.select(0);

		createJunctionRegulationControls(container);
		validatePage();
	}

	private void enableControls(boolean enable) {
		btnMergeTrafficLightsPerApproach.setEnabled(enable);
		btnMultiLane.setEnabled(enable);
		btnSingleLane.setEnabled(enable);
		comboController.setEnabled(enable);
		comboNodeType.setEnabled(enable);
		spinnerIntergreenTime.setEnabled(enable);
		spinnerLowerSpeedLimit.setEnabled(enable);
		spinnerNumSegments.setEnabled(enable);
		spinnerRedYellowTime.setEnabled(enable);
		spinnerUpperSpeedLimit.setEnabled(enable);
		spinnerYellowTime.setEnabled(enable);
		currentConfigurationControl.activate(enable);
	}

	private void createJunctionRegulationControls(Composite container) {
		grpRegulation = new Group(container, SWT.NONE);
		grpRegulation.setLayout(new GridLayout(2, false));
		grpRegulation.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpRegulation.setText("Traffic Light Configuration");

		btnMergeTrafficLightsPerApproach = new Button(grpRegulation, SWT.CHECK);
		btnMergeTrafficLightsPerApproach.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
		btnMergeTrafficLightsPerApproach.setText("Merge traffic lights per approach");
		btnMergeTrafficLightsPerApproach
				.setToolTipText("All traffic lights in an approach are operated simultaneoulsy. Otherwise, each lane is operated individually");

		Label lblController = new Label(grpRegulation, SWT.NONE);
		lblController.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblController.setText("Control Strategy");

		comboController = new Combo(grpRegulation, SWT.READ_ONLY);
		comboController.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		for (TrafficLightControllers t : TrafficLightControllers.values()) {
			comboController.add(t.toString());
		}

		comboController.select(0);
		currentControlMode = TrafficLightControllers.values()[0];

		comboController.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateControlConfiguration();
			}
		});

		Label lblTrafficLight = new Label(grpRegulation, SWT.NONE);
		lblTrafficLight.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblTrafficLight.setText("Traffic Light");

		Label trafficLightIntegreenLabel = new Label(grpRegulation, SWT.NONE);
		trafficLightIntegreenLabel.setText("Intergreen time [s]");
		trafficLightIntegreenLabel.setToolTipText("Delay when traffic light switches from the red to red-yellow phase");

		spinnerIntergreenTime = new Spinner(grpRegulation, SWT.BORDER);
		spinnerIntergreenTime.setDigits(3);
		spinnerIntergreenTime.setMaximum(10000);
		spinnerIntergreenTime.setMinimum(1000);
		spinnerIntergreenTime.setPageIncrement(1000);

		Label trafficLightYellowLabel = new Label(grpRegulation, SWT.NONE);
		trafficLightYellowLabel.setText("Yellow time [s]");
		trafficLightYellowLabel.setToolTipText("Duration of the traffic light's yellow phase");

		spinnerYellowTime = new Spinner(grpRegulation, SWT.BORDER);
		spinnerYellowTime.setDigits(3);
		spinnerYellowTime.setMaximum(10000);
		spinnerYellowTime.setMinimum(1000);
		spinnerYellowTime.setPageIncrement(1000);

		Label trafficLightRedYellowLabel = new Label(grpRegulation, SWT.NONE);
		trafficLightRedYellowLabel.setText("Red-yellow time [s]");
		trafficLightRedYellowLabel.setToolTipText("Duration of the traffic light's red-yellow phase");

		spinnerRedYellowTime = new Spinner(grpRegulation, SWT.BORDER);
		spinnerRedYellowTime.setDigits(3);
		spinnerRedYellowTime.setMaximum(10000);
		spinnerRedYellowTime.setMinimum(1000);
		spinnerRedYellowTime.setPageIncrement(1000);

		Group grpConfiguration = new Group(grpRegulation, SWT.NONE);
		grpConfiguration.setLayout(new GridLayout(2, false));
		GridData configurationGridData = new GridData(SWT.FILL, SWT.FILL, true, false, 3, 1);
		grpConfiguration.setLayoutData(configurationGridData);
		grpConfiguration.setText("Configuration");

		// Initialize dynamic configuration controls
		CyclicRegulationConfigurationControl cyclicConfigurationControl = new CyclicRegulationConfigurationControl(grpConfiguration, SWT.NONE);
		cyclicConfigurationControl.setVisible(false);
		cyclicConfigurationControl.hide();

		FixedTimeRegulationConfigurationControl fixedTimeConfigurationControl = new FixedTimeRegulationConfigurationControl(grpConfiguration,
				SWT.NONE);
		fixedTimeConfigurationControl.setVisible(false);
		fixedTimeConfigurationControl.hide();

		SelfOrganizingRegulationConfigurationControl selfOrganizingConfigurationControl = new SelfOrganizingRegulationConfigurationControl(
				grpConfiguration, SWT.NONE);
		selfOrganizingConfigurationControl.setVisible(false);
		selfOrganizingConfigurationControl.hide();

		configurationControlMapping.put(TrafficLightControllers.CYCLIC, cyclicConfigurationControl);
		configurationControlMapping.put(TrafficLightControllers.FIXED_TIMED, fixedTimeConfigurationControl);
		configurationControlMapping.put(TrafficLightControllers.SELF_ORGANIZING, selfOrganizingConfigurationControl);
		updateControlConfiguration();
	}

	@Override
	public boolean canFlipToNextPage() {
		return StringUtil.isNullOrEmpty(getErrorMessage());
	}

	private void updateControlConfiguration() {
		if (comboController.getText().compareTo(TrafficLightControllers.CYCLIC.toString()) == 0) {
			currentControlMode = TrafficLightControllers.CYCLIC;
		} else if (comboController.getText().compareTo(TrafficLightControllers.FIXED_TIMED.toString()) == 0) {
			currentControlMode = TrafficLightControllers.FIXED_TIMED;
		} else {
			currentControlMode = TrafficLightControllers.SELF_ORGANIZING;
		}

		if (prevControlMode != currentControlMode) {
			if (currentConfigurationControl != null) {
				currentConfigurationControl.hide();
				currentConfigurationControl.setVisible(false);
			}

			currentConfigurationControl = configurationControlMapping.get(currentControlMode);
			currentConfigurationControl.show();
			currentConfigurationControl.setVisible(true);
			prevControlMode = currentControlMode;
			grpRegulation.pack();
		}
	}

	public void validatePage() {

		if (spinnerLowerSpeedLimit.getSelection() >= spinnerUpperSpeedLimit.getSelection()) {
			setErrorMessage("Lower speed limit must not be greater or equal to the upper speed limit");
			return;
		} else {
			setErrorMessage(null);
		}

		if (SimulationKernel.getInstance().getActiveModel() == null) {
			setErrorMessage("No simulation model selected");
			btnRemoveAllTrafficLights.setEnabled(false);
			return;
		} else {
			setErrorMessage(null);
		}

		btnRemoveAllTrafficLights.setEnabled(true);

		// General generation parameters
		generationParameters.includeSingleLane = btnSingleLane.getSelection();
		generationParameters.includeMultiLane = btnMultiLane.getSelection();
		generationParameters.numInflowingSegments = spinnerNumSegments.getSelection();
		generationParameters.lowerSpeedLimit = spinnerLowerSpeedLimit.getSelection();
		generationParameters.upperSpeedLimit = spinnerUpperSpeedLimit.getSelection();

		for (NodeType t : NodeType.values()) {
			if (comboNodeType.getText().compareTo(t.toString()) == 0) {
				generationParameters.nodeType = t;
				break;
			}
		}

		// Traffic light configuration parameters;
		trafficLightConfigurationParameters = currentConfigurationControl.getConfigurationParameters();

		if (comboController.getText().compareTo(TrafficLightControllers.CYCLIC.toString()) == 0) {
			trafficLightConfigurationParameters.controlMode = TrafficLightControllers.CYCLIC;
		} else if (comboController.getText().compareTo(TrafficLightControllers.FIXED_TIMED.toString()) == 0) {
			trafficLightConfigurationParameters.controlMode = TrafficLightControllers.FIXED_TIMED;
		} else {
			trafficLightConfigurationParameters.controlMode = TrafficLightControllers.SELF_ORGANIZING;
		}

		trafficLightConfigurationParameters.interGreenTime = spinnerIntergreenTime.getSelection();
		trafficLightConfigurationParameters.yellowTime = spinnerYellowTime.getSelection();
		trafficLightConfigurationParameters.redYellowTime = spinnerRedYellowTime.getSelection();
		trafficLightConfigurationParameters.mergeApproaches = btnMergeTrafficLightsPerApproach.getSelection();
	}

	@Override
	public boolean isPageComplete() {
		validatePage();
		return getErrorMessage() == null;
	}

	public TrafficLightGenerationParameters getGenerationParameters() {
		return generationParameters;
	}

	public TrafficLightConfigurationParameters getTrafficLightConfigurationParameters() {
		return trafficLightConfigurationParameters;
	}

	public boolean performRemove() {
		return btnRemoveAllTrafficLights.getSelection();
	}
}

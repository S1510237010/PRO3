package at.fhhagenberg.mc.traffsim.util.math;

import java.util.Random;

import org.apache.commons.math3.distribution.AbstractRealDistribution;
import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.distribution.LogNormalDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.distribution.PoissonDistribution;
import org.apache.commons.math3.distribution.UniformRealDistribution;
import org.apache.commons.math3.distribution.WeibullDistribution;
import org.apache.commons.math3.random.RandomGenerator;

/**
 * This class provides various useful utility methods for:
 * <p>
 * - Obtaining random realizations based on different distributions
 * </p>
 * <p>
 * - Realizing a smooth step function between two variable values
 * </p>
 *
 * @author Manuel Lindorfer
 */
public class MathUtil {

	/** Random object required for obtaining uniformly distributed random values */
	private static Random rand = new Random();

	/**
	 * Performs a clamp operation between for the given value between the provided min. and max. value. If "value" is below "min" or greater
	 * than "max", it is set to the respective values accordingly.
	 *
	 * @param value
	 *            the value to be clamped
	 * @param min
	 *            the minimum allowed value
	 * @param max
	 *            the maximum allowed value
	 * @return the clamped value
	 */
	public static double clamp(double value, double min, double max) {
		if (value < min) {
			value = min;
		} else if (value > max) {
			value = max;
		}

		return value;
	}

	/**
	 * Generates a ex-gaussian distributed random variable with the given parameters.
	 *
	 * @param meanNormal
	 *            the mean value of the distribution
	 * @param stdNormal
	 *            the standard deviation of the distribution
	 * @param meanExp
	 *            the mean value of the distribution
	 * @return a ex-gaussian distributed random variable
	 */
	public static double distributeExGaussian(double meanNormal, double stdNormal, double meanExp) {
		NormalDistribution normal = new NormalDistribution(meanNormal, stdNormal);
		ExponentialDistribution exponential = new ExponentialDistribution(meanExp);

		double result = normal.sample() + exponential.sample();
		return result;
	}

	public static double distributionUniformly(double lowerBound, double upperBound) {
		UniformRealDistribution uniform = new UniformRealDistribution(lowerBound, upperBound);
		double result = uniform.sample();
		return result;
	}

	/**
	 * Generates a log-normally distributed random variable with given mean and standard deviation.
	 *
	 * @param mean
	 *            the mean value of the distribution
	 * @param std
	 *            the standard deviation of the distribution
	 * @return a log-normally distributed random variable
	 */
	public static double distributeLogNormally(double mean, double std) {
		double x = 1 + std / (mean * mean);
		double mu = Math.log(mean * mean / Math.sqrt(std + mean * mean));
		double sigma = Math.sqrt(Math.log(x));
		LogNormalDistribution logN = new LogNormalDistribution(mu, sigma);

		double result = logN.sample();
		return result;
	}

	/**
	 * Generates a log-normally distributed random variable with given mu and sigma.
	 *
	 * @param mu
	 *            value of mu of the log-normal distribution
	 * @param sigma
	 *            value of sigma of the log-normal distribution
	 * @return a log-normally distributed random variable
	 */
	public static double distributeLogNormallyMuSigma(double mu, double sigma) {
		LogNormalDistribution logN = new LogNormalDistribution(mu, sigma);
		double result = logN.sample();
		return result;
	}

	public static double distributeExponentially(double mean) {
		ExponentialDistribution exp = new ExponentialDistribution(mean);
		double result = exp.sample();
		return result;
	}

	/**
	 * Generates a normally distributed random variable between 0 and 1.
	 *
	 * @return a normally distributed random variable
	 */
	public static double distributeNormally() {
		NormalDistribution normal = new NormalDistribution();
		double result = normal.sample();
		return result;
	}

	/**
	 * Generates a normally distributed random variable with the given mean and standard deviation.
	 *
	 * @param mean
	 *            the mean value of the distribution
	 * @param std
	 *            the standard deviation of the distribution
	 * @return a normally distributed random variable
	 */
	public static double distributeNormally(double mean, double std) {
		NormalDistribution normal = new NormalDistribution(mean, std);
		double result = normal.sample();
		return result;
	}

	/**
	 * Generates a truncated normally distributed random variable with the given mean, standard deviation, lower and upper bound. It is
	 * ensured that resulting values are lying between the respective boundaries.
	 *
	 * @param mean
	 *            the mean value of the distribution
	 * @param std
	 *            the standard deviation of the distribution
	 * @param lowerBound
	 *            the distribution's lower bound
	 * @param upperBound
	 *            the distribution's upper bound
	 * @return a normally distributed random variable within the given bounds
	 */
	public static double distributeNormally(double mean, double std, double lowerBound, double upperBound) {
		NormalDistribution normal = new NormalDistribution(mean, std);
		double result = normal.sample();

		while (result < lowerBound || result > upperBound) {
			result = normal.sample();
		}

		return result;
	}

	/**
	 * Generates a Weibull-distributed random variable with the given shape and scale parameter.
	 *
	 * @param alpha
	 *            the distribution's shape parameter
	 * @param beta
	 *            the distribution's scale parameter
	 * @return a weibull-distributed random variable
	 */
	public static double distributeWeibull(double alpha, double beta) {
		WeibullDistribution weibull = new WeibullDistribution(alpha, beta);
		double result = weibull.sample();
		return result;
	}

	/**
	 * Generates a log-normal distribution with the given mean and standard deviation.
	 *
	 * @param mean
	 *            the mean value of the distribution
	 * @param std
	 *            the standard deviation of the distribution
	 * @return an instance of LogNormalDistribution with given mean and standard deviation
	 */
	public static LogNormalDistribution getLogNormalDistribution(double mean, double std) {
		double variance = std * std;
		double mu = Math.log(mean * mean / Math.sqrt(variance + mean * mean));
		double sigma = Math.sqrt(Math.log(variance / (mean * mean) + 1));
		LogNormalDistribution logN = new LogNormalDistribution(mu, sigma);
		return logN;
	}

	public static LogNormalDistribution getLogNormalDistribution(double mean, double std, RandomGenerator randomGenerator) {
		double variance = std * std;
		double mu = Math.log(mean * mean / Math.sqrt(variance + mean * mean));
		double sigma = Math.sqrt(Math.log(variance / (mean * mean) + 1));
		LogNormalDistribution logN = new LogNormalDistribution(randomGenerator, mu, sigma);
		return logN;
	}

	public static GammaDistribution getGammaDistribution(double mean, double std) {
		double variance = std * std;
		double scale = variance / mean;
		double shape = mean * mean / variance;
		GammaDistribution gamma = new GammaDistribution(shape, scale);
		return gamma;
	}

	public static GammaDistribution getGammaDistribution(double mean, double std, RandomGenerator randomGenerator) {
		double variance = std * std;
		double scale = variance / mean;
		double shape = mean * mean / variance;
		GammaDistribution gamma = new GammaDistribution(randomGenerator, shape, scale);
		return gamma;
	}

	public static PoissonDistribution getPoissonDistribution(double mean) {
		PoissonDistribution poisson = new PoissonDistribution(mean);
		return poisson;
	}

	public static PoissonDistribution getPoissonDistribution(double mean, double epsilon) {
		PoissonDistribution poisson = new PoissonDistribution(mean, epsilon);
		return poisson;
	}

	/**
	 * Generates a normal distribution.
	 *
	 * @return an instance of NormalDistribution
	 */
	public static NormalDistribution getNormalDistribution() {
		NormalDistribution normal = new NormalDistribution();
		return normal;
	}

	/**
	 * Generates a normal distribution with the given mean and standard deviation.
	 *
	 * @param mean
	 *            the mean value of the distribution
	 * @param std
	 *            the standard deviation of the distribution
	 * @return an instance of NormalDistribution with given mean and standard deviation
	 */
	public static NormalDistribution getNormalDistribution(double mean, double std) {
		NormalDistribution normal = new NormalDistribution(mean, std);
		return normal;
	}

	public static ExponentialDistribution getExponentialDistribution(double mean) {
		ExponentialDistribution exponential = new ExponentialDistribution(mean);
		return exponential;
	}

	/**
	 * Gets a sample value of the given distribution between the provided intervals (inclusive).
	 *
	 * @param distribution
	 *            the distribution to obtain a sample from
	 * @param min
	 *            the minimum allowed value (lower bound)
	 * @param max
	 *            the maximum allowd value (upper bound)
	 * @return a sample value obtained from the given distribution
	 */
	public static double getSample(AbstractRealDistribution distribution, double min, double max) {
		double result = distribution.sample();

		// Safety check, since several distributions are defined in R+ only
		if (max <= distribution.getSupportLowerBound()) {
			return max;
		} else if (min >= distribution.getSupportUpperBound()) {
			return min;
		}

		while (result < min || result > max) {
			result = distribution.sample();
		}

		return result;
	}

	/**
	 * Implements a "smoother" step function of higher polynomial order to allow a smooth transition between the two edges.
	 *
	 * @param leftEdge
	 *            the left edge (i.e. where the smoothed step starts)
	 * @param rightEdge
	 *            the right edge (i.e. where the smoothed step ends)
	 * @param value
	 *            the value (an intermediate value for which the respective value of the smooth step function is of interest)
	 * @return the value of the smooth step function for the provided input value
	 */
	public static double getSmootherStep(double leftEdge, double rightEdge, double value) {
		value = clamp((value - leftEdge) / (rightEdge - leftEdge), 0, 1);
		return value * value * value * (value * (6 * value - 15) + 10);
	}

	/**
	 * Implements a "smoothest" step function of highest polynomial order to allow a smooth transition between the two edges.
	 *
	 * @param leftEdge
	 *            the left edge (i.e. where the smoothed step starts)
	 * @param rightEdge
	 *            the right edge (i.e. where the smoothed step ends)
	 * @param value
	 *            the value (an intermediate value for which the respective value of the smooth step function is of interest)
	 * @return the value of the smooth step function for the provided input value
	 */
	public static double getSmoothestStep(double leftEdge, double rightEdge, double value) {
		value = clamp((value - leftEdge) / (rightEdge - leftEdge), 0, 1);
		return value * value * value * value * (35 - 84 * value + 70 * value * value - 20 * value * value * value);
	}

	/**
	 * Implements a "smooth" step function of higher polynomial order to allow a smooth transition between the two edges.
	 *
	 * @param leftEdge
	 *            the left edge (i.e. where the smoothed step starts)
	 * @param rightEdge
	 *            the right edge (i.e. where the smoothed step ends)
	 * @param value
	 *            the value (an intermediate value for which the respective value of the smooth step function is of interest)
	 * @return the value of the smooth step function for the provided input value
	 */
	public static double getSmoothStep(double leftEdge, double rightEdge, double value) {
		value = clamp((value - leftEdge) / (rightEdge - leftEdge), 0, 1);
		return value * value * (3.0 - 2 * value);
	}

	/**
	 * Generates a weibull distribution with the given shape and scale parameter.
	 *
	 * @param alpha
	 *            the distribution's shape parameter
	 * @param beta
	 *            the distribution's scale parameter
	 * @return an instance of WeibullDistribution with the given shape and scale parameter
	 */
	public static WeibullDistribution getWeibullDistribution(double alpha, double beta) {
		WeibullDistribution weibull = new WeibullDistribution(alpha, beta);
		return weibull;
	}

	/**
	 * Gets the next pseudorandom, uniformly distributed value between 0 and 1 from the random number generator's sequence.
	 *
	 * @return a uniformly distributed value between 0 and 1
	 */
	public static double nextDouble() {
		return rand.nextDouble();
	}

	/**
	 * Gets the next pseudorandom, uniformly distributed (integer) value between 0 and 2^32 from the random number generator's sequence.
	 *
	 * @return a uniformly distributed (integer) value between 0 and 2^32
	 */
	public static int nextInt() {
		return rand.nextInt();
	}

	/**
	 * Gets the next pseudorandom, uniformly distributed (integer) value between 0 and n (inclusive) from the random number generator's
	 * sequence.
	 *
	 * @param n
	 *            the upper bound for the resulting value
	 * @return a uniformly distributed (integer) value between 0 and n (exclusive)
	 */
	public static int nextInt(int n) {
		return rand.nextInt(n);
	}
}
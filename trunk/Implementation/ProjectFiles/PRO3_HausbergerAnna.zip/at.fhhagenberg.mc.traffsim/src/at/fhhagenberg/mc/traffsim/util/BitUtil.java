package at.fhhagenberg.mc.traffsim.util;

/**
 * Utility class providing various useful bit operation.
 *
 * @author Christian Backfrieder
 */
public class BitUtil {

	/**
	 * Checks if the value has all flag bits set from mask.
	 *
	 * @param value
	 *            the value to check
	 * @param mask
	 *            containing all flag bits
	 * @return true if all bits are set, false otherwise
	 */
	public static boolean checkMask(int value, int mask) {
		return (value & mask) == mask;
	}

	/**
	 * Check if bit with specific index is set.
	 *
	 * @param number
	 *            the integer which should be checked
	 * @param bit
	 *            the index of the bit to check (starting at 0)
	 * @return true if bit is set, false otehrwise
	 */
	public static boolean isSet(int number, int bit) {
		int mask = 1 << bit;
		return (number & mask) == mask;
	}

	/**
	 * Reset a specific bit in the given integer to 0.
	 *
	 * @param number
	 *            the integer where to set the bit
	 * @param bit
	 *            index of the bit to reset
	 * @return integer with reset bit
	 */
	public static int reset(int number, int bit) {
		return number & ~(1 << bit);
	}

	/**
	 * Set specific bits in the given integer.
	 *
	 * @param number
	 *            the number where to set the bit to 1
	 * @param bits
	 *            the index(ex) of the bit (starting at 0)
	 * @return number with bit set to 1
	 */
	public static int set(int number, int... bits) {
		for (int bit : bits) {
			number |= 1 << bit;
		}
		return number;
	}
}
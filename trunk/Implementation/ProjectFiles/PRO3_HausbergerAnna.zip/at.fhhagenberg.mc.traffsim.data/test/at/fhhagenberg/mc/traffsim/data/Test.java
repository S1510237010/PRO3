package at.fhhagenberg.mc.traffsim.data;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.BeanConfigurationContainer;
import at.fhhagenberg.mc.traffsim.data.beans.CoordinateBean;
import at.fhhagenberg.mc.traffsim.data.beans.ParameterBean;
import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficGeneratorBean;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficObstructionBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.BaseRoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ConnectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionCarDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.EngineDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.MOBILDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.ACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.MemoryDataBean;
import at.fhhagenberg.mc.traffsim.data.xml.DataSerializer;
import at.fhhagenberg.mc.util.LinkedProperties;

public class Test {
	private static final String DIESEL_90KW = "Diesel_90kw";
	private static final String TEST_FOLDER = "./data/test/";
	private DataSerializer ser;

	private static final String IDM1_REF = "IDM1";
	private static final String ACC1_REF = "ACC1";
	private static final String MOBIL1_REF = "MOBIL1";
	private static final String MEMORY1_REF = "MEMORY1";

	@Before
	public void init() {
		new File(TEST_FOLDER).mkdirs();
		HashMap<String, BeanConfigurationContainer> mapping = new HashMap<>();

		mapping.put(InfrastructureBean.class.getCanonicalName(),
				new BeanConfigurationContainer(InfrastructureBean.class.getCanonicalName(), "roadnetwork.xml"));
		mapping.put(BaseRoadSegmentBean.class.getCanonicalName(),
				new BeanConfigurationContainer(RoadSegmentBean.class.getCanonicalName(), "baseroadsegments.xml"));
		mapping.put(TrafficObstructionBean.class.getCanonicalName(),
				new BeanConfigurationContainer(TrafficObstructionBean.class.getCanonicalName(), "obstructions.xml"));
		mapping.put(RouteBean.class.getCanonicalName(), new BeanConfigurationContainer(RouteBean.class.getCanonicalName(), "routes.xml"));
		mapping.put(TrafficGeneratorBean.class.getCanonicalName(),
				new BeanConfigurationContainer(TrafficGeneratorBean.class.getCanonicalName(), "trafficGenerators.xml"));
		mapping.put(ModelBean.class.getCanonicalName(), new BeanConfigurationContainer(ModelBean.class.getCanonicalName(), "models.xml"));
		mapping.put(VehicleBean.class.getCanonicalName(),
				new BeanConfigurationContainer(VehicleBean.class.getCanonicalName(), "vehicles.xml"));
		mapping.put(ParameterBean.class.getCanonicalName(),
				new BeanConfigurationContainer(ParameterBean.class.getCanonicalName(), "parameters.xml"));

		final File configFile = new File(TEST_FOLDER + "configuration.xml");
		TraffSimConfiguration config = new TraffSimConfiguration();
		config.setBeanConfigurations(mapping);
		config.setStartTime(new Date());
		config.setConfigurationFile(configFile);
		config.setOsmNetworkFile("osmfile.osm");
		config.setGraphFile("graph.gph");
		config.setOutputFolder("outputordner");

		ser = new DataSerializer();
		ser.setConfiguration(config);
		ser.writeConfiguration(configFile);
	}

	@org.junit.Test
	public void TestDataSerializer() {

		// //////////////////////////////

		List<RouteBean> routeBeans = new ArrayList<>();
		RouteBean routeBean = new RouteBean(1, new long[] { 1, 2, 3, 4, 5, 6 });
		routeBeans.add(routeBean);

		List<TrafficGeneratorBean> tgBeans = new ArrayList<>();
		TrafficGeneratorBean tg = new TrafficGeneratorBean();
		tg.setLaneChangeModelRef(MOBIL1_REF);
		tg.setLongitudinalModelRef(IDM1_REF);
		tg.setMemoryModelRef(MEMORY1_REF);

		tgBeans.add(tg);

		ser.writeData(routeBeans);
		ser.writeData(tgBeans);

		List<? extends AbstractBean> routeBeansRead = null;
		try {
			routeBeansRead = ser.readData(RouteBean.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (AbstractBean b : routeBeansRead) {
			assertTrue(b instanceof RouteBean);
			RouteBean bean = (RouteBean) b;
			assertEquals(bean.getId(), routeBean.getId());
			assertArrayEquals(routeBean.getRoadSegmentIds().toArray(), bean.getRoadSegmentIds().toArray());
		}

	}

	@org.junit.Test
	public void TestSerializeLongitudinalModelData() {
		// //////////////////////////////

		IDMDataBean idm = new IDMDataBean();
		idm.setId(1);
		idm.setComfortableAcc(1.5);
		idm.setDelta(4);
		idm.setFullName("Intelligent Driver Model");
		idm.setMaxDec(-7);
		idm.setModelIdentifier(IDM1_REF);
		idm.setSafeDec(-2);
		idm.setsMin(2);
		idm.settMin(1.1);

		ACCDataBean acc = new ACCDataBean();
		acc.setId(2);
		acc.setComfortableAcc(1.5);
		acc.setDelta(4);
		acc.setFullName("Adaptive Cruise Control (IIDM)");
		acc.setMaxDec(-7);
		acc.setModelIdentifier(ACC1_REF);
		acc.setSafeDec(-2);
		acc.setsMin(2);
		acc.settMin(1.1);
		acc.setCoolness(0.99);

		MOBILDataBean mobil = new MOBILDataBean();
		mobil.setBiasRight(0.2);
		mobil.setFullName("MOBIL (treiber)");
		mobil.setId(3);
		mobil.setMaxDec(-7);
		mobil.setModelIdentifier(MOBIL1_REF);
		mobil.setPoliteness(0.99);
		mobil.setSafeDec(-2);
		mobil.setsMin(2);
		mobil.setThreshold(0.1);

		MemoryDataBean mem = new MemoryDataBean();
		mem.setFullName("Default memory");
		mem.setId(0);
		mem.setModelIdentifier(MEMORY1_REF);
		mem.setTau(600);
		mem.setResignationMinAlphaA(1);
		mem.setResignationMinAlphaV0(1);
		mem.setResignationMaxAlphaT(1.7);

		ConsumptionCarDataBean ccd = new ConsumptionCarDataBean();
		ccd.setVehicleMass(1500);
		ccd.setCrossSectionSurface(2.2);
		ccd.setCdValue(0.32);
		ccd.setElectricPower(3000);
		ccd.setConsFrictionCoefficient(0.015);
		ccd.setvFrictionCoefficient(0);
		ccd.setDynamicTyreRadius(0.31);

		EngineDataBean ed = new EngineDataBean();
		ed.setMaxPower(90);
		ed.setCylinderVolume(1.4);
		ed.setIdleConsumptionRateLiterPerSecond(0.8);
		ed.setMinSpecificConsumption(185);
		ed.setEffectivePressureMaximum(22);
		ed.setEffectivePressureMinimum(1);
		ed.setIdleRotationRate(900);
		ed.setMaxRotationRate(4500);
		ArrayList<Double> gearRatios = new ArrayList<Double>();
		gearRatios.add(13.9);
		gearRatios.add(7.8);
		gearRatios.add(5.26);
		gearRatios.add(3.79);
		gearRatios.add(3.09);
		ed.setGearRatios(gearRatios);

		ConsumptionBean cons = new ConsumptionBean();
		cons.setCarData(ccd);
		cons.setEngineData(ed);
		cons.setModelIdentifier(DIESEL_90KW);
		cons.setId(0);

		List<ModelBean> modelBeans = new ArrayList<>();
		modelBeans.add(idm);
		modelBeans.add(acc);
		modelBeans.add(mobil);
		modelBeans.add(mem);
		modelBeans.add(cons);

		ser.writeData(modelBeans);
	}

	@org.junit.Test
	public void TestVehicleBeans() {
		int num = 30;
		int delay = 1200;
		Date start = ser.getStartTime();
		List<VehicleBean> vehicles = new ArrayList<>();
		for (int i = 1; i <= num; i++) {
			VehicleBean vb = new VehicleBean();
			vb.setId(i);
			vb.setLabel("My vehicle");
			vb.setLaneChaneModelIdentifier(MOBIL1_REF);
			vb.setLength(5);
			vb.setLongitudinalModelIdentifier(IDM1_REF);
			vb.setRouteId(1);
			vb.setStartDate(new Date(start.getTime() + i * delay));
			vb.setVehicleType("CAR");
			vb.setWidth(2);
			vb.setMemoryIdentifier(MEMORY1_REF);
			vb.setInitialSpeed(12);
			vb.setConsumptionIdentifier(DIESEL_90KW);
			vehicles.add(vb);
		}
		ser.writeData(vehicles);
	}

	@org.junit.Test
	public void TestReadConfig() {
		ser.readConfiguration(new File(TEST_FOLDER + "configuration.xml"));
	}

	@org.junit.Test
	public void testJunctionConnectors() {
		TraffSimConfiguration config = ser.getConfiguration();
		List<ConnectorBean> conn = new ArrayList<>();

		ConnectorBean c1 = new ConnectorBean(3, 0, 0, 0, 5, 1, null, null);
		ConnectorBean c2 = new ConnectorBean(1, 6, 0, 0, 5, 1, null, null);
		conn.add(c1);
		conn.add(c2);

		config.getBeanConfigurationsMapping().put(InfrastructureBean.class.getCanonicalName(),
				new BeanConfigurationContainer(InfrastructureBean.class.getCanonicalName(), "roadnetwork_junctions.xml"));
		ser.setConfiguration(config);
		ser.writeData(conn);
	}

	@org.junit.Test
	public void testBaseRoadSegments() {
		BaseRoadSegmentBean brsb = new BaseRoadSegmentBean();
		brsb.setId(123);
		brsb.setLaneCount(3);
		brsb.setName("base name");
		brsb.setSinkNodeId(178);
		brsb.setSourceNodeId(197);
		brsb.setSpeedLimit(123.45);
		brsb.setPoints(new ArrayList<CoordinateBean>());
		ArrayList<BaseRoadSegmentBean> brsbs = new ArrayList<>();
		brsbs.add(brsb);
		ser.writeData(brsbs);
	}

	@org.junit.Test
	public void testRead() throws Exception {
		ser.readData(InfrastructureBean.class);
		ser.readData(BaseRoadSegmentBean.class);
		ser.readData(VehicleBean.class);
		ser.readData(ModelBean.class);
		ser.readData(TrafficGeneratorBean.class);
	}

	@org.junit.Test
	public void testObstruction() {
		Date start = new Date();
		TrafficObstructionBean bean = new TrafficObstructionBean(start, new Date(start.getTime() + 10000), 1, new int[] { 0 }, 30);
		List<TrafficObstructionBean> obs = new ArrayList<>();
		obs.add(bean);
		ser.writeData(obs);
	}

	@org.junit.Test
	public void testOsmFile() {
		TraffSimConfiguration config = ser.getConfiguration();
		config.setOsmNetworkFile("osmfile.osm");
		ser.setConfiguration(config);
		ser.writeConfiguration(ser.getConfiguration().getConfigurationFile());
	}

	@org.junit.Test
	public void testParameters() {
		LinkedProperties prop = new LinkedProperties();
		prop.put("number_prop", 7.42);
		prop.put("string_prop", "string-value");
		ParameterBean pb = new ParameterBean();
		pb.setProperties(prop);
		ser.writeData(pb);
	}
}

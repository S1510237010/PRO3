package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Data bean for platooning longitudinal model
 * 
 * @author Sebastian Huber
 *
 */
@XStreamAlias("CACC")
public class CACCDataBean extends IDMDataBean {
	
	private static final long serialVersionUID = 3912688030438704622L;

	/**
	 * weighting factor between acceleration of leader and the preceding vehicle
	 */
	private double c1;

	/**
	 * damping (ξ, Xi) ratio (default set to 1) 
	 */
	private double damping;
	
	/**
	 * bandwidth (ω, omega) of controller
	 */
	private double bandwidth;
	
	/**
	 * Wheighting factor
	 * @return c1
	 */
	public double getC1(){
		return c1;
	}
	
	/**
	 * Weighting factor
	 * @param c1 c1
	 */
	public void setC1(double c1){
		this.c1 = c1;
	}

	/**
	 * Damping
	 * @return damping
	 */
	public double getDamping() {
		return damping;
	}

	/**
	 * Damping
	 * @param damping damping
	 */
	public void setDamping(double damping) {
		this.damping = damping;
	}

	/**
	 * Bandwidth
	 * @return bandwidth
	 */
	public double getBandwidth() {
		return bandwidth;
	}

	/**
	 * Bandwidth
	 * @param bandwidth bandwidth
	 */
	public void setBandwidth(double bandwidth) {
		this.bandwidth = bandwidth;
	}
}

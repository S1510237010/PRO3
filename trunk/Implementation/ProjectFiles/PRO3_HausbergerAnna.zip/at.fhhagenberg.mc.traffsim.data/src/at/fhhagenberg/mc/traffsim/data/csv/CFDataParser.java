package at.fhhagenberg.mc.traffsim.data.csv;

import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class CFDataParser {

	public static boolean isValidNGSIMSet(String filepath) {

		try {
			final Reader reader = new FileReader(filepath);
			CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT.withDelimiter(';'));
			CSVRecord record = parser.getRecords().iterator().next();
			getNGSIM(record);

			if (parser != null) {
				parser.close();
			}

			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public static boolean isValidOBDSet(String filepath) {
		try {
			final Reader reader = new FileReader(filepath);
			CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT.withDelimiter(';'));
			CSVRecord record = parser.getRecords().iterator().next();
			getOBD(record);

			if (parser != null) {
				parser.close();
			}

			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public static List<CFDataSet> parse(String filepath) {
		try {
			if (isValidNGSIMSet(filepath)) {
				return parseNGSIM(filepath);
			}

			if (isValidOBDSet(filepath)) {
				return parseOBD(filepath);
			}

			return null;
		} catch (Exception ex) {
			return null;
		}
	}

	private static List<CFDataSet> parseNGSIM(String filepath) {
		try {
			ArrayList<CFDataSet> data = new ArrayList<>();
			final Reader reader = new FileReader(filepath);
			CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT.withDelimiter(';'));
			Iterable<CSVRecord> records = parser.getRecords();

			for (CSVRecord record : records) {
				data.add(getNGSIM(record));
			}

			if (parser != null) {
				parser.close();
			}

			return data;
		} catch (Exception ex) {
			return null;
		}
	}

	private static List<CFDataSet> parseOBD(String filepath) {
		try {
			ArrayList<CFDataSet> data = new ArrayList<>();
			final Reader reader = new FileReader(filepath);
			CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT.withDelimiter(';'));
			Iterable<CSVRecord> records = parser.getRecords();

			for (CSVRecord record : records) {
				data.add(getOBD(record));
			}

			if (parser != null) {
				parser.close();
			}

			return data;
		} catch (Exception ex) {
			return null;
		}
	}

	private static NGSIMDataSet getNGSIM(CSVRecord record) {
		NGSIMDataSet data = new NGSIMDataSet();
		data.setTimestamp(Long.parseLong(record.get(0)));
		data.setSpeed(Double.parseDouble(record.get(1)));
		data.setDistance(Double.parseDouble(record.get(2)));
		data.setSpeedDifference(Double.parseDouble(record.get(3)));
		data.setAccLeadVehicle(Double.parseDouble(record.get(4)));
		data.setSpeedLeadVehicle(Double.parseDouble(record.get(5)));
		data.setAcceleration(Double.parseDouble(record.get(6)));
		return data;
	}

	private static OBDDataSet getOBD(CSVRecord record) {
		OBDDataSet data = new OBDDataSet();
		data.setTimestamp(Double.parseDouble(record.get(0)));
		data.setAcceleration(Double.parseDouble(record.get(1)));
		data.setSpeed(Double.parseDouble(record.get(2)));
		data.setAccLeadVehicle(Double.parseDouble(record.get(3)));
		data.setSpeedLeadVehicle(Double.parseDouble(record.get(4)));
		data.setIsFollowerDistracted(Double.parseDouble(record.get(5)) == 1.0);
		return data;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.csv.CFDataSet;

@XStreamAlias("Behavior")
public class BehaviorBean extends AbstractBean {

	private static final long serialVersionUID = 1L;
	private String behaviorType;
	private String vehicleLabel;
	private double intensity;
	private double duration;
	private double offset;
	private double param;

	private List<CFDataSet> controlTrace;

	public String getBehaviorType() {
		return behaviorType;
	}

	public void setBehaviorType(String behaviorType) {
		this.behaviorType = behaviorType;
	}

	public String getVehicleLabel() {
		return vehicleLabel;
	}

	public void setVehicleLabel(String vehicleLabel) {
		this.vehicleLabel = vehicleLabel;
	}

	public double getIntensity() {
		return intensity;
	}

	public void setIntensity(double intensity) {
		this.intensity = intensity;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public double getOffset() {
		return offset;
	}

	public void setOffset(double offset) {
		this.offset = offset;
	}

	public double getParam() {
		return param;
	}

	public void setParam(double param) {
		this.param = param;
	}

	public List<CFDataSet> getControlTrace() {
		return controlTrace;
	}

	public void setControlTrace(List<CFDataSet> controlTrace) {
		this.controlTrace = controlTrace;
		this.duration = controlTrace.get(controlTrace.size() - 1).getTimestamp() - controlTrace.get(0).getTimestamp();
	}
}

package at.fhhagenberg.mc.traffsim.data.csv;

public abstract class CFDataSet {

	private double timestamp;
	private double acceleration;
	private double speed;
	private double accLeadVehicle;
	private double speedLeadVehicle;

	public void setTimestamp(double timestamp) {
		this.timestamp = timestamp;
	}

	public double getTimestamp() {
		return this.timestamp;
	}

	public void setAcceleration(double acceleration) {
		this.acceleration = acceleration;
	}

	public double getAcceleration() {
		return this.acceleration;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public double getSpeed() {
		return this.speed;
	}

	public void setAccLeadVehicle(double accLeadVehicle) {
		this.accLeadVehicle = accLeadVehicle;
	}

	public double getAccLeadVehicle() {
		return this.accLeadVehicle;
	}

	public void setSpeedLeadVehicle(double speedLeadVehicle) {
		this.speedLeadVehicle = speedLeadVehicle;
	}

	public double getSpeedLeadVehicle() {
		return this.speedLeadVehicle;
	}
}

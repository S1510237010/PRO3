package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("TrafficLight")
public class TrafficLightBean extends IntersectionControlBean {

	private static final long serialVersionUID = 6472491401338370283L;

	private List<Long> connectors;

	private long timeYellow;
	private long timeRedYellow;
	private long timeIntergreen;

	public List<Long> getConnectors() {
		return connectors;
	}

	public void setConnectors(List<Long> connectors) {
		this.connectors = connectors;
	}

	public long getTimeIntergreen() {
		return timeIntergreen;
	}

	public void setTimeIntergreen(long timeIntergreen) {
		this.timeIntergreen = timeIntergreen;
	}

	public long getTimeRedYellow() {
		return timeRedYellow;
	}

	public void setTimeRedYellow(long timeRedYellow) {
		this.timeRedYellow = timeRedYellow;
	}

	public long getTimeYellow() {
		return timeYellow;
	}

	public void setTimeYellow(long timeYellow) {
		this.timeYellow = timeYellow;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.CoordinateBean;

@XStreamAlias("LaneSegment")
public class LaneSegmentBean extends InfrastructureBean {
	private static final long serialVersionUID = 1264266915442374198L;
	private long sourceLane, sinkLane;
	private String type;
	private int laneIndex;
	private double laneWidth;
	private List<CoordinateBean> points;
	private List<CoordinateBean> leftEdge;
	private List<CoordinateBean> rightEdge;

	public LaneSegmentBean() {
	}

	public LaneSegmentBean(long uniqueId) {
		this.id = uniqueId;
	}

	public long getSourceLane() {
		return sourceLane;
	}

	public void setSourceLane(long sourceLane) {
		this.sourceLane = sourceLane;
	}

	public long getSinkLane() {
		return sinkLane;
	}

	public void setSinkLane(long sinkLane) {
		this.sinkLane = sinkLane;
	}

	public List<CoordinateBean> getPoints() {
		return points;
	}

	public void setPoints(List<CoordinateBean> points) {
		this.points = points;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getLaneIndex() {
		return laneIndex;
	}

	public void setLaneIndex(int laneIndex) {
		this.laneIndex = laneIndex;
	}

	public List<CoordinateBean> getLeftEdge() {
		return leftEdge;
	}

	public void setLeftEdge(List<CoordinateBean> leftEdge) {
		this.leftEdge = leftEdge;
	}

	public List<CoordinateBean> getRightEdge() {
		return rightEdge;
	}

	public void setRightEdge(List<CoordinateBean> rightEdge) {
		this.rightEdge = rightEdge;
	}

	public double getLaneWidth() {
		return laneWidth;
	}

	public void setLaneWidth(double laneWidth) {
		this.laneWidth = laneWidth;
	}

}

package at.fhhagenberg.mc.traffsim.data.beans;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public abstract class AbstractBean extends LabeledBean implements Serializable {

	private static final long serialVersionUID = -3280480270304773122L;

	@XStreamAsAttribute
	public long id;

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
}

package at.fhhagenberg.mc.traffsim.data.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.tuple.Pair;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.thoughtworks.xstream.XStream;

import at.fhhagenberg.mc.traffsim.data.TraffSimDataPlugin;
import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.BeanConfigurationContainer;
import at.fhhagenberg.mc.traffsim.data.beans.ListBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.util.ReflectionUtil;

/**
 * Serializer for data used by TraffSim simulator. This class saves and loads {@link List}s of java classes containing {@link AbstractBean}s
 * to XML files.
 *
 * @author Christian B.
 *
 */
public class DataSerializer extends BaseSerializer {
	public static final String CACHE_FILE_SUFFIX = ".javaobj";
	private Kryo kryo = new Kryo();

	/**
	 * Default constructor which performs initialization of {@link XStream}
	 *
	 */
	public DataSerializer() {
		super();
		kryo.setClassLoader(TraffSimDataPlugin.class.getClassLoader());
		kryo.setAutoReset(true);
		kryo.register(FileInfo.class);
	}

	/**
	 * Registers an alias for the given class for usage in the xml file. This must be called prior to writing data to the xml file or
	 * reading from it.<br>
	 * <br>
	 * <b>NOTE:</b>Make sure to use the same initialization for each use of serialization!
	 *
	 * @param alias
	 * @param clazz
	 */
	public void registerAlias(String alias, Class<?> clazz) {
		xstream.alias(alias, clazz);
	}

	/**
	 * Registers classes of which annotations should be processed, in order to read specified aliases and so on. This must be called prior
	 * to writing data to the xml file or reading from it.<br>
	 * <br>
	 * <b>NOTE:</b>Make sure to use the same initialization for each use of serialization!
	 *
	 * @param clazzes
	 */
	public void registerClasses(Class<?>[] clazzes) {
		xstream.processAnnotations(clazzes);
		for (Class<?> clazz : clazzes) {
			/**
			 * Add an additional ClassLoader which should be used for file lookup. This is essential if registering classes from different
			 * plugins
			 *
			 */
			this.additionalClassLoaders.add(clazz.getClassLoader());
		}
	}

	/**
	 * Write a single object, which is not an {@link AbstractBean} to the configuration. This object needs to take care of any Xstream
	 * specific parameters like attribute names, aliases, ignored fields etc. itself! <br>
	 * <br>
	 * <b>NOTE:</b> Please consider to register a filename for prior to writing the object, in case it should be a defined one. If no
	 * registered filename is found for this object type, a default one is created according to the name of the provided java class.
	 *
	 * @param object
	 *            the object to serialize
	 */
	public void writeObject(Object object) {
		File file = findFileFor(object);
		try {
			xstream.toXML(object, new FileWriter(file));

		} catch (IOException e) {
			Logger.getLogger(LOGGER_NAME).log(Level.SEVERE, "Could not write to file", e);
		}
	}

	/**
	 * Write a single object to the defined, configuration relative path. The provided object needs to take care of any {@link XStream}
	 * specific parameters like attribute names, aliases, ignored fields etc. itself!
	 *
	 * @param object
	 *            the object to write
	 * @param relativePath
	 *            the path of the target file, relative to the loaded configuration directory
	 * @throws IOException
	 *             if any error occurs
	 */
	public void writeObject(Object object, String relativePath) throws IOException {
		File file = new File(configurationDirectory, relativePath);
		xstream.toXML(object, new FileWriter(file));
	}

	/**
	 * Clears the data in the xml file for the specific class, if applicable.
	 *
	 * @param clazz
	 */
	public void clearData(Class<? extends AbstractBean> clazz) {
		File f = getFileFor(clazz.getName());
		writeData(f, new ArrayList<AbstractBean>());
	}

	public List<? extends AbstractBean> readData(Class<? extends AbstractBean> type) throws Exception {
		return readData(type, null, false);
	}

	public List<? extends AbstractBean> readData(Class<? extends AbstractBean> type, boolean useCache) throws Exception {
		return readData(type, null, useCache);
	}

	/**
	 * Read data of the given type from the persisted XML file.
	 *
	 * @param type
	 *            {@link AbstractBean}s which should be loaded.
	 * @param labels
	 *            a list of existing labels, to which a potentially defined label is appended. if not defined, or no auxiliary files are
	 *            referenced, nothing is appended
	 * @param useCache
	 * @return the loaded data, or empty {@link ArrayList}, but never <code>null</code>
	 * @throws Exception
	 *             if anything goes wrong
	 */
	@SuppressWarnings("unchecked")
	public List<? extends AbstractBean> readData(Class<? extends AbstractBean> type, List<String> labels, boolean useCache) throws Exception {
		if (configuration != null) {
			File f = getFileFor(type.getCanonicalName());
			if (f != null && !f.exists()) {
				// try to find in local dir, if not found in given path (can happen for batch scenarios, where relatively linked files are
				// copied to temp dir)
				f = new File(configuration.getConfigurationFile().getParentFile(), f.getName());
			}
			if (f != null && f.exists()) {
				Object listObj = readFromCache(f);
				/**
				 * set classloader to class that is currently loaded (if not done so, it leads to problems in case of different source
				 * plugins trying to load classes)
				 */
				xstream.setClassLoader(type.getClassLoader());
				if (listObj == null) {
					listObj = xstream.fromXML(f);
					writeToCache(f, listObj);
				}
				List<? extends AbstractBean> list = null;
				try {
					if (listObj instanceof ListBean) {
						ListBean lb = (ListBean) listObj;
						list = (List<? extends AbstractBean>) lb.getList();
						if (lb.isShuffle()) {
							Collections.shuffle(list);
						}
						if (labels != null) {
							labels.add(((ListBean) listObj).getLabel());
						}
					} else if (listObj instanceof List<?>) {
						list = (List<? extends AbstractBean>) listObj;
					}
				} catch (ClassCastException e) {
					return new ArrayList<AbstractBean>();
				}
				for (Pair<String, String> att : configuration.getBeanConfigurationsMapping().get(type.getName()).getAdditionalAttributes()) {
					File auxFile = new File(configuration.getConfigurationFile().getParentFile(), att.getRight());
					if (!auxFile.exists()) {
						// find file in current dir, if relative reference does not exist
						auxFile = new File(configuration.getConfigurationFile().getParentFile(), new File(att.getRight()).getName());
					}
					if (auxFile.exists()) {
						Object fromXML = readFromCache(auxFile);
						if (fromXML == null) {
							fromXML = xstream.fromXML(auxFile);
							writeToCache(auxFile, fromXML);
						}
						List<?> fromXMLList;
						if (fromXML instanceof List<?> || fromXML instanceof ListBean) {
							if (fromXML instanceof ListBean) {
								ListBean lb = (ListBean) fromXML;
								fromXMLList = lb.getList();
								if (lb.isShuffle()) {
									Collections.shuffle(fromXMLList);
								}
								if (labels != null) {
									labels.add(lb.getLabel());
								}
							} else {
								fromXMLList = ((List<?>) fromXML);
							}
							for (int i = 0; i < list.size() && i < fromXMLList.size(); i++) {
								AbstractBean bean = list.get(i);
								Object aux = fromXMLList.get(i);
								String fieldName = att.getLeft();
								ReflectionUtil.callSetterForField(bean, fieldName, aux);
							}
						}
					}
				}
				return list;
			}
		}
		return new ArrayList<AbstractBean>();

	}

	/**
	 * Read from a potentially existing cache file for original file
	 *
	 * @param originalFile
	 *            the original file for which a cache should be found and read
	 * @return the object read from the cache, or <code>null</code> if nothing found
	 * @throws FileNotFoundException
	 */
	private Object readFromCache(File originalFile) throws FileNotFoundException {
		File cacheFile;
		Object data = null;
		if ((cacheFile = getCacheFile(originalFile)).exists()) {
			Input input = new Input(new FileInputStream(cacheFile));
			try {
				FileInfo info = (FileInfo) kryo.readClassAndObject(input);
				if (info.getFileName().equals(originalFile.getAbsolutePath()) && info.getModifiedDate() == originalFile.lastModified()) {
					data = kryo.readClassAndObject(input);
				}
			} catch (Exception e) {
				return data;
			}
		}
		return data;
	}

	/**
	 * Write the data to the cache file for the provided file
	 *
	 * @param originalFile
	 * @param data
	 *            the data to write
	 * @throws FileNotFoundException
	 */
	private void writeToCache(File originalFile, Object data) throws FileNotFoundException {
		Output output = new Output(new FileOutputStream(getCacheFile(originalFile)));
		kryo.writeClassAndObject(output, new FileInfo(originalFile.lastModified(), originalFile.getAbsolutePath()));
		kryo.writeClassAndObject(output, data);
		output.flush();
		output.close();
	}

	private File getCacheFile(File originalFile) {
		return new File(originalFile.getAbsolutePath() + CACHE_FILE_SUFFIX);
	}

	/**
	 * Check if a file for the given type exists and contains any data. This method does not validate the contents for performance reasons!
	 * use for basic validation of configruation.
	 *
	 * @param type
	 *            the type of class to check
	 * @return <code>true</code> if the configuration contains a file with size &gt; 0 for the given type, <code>false</code> otherwise
	 */
	public boolean containsData(Class<? extends AbstractBean> type) {
		if (configuration != null) {
			File f = getFileFor(type.getCanonicalName());
			return f != null && f.exists() && f.length() > 0;
		}
		return false;
	}

	private File findFileFor(Object objToWrite) {
		if (objToWrite == null) {
			throw new NullPointerException("Provided object to find file for must not be null!");
		}
		for (BeanConfigurationContainer bcc : configuration.getBeanConfigurations()) {
			try {
				Class<?> clazz = Class.forName(bcc.getClassName());
				clazz.cast(objToWrite);
				return getFileFor(bcc.getFileName());
			} catch (ClassNotFoundException e) {
				Logger.getLogger(LOGGER_NAME).log(Level.SEVERE, "Given class '" + bcc.getClassName() + "' not found on classpath.", e);
			} catch (ClassCastException e) {
				// class not found. Continue
				continue;
			}
		}
		// no class found -> create entry in configuration
		final String newFilename = objToWrite.getClass().getSimpleName().toLowerCase() + ".xml";
		configuration.registerFilenameForClass(objToWrite.getClass(), newFilename);
		writeConfiguration(configuration.getConfigurationFile());
		return new File(configurationDirectory + "/" + newFilename);
	}

	public void setConfiguration(TraffSimConfiguration configuration) {
		this.configuration = configuration;
	}

	public TraffSimConfiguration getConfiguration() {
		return configuration;
	}

	public Date getStartTime() {
		return configuration.getStartTime();
	}

	public String getConfigurationDirectory() {
		return configurationDirectory;
	}

	public File getFullFile(String fileName) {
		return new File(configurationDirectory + "/" + fileName);
	}

}

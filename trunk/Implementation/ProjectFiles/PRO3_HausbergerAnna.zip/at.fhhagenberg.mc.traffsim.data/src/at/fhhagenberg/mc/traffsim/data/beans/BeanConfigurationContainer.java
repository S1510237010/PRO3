package at.fhhagenberg.mc.traffsim.data.beans;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Mapping between a class name, a file name containing the beans for this class, and additional custom field mappings (in the form
 * attribute to value)
 * 
 * @author Christian Backfrieder
 *
 */
public class BeanConfigurationContainer {
	private String className;
	private String fileName;
	private List<Pair<String, String>> additionalAttributes = new ArrayList<>();

	public BeanConfigurationContainer(String className, String fileName) {
		this.className = className;
		this.fileName = fileName;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void addAdditionalAttribute(String name, String value) {
		additionalAttributes.add(new ImmutablePair<>(name, value));
	}

	public List<Pair<String, String>> getAdditionalAttributes() {
		return additionalAttributes;
	}

	public void setAdditionalAttributes(List<Pair<String, String>> additionalAttributes) {
		this.additionalAttributes = additionalAttributes;
	}

}

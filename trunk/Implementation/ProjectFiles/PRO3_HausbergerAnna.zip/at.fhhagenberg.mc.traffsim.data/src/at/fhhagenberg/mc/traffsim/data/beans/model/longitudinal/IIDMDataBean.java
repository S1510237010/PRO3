package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("IIDM")
public class IIDMDataBean extends IDMDataBean {

	private static final long serialVersionUID = 1L;
}

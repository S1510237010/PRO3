package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;

public abstract class LongitudinalControlBean extends AbstractBean {

	@XStreamAsAttribute
	private String identifier;

	private String longitudinalModelIdentifier;
	private boolean cllxtEnabled = false;

	public LongitudinalControlBean() {
		super();
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getLongitudinalModelIdentifier() {
		return longitudinalModelIdentifier;
	}

	public void setLongitudinalModelIdentifier(String longitudinalModelIdentifier) {
		this.longitudinalModelIdentifier = longitudinalModelIdentifier;
	}

	public boolean getCllxtEnabled() {
		return cllxtEnabled;
	}

	public void setCllxtEnabled(boolean cllxtEnabled) {
		this.cllxtEnabled = cllxtEnabled;
	}
}
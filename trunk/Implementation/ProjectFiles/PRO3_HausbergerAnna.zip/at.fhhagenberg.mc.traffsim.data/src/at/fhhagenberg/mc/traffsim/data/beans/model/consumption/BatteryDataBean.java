package at.fhhagenberg.mc.traffsim.data.beans.model.consumption;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

public class BatteryDataBean extends ModelBean {

	private static final long serialVersionUID = 1L;

	private int mCells;
	private String mType;
	private double mMaxCharge;
	private double mCapacity;
	private double mK;

	public void setK(double _k) {
		mK = _k;
	}

	public double getK() {
		return mK;
	}

	public void setCapacity(double _capa) {
		mCapacity = _capa;
	}

	public double getCapacity() {
		return mCapacity;
	}

	public void setCells(int _cells) {
		mCells = _cells;
	}

	public int getCells() {
		return mCells;
	}

	public void setType(String _type) {
		mType = _type;
	}

	public String getType() {
		return mType;
	}

	public void setMaxCharge(double _max) {
		mMaxCharge = _max;
	}

	public double getMaxCharge() {
		return mMaxCharge;
	}

}

package at.fhhagenberg.mc.traffsim.data.beans.model;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;

public abstract class ModelBean extends AbstractBean {
	@XStreamAsAttribute
	private String modelIdentifier;
	private String fullName;

	/** The type of the model. By its help, the model is identified in the simulator (can be e.g. IDM, */

	public ModelBean() {
	}

	public ModelBean(String identifier) {
		super();
		this.modelIdentifier = identifier;
	}

	/**
	 * @return the modelName
	 */
	public String getModelIdentifier() {
		return modelIdentifier;
	}

	/**
	 * @param modelIdentifier
	 *            the modelName to set
	 */
	public void setModelIdentifier(String modelIdentifier) {
		this.modelIdentifier = modelIdentifier;
	}

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName
	 *            the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

}

package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("OVM")
public class OVMDataBean extends LongitudinalModelInputDataBean {

	private static final long serialVersionUID = 1L;
	private double beta = 0.0;
	private double gamma = 0.0;
	private String ovmFunction;

	private double tau = 0.0;

	private double transitionWidth = 0.0;

	public double getBeta() {
		return beta;
	}

	public double getGamma() {
		return gamma;
	}

	public String getOVMFunction() {
		return ovmFunction;
	}

	public double getTau() {
		return tau;
	}

	public double getTransitionWidth() {
		return transitionWidth;
	}

	public void setBeta(double beta) {
		this.beta = beta;
	}

	public void setGamma(double gamma) {
		this.gamma = gamma;
	}

	public void setOVMFunction(String ovmFunction) {
		this.ovmFunction = ovmFunction;
	}

	public void setTau(double tau) {
		this.tau = tau;
	}

	public void setTransitionWidth(double transitionWidth) {
		this.transitionWidth = transitionWidth;
	}
}
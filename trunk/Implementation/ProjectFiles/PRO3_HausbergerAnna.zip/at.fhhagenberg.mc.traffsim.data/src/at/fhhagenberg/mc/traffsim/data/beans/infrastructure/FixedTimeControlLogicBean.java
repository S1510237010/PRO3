package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("FixedTime")
public class FixedTimeControlLogicBean extends ControlLogicBean {

	private static final long serialVersionUID = 1L;

	private long delay;
	private long timeGreen;
	private long timeRed;
	private boolean isGreenInitially;
	private long offset;

	public long getDelay() {
		return delay;
	}

	public void setDelay(long delay) {
		this.delay = delay;
	}

	public long getTimeGreen() {
		return timeGreen;
	}

	public void setTimeGreen(long timeGreen) {
		this.timeGreen = timeGreen;
	}

	public long getTimeRed() {
		return timeRed;
	}

	public void setTimeRed(long timeRed) {
		this.timeRed = timeRed;
	}

	public boolean getIsGreenInitially() {
		return isGreenInitially;
	}

	public void setIsGreenInitially(boolean isGreenInitially) {
		this.isGreenInitially = isGreenInitially;
	}
	
	public long getOffset() {
		return offset;
	}

	public void setOffset(long offset) {
		this.offset = offset;
	}
}

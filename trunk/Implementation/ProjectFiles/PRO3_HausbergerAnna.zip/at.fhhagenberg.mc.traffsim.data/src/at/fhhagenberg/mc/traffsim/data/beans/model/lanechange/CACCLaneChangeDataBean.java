package at.fhhagenberg.mc.traffsim.data.beans.model.lanechange;

import com.thoughtworks.xstream.annotations.XStreamAlias;
/**
 * Data bean for platooning lane change model
 * 
 * @author Sebastian Huber
 *
 */
@XStreamAlias("CACCLC")
public class CACCLaneChangeDataBean extends LaneChangeModelInputDataBean {
	
	private static final long serialVersionUID = 6727727890582152148L;

	/**
	 * Identifier for the human model
	 */
	private String humanLaneChangeModelIdentifier;
	
	/**
	 * Identifier for the leader model
	 */
	private String leaderLaneChangeModelIdentifier;
	
	/**
	 * Flag to enable leader model for lane changes of platoon
	 */
	private boolean platoonLaneChangeEnabled;
	
	/**
	 * Minimum distance between vehicles
	 */
	private double sMin;
	
	/**
	 * Max deceleration of vehicle
	 */
	private double maxDec;

	/**
	 * Safe deceleration of vehicle
	 */
	private double safeDec;

	/**
	 * Get human lane change model identifier
	 * @return identifier
	 */
	public String getHumanLaneChangeModelIdentifier() {
		return humanLaneChangeModelIdentifier;
	}

	/**
	 * Set human lane change model identifier
	 * @param humanLaneChangeModelIdentifier identifier
	 */
	public void setHumanLaneChangeModelIdentifier(String humanLaneChangeModelIdentifier) {
		this.humanLaneChangeModelIdentifier = humanLaneChangeModelIdentifier;
	}
	
	
	/**
	 * Get leader lane change model identifier
	 * @return identifier
	 */
	public String getLeaderLaneChangeModelIdentifier() {
		return leaderLaneChangeModelIdentifier;
	}

	/**
	 * Set leader lane change model identifier
	 * @param leaderLaneChangeModelIdentifier identifier
	 */
	public void setLeaderLaneChangeModelIdentifier(String leaderLaneChangeModelIdentifier) {
		this.leaderLaneChangeModelIdentifier = leaderLaneChangeModelIdentifier;
	}

	/**
	 * Get flag for enabling lane changes for platoon
	 * @return enabled
	 */
	public boolean isPlatoonLaneChangeEnabled() {
		return platoonLaneChangeEnabled;
	}

	/**
	 * Set flag for enabling lane changes for platoon
	 * @param platoonLaneChangeEnabled enabled
	 */
	public void setPlatoonLaneChangeEnabled(boolean platoonLaneChangeEnabled) {
		this.platoonLaneChangeEnabled = platoonLaneChangeEnabled;
	}

	/**
	 * Minimum distance between vehicles
	 * @return sMin
	 */
	public double getsMin() {
		return sMin;
	}

	/**
	 * Minimum distance between vehicles
	 * @param sMin sMin
	 */
	public void setsMin(double sMin) {
		this.sMin = sMin;
	}

	/**
	 * Max deceleration of vehicle
	 * @return maxDec
	 */
	public double getMaxDec() {
		return maxDec;
	}

	/**
	 * Max deceleration of vehicle
	 * @param maxDec maxDec
	 */
	public void setMaxDec(double maxDec) {
		this.maxDec = maxDec;
	}

	/**
	 * Safe deceleration of vehicle
	 * @return safeDec
	 */
	public double getSafeDec() {
		return safeDec;
	}

	/**
	 * Safe deceleration of vehicle
	 * @param safeDec safeDec
	 */
	public void setSafeDec(double safeDec) {
		this.safeDec = safeDec;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

public abstract class LongitudinalModelInputDataBean extends ModelBean {

	private double comfortableAcc;
	private double sMin;
	private double vTarget;

	public double getComfortableAcc() {
		return comfortableAcc;
	}

	public double getsMin() {
		return sMin;
	}

	public double getvTarget() {
		return vTarget;
	}

	public void setComfortableAcc(double comfortableAcc) {
		this.comfortableAcc = comfortableAcc;
	}

	public void setsMin(double sMin) {
		this.sMin = sMin;
	}

	public void setvTarget(double vTarget) {
		this.vTarget = vTarget;
	}
}
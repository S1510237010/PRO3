package at.fhhagenberg.mc.traffsim.data.beans;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("TrafficGenerator")
public class TrafficGeneratorBean extends AbstractBean {

	private static final long serialVersionUID = 1L;
	private String longitudinalControlRef;
	private String laneChangeModelRef;
	private String memoryModelRef;
	private String fuelConsumptionModelRef;
	
	private long initialRoadSegmentId;
	private double speedInitial;
	private double speedAverage;
	private double speedAverageStdDeviation;
	private double inFlowRate;
	private double inFlowRateStdDeviation;
	
	private boolean isStochastic;
	private double sampleInterval;
	private double vehicleLengthStdDeviation;
	
	private List<Long> possibleRouteIds = new ArrayList<>();
	private int maxNumVehicles = 0;

	public TrafficGeneratorBean() {
	}

	public TrafficGeneratorBean(long id, double speedInitial, long initialRoadSegmentId, double inFlowRate, double speedAverage,
			double speedAverageStdDeviation, List<Long> possibleRouteIds) {
		super();
		this.id = id;
		this.speedInitial = speedInitial;
		this.initialRoadSegmentId = initialRoadSegmentId;
		this.inFlowRate = inFlowRate;
		this.speedAverage = speedAverage;
		this.speedAverageStdDeviation = speedAverageStdDeviation;
		this.possibleRouteIds = possibleRouteIds;
	}

	public double getInFlowRate() {
		return inFlowRate;
	}

	public void setInFlowRate(double inFlowRate) {
		this.inFlowRate = inFlowRate;
	}
	
	public double getInFlowRateStdDeviation(){
		return inFlowRateStdDeviation;
	}
	
	public void setInFlowRateStdDeviation(double inFlowRateStdDeviation){
		this.inFlowRateStdDeviation = inFlowRateStdDeviation;
	}

	public long getInitialRoadSegmentId() {
		return initialRoadSegmentId;
	}

	public void setInitialRoadSegmentId(long initialRoadSegmentId) {
		this.initialRoadSegmentId = initialRoadSegmentId;
	}

	public double getSpeedAverage() {
		return speedAverage;
	}

	public void setSpeedAverage(double speedAverage) {
		this.speedAverage = speedAverage;
	}

	public double getAverageSpeedStdDeviation() {
		return speedAverageStdDeviation;
	}

	public void setSpeedAverageStdDeviation(double speedAverageStdDeviation) {
		this.speedAverageStdDeviation = speedAverageStdDeviation;
	}

	public List<Long> getPossibleRouteIds() {
		return possibleRouteIds;
	}

	public void setPossibleRouteIds(List<Long> possibleRouteIds) {
		this.possibleRouteIds = possibleRouteIds;
	}

	public double getSpeedInitial() {
		return speedInitial;
	}

	public void setSpeedInitial(double speedInitial) {
		this.speedInitial = speedInitial;
	}

	public String getLongitudinalControlRef() {
		return longitudinalControlRef;
	}

	public void setLongitudinalControlRef(String longitudinalControlRef) {
		this.longitudinalControlRef = longitudinalControlRef;
	}

	public String getLaneChangeModelRef() {
		return laneChangeModelRef;
	}

	public void setLaneChangeModelRef(String laneChangeModelRef) {
		this.laneChangeModelRef = laneChangeModelRef;
	}

	public double getVehicleLengthStdDeviation() {
		return vehicleLengthStdDeviation;
	}

	public void setVehicleLengthStdDeviation(double vehicleLengthStdDeviation) {
		this.vehicleLengthStdDeviation = vehicleLengthStdDeviation;
	}

	public String getMemoryModelRef() {
		return memoryModelRef;
	}

	public void setMemoryModelRef(String memoryModelRef) {
		this.memoryModelRef = memoryModelRef;
	}

	public String getFuelConsumptionModelRef() {
		return fuelConsumptionModelRef;
	}

	public void setFuelConsumptionModelRef(String fuelConsumptionModelRef) {
		this.fuelConsumptionModelRef = fuelConsumptionModelRef;
	}

	public int getMaxNumVehicles() {
		return maxNumVehicles;
	}

	public void setMaxNumVehicles(int maxNumVehicles) {
		this.maxNumVehicles = maxNumVehicles;
	}
	
	public boolean getIsStochastic(){
		return isStochastic;
	}
	
	public void setIsStochastic(boolean isStochastic){
		this.isStochastic = isStochastic;
	}
	
	public double getSampleInterval(){
		return sampleInterval;
	}
	
	public void setSampleInterval(double sampleInterval){
		this.sampleInterval = sampleInterval;
	}
}

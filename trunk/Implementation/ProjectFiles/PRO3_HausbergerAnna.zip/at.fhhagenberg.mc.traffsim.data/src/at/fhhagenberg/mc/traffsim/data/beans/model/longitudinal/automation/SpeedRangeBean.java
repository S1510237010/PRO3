package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("speedRange")
public class SpeedRangeBean {

	private double fromSpeed;
	private double toSpeed;
	private double fallbackProbability;

	public double getFromSpeed() {
		return fromSpeed;
	}

	public void setFromSpeed(double fromSpeed) {
		this.fromSpeed = fromSpeed;
	}

	public double getToSpeed() {
		return toSpeed;
	}

	public void setToSpeed(double toSpeed) {
		this.toSpeed = toSpeed;
	}

	public double getFallbackProbability() {
		return fallbackProbability;
	}

	public void setFallbackProbability(double fallbackProbability) {
		this.fallbackProbability = fallbackProbability;
	}
}

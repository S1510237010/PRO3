package at.fhhagenberg.mc.traffsim.data.beans;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("CommData")
public class VehicleCommDataBean extends AbstractBean {
	private static final long serialVersionUID = 1L;
	private Long vehicleDataCommInterval;
	private Long staticRouteUpdateInterval;
	private Long dynamicRouteUpdateThreshold;

	public Long getStaticRouteUpdateInterval() {
		return staticRouteUpdateInterval;
	}

	public void setStaticRouteUpdateInterval(Long staticRouteUpdateInterval) {
		this.staticRouteUpdateInterval = staticRouteUpdateInterval;
	}

	public Long getDynamicRouteUpdateThreshold() {
		return dynamicRouteUpdateThreshold;
	}

	public void setDynamicRouteUpdateThreshold(Long dynamicRouteUpdateThreshold) {
		this.dynamicRouteUpdateThreshold = dynamicRouteUpdateThreshold;
	}

	public Long getVehicleDataCommInterval() {
		return vehicleDataCommInterval;
	}

	public void setVehicleDataCommInterval(Long vehicleDataCommInterval) {
		this.vehicleDataCommInterval = vehicleDataCommInterval;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dynamicRouteUpdateThreshold == null) ? 0 : dynamicRouteUpdateThreshold.hashCode());
		result = prime * result + ((staticRouteUpdateInterval == null) ? 0 : staticRouteUpdateInterval.hashCode());
		result = prime * result + ((vehicleDataCommInterval == null) ? 0 : vehicleDataCommInterval.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VehicleCommDataBean other = (VehicleCommDataBean) obj;
		if (dynamicRouteUpdateThreshold == null) {
			if (other.dynamicRouteUpdateThreshold != null)
				return false;
		} else if (!dynamicRouteUpdateThreshold.equals(other.dynamicRouteUpdateThreshold))
			return false;
		if (staticRouteUpdateInterval == null) {
			if (other.staticRouteUpdateInterval != null)
				return false;
		} else if (!staticRouteUpdateInterval.equals(other.staticRouteUpdateInterval))
			return false;
		if (vehicleDataCommInterval == null) {
			if (other.vehicleDataCommInterval != null)
				return false;
		} else if (!vehicleDataCommInterval.equals(other.vehicleDataCommInterval))
			return false;
		return true;
	}
}

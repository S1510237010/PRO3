package at.fhhagenberg.mc.traffsim.data.beans.model.platoon;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;

/**
 * Data bean for platoon manager
 * 
 * @author Sebastian Huber
 *
 */
@XStreamAlias("PlatoonManager")
public class PlatoonManagerDataBean extends AbstractBean {
	
	private static final long serialVersionUID = 8674708198475695993L;

	/**
	 * Parameters for platoon creation
	 */
	private PlatoonDataBean platoonData;
	
	/**
	 * Timeout for retrying an action in the action queue if not succeed
	 */
	private long actionTimeout;
	
	/**
	 * Predefined action for platooning
	 */
	private List<PlatoonActionDataBean> platoonActions;
	
	
	/**
	 * Get parameters for platoon creation
	 * @return platoon data
	 */
	public PlatoonDataBean getPlatoonData() {
		return platoonData;
	}

	/**
	 * Set parameters for platoon creation
	 * @param platoonData platoon data
	 */
	public void setPlatoonData(PlatoonDataBean platoonData) {
		this.platoonData = platoonData;
	}

	/**
	 * Get timeout for retrying a platoon action before it is removed from queue
	 * @return timeout
	 */
	public long getActionTimeout() {
		return actionTimeout;
	}

	/**
	 * Set timeout for retrying a platoon action before it is removed from queue
	 * @param actionTimeout timeout
	 */
	public void setActionTimeout(long actionTimeout) {
		this.actionTimeout = actionTimeout;
	}

	/**
	 * Getter for predefined platoon actions
	 * @return list of actions
	 */
	public List<PlatoonActionDataBean> getPlatoonActions() {
		return platoonActions;
	}
	
	/**
	 * Setter for predefined platoon actions
	 * @param platoonActions list of actions
	 */
	public void setPlatoonActions(List<PlatoonActionDataBean> platoonActions) {
		this.platoonActions = platoonActions;
	}
}

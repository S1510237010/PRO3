package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("drivingRegime")
public class DrivingRegimeBean {

	private String regime;
	private double fallbackProbability;

	public String getRegime() {
		return regime;
	}

	public void setRegime(String regime) {
		this.regime = regime;
	}

	public double getFallbackProbability() {
		return fallbackProbability;
	}

	public void setFallbackProbability(double fallbackProbability) {
		this.fallbackProbability = fallbackProbability;
	}
}

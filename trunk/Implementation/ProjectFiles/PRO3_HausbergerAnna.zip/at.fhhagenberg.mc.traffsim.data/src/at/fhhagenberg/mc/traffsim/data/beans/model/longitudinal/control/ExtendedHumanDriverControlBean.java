package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.RTDataBean;

@XStreamAlias("ExtendedHumanDriver")
public class ExtendedHumanDriverControlBean extends LongitudinalControlBean {

	private static final long serialVersionUID = 1L;
	// Noise and distraction models
	private String accelerationNoiseIdentifier;
	private String distanceNoiseIdentifier;
	private String velocityDifferenceNoiseIdentifier;

	// Spatial anticipation
	private int numConsideredVehicles;
	private double sightDistance;

	// Finite reaction times and timely anticipation
	private RTDataBean responseTimes;

	// Driving regimes
	private double spaceHeadwayThreshold;

	public String getAccelerationNoiseIdentifier() {
		return accelerationNoiseIdentifier;
	}

	public void setAccelerationNoiseIdentifier(String accelerationNoiseIdentifier) {
		this.accelerationNoiseIdentifier = accelerationNoiseIdentifier;
	}

	public String getDistanceNoiseIdentifier() {
		return distanceNoiseIdentifier;
	}

	public void setDistanceNoiseIdentifier(String distanceNoiseIdentifier) {
		this.distanceNoiseIdentifier = distanceNoiseIdentifier;
	}

	public String getVelocityDifferenceNoiseIdentifier() {
		return velocityDifferenceNoiseIdentifier;
	}

	public void setVelocityDifferenceNoiseIdentifier(String velocityDifferenceNoiseIdentifier) {
		this.velocityDifferenceNoiseIdentifier = velocityDifferenceNoiseIdentifier;
	}

	public int getNumConsideredVehicles() {
		return numConsideredVehicles;
	}

	public void setNumConsideredVehicles(int numConsideredVehicles) {
		this.numConsideredVehicles = numConsideredVehicles;
	}

	public double getSightDistance() {
		return sightDistance;
	}

	public void setSightDistance(double sightDistance) {
		this.sightDistance = sightDistance;
	}

	public RTDataBean getResponseTimes() {
		return responseTimes;
	}

	public void setResponseTimes(RTDataBean responseTimes) {
		this.responseTimes = responseTimes;
	}

	public double getSpaceHeadwayThreshold() {
		return spaceHeadwayThreshold;
	}

	public void setSpaceHeadwayThreshold(double spaceHeadwayThreshold) {
		this.spaceHeadwayThreshold = spaceHeadwayThreshold;
	}
}

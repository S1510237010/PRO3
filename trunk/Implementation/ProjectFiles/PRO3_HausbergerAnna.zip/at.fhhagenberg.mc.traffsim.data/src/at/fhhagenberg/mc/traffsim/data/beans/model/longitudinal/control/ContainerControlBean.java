package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.util.StringUtil;

public abstract class ContainerControlBean extends LongitudinalControlBean {

	@XStreamAlias("controlIdentifiers")
	private List<String> controlIdentifiers = new ArrayList<>();

	public ContainerControlBean() {
		super();
	}

	public List<String> getControlIdentifiers() {
		return this.controlIdentifiers;
	}

	public void setControlIdentifiers(List<String> controlIdentifiers) {
		this.controlIdentifiers = controlIdentifiers;
	}

	public void addControlIdentifier(String controlIdentifier) {
		if (!StringUtil.isNullOrEmpty(controlIdentifier) && !controlIdentifiers.contains(controlIdentifier)) {
			controlIdentifiers.add(controlIdentifier);
		}
	}

	public void removeControlIdentifier(String controlIdentifier) {
		if (!StringUtil.isNullOrEmpty(controlIdentifier) && controlIdentifiers.contains(controlIdentifier)) {
			controlIdentifiers.remove(controlIdentifier);
		}
	}

	public void removeFirstControlIdentifer() {
		if (controlIdentifiers.size() > 0) {
			controlIdentifiers.remove(0);
		}
	}

	public void removeLastControlIdentifier() {
		if (controlIdentifiers.size() > 0) {
			controlIdentifiers.remove(controlIdentifiers.size() - 1);
		}
	}

	public int getNumChildControls() {
		if (controlIdentifiers != null) {
			return controlIdentifiers.size();
		}

		return 0;
	}
}

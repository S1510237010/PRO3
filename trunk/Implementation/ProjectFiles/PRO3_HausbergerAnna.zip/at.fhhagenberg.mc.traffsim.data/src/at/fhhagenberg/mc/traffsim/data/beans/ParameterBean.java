package at.fhhagenberg.mc.traffsim.data.beans;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

import at.fhhagenberg.mc.util.LinkedProperties;

@XStreamAlias("ParameterSet")
public class ParameterBean extends AbstractBean {
	private static final long serialVersionUID = 1L;
	@XStreamAlias("params")
	private LinkedProperties properties;
	@XStreamAsAttribute
	private String name;
	@XStreamAsAttribute
	private boolean enabled;

	public ParameterBean() {
	}

	public LinkedProperties getProperties() {
		return properties;
	}

	public void setProperties(LinkedProperties properties) {
		this.properties = properties;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
}

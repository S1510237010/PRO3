package at.fhhagenberg.mc.traffsim.data.beans;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("LabeledList")
public class ListBean extends LabeledBean implements Serializable {
	private static final long serialVersionUID = -1761457550911178820L;
	private List<?> list;
	@XStreamAsAttribute
	private boolean shuffle;

	public List<?> getList() {
		return list;
	}

	public void setList(List<?> list) {
		this.list = list;
	}

	public boolean isShuffle() {
		return shuffle;
	}

	public void setShuffle(boolean randomize) {
		this.shuffle = randomize;
	}
}

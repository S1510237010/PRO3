package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("HumanDriver")
public class HumanDriverControlBean extends LongitudinalControlBean {

	private static final long serialVersionUID = 1L;
	// Noise models
	private String distanceNoiseIdentifier;
	private String velocityDifferenceNoiseIdentifier;

	// Spatial anticipation
	private int numConsideredVehicles;

	// Timely anticipation
	private boolean isAnticipative;

	// Finite reaction time
	private boolean isReactive;
	private double reactionTime;

	public String getDistanceNoiseIdentifier() {
		return distanceNoiseIdentifier;
	}

	public void setDistanceNoiseIdentifier(String distanceNoiseIdentifier) {
		this.distanceNoiseIdentifier = distanceNoiseIdentifier;
	}

	public String getVelocityDifferenceNoiseIdentifier() {
		return velocityDifferenceNoiseIdentifier;
	}

	public void setVelocityDifferenceNoiseIdentifier(String velocityDifferenceNoiseIdentifier) {
		this.velocityDifferenceNoiseIdentifier = velocityDifferenceNoiseIdentifier;
	}

	public int getNumConsideredVehicles() {
		return numConsideredVehicles;
	}

	public void setNumConsideredVehicles(int numConsideredVehicles) {
		this.numConsideredVehicles = numConsideredVehicles;
	}

	public boolean getIsAnticipative() {
		return isAnticipative;
	}

	public void setIsAnticipative(boolean isAnticipative) {
		this.isAnticipative = isAnticipative;
	}

	public boolean getIsReactive() {
		return isReactive;
	}

	public void setIsReactive(boolean isReactive) {
		this.isReactive = isReactive;
	}

	public double getReactionTime() {
		return reactionTime;
	}

	public void setReactionTime(double reactionTime) {
		this.reactionTime = reactionTime;
	}
}

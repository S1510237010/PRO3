package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("NOISE")
public class NoiseDataBean extends ModelBean {

	private static final long serialVersionUID = 1L;
	/** The fluctuation strength in m^2/s^3 **/
	private double fluctStrength;

	/** The tau relax acceleration in seconds ( ~20) **/
	private double tau;

	/** Amplificiation variable **/
	private double amplifier;

	public double getFluctStrength() {
		return fluctStrength;
	}

	public void setFluctStrength(double fluctStrength) {
		this.fluctStrength = fluctStrength;
	}

	public double getTau() {
		return tau;
	}

	public void setTau(double tau) {
		this.tau = tau;
	}

	public double getAmplifier() {
		return amplifier;
	}

	public void setAmplifier(double amplifier) {
		this.amplifier = amplifier;
	}
}

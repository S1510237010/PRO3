package at.fhhagenberg.mc.traffsim.data;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class TraffSimDataPlugin implements BundleActivator {
	public static final String PLUGIN_ID = "at.fhhagenberg.mc.traffsim.data";

	@Override
	public void start(BundleContext context) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop(BundleContext context) throws Exception {
		// TODO Auto-generated method stub

	}

}

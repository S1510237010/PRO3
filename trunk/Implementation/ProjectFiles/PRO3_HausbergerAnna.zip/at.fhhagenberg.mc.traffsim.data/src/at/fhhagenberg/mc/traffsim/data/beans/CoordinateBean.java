package at.fhhagenberg.mc.traffsim.data.beans;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Coordinate")
public class CoordinateBean {

	@XStreamAsAttribute
	private double x;
	@XStreamAsAttribute
	private double y;

	public CoordinateBean() {
	}

	public CoordinateBean(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return x + " " + y;
	}
}

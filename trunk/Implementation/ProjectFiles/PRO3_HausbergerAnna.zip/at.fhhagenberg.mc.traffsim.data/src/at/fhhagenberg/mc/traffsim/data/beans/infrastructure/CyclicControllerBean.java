package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("CyclicController")
public class CyclicControllerBean extends TrafficLightControllerBean{

	private static final long serialVersionUID = 1L;
	
	private boolean startWithGreen;

	public boolean getStartWithGreen() {
		return startWithGreen;
	}

	public void setStartWithGreen(boolean startWithGreen) {
		this.startWithGreen = startWithGreen;
	}
}

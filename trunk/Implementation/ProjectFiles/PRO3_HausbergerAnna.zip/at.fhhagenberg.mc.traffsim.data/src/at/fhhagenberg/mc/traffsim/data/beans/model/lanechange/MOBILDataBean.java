package at.fhhagenberg.mc.traffsim.data.beans.model.lanechange;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("MOBIL")
public class MOBILDataBean extends LaneChangeModelInputDataBean {

	private static final long serialVersionUID = 1L;
	private double biasRight;

	private double maxDec;

	private double politeness;

	private double safeDec;

	private double sMin;

	private double threshold;

	public double getBiasRight() {
		return biasRight;
	}

	public double getMaxDec() {
		return maxDec;
	}

	public double getPoliteness() {
		return politeness;
	}

	public double getSafeDec() {
		return safeDec;
	}

	public double getsMin() {
		return sMin;
	}

	public double getThreshold() {
		return threshold;
	}

	public void setBiasRight(double biasRight) {
		this.biasRight = biasRight;
	}

	public void setMaxDec(double maxDec) {
		this.maxDec = maxDec;
	}

	public void setPoliteness(double politeness) {
		this.politeness = politeness;
	}

	public void setSafeDec(double safeDec) {
		this.safeDec = safeDec;
	}

	public void setsMin(double sMin) {
		this.sMin = sMin;
	}

	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}
}

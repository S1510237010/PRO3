package at.fhhagenberg.mc.traffsim.data.xml;

import java.util.Properties;

import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.converters.collections.PropertiesConverter;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;

import at.fhhagenberg.mc.util.LinkedProperties;

/**
 * Converter for {@link Properties}, which preserves the order of properties as specified in the file by using the inherited
 * {@link LinkedProperties}, that allows ordering properties
 * 
 * @author Christian Backfrieder
 *
 */
public class LinkedPropertiesConverter extends PropertiesConverter {
	@Override
	public boolean canConvert(@SuppressWarnings("rawtypes") Class type) {
		return super.canConvert(type) || LinkedProperties.class == type;
	}

	@Override
	public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
		LinkedProperties properties = new LinkedProperties();
		LinkedProperties defaults = null;
		while (reader.hasMoreChildren()) {
			reader.moveDown();
			if (reader.getNodeName().equals("defaults")) {
				defaults = (LinkedProperties) unmarshal(reader, context);
			} else {
				String name = reader.getAttribute("name");
				String value = reader.getAttribute("value");
				properties.setProperty(name, value);
			}
			reader.moveUp();
		}
		if (defaults == null) {
			return properties;
		} else {
			Properties propertiesWithDefaults = new Properties(defaults);
			propertiesWithDefaults.putAll(properties);
			return propertiesWithDefaults;
		}
	}
}

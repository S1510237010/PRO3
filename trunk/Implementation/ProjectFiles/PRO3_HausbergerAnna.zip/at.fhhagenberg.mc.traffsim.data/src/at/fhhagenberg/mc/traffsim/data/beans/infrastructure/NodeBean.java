package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Node only has an ID, and is referenced by RoadSegments as start and end.
 *
 * can be a crossing, in case of more than 2 connectors (i.e. referers using the id). The interpretation is responsibility of the reading
 * entity.
 *
 * @author Christian B.
 *
 */
@XStreamAlias("Node")
public class NodeBean extends InfrastructureBean {
	private static final long serialVersionUID = 1L;
	private static long nextId = 0;
	private double altitude = Double.NaN;
	private NodeType type = NodeType.SIMPLE;
	/** list of node ids that were merged with this one during initialization */
	private List<Long> secondaryIds;

	/**
	 * Create new node bean without an ID. <br>
	 * <br>
	 * <b>ATTENTION:</b> Do NOT use this constructor and #{@link #NodeBean(long)} in parallel, since this may lead to duplicate ids!
	 */
	public NodeBean() {
		this.id = nextId++;
	}

	/**
	 * Create node using id. This ID must be unique!
	 *
	 * <b>ATTENTION:</b> Do NOT use this constructor and #{@link #NodeBean()} in parallel, since this may lead to duplicate ids!
	 *
	 * @param id
	 */
	public NodeBean(long id) {
		this.id = id;
		nextId = id;
	}

	/**
	 * Create node using id. This ID must be unique!
	 *
	 * <b>ATTENTION:</b> Do NOT use this constructor and #{@link #NodeBean()} in parallel, since this may lead to duplicate ids!
	 *
	 * @param id
	 * @param altitude
	 */
	public NodeBean(long id, double altitude) {
		this(id);
		this.altitude = altitude;
	}

	/**
	 * @return the geographic altitude of this node in meters above sea level, or {@link Double#NaN} if unknown
	 */
	public double getAltitude() {
		return altitude;
	}

	/**
	 *
	 * @param altitude
	 *            the geographic altitude in meters above sea level, or {@link Double#NaN} if unknown
	 */
	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	public NodeType getType() {
		return type;
	}

	public void setType(NodeType type) {
		this.type = type;
	}

	public List<Long> getSecondaryIds() {
		return secondaryIds;
	}

	public void setSecondaryIds(List<Long> secondaryIds) {
		this.secondaryIds = secondaryIds;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Default")
public class DefaultLongitudinalControlBean extends LongitudinalControlBean {
	private static final long serialVersionUID = 1L;

}

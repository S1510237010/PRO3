package at.fhhagenberg.mc.traffsim.data.beans.model.distraction;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("DistractionType")
public class DistractionTypeBean {

	@XStreamAsAttribute
	private long id;

	private String description;

	// Number of distractive events occurring per hour
	private double frequency;

	// Percent of all drivers engaging in the type of distraction
	private double exposure;

	// Mean, minimum and maximum duration
	private double meanDuration;
	private double stdDuration;
	private double minDuration;
	private double maxDuration;

	// Determines the bounds by which factor the driver's response time is affected
	private double minDelay;
	private double maxDelay;

	// Determines whether the distraction is severe or not
	private boolean isSevere;

	private boolean isStochastic;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setIsStochastic(boolean isStochastic) {
		this.isStochastic = isStochastic;
	}

	public boolean getIsStochastic() {
		return isStochastic;
	}

	public double getFrequency() {
		return frequency;
	}

	public void setFrequency(double frequency) {
		this.frequency = frequency;
	}

	public double getExposure() {
		return exposure;
	}

	public void setExposure(double exposure) {
		this.exposure = exposure;
	}

	public double getMeanDuration() {
		return meanDuration;
	}

	public void setMeanDuration(double meanDuration) {
		this.meanDuration = meanDuration;
	}

	public double getStdDuration() {
		return stdDuration;
	}

	public void setStdDuration(double stdDuration) {
		this.stdDuration = stdDuration;
	}

	public double getMinDuration() {
		return minDuration;
	}

	public void setMinDuration(double minDuration) {
		this.minDuration = minDuration;
	}

	public double getMaxDuration() {
		return maxDuration;
	}

	public void setMaxDuration(double maxDuration) {
		this.maxDuration = maxDuration;
	}

	public double getMinDelay() {
		return minDelay;
	}

	public void setMinDelay(double minDelay) {
		this.minDelay = minDelay;
	}

	public double getMaxDelay() {
		return maxDelay;
	}

	public void setMaxDelay(double maxDelay) {
		this.maxDelay = maxDelay;
	}

	public boolean isSevere() {
		return isSevere;
	}

	public void setIsSevere(boolean isSevere) {
		this.isSevere = isSevere;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.CoordinateBean;

/**
 * This class contains the basic information that is necessary for defining a road segment. It contains information available from OSM, and
 * should only contain OSM-suitable data.
 *
 * @author Christian Backfrieder
 *
 */
@XStreamAlias("BaseRoadSegment")
public class BaseRoadSegmentBean extends InfrastructureBean {
	private static final long serialVersionUID = -2072542364870066579L;
	private static final int DEFAULT_LANE_COUNT = 1;
	private static final String DEFAULT_NAME = "";

	/** The polygon geometry */
	protected List<CoordinateBean> points;
	/** Ids of source and sink nodes. */
	protected long sourceNodeId;
	/** Ids of source and sink nodes. */
	protected long sinkNodeId;
	/** number of lanes in this road segment (unidirectional!) */
	protected int laneCount = DEFAULT_LANE_COUNT;
	/**
	 * The ID for this part of the road which is used for routing. This needs not to be unique within the whole system, but just for all
	 * driving possibilities out of a crossing
	 */
	protected long routingId;
	private double speedLimit = Double.POSITIVE_INFINITY;
	private String name = DEFAULT_NAME;
	private boolean reverse;

	private String restrictions;
	private String meta;

	/**
	 * IDs of lanes which are entry lanes, numbered from the middle of the road as lane 0 (left-most lane, contiguously to the right-most
	 * lane, which respectively has the highest index). Should always be the rightmost lane!
	 */
	private int[] entryLanes;
	/** see {@link #entryLanes} */
	private int[] exitLanes;
	/** is a oneway road */
	private boolean oneWay = false;

	public BaseRoadSegmentBean() {
	}

	/**
	 *
	 * @param points
	 *            the geometry of the road
	 * @param sourceNodeId
	 *            node id of start
	 * @param sinkNodeId
	 *            node id of end
	 * @param laneCount
	 *            number of lanes in this direction (according to geometry)
	 * @param routingId
	 *            id for routing
	 * @param id
	 *            internal id of the segment
	 * @param name
	 *            road name
	 * @param osmReverse
	 *            defines if the original OSM direction is the same as this direction, or if this segment was reversed
	 *
	 */
	public BaseRoadSegmentBean(List<CoordinateBean> points, long sourceNodeId, long sinkNodeId, int laneCount, long routingId, long id,
			String name, boolean osmReverse) {
		this.points = points;
		this.sourceNodeId = sourceNodeId;
		this.sinkNodeId = sinkNodeId;
		this.laneCount = laneCount;
		this.routingId = routingId;
		this.id = id;
		this.name = name;
		this.reverse = osmReverse;
	}

	public int[] getEntryLanes() {
		return entryLanes;
	}

	public void setEntryLanes(int[] entryLanes) {
		this.entryLanes = entryLanes;
	}

	public int[] getExitLanes() {
		return exitLanes;
	}

	public void setExitLanes(int[] exitLanes) {
		this.exitLanes = exitLanes;
	}

	public List<CoordinateBean> getPoints() {
		return points;
	}

	public void setPoints(List<CoordinateBean> points) {
		this.points = points;
	}

	public long getSourceNodeId() {
		return sourceNodeId;
	}

	public void setSourceNodeId(long sourceNodeId) {
		this.sourceNodeId = sourceNodeId;
	}

	public long getSinkNodeId() {
		return sinkNodeId;
	}

	public void setSinkNodeId(long sinkNodeId) {
		this.sinkNodeId = sinkNodeId;
	}

	public int getLaneCount() {
		return laneCount;
	}

	public void setLaneCount(int laneCount) {
		this.laneCount = laneCount;
	}

	public long getRoutingId() {
		return routingId;
	}

	public void setRoutingId(long routingId) {
		this.routingId = routingId;
	}

	public double getSpeedLimit() {
		return speedLimit;
	}

	public void setSpeedLimit(double speedLimit) {
		this.speedLimit = speedLimit;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isReverse() {
		return reverse;
	}

	public void setReverse(boolean reverse) {
		this.reverse = reverse;
	}

	public void setOneWay(boolean oneWay) {
		this.oneWay = oneWay;
	}

	public boolean isOneWay() {
		return oneWay;
	}

	public String getRestrictions() {
		return restrictions;
	}

	public void setRestrictions(String restrictions) {
		this.restrictions = restrictions;
	}

	public String getMeta() {
		return meta;
	}

	public void setMeta(String meta) {
		this.meta = meta;
	}

}
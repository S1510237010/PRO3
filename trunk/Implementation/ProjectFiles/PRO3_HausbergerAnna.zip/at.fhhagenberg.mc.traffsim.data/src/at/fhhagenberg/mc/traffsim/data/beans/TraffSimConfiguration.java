package at.fhhagenberg.mc.traffsim.data.beans;

import java.io.File;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("Configuration")
public class TraffSimConfiguration {
	private Date startTime;

	private String osmNetworkFile;
	private String graphFile;

	private String outputFolder = "";

	@XStreamOmitField
	private File configurationFile;
	private Map<String, BeanConfigurationContainer> beanConfigurationContainers = new HashMap<>();

	public Collection<BeanConfigurationContainer> getBeanConfigurations() {
		return beanConfigurationContainers.values();
	}

	public Map<String, BeanConfigurationContainer> getBeanConfigurationsMapping() {
		return beanConfigurationContainers;
	}

	public boolean hasMappingFor(String clazz) {
		return beanConfigurationContainers.containsKey(clazz);
	}

	/**
	 * Update the filename of an existing bean configuration, or add it if not already present. The existing metadata is not altered by this
	 * method.
	 * 
	 * @param clazz
	 *            the clazz key to add or change
	 * @param fileName
	 *            the updated filename
	 */
	public void addOrUpdateBeanConfiguration(String clazz, String fileName) {
		if (!beanConfigurationContainers.containsKey(clazz)) {
			beanConfigurationContainers.put(clazz, new BeanConfigurationContainer(clazz, fileName));
		} else {
			beanConfigurationContainers.get(clazz).setFileName(fileName);
		}
	}

	public void setBeanConfigurations(Map<String, BeanConfigurationContainer> containers) {
		this.beanConfigurationContainers = containers;
	}

	/**
	 * Registers a new filename for the class provided. Arbitrary, {@link XStream}-serializable classes can be written into this
	 * configuration.
	 * 
	 * @param clazz
	 *            {@link Class} type which should be written into the file
	 * @param filename
	 *            the filename as string, including suffix (e.g. awesome_content.xml)
	 */
	public void registerFilenameForClass(Class<?> clazz, String filename) {
		this.beanConfigurationContainers.put(clazz.getCanonicalName(), new BeanConfigurationContainer(clazz.getCanonicalName(), filename));
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return The file where this configuration is stored in
	 */
	public File getConfigurationFile() {
		return configurationFile;
	}

	public void setConfigurationFile(File configurationFile) {
		this.configurationFile = configurationFile;
	}

	public String getOsmNetworkFile() {
		return osmNetworkFile;
	}

	public void setOsmNetworkFile(String osmNetworkFile) {
		this.osmNetworkFile = osmNetworkFile;
	}

	public String getGraphFile() {
		return graphFile;
	}

	public void setGraphFile(String graphFile) {
		this.graphFile = graphFile;
	}

	public File obtainGraphFile() {
		return graphFile != null ? new File(configurationFile.getParentFile(), graphFile) : null;
	}

	public String getOutputFolder() {
		return outputFolder;
	}

	public void setOutputFolder(String outputFolder) {
		this.outputFolder = outputFolder;
	}

	/**
	 * 
	 * @param includeConfiguration
	 *            whether the name of the configuration itself should be included in the list
	 * @return a list of filenames (xml values) referenced by this configuration
	 */
	public List<String> getAllFileNames(boolean includeConfiguration) {
		List<String> filenames = beanConfigurationContainers.values().stream().map(conf -> conf.getFileName()).collect(Collectors.toList());
		for (BeanConfigurationContainer cont : beanConfigurationContainers.values()) {
			for (Pair<String, String> att : cont.getAdditionalAttributes()) {
				filenames.add(att.getRight());
			}
		}
		if (includeConfiguration) {
			filenames.add(configurationFile.getName());
		}
		return filenames;
	}

	/**
	 * Get a filename for a defined classname if existing
	 * 
	 * @param className
	 *            the classname to look for
	 * @return the filename as defined in configuration, or <code>null</code> if undefined
	 */
	public String getFilenameFor(String className) {
		if (getBeanConfigurationsMapping().containsKey(className)) {
			BeanConfigurationContainer beanConf = getBeanConfigurationsMapping().get(className);
			return beanConf != null ? beanConf.getFileName() : null;
		} else {
			return null;
		}
	}

}

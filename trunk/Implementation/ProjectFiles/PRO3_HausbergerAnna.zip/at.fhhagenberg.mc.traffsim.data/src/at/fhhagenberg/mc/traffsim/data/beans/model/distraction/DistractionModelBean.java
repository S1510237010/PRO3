package at.fhhagenberg.mc.traffsim.data.beans.model.distraction;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("Distraction")
public class DistractionModelBean extends ModelBean {
	private static final long serialVersionUID = 1L;

	private double updateInterval;
	private boolean isExposureStochastic;
	private boolean isArrivalStochastic;

	@XStreamAlias("distractionTypes")
	private List<DistractionTypeBean> distractionTypes = new ArrayList<>();

	public double getUpdateInterval() {
		return updateInterval;
	}

	public void setUpdateInterval(double updateInterval) {
		this.updateInterval = updateInterval;
	}

	public boolean getIsExposureStochastic() {
		return isExposureStochastic;
	}

	public void setIsExposureStochastic(boolean isExposureStochastic) {
		this.isExposureStochastic = isExposureStochastic;
	}

	public boolean getIsArrivalStochastic() {
		return isArrivalStochastic;
	}

	public void setIsArrivalStochastic(boolean isArrivalStochastic) {
		this.isArrivalStochastic = isArrivalStochastic;
	}

	public List<DistractionTypeBean> getDistractionTypes() {
		return distractionTypes;
	}

	public void setDistractionTypes(List<DistractionTypeBean> distractionTypes) {
		this.distractionTypes = distractionTypes;
	}
}

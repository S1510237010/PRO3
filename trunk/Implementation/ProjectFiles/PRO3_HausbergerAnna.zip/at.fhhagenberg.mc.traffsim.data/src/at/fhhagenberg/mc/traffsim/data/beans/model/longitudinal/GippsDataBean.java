package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("GIPPS")
public class GippsDataBean extends LongitudinalModelInputDataBean {
	private static final long serialVersionUID = 1L;
	private double safeDec;

	public double getSafeDec() {
		return safeDec;
	}

	public void setSafeDec(double safeDec) {
		this.safeDec = safeDec;
	}
}
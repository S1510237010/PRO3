package at.fhhagenberg.mc.traffsim.data.beans.model.communication;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("GeomChannel")
public class GeometricDistributionChannelDataBean extends ModelBean {
	private static final long serialVersionUID = 1L;
	/** lambda parameter characterization of distibution */
	private float lambda;
	/** the time to be added to delay if transmission failed */
	private long roundtripMillisMean;
	/** gaussian standard deviation for round trip */
	private double roundtripStdDev;

	/** roundtrip millis that are added to each calculated value */
	private long roundtripMillisOffset;

	/** the time to be added to delay if transmission failed */
	private Long randomSeed;

	public GeometricDistributionChannelDataBean() {
	}

	public Long getRandomSeed() {
		return randomSeed;
	}

	public void setRandomSeed(Long randomSeed) {
		this.randomSeed = randomSeed;
	}

	public float getLambda() {
		return lambda;
	}

	public void setLambda(float lambda) {
		this.lambda = lambda;
	}

	public long getRoundtripMillisMean() {
		return roundtripMillisMean;
	}

	public void setRoundtripMillisMean(long roundtripMillisMean) {
		this.roundtripMillisMean = roundtripMillisMean;
	}

	public double getRoundtripStdDev() {
		return roundtripStdDev;
	}

	public void setRoundtripStdDev(double roundtripStdDev) {
		this.roundtripStdDev = roundtripStdDev;
	}

	public long getRoundtripMillisOffset() {
		return roundtripMillisOffset;
	}

	public void setRoundtripMillisOffset(long roundtripMillisOffset) {
		this.roundtripMillisOffset = roundtripMillisOffset;
	}

}

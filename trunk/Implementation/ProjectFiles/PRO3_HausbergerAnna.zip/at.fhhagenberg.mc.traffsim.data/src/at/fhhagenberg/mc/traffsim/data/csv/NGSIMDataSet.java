package at.fhhagenberg.mc.traffsim.data.csv;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("NGSIM")
public class NGSIMDataSet extends CFDataSet {

	private double distance;
	private double speedDifference;

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public double getDistance() {
		return this.distance;
	}

	public void setSpeedDifference(double speedDifference) {
		this.speedDifference = speedDifference;
	}

	public double getSpeedDifference() {
		return this.speedDifference;
	}
}

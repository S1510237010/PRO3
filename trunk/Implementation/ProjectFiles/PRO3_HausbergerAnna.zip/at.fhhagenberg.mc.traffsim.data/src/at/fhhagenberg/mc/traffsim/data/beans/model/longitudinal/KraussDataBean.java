package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("KRAUSS")
public class KraussDataBean extends GippsDataBean {
	private static final long serialVersionUID = 1L;

	private double epsilon = 0.0;

	public double getEpsilon() {
		return epsilon;
	}

	public void setEpsilon(double epsilon) {
		this.epsilon = epsilon;
	}
}
package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;

@XStreamAlias("Detector")
public class DetectorBean extends AbstractBean {
	private static final long serialVersionUID = 1L;

	/** Identifier of the associated road segment **/
	private long roadSegmentId;

	/** Measuring interval in seconds (i.e. when to aggregate data) **/
	private int sampleInterval;

	/** Position on the road segment in meters measured from the segment's start **/
	private double position;

	public long getRoadSegmentId() {
		return roadSegmentId;
	}

	public void setRoadSegmentId(long roadSegmentId) {
		this.roadSegmentId = roadSegmentId;
	}

	public int getSampleInterval() {
		return sampleInterval;
	}

	public void setSampleInterval(int sampleIntervall) {
		this.sampleInterval = sampleIntervall;
	}

	public double getPosition() {
		return position;
	}

	public void setPosition(double position) {
		this.position = position;
	}
}

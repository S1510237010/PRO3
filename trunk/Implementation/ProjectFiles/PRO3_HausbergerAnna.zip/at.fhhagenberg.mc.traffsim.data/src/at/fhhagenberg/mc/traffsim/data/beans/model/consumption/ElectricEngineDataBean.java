package at.fhhagenberg.mc.traffsim.data.beans.model.consumption;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

public class ElectricEngineDataBean extends ModelBean {

	private static final long serialVersionUID = 1L;

	private double mGeareff;
	private double mRadius;
	private double mKc;
	private double mKi;
	private double mKw;
	private double mConstloss;

	public void setGearEff(double _gearEff) {
		mGeareff = _gearEff;
	}

	public double getGearEff() {
		return mGeareff;
	}

	public void setRadius(double _radius) {
		mRadius = _radius;
	}

	public double getRadius() {
		return mRadius;
	}

	public void setKC(double _kc) {
		mKc = _kc;
	}

	public double getKC() {
		return mKc;
	}

	public void setKI(double _ki) {
		mKi = _ki;
	}

	public double getKI() {
		return mKi;
	}

	public void setKW(double _kw) {
		mKw = _kw;
	}

	public double getKW() {
		return mKw;
	}

	public void setConstLoss(double _constLoss) {
		mConstloss = _constLoss;
	}

	public double getConstLoss() {
		return mConstloss;
	}

}

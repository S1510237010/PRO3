package at.fhhagenberg.mc.traffsim.data.beans.model.communication;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("GEChannel")
public class GilbertElliotChannelDataBean extends ModelBean {
	private static final long serialVersionUID = 1L;
	/** probability of staying in good state if already in good state (between 0 and 1) */
	private float pGoodGood;
	/** probability of staying in bad state (between 0 and 1) */
	private float pBadBad;
	/** the time to be added to delay if transmission failed */
	private long roundtripMillisMean;
	/** gaussian standard deviation for round trip */
	private double roundtripStdDev;
	/** OPTIONAL: random seed for initialization (null if unused) */
	private Long randomSeed;

	public GilbertElliotChannelDataBean() {
	}

	public float getpGoodGood() {
		return pGoodGood;
	}

	public void setpGoodGood(float pGoodGood) {
		this.pGoodGood = pGoodGood;
	}

	public float getpBadBad() {
		return pBadBad;
	}

	public void setpBadBad(float pBadBad) {
		this.pBadBad = pBadBad;
	}

	public long getRoundtripMillisMean() {
		return roundtripMillisMean;
	}

	public void setRoundtripMillisMean(long roundtripMillisMean) {
		this.roundtripMillisMean = roundtripMillisMean;
	}

	public double getRoundtripStdDev() {
		return roundtripStdDev;
	}

	public void setRoundtripStdDev(double roundtripStdDevMillis) {
		this.roundtripStdDev = roundtripStdDevMillis;
	}

	public Long getRandomSeed() {
		return randomSeed;
	}

	public void setRandomSeed(Long randomSeed) {
		this.randomSeed = randomSeed;
	}

}

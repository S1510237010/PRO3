package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public abstract class TrafficLightControllerBean extends IntersectionControlBean {

	private static final long serialVersionUID = 6472491401338370223L;

	@XStreamAsAttribute
	private long junctionId;

	private List<ControlLogicBean> controlLogic;

	private boolean areLanesOperatedIndividually;

	public long getJunctionId() {
		return junctionId;
	}

	public void setJunctionId(long junctionId) {
		this.junctionId = junctionId;
	}

	public List<ControlLogicBean> getControlLogic() {
		return controlLogic;
	}

	public void setControlLogic(List<ControlLogicBean> controlLogic) {
		this.controlLogic = controlLogic;
	}

	public boolean getAreLanesOperatedIndividually() {
		return areLanesOperatedIndividually;
	}

	public void setAreLanesOperatedIndividually(boolean areLanesOperatedIndividually) {
		this.areLanesOperatedIndividually = areLanesOperatedIndividually;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ACC")
public class ACCDataBean extends IDMDataBean {

	private static final long serialVersionUID = 1L;
	/**
	 * From Kesting et al. Enhanced intelligent driver model ...<br>
	 * Compared with the IDM parameters, the ACC model contains only one additional model parameter c, which can be interpreted as a
	 * coolness factor. For c =0, the model reverts to the IDM, while for c =1 the sensitivity with respect to changes in the gap vanishes
	 * in situations with small gaps and no velocity difference. This means that the behaviour would be too relaxed. In this paper, we have
	 * assumed c =0.99 (see table 1)
	 */
	private double coolness;

	public double getCoolness() {
		return coolness;
	}

	public void setCoolness(double coolness) {
		this.coolness = coolness;
	}
}
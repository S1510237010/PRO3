package at.fhhagenberg.mc.traffsim.data.beans.model.consumption;

public class PlatoonBean {

	float avgOnePlatoon;
	float avgTwoPlatoon;
	float avgThreePlatoon;
	float avgFourPlatoon;
	float avgMorePlatoon;

}

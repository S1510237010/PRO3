package at.fhhagenberg.mc.traffsim.data.xml;

import java.util.ArrayList;
import java.util.Collection;

import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.converters.collections.CollectionConverter;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.mapper.Mapper;

/**
 * A converter utility which
 * 
 * @author Christian Backfrieder
 * 
 */
public class NumberListConverter extends CollectionConverter {

	public NumberListConverter(Mapper mapper) {
		super(mapper);
	}

	@Override
	public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
		try {
			@SuppressWarnings("unchecked")
			Collection<? extends Number> numberList = (Collection<? extends Number>) source;
			StringBuilder sb = new StringBuilder();
			boolean firstTime = true;
			for (Number tmp : numberList) {
				if (!firstTime)
					sb.append(",");
				sb.append(tmp);
				firstTime = false;
			}
			writer.setValue(sb.toString());
		} catch (ClassCastException ce) {
			super.marshal(source, writer, context);
		}
	}

	@Override
	public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
		String data = reader.getValue();
		String[] parsed = data.split(",");
		if (parsed.length > 0) {
			Collection<Number> result = new ArrayList<Number>(parsed.length);
			for (String tmp : parsed) {
				try {
					if (tmp.contains(".")) {
						result.add(Double.valueOf(tmp));
					} else {
						result.add(Long.valueOf(tmp));
					}
				} catch (NumberFormatException e) {
					return super.unmarshal(reader, context);
				}
			}
			return result;
		}
		return super.unmarshal(reader, context);
	}
}

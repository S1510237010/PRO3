package at.fhhagenberg.mc.traffsim.data.beans.model.consumption;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("Consumption")
public class ConsumptionCarDataBean extends ModelBean {
	private static final long serialVersionUID = 1L;
	private double vehicleMass; // in kg
	private double crossSectionSurface; // in m^2
	private double cdValue; // unitless
	private double electricPower; // in Watt
	private double consFrictionCoefficient; // unitless
	private double vFrictionCoefficient;
	private double dynamicTyreRadius; // in m

	public double getVehicleMass() {
		return vehicleMass;
	}

	public void setVehicleMass(double vehicleMass) {
		this.vehicleMass = vehicleMass;
	}

	public double getCrossSectionSurface() {
		return crossSectionSurface;
	}

	public void setCrossSectionSurface(double crossSectionSurface) {
		this.crossSectionSurface = crossSectionSurface;
	}

	public double getCdValue() {
		return cdValue;
	}

	public void setCdValue(double cdValue) {
		this.cdValue = cdValue;
	}

	public double getElectricPower() {
		return electricPower;
	}

	public void setElectricPower(double electricPower) {
		this.electricPower = electricPower;
	}

	public double getConsFrictionCoefficient() {
		return consFrictionCoefficient;
	}

	public void setConsFrictionCoefficient(double consFrictionCoefficient) {
		this.consFrictionCoefficient = consFrictionCoefficient;
	}

	public double getvFrictionCoefficient() {
		return vFrictionCoefficient;
	}

	public void setvFrictionCoefficient(double vFrictionCoefficient) {
		this.vFrictionCoefficient = vFrictionCoefficient;
	}

	public double getDynamicTyreRadius() {
		return dynamicTyreRadius;
	}

	public void setDynamicTyreRadius(double dynamicTyreRadius) {
		this.dynamicTyreRadius = dynamicTyreRadius;
	}
}

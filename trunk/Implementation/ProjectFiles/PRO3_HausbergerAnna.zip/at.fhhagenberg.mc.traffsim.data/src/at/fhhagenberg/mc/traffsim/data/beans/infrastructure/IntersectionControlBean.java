package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;

/**
 * All files which are related to intersection control can derive from this class to be located in the same file.
 * 
 * @author Manuel Lindorfer
 * 
 */
public abstract class IntersectionControlBean extends AbstractBean {

	private static final long serialVersionUID = 1L;

}

package at.fhhagenberg.mc.traffsim.data.xml;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.BeanConfigurationContainer;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RoadSegmentBean;

public class BaseSerializer {
	public static final String LOGGER_NAME = "Logger for DataSerializer";
	String configurationDirectory;
	Set<ClassLoader> additionalClassLoaders = new HashSet<>();

	protected XStream xstream;
	protected TraffSimConfiguration configuration;

	public BaseSerializer() {
		super();
		xstream = new XStream(new DomDriver("UTF-8"));
		xstream.autodetectAnnotations(true);
		xstream.ignoreUnknownElements();
		xstream.processAnnotations(DefaultProcessedClasses.XML_BEANS);
		xstream.registerConverter(new TraffSimConfigurationConverter());
		xstream.registerConverter(new NumberListConverter(xstream.getMapper()));
		xstream.registerConverter(new LinkedPropertiesConverter());
		xstream.setClassLoader(this.getClass().getClassLoader());

	}

	/**
	 * Read a configuration file from the given path and parse all classes located there. This method must be called before using
	 * {@link DataSerializer#readData(Class,boolean)} and {@link #writeData(List)}!
	 *
	 * This method can also be used to replace the configuration directory and load data from another location.
	 *
	 * @param configurationFile
	 *            This should be an absolute file path pointing to the XML file containing the serialized {@link TraffSimConfiguration}.
	 * @return true if loading data was successful, false otherwise
	 * @see TraffSimConfiguration
	 */
	public boolean readConfiguration(File configurationFile) {
		this.configurationDirectory = configurationFile.getAbsoluteFile().getParentFile().getAbsolutePath();
		Object parsed = xstream.fromXML(configurationFile);
		if (parsed instanceof TraffSimConfiguration) {
			configuration = (TraffSimConfiguration) parsed;
			configuration.setConfigurationFile(configurationFile);
			return true;
		}
		return false;
	}

	/**
	 * The currently set configuration is persisted at the location given. After setting a new configuration with
	 * {@link DataSerializer#setConfiguration(TraffSimConfiguration)} it can be persisted this way.
	 *
	 * @param configurationFile
	 *
	 *            The path to the target file which should contain the configuration (including filename, e.g. C:\\configuration.xml)
	 * @return true if writing was successful, false otherwise
	 */
	public boolean writeConfiguration(File configurationFile) {
		try {
			configurationDirectory = configurationFile.getParentFile().getAbsolutePath();
			xstream.toXML(configuration, new FileWriter(configurationFile));
			return true;
		} catch (IOException e) {
			Logger.getLogger(LOGGER_NAME).log(Level.SEVERE, "Could not write to file", e);
		}
		return false;
	}

	/**
	 * Write the data to the data directory, using the appropriate file specified in the loaded {@link TraffSimConfiguration} <br>
	 * <b>Note:</b> For writing {@link RoadSegmentBean}s, {@link NodeBean}s or other infrastructure, use a list of type
	 * {@link InfrastructureBean} instead of the type itself, as specified in the {@link TraffSimConfiguration}. By doing so, the
	 * infrastructure can be stored in one single XML file instead of a separate file for each type.
	 *
	 * @param beans
	 *            The data to write, which must not be null or empty, because in these cases the type cannot be determined. Use
	 *            {@link DataSerializer#clearData(Class)} to erase the data instead!
	 *
	 *
	 */
	public void writeData(List<? extends AbstractBean> beans) {
		if (beans == null) {
			throw new IllegalArgumentException("Data must not be null");
		}
		if (beans.isEmpty()) {
			return;
		}
		File file = findFileFor(beans);
		writeData(file, beans);
	}

	protected void writeData(File file, List<? extends AbstractBean> beans) {
		if (file != null) {
			try {
				xstream.toXML(beans, new OutputStreamWriter(new FileOutputStream(file), Charset.forName("UTF-8")));
			} catch (IOException e) {
				Logger.getLogger(LOGGER_NAME).log(Level.SEVERE, "Could not write to file", e);
			}
		}
	}

	File findFileFor(List<? extends AbstractBean> beans) {
		if (beans.isEmpty()) {
			return null;
		}
		// check type
		Class<?> deepestDepthClass = null;
		AbstractBean bean = beans.get(0);
		for (BeanConfigurationContainer bcc : configuration.getBeanConfigurations()) {
			try {
				Class<?> clazz = null;
				try {
					// try to find the class on current classpath
					clazz = Class.forName(bcc.getClassName());
				} catch (ClassNotFoundException ex) {
					// class not found on current classpath? try registered additional classloaders from external plugins
					for (ClassLoader cl : additionalClassLoaders) {
						try {
							clazz = Class.forName(bcc.getClassName(), false, cl);
						} catch (ClassNotFoundException e2) {
							continue;
						}
					}
				}
				if (clazz == null) {
					Logger.getLogger(LOGGER_NAME).log(Level.SEVERE, "Given class '" + bcc.getClassName() + "' not found on classpath.");
					continue;
				}
				// class found on current or any external classpath
				clazz.cast(bean);
				// no exception when trying to cast -> type found.
				if (deepestDepthClass != null) {
					if (deepestDepthClass.isAssignableFrom(clazz)) {
						deepestDepthClass = clazz;
					}
				} else {
					deepestDepthClass = clazz;
				}
			} catch (ClassCastException e) {
				// class not found. Continue
				continue;
			}
		}

		if (deepestDepthClass != null) {
			return getFileFor(deepestDepthClass.getName());
		}
		return null;
	}

	protected File getFileFor(String className) {
		if (configuration.getBeanConfigurationsMapping().containsKey(className)) {
			return new File(configurationDirectory + "/" + configuration.getBeanConfigurationsMapping().get(className).getFileName());
		} else {
			return null;
		}
	}

}
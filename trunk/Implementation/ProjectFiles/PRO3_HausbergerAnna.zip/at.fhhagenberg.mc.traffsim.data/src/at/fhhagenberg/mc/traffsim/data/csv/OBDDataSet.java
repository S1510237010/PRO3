package at.fhhagenberg.mc.traffsim.data.csv;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("OBD2")
public class OBDDataSet extends CFDataSet {

	private boolean isFollowerDistracted;

	public boolean isFollowerDistracted() {
		return this.isFollowerDistracted;
	}

	public void setIsFollowerDistracted(boolean isFollowerDistracted) {
		this.isFollowerDistracted = isFollowerDistracted;
	}
}

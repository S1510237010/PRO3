package at.fhhagenberg.mc.traffsim.data.beans.model.consumption;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("Engine")
public class EngineDataBean extends ModelBean {

	private static final long serialVersionUID = 1L;
	private String fuelType;

	/** in kW */
	private double maxPower;
	/** in liter */
	private double cylinderVolume;
	/** in liter per second */
	private double idleConsumptionRateLiterPerSecond;
	/** in kg/Ws */
	private double minSpecificConsumption;
	/** in Pascal */
	private double effectivePressureMinimum;
	/** in Pascal */
	private double effectivePressureMaximum;
	/** per second */
	private double idleRotationRate;
	/** per second */
	private double maxRotationRate;

	private List<Double> gearRatios;

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public double getMaxPower() {
		return maxPower;
	}

	public void setMaxPower(double maxPower) {
		this.maxPower = maxPower;
	}

	public double getCylinderVolume() {
		return cylinderVolume;
	}

	public void setCylinderVolume(double cylinderVolume) {
		this.cylinderVolume = cylinderVolume;
	}

	public double getIdleConsumptionRateLiterPerSecond() {
		return idleConsumptionRateLiterPerSecond;
	}

	public void setIdleConsumptionRateLiterPerSecond(double idleConsumptionRateLiterPerSecond) {
		this.idleConsumptionRateLiterPerSecond = idleConsumptionRateLiterPerSecond;
	}

	public double getMinSpecificConsumption() {
		return minSpecificConsumption;
	}

	public void setMinSpecificConsumption(double minSpecificConsumption) {
		this.minSpecificConsumption = minSpecificConsumption;
	}

	public double getEffectivePressureMinimum() {
		return effectivePressureMinimum;
	}

	public void setEffectivePressureMinimum(double effectivePressureMinimum) {
		this.effectivePressureMinimum = effectivePressureMinimum;
	}

	public double getEffectivePressureMaximum() {
		return effectivePressureMaximum;
	}

	public void setEffectivePressureMaximum(double effectivePressureMaximum) {
		this.effectivePressureMaximum = effectivePressureMaximum;
	}

	public double getIdleRotationRate() {
		return idleRotationRate;
	}

	public void setIdleRotationRate(double idleRotationRate) {
		this.idleRotationRate = idleRotationRate;
	}

	public double getMaxRotationRate() {
		return maxRotationRate;
	}

	public void setMaxRotationRate(double maxRotationRate) {
		this.maxRotationRate = maxRotationRate;
	}

	public List<Double> getGearRatios() {
		return gearRatios;
	}

	public void setGearRatios(List<Double> gearRatios) {
		Collections.sort(gearRatios, new Comparator<Double>() {
			@Override
			public int compare(Double o1, Double o2) {
				final Double pos1 = new Double((o1).doubleValue());
				final Double pos2 = new Double((o2).doubleValue());
				return pos2.compareTo(pos1); // sort with DECREASING transmission ratios (gear 1 has highest ratio)
			}
		});

		// put double values in dedicated collection
		List<Double> ratios = new ArrayList<Double>();

		for (final Double phiGear : gearRatios) {
			ratios.add(phiGear);
		}

		this.gearRatios = ratios;
	}
}

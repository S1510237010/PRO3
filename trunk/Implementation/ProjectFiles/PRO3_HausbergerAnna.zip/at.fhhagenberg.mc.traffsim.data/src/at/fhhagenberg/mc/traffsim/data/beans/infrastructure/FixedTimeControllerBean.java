package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("FixedTimeController")
public class FixedTimeControllerBean extends TrafficLightControllerBean{

	private static final long serialVersionUID = 1L;
}

package at.fhhagenberg.mc.traffsim.data.beans;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Route")
public class RouteBean extends AbstractBean {
	private static final long serialVersionUID = 1L;
	private List<Long> roadSegmentIds = new ArrayList<>();

	public RouteBean() {
	}

	public RouteBean(long id, long[] segmentIds) {
		this.id = id;
		for (long sid : segmentIds) {
			roadSegmentIds.add(sid);
		}
	}

	public List<Long> getRoadSegmentIds() {
		return roadSegmentIds;
	}

	public void setRoadSegmentIds(List<Long> roadSegmentIds) {
		this.roadSegmentIds = roadSegmentIds;
	}

}

package at.fhhagenberg.mc.traffsim.data.beans.model.platoon;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("PlatoonData")
public class PlatoonDataBean {

	/**
	 * Desired speed for a platoon
	 */
	private double desiredSpeed;

	/**
	 * desired gap between vehicles inside the platoon
	 */
	private double desiredGap;

	/**
	 * desired gap between vehicles inside the platoon for the side join maneuver
	 */
	private double maneuverGap;

	/**
	 * minimum lane count for a platoons to be coordinated
	 */
	private int minimumLaneCount;

	/**
	 * Maximum count of vehicles inside a platoon
	 */
	private int maxVehiclesPerPlatoon;

	/**
	 * Maximum distance between a vehicle and the platoon it want to join
	 */
	private double maxDistanceForJoin;

	/**
	 * Maximum target speed difference between a joining vehicle and the platoon it want to join
	 */
	private double maxTargetSpeedDifferenceForJoin;

	/**
	 * Timeout for a maneuver (e.g. if join maneuver takes to long)
	 */
	private long maneuverTimeout;

	/**
	 * If platoon's speed is zero for this timeout platoon is resolved
	 */
	private long dissolveTimeout;

	/**
	 * Offset for speed difference to leader for some maneuvers (e.g. front join speed -> leaderSpeed * (1 -factor)).
	 */
	private double maneuverSpeedTOffset;

	/**
	 * Threshold offset in m for minimum human gap to platoon (front, tail or preceding) (e.g. front join distance -> distanceToLeader <
	 * minimumHumanGap + offset)
	 */
	private double maneuverHumanDistanceThresholdOffset;

	/**
	 * Threshold offset in m for desired gap of platoon to finish maneuver (maneuver is finished if distance to surrounding platoon vehicles
	 * is less than desiredGap + offset)
	 */
	private double maneuverPlatoonDistanceThresholdOffset;

	/**
	 * Get desired speed for platoon
	 *
	 * @return speed
	 */
	public double getDesiredSpeed() {
		return desiredSpeed;
	}

	/**
	 * Set desired speed for platoon
	 *
	 * @param desiredSpeed
	 *            speed for platoon
	 */
	public void setDesiredSpeed(double desiredSpeed) {
		this.desiredSpeed = desiredSpeed;
	}

	/**
	 * Desired Gap
	 *
	 * @return desired gap
	 */
	public double getDesiredGap() {
		return desiredGap;
	}

	/**
	 * Desired Gap
	 *
	 * @param desiredGap
	 *            gap to be set
	 */
	public void setDesiredGap(double desiredGap) {
		this.desiredGap = desiredGap;
	}

	/**
	 * Get desired gap for side join/leave maneuvers
	 *
	 * @return maneuver gap
	 */
	public double getManeuverGap() {
		return maneuverGap;
	}

	/**
	 * Get desired gap for side join/leave maneuvers
	 *
	 * @param maneuverGap
	 *            maneuver gap
	 */
	public void setManeuverGap(double maneuverGap) {
		this.maneuverGap = maneuverGap;
	}

	/**
	 * Minimum lane count for platoons to be coordinated
	 *
	 * @return minimum lane count
	 */
	public int getMinimumLaneCount() {
		return minimumLaneCount;
	}

	/**
	 * Minimum lane count for platoons to be coordinated
	 *
	 * @param minimumLaneCount
	 *            minimum lane count
	 */
	public void setMinimumLaneCount(int minimumLaneCount) {
		this.minimumLaneCount = minimumLaneCount;
	}

	/**
	 * Maximum vehicles per platoon
	 *
	 * @return maximum vehicle count
	 */
	public int getMaxVehiclesPerPlatoon() {
		return maxVehiclesPerPlatoon;
	}

	/**
	 * Maximum vehicles per platoon
	 *
	 * @param maxVehiclesPerPlatoon
	 *            maximum vehicle count
	 */
	public void setMaxVehiclesPerPlatoon(int maxVehiclesPerPlatoon) {
		this.maxVehiclesPerPlatoon = maxVehiclesPerPlatoon;
	}

	/**
	 * Maximum distance to paltoon for joining
	 *
	 * @return maximum distance
	 */
	public double getMaxDistanceForJoin() {
		return maxDistanceForJoin;
	}

	/**
	 * Maximum distance to platoon for joining
	 *
	 * @param maxDistanceForJoin
	 *            maximum distance
	 */
	public void setMaxDistanceForJoin(double maxDistanceForJoin) {
		this.maxDistanceForJoin = maxDistanceForJoin;
	}

	/**
	 * Get maximum target speed difference
	 *
	 * @return speed difference
	 */
	public double getMaxTargetSpeedDifferenceForJoin() {
		return maxTargetSpeedDifferenceForJoin;
	}

	/**
	 * Set maximum target speed difference
	 *
	 * @param maxTargetSpeedDifferenceForJoin
	 *            speed difference
	 */
	public void setMaxTargetSpeedDifferenceForJoin(double maxTargetSpeedDifferenceForJoin) {
		this.maxTargetSpeedDifferenceForJoin = maxTargetSpeedDifferenceForJoin;
	}

	/**
	 * Get maneuver timeout for a platoon maneuver
	 *
	 * @return timeout
	 */
	public long getManeuverTimeout() {
		return maneuverTimeout;
	}

	/**
	 * Set maneuver timeout for a platoon maneuver
	 *
	 * @param maneuverTimeout
	 *            timeout
	 */
	public void setManeuverTimeout(long maneuverTimeout) {
		this.maneuverTimeout = maneuverTimeout;
	}

	/**
	 * Get timeout for dissolving platoon on zero speed
	 *
	 * @return timeout
	 */
	public long getDissolveTimeout() {
		return dissolveTimeout;
	}

	/**
	 * Set timeout for dissolving platoon on zero speed
	 *
	 * @param dissolveTimeout
	 *            timeout
	 */
	public void setDissolveTimeout(long dissolveTimeout) {
		this.dissolveTimeout = dissolveTimeout;
	}

	/**
	 * Get maneuver speed offset
	 *
	 * @return offset
	 */
	public double getManeuverSpeedTOffset() {
		return maneuverSpeedTOffset;
	}

	/**
	 * Set maneuver speed offset
	 *
	 * @param maneuverSpeedTOffset
	 *            offset
	 */
	public void setManeuverSpeedTOffset(double maneuverSpeedTOffset) {
		this.maneuverSpeedTOffset = maneuverSpeedTOffset;
	}

	/**
	 * Get maneuver distance threshold offset
	 *
	 * @return offset
	 */
	public double getManeuverHumanDistanceThresholdOffset() {
		return maneuverHumanDistanceThresholdOffset;
	}

	/**
	 * Set maneuver distance threshold offset
	 *
	 * @param maneuverHumanDistanceThresholdOffset
	 *            offset
	 */
	public void setManeuverHumanDistanceThresholdOffset(double maneuverHumanDistanceThresholdOffset) {
		this.maneuverHumanDistanceThresholdOffset = maneuverHumanDistanceThresholdOffset;
	}

	/**
	 * Get desired gap threshold offset
	 *
	 * @return offset
	 */
	public double getManeuverPlatoonDistanceThresholdOffset() {
		return maneuverPlatoonDistanceThresholdOffset;
	}

	/**
	 * Set desired gap threshold offset
	 *
	 * @param maneuverPlatoonDistanceThresholdOffset
	 *            offset
	 */
	public void setManeuverPlatoonDistanceThresholdOffset(double maneuverPlatoonDistanceThresholdOffset) {
		this.maneuverPlatoonDistanceThresholdOffset = maneuverPlatoonDistanceThresholdOffset;
	}
}

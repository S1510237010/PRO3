package at.fhhagenberg.mc.traffsim.data.beans.model.lanechange;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

public abstract class LaneChangeModelInputDataBean extends ModelBean {
	private static final long serialVersionUID = 1L;
}

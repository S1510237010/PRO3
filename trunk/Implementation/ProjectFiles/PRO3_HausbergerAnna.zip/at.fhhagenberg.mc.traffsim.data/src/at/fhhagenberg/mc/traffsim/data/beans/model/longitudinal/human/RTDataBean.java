package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("RESPONSETIMES")
public class RTDataBean {

	private double driveAway;
	private double expected;
	private double unexpected;

	private boolean isAnticipative;
	private boolean isReactive;

	private double timeHeadway;

	public double getDriveAway() {
		return driveAway;
	}

	public double getExpected() {
		return expected;
	}

	public boolean getIsAnticipative() {
		return isAnticipative;
	}

	public boolean getIsReactive() {
		return isReactive;
	}

	public double getTimeHeadway() {
		return timeHeadway;
	}

	public double getUnexpected() {
		return unexpected;
	}

	public void setDriveAway(double driveAway) {
		this.driveAway = driveAway;
	}

	public void setExpected(double expected) {
		this.expected = expected;
	}

	public void setIsAnticipative(boolean isAnticipative) {
		this.isAnticipative = isAnticipative;
	}

	public void setIsReactive(boolean isReactive) {
		this.isReactive = isReactive;
	}

	public void setTimeHeadway(double timeHeadway) {
		this.timeHeadway = timeHeadway;
	}

	public void setUnexpected(double unexpected) {
		this.unexpected = unexpected;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("RemovedRoutingIds")
public class RemovedRoutingIdsBean extends InfrastructureBean {
	private static final long serialVersionUID = 1L;
	private List<Long> oldRoutingIds;

	public RemovedRoutingIdsBean() {
	}

	public RemovedRoutingIdsBean(List<Long> oldRoutingIds) {
		this.oldRoutingIds = oldRoutingIds;
	}

	public List<Long> getOldRoutingIds() {
		return oldRoutingIds;
	}

	public void setOldRoutingIds(List<Long> oldRoutingIds) {
		this.oldRoutingIds = oldRoutingIds;
	}
}

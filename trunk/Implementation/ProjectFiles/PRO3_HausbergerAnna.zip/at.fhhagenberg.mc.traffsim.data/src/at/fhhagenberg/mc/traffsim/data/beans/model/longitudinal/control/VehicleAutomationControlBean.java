package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation.DrivingRegimeBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation.SpeedRangeBean;

@XStreamAlias("AutomatedVehicle")
public class VehicleAutomationControlBean extends ContainerControlBean {

	private static final long serialVersionUID = 1L;
	private double transitionSecondsAutomated;
	private double transitionSecondsHuman;

	private String automationLevel;

	@XStreamAlias("speedRanges")
	private List<SpeedRangeBean> speedRanges = new ArrayList<>();

	@XStreamAlias("drivingRegimes")
	private List<DrivingRegimeBean> drivingRegimes = new ArrayList<>();

	/**
	 * Determines in which time interval the driving mode (human, automated) is evaluated using the specified probabilities and the current
	 * speed and / or driving regime
	 **/
	private double evaluationRate;

	/** Required for regime determination **/
	private double timeHeadway;
	private double spaceHeadway;

	public VehicleAutomationControlBean() {
		super();
	}

	public double getTransitionSecondsAutomated() {
		return transitionSecondsAutomated;
	}

	public void setTransitionSecondsAutomated(double transitionSecondsAutomated) {
		this.transitionSecondsAutomated = transitionSecondsAutomated;
	}

	public double getTransitionSecondsHuman() {
		return transitionSecondsHuman;
	}

	public void setTransitionSecondsHuman(double transitionSecondsHuman) {
		this.transitionSecondsHuman = transitionSecondsHuman;
	}

	public String getAutomationLevel() {
		return automationLevel;
	}

	public void setAutomationLevel(String automationLevel) {
		this.automationLevel = automationLevel;
	}

	public List<SpeedRangeBean> getSpeedRanges() {
		return speedRanges;
	}

	public void setSpeedRanges(List<SpeedRangeBean> speedRanges) {
		this.speedRanges = speedRanges;
	}

	public List<DrivingRegimeBean> getDrivingRegimes() {
		return drivingRegimes;
	}

	public void setDrivingRegimes(List<DrivingRegimeBean> drivingRegimes) {
		this.drivingRegimes = drivingRegimes;
	}

	public double getEvaluationRate() {
		return evaluationRate;
	}

	public void setEvaluationRate(double evaluationRate) {
		this.evaluationRate = evaluationRate;
	}

	public double getTimeHeadway() {
		return timeHeadway;
	}

	public void setTimeHeadway(double timeHeadway) {
		this.timeHeadway = timeHeadway;
	}

	public double getSpaceHeadway() {
		return spaceHeadway;
	}

	public void setSpaceHeadway(double spaceHeadway) {
		this.spaceHeadway = spaceHeadway;
	}
}

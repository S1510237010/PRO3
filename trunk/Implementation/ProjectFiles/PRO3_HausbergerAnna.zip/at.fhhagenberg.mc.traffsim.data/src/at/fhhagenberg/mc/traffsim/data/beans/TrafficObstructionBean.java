package at.fhhagenberg.mc.traffsim.data.beans;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Describes an accident or any other traffic obstruction which occurs in a specific point in time and is generated manually by the
 * simulator.
 *
 * @author Christian Backfrieder
 *
 */
@XStreamAlias("TrafficObstruction")
public class TrafficObstructionBean extends AbstractBean {
	private static final long serialVersionUID = 1L;

	/** Offset from simulation start */
	private double offset;

	/** duration of the obstruction */
	private double duration;

	/** id of road segment where the obstruction happesn */
	private long roadSegmentId;

	/** id of the lane on given road segment which is affected */
	private int laneId;

	/** position on road segment (measured from road geometry), where the accident happens */
	private double position;

	private boolean isPermanent;

	public TrafficObstructionBean() {
		super();
		offset = 0d;
		duration = 0d;
		roadSegmentId = -1;
		laneId = 0;
		position = 0d;
		isPermanent = true;
	}

	public TrafficObstructionBean(double offset, double duration, boolean isPermanent, long roadSegmentId, int laneId, double position) {
		super();
		this.offset = offset;
		this.duration = duration;
		this.roadSegmentId = roadSegmentId;
		this.laneId = laneId;
		this.position = position;
		this.isPermanent = isPermanent;
	}

	public double getOffset() {
		return offset;
	}

	public void setOffset(double offset) {
		this.offset = offset;
	}

	public boolean getIsPermanent() {
		return isPermanent;
	}

	public void setIsPermanent(boolean isPermanent) {
		this.isPermanent = isPermanent;
	}

	public long getRoadSegmentId() {
		return roadSegmentId;
	}

	public void setRoadSegmentId(long roadSegmentId) {
		this.roadSegmentId = roadSegmentId;
	}

	public int getLaneId() {
		return laneId;
	}

	public void setLaneId(int laneId) {
		this.laneId = laneId;
	}

	public double getPosition() {
		return position;
	}

	public void setPosition(double position) {
		this.position = position;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}
}

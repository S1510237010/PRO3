package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Cyclic")
public class CyclicControlLogicBean extends ControlLogicBean {

	private static final long serialVersionUID = 1L;

	private long delay;
	private long phaseLength;

	public long getDelay() {
		return delay;
	}

	public void setDelay(long delay) {
		this.delay = delay;
	}
	
	public long getPhaseLength() {
		return phaseLength;
	}

	public void setPhaseLength(long phaseLength) {
		this.phaseLength = phaseLength;
	}
}

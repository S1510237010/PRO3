package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("IDM")
public class IDMDataBean extends GippsDataBean {

	private static final long serialVersionUID = 1L;
	private double delta;
	private double maxAcc;
	private double maxDec;
	private double tMin;

	public double getDelta() {
		return delta;
	}

	public double getMaxAcc() {
		return maxAcc;
	}

	public double getMaxDec() {
		return maxDec;
	}

	public double gettMin() {
		return tMin;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}

	public void setMaxAcc(double maxAcc) {
		this.maxAcc = maxAcc;
	}

	public void setMaxDec(double maxDec) {
		this.maxDec = maxDec;
	}

	public void settMin(double tMin) {
		this.tMin = tMin;
	}
}
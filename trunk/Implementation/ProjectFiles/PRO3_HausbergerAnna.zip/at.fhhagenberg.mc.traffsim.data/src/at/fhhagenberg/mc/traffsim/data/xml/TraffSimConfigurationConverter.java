package at.fhhagenberg.mc.traffsim.data.xml;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.tuple.Pair;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

import at.fhhagenberg.mc.traffsim.data.beans.BeanConfigurationContainer;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;

public class TraffSimConfigurationConverter implements Converter {

	private static final String CLASS_ATTRIBUTE = "class";
	private static final String FILE_NODE = "file";
	private static final String DATE_NODE = "startTime";
	private static final String OSM_FILE_NODE = "osmNetworkFile";
	private static final String GRAPH_FILE_NODE = "graphFile";
	private static final String OUTPUTFOLDER_NODE = "outputFolder";

	@Override
	public boolean canConvert(@SuppressWarnings("rawtypes") Class type) {
		return type.equals(TraffSimConfiguration.class);
	}

	@Override
	public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
		TraffSimConfiguration configuration = (TraffSimConfiguration) source;
		if (configuration.getStartTime() != null) {
			writer.startNode(DATE_NODE);
			context.convertAnother(configuration.getStartTime());
			writer.endNode();
		}
		writer.startNode(OSM_FILE_NODE);
		context.convertAnother(configuration.getOsmNetworkFile());
		writer.endNode();
		writer.startNode(GRAPH_FILE_NODE);
		context.convertAnother(configuration.getGraphFile());
		writer.endNode();
		writer.startNode(OUTPUTFOLDER_NODE);
		context.convertAnother(configuration.getOutputFolder());
		writer.endNode();
		for (BeanConfigurationContainer container : configuration.getBeanConfigurations()) {
			writer.startNode(FILE_NODE);
			writer.addAttribute(CLASS_ATTRIBUTE, container.getClassName());
			for (Pair<String, String> p : container.getAdditionalAttributes()) {
				writer.addAttribute(p.getKey(), p.getValue());
			}
			writer.setValue(container.getFileName());
			writer.endNode();
		}
	}

	@Override
	public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
		TraffSimConfiguration configuration = new TraffSimConfiguration();
		Map<String, BeanConfigurationContainer> beanConfigurations = new HashMap<>();
		while (reader.hasMoreChildren()) {
			reader.moveDown();
			if (reader.getNodeName().equals(DATE_NODE)) {
				configuration.setStartTime((Date) context.convertAnother(reader.getValue(), Date.class));
			} else if (reader.getNodeName().equals(GRAPH_FILE_NODE)) {
				configuration.setGraphFile((String) context.convertAnother(reader.getValue(), String.class));
			} else if (reader.getNodeName().equals(OSM_FILE_NODE)) {
				configuration.setOsmNetworkFile((String) context.convertAnother(reader.getValue(), String.class));
			} else if (reader.getNodeName().equals(OUTPUTFOLDER_NODE)) {
				configuration.setOutputFolder((String) context.convertAnother(reader.getValue(), String.class));
			} else if (reader.getNodeName().equals(FILE_NODE)) {
				String className = reader.getAttribute(CLASS_ATTRIBUTE);
				BeanConfigurationContainer bean = new BeanConfigurationContainer(className, reader.getValue());
				if (reader.getAttributeCount() > 1) {
					for (int att = 1; att < reader.getAttributeCount(); att++) {
						bean.addAdditionalAttribute(reader.getAttributeName(att), reader.getAttribute(att));
					}
				}
				beanConfigurations.put(bean.getClassName(), bean);
			}
			reader.moveUp();
		}
		configuration.setBeanConfigurations(beanConfigurations);
		return configuration;
	}
}

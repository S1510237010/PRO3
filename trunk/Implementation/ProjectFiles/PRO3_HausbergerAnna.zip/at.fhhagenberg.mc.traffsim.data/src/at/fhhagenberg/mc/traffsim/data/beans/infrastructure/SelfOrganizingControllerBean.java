package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("SelfOrganizingController")
public class SelfOrganizingControllerBean extends TrafficLightControllerBean {

	private static final long serialVersionUID = 1L;

	private int mode;
	private long maxCycleLength;
	private long targetCycleLength;
	private boolean useHeuristics;
	private long updateInterval;

	public int getMode() {
		return mode;
	}

	public void setMode(int mode) {
		this.mode = mode;
	}

	public long getMaxCycleLength() {
		return maxCycleLength;
	}

	public void setMaxCycleLength(long maxCycleLength) {
		this.maxCycleLength = maxCycleLength;
	}

	public long getTargetCycleLength() {
		return targetCycleLength;
	}

	public void setTargetCycleLength(long targetCycleLength) {
		this.targetCycleLength = targetCycleLength;
	}

	public boolean getUseHeuristics() {
		return useHeuristics;
	}

	public void setUseHeuristics(boolean useHeuristics) {
		this.useHeuristics = useHeuristics;
	}

	public long getUpdateInterval() {
		return updateInterval;
	}

	public void setUpdateInterval(long updateInterval) {
		this.updateInterval = updateInterval;
	}
}

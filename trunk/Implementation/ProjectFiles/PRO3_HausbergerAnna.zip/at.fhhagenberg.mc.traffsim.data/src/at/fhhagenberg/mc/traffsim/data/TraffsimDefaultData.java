package at.fhhagenberg.mc.traffsim.data;

public interface TraffsimDefaultData {
	String DIRECTORY_NAME = "data_default";
	String MODELS_XML_NAME = "models.xml";
	String PARAMETERS_XML_NAME = "parameters.xml";
	String CONTROLS_XML_NAME = "controls.xml";
	String TRAFFIC_GENERATORS_XML_NAME = "trafficGenerators.xml";
	String INTERSECTION_CONTROLS_XML_NAME = "intersectionControls.xml";
	String BEHAVIORS_XML_NAME = "behaviors.xml";
	String DETECTORS_XML_NAME = "detectors.xml";
	String VEHICLES_XML_NAME = "vehicles.xml";
	String ROUTES_XML_NAME = "routes.xml";
	String ROAD_NETWORK_XML_NAME = "roadnetwork.xml";
	String OBSTRUCTIONS_XML_NAME = "obstructions.xml";
	String VEHICLE_COMMUNICATIONS_XML_NAME = "vehicleCommData.xml";
	String SEPARATOR = "/";
}
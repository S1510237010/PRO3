package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("SelfOrganizing")
public class SelfOrganizingControlLogicBean extends ControlLogicBean {

	private static final long serialVersionUID = 1L;

	private long timeHorizon;
	private long passOverTime;
	private long startUpLossTime;

	public long getTimeHorizon() {
		return timeHorizon;
	}

	public void setTimeHorizon(long timeHorizon) {
		this.timeHorizon = timeHorizon;
	}

	public long getPassOverTime() {
		return passOverTime;
	}

	public void setPassOverTime(long passOverTime) {
		this.passOverTime = passOverTime;
	}

	public long getStartUpLossTime() {
		return startUpLossTime;
	}

	public void setStartUpLossTime(long startUpLossTime) {
		this.startUpLossTime = startUpLossTime;
	}
}

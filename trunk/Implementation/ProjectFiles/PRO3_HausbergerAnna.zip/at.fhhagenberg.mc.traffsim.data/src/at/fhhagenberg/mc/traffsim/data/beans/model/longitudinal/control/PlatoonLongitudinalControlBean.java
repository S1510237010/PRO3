package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control;

import com.thoughtworks.xstream.annotations.XStreamAlias;


@XStreamAlias("PlatoonControl")
public class PlatoonLongitudinalControlBean extends LongitudinalControlBean{

	private static final long serialVersionUID = -1382709691938778149L;
	
	/**
	 * Identifier for the leader model
	 */
	private String leaderLongitudinalModelIdentifier;
	
	/**
	 * Identifier for the follower model
	 */
	private String followerLongitudinalModelIdentifier;
	
	/**
	 * Identifier for maneuver longitudinal model
	 */
	private String maneuverLongitudinalModelIdentifier = null;
	
	/**
	 * Identifier for the human model
	 */
	private String humanLongitudinalModelIdentifier;
	
	/**
	 * Get leader longitudinal model identifier
	 * @return identifier
	 */
	public String getLeaderLongitudinalModelIdentifier() {
		return leaderLongitudinalModelIdentifier;
	}

	/**
	 * Set leader longitudinal model identifier
	 * @param leaderLongitudinalModelIdentifier identifier
	 */
	public void setLeaderLongitudinalModelIdentifier(String leaderLongitudinalModelIdentifier) {
		this.leaderLongitudinalModelIdentifier = leaderLongitudinalModelIdentifier;
	}
	
	/**
	 * Get follower longitudinal model identifier
	 * @return identifier
	 */
	public String getFollowerLongitudinalModelIdentifier() {
		return followerLongitudinalModelIdentifier;
	}

	/**
	 * Set follower longitudinal model identifier
	 * @param followerLongitudinalModelIdentifier identifier
	 */
	public void setFollowerLongitudinalModelIdentifier(String followerLongitudinalModelIdentifier) {
		this.followerLongitudinalModelIdentifier = followerLongitudinalModelIdentifier;
	}
	
	
	/**
	 * Set maneuver longitudinal model identifier
	 * @return identifier
	 */
	public String getManeuverLongitudinalModelIdentifier() {
		return maneuverLongitudinalModelIdentifier;
	}

	/**
	 * Get maneuver longitudinal model identifier
	 * @param maneuverLongitudinalModelIdentifier identifier
	 */
	public void setManeuverLongitudinalModelIdentifier(String maneuverLongitudinalModelIdentifier) {
		this.maneuverLongitudinalModelIdentifier = maneuverLongitudinalModelIdentifier;
	}

	/**
	 * Get human longitudinal model identifier
	 * @return identifier
	 */
	public String getHumanLongitudinalModelIdentifier() {
		return humanLongitudinalModelIdentifier;
	}

	/**
	 * Set human longitudinal model identifier
	 * @param humanLongitudinalModelIdentifier
	 */
	public void setHumanLongitudinalModelIdentifier(String humanLongitudinalModelIdentifier) {
		this.humanLongitudinalModelIdentifier = humanLongitudinalModelIdentifier;
	}
}

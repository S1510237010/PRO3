package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public abstract class ControlLogicBean extends IntersectionControlBean {

	private static final long serialVersionUID = 1L;

	@XStreamAsAttribute
	private long trafficLightId;

	public long getTrafficLightId() {
		return trafficLightId;
	}

	public void setTrafficLightId(long trafficLightId) {
		this.trafficLightId = trafficLightId;
	}
}

package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

public enum NodeType {
	SIMPLE, DRIVE_THROUGH, TRAFFIC_LIGHT, ROUNDABOUT
}

package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Connector")
public class ConnectorBean extends InfrastructureBean {
	private static final long serialVersionUID = 1L;
	private long fromSegment;
	private int fromLane;
	private long toSegment;
	private int toLane;
	private int priority;
	private long nodeId;
	private String roadSign;
	private double shrinkFactor = -1;
	private int smoothing = -1;

	public ConnectorBean() {
		super();
	}

	public ConnectorBean(long id, long fromSegment, int fromLane, long toSegment, int toLane, int priority, long nodeId, String roadSign) {
		this();
		this.id = id;
		this.fromSegment = fromSegment;
		this.fromLane = fromLane;
		this.toSegment = toSegment;
		this.toLane = toLane;
		this.priority = priority;
		this.nodeId = nodeId;
		this.roadSign = roadSign;
	}

	public long getFromSegment() {
		return fromSegment;
	}

	public void setFromSegment(long fromSegment) {
		this.fromSegment = fromSegment;
	}

	public long getToSegment() {
		return toSegment;
	}

	public void setToSegment(long toSegment) {
		this.toSegment = toSegment;
	}

	public int getFromLane() {
		return fromLane;
	}

	public void setFromLane(int fromLane) {
		this.fromLane = fromLane;
	}

	public int getToLane() {
		return toLane;
	}

	public void setToLane(int toLane) {
		this.toLane = toLane;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getRoadSign() {
		return roadSign;
	}

	public void setRoadSign(String roadSign) {
		this.roadSign = roadSign;
	}

	public long getNodeId() {
		return nodeId;
	}

	public void setNodeId(long nodeId) {
		this.nodeId = nodeId;
	}

	public double getShrinkFactor() {
		return shrinkFactor;
	}

	public void setShrinkFactor(double widthFactor) {
		this.shrinkFactor = widthFactor;
	}

	public int getSmoothing() {
		return smoothing;
	}

	public void setSmoothing(int smoothing) {
		this.smoothing = smoothing;
	}
}

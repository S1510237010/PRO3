package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.CoordinateBean;

/**
 * Data container of a road segment. This represents a part of a road in one direction, including detailed lane information with geometries,
 * lane width and other info which is not available in OSM, but must be extended by TraffSim.
 *
 * @author Christian B.
 *
 */
@XStreamAlias("RoadSegment")
public class RoadSegmentBean extends BaseRoadSegmentBean {
	private static final long serialVersionUID = 1L;
	/** The geometry of this particular segment when junctions are considered */
	private List<CoordinateBean> fittedPoints;

	private List<LaneSegmentBean> laneSegments;
	private double defaultLaneWidth;

	public RoadSegmentBean() {
		super();
	}

	public RoadSegmentBean(List<CoordinateBean> points, long sourceNodeId, long sinkNodeId, int laneCount, long routingId, long id,
			String name, boolean reverse) {
		super(points, sourceNodeId, sinkNodeId, laneCount, routingId, id, name, reverse);
	}

	public List<LaneSegmentBean> getLaneSegments() {
		return laneSegments;
	}

	public void setLaneSegments(List<LaneSegmentBean> laneSegments) {
		this.laneSegments = laneSegments;
	}

	public double getDefaultLaneWidth() {
		return defaultLaneWidth;
	}

	public void setDefaultLaneWidth(double defaultLaneWidth) {
		this.defaultLaneWidth = defaultLaneWidth;
	}

	public List<CoordinateBean> getFittedPoints() {
		return fittedPoints;
	}

	public void setFittedPoints(List<CoordinateBean> fittedPoints) {
		this.fittedPoints = fittedPoints;
	}
}
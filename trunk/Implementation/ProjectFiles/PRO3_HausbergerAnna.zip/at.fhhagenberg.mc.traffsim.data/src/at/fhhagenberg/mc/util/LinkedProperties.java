package at.fhhagenberg.mc.util;

import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

public class LinkedProperties extends Properties {

	private static final long serialVersionUID = 1L;

	private Map<Object, Object> linkMap = new LinkedHashMap<Object, Object>();

	@Override
	public synchronized Object put(Object key, Object value) {
		super.put(key, value);
		return linkMap.put(key, value);
	}

	@Override
	public Set<Object> keySet() {
		return linkMap.keySet();
	}

	@Override
	public synchronized void forEach(BiConsumer<? super Object, ? super Object> action) {
		linkMap.forEach(action);
	}

	@Override
	public synchronized void putAll(Map<? extends Object, ? extends Object> t) {
		super.putAll(t);
		linkMap.putAll(t);
	}

	@Override
	public synchronized Object putIfAbsent(Object key, Object value) {
		super.putIfAbsent(key, value);
		return linkMap.putIfAbsent(key, value);
	}

	@Override
	public synchronized boolean replace(Object key, Object oldValue, Object newValue) {
		super.replace(key, oldValue, newValue);
		return linkMap.replace(key, oldValue, newValue);
	}

	@Override
	public synchronized Object replace(Object key, Object value) {
		super.replace(key, value);
		return linkMap.replace(key, value);
	}

	@Override
	public synchronized void replaceAll(BiFunction<? super Object, ? super Object, ? extends Object> function) {
		super.replaceAll(function);
		linkMap.replaceAll(function);
	}

	@Override
	public synchronized Enumeration<Object> elements() {
		throw new UnsupportedOperationException("Enumerations are so old-school, don't use them, " + "use keySet() or entrySet() instead");
	}

	@Override
	public Set<java.util.Map.Entry<Object, Object>> entrySet() {
		return linkMap.entrySet();
	}

	@Override
	public synchronized void clear() {
		super.clear();
		linkMap.clear();
	}

	@Override
	public synchronized Object remove(Object key) {
		super.remove(key);
		return linkMap.remove(key);
	}

	@Override
	public synchronized boolean containsKey(Object key) {
		return linkMap.containsKey(key);
	}

}
package at.fhhagenberg.mc.traffsim.data.beans;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public abstract class LabeledBean {
	@XStreamAsAttribute
	private String label;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

}

package at.fhhagenberg.mc.traffsim.data.beans.model.platoon;

import java.util.Date;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Data bean for a platoon action
 * 
 * @author Sebastian Huber
 *
 */
@XStreamAlias("PlatoonAction")
public class PlatoonActionDataBean{
	
	/**
	 * Id of platoon
	 */
	private long platoonId;
	
	/**
	 * Id of vehicle
	 */
	private long vehicleId;
	
	/**
	 * Position for maneuver (not mandatory)
	 */
	private int position;
	
	/**
	 * Type of action
	 */
	private String action;
	
	/**
	 * Time of action
	 */
	private Date time;
	
	/**
	 * Flag to force an action (force means do it without join procedure)
	 */
	private boolean force;
	
	/**
	 * Platoon id
	 * @return id 
	 */
	public long getPlatoonId() {
		return platoonId;
	}
	
	/**
	 * Platoon id
	 * @param platoonId id
	 */
	public void setPlatoonId(long platoonId) {
		this.platoonId = platoonId;
	}
	
	/**
	 * Vehicle id
	 * @return id
	 */
	public long getVehicleId() {
		return vehicleId;
	}
	
	/**
	 * Vehicle id
	 * @param vehicleId id
	 */
	public void setVehicleId(long vehicleId) {
		this.vehicleId = vehicleId;
	}
	
	/**
	 * Get position for maneuver
	 * @return position
	 */
	public int getPosition() {
		return position;
	}

	/**
	 * Set position for maneuver
	 * @param position position (0 to size of platoon)
	 */
	public void setPosition(int position) {
		this.position = position;
	}

	/**
	 * Action to perform
	 * @return action
	 */
	public String getAction() {
		return action;
	}
	
	/**
	 * Action to perform
	 * @param action action
	 */
	public void setAction(String action) {
		this.action = action;
	}
	
	/**
	 * Time to perform action
	 * @return time
	 */
	public Date getTime() {
		return time;
	}
	
	/**
	 * Time to perform action
	 * @param time time
	 */
	public void setTime(Date time) {
		this.time = time;
	}

	/**
	 * Get force flag for action (do action without maneuver procedure)
	 * @return force flag
	 */
	public boolean isForce() {
		return force;
	}

	/**
	 * Set force flag for action 
	 * @param force force flag
	 */
	public void setForce(boolean force) {
		this.force = force;
	}
}

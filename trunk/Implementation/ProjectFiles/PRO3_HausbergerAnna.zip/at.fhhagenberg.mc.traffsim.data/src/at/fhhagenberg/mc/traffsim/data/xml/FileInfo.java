package at.fhhagenberg.mc.traffsim.data.xml;

import java.io.Serializable;

/**
 * File information class for XML configuration files, which contains the filename and the last modified date for verification whether or
 * not a cached data must be refreshed
 *
 * @author Christian
 *
 */
public class FileInfo implements Serializable {

	private static final long serialVersionUID = 4643275705565139176L;
	private Long modifiedDate;
	private String fileName;

	public FileInfo() {
	}

	public FileInfo(Long modifiedDate, String fileName) {
		super();
		this.modifiedDate = modifiedDate;
		this.fileName = fileName;
	}

	public Long getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Long modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}

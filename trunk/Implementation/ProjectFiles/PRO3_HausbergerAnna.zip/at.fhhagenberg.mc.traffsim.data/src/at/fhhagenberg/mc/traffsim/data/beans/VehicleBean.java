package at.fhhagenberg.mc.traffsim.data.beans;

import java.util.Date;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.converters.basic.DateConverter;

@XStreamAlias("Vehicle")
public class VehicleBean extends AbstractBean {
	private static final long serialVersionUID = 1L;
	private String label = "";
	private String vehicleType;
	private double length;
	private double width;
	private String laneChaneModelIdentifier = "";
	private String longitudinalControlIdentifier = "";
	private String consumptionIdentifier = "";
	private String memoryIdentifier = "";
	private long routeId;
	private Date startDate;
	private double initialSpeed;
	private boolean deactivated = false;
	private boolean leaderCapability = false;
	
	/**
	 * @deprecated use properties in {@link VehicleCommDataBean} instead! only kept for compatibility reasons.
	 */
	@Deprecated
	private Long routeUpdateInterval;

	/**
	 * Communication data reference. Default value <code>null</code> means non-communicating vehicle
	 */
	private Long commDataId = null;

	@Override
	public String getLabel() {
		return label;
	}

	@Override
	public void setLabel(String label) {
		this.label = label;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getLaneChaneModelIdentifier() {
		return laneChaneModelIdentifier;
	}

	public void setLaneChaneModelIdentifier(String laneChaneModelIdentifier) {
		this.laneChaneModelIdentifier = laneChaneModelIdentifier;
	}

	public String getLongitudinalControlIdentifier() {
		return longitudinalControlIdentifier;
	}

	public void setLongitudinalControlIdentifier(String longitudinalControlIdentifier) {
		this.longitudinalControlIdentifier = longitudinalControlIdentifier;
	}

	public long getRouteId() {
		return routeId;
	}

	public void setRouteId(long routeId) {
		this.routeId = routeId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getMemoryIdentifier() {
		return memoryIdentifier;
	}

	public void setMemoryIdentifier(String memoryIdentifier) {
		this.memoryIdentifier = memoryIdentifier;
	}

	public double getInitialSpeed() {
		return initialSpeed;
	}

	public void setInitialSpeed(double initialSpeed) {
		this.initialSpeed = initialSpeed;
	}

	public String getConsumptionIdentifier() {
		return consumptionIdentifier;
	}

	public void setConsumptionIdentifier(String consumptionIdentifier) {
		this.consumptionIdentifier = consumptionIdentifier;
	}
	
	public boolean getDeactivated(){
		return deactivated;
	}
	
	public void setDeactivated(boolean deactivated){
		this.deactivated = deactivated;
	}

	public boolean hasLeaderCapability() {
		return leaderCapability;
	}

	public void setLeaderCapability(boolean leaderCapability) {
		this.leaderCapability = leaderCapability;
	}

	/**
	 * @deprecated use {@link VehicleCommDataBean} and {@link #setCommDataId(Long)} instead
	 * @return the route update interval
	 */
	@Deprecated
	public long getRouteUpdateInterval() {
		return routeUpdateInterval;
	}

	/**
	 * @deprecated use {@link VehicleCommDataBean} and {@link #setCommDataId(Long)} instead
	 *
	 * @param routeUpdateInterval
	 */
	@Deprecated
	public void setRouteUpdateInterval(Long routeUpdateInterval) {
		this.routeUpdateInterval = routeUpdateInterval;
	}

	/**
	 * Set date for calls via reflection
	 *
	 * @param date
	 *            the date as {@link String}, as converted by {@link DateConverter} or {@link Date}
	 */
	public void setStartDate(Object date) {
		if (date == null) {
			this.startDate = null;
		} else if (date instanceof Date) {
			this.startDate = (Date) date;
		} else if (date instanceof String) {
			this.startDate = (Date) new DateConverter().fromString((String) date);
		} else {
			throw new IllegalArgumentException("Cannot handle given start date type");
		}
	}

	/**
	 * Set update interval via reflectio
	 *
	 * @deprecated use {@link VehicleCommDataBean} and {@link #setCommDataId(Long)} instead
	 * @param obj
	 *            the new update interval, can be <code>null</code>, instanceof {@link String} or {@link Long}
	 */
	@Deprecated
	public void setRouteUpdateInterval(Object obj) {
		if (obj == null) {
			routeUpdateInterval = null;
		} else if (obj instanceof String) {
			routeUpdateInterval = Long.parseLong((String) obj);
		} else if (obj instanceof Long) {
			routeUpdateInterval = (Long) obj;
		} else {
			throw new IllegalArgumentException("Cannot handle given start date type");
		}
	}

	public Long getCommDataId() {
		return commDataId;
	}

	public void setCommDataId(Long commDataId) {
		this.commDataId = commDataId;
	}

	/**
	 * Set comm data id via reflectio
	 *
	 * @param obj
	 *            the new update interval, can be <code>null</code>, instanceof {@link String} or {@link Long}
	 */
	public void setCommDataId(Object obj) {
		if (obj == null) {
			commDataId = null;
		} else if (obj instanceof String) {
			commDataId = Long.parseLong((String) obj);
		} else if (obj instanceof Long) {
			commDataId = (Long) obj;
		} else {
			throw new IllegalArgumentException("Cannot handle given start date type");
		}
	}

	public boolean isCommEnabled() {
		return commDataId != null && commDataId >= 0;
	}

}

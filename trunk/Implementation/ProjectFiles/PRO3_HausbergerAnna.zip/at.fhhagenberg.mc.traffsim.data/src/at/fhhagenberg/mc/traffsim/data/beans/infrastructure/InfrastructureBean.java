package at.fhhagenberg.mc.traffsim.data.beans.infrastructure;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;

/**
 * All files which are related to infrastructure can derive from this class to be located in the same file.
 *
 * @author Christian Backfrieder
 *
 */
public abstract class InfrastructureBean extends AbstractBean {

	private static final long serialVersionUID = 1L;
}

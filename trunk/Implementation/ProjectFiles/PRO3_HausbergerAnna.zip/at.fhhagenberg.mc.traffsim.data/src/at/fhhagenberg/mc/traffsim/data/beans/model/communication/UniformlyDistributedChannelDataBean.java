package at.fhhagenberg.mc.traffsim.data.beans.model.communication;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("UniChannel")
public class UniformlyDistributedChannelDataBean extends ModelBean {
	private static final long serialVersionUID = 1L;
	/** success probability for transmission */
	private double pSuccess;
	/** OPTIONAL: random seed for initialization (null if unused) */
	private Long randomSeed;

	public UniformlyDistributedChannelDataBean() {
	}

	public double getpSuccess() {
		return pSuccess;
	}

	public void setpSuccess(double pSuccess) {
		this.pSuccess = pSuccess;
	}

	public Long getRandomSeed() {
		return randomSeed;
	}

	public void setRandomSeed(Long randomSeed) {
		this.randomSeed = randomSeed;
	}

}

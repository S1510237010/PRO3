package at.fhhagenberg.mc.traffsim.data.xml;

import at.fhhagenberg.mc.traffsim.data.beans.AbstractBean;
import at.fhhagenberg.mc.traffsim.data.beans.BehaviorBean;
import at.fhhagenberg.mc.traffsim.data.beans.CoordinateBean;
import at.fhhagenberg.mc.traffsim.data.beans.LabeledBean;
import at.fhhagenberg.mc.traffsim.data.beans.ListBean;
import at.fhhagenberg.mc.traffsim.data.beans.ParameterBean;
import at.fhhagenberg.mc.traffsim.data.beans.RouteBean;
import at.fhhagenberg.mc.traffsim.data.beans.TraffSimConfiguration;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficGeneratorBean;
import at.fhhagenberg.mc.traffsim.data.beans.TrafficObstructionBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleBean;
import at.fhhagenberg.mc.traffsim.data.beans.VehicleCommDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.BaseRoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ConnectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.ControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.CyclicControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.CyclicControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.DetectorBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.FixedTimeControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.FixedTimeControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.InfrastructureBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.IntersectionControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.LaneSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.NodeBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RemovedRoutingIdsBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.RoadSegmentBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.SelfOrganizingControlLogicBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.SelfOrganizingControllerBean;
import at.fhhagenberg.mc.traffsim.data.beans.infrastructure.TrafficLightBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.GeometricDistributionChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.GilbertElliotChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.communication.UniformlyDistributedChannelDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.ConsumptionCarDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.consumption.EngineDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.distraction.DistractionModelBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.distraction.DistractionTypeBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.CACCLaneChangeDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.LaneChangeModelInputDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.lanechange.MOBILDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.ACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.CACCDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.GippsDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.IIDMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.KraussDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.LongitudinalModelInputDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.MemoryDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.OVMDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation.DrivingRegimeBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.automation.SpeedRangeBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ContainerControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.DefaultLongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.ExtendedHumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.HumanDriverControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.LongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.PlatoonLongitudinalControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.control.VehicleAutomationControlBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.NoiseDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal.human.RTDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.platoon.PlatoonActionDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.platoon.PlatoonDataBean;
import at.fhhagenberg.mc.traffsim.data.beans.model.platoon.PlatoonManagerDataBean;

public class DefaultProcessedClasses {
	public static Class<?>[] XML_BEANS = new Class<?>[] { AbstractBean.class, VehicleAutomationControlBean.class, ContainerControlBean.class,
			LongitudinalControlBean.class, CoordinateBean.class, RouteBean.class, TrafficGeneratorBean.class, TrafficObstructionBean.class,
			TraffSimConfiguration.class, VehicleBean.class, BehaviorBean.class, InfrastructureBean.class, BaseRoadSegmentBean.class,
			ConnectorBean.class, LaneSegmentBean.class, NodeBean.class, RoadSegmentBean.class, TrafficLightBean.class, ConsumptionBean.class,
			ConsumptionCarDataBean.class, EngineDataBean.class, LaneChangeModelInputDataBean.class, MOBILDataBean.class, ACCDataBean.class,
			IDMDataBean.class, IIDMDataBean.class, HumanDriverControlBean.class, ExtendedHumanDriverControlBean.class, GippsDataBean.class,
			RTDataBean.class, LongitudinalModelInputDataBean.class, MemoryDataBean.class, SpeedRangeBean.class, DrivingRegimeBean.class,
			NoiseDataBean.class, ModelBean.class, RemovedRoutingIdsBean.class, ParameterBean.class, OVMDataBean.class, KraussDataBean.class,
			ListBean.class, LabeledBean.class, VehicleCommDataBean.class, GilbertElliotChannelDataBean.class, DetectorBean.class,
			DefaultLongitudinalControlBean.class, GeometricDistributionChannelDataBean.class, UniformlyDistributedChannelDataBean.class,
			IntersectionControlBean.class, TrafficGeneratorBean.class, CyclicControllerBean.class, FixedTimeControllerBean.class,
			ControlLogicBean.class, CyclicControlLogicBean.class, FixedTimeControlLogicBean.class, SelfOrganizingControlLogicBean.class,
			SelfOrganizingControllerBean.class, DistractionModelBean.class, DistractionTypeBean.class, CACCLaneChangeDataBean.class,
			CACCDataBean.class, PlatoonLongitudinalControlBean.class, PlatoonActionDataBean.class, PlatoonManagerDataBean.class,
			PlatoonDataBean.class};
}

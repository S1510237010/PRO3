package at.fhhagenberg.mc.traffsim.data.beans.model.longitudinal;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("MEMORY")
public class MemoryDataBean extends ModelBean {
	private static final long serialVersionUID = 1L;
	/** The resignation max alpha t. unitless */
	private double resignationMaxAlphaT;

	/** The resignation min alpha a. unitless */
	private double resignationMinAlphaA;
	/** The resignation min alpha v0. unitless */
	private double resignationMinAlphaV0;

	/** The tau. in seconds */
	private double tau;

	public double getResignationMaxAlphaT() {
		return resignationMaxAlphaT;
	}

	public double getResignationMinAlphaA() {
		return resignationMinAlphaA;
	}

	public double getResignationMinAlphaV0() {
		return resignationMinAlphaV0;
	}

	public double getTau() {
		return tau;
	}

	public void setResignationMaxAlphaT(double resignationMaxAlphaT) {
		this.resignationMaxAlphaT = resignationMaxAlphaT;
	}

	public void setResignationMinAlphaA(double resignationMinAlphaA) {
		this.resignationMinAlphaA = resignationMinAlphaA;
	}

	public void setResignationMinAlphaV0(double resignationMinAlphaV0) {
		this.resignationMinAlphaV0 = resignationMinAlphaV0;
	}

	public void setTau(double tau) {
		this.tau = tau;
	}
}
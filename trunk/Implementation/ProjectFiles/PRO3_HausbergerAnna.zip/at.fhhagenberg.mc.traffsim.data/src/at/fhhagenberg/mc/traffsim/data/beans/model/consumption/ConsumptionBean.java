package at.fhhagenberg.mc.traffsim.data.beans.model.consumption;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import at.fhhagenberg.mc.traffsim.data.beans.model.ModelBean;

@XStreamAlias("CONSUMPTION")
public class ConsumptionBean extends ModelBean {
	private static final long serialVersionUID = 1L;
	private ConsumptionCarDataBean carData;
	private EngineDataBean engineData;

	public ConsumptionCarDataBean getCarData() {
		return carData;
	}

	public void setCarData(ConsumptionCarDataBean carData) {
		this.carData = carData;
	}

	public EngineDataBean getEngineData() {
		return engineData;
	}

	public void setEngineData(EngineDataBean engineData) {
		this.engineData = engineData;
	}
}
